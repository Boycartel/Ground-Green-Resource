<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>


</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Get Password</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-upload"></i>
                                </a>
                            </li>
                            <li><span></span></li>

                        </ol>


                    </div>
                </header>

                <!-- start: page -->

                <div class="row">

                    <div class="col-lg-12  col-md-12">

                        <div class="col-lg-12">
                            <section class="panel panel-success">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>

                                    <h2 class="panel-title">Get Password</h2>
                                </header>
                                <div class="panel-body">
                                    <?php
                                    $name1 = $password = $decryption = "";
                                    $sql = "SELECT * FROM reg_password";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $stdid = $row["stdid"];
                                            $password = $row["pword"];

                                            //$name1=$row["full_name"];
                                            $ciphering = "AES-128-CTR";
                                            // Use OpenSSl Encryption method
                                            $iv_length = openssl_cipher_iv_length($ciphering);
                                            $options = 0;
                                            // Non-NULL Initialization Vector for encryption
                                            $encryption_iv = '1999201920202021';
                                            //$encryption_iv = '1234567891011121';
                                            // Store the encryption key
                                            $encryption_key = "FUTMinnaEresults";

                                            // Use openssl_encrypt() function to encrypt the data
                                            $encryption = openssl_encrypt(
                                                $password,
                                                $ciphering,
                                                $encryption_key,
                                                $options,
                                                $encryption_iv
                                            );

                                            $sql2 = "UPDATE reg_password SET pword2='$encryption' WHERE stdid='$stdid'";
                                            $result2 = $conn->query($sql2);
                                        }
                                    }



                                    ?>
                                    <form class="form-horizontal form-bordered" method="post">

                                        <br>

                                        <div class="form-group">
                                            <div class="form-group">
                                                <div class="col-lg-3">

                                                </div>
                                                <div class="col-lg-6">
                                                    <label for="staff">End</label><br>

                                                </div>
                                                <div class="col-lg-3">

                                                </div>
                                            </div>

                                        </div>

                                    </form>

                                </div>

                            </section>


                        </div>

                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-autosize/jquery.autosize.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Print Div-->
    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Download Senate Summary</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Download
                            </li>

                            <li class="active">
                                <strong>Download Senate Summary</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Download Senate Summary
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form class="form-horizontal" method="post">
                                    <div class="col-lg-1">

                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">

                                            <label class="control-label col-lg-3" for="regid">Session:</label>
                                            <div class="col-lg-8">
                                                <select name="getsession" class="form-control" style="color:#000000"
                                                    id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    $iniyear = 2015;
                                                    $finalyear = substr($_SESSION['corntsession'], 5);

                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">

                                            <label class="control-label col-lg-3" for="regid">Semester:</label>
                                            <div class="col-lg-8">
                                                <select name="getsemester" class="form-control" style="color:#000000"
                                                    id="getsemester">
                                                    <option value=''></option>
                                                    <option value='1ST'>1ST</option>
                                                    <option value='2ND'>2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-9">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1">

                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                if (isset($_POST["submit"])) {
                                    $getsemester = $_POST['getsemester'];
                                    $getsession = $_POST['getsession'];

                                    if ($getsemester == "1ST") {
                                        $getsemester2 = "First Semester";
                                    } else {
                                        $getsemester2 = "Second Semester";
                                    }

                                ?>
                                <div class="col-lg-12  col-md-12">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <?php
                                            set_time_limit(500);

                                            ?>
                                        <div id="printableAreaAll">
                                            <p style="font-size: large; color:black; text-align:center">
                                                <strong><?php echo $_SESSION['instname'] ?><br>
                                                    EXAMINATION RESULTS SCRUTINY COMMITTEE</strong>
                                            </p>
                                            <br><br>
                                            <p style="font-size: large; color:black; text-align:center;">
                                                <strong>COMMUNICATION FROM SENATE
                                                    EXAMINATION
                                                    RESULTS SCRUTINY
                                                    COMMITTEE</strong>
                                            </p>
                                            <br>
                                            <?php
                                                $sno1 = 0;
                                                $sql3 = "SELECT * FROM schoolname ORDER BY SchName";
                                                $result3 = $conn->query($sql3);
                                                if ($result3->num_rows > 0) {
                                                    while ($row3 = $result3->fetch_assoc()) {
                                                        $sno1++;
                                                        $SchCode = $row3["SchCode"];
                                                        $SchName = $row3["SchName"];
                                                ?>
                                            <p style="font-size:large; color:black"><?php echo $sno1 . ".0" ?>
                                                <u><strong>Submission from
                                                        <?php echo $SchName . "(" . $SchCode . ")" ?></strong></u>
                                            </p>
                                            <?php
                                                        $sno2 = 0;
                                                        $sql2 = "SELECT * FROM deptcoding WHERE School = '$SchCode' ORDER BY DeptName";
                                                        $result2 = $conn->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {

                                                                $DeptCode = $row2["DeptCode"];
                                                                $DeptName = $row2["DeptName"];
                                                                $DeptCode2 = strtolower($DeptCode);

                                                                $dept_db = $_SESSION['deptdb'] . strtolower($DeptCode2);
                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                if ($conn_stu->connect_error) {
                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                }

                                                                $Level100 = $Level200 = $Level300 = $Level400 = $Level500 = 0;
                                                                $PCount100 = $IGSCount100 = $DEFCount100 = $SP1Count100 = $SP2Count100 = $DLCount100 = $VCLCount100 = $Ten88Count100 = $BL2Count100 = 0;
                                                                $PCount200 = $IGSCount200 = $DEFCount200 = $SP1Count200 = $SP2Count200 = $DLCount200 = $VCLCount200 = 0;
                                                                $PCount300 = $IGSCount300 = $DEFCount300 = $SP1Count300 = $SP2Count300 = $DLCount300 = $VCLCount300 = 0;
                                                                $PCount400 = $IGSCount400 = $DEFCount400 = $SP1Count400 = $SP2Count400 = $DLCount400 = $VCLCount400 = 0;
                                                                $PCount500 = $IGSCount500 = $DEFCount500 = $SP1Count500 = $SP2Count500 = $DLCount500 = $VCLCount500 = 0;
                                                                //$DeptCode2 = "mat";
                                                                $sql4 = "select 1 from scrutiny_senate";
                                                                $exists = $conn_stu->query($sql4);

                                                                if ($exists == true) {

                                                                    $sno2++;
                                                        ?>
                                            <p style="color:#000000">
                                                <?php echo $sno1 . "." . $sno2 ?> <?php echo $DeptName ?></p>

                                            <p style="color:#000000"><strong>
                                                    <?php echo $getsemester2 ?> <?php echo $getsession ?>
                                                    Session</strong>
                                            </p>

                                            <table class="table mb-none" style="width: 97%;">
                                                <thead>
                                                    <tr>
                                                        <th style='text-align: center;'>LEVEL</th>
                                                        <th style='text-align: center;'>VL</th>
                                                        <th style='text-align: center;'>DL</th>
                                                        <th style='text-align: center;'>IGS</th>
                                                        <th style='text-align: center;'>DEF</th>
                                                        <th style='text-align: center;'>P</th>
                                                        <th style='text-align: center;'>SP1</th>
                                                        <th style='text-align: center;'>SP2</th>
                                                        <?php
                                                                                if ($SchCode == "SEET" || $SchCode == "SIPET") {
                                                                                    if ($getsemester = "2ND") {
                                                                                        echo "<th>10-8-8</th>";
                                                                                        echo "<th>BL2</th>";
                                                                                    }
                                                                                }
                                                                                ?>

                                                        <th>TOTAL</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php


                                                                            $sql = "SELECT * FROM scrutiny_senate WHERE session1 = '$getsession' AND semester = '$getsemester'";
                                                                            $result = $conn_stu->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {

                                                                                    if ($row["Level1"] == "100") {
                                                                                        $Level100++;
                                                                                        if ($row["RMK"] == "VL") {
                                                                                            $VCLCount100++;
                                                                                        } elseif ($row["RMK"] == "DL") {
                                                                                            $DLCount100++;
                                                                                        } elseif ($row["RMK"] == "IGS") {
                                                                                            $IGSCount100++;
                                                                                        } elseif ($row["RMK"] == "DEF") {
                                                                                            $DEFCount100++;
                                                                                        } elseif ($row["RMK"] == "P") {
                                                                                            $PCount100++;
                                                                                        } elseif ($row["RMK"] == "SP1") {
                                                                                            $SP1Count100++;
                                                                                        } elseif ($row["RMK"] == "SP2") {
                                                                                            $SP2Count100++;
                                                                                        } elseif ($row["RMK"] == "8-7-6") {
                                                                                            $Ten88Count100++;
                                                                                        } elseif ($row["RMK"] == "BL2") {
                                                                                            $BL2Count100++;
                                                                                        }
                                                                                    } elseif ($row["Level1"] == "200") {
                                                                                        $Level200++;
                                                                                        if ($row["RMK"] == "VL") {
                                                                                            $VCLCount200++;
                                                                                        } elseif ($row["RMK"] == "DL") {
                                                                                            $DLCount200++;
                                                                                        } elseif ($row["RMK"] == "IGS") {
                                                                                            $IGSCount200++;
                                                                                        } elseif ($row["RMK"] == "DEF") {
                                                                                            $DEFCount200++;
                                                                                        } elseif ($row["RMK"] == "P") {
                                                                                            $PCount200++;
                                                                                        } elseif ($row["RMK"] == "SP1") {
                                                                                            $SP1Count200++;
                                                                                        } elseif ($row["RMK"] == "SP2") {
                                                                                            $SP2Count200++;
                                                                                        }
                                                                                    } elseif ($row["Level1"] == "300") {
                                                                                        $Level300++;
                                                                                        if ($row["RMK"] == "VL") {
                                                                                            $VCLCount300++;
                                                                                        } elseif ($row["RMK"] == "DL") {
                                                                                            $DLCount300++;
                                                                                        } elseif ($row["RMK"] == "IGS") {
                                                                                            $IGSCount300++;
                                                                                        } elseif ($row["RMK"] == "DEF") {
                                                                                            $DEFCount300++;
                                                                                        } elseif ($row["RMK"] == "P") {
                                                                                            $PCount300++;
                                                                                        } elseif ($row["RMK"] == "SP1") {
                                                                                            $SP1Count300++;
                                                                                        } elseif ($row["RMK"] == "SP2") {
                                                                                            $SP2Count300++;
                                                                                        }
                                                                                    } elseif ($row["Level1"] == "400") {
                                                                                        $Level400++;
                                                                                        if ($row["RMK"] == "VL") {
                                                                                            $VCLCount400++;
                                                                                        } elseif ($row["RMK"] == "DL") {
                                                                                            $DLCount400++;
                                                                                        } elseif ($row["RMK"] == "IGS") {
                                                                                            $IGSCount400++;
                                                                                        } elseif ($row["RMK"] == "DEF") {
                                                                                            $DEFCount400++;
                                                                                        } elseif ($row["RMK"] == "P") {
                                                                                            $PCount400++;
                                                                                        } elseif ($row["RMK"] == "SP1") {
                                                                                            $SP1Count400++;
                                                                                        } elseif ($row["RMK"] == "SP2") {
                                                                                            $SP2Count400++;
                                                                                        }
                                                                                    } elseif ($row["Level1"] == "500") {
                                                                                        $Level500++;
                                                                                        if ($row["RMK"] == "VL") {
                                                                                            $VCLCount500++;
                                                                                        } elseif ($row["RMK"] == "DL") {
                                                                                            $DLCount500++;
                                                                                        } elseif ($row["RMK"] == "IGS") {
                                                                                            $IGSCount500++;
                                                                                        } elseif ($row["RMK"] == "DEF") {
                                                                                            $DEFCount500++;
                                                                                        } elseif ($row["RMK"] == "P") {
                                                                                            $PCount500++;
                                                                                        } elseif ($row["RMK"] == "SP1") {
                                                                                            $SP1Count500++;
                                                                                        } elseif ($row["RMK"] == "SP2") {
                                                                                            $SP2Count500++;
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                            if ($_SESSION['InstType'] = "University") {
                                                                                if ($Level100 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>100L</td><td style='text-align: center;'>$VCLCount100</td><td style='text-align: center;'>$DLCount100</td><td style='text-align: center;'>$IGSCount100</td><td style='text-align: center;'>$DEFCount100</td><td style='text-align: center;'>$PCount100</td><td style='text-align: center;'>$SP1Count100</td><td style='text-align: center;'>$SP2Count100</td><td style='text-align: center;'>$Level100</td></tr>\n";
                                                                                if ($Level200 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>200L</td><td style='text-align: center;'>$VCLCount200</td><td style='text-align: center;'>$DLCount200</td><td style='text-align: center;'>$IGSCount200</td><td style='text-align: center;'>$DEFCount200</td><td style='text-align: center;'>$PCount200</td><td style='text-align: center;'>$SP1Count200</td><td style='text-align: center;'>$SP2Count200</td><td style='text-align: center;'>$Level200</td></tr>\n";
                                                                                if ($Level300 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>300L</td><td style='text-align: center;'>$VCLCount300</td><td style='text-align: center;'>$DLCount300</td><td style='text-align: center;'>$IGSCount300</td><td style='text-align: center;'>$DEFCount300</td><td style='text-align: center;'>$PCount300</td><td style='text-align: center;'>$SP1Count300</td><td style='text-align: center;'>$SP2Count300</td><td style='text-align: center;'>$Level300</td></tr>\n";
                                                                                if ($Level400 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>400L</td><td style='text-align: center;'>$VCLCount400</td><td style='text-align: center;'>$DLCount400</td><td style='text-align: center;'>$IGSCount400</td><td style='text-align: center;'>$DEFCount400</td><td style='text-align: center;'>$PCount400</td><td style='text-align: center;'>$SP1Count400</td><td style='text-align: center;'>$SP2Count400</td><td style='text-align: center;'>$Level400</td></tr>\n";
                                                                                if ($Level500 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>500L</td><td style='text-align: center;'>$VCLCount500</td><td style='text-align: center;'>$DLCount500</td><td style='text-align: center;'>$IGSCount500</td><td style='text-align: center;'>$DEFCount500</td><td style='text-align: center;'>$PCount500</td><td style='text-align: center;'>$SP1Count500</td><td style='text-align: center;'>$SP2Count500</td><td style='text-align: center;'>$Level500</td></tr>\n";
                                                                            } else {
                                                                                if ($Level100 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>ND I</td><td style='text-align: center;'>$VCLCount100</td><td style='text-align: center;'>$DLCount100</td><td style='text-align: center;'>$IGSCount100</td><td style='text-align: center;'>$DEFCount100</td><td style='text-align: center;'>$PCount100</td><td style='text-align: center;'>$SP1Count100</td><td style='text-align: center;'>$SP2Count100</td><td style='text-align: center;'>$Level100</td></tr>\n";
                                                                                if ($Level200 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>ND II</td><td style='text-align: center;'>$VCLCount200</td><td style='text-align: center;'>$DLCount200</td><td style='text-align: center;'>$IGSCount200</td><td style='text-align: center;'>$DEFCount200</td><td style='text-align: center;'>$PCount200</td><td style='text-align: center;'>$SP1Count200</td><td style='text-align: center;'>$SP2Count200</td><td style='text-align: center;'>$Level200</td></tr>\n";
                                                                                if ($Level300 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>HND I</td><td style='text-align: center;'>$VCLCount300</td><td style='text-align: center;'>$DLCount300</td><td style='text-align: center;'>$IGSCount300</td><td style='text-align: center;'>$DEFCount300</td><td style='text-align: center;'>$PCount300</td><td style='text-align: center;'>$SP1Count300</td><td style='text-align: center;'>$SP2Count300</td><td style='text-align: center;'>$Level300</td></tr>\n";
                                                                                if ($Level400 > 0)
                                                                                    echo "<tr><td style='text-align: center;'>HND II</td><td style='text-align: center;'>$VCLCount400</td><td style='text-align: center;'>$DLCount400</td><td style='text-align: center;'>$IGSCount400</td><td style='text-align: center;'>$DEFCount400</td><td style='text-align: center;'>$PCount400</td><td style='text-align: center;'>$SP1Count400</td><td style='text-align: center;'>$SP2Count400</td><td style='text-align: center;'>$Level400</td></tr>\n";
                                                                            }



                                                                            ?>
                                                </tbody>
                                            </table>

                                            <?php
                                                                }
                                                            }
                                                            $conn_stu->close();
                                                        }
                                                        echo "<br>";
                                                        ?>
                                            <?php
                                                    }
                                                }
                                                ?>

                                        </div>
                                        <div style="text-align: right">
                                            <input type="button" onclick="printDiv('printableAreaAll')" value="print"
                                                class="btn-success" />
                                        </div>

                                    </div>
                                    <div class="col-lg-1">

                                    </div>


                                </div>



                                <?php } ?>
                                <?php
                                $conn->close();
                                $conn2->close();

                                ?>

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_qap.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Courseware</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Courseware</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Courseware
                        </div>
                        <div class="panel-body">

                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <center><strong>
                                        <h3> <?php echo $_SESSION['corntsession'] . " " ?>Session</h3>
                                    </strong></center>

                                <br>

                                <div class="form-group">
                                    <label class="control-label col-lg-3" style="color:#000000;">Select
                                        Course:</label>
                                    <div class="col-lg-8">

                                        <select name="courses" class="form-control" style="color:#000000" id="courses"
                                            onChange="showUser(this.value)">
                                            <option value="selectitem">Select Item</option>
                                            <?php
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }


                                            $curtsession = $_SESSION['corntsession'];
                                            $savesession = substr($curtsession, 0, 4) . "_" . substr($curtsession, -4);
                                            $staffid = $_SESSION['staffid'];

                                            $sql = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$curtsession' ORDER BY CCode";
                                            $result = $conn->query($sql);

                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                                while ($row = $result->fetch_assoc()) {
                                                    $ccode = $row["CCode"];
                                                    $ctitle = $row["CTitle"];
                                                    echo "<option value=$ccode>$ccode $ctitle</option>";
                                                }
                                            }
                                            $conn->close();

                                            ?>


                                        </select>
                                        <br>

                                    </div>
                                </div>



                                <br>
                                <div class="col-lg-12">

                                    <div id="txtHint"></div>
                                </div>

                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
    function showUser(str) {
        if (str == "") {
            document.getElementById("txtHint").innerHTML = "";
            return;
        } else {
            if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp = new XMLHttpRequest();
            } else {
                // code for IE6, IE5
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("txtHint").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "view_courseware_inc.php?q=" + str, true);
            xmlhttp.send();
        }
    }
    </script>

</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

set_time_limit(2000);
//error_reporting(E_ERROR);

echo scanDirectoryImages("stu_passport2");

/**
 * Recursively search through directory for images and display them
 *
 * @param  array  $exts
 * @param  string $directory
 * @return string
 */

function scanDirectoryImages($directory, array $exts = array('jpeg', 'jpg', 'gif', 'png'))
{
    if (substr($directory, -1) == '/') {
        $directory = substr($directory, 0, -1);
    }
    $html = '';
    if (
        is_readable($directory)
        && (file_exists($directory) || is_dir($directory))
    ) {
        $directoryList = opendir($directory);
        while ($file = readdir($directoryList)) {
            if ($file != '.' && $file != '..') {
                $path = $directory . '/' . $file;
                if (is_readable($path)) {
                    if (is_dir($path)) {
                        return scanDirectoryImages($path, $exts);
                    }
                    if (
                        is_file($path)
                        && in_array(end(explode('.', end(explode('/', $path)))),   $exts)
                    ) {
                        $html .= '<a href="' . $path . '"><img src="' . $path
                            . '" style="max-height:100px;max-width:100px" />  </a>';

                        //                        $imgData = addslashes(file_get_contents($path));
                        //                        $imageProperties = getimageSize($path);
                        //
                        //                        $conn10 = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $_SESSION['dbname10']);
                        //                        if ($conn10->connect_error) {
                        //                            die("Connection failed: " . $conn10->connect_error);
                        //                        }
                        //
                        //                        $sql = "INSERT INTO mat (imageType, imageData) VALUES('{$imageProperties['mime']}', '{$imgData}')";
                        //                        $current_id = $conn10->query($sql);
                    }
                }
            }
        }
        closedir($directoryList);
    }
    return $html;
}


$conn = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $_SESSION['dbname']);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $_SESSION['dbname2']);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$conn10 = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $_SESSION['dbname10']);
if ($conn10->connect_error) {
    die("Connection failed: " . $conn10->connect_error);
}

$sql = "SELECT students, DeptCode FROM deptcoding WHERE students = 'yes'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while ($row2 = $result->fetch_assoc()) {
        $dept = $row2["DeptCode"];

        $sql4 = "select 1 from " . $dept;
        $exists = $conn10->query($sql4);

        if ($exists == FALSE) {
            $TabCreate = strtolower($dept);
            $sql4 = "CREATE TABLE " . $TabCreate . " SELECT * FROM dept_temp";
            $result4 = $conn10->query($sql4);
        }

        $sql2 = "SELECT stdid, Deptcode FROM stdprofile WHERE Deptcode = '$dept' AND  (session='2013/2014' or session='2014/2015' or session='2015/2016' or session='2016/2017' or session='2017/2018' or session='2018/2019' or session='2019/2020' or session='2021/2022')";
        $result2 = $conn2->query($sql2);

        if ($result2->num_rows > 0) {
            // output data of each row
            while ($row = $result2->fetch_assoc()) {
                $stdid = $row["stdid"];

                $dirname = "stu_passport/";
                $images = glob($dirname . "passport_" . $stdid . ".jpg");
                foreach ($images as $image) {
                    //echo '<img src="'.$image.'" /><br />';

                    $imgData = addslashes(file_get_contents($image));
                    $imageProperties = getimageSize($image);

                    $conn10 = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $_SESSION['dbname10']);
                    if ($conn10->connect_error) {
                        die("Connection failed: " . $conn10->connect_error);
                    }

                    $sql4 = "INSERT INTO " . strtolower($dept) . " (stdid, imageType, imageData) VALUES('$stdid', '{$imageProperties['mime']}', '{$imgData}')";
                    $current_id = $conn10->query($sql4);
                }

                //        if ($handle = opendir('rpport')) { // here add your directory
                //            $keyword = "passport_".$stdid.".jpg"; // your keyword
                //            while (false !== ($entry = readdir($handle))) {
                //                // (preg_match('/\.txt$/', $entry)) {
                //                if (preg_match('/'.$keyword.'/i', $entry)) {
                //                    //echo "$entry\n";
                //                    $path = 'rpport/' . $entry;
                //
                //                    $imgData = addslashes(file_get_contents($path));
                //                    $imageProperties = getimageSize($path);
                //
                //                    $conn10 = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $_SESSION['dbname10']);
                //                    if ($conn10->connect_error) {
                //                        die("Connection failed: " . $conn10->connect_error);
                //                    }
                //
                //                    $sql = "INSERT INTO mat (stdid, imageType, imageData) VALUES('$stdid', '{$imageProperties['mime']}', '{$imgData}')";
                //                    $current_id = $conn10->query($sql);
                //                }
                //            }
                //
                //            closedir($handle);
                //        }

            }
        }
    }
}

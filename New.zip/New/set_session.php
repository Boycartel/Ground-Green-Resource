<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Set Session</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Settings
                            </li>

                            <li class="active">
                                <strong>Set Session</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Set Session
                        </div>
                        <div class="panel-body">
                            <!-- start: page -->
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $success = "";
                            $GetTheSession = $_SESSION['resultsession'];
                            if (isset($_POST["submit"])) {
                                $reg_session = $_POST["reg_session"];
                                $reg_semester = $_POST["reg_semester"];
                                $results_session = $_POST["results_session"];
                                $results_semester = $_POST["results_semester"];

                                $sql = "UPDATE sessions SET session_title='$reg_session', semester='$reg_semester', result_session='$results_session', result_semester='$results_semester' WHERE getkey = 'key1'";
                                $result = $conn->query($sql);

                                /* $iniyear = substr($reg_session, 5) - 6;
                                $inisession = $iniyear . "/" . ($iniyear + 1);

                                $sql2 = "UPDATE std_data_view SET session_reg_status = 'NO' WHERE YAddmitted >= '$iniyear'";
                                $result2 = $conn2->query($sql2); */


                                echo  "<script type='text/javascript'>";
                                echo  "window.location.href = 'includes/logout.php'";
                                echo "</script>";
                            }



                            $sql = "SELECT * FROM sessions WHERE getkey = 'key1'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $reg_session = $row["session_title"];
                                    $reg_semester = $row["semester"];
                                    $results_session = $row["result_session"];
                                    $results_semester = $row["result_semester"];
                                }
                            }
                            $conn->close();

                            ?>
                            <div class="row">

                                <h2 style="color: blue; text-align: center"><?php echo $success ?></h2>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="col-lg-6">

                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Registration
                                                Session:</label>
                                            <div class="col-lg-7">
                                                <?php

                                                $iniyear = substr($reg_session, 5) - 3;
                                                $finalyear = $iniyear + 7;
                                                ?>
                                                <select class="country form-control" style="color:#000000" name="reg_session">
                                                    <option value="<?php echo $reg_session ?>">
                                                        <?php echo $reg_session ?></option>
                                                    <?php
                                                    for ($x = $iniyear; $x <= $finalyear; $x++) {
                                                        $addyear = $x + 1;
                                                        echo "<option value = '$x/$addyear'>$x/$addyear</option>";
                                                    }

                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <br>
                                        </div>
                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Registration
                                                Semester:</label>
                                            <div class="col-lg-7">
                                                <select class="country form-control" style="color:#000000" name="reg_semester">
                                                    <option value="<?php echo $reg_semester ?>">
                                                        <?php echo $reg_semester ?></option>
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <br>
                                        </div>
                                        <!-- <div class="row" style="text-align: right">
                                            <button type="submit" name="submit_reg"
                                                class="btn btn-primary btn-xs">Submit</button>
                                        </div> -->

                                    </div>
                                    <div class="col-lg-6">

                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Results Session:</label>
                                            <div class="col-lg-7">
                                                <?php
                                                $iniyear = substr($reg_session, 5) - 3;
                                                $finalyear = $iniyear + 7;
                                                ?>
                                                <select class="country form-control" style="color:#000000" name="results_session">
                                                    <option value="<?php echo $results_session ?>">
                                                        <?php echo $results_session ?></option>
                                                    <?php
                                                    for ($x = $iniyear; $x <= $finalyear; $x++) {
                                                        $addyear = $x + 1;
                                                        echo "<option value = '$x/$addyear'>$x/$addyear</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <br>
                                        </div>
                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Results
                                                Semester:</label>
                                            <div class="col-lg-7">
                                                <select class="country form-control" style="color:#000000" name="results_semester">
                                                    <option value="<?php echo $results_semester ?>">
                                                        <?php echo $results_semester ?></option>
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <br>
                                        </div>
                                        <div class="row" style="text-align: right; padding-right:1em">
                                            <button type="submit" name="submit" class="btn btn-primary btn-xs">Submit</button>
                                        </div>

                                    </div>
                                </form>
                            </div>
                            <!-- end: page -->

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
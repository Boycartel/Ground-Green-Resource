<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>
<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Missing</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Missing</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Missing
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal form-bordered" method="post">

                                <div class="row">
                                    <h2 class="panel-title" style="text-align: center">Faculty Board Format</h2>
                                    <br><br><br>
                                    <div class="col-lg-5">
                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-7">
                                                <select class="country form-control" style="color:#000000" name="dept">
                                                    <option value="SelectItem">Select Item</option>
                                                    <?php
                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = strtolower($row["DeptCode"]);
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-lg-3">
                                        <button type="submit" name="submitdup" class="btn btn-primary btn-sm">Submit</button>
                                    </div>

                                </div>
                            </form>
                            <?php
                            set_time_limit(500);
                            error_reporting(E_ERROR);


                            /*  $sql = "SELECT * FROM deptcoding WHERE students = 'Yes' ORDER BY DeptCode";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $deptcode2 = strtolower($row["DeptCode"]);

                                    $dept_db = $_SESSION['deptdb'] . $deptcode2;

                                    try {
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }
                                    } catch (Exception $e) {
                                    }

                                    $oldColumnName = "Grouping2";
                                    $newColumnName = "Grouping2";
                                    try {
                                        $sql2 = "CREATE TABLE absent_students (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, matric_no VARCHAR(30) NOT NULL, CCode VARCHAR(20) NOT NULL, CA VARCHAR(10), Exam VARCHAR(10), status1 VARCHAR(10), session1 VARCHAR(10))";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (Exception $e) {
                                    }
                                }
                            } */
                            if (isset($_POST["submitdup"])) {
                                $dupDept = strtolower($_POST["dept"]);
                                $dept_db = $_SESSION['deptdb'] . $dupDept;

                                try {
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                } catch (Exception $e) {
                                }

                                $sql = "CREATE TABLE absent_students_bk SELECT * FROM absent_students WHERE 1=2";
                                $result = $conn_stu->query($sql);

                                $sql = "CREATE TABLE correg_2022_2023_bk SELECT * FROM correg_2022_2023 WHERE 1=2";
                                $result = $conn_stu->query($sql);

                                $sql4 = "SELECT * FROM absent_students";
                                $result4 = $conn_stu->query($sql4);
                                if ($result4->num_rows > 0) {
                                    while ($row4 = $result4->fetch_assoc()) {
                                        $matric_no = $row4["matric_no"];
                                        $CCode = $row4["CCode"];
                                        $CA = $row4["CA"];
                                        $Exam = $row4["Exam"];
                                        $status1 = $row4["status1"];
                                        $session1 = $row4["session1"];
                                        $semtaken = $row4["semtaken"];
                                        $Level1 = $row4["Level1"];
                                        $split_two = $row4["split_two"];
                                        $CUnit = $row4["CUnit"];

                                        $sql = "SELECT * FROM absent_students_bk WHERE matric_no = '$matric_no' AND CCode = '$CCode' AND semtaken = '$semtaken'";
                                        $result = $conn_stu->query($sql);
                                        if ($result->num_rows == 0) {
                                            $sql3 = "INSERT INTO absent_students_bk(matric_no, CCode, CA, Exam, status1, session1, semtaken, Level1, split_two, CUnit)VALUES('$matric_no', '$CCode', '$CA', '$Exam', '$status1', '$session1', '$semtaken', '$Level1', '$split_two', '$CUnit')";
                                            $result3 = $conn_stu->query($sql3);
                                        }
                                    }
                                }

                                $sql4 = "SELECT * FROM correg_2022_2023";
                                $result4 = $conn_stu->query($sql4);
                                if ($result4->num_rows > 0) {
                                    while ($row4 = $result4->fetch_assoc()) {

                                        $CCode = $row4["CCode"];
                                        $CTitle = $row4["CTitle"];
                                        $CNature = $row4["CNature"];
                                        $CUnit = $row4["CUnit"];
                                        $SemTaken = $row4["SemTaken"];
                                        $SessionRegis = $row4["SessionRegis"];
                                        $CA = $row4["CA"];
                                        $Exam = $row4["Exam"];
                                        $grade = $row4["grade"];
                                        $Grouping2 = $row4["Grouping2"];
                                        $Regn1 = $row4["Regn1"];
                                        $coursecondon = $row4["coursecondon"];
                                        $noexam = $row4["noexam"];
                                        $deptOption = $row4["deptOption"];
                                        $curriculum = $row4["curriculum"];
                                        $date = $row4["date"];
                                        $point = $row4["point"];

                                        $sql = "SELECT * FROM correg_2022_2023_bk WHERE Regn1 = '$Regn1' AND CCode = '$CCode' AND SemTaken = '$SemTaken'";
                                        $result = $conn_stu->query($sql);
                                        if ($result->num_rows == 0) {
                                            $sql3 = "INSERT INTO correg_2022_2023_bk(CCode, CTitle, CNature, CUnit, SemTaken, SessionRegis, CA, Exam, grade, Grouping2, Regn1, coursecondon, noexam, deptOption, curriculum, date, point)VALUES('$CCode', '$CTitle', '$CNature', '$CUnit', '$SemTaken', '$SessionRegis', '$CA', '$Exam', '$grade', '$Grouping2', '$Regn1', '$coursecondon', '$noexam', '$deptOption', '$curriculum', '$date', '$point')";
                                            $result3 = $conn_stu->query($sql3);
                                        }
                                    }
                                }

                                $sql = "DROP TABLE IF EXISTS absent_students";
                                $result = $conn_stu->query($sql);

                                $sql = "DROP TABLE IF EXISTS correg_2022_2023";
                                $result = $conn_stu->query($sql);

                                $sql = "ALTER TABLE absent_students_bk RENAME TO absent_students";
                                $result = $conn_stu->query($sql);

                                $sql = "ALTER TABLE correg_2022_2023_bk RENAME TO correg_2022_2023";
                                $result = $conn_stu->query($sql);
                            }
                            /* $sql4 = "SELECT * FROM gencoursesupload";
                            $result4 = $conn->query($sql4);
                            if ($result4->num_rows > 0) {
                                while ($row4 = $result4->fetch_assoc()) {
                                    $id = $row4["id"];
                                    $C_codding = trim($row4["C_codding"]);
                                    $sql3 = "UPDATE gencoursesupload SET C_codding = '$C_codding' WHERE id = '$id'";
                                    $result3 = $conn->query($sql3);
                                }
                            } */

                            /* $sql = "SELECT * FROM deptcoding WHERE students = 'Yes' ORDER BY DeptCode";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $deptcode2 = strtolower($row["DeptCode"]);

                                    $dept_db = $_SESSION['deptdb'] . $deptcode2;

                                    try {
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }
                                    } catch (Exception $e) {
                                    }


                                    try {
                                        $sql2 = "ALTER TABLE scrutiny_senate ADD stu_group VARCHAR(5)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (Exception $e) {
                                    }
                                }
                            } */

                            /* $sql = "SELECT * FROM courses_register_2024_2025 WHERE departments = '$DeptCode'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $matricno = $row["Regn1"];
                                    $sql2 = "SELECT * FROM hod_list WHERE matricno = '$matricno'";
                                    $result2 = $conn_stu->query($sql2);
                                    if ($result2->num_rows == 0) {
                                        $sql4 = "SELECT * FROM std_data_view WHERE matric_no = '$matricno'";
                                        $result4 = $conn2->query($sql4);
                                        if ($result4->num_rows > 0) {
                                            while ($row4 = $result4->fetch_assoc()) {
                                                $name1 = $row4["first_name"] . " " . $row4["other_name"] . " " . $row4["surname"];
                                                $stateorigin = $row4["state"];
                                                $lga = $row4["lga"];
                                                $level = $row4["level"];
                                            }
                                        }
                                        $sql3 = "INSERT INTO hod_list(matricno, name1, LevelAdvice, HOD, stateorigin, lga, Session1, StuLevel)VALUES('$matricno', '$name1', 'Yet', 'Yet', '$stateorigin', '$lga', '2024/2025', '$level')";
                                        $result3 = $conn_stu->query($sql3);
                                    }
                                }
                            } */

                            /* $oldDeptCode = "ARB";
                            $newDeptCode = "ARA";

                            $dept_db = $_SESSION['deptdb'] . strtolower($oldDeptCode);
                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                            if ($conn_stu->connect_error) {
                                die("Connection failed: " . $conn_stu->connect_error);
                            }

                            //$sql = "SELECT * FROM std_data_view WHERE dept_code = '$oldDeptCode' AND entry_session = '2024/2025' AND modeofentry = 'UTME'";
                            $sql = "SELECT * FROM std_data_view WHERE dept_code = '$oldDeptCode' AND entry_session = '2024/2025'";
                            $result = $conn2->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $id = $row["id"];
                                    $oldMatNo = $row["matric_no"];
                                    $countMatNo = strlen($row["matric_no"]);
                                    if ($countMatNo > 2) {
                                        $newMatricNo = str_replace($oldDeptCode, $newDeptCode, $row["matric_no"]);

                                        $sql2 = "UPDATE std_data_view SET matric_no = '$newMatricNo', regid = '$newMatricNo' WHERE id = '$id'";
                                        $result2 = $conn2->query($sql2);

                                        $sql3 = "UPDATE std_login SET matric_no = '$newMatricNo' WHERE matric_no = '$oldMatNo'";
                                        $result3 = $conn2->query($sql3);

                                        $sql4 = "UPDATE std_login SET stdid = '$newMatricNo' WHERE stdid = '$oldMatNo'";
                                        $result4 = $conn2->query($sql4);

                                        $sql5 = "UPDATE courses_register_2024_2025 SET Regn1 = '$newMatricNo' WHERE Regn1 = '$oldMatNo'";
                                        $result5 = $conn->query($sql5);

                                        $sql6 = "UPDATE correg_2024_2025 SET Regn1 = '$newMatricNo' WHERE Regn1 = '$oldMatNo'";
                                        $result6 = $conn_stu->query($sql6);

                                        $sql7 = "UPDATE hod_list SET matricno = '$newMatricNo' WHERE matricno = '$oldMatNo'";
                                        $result7 = $conn_stu->query($sql7);
                                    }
                                }
                            } */



                            /* $sql = "SELECT * FROM deptcoding ORDER BY DeptCode";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $deptcode2 = strtolower($row["DeptCode"]);

                                    $dept_db = $_SESSION['deptdb'] . $deptcode2;

                                    try {
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }
                                    } catch (PDOException $e) {
                                    }

                                    $oldColumnName = "Grouping2";
                                    $newColumnName = "Grouping2";
                                    try {
                                        $sql2 = "ALTER TABLE gencourses CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(5) DEFAULT 'NO'";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }

                                    //$sql2 = "DELETE FROM gencourses";
                                    //$result2 = $conn_stu->query($sql2);

                                    $oldColumnName = "Grouping";
                                    $newColumnName = "Grouping2";

                                    $tableName = "correg_2018_2019";
                                    try {
                                        $sql2 = "ALTER TABLE $tableName CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(10)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }

                                    $tableName2 = "correg_2019_2020";
                                    try {
                                        $sql2 = "ALTER TABLE $tableName2 CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(10)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }

                                    $tableName3 = "correg_2020_2021";
                                    try {
                                        $sql2 = "ALTER TABLE $tableName3 CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(10)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }

                                    $tableName4 = "correg_2021_2022";
                                    try {
                                        $sql2 = "ALTER TABLE $tableName4 CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(10)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }

                                    $tableName5 = "correg_2022_2023";
                                    try {
                                        $sql2 = "ALTER TABLE $tableName5 CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(10)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }

                                    $tableName6 = "correg_2023_2024";
                                    try {
                                        $sql2 = "ALTER TABLE $tableName6 CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(10)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }

                                    $tableName7 = "correg_empty";
                                    try {
                                        $sql2 = "ALTER TABLE $tableName7 CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(10)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }

                                    $tableName8 = "gencourses";
                                    try {
                                        $sql2 = "ALTER TABLE $tableName8 CHANGE COLUMN $oldColumnName $newColumnName VARCHAR(10)";
                                        $result2 = $conn_stu->query($sql2);
                                    } catch (PDOException $e) {
                                    }
                                }
                            } */


                            $msg = "";
                            $success_upl = "no";

                            if (isset($_POST["upfile"])) {

                                set_time_limit(500);
                                error_reporting(E_ERROR);


                                $filename = $_FILES["uploaded"]["tmp_name"];

                                $file_ext = strtolower(end(explode('.', $_FILES['uploaded']['name'])));

                                if ($file_ext == "csv") {

                                    if ($_FILES["uploaded"]["size"] > 0) {
                                        $file = fopen($filename, "r");

                                        $count = 0;

                                        while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                            $count++;
                                            $Row0 = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                            $Row1 = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                            //$Row2 = filter_var($Row[2], FILTER_SANITIZE_STRING);

                                            //$Cdept = strtolower($Row1);


                                            $sql = "UPDATE std_data_view SET stu_group ='$Row1' WHERE matric_no='$Row0'";
                                            $result = $conn2->query($sql);
                                        }


                                        fclose($file);


                                        /*
                                            $sql = "UPDATE users SET department ='$studept2', staffacddept ='$studept2' WHERE department='$selDept_old2'";
                                            $result = $conn->query($sql);

                                            $sql = "UPDATE deptcourses SET dept ='$studept2' WHERE dept='$selDept_old2'";
                                            $result = $conn->query($sql);

                                            $sql = "UPDATE gencoursesupload SET Department ='$studept2' WHERE Department='$selDept_old2'";
                                            $result = $conn->query($sql);
                                            */


                                        echo '<center><p style="color:#006">CSV File has been successfully Imported</p></center>';
                                        $success_upl = "yes";
                                    } else
                                        echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center>';
                                } else {
                                    echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center></p>';
                                }
                            }
                            ?>

                            <form enctype="multipart/form-data" action="" method="post">
                                <h4 style="text-align: center">CSV File with the Format Below.</h4>
                                <center><img src='img/upload_courses.JPG' width='500' height='300' alt=''>
                                </center>
                                <br><br>

                                <div class="form-group" style="text-align: center;">
                                    <label class="col-md-2 control-label">File Upload</label>
                                    <div class="col-md-4">



                                        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
                                            <div class="form-control" data-trigger="fileinput">
                                                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                                <span class="fileinput-filename"></span>
                                            </div>
                                            <span class="input-group-addon btn btn-default btn-file"><span class="fileinput-new">Select
                                                    file</span><span class="fileinput-exists">Change</span><input type="file" name="uploaded"></span>
                                            <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <input type="submit" name="upfile" value="Upload File" class="btn btn-primary btn-sm">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Table -->
    <script src="js/plugins/dataTables/datatables.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>


</body>

</html>
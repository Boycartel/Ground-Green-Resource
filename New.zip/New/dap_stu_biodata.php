<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>
    <script src="js/getexcel/tableToExcel_Staff.js"></script>


    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    $user1 = $_SESSION['staffid'];
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li><span>APU</span></li>
                            <li><span>Students Record</span></li>
                            <li class="active">
                                <strong>Student's Profile</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Student's Profile
                        </div>
                        <div class="panel-body">
                            <?php
                            $regno = $_POST['id'];
                            $sql = "SELECT * FROM stdprofile WHERE regid = '$regno'";
                            $result = $conn2->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $stuid = $row["stdid"];
                                    $surname = $row["surname"];
                                    $firstname = $row["firstname"];
                                    $oname = $row["othername"];
                                    $Sex = $row["sex"];
                                    if ($Sex == "M") {
                                        $Sex2 = "Male";
                                    } elseif ($Sex == "F") {
                                        $Sex2 = "Female";
                                    } else {
                                        $Sex2 = $Sex;
                                    }
                                    $ParmtAdress = $row["ParmtAdress"];
                                    $ContAddress = $row["ContAddress"];
                                    $marital = $row["marital"];
                                    $Nationality = $row["Nationality"];
                                    $stateOfOrigin = $row["stateOfOrigin"];
                                    $lga = $row["lga"];
                                    $dob = $row["dob"];
                                    $Deptcode = $row["Deptcode"];
                                    $SchCode = $row["SchCode"];
                                    $modeofentry = $row["modeofentry"];
                                    $email = $row["email"];
                                    $Phone = $row["Phone"];
                                    $PlaceBirth = $row["PlaceBirth"];
                                    $religion = $row["religion"];
                                    $next_name = $row["next_name"];
                                    $next_rel = $row["next_rel"];
                                    $next_addr = $row["next_addr"];
                                    $next_phone = $row["next_phone"];
                                    $next_email = $row["next_email"];
                                    $blood_group = $row["blood_group"];
                                    $JAMB_RegNo = $row["JAMB_RegNo"];

                                    $_SESSION["stuid"] = $stuid;
                                    $_SESSION["lga2"] = $lga;
                                    $sql2 = "SELECT * FROM deptcoding WHERE DeptCode = '$Deptcode'";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $departfull = $row2["DeptName"];
                                        }
                                    }

                                    $sql2 = "SELECT * FROM schoolname WHERE SchCode = '$SchCode'";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $schfull = $row2["SchName"];
                                        }
                                    }
                                }
                                //$_SESSION['regno']=$regno;
                                //$_SESSION['stuid']=$stuid;
                            }
                            ?>

                            <!-- start: page -->

                            <div class="row">

                                <center><img src="stu_passport/passport_<?php echo $stuid ?>.jpg" alt="" width="200" height="250" /></center>
                                <br />
                                <form class="form-horizontal bucket-form" method="Post">

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Matric Number:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo strtoupper($regno) ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Student ID:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo strtoupper($stuid) ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Surname:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $surname ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">First Name:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $firstname ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Other Names:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $oname ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Gender:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $Sex2 ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Parmenent Home Address:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $ParmtAdress ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Contact Address:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $ContAddress ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Marital Status:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $marital ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Nationality:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $Nationality ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">State of Origin:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $stateOfOrigin ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">LGA:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $lga ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Date of Birth:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $dob ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Place of Birth:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $PlaceBirth ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">School:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $schfull ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Department:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $departfull ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Mode of Entry:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $modeofentry ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Email:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $email ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Phone:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $Phone ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Religion:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $religion ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Blood Group:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $blood_group ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">JAMB Reg Number:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $JAMB_RegNo ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">O'Level Results:</label>
                                        <div class="col-sm-8">
                                            <table class="table stats-table">
                                                <thead>
                                                    <tr>
                                                        <th>S/No</th>
                                                        <th>Subject</th>
                                                        <th>Grade</th>

                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                                    $sql = "SELECT * FROM e_data WHERE MatNumber = '$regno'";
                                                    $result = $conn3->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {

                                                            $n1subject = $row["s_rslt1"];
                                                            $n2subject = $row["s_rslt2"];
                                                            $n3subject = $row["s_rslt3"];
                                                            $n4subject = $row["s_rslt4"];
                                                            $n5subject = $row["s_rslt5"];
                                                            $n6subject = $row["s_rslt6"];
                                                            $n7subject = $row["s_rslt7"];
                                                            $g1subject = substr($n1subject, -3, -1);
                                                            $g2subject = substr($n2subject, -3, -1);
                                                            $g3subject = substr($n3subject, -3, -1);
                                                            $g4subject = substr($n4subject, -3, -1);
                                                            $g5subject = substr($n5subject, -3, -1);
                                                            $g6subject = substr($n6subject, -3, -1);
                                                            $g7subject = substr($n7subject, -3, -1);

                                                            $n1subject = substr($n1subject, 0, -4);
                                                            $n2subject = substr($n2subject, 0, -4);
                                                            $n3subject = substr($n3subject, 0, -4);
                                                            $n4subject = substr($n4subject, 0, -4);
                                                            $n5subject = substr($n5subject, 0, -4);
                                                            $n6subject = substr($n6subject, 0, -4);
                                                            $n7subject = substr($n7subject, 0, -4);

                                                            echo "<tr><td>1</td><td>$n1subject</td><td>$g1subject</td></tr>";
                                                            echo "<tr><td>2</td><td>$n2subject</td><td>$g2subject</td></tr>";
                                                            echo "<tr><td>3</td><td>$n3subject</td><td>$g3subject</td></tr>";
                                                            echo "<tr><td>4</td><td>$n4subject</td><td>$g4subject</td></tr>";
                                                            echo "<tr><td>5</td><td>$n5subject</td><td>$g5subject</td></tr>";
                                                            echo "<tr><td>6</td><td>$n6subject</td><td>$g6subject</td></tr>";
                                                            echo "<tr><td>7</td><td>$n7subject</td><td>$g7subject</td></tr>";
                                                        }
                                                    }

                                                    ?>

                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Next of Kin:</label>
                                        <div class="col-sm-8">

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label"></label>
                                        <div class="col-sm-8">
                                            <table class="stats-table">

                                                <tbody>
                                                    <tr>
                                                        <th>Name:</th>
                                                        <td><?php echo $next_name ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Relationship:</th>
                                                        <td><?php echo $next_rel ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Address:</th>
                                                        <td><?php echo $next_addr ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Phone:</th>
                                                        <td><?php echo $next_phone ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Email:</th>
                                                        <td><?php echo $next_email ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                        </div>
                                    </div>


                                </form>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
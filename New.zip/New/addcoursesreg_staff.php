<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['sta_stu_course_reg'] == false) {
    header('Location: Home_Staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <!--Check All checkbox-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!--Auto pop up div-->
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("select.country").change(function() {
                var selectedCountry = $(".country option:selected").val();
                $.ajax({
                    type: "POST",
                    url: "includes/dept_course_list.php",
                    data: {
                        country: selectedCountry
                    }
                }).done(function(data) {
                    $("#getalldeptlist").html(data);
                });
            });
        });
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Students' Registered Courses</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Students' Registered Courses</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students' Registered Courses
                        </div>
                        <div class="panel-body">
                            <?php
                            if (isset($_POST["addfromdept"])) {
                                $regid = $_POST["matno"];
                                $dept = $_POST['studept'];
                                $level = $_POST['stulevel'];
                                $_SESSION["regid"] = $regid;
                                $_SESSION['deptcode'] = $dept;
                                $_SESSION['stulevel2'] = $level;
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $sql = "DELETE FROM add_courses_cat WHERE Regn1 ='$regid'";
                                $result = $conn->query($sql);
                                $conn->close();
                            } else {
                                $regid = $_SESSION["regid"];
                                $dept = $_SESSION['deptcode'];
                                $level = $_SESSION['stulevel2'];
                            }

                            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                $regid = $_SESSION["regid"];
                                $dept = $_SESSION['deptcode'];

                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                if (!empty($_POST["chosenalldept"])) {
                                    foreach ($_POST["chosenalldept"] as $key => $value) {

                                        $ccode = $_POST["ccode1"][$key];
                                        $CTitle = str_replace("'", "''", $_POST["CTitle1"][$key]);
                                        $CUnit = $_POST["CUnit1"][$key];
                                        $SemTaken = $_POST["SemTaken1"][$key];
                                        $Nature = $_POST["Nature1"][$key];
                                        // sql to insert record
                                        $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND level = '$level' AND CCode = '$ccode'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows == 0) {
                                            $sql2 = "INSERT INTO add_courses_cat (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature')";
                                            $result2 = $conn->query($sql2);
                                        }
                                    }
                                }
                                $conn->close();
                            }
                            ?>
                            <div class="table-responsive">
                                <div class="col-lg-1">

                                </div>
                                <div class="col-lg-10">
                                    <form class="form-horizontal" role="form" method="post" action="addcoursesreg_staff.php">
                                        <br />
                                        <h3>
                                            <center>1ST Semester</center>
                                        </h3>
                                        <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $regid = $_SESSION["regid"];
                                        $dept = $_SESSION['deptcode'];

                                        $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND level = '$level' AND SemTaken = '1ST'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                            if ($tot1outunit < 24) {
                                        ?>

                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>

                                                            <th>Course Code</th>
                                                            <th>Course Title</th>
                                                            <th>Unit</th>
                                                            <th>Semester</th>
                                                            <th>Nature</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <?php

                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["id"];
                                                            $ccode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $Nature = $row["Nature"];

                                                            echo "<tr>
                                    
                                    <td>
                                    <label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
                                    <input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
                                    </td>
                                    <td>
                                    <label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
                                    <input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
                                    </td>
                                    <td>
                                    <label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
                                    <input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
                                    </td>
                                    <td>
                                    <label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
                                    <input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>
                                    </td>
                                    
                                    <td>
                                    <label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
                                    <input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
                                    </td>
                                    
                                  </tr>\n";
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>

                                            <?php
                                            }
                                        } else {
                                        }

                                        $sql = "SELECT * FROM add_courses_cat WHERE Regn1 = '$regid' AND SemTaken = '1ST'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                            if ($tot1outunit < 24) {
                                            ?>

                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>

                                                            <th>Course Code</th>
                                                            <th>Course Title</th>
                                                            <th>Unit</th>
                                                            <th>Semester</th>
                                                            <th>Nature</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <?php

                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["sn"];
                                                            $ccode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $Nature = $row["Nature"];

                                                            echo "<tr>
                                    
                                    <td>
                                    <label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
                                    <input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
                                    </td>
                                    <td>
                                    <label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
                                    <input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
                                    </td>
                                    <td>
                                    <label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
                                    <input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
                                    </td>
                                    <td>
                                    <label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
                                    <input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>

                                    </td>
                                    
                                    <td>
                                    <label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
                                    <input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
                                    </td>
                                    
                                  </tr>\n";
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>

                                        <?php
                                            }
                                        } else {
                                        }

                                        //$conn->close();
                                        ?>
                                        <br /><br />
                                        <h3>
                                            <center>2ND Semester</center>
                                        </h3>
                                        <?php


                                        $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND level = '$level' AND SemTaken = '2ND'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                            if ($tot2outunit < 24) {
                                        ?>

                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>

                                                            <th>Course Code</th>
                                                            <th>Course Title</th>
                                                            <th>Unit</th>
                                                            <th>Semester</th>
                                                            <th>Nature</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["id"];
                                                            $ccode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $Nature = $row["Nature"];

                                                            echo "<tr>
                                   
                                    <td>
                                    <label id='ccode2' name='ccode2[" . $id . "]'>$ccode</label>
                                    <input type='hidden' id='ccode2' name='ccode2[" . $id . "]' value='" . $ccode . "'/>
                                    </td>
                                    <td>
                                    <label id='CTitle2' name='CTitle2[" . $id . "]'>$CTitle</label>
                                    <input type='hidden' id='CTitle2' name='CTitle2[" . $id . "]' value='" . $CTitle . "'/>
                                    </td>
                                    <td>
                                    <label id='CUnit2' name='CUnit2[" . $id . "]'>$CUnit</label>
                                    <input type='hidden' id='CUnit2' name='CUnit2[" . $id . "]' value='" . $CUnit . "'/>
                                    </td>
                                    <td>
                                    <label id='SemTaken2' name='SemTaken2[" . $id . "]'>$SemTaken</label>
                                    <input type='hidden' id='SemTaken2' name='SemTaken2[" . $id . "]' value='" . $SemTaken . "'/>
                                    </td>
                                    
                                    <td>
                                    <label id='Nature2' name='Nature2[" . $id . "]'>$Nature</label>
                                    <input type='hidden' id='Nature2' name='Nature2[" . $id . "]' value='" . $Nature . "'/>
                                    </td>
                                    
                                  </tr>\n";
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>

                                            <?php
                                            }
                                        } else {
                                        }

                                        $sql = "SELECT * FROM add_courses_cat WHERE Regn1 = '$regid' AND SemTaken = '2ND'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                            if ($tot2outunit < 24) {
                                            ?>

                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>

                                                            <th>Course Code</th>
                                                            <th>Course Title</th>
                                                            <th>Unit</th>
                                                            <th>Semester</th>
                                                            <th>Nature</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["sn"];
                                                            $ccode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $Nature = $row["Nature"];

                                                            echo "<tr>
                                    
                                    <td>
                                    <label id='ccode2' name='ccode2[" . $id . "]'>$ccode</label>
                                    <input type='hidden' id='ccode2' name='ccode2[" . $id . "]' value='" . $ccode . "'/>
                                    </td>
                                    <td>
                                    <label id='CTitle2' name='CTitle2[" . $id . "]'>$CTitle</label>
                                    <input type='hidden' id='CTitle2' name='CTitle2[" . $id . "]' value='" . $CTitle . "'/>
                                    </td>
                                    <td>
                                    <label id='CUnit2' name='CUnit2[" . $id . "]'>$CUnit</label>
                                    <input type='hidden' id='CUnit2' name='CUnit2[" . $id . "]' value='" . $CUnit . "'/>
                                    </td>
                                    <td>
                                    <label id='SemTaken2' name='SemTaken2[" . $id . "]'>$SemTaken</label>
                                    <input type='hidden' id='SemTaken2' name='SemTaken2[" . $id . "]' value='" . $SemTaken . "'/>
                                    </td>
                                    
                                    <td>
                                    <label id='Nature2' name='Nature2[" . $id . "]'>$Nature</label>
                                    <input type='hidden' id='Nature2' name='Nature2[" . $id . "]' value='" . $Nature . "'/>
                                    </td>
                                    
                                  </tr>\n";
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>

                                        <?php
                                            }
                                        } else {
                                        }


                                        ?>

                                        <br /><br />
                                        <div class="form-group">
                                            <label class="col-lg-6 control-label">Select Department:</label>
                                            <div class="col-lg-6">
                                                <select class="country form-control" style="color:#000000" name="state">
                                                    <option value="No">No</option>
                                                    <?php

                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode = $row["DeptCode"];
                                                            $deptname = $row["DeptName"];
                                                            echo "<option value=$deptcode>$deptname</option>";
                                                        }
                                                    }

                                                    $sql = "SELECT * FROM schoolname ORDER BY SchName";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode = $row["SchCode"];
                                                            $deptname = $row["SchName"];
                                                            echo "<option value=$deptcode>$deptname</option>";
                                                        }
                                                    }
                                                    //$conn->close();
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group" id="getalldeptlist">

                                        </div>
                                        <br /><br />
                                        <div class="row" style="text-align:right">
                                            <button type="submit" name="submit" class="btn btn-primary">Add to
                                                Cart</button>
                                        </div>

                                        <?php
                                        $conn->close();
                                        ?>
                                    </form>
                                    <form class="form-horizontal" role="form" method="post" action="sta_stu_course_reg.php">
                                        <div class="row">
                                            <button type="submit" name="submitBackCReg" class="btn btn-default" style="color:blue;">Back to
                                                Course
                                                Reg</button>

                                        </div>
                                    </form>
                                    <br /><br />
                                </div>
                                <div class="col-lg-1">

                                </div>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>




    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';

$countprog = $_SESSION["countprog"];
if ($countprog > 1) {
    if ($_SESSION["seldeptLogin"] == false) {
        if (isset($_POST['view_home_option'])) {
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $newdeptcode = $_POST["seldeptcode"];
            $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$newdeptcode'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $deptselcode = $row["DeptCode"];
                    $deptselname = $row["DeptName"];

                    $_SESSION['deptcode'] = strtolower($deptselcode);
                    $_SESSION['selectdept'] = strtolower($deptselcode);
                    $_SESSION['dept_id'] = $row["id"];

                    $_SESSION['deptname'] = $row["DeptName"];
                    $_SESSION["siwesstatus"] = $row["siwes"];
                    $_SESSION['schcode'] = $row["School"];
                    $_SESSION['deptoption'] = $row["deptoption"];
                    $_SESSION['DegType'] = $row["DegreeAward"];
                    $_SESSION['curricul'] = $row["curriculum"];
                    $_SESSION['dept_id'] = $row["id"];
                    $_SESSION['prog_no_years'] = $row["prog_no_years"];
                }
            }

            $schcode = $_SESSION['schcode'];
            $sql = "SELECT SchCode, SchName FROM schoolname WHERE SchCode = '$schcode'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $_SESSION['schname'] = $row["SchName"];
                }
            }
            $conn->close();

            $_SESSION["seldeptLogin"] = true;
        } else {
            session_destroy();
            header('Location: index_staff.php');
        }
    }
}

require_once 'includes/check_validity.php';
?>



<?php
$unuse = "YES";

$staffid = $_SESSION['staffid'];

$dept = $_SESSION['deptcode'];
//$cat = $_SESSION['cat'];
$schcode = $_SESSION['schcode'];

//error_reporting(E_ERROR);

date_default_timezone_set("Africa/Lagos");
$prestimefull =  date("h:i:sa");

$prestime = date("ha");
$preday = date("l");


?>
<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>


    <!-- orris -->
    <link href="css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <style>
        button {
            background: none !important;
            border: none;
            padding: 0 !important;
            /*optional*/
            font-family: arial, sans-serif;
            /*input has OS specific font-family*/
            color: #069;
            text-decoration: underline;
            cursor: pointer;
        }
    </style>
    <?php
    //$autologoutURL = "";
    //include_once 'includes/autologout.php';
    ?>

</head>

<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <?php
            //$DegType = $_SESSION['DegType'];
            $resultsession = $_SESSION['resultsession'];
            $resultsemester = $_SESSION['resultsemester'];
            $corntsession = $_SESSION['corntsession'];

            function calculate_time_span($date)
            {
                $seconds  = strtotime(date('Y-m-d H:i:s')) - strtotime($date);

                $months = floor($seconds / (3600 * 24 * 30));
                $day = floor($seconds / (3600 * 24));
                $hours = floor($seconds / 3600);
                $mins = floor(($seconds - ($hours * 3600)) / 60);
                $secs = floor($seconds % 60);

                if ($seconds < 60)
                    $time = $secs . " seconds ago";
                else if ($seconds < 60 * 60)
                    $time = $mins . " min ago";
                else if ($seconds < 24 * 60 * 60)
                    $time = $hours . " hours ago";
                else if ($seconds < 24 * 60 * 60)
                    $time = $day . " day ago";
                else
                    $time = $months . " month ago";

                return $time;
            }

            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            //set_time_limit(1000);
            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
            if ($conn_stu->connect_error) {
                die("Connection failed: " . $conn_stu->connect_error);
            }


            /* $sql = "SELECT * FROM users";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $id = $row["sn"];
                    $Department = $row["department"];
                    $school = "XXXX";
                    $sql2 = "SELECT * FROM deptcoding WHERE DeptCode = '$Department'";
                    $result2 = $conn->query($sql2);
                    if ($result2->num_rows > 0) {
                        while ($row2 = $result2->fetch_assoc()) {
                            $school = $row2["School"];
                        }
                    }

                    $sql2 = "UPDATE users SET SchCode ='$school' WHERE  sn =  '$id'";
                    $result2 = $conn->query($sql2);
                }
            } */



            $Level100 = $Level200 = $Level300 = $Level400 = $Level500 = $Level600 = 0;
            unset($stuState);
            $stuState[] = "";
            unset($stuStateFull);
            $stuStateFull[] = "";
            unset($stuStateCount);
            $stuStateCount[] = 0;
            $StateCount = 0;

            if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES" || $cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {

                $corntsession2 = str_replace("/", "_", $corntsession);



                $sql = "SELECT * FROM states";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $StateCount++;
                        $stuState[$StateCount] = $row["StateCode"];
                        $stuStateFull[$StateCount] = str_replace("-", " ", strtoupper($row["state"]));
                        $stuStateCount[$StateCount] = 0;
                    }
                }

                $totStu = 0;
                $PCount100 = $IGSCount100 = $DEFCount100 = $SP1Count100 = $SP2Count100 = $DLCount100 = $VCLCount100 = $Ten88Count100 = $BL2Count100 = 0;
                $PCount200 = $IGSCount200 = $DEFCount200 = $SP1Count200 = $SP2Count200 = $DLCount200 = $VCLCount200 = 0;
                $PCount300 = $IGSCount300 = $DEFCount300 = $SP1Count300 = $SP2Count300 = $DLCount300 = $VCLCount300 = 0;
                $PCount400 = $IGSCount400 = $DEFCount400 = $SP1Count400 = $SP2Count400 = $DLCount400 = $VCLCount400 = 0;
                $PCount500 = $IGSCount500 = $DEFCount500 = $SP1Count500 = $SP2Count500 = $DLCount500 = $VCLCount500 = 0;
                $PCount600 = $IGSCount600 = $DEFCount600 = $SP1Count600 = $SP2Count600 = $DLCount600 = $VCLCount600 = 0;

                $Level100 = $Level200 = $Level300 = $Level400 = $Level500 = $Level600 = 0;
                if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES") {
                    $sql3 = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptCode";
                    $result3 = $conn->query($sql3);
                    if ($result3->num_rows > 0) {
                        while ($row3 = $result3->fetch_assoc()) {

                            $dept_db = $_SESSION['deptdb'] . strtolower($row3["DeptCode"]);
                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                            if ($conn_stu->connect_error) {
                                die("Connection failed: " . $conn_stu->connect_error);
                            }

                            $sql = "SELECT matricno, StuLevel, stateorigin, Session1 FROM hod_list WHERE Session1 = '$corntsession'";
                            $result = $conn_stu->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    for ($x = 1; $x <= $StateCount; $x++) {
                                        $stuStateFull2 = $stuStateFull[$x];
                                        $stateorigin = strtoupper($row["stateorigin"]);
                                        if ($stateorigin == $stuState[$x] || $stateorigin == $stuStateFull2) {
                                            if ($_SESSION['InstType'] == "University") {
                                                if ($row["StuLevel"] == 100) {
                                                    $Level100++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 200) {
                                                    $Level200++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 300) {
                                                    $Level300++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 400) {
                                                    $Level400++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 500) {
                                                    $Level500++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 600) {
                                                    $Level600++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                }
                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                if ($row["StuLevel"] == 100) {
                                                    $Level100++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 200) {
                                                    $Level200++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 300) {
                                                    $Level300++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 400) {
                                                    $Level400++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                } elseif ($row["StuLevel"] == 600) {
                                                    $Level600++;
                                                    $stuStateCount[$x]++;
                                                    $totStu++;
                                                }
                                            } else {
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    $sql = "SELECT matricno, StuLevel, stateorigin, Session1 FROM hod_list WHERE Session1 = '$corntsession'";
                    $result = $conn_stu->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            for ($x = 1; $x <= $StateCount; $x++) {
                                $stuStateFull2 = $stuStateFull[$x];
                                $stateorigin = strtoupper($row["stateorigin"]);
                                if ($stateorigin == $stuState[$x] || $stateorigin == $stuStateFull2) {
                                    if ($_SESSION['InstType'] == "University") {
                                        if ($row["StuLevel"] == 100) {
                                            $Level100++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 200) {
                                            $Level200++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 300) {
                                            $Level300++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 400) {
                                            $Level400++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 500) {
                                            $Level500++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 600) {
                                            $Level600++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        }
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        if ($row["StuLevel"] == 100) {
                                            $Level100++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 200) {
                                            $Level200++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 300) {
                                            $Level300++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 400) {
                                            $Level400++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        } elseif ($row["StuLevel"] == 600) {
                                            $Level600++;
                                            $stuStateCount[$x]++;
                                            $totStu++;
                                        }
                                    } else {
                                    }
                                }
                            }
                        }
                    }
                }
            }
            ?>

            <div class="wrapper wrapper-content">
                <?php if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES" || $cat_HOD == "YES" || $cat_Examiner == "YES") { ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ibox float-e-margins">

                                <div class="ibox-content">
                                    <div class="row">
                                        <div class="col-lg-9">
                                            <div class="ibox-title">
                                                <h5>Bar Chat (<?php echo $corntsession ?> Session Registered Students
                                                    according to State of Origin) </h5>

                                            </div>
                                            <div class="flot-chart">
                                                <canvas id="barChart" height="50"></canvas>

                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="ibox-title">
                                                <h5>Pie Chat (<?php echo $corntsession ?> Session Registered Students
                                                    according to Level) </h5>

                                            </div>
                                            <div class="ibox-content">
                                                <div>
                                                    <canvas id="doughnutChart" height="140"></canvas>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <?php
                        set_time_limit(500);

                        ?>
                        <div class="col-lg-12">
                            <div class="ibox float-e-margins">

                                <div class="ibox-content">
                                    <div class="row">
                                        <div class="col-lg-9">
                                            <div class="table-responsive">
                                                <table class="table table-striped mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th>State</th>
                                                            <?php
                                                            for ($x = 1; $x <= $StateCount; $x++) {
                                                                $stuStateFull2 = ucwords(strtolower($stuStateFull[$x]));
                                                                echo "<th>$stuStateFull2</th>";
                                                            }
                                                            ?>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        echo "<tr><td>No. of Students</td>";
                                                        for ($x = 1; $x <= $StateCount; $x++) {
                                                            echo "<td>$stuStateCount[$x]</td>";
                                                        }
                                                        echo "<td>$totStu</td></tr>";
                                                        echo "<tr><td>Action</td>";
                                                        for ($x = 1; $x <= $StateCount; $x++) {
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='$stuState[$x]' name='id'>";
                                                            echo "<input type='hidden' value='$stuStateFull[$x]' name='id2'>";
                                                            echo "<button name='viewStu'>View</button>";
                                                            //echo "<input type='submit' name='viewStu' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                        }
                                                        echo "</tr>";

                                                        ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="table-responsive">
                                                <table class="table table-hover margin bottom">
                                                    <thead>
                                                        <tr>
                                                            <?php if ($_SESSION['InstType'] == "University") { ?>
                                                                <th>Level</th>
                                                                <th>100L</th>
                                                                <th>200L</th>
                                                                <th>300L</th>
                                                                <th>400L</th>
                                                                <th>500L</th>
                                                                <th>Spill Over</th>
                                                                <th>Total</th>
                                                            <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                                <th>Level</th>
                                                                <th>ND I</th>
                                                                <th>ND II</th>
                                                                <th>HND I</th>
                                                                <th>HND II</th>
                                                                <th>Spill Over</th>
                                                                <th>Total</th>
                                                            <?php } else { ?>

                                                            <?php } ?>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $totStu = $Level100 + $Level200 + $Level300 + $Level400 + $Level500 + $Level600;
                                                        if ($_SESSION['InstType'] == "University") {
                                                            echo "<tr><td>No. of Students</td><td>$Level100</td><td>$Level200</td><td>$Level300</td><td>$Level400</td><td>$Level500</td><td>$Level600</td><td>$totStu</td></tr>";
                                                            echo "<tr><td>Action</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='100' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='200' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='300' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='400' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='500' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='600' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td></td>";
                                                            echo "</tr>";
                                                        } elseif ($_SESSION['InstType'] = "Polytechnic") {
                                                            echo "<tr><td>No. of Students</td><td>$Level100</td><td>$Level200</td><td>$Level300</td><td>$Level400</td><td>$Level600</td><td>$totStu</td></tr>";
                                                            echo "<tr><td>Action</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='100' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='200' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='300' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='400' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td>";
                                                            echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                            echo "<input type='hidden' value='600' name='id'>";
                                                            echo "<button name='viewStuLevel'>View</button>";
                                                            //echo "<input type='submit' name='viewStuLevel' class='btn btn-primary btn-xs' value='View'>";
                                                            echo "</form>";
                                                            echo "</td>";
                                                            echo "<td></td>";

                                                            echo "</tr>";
                                                        } else {
                                                        }


                                                        ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-lg-8">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5><?php echo $_SESSION['corntsession'] . " Session Course Allocation" ?></h5>

                            </div>

                            <div class="ibox-content">
                                <table class="table table-hover margin bottom">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Course</th>
                                            <th>Semester</th>
                                            <th>Number of Students</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sno = 0;

                                        $sql = "SELECT PFNo, SessionReg, Semester, CCode, CTitle, curri FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$corntsession' ORDER BY Semester";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $sno++;
                                                $ccode = $row['CCode'];
                                                $ctitle = $row['CTitle'];
                                                $CSemester = $row['Semester'];
                                                $curri = $row['curri'];
                                                $countstu = 0;
                                                $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$ccode' AND type1 = '$curri'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $countstu = $row2['totStu'];
                                                    }
                                                }

                                                //$countstu2 = number_format($countstu, 0);
                                                if ($CSemester == "1ST") {
                                                    echo "<tr><td>$sno</td><td>$ccode - $ctitle</td><td>$CSemester</td><td><span class='label label-primary'>$countstu</span></td><td>";
                                                } else {
                                                    echo "<tr><td>$sno</td><td>$ccode - $ctitle</td><td>$CSemester</td><td><span class='label label-success'>$countstu</span></td><td>";
                                                }

                                                echo "<form class='form-horizontal form-bordered' method='post' action='home_view_rec.php'>";
                                                echo "<input type='hidden' value='$ccode' name='id'>";
                                                echo "<button name='viewCourse'>View</button>";
                                                //echo "<input type='submit' name='viewCourse' class='btn btn-primary btn-xs' value='View'>";
                                                echo "</form>";
                                                echo "</td></tr>";
                                            }
                                        }


                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h3><i class="fa fa-desktop"></i> Notice Board</h3>

                            </div>

                            <div class="ibox-content full-height-scroll">
                                <div id="chat_body" class="feed-activity-list" style="height: 400px;">

                                    <?php
                                    $getcode = "XX";
                                    if ($cat_Dean == "YES") {
                                        $getcode = "SD";
                                    } elseif ($cat_HOD == "YES") {
                                        $getcode = "DH";
                                    } elseif ($cat_Examiner == "Examiner") {
                                        $getcode = "DE";
                                    } elseif ($cat_SchExaminer == "YES") {
                                        $getcode = "SE";
                                    }

                                    $dept_notice = strtoupper($dept);
                                    $schcode_notice = strtoupper($schcode);
                                    //if ($cat == "Administrator" || $cat == "Sub Admin I" || $cat == "Sub Admin II") {
                                    //$sql = "SELECT * FROM notice_board ORDER BY id DESC";
                                    //} else {
                                    $sql = "SELECT * FROM notice_board WHERE (sch_dept = '$dept_notice' AND code = 'DA') OR (sch_dept = '$schcode_notice' AND code = 'SA') OR code = '$getcode' OR to_who = 'Group' ORDER BY id DESC";
                                    //}

                                    //$sql = "SELECT notice_board.id, notice_board.to_who, notice_board.type1, notice_board.code, notice_board.date1, notice_board.sch_dept_name, notice_board.sender_id, cat, staffid FROM notice_board INNER JOIN users ON book_mast.cate_id=category.cate_id WHERE book_mast.pub_lang='English'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {

                                        while ($row = $result->fetch_assoc()) {
                                            $id = $row["id"];
                                            $to_who = $row["to_who"];
                                            $sch_dept = $row["sch_dept"];
                                            $ingroup = true;
                                            if ($to_who == "Group") {
                                                $sql2 = "SELECT * FROM group_message WHERE group_id = '$sch_dept' AND to_who = '$staffid'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows == 0) {
                                                    $ingroup = false;
                                                }
                                            }
                                            if ($ingroup == true) {


                                                $type1 = $row["type1"];
                                                $code = $row["code"];
                                                $date = date_create($row["date1"]);
                                                $Sch_dept_Name = $row["sch_dept_name"];
                                                $sender_id = $row["sender_id"];

                                                $sql2 = "SELECT * FROM users WHERE staffid = '$sender_id'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        //$cat_sender = $row2["cat"];
                                                        $userdeptNB = $row2["staffacddept"];
                                                        $userDean = $row2["SchCode"];

                                                        $Administrator_sender = $row2["Administrator"];
                                                        $Sub_Admin_sender = $row2["Sub_Admin"];
                                                        $Dean_sender = $row2["Dean"];
                                                        $HOD_sender = $row2["HOD"];
                                                        $Examiner_sender = $row2["Examiner"];
                                                        $Ass_Examiner_sender = $row2["Ass_Examiner"];
                                                        $PG_Coord_sender = $row2["PG_Coord"];
                                                        $Seminer_Coord_sender = $row2["Seminer_Coord"];
                                                        $SIWES_Coord_sender = $row2["SIWES_Coord"];
                                                        $L100_sender = $row2["L100"];
                                                        $L200_sender = $row2["L200"];
                                                        $L300_sender = $row2["L300"];
                                                        $L400_sender = $row2["L400"];
                                                        $L500_sender = $row2["L500"];
                                                        $spill_over_sender = $row2["spill_over"];

                                                        $SchExaminer_sender = $row2["SchExaminer"];
                                                        $POs_sender = $row2["POs"];
                                                        $APU_sender = $row2["APU"];
                                                        $QAP_sender = $row2["QAP"];
                                                        $AcadSec_sender = $row2["AcadSec"];
                                                        $Acad_Ofice_sender = $row2["Acad_Ofice"];
                                                        $CourseLec_sender = $row2["CourseLec"];
                                                        $transcript_sender = $row2["transcript"];
                                                    }
                                                }
                                                if ($Administrator_sender == "YES") {
                                                    $role = "Administrator";
                                                } elseif ($Sub_Admin_sender == "YES") {
                                                    $role = "Sub Admin";
                                                } elseif ($AcadSec_sender == "YES" || $Acad_Ofice_sender == "YES") {
                                                    $role = "Academic Secretary";
                                                } elseif ($POs_sender == "YES") {
                                                    $role = "School Management";
                                                } elseif ($QAP_sender == "YES") {
                                                    $role = "QAP Unit";
                                                } elseif ($APU_sender == "YES") {
                                                    $role = "Academic Planning Unit";
                                                } elseif ($HOD_sender == "YES") {
                                                    $role = "HOD of " . $userdeptNB;
                                                } elseif ($Dean_sender == "YES") {
                                                    $role = "Dean of " . $userDean;
                                                }

                                                if ($type1 == "S") {

                                                    if ($code == "SD") {
                                                        $getcode = "Dean";
                                                    } elseif ($code == "SA") {
                                                        $getcode = "All Staff";
                                                    } elseif ($code == "SE") {
                                                        $getcode = "School/Faculty Exam Officer";
                                                    }
                                                } else if ($type1 == "D") {

                                                    if ($code == "DH") {
                                                        $getcode = "HOD";
                                                    } elseif ($code == "DA") {
                                                        $getcode = "All Staff";
                                                    } elseif ($code == "DE") {
                                                        $getcode = "Departmental Exam Officer";
                                                    }
                                                }


                                    ?>
                                                <div class="feed-element">
                                                    <div>
                                                        <?php
                                                        $current_timestamp = strtotime($row["date1"]);
                                                        $midnight_timestamp = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
                                                        ?>
                                                        <?php if ($current_timestamp > $midnight_timestamp) { ?>
                                                            <small class="pull-right text-navy"><?php echo calculate_time_span($row["date1"]) ?></small>
                                                        <?php } else { ?>
                                                            <small class="pull-right"><?php echo calculate_time_span($row["date1"]) ?></small>
                                                        <?php } ?>
                                                        <strong>Message from
                                                            <?php echo $role ?></strong>
                                                        <br><br>
                                                        <div>
                                                            <?php echo $row["message1"] ?><br>

                                                            <?php if (file_exists('pdf/noticeboard/' . $id . '.pdf')) { ?>

                                                                <p><a href="pdf/noticeboard/<?php echo $id ?>.pdf" target="_blank"><img src="img/pdf_icon.png" width="40" height="40">
                                                                        <?php echo $row["filename1"] ?></a>
                                                                </p>
                                                            <?php } ?>
                                                        </div>
                                                        <?php


                                                        if ($current_timestamp > $midnight_timestamp) {

                                                        ?>
                                                            <small class="pull-right text-muted">Today
                                                                <?php echo date_format($date, "h:i A d D, Y"); ?></small>
                                                        <?php
                                                        } else if ($current_timestamp > $midnight_timestamp - 86400) {

                                                        ?>
                                                            <small class="pull-right text-muted">Yesterday
                                                                <?php echo date_format($date, "h:i A d D, Y"); ?></small>
                                                        <?php
                                                        } else {

                                                        ?>
                                                            <small class="pull-right text-muted"><?php echo date_format($date, "l, h:i:s A d D, Y"); ?></small>
                                                        <?php
                                                        }

                                                        ?>

                                                    </div>
                                                    <br>
                                                </div>
                                                <hr>
                                    <?php
                                            }
                                        }
                                    }
                                    ?>



                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                <div class="row">
                    <div class="col-lg-8">
                        <div class="ibox float-e-margins">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5><?php echo $_SESSION['corntsession'] . " ";  ?> Academic
                                        Calendar</h2>
                                    </h5>
                                    <div class="ibox-tools">
                                        <a class="collapse-link">
                                            <i class="fa fa-chevron-up"></i>
                                        </a>
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                            <i class="fa fa-wrench"></i>
                                        </a>
                                        <ul class="dropdown-menu dropdown-user">
                                            <li><a href="#">Config option 1</a>
                                            </li>
                                            <li><a href="#">Config option 2</a>
                                            </li>
                                        </ul>
                                        <a class="close-link">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="ibox-content" style="position: relative">
                                    <table class="table table-hover margin bottom">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Semester</th>
                                                <th>Activity</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            $sql = "SELECT * FROM acad_calendar";
                                            $result = $conn->query($sql);

                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $date1 = $row["date1"];
                                                    $semester = $row["semester"];
                                                    $activity1 = $row["activity1"];
                                                    echo "<tr><td>$date1</td><td>$semester</td><td>$activity1</td></tr>\n";
                                                }
                                            }

                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>Profile</h5>
                                    <div class="ibox-tools">
                                        <a class="collapse-link">
                                            <i class="fa fa-chevron-up"></i>
                                        </a>
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                            <i class="fa fa-wrench"></i>
                                        </a>
                                        <ul class="dropdown-menu dropdown-user">
                                            <li><a href="#">Config option 1</a>
                                            </li>
                                            <li><a href="#">Config option 2</a>
                                            </li>
                                        </ul>
                                        <a class="close-link">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <div style="height: 100px; font-size: 14px">
                                        Name: <?php echo $_SESSION["names"] ?><br>
                                        Department: <?php echo $_SESSION["deptname"] ?><br>
                                        email: <?php echo $_SESSION["email"] ?> <br>
                                        Phone: <?php echo $_SESSION["phone"] ?>
                                    </div>
                                    <div class="summary-footer">
                                        <hr class="separator" />
                                        <a class="text-muted text-uppercase" href="staff_profile.php">(view all)</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h5>OUR VISION </h5>
                            </div>
                            <div class="panel-body">
                                <p style="text-align: justify;"><?php echo $_SESSION['vision'] ?></p>


                            </div>

                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h5>OUR MISSION </h5>
                            </div>
                            <div class="panel-body">
                                <p style="text-align: justify;"><?php echo $_SESSION['mission'] ?></p>
                            </div>

                        </div>
                    </div>
                </div>

                <?php
                $conn->close();
                ?>
            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
    </div>
    <div id="right-sidebar">
        <?php
        include_once 'includes/aside_right.php';
        ?>

    </div>
    <?php
    //include_once 'small_chat.php';
    ?>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- ChartJS-->
    <script src="js/plugins/chartJs/Chart.min.js"></script>
    <script src="js/demo/chartjs-demo.js"></script>
    <script>
        $(function() {




            var barData = {
                labels: [
                    <?php for ($x = 1; $x <= $StateCount; $x++) { ?> "<?php echo ucwords(strtolower($stuStateFull[$x])) ?>",
                    <?php } ?>
                ],
                datasets: [{
                    label: "No. of Students",
                    backgroundColor: 'rgba(26,179,148,0.5)',
                    borderColor: "rgba(26,179,148,0.7)",
                    pointBackgroundColor: "rgba(26,179,148,1)",
                    pointBorderColor: "#fff",
                    data: [
                        <?php for ($x = 1; $x <= $StateCount; $x++) { ?>
                            <?php echo $stuStateCount[$x] ?>,
                        <?php } ?>

                    ]
                }]
            };

            var barOptions = {
                responsive: true
            };


            var ctx2 = document.getElementById("barChart").getContext("2d");
            new Chart(ctx2, {
                type: 'bar',
                data: barData,
                options: barOptions
            });



            <?php if ($_SESSION['InstType'] == "University") { ?>
                var doughnutData = {
                    labels: ["100 Level", "200 Level", "300 Level", "400 Level", "500 Level", "Spill Over"],
                    datasets: [{
                        data: [<?php echo $Level100 ?>, <?php echo $Level200 ?>, <?php echo $Level300 ?>,
                            <?php echo $Level400 ?>, <?php echo $Level500 ?>, <?php echo $Level600 ?>
                        ],
                        backgroundColor: ["#a3e1d4", "#dedede", "#b5b8cf", "#138D75", "#186A3B", "#b5b8cf"]
                    }]
                };


                var doughnutOptions = {
                    responsive: true
                };


                var ctx4 = document.getElementById("doughnutChart").getContext("2d");
                new Chart(ctx4, {
                    type: 'doughnut',
                    data: doughnutData,
                    options: doughnutOptions
                });
            <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                var doughnutData = {
                    labels: ["ND I", "ND II", "HND I", "HND II", "Spill Over"],
                    datasets: [{
                        data: [<?php echo $Level100 ?>, <?php echo $Level200 ?>, <?php echo $Level300 ?>,
                            <?php echo $Level400 ?>, <?php echo $Level600 ?>
                        ],
                        backgroundColor: ["#a3e1d4", "#dedede", "#b5b8cf", "#138D75", "#dedede"]
                    }]
                };


                var doughnutOptions = {
                    responsive: true
                };


                var ctx4 = document.getElementById("doughnutChart").getContext("2d");
                new Chart(ctx4, {
                    type: 'doughnut',
                    data: doughnutData,
                    options: doughnutOptions
                });
            <?php } else { ?>

            <?php } ?>






        });
    </script>

    <script>
        $(document).ready(function() {
            setInterval(function() {
                $("#chat_body").load(window.location.href + " #chat_body");
            }, 3000);
        });
    </script>
</body>

</html>
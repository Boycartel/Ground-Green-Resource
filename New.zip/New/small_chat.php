<?php
//require_once 'includes/db_connect.php';
?>
<div class="small-chat-box fadeInRight animated">

    <div class="heading" draggable="true">
        <div id="smallchat_lasttime">
            <small class="chat-date pull-right">
                <?php echo $_SESSION['lasttime_chat'];
                ?>
            </small>
            Help Desk chat
        </div>

    </div>

    <div class="content">
        <div id="small_chat_body">
            <?php
            $curuser = "";
            $helpdesk = "NO";
            $_SESSION['countnewmsg'] = 0;

            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
            if ($conn2->connect_error) {
                die("Connection failed: " . $conn2->connect_error);
            }

            if ($_SESSION['logintype'] == "student") {
                $curuser = $_SESSION['regid'];
                $sql = "SELECT * FROM small_chat WHERE user_id = '$curuser' OR helpdesk = 'YES' ORDER BY id DESC";
            } else {
                $curuser = $_SESSION['staffid'];
                $sql2 = "SELECT * FROM users WHERE staffid = '$curuser'";
                $result2 = $conn->query($sql2);
                if ($result2->num_rows > 0) {
                    while ($row2 = $result2->fetch_assoc()) {
                        $helpdesk = $row2['helpdesk'];
                    }
                }
                if ($helpdesk == "YES") {
                    $sql = "SELECT * FROM small_chat ORDER BY id DESC";
                } else {
                    $sql = "SELECT * FROM small_chat WHERE user_id = '$curuser' OR helpdesk = 'YES' ORDER BY id DESC";
                }
            }



            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $user_id = $row["user_id"];
                    //$file_no = $row["file_no"];
                    $thechat = $row["thechat"];
                    $name1 = $row["name1"];
                    $status = $row["status1"];
                    if ($status == "NO") {
                        $_SESSION['countnewmsg']++;
                    }
                    //$date = $row["date_time"];
                    $date_time = date_create($row["date_time"]);
                    $date = date_format($date_time, "h:i:s A");
                    $IsStudent = false;
                    $sql3 = "SELECT matric_no FROM std_data_view WHERE matric_no = '$user_id'";
                    $result3 = $conn2->query($sql3);
                    if ($result3->num_rows > 0) {
                        $IsStudent = true;
                    }
            ?>
                    <?php if ($_SESSION['logintype'] == "student") { ?>
                        <?php if ($user_id == $curuser) { ?>
                            <div class="right">
                                <div class="author-name">
                                    You
                                    <small class="chat-date">
                                        <?php echo $date ?>
                                    </small>
                                </div>
                                <div class="chat-message active">
                                    <?php echo $thechat ?>
                                </div>
                            </div>

                        <?php } else { ?>
                            <div class="left">
                                <div class="author-name">
                                    Desk Officer
                                    <small class="chat-date">
                                        <?php echo $date ?>
                                    </small>
                                </div>
                                <div class="chat-message">
                                    <?php echo $thechat ?>
                                </div>

                            </div>
                        <?php } ?>
                    <?php } else { ?>
                        <?php if ($user_id == $curuser) { ?>
                            <div class="right">
                                <div class="author-name">
                                    You
                                    <small class="chat-date">
                                        <?php echo $date ?>
                                    </small>
                                </div>
                                <div class="chat-message active">
                                    <?php echo $thechat ?>
                                </div>
                            </div>

                        <?php } else { ?>
                            <div class="left">
                                <div class="author-name">
                                    <?php if ($user_id == "helpdesk") { ?>
                                        Desk Officer
                                    <?php } else { ?>
                                        <?php echo $name1 ?>
                                    <?php } ?>

                                    <small class="chat-date">
                                        <?php echo $date ?>
                                    </small>
                                </div>
                                <div class="chat-message">
                                    <?php echo $thechat ?>
                                </div>

                            </div>
                        <?php } ?>
                    <?php } ?>

            <?php
                }
            }


            $sql = "SELECT * FROM small_chat ORDER BY id DESC";
            $result = $conn->query($sql);
            $idcount = 0;
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $idcount++;
                    $date = new DateTime($row['date_time']);
                    $_SESSION['lasttime_chat'] =  date_format($date, "h:i:s A");
                    if ($idcount > 0) {
                        break;
                    }
                }
            }

            $conn->close();
            $conn2->close();
            ?>
        </div>
    </div>
    <div class="form-chat">
        <div class="input-group input-group-sm">
            <input type="text" id="mychat_small" name="mychat_small">
            <input type="hidden" id="user_id_small" name="user_id_small" value="<?php echo $curuser ?>">
            <input type="hidden" id="user_full_name" name="user_full_name" value="<?php echo $names ?>">
            <input type="hidden" id="user_helpdesk" name="user_helpdesk" value="<?php echo $helpdesk ?>">
            <span class="input-group-btn">
                <button type="submit" name="sub_post_small" id="sub_post_small" class="btn btn-primary"><b style="color: black;">Post</b></button>
            </span>
        </div>
    </div>

</div>
<div id="small-chat">
    <span class="badge badge-warning pull-right"><b id="countnewmsg"></b></span>

    <a class="open-small-chat">
        <i class="fa fa-comments" data-toggle="tooltip" title="Help Desk"></i>

    </a>

</div>
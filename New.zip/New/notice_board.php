<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['notice_board'] == false) {
    header('Location: home_staff.php');
}

?>
<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/dropzone/dropzone.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
    <link href="css/plugins/codemirror/codemirror.css" rel="stylesheet">

    <!-- Textarea Editor -->
    <link href="editor/css_/bootstrap3-wysihtml5.min.css" rel="stylesheet" media="screen" />

    <!-- Auto show DIV -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
    $(document).ready(function() {
        $("input[name$='cars']").click(function() {
            var test = $(this).val();

            $("div.desc").hide();
            $("#Cars" + test).show();
        });
    });
    </script>

    <!--Multi-select-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
    <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js">
    </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>

</head>

<body>
    <?php
    $saveresponce = "";
    $names = $_SESSION['names'];
    $staffid = $_SESSION['staffid'];
    $dept = $_SESSION['deptcode'];
    //$cat = $_SESSION['cat'];
    $Deanschcode = $_SESSION['schcode2'];
    $Userschcode = $_SESSION['schcode2'];

    function calculate_time_span($date)
    {
        $seconds  = strtotime(date('Y-m-d H:i:s')) - strtotime($date);

        $months = floor($seconds / (3600 * 24 * 30));
        $day = floor($seconds / (3600 * 24));
        $hours = floor($seconds / 3600);
        $mins = floor(($seconds - ($hours * 3600)) / 60);
        $secs = floor($seconds % 60);

        if ($seconds < 60)
            $time = $secs . " seconds ago";
        else if ($seconds < 60 * 60)
            $time = $mins . " min ago";
        else if ($seconds < 24 * 60 * 60)
            $time = $hours . " hours ago";
        else if ($seconds < 24 * 60 * 60)
            $time = $day . " day ago";
        else
            $time = $months . " month ago";

        return $time;
    }

    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }

    if (isset($_POST["submit"])) {

        $messages = $_POST['messages'];
        if ($_POST['cars'] == 2) {
            $messageto = $_POST['messageto'];
            $sch_dept = substr($messageto, 3);
            $code = substr($messageto, 0, 2);
            $type1 = substr($messageto, 0, 1);
        } else {
            $messageto = "Group";
            //$sch_dept = "XX";
            $code = "XX";
            $type1 = "XX";

            $sch_dept = $staffid . "_" . rand(1000, 10000);

            if (!empty($_POST["groupstaff"])) {
                foreach ($_POST['groupstaff'] as $getoutstand) {
                    $sql = "SELECT full_name, staffid, staffacddept FROM users WHERE staffid = '$getoutstand'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $groupdept = strtoupper($row["staffacddept"]);
                            $staffname = "(" . $groupdept . ") " . $row["full_name"];
                        }
                    }
                    $sql2 = "INSERT INTO group_message(sender_id, to_who, group_id, staffname)VALUES('$staffid', '$getoutstand', '$sch_dept', '$staffname')";
                    $result2 = $conn->query($sql2);
                }
            }
        }

        if ($type1 == "S") {
            $sql = "SELECT * FROM schoolname WHERE SchCode = '$sch_dept'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $SchName = "School/Faculty of " . $row["SchName"];
                }
            }
        } elseif ($type1 == "D") {
            $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$sch_dept'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $SchName = $row["DeptName"] . "Department";
                }
            }
        } else {
            $SchName = "XX";
        }

        $newFileName = "XX";
        if (is_uploaded_file($_FILES['file_assign']['tmp_name'])) {

            $fileTmpPath = $_FILES['file_assign']['tmp_name'];
            $fileName = $_FILES['file_assign']['name'];
            $fileSize = $_FILES['file_assign']['size'];
            $fileType = $_FILES['file_assign']['type'];
            $fileNameCmps = explode(".", $fileName);
            $fileExtension = strtolower(end($fileNameCmps));


            $fileName = str_replace("'", "''", $fileName);
            $fileName = filter_var($fileName, FILTER_SANITIZE_STRING);
            //$newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $newFileName = $fileName;

            $allowedfileExtensions = array('pdf');
            if (in_array($fileExtension, $allowedfileExtensions)) {
                // directory in which the uploaded file will be moved
                if ($_FILES['file_assign']['size'] / 1024 <= 5120) { // 5MB

                    $assign_no = $staffid;
                    $uploadFileDir = "pdf/noticeboard/";

                    if (!file_exists($uploadFileDir)) {
                        mkdir($uploadFileDir, 0777, true);
                    }


                    $dest_path = $uploadFileDir . $assign_no . "." . $fileExtension;

                    if (move_uploaded_file($fileTmpPath, $dest_path)) {
                        $sql = "INSERT INTO notice_board (message1, sender_id, to_who, filename1, sch_dept, code, type1, sch_dept_name) VALUES ('$messages', '$staffid', '$messageto', '$newFileName', '$sch_dept', '$code', '$type1', '$SchName')";
                        //$result = $conn->query($sql);
                        if (mysqli_query($conn, $sql)) {
                            $last_id = mysqli_insert_id($conn);
                        }

                        rename("pdf/noticeboard/" . $assign_no . ".pdf", "pdf/noticeboard/" . $last_id . ".pdf");

                        $saveresponce = "<h2 class='alert alert-success'>Record Saved ...</h2>";
                    } else {
                        $message = "<h2 class='alert alert-danger'>Error in moving the file. Make sure you select correct file type.</h2>";
                    }
                } else {
                    $message = "<h2 class='alert alert-danger'>Error: File should be maximun 5MB in size!</h2>";
                }
            } else {
                $message = "<h2 class='alert alert-danger'>Error: Select pdf file</h2>";
            }
        } else {
            $sql = "INSERT INTO notice_board (message1, sender_id, to_who, filename1, sch_dept, code, type1, sch_dept_name) VALUES ('$messages', '$staffid', '$messageto', '$newFileName', '$sch_dept', '$code', '$type1', '$SchName')";
            $result = $conn->query($sql);

            $saveresponce = "<h2 class='alert alert-success'>Record Saved ...</h2>";
        }
    }

    if (isset($_POST["delete"])) {

        $id = $_POST['id'];
        $sql = "SELECT * FROM notice_board WHERE id = '$id'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $group_id = $row["sch_dept"];
            }
        }
        $sql2 = "DELETE FROM group_message  WHERE group_id = '$group_id'";
        $result2 = $conn->query($sql2);

        $sql = "DELETE FROM notice_board WHERE id = '$id'";
        $result = $conn->query($sql);

        $file_to_delete = 'pdf/noticeboard/' . $id . '.pdf';
        unlink($file_to_delete);

        $saveresponce = "<h2 class='alert alert-success'>Record Deleted ...</h2>";
    }
    $conn->close();
    $conn2->close();
    ?>
    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <?php
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                if ($conn2->connect_error) {
                    die("Connection failed: " . $conn2->connect_error);
                }
                ?>
                <div class="col-sm-4">
                    <h2>Notice Board</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li class="active">
                            <strong>Notice Board</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-sm-8">
                    <div class="title-action">
                        <!-- Modal Window -->
                        <div class="modal inmodal" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                                <form enctype="multipart/form-data" class="form-horizontal" action="" method="post">
                                    <div class="modal-content animated bounceInRight">
                                        <div class="modal-header">

                                            <h4 class="modal-title">Add Message to Notice Board</h4>

                                        </div>
                                        <div class="modal-body">
                                            <div id="myRadioGroup">

                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label">Select Group
                                                        Recipient</label>

                                                    <div class="col-sm-7">

                                                        <div class="text-left"><label> <input type="radio" name="cars"
                                                                    checked="checked" value="2" /> School/Faculty
                                                                Group</label></div>
                                                        <div class="text-left"><label> <input type="radio" name="cars"
                                                                    value="3" /> Group
                                                                by Staff </label></div>
                                                    </div>
                                                </div>


                                                <div id="Cars3" class="form-group desc"
                                                    style="text-align: left; display: none;">
                                                    <?php
                                                    $staffidarry[] = "";
                                                    //$staffname[] = "";
                                                    ?>
                                                    <select id="groupstaff" name="groupstaff[]"
                                                        placeholder="Select items(max of 50)" multiple>
                                                        <?php
                                                        $i = 0;
                                                        if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES" || $cat_AcadSec == "YES" || $cat_QAP == "YES" || $cat_APU == "YES" || $cat_Acad_Ofice == "YES") {
                                                            $sql = "SELECT full_name, staffid, staffacddept FROM users ORDER BY staffacddept";
                                                        } elseif ($cat_Dean == "YES") {
                                                            $sql = "SELECT full_name, staffid, staffacddept FROM users WHERE SchCode = '$Deanschcode' ORDER BY staffacddept";
                                                        } elseif ($cat_HOD == "YES") {
                                                            $sql = "SELECT full_name, staffid, staffacddept FROM users WHERE staffacddept = '$dept' ORDER BY staffacddept";
                                                        }
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $i++;
                                                                $staffidarry[$i] = $row["staffid"];
                                                                $staffname = $row["full_name"];
                                                                $groupdept = strtoupper($row["staffacddept"]);
                                                                echo "<option value = '$staffidarry[$i]'>$staffidarry[$i] ($groupdept) $staffname</option>";
                                                            }
                                                        }

                                                        ?>
                                                    </select>

                                                    <!-- </select> -->
                                                </div>
                                                <div id="Cars2" class="form-group desc" style="text-align: left;">
                                                    <label>Select Recipient</label>

                                                    <select name="messageto" class="form-control" style="color:#000000"
                                                        id="messageto">
                                                        <option value="">Select Item</option>
                                                        <?php
                                                        if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES" || $cat_AcadSec == "YES" || $cat_QAP == "YES" || $cat_APU == "YES" || $cat_Acad_Ofice == "YES") {
                                                            echo "<option value='All'>All Staff</option>";

                                                            $sql = "SELECT * FROM schoolname";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $SchCode = $row["SchCode"];
                                                                    $SchName = $row["SchName"];
                                                                    echo "<option value='SD_$SchCode'>DEAN $SchName</option>";
                                                                }
                                                            }


                                                            $sql = "SELECT * FROM schoolname";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $SchCode = $row["SchCode"];
                                                                    $SchName = $row["SchName"];
                                                                    echo "<option value='SA_$SchCode'>All Staff ($SchName)</option>";
                                                                }
                                                            }

                                                            $sql = "SELECT * FROM schoolname";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $SchCode = $row["SchCode"];
                                                                    $SchName = $row["SchName"];
                                                                    echo "<option value='SE_$SchCode'>School/Faculty Exam Officer ($SchName)</option>";
                                                                }
                                                            }


                                                            $sql = "SELECT * FROM deptcoding";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DH_$DeptCode'>HOD ($DeptName)</option>";
                                                                }
                                                            }


                                                            $sql = "SELECT * FROM deptcoding";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DA_$DeptCode'>All Staff ($DeptName)</option>";
                                                                }
                                                            }

                                                            $sql = "SELECT * FROM deptcoding";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DE_$DeptCode'>Departmental Exam Officer ($DeptName)</option>";
                                                                }
                                                            }
                                                        } elseif ($cat_Dean == "YES") {
                                                            $sql = "SELECT * FROM schoolname";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $SchCode = $row["SchCode"];
                                                                    $SchName = $row["SchName"];
                                                                    echo "<option value='SD_$SchCode'>DEAN $SchName</option>";
                                                                }
                                                            }


                                                            $sql = "SELECT * FROM schoolname WHERE SchCode = '$Deanschcode'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $SchCode = $row["SchCode"];
                                                                    $SchName = $row["SchName"];
                                                                    echo "<option value='SA_$SchCode'>All Staff ($SchName)</option>";
                                                                }
                                                            }

                                                            $sql = "SELECT * FROM schoolname WHERE SchCode = '$Deanschcode'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $SchCode = $row["SchCode"];
                                                                    $SchName = $row["SchName"];
                                                                    echo "<option value='SE_$SchCode'>School/Faculty Exam Officer ($SchName)</option>";
                                                                }
                                                            }

                                                            $sql = "SELECT * FROM deptcoding";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DH_$DeptCode'>HOD ($DeptName)</option>";
                                                                }
                                                            }


                                                            $sql = "SELECT * FROM deptcoding WHERE School = '$Deanschcode'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DA_$DeptCode'>All Staff ($DeptName)</option>";
                                                                }
                                                            }

                                                            $sql = "SELECT * FROM deptcoding WHERE School = '$Deanschcode'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DE_$DeptCode'>Departmental Exam Officer ($DeptName)</option>";
                                                                }
                                                            }
                                                        } elseif ($cat_HOD == "YES") {
                                                            $sql = "SELECT * FROM schoolname";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $SchCode = $row["SchCode"];
                                                                    $SchName = $row["SchName"];
                                                                    echo "<option value='SD_$SchCode'>DEAN $SchName</option>";
                                                                }
                                                            }


                                                            $sql = "SELECT * FROM schoolname WHERE SchCode = '$Userschcode'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $SchCode = $row["SchCode"];
                                                                    $SchName = $row["SchName"];
                                                                    echo "<option value='SE_$SchCode'>School/Faculty Exam Officer ($SchName)</option>";
                                                                }
                                                            }

                                                            $sql = "SELECT * FROM deptcoding";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DH_$DeptCode'>HOD ($DeptName)</option>";
                                                                }
                                                            }


                                                            $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DA_$DeptCode'>All Staff ($DeptName)</option>";
                                                                }
                                                            }

                                                            $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $DeptCode = $row["DeptCode"];
                                                                    $DeptName = $row["DeptName"];
                                                                    echo "<option value='DE_$DeptCode'>Departmental Exam Officer ($DeptName)</option>";
                                                                }
                                                            }
                                                        }

                                                        ?>

                                                    </select>
                                                </div>

                                            </div>





                                            <div class="form-group" style="text-align: left;">
                                                <label>Add Message</label>
                                                <textarea name="messages" id="tinymce_basic"></textarea>
                                            </div>
                                            <div class="form-group" style="text-align: left;">
                                                <label>Upload PDF File</label>
                                                <div class="fileinput fileinput-new input-group"
                                                    data-provides="fileinput">
                                                    <div class="form-control" data-trigger="fileinput"><i
                                                            class="glyphicon glyphicon-file fileinput-exists"></i> <span
                                                            class="fileinput-filename"></span></div>
                                                    <span class="input-group-addon btn btn-default btn-file"><span
                                                            class="fileinput-new">Select file</span><span
                                                            class="fileinput-exists">Change</span><input type="file"
                                                            name="file_assign"></span>
                                                    <a href="#"
                                                        class="input-group-addon btn btn-default fileinput-exists"
                                                        data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>


                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-white"
                                                data-dismiss="modal">Close</button>
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper wrapper-content animated fadeInRight">

                        <div class="ibox-content m-b-sm border-bottom">
                            <div class="text-center p-lg">
                                <span>Add your message by selecting </span>
                                <button type="button" class="btn btn-primary btn-xs" data-toggle="modal"
                                    data-target="#myModal"><i class="fa fa-plus"></i>Add Message</button> button
                                <?php echo $saveresponce ?>
                            </div>
                        </div>

                        <div class="col-md-1">

                        </div>
                        <div class="col-md-10">

                            <?php
                            $sql = "SELECT * FROM notice_board WHERE sender_id = '$staffid' ORDER BY id DESC";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                            ?>

                            <table style="width: 100%;">
                                <tbody>
                                    <?php
                                        while ($row = $result->fetch_assoc()) {
                                            $id = $row["id"];
                                            $to_who = $row["to_who"];
                                            $sch_dept = $row["sch_dept"];
                                            $type1 = $row["type1"];
                                            $code = $row["code"];
                                            $date = date_create($row["date1"]);
                                            $Sch_dept_Name = $row["sch_dept_name"];

                                            if ($type1 == "S") {

                                                if ($code == "SD") {
                                                    $getcode = "Dean";
                                                } elseif ($code == "SA") {
                                                    $getcode = "All Staff";
                                                } elseif ($code == "SE") {
                                                    $getcode = "School/Faculty Exam Officer";
                                                }
                                            } else if ($type1 == "D") {

                                                if ($code == "DH") {
                                                    $getcode = "HOD";
                                                } elseif ($code == "DA") {
                                                    $getcode = "All Staff";
                                                } elseif ($code == "DE") {
                                                    $getcode = "Departmental Exam Officer";
                                                }
                                            }


                                        ?>
                                    <tr>
                                        <td>
                                            <div class="faq-item">
                                                <div class="row">
                                                    <div class="col-md-10">
                                                        <?php if ($to_who == "Group") { ?>
                                                        <strong>Message to Group</strong><select class="form-control"
                                                            style="color:#000000">
                                                            <?php
                                                                        $sql2 = "SELECT * FROM group_message WHERE group_id = '$sch_dept'";
                                                                        $result2 = $conn->query($sql2);
                                                                        if ($result2->num_rows > 0) {
                                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                                $to_who = $row2["to_who"];
                                                                                $staffname = $row2["staffname"];
                                                                                echo "<option value=''>$to_who $staffname</option>";
                                                                            }
                                                                        }
                                                                        ?>

                                                        </select>
                                                        <?php } else { ?>
                                                        <strong>Message to:
                                                            <?php echo $getcode ?> (
                                                            <?php echo $Sch_dept_Name ?>
                                                            )</strong>
                                                        <?php } ?>
                                                        <br>
                                                    </div>
                                                    <div class="col-md-2 text-right">
                                                        <form class="form-horizontal" action="" method="post">
                                                            <input type="hidden" name="id"
                                                                value="<?php echo $row["id"] ?>">
                                                            <button type="submit" name="delete"
                                                                class="btn btn-danger btn-xs">Delete</button>
                                                        </form>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-9">
                                                        <?php echo $row["message1"] ?><br>

                                                        <?php if (file_exists('pdf/noticeboard/' . $id . '.pdf')) { ?>
                                                        <p>Click below to download PDF</p>
                                                        <p><a href="pdf/noticeboard/<?php echo $id ?>.pdf"
                                                                target="_blank"><img src="img/pdf_icon.png" width="40"
                                                                    height="40"> <?php echo $row["filename1"] ?></a>
                                                        </p>
                                                        <?php } ?>


                                                    </div>
                                                    <div class="col-md-3">
                                                        <?php

                                                                $current_timestamp = strtotime($row["date1"]);
                                                                $midnight_timestamp = mktime(0, 0, 0, date('m'), date('d'), date('Y'));

                                                                if ($current_timestamp > $midnight_timestamp) {

                                                                ?>
                                                        <small class="pull-right text-muted">Today
                                                            <?php echo date_format($date, "h:i A d D, Y"); ?></small>
                                                        <?php
                                                                } else if ($current_timestamp > $midnight_timestamp - 86400) {

                                                                ?>
                                                        <small class="pull-right text-muted">Yesterday
                                                            <?php echo date_format($date, "h:i A d D, Y"); ?></small>
                                                        <?php
                                                                } else {

                                                                ?>
                                                        <small
                                                            class="pull-right text-muted"><?php echo date_format($date, "l, h:i:s A d D, Y"); ?></small>
                                                        <?php
                                                                }

                                                                ?>

                                                    </div>

                                                </div>

                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                        }
                                        ?>
                                </tbody>
                            </table>
                            <?php
                            }
                            ?>



                            <br><br><br>
                        </div>
                        <div class="col-md-1">

                        </div>


                    </div>
                </div>
            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
            <?php
            $conn->close();
            $conn2->close();
            ?>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>

    <!--Textarea Editor-->
    <!-- <script src="editor/js_/app.js" type="text/javascript"></script> -->
    <script src="editor/js_/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="editor/js_/ckeditor.js" type="text/javascript"></script>
    <script src="editor/js_/jquery.js" type="text/javascript"></script>
    <script src="editor/js_/editor1.js" type="text/javascript"></script>

    <script>
    $(document).ready(function() {

        $('#loading-example-btn').click(function() {
            btn = $(this);
            simpleLoad(btn, true)

            // Ajax example
            //                $.ajax().always(function () {
            //                    simpleLoad($(this), false)
            //                });

            simpleLoad(btn, false)
        });
    });

    function simpleLoad(btn, state) {
        if (state) {
            btn.children().addClass('fa-spin');
            btn.contents().last().replaceWith(" Loading");
        } else {
            setTimeout(function() {
                btn.children().removeClass('fa-spin');
                btn.contents().last().replaceWith(" Refresh");
            }, 2000);
        }
    }
    </script>

    <script>
    $(document).ready(function() {

        var multipleCancelButton = new Choices('#groupstaff', {
            removeItemButton: true,
            maxItemCount: 50,
            searchResultLimit: 50
            /* renderChoiceLimit: 7 */
        });


    });
    </script>

</body>

</html>
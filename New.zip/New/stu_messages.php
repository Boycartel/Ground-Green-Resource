<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

$_SESSION['noresult'] = "YES";
$tot1outunit = $tot2outunit = 0;
$stutype = $_SESSION['stutype'];
$staff_pic_folder = $_SESSION['staff_pic_folder'];
$schcode = $_SESSION['schcode'];
if ($stutype == "UG") {
    include_once 'includes/get_stu_level.php';
}
$_SESSION["TheStuLevel"] = $level;

$regid = $_SESSION["regid"];
$dept = $_SESSION['deptcode'];
$curtsession = $_SESSION['corntsession'];
$level = $_SESSION["TheStuLevel"];


$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$level_code = "L" . $level;
$level_code_all = "L" . $level . "_stu";
$sql = "UPDATE comment SET msgopen ='YES' WHERE (matricno = '$regid' or matricno = '$level_code' or matricno = '$level_code_all' or matricno = 'All' or matricno = 'All_stu')";
$result = $conn_stu->query($sql);

$conn_stu->close();
?>
<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>

    <style type="text/css">
        .asd {
            background: transparent !important;
            border: none !important;
            outline: none !important;
            padding: 0px, 0px, 0px, 0px !important;
            cursor: pointer;

        }
    </style>




</head>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Messages</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_stu.php">Home</a>
                        </li>
                        <li class="active">
                            <strong>Messages</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>


            <div class="wrapper wrapper-content animated fadeInRight">

                <div class="row">
                    <div class="col-lg-12">

                        <div class="ibox chat-view">

                            <div class="ibox-title">

                                Chat room panel <?php echo $level ?>
                            </div>


                            <div class="ibox-content">
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }
                                ?>
                                <div class="row">
                                    <div class="col-md-3">
                                        <form id="myForm" action="ajax_save_rec/stu_chatzone_load.php" method="POST">

                                            <h3 style="padding-left: 1.5em;">Select Recipient</h3>
                                            <select name="msgto" class="form-control" style="color:#000000" size="10" id="selectOption" name="selectOption" onchange="postFormData()">

                                                <option value="Dean" class="chat-user">Dean</option>
                                                <option value="HOD" class="chat-user">HOD</option>
                                                <option value="Examiner" class="chat-user">Exam Officer</option>
                                                <option value="LevelAdv" class="chat-user">Level Adviser</option>

                                                <?php
                                                $dbsession = str_replace("/", "_", $curtsession);
                                                $sql = "SELECT CCode FROM courses_register_" . $dbsession . " WHERE Regn1 = '$regid' ORDER BY CCode";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $CCode = $row["CCode"];

                                                        echo "<option value='$CCode' class='chat-user'>$CCode Course Lecturer(s)</option>";
                                                    }
                                                }


                                                $sql = "SELECT matricno, name1, Session1 FROM hod_list WHERE Session1 = '$curtsession' AND matricno <> '$regid' ORDER BY matricno";
                                                $result = $conn_stu->query($sql);

                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $regid2 = $row["matricno"];
                                                        $stuname2 = strtolower($row["name1"]);
                                                        $stuname2 = ucwords($stuname2);

                                                        echo "<option value='$regid2' class='chat-user'>$regid2 $stuname2</option>";
                                                    }
                                                }

                                                ?>
                                            </select>


                                            <input type="hidden" id="dept1" name="dept1" value="<?php echo $dept ?>" onkeyup="postFormData()">
                                            <input type="hidden" id="stulevel" name="stulevel" value="<?php echo $level ?>" onkeyup="postFormData()">
                                            <input type="hidden" id="staff_pic_folder" name="staff_pic_folder" value="<?php echo $_SESSION["staff_pic_folder"] ?>" onkeyup="postFormData()">

                                            <!-- Use a hidden input field to dynamically store the selected option -->
                                            <input type="hidden" id="selectedOptionHidden" name="selectedOptionHidden">

                                        </form>

                                    </div>
                                    <div class="col-md-9 ">
                                        <h3 style="text-align:center">Chat Body</h3>
                                        <div class="chat-discussion">
                                            <div id="chat_body">
                                                <?php

                                                $level_code = "L" . $level;
                                                $level_code_all = "L" . $level . "_stu";
                                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                $ArryCCode[1] = $ArryCCode[2] = $ArryCCode[3] = $ArryCCode[4] = $ArryCCode[5] = $ArryCCode[6] = $ArryCCode[7] = $ArryCCode[8] = $ArryCCode[9] = $ArryCCode[10] = $ArryCCode[11] = $ArryCCode[12] = $ArryCCode[13] = $ArryCCode[14] = $ArryCCode[15] = $ArryCCode[16] = $ArryCCode[17] = $ArryCCode[18] = $ArryCCode[19] = $ArryCCode[20] = "";
                                                $countArCode = 0;
                                                $dbsession = str_replace("/", "_", $curtsession);
                                                $sql = "SELECT CCode FROM courses_register_" . $dbsession . " WHERE Regn1 = '$regid' ORDER BY CCode";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $countArCode++;
                                                        $CCode = $row["CCode"];
                                                        $ArryCCode[$countArCode] = $row["CCode"];
                                                    }
                                                }


                                                $countrec = 0;
                                                $sql = "SELECT matricno, msgid, cat_coment, recieve_coment, sent_coment, date_time FROM comment WHERE matricno = '$regid' OR matricno = '$level_code' OR matricno = '$level_code_all' OR matricno = 'All' OR matricno = 'All_stu' OR matricno = '$ArryCCode[1]' OR matricno = '$ArryCCode[2]' OR matricno = '$ArryCCode[3]' OR matricno = '$ArryCCode[4]' OR matricno = '$ArryCCode[5]' OR matricno = '$ArryCCode[6]' OR matricno = '$ArryCCode[7]' OR matricno = '$ArryCCode[8]' OR matricno = '$ArryCCode[9]' OR matricno = '$ArryCCode[10]' OR matricno = '$ArryCCode[11]' OR matricno = '$ArryCCode[12]' OR matricno = '$ArryCCode[13]' OR matricno = '$ArryCCode[14]' OR matricno = '$ArryCCode[15]' OR matricno = '$ArryCCode[16]' OR matricno = '$ArryCCode[17]' OR matricno = '$ArryCCode[18]' OR matricno = '$ArryCCode[19]' OR matricno = '$ArryCCode[20]' ORDER BY id DESC";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $countrec++;
                                                        if ($countrec > 20) {
                                                            break;
                                                        }
                                                        $cat = $row['cat_coment'];
                                                        $cat2 = $row['cat_coment'];
                                                        if ($cat == "Examiner" || $cat == "Ass_Examiner") {
                                                            $cat = "Exam Officer";
                                                        } elseif ($cat == "L100" || $cat == "L200" || $cat == "L300" || $cat == "L400" || $cat == "L500" || $cat == "spill_over") {
                                                            $cat = "Level Adviser";
                                                        } elseif ($cat == "HOD") {
                                                            $cat = "HOD";
                                                        } elseif ($cat == "Sub_Admin" || $cat == "Administrator") {
                                                            $cat = "Admin";
                                                        } elseif ($cat == "PG_Coord") {
                                                            $cat = "PG Coordiator";
                                                        }

                                                        if (is_null($row['recieve_coment'])) {

                                                ?>
                                                            <div class="chat-message right">
                                                                <?php

                                                                $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                                $passptfile = str_replace("/", "", $_SESSION['passportid']) . "_passport.jpg";

                                                                echo "<img alt=''  class='message-avatar' src='$stu_pic_folder/$passptfile' width='50' height='50'>";


                                                                ?>

                                                                <div class="message">
                                                                    <a class="message-author" href="#"> <?php echo $cat ?> </a>
                                                                    <span class="message-date"> <?php echo $row['date_time'] ?>
                                                                    </span>
                                                                    <span class="message-content" style="text-align: left;">
                                                                        <?php
                                                                        echo $row['sent_coment'];
                                                                        ?>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="chat-message left">
                                                                <?php
                                                                $sturegother = "";
                                                                if ($cat2 == "Dean" || $cat2 == "HOD" || $cat2 == "Examiner" || $cat2 == "Ass_Examiner" || $cat2 == "L100" || $cat2 == "L200" || $cat2 == "L300" || $cat2 == "L400" || $cat2 == "L500" || $cat2 == "spill_over" || $cat2 == "Administrator" || $cat2 == "Sub_Admin" || $cat2 == "PG_Coord") {
                                                                    $staff_pic_folder = $_SESSION['staff_pic_folder'];
                                                                    $filename = $staff_pic_folder . $row['msgid'] . '.jpg';

                                                                    if (file_exists($filename)) {
                                                                        echo "<img alt=''  class='message-avatar' src='$staff_pic_folder" . $row['msgid'] . ".jpg' width='35' height='35'>";
                                                                    } else {
                                                                        echo "<img alt=''  class='message-avatar' src='img/logo.ico' width='50' height='50'>";
                                                                    }

                                                                    // echo "<img class='message-avatar' alt='' src='$staff_pic_folder/" . strtoupper($_SESSION['deptcode']) . "/images/" . $row['msgid'] . "/MyPic1.jpg'  width='50' height='50' alt=''>";
                                                                } else {
                                                                    $stdid = "NO";
                                                                    $sql3 = "SELECT stdid, matric_no, first_name, other_name, surname FROM std_data_view WHERE matric_no = '$cat2'";
                                                                    $result3 = $conn2->query($sql3);
                                                                    if ($result3->num_rows > 0) {
                                                                        while ($row3 = $result3->fetch_assoc()) {
                                                                            $stdid = $row3['stdid'];
                                                                            $sturegother = $row3['matric_no'];
                                                                            $cat = $row3["first_name"] . " " . $row3["other_name"] . " " . $row3["surname"];
                                                                            $cat = strtolower($cat);
                                                                            $cat = ucwords($cat);
                                                                        }
                                                                    }
                                                                    $sql3 = "SELECT * FROM std_login WHERE stdid = '$stdid'";
                                                                    $result3 = $conn2->query($sql3);
                                                                    if ($result3->num_rows > 0) {
                                                                        $passportid = $stdid;
                                                                    } else {
                                                                        $passportid = $cat2;
                                                                    }

                                                                    $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                                    $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";

                                                                    echo "<img alt=''  class='message-avatar' src='$stu_pic_folder/$passptfile' width='50' height='50'>";
                                                                }

                                                                ?>

                                                                <div class="message">
                                                                    <a class="message-author" href="#"><?php echo $cat . "<br>" . $sturegother ?> </a>
                                                                    <span class="message-date"> <?php echo $row['date_time'] ?>
                                                                    </span>
                                                                    <span class="message-content">
                                                                        <?php
                                                                        echo $row['recieve_coment'];
                                                                        ?>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        <?php } ?>
                                                    <?php } ?>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-lg-12">

                                        <div class="col-md-3 ">
                                            <h3 style="text-align:center; color:black">Message To ...</h3>
                                            <input type="hidden" id="dept2" name="dept2" value="<?php echo $dept ?>">
                                            <input type="hidden" id="stureg" name="stureg" value="<?php echo $regid ?>">
                                            <input type="hidden" id="dbdept" name="dbdept" value="<?php echo $_SESSION['deptdb'] ?>">

                                            <div class="form-group" id="sendto">

                                            </div>
                                        </div>
                                        <div class="col-md-9 ">
                                            <div class="chat-message-form">
                                                <div class="form-group">
                                                    <div class="col-md-11 ">
                                                        <textarea class="form-control message-input" id="mychat" name="mychat" placeholder="Enter message text"></textarea>
                                                    </div>
                                                    <div class="col-md-1 ">
                                                        <button onclick="postAndInsert()" class="btn btn-primary btn-xs">Post</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <br><br>
                                <?php
                                $conn->close();
                                $conn2->close();
                                $conn_stu->close();
                                ?>
                            </div>

                        </div>
                    </div>

                </div>


            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
        <?php
        include_once 'small_chat.php';
        ?>
    </div>



    <?php
    include_once 'includes/footer.php';
    ?>
    <!--Insert Chat-->



    <script type="text/javascript">
        function postAndInsert() {

            var mychat = document.getElementById("mychat").value;
            var recip_id = document.getElementById("recip_id").value;
            var dept2 = document.getElementById("dept2").value;
            var stureg = document.getElementById("stureg").value;
            var dbdept = document.getElementById("dbdept").value;


            $.ajax({
                url: 'ajax_save_rec/stu_chatzone_insert.php',
                method: 'POST',
                data: {
                    mychat: mychat,
                    recip_id: recip_id,
                    dept2: dept2,
                    stureg: stureg,
                    dbdept: dbdept
                },
                //success: function(data) {
                //alert(data);
                //}
            });



            document.getElementById("mychat").value = "";
            //document.getElementById("recip_id").value = "";
        }
    </script>
    <!--Fetch Chat-->
    <!--<script src="http://code.jquery.com/jquery-latest.js"></script>-->
    <script>
        $(document).ready(function() {
            setInterval(function() {
                $("#chat_body").load(window.location.href + " #chat_body");
            }, 3000);
        });
    </script>



    <script type="text/javascript">
        function postFormData() {
            var selectOption = document.getElementById("selectOption").value;
            var dept = document.getElementById("dept1").value;
            var staff_pic_folder = document.getElementById("staff_pic_folder").value;
            var stulevel = document.getElementById("stulevel").value;

            // Assign the selected option to the hidden input field
            document.getElementById("selectedOptionHidden").value = selectOption;

            // Display the selected option and input text
            //alert("Selected Option: " + selectOption + "\nInput Text: " + inputText);

            // You can also perform other actions here like sending an AJAX request to the server
            // You can use the FormData API to easily send the form data asynchronously
            // Example: 
            // var formData = new FormData(document.getElementById("myForm"));
            // fetch("process.php", {
            //     method: "POST",
            //     body: formData
            // }).then(response => response.text())
            //   .then(data => {
            //       console.log(data); // Response from the server
            //   });
            /*
            var formData = new FormData(document.getElementById("myForm"));
            fetch("ajax_save_rec/stu_chatzone_load.php", {
                method: "POST",
                body: formData
            }).then(response => response.text())
              .then(data => {
                  // Display the results in the div element
                  document.getElementById("sendto").innerHTML = data;
            });
            */

            $.ajax({
                type: "POST",
                url: 'ajax_save_rec/stu_chatzone_load.php',
                data: {
                    state1: selectOption,
                    dept1: dept,
                    staff_pic_folder1: staff_pic_folder,
                    stulevel1: stulevel
                }
            }).done(function(data) {
                $("#sendto").html(data);
            });

        }
    </script>




</body>

</html>


    <?php
	require_once 'includes/db_connect.php';
	require_once 'includes/check_validity.php';

	if (isset($_POST["state"])) {

		// Capture selected country

		$getdept = $_POST["state"];

		// Define country and city array

		$sql = "SELECT * FROM dept_program WHERE DeptCode = '$getdept'";
		$result = $conn->query($sql);

		echo "<select class='form-control' style='color:#000000' id='prog' name='prog' required='required'>";
		echo "<option></option>";
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				$ProgName = $row["ProgName"];
				echo "<option value='$ProgName'>$ProgName</option>";
			}
		}
		echo "</select>";
	}

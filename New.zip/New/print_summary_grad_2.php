<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?>, Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword"
        content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light"
        rel="stylesheet" type="text/css">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>


    <style>
    .btn-xs,
    .btn-group-xs>.btn {
        padding: 1px 5px;
        font-size: 12px;
        line-height: 1.5;
        border-radius: 3px;
    }
    </style>


    <style type="text/css">
    table {
        page-break-inside: avoid;
        border: 2em;
    }

    /*h3 {
            page-break-before: always;
        }*/
    @page {
        size: A4 portrait;
        font-size: small;
    }

    @page :left {
        margin-left: 1cm;
    }

    @page :right {
        margin-left: 2cm;
    }
    </style>
    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: auto; height=auto; font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <?php

    $deptname = "";

    $getdept = $_SESSION['dept_sctny'];
    $getyeargrad = $_SESSION['getyeargrad'];
    $getsemester = $_SESSION['semesterSel'];
    if ($_SESSION['InstType'] == "Polytechnic") {
        $getprogram = $_SESSION['getprogram'];
        if ($getprogram == "ND") {
            $prog = "National Diploma";
        } elseif ($getprogram == "HND") {
            $prog = "Higher National Diploma";
        }
    }
    $deptname = $_SESSION["deptname"];
    ?>


    <?php
    /* $userdept = $_SESSION['deptcode'];
    $userid = $_SESSION["staffid"];
    $usernames = $_SESSION['names'];
    $useremail = $_SESSION['email'];
    $deptname = $_SESSION['deptname'];
    $cat = $_SESSION['cat'];
    $corntsession = $_SESSION['corntsession'];
    $cursemester = $_SESSION['cursemester']; */
    ?>

    <?php
    //$lga = $prog = "selitem";
    $getDE = "NO";
    $siwesstatus = $_SESSION["siwesstatus"];
    $deptoption = $_SESSION['deptoption'];

    $Is500L = "NO";

    $getdept = $_SESSION['dept_sctny'];
    $schcode = $_SESSION['schcode'];

    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$getdept'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $isdeptoption = $row["deptoption"];
            $iscurriculum = $row["curriculum"];
        }
    }

    $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION["HOD_Sign"] = $row["full_name"];
        }
    }

    $sql = "SELECT * FROM users WHERE SchCode = '$schcode' AND (cat = 'Dean' OR cat = 'HODDean' OR cat = 'PGExam')";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $_SESSION["Dean_Sign"] = $row["full_name"];
        }
    } else {
        $_SESSION["Dean_Sign"] = "XXXX";
    }


    //echo $maxSession."<br>";
    $classdegree = "";
    $getdept = $_SESSION['dept_sctny'];

    $getyeargrad = $_SESSION['getyeargrad'];
    $getsemester = $_SESSION['semesterSel'];
    //$dept_scrutiny_senate = $getdept . "_scrutiny_senate";


    ?>


    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
        <form class="form-horizontal form-bordered" method="post">
            <div class="row">

                <div class="row">
                    <div class="col-lg-5">
                        Department: <?php echo $deptname; ?>
                    </div>
                    <div class="col-lg-4">
                        Year of Graduation: <?php echo $_SESSION['getyeargrad']; ?>
                    </div>
                    <div class="col-lg-3">
                        Semester: <?php echo $_SESSION['semesterSel']; ?>
                    </div>

                </div>
                <hr class="separator" />
                <br>
                <div class="col-lg-12">
                    <div id="printableArea" style="width: auto; float: none">
                        <h4 style="text-align: center">
                            <?php echo $_SESSION['instname'] ?><br>
                            <?php echo $_SESSION['sch_faculty'] ?> OF <?php echo strtoupper($_SESSION['schname']) ?><br>

                            DEPARTMENT OF <?php echo strtoupper($deptname) ?><br>
                            <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                            <?php echo strtoupper($prog) ?><br>
                            <?php } ?>
                            <strong>COMPUTED RESULTS FOR GRADUATING STUDENTS</strong><br>
                        </h4>

                        <?php
                        $getsemester = $_SESSION['semesterSel'];
                        $deptdb = $_SESSION['deptdb'];
                        $dept_db = $deptdb . strtolower($getdept);
                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                        if ($conn_stu->connect_error) {
                            die("Connection failed: " . $conn_stu->connect_error);
                        }

                        $headsession[] = "";
                        $headlevel[] = "";
                        $count_sess = 0;
                        $sql = "SELECT * FROM grad_session WHERE yeargrad = '$getyeargrad' AND semester = '$getsemester' ORDER BY session1, level1";
                        $result = $conn_stu->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $count_sess++;
                                $headsession[$count_sess] = $row['session1'];
                                $headlevel[$count_sess] = $row['level1'];
                            }
                        }
                        ?>
                        <table class="table table-bordered" cellspacing="0" rules="all" border="1">
                            <thead style='text-align:center'>
                                <tr>
                                    <th>S/No</th>
                                    <th>Matric No</th>
                                    <th>Name</th>
                                    <?php for ($i = 1; $i <= $count_sess; $i++) { ?>
                                    <?php
                                        $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$headsession[$i]'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            echo "<th colspan='4'>Canceled Session<br>$headsession[$i]</th>";
                                        } else {
                                            echo "<th colspan='4'>$headlevel[$i] Level<br>$headsession[$i]</th>";
                                        }
                                        ?>


                                    <?php } ?>

                                    <th>Class of Degree</th>

                                </tr>
                                <tr>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <?php for ($i = 1; $i <= $count_sess; $i++) { ?>
                                    <th>TCUR</th>
                                    <th>TCP</th>
                                    <th>TWGP</th>
                                    <th>CGPA</th>
                                    <?php } ?>

                                    <th></th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $ccgpa = 0;
                                $classdegree = "";
                                //$sno=0;
                                $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = 0;



                                $gradstuReg = $_SESSION["gradstuReg"];
                                $gradStuName = $_SESSION["gradStuName"];
                                $snoArray = $_SESSION["snoArray"];
                                $sno = $_SESSION["sno"];
                                $gradStuCGPA = $_SESSION["gradStuCGPA"];
                                $gradStuDOpt = $_SESSION["gradStuDOpt"];

                                for ($i = 1; $i <= $sno; $i++) {
                                    $no = $snoArray[$i];
                                    $matno = $gradstuReg[$i];
                                    $names = $gradStuName[$i];
                                    $ccgpa = $gradStuCGPA[$i];
                                    $Deptopt2 = $gradStuDOpt[$i];

                                    $sql4 = "SELECT * FROM grad_summary WHERE matric_no = '$matno'";
                                    $result4 = $conn_stu->query($sql4);
                                    if ($result4->num_rows == 0) {

                                        $sql = "SELECT * FROM std_data_view WHERE matric_no = '$matno'";
                                        $result = $conn2->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                                if ($_SESSION['InstType'] == "Polytechnic") {
                                                    $modeofentry = $row['modeofentry'];
                                                    if ($modeofentry == "ND") {
                                                        $prog = "National Diploma";
                                                    } elseif (
                                                        $modeofentry == "HND"
                                                    ) {
                                                        $prog = "Higher National Diploma";
                                                    }
                                                }
                                                $entry_level = $row['entry_level'];
                                                $entry_session = $row['entry_session'];
                                                $stu_curriculum = $row['curriculum'];
                                                $Stu_Dept_Opt = $row["Dept_Option"];
                                                $YAddmitted = substr($entry_session, 0, 4);
                                                if ($entry_level == 200) {
                                                    $getDE = "DE200";
                                                } elseif ($entry_level == 300) {
                                                    $getDE = "DE300";
                                                } elseif ($entry_level == 100) {
                                                }
                                            }
                                        }


                                        unset($sessionarry);
                                        unset($LevelArray);

                                        unset($countSesRes);

                                        unset($LevelCGPA);
                                        unset($absent1ST);
                                        unset($absent2ND);

                                        $totCT = $totCP = $gpoint = $totGP = 0;

                                        $Lev_totunit = 0;
                                        $Lev_totgp = 0;
                                        $maxSession = "";
                                        $NotRelevant = false;
                                        $SessionCount = 0;

                                        $yearadmt = substr($entry_session, 0, 4);
                                        if ($entry_level == 200) {
                                            $yearadmt = $yearadmt - 1;
                                        } elseif ($entry_level == 300) {
                                            $yearadmt = $yearadmt - 2;
                                        }
                                        $countstu = 0;

                                        for ($x = 0; $x <= 11; $x++) {
                                            //$countOneLev=$countTwoLev=$countThreLev=$countFivLev=$countFourLev=0;
                                            $maxLevel = 0;
                                            $nextyr = $yearadmt + 1;
                                            $sessionarry[$x] = $yearadmt . "/" . $nextyr;

                                            $StuCurSess = str_ireplace("/", "_", $sessionarry[$x]);
                                            $yearadmt++;


                                            $gtotgp = 0;
                                            $stcp = 0;
                                            $LevelCGPA2 = 0;
                                            $countSesRes[$x] = 0;
                                            $absent1ST[$x] = 0;
                                            $absent2ND[$x] = 0;
                                            $countOneLev = $countTwoLev = $countThreLev = $countFivLev = $countFourLev = $getlevel = 0;


                                            if ($stu_curriculum == "old") {
                                                $stu_curriculum2 = "";
                                            } else {
                                                $stu_curriculum2 = "_" . $stu_curriculum;
                                            }

                                            if ($sessionarry[$x] < "2014/2015") {
                                                $deptcorreg = "correg";
                                            } else {
                                                $deptcorreg = "correg_" . $StuCurSess;
                                            }

                                            $CT = $CP = $GP = $GPA = 0;

                                            $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
                                            $result = $conn_stu->query($sql);
                                            $totunit = $totgp = $cgpa = $gtotgp = $gtotunit = 0;
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {

                                                    $ccode = $row['CCode'];
                                                    $ctitle = $row['CTitle'];
                                                    $cunit = $row['CUnit'];


                                                    if ((int)substr($ccode, 3, 1) == 5) {
                                                        $countFivLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 4) {
                                                        $countFourLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 3) {
                                                        $countThreLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 2) {
                                                        $countTwoLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 1) {
                                                        $countOneLev++;
                                                    }

                                                    $gpoint = $row["point"];
                                                    $grade = $row["grade"];
                                                    $stcp = $stcp + $cunit;

                                                    if ($grade !== "F") {

                                                        $CP = $CP + $cunit;
                                                        $totCP = $totCP + $cunit;
                                                    }

                                                    $CA = $row["CA"];
                                                    $Exam = $row["Exam"];

                                                    $total = $CA + $Exam;



                                                    $CT = $CT + $cunit;
                                                    $GP = $GP + $gpoint;

                                                    $totCT = $totCT + $cunit;
                                                    $totGP = $totGP + $gpoint;


                                                    $countSesRes[$x]++;
                                                }
                                            }
                                            $SessionCount = $x;
                                            $maxLevel = max(
                                                $countOneLev,
                                                $countTwoLev,
                                                $countThreLev,
                                                $countFourLev,
                                                $countFivLev
                                            );
                                            if ($countOneLev == $maxLevel) {
                                                $LevelArray[$x] = 100;
                                            } elseif ($countTwoLev == $maxLevel) {
                                                $LevelArray[$x] = 200;
                                            } elseif ($countThreLev == $maxLevel) {
                                                $LevelArray[$x] = 300;
                                            } elseif ($countFourLev == $maxLevel) {
                                                $LevelArray[$x] = 400;
                                            } elseif ($countFivLev == $maxLevel) {
                                                $LevelArray[$x] = 500;
                                                //$Is500L="YES";
                                            }


                                            if ($CT > 0) {
                                                $GPA = number_format($GP / $CT, 2);
                                                $GPA2 = $GP / $CT;
                                            } else {
                                                $GPA = 0;
                                                $GPA2 = 0;
                                            }

                                            if ($totCT > 0) {
                                                $cgpa = number_format($totGP / $totCT, 2);
                                                $cgpa2 = $totGP / $totCT;
                                            } else {
                                                $cgpa = 0;
                                                $cgpa2 = 0;
                                            }

                                            $Lev_totunit = $Lev_totunit + $totunit;
                                            $Lev_totgp = $Lev_totgp + $totgp;


                                            if (
                                                $Lev_totunit == 0
                                            ) {
                                                $LevelCGPA[$x] = 0;
                                            } else {
                                                $LevelCGPA[$x] = $Lev_totgp / $Lev_totunit;
                                            }
                                            if ($nextyr >= $getyeargrad + 1) {
                                                $maxSession = $sessionarry[$x];
                                                $getMaxSess = $sessionarry[$x];
                                                break;
                                            }
                                            $newSession = $sessionarry[$x];
                                            $newLevel = $LevelArray[$x];


                                            if ($_SESSION['InstType'] == "Polytechnic") {
                                                $prog = $modeofentry;
                                            } else {
                                                $prog = "NO";
                                            }
                                            $sql6 = "INSERT INTO grad_summary(matric_no, name1, session1, level1, CT, CP, GP, GPA, TCT, TCP, TGP, CGPA, curri, deptopt, prog, yeargrad, semester)VALUES('$matno', '$names', '$newSession', '$newLevel', '$CT', '$CP', '$GP', '$GPA', '$totCT', '$totCP', '$totGP', '$cgpa', '$stu_curriculum', '$Stu_Dept_Opt', '$prog', '$getyeargrad', '$getsemester')";
                                            $result6 = $conn_stu->query($sql6);

                                            $sql4 = "SELECT * FROM grad_session WHERE session1 = '$newSession' AND level1 = '$newLevel' AND yeargrad = '$getyeargrad' AND curri = '$stu_curriculum' AND deptopt = '$Stu_Dept_Opt' AND prog = '$prog' AND semester = '$getsemester'";
                                            $result4 = $conn_stu->query($sql4);
                                            if ($result4->num_rows == 0) {
                                                $sql5 = "INSERT INTO grad_session(session1, level1, curri, deptopt, yeargrad, prog, semester)VALUES('$newSession', '$newLevel', '$stu_curriculum', '$Stu_Dept_Opt', '$getyeargrad', '$prog', '$getsemester')";
                                                $result5 = $conn_stu->query($sql5);
                                            }
                                        }
                                    }


                                    echo "<tr><td>$no</td><td>$matno</td><td>$names</td>";

                                    for ($k = 1; $k <= $count_sess; $k++) {
                                        $totCTview = $totCPview = $totGPview = $totGPAview = "";
                                        $stusession = $headsession[$k];
                                        $stulevel = $headlevel[$k];
                                        $sql = "SELECT * FROM grad_summary WHERE matric_no = '$matno' AND level1 = '$stulevel' AND session1 = '$stusession'";
                                        $result = $conn_stu->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                                $totCTview = $row["TCT"];
                                                $totCPview = $row["TCP"];
                                                $totGPview = $row["TGP"];
                                                $totGPAview = number_format($row["CGPA"], 2);
                                            }
                                        }
                                        $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$stusession'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            echo "<td style='text-align: center'></td><td style='text-align: center'></td><td style='text-align: center'></td><td style='text-align: center'></td>";
                                        } else {
                                            echo "<td style='text-align: center'>$totCTview</td><td style='text-align: center'>$totCPview</td><td style='text-align: center'>$totGPview</td><td style='text-align: center'>$totGPAview</td>";
                                        }
                                    }
                                    $cgpa = $totGPAview;
                                    //$cgpa = 3.0;
                                    include 'modulesInSess/classofdegree_inc.php';


                                    echo "<td>$classdegree</td></tr>";
                                }

                                $Percfirst = number_format(($Countfirst / $sno) * 100, 1);
                                $Perc2Upper = number_format(($Count2Upper / $sno) * 100);
                                $Perc2Lower = number_format(($Count2Lower / $sno) * 100);
                                $Perc3Class = number_format(($Count3Class / $sno) * 100);
                                $PercPass = number_format(($CountPass / $sno) * 100);
                                ?>
                            </tbody>
                        </table>
                        <br>
                        <h4 style="text-align: center">SUMMARY</h4>
                        <table class="table table-bordered" cellspacing="0" rules="all" border="1">
                            <thead style='text-align:center'>
                                <tr>
                                    <th>S/No</th>
                                    <th>Class of Degree</th>
                                    <th>Number</th>
                                    <th>Percentage %</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                echo "<tr><td>1</td><td>First Class</td><td style='text-align: center'>$Countfirst</td><td style='text-align: center'>$Percfirst %</td></tr>";
                                echo "<tr><td>2</td><td>Second Class Upper</td><td style='text-align: center'>$Count2Upper</td><td style='text-align: center'>$Perc2Upper %</td></tr>";
                                echo "<tr><td>3</td><td>Second Class Lower</td><td style='text-align: center'>$Count2Lower</td><td style='text-align: center'>$Perc2Lower %</td></tr>";
                                echo "<tr><td>4</td><td>Third Class</td><td style='text-align: center'>$Count3Class</td><td style='text-align: center'>$Perc3Class %</td></tr>";
                                echo "<tr><td>5</td><td>Pass</td><td style='text-align: center'>$CountPass</td><td style='text-align: center'>$PercPass %</td></tr>";
                                echo "<tr><td></td><th>Total</th><td style='text-align: center'>$sno</td><td style='text-align: center'>100 %</td></tr>";
                                ?>
                            </tbody>
                        </table>
                        <br>
                        <table style="width: 100%;">
                            <tbody>
                                <tr>
                                    <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em"
                                        colspan="12">
                                        <?php echo $_SESSION["HOD_Sign"] ?></td>
                                    <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em"
                                        colspan="8">
                                        <?php echo $_SESSION["Dean_Sign"] ?></td>
                                </tr>
                                <tr>
                                    <th style="border-style: none; text-align:center; font-size:small" colspan="12">
                                        Head of Department and Chief Examiner
                                    </th>
                                    <th style="border-style: none; text-align:center; font-size:small" colspan="8">
                                        Dean of Faculty
                                    </th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-lg-12" style="text-align: right">
                        <input type="button" onclick="printDiv('printableArea')" value="print to PDF" />
                    </div>
                    <br><br>
                </div>

            </div>
        </form>
    </div>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_edit'] == false) {
    header('Location: home_staff.php');
}
?>
<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_D.js"> </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Gradaution</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Gradaution
                            </li>

                            <li class="active">
                                <strong>Students Record</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students Record
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal bucket-form" method="post" action="">
                                <div class="row">
                                    <div class="col-lg-3 col-sm-3 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Session of Graduation:</label>
                                            <div class="col-sm-7">
                                                <select class="scale form-control m-bot15" name="sessiongrad"
                                                    required="required">
                                                    <option></option>
                                                    <?php
                                                    $finalyear = substr($_SESSION['resultsession'], 0, 4);
                                                    for ($x = 2018; $x <= $finalyear; $x++) {
                                                        $x2 = $x + 1;
                                                    ?>
                                                    <option><?php echo $x . "/" . $x2; ?></option>

                                                    <?php } ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-3 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Department:</label>
                                            <div class="col-sm-7">
                                                <select class="form-control m-bot15" name="dept" id="dept">
                                                    <option value="All">All</option>

                                                    <?php
                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode = $row["DeptCode"];
                                                            $deptname = $row["DeptName"];
                                                            echo "<option value=$deptcode>$deptname</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-3 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Semester:</label>
                                            <div class="col-sm-7">
                                                <select class="form-control m-bot15" name="semes" id="semes" required>
                                                    <option value="">Select Item</option>
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-sm-3 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label"></label>
                                            <div class="col-sm-7">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </form>

                            <?php
                            //for ($i = 1; $i <= 10000; $i++) {
                            //echo addOrdinalNumberSuffix($i) . "\t";
                            //if ($i % 10 == 0) {
                            //echo "\n";
                            //}
                            //}

                            if (isset($_POST["submit"])) {

                                $sessiongradpost = $_POST["sessiongrad"];
                                $deptpost = $_POST["dept"];
                                $semes = $_POST["semes"];
                                $deptname = "All";
                                $sql = "SELECT * FROM deptcoding WHERE DeptCode='$deptpost'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    // output data of each row
                                    while ($row = $result->fetch_assoc()) {
                                        $deptname = $row["DeptName"];
                                    }
                                }
                            ?>
                            <table id="myTable" style="font-size:12px" summary="" rules="groups" frame="hsides"
                                border="2" class="table mb-none">
                                <caption>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA <br> DEPARTMENT OF
                                    <?php echo strtoupper($deptname) ?><br> <?php echo $sessiongradpost ?>
                                    GRADUATING STUDENT'S BIODATA FORM</caption>
                                <colgroup align="left"></colgroup>
                                <colgroup align="left"></colgroup>
                                <colgroup span="2"></colgroup>
                                <colgroup span="3" align="left"></colgroup>
                                <thead style='text-align:center'>
                                    <tr>
                                        <th>S/No</th>
                                        <th>MATRIC NO.</th>
                                        <th>FIRST Name</th>
                                        <th>MIDDLE NAME</th>
                                        <th>SURNAME</th>
                                        <th>GSM Number</th>
                                        <th>STATE OF ORIGIN</th>
                                        <th>CLASS OF DEGREE</th>
                                        <th>DATE OF BIRTH</th>
                                        <th>DATE OF GRADUATION</th>
                                        <th>STATUS</th>
                                        <th>GENDER</th>
                                        <th>MARITAL STATUS</th>
                                        <th>JAMB REG</th>
                                        <th>MILITARY PERSONEL</th>
                                        <th>COURSE OF STUDY</th>
                                        <th>STUDY MODE</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                        set_time_limit(5000);
                                        $sno = 0;



                                        $classdegree = "";
                                        $cgpa = 0;
                                        if ($deptpost == "All") {
                                            $sql = "SELECT DeptCode, DeptName FROM deptcoding ORDER BY DeptName";
                                        } else {
                                            $sql = "SELECT DeptCode, DeptName FROM deptcoding WHERE DeptCode = '$deptpost'";
                                        }
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $deptpost = strtolower($row["DeptCode"]);

                                                $dept_db = $_SESSION['deptdb'] . strtolower($deptpost);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }
                                                if ($_SESSION['InstType'] == "University") {
                                                    $sql3 = "SELECT * FROM scrutiny_senate WHERE session1 = '$sessiongradpost' AND semester = '$semes' AND graduated = 'YES'";
                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                    $sql3 = "SELECT * FROM scrutiny_senate WHERE session1 = '$sessiongradpost' AND semester = '$semes' AND graduated = 'YES' AND mode_entry = 'HND'";
                                                }

                                                $result3 = $conn_stu->query($sql3);
                                                if ($result3->num_rows > 0) {
                                                    while ($row3 = $result3->fetch_assoc()) {
                                                        $sno++;
                                                        $Regn = $row3["Regn"];
                                                        $cgpa = number_format((float)$row3["CGPA"], 2, '.', '');
                                                        $classdegree = $row3["classdegree"];

                                                        $yearGrd = $row3["yearGrad"];
                                                        $Department = $row3["deptfull"];

                                                        $fname = $row3["fname"];
                                                        $oname = $row3["oname"];
                                                        $sname = $row3["sname"];
                                                        $gender = $row3["sex"];

                                                        $dob = $row3["dob"];
                                                        $mstatus = $row3["m_status"];
                                                        $JAMB_No = $row3["JANB_no"];
                                                        //$dob2   =   date("m-d-Y", strtotime($dob));
                                                        $Phone = $row3["phone"];
                                                        $stateOfOrigin = $row3["stateOfOrigin"];
                                                        $marital = $row3["m_status"];

                                                        $modeofentry = $row3["mode_entry"];

                                                        echo "<tr><td>$sno</td><td>$Regn</td><td>$fname</td><td>$oname</td><td>$sname</td><td>$Phone</td><td>$stateOfOrigin</td><td>$classdegree</td><td>$dob</td><td>$yearGrd</td><td></td><td>$gender</td><td>$mstatus</td><td>$JAMB_No</td><td></td><td>$Department</td><td>$modeofentry</td></tr>\n";
                                                    }
                                                }
                                                $conn_stu->close();
                                            }
                                        }

                                        ?>
                                </tbody>
                            </table>

                            <br><br>
                            <div class="form-group">
                                <!-- Buttons -->
                                <div class="col-lg-offset-2 col-lg-9">
                                    <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                        class="btn btn-primary">Download</a>
                                </div>
                            </div>

                            <?php
                            }    //End Submit
                            ?>


                        </div>
                    </div>
                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>


                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
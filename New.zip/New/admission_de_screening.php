<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_view'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php

    $sno = 0;

    $schcode = $_SESSION['schcode2'];
    $names = $_SESSION['names'];
    $staffid = strtoupper($_SESSION['staffid']);
    //$cat = $_SESSION['cat'];

    $error1 = "";
    $error2 = "";
    $error3 = "NO";
    $date1 = date("Y/m/d");

    $getyear = "2020";
    $_SESSION["getyear"] = $getyear;
    if (isset($_POST["view"])) {
        $getJAMB = $_POST["id"];
        $sql = "SELECT * FROM fchoice_" . $getyear . " WHERE RegNumb = '$getJAMB'";
        $result = $conn11->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $candname = $row["CandName"];
                $getdept = $row["FUTMX_DEPT_CODE"];
                $getstate = $row["StateOfOrigin"];
                $getsex = $row["Sex"];
            }
        }
    }
    if (isset($_POST["submit"])) {

        $level_admt = 200;
        $tot_score = 0;
        $postJAMB = $_POST["postJAMB"];
        $postcandname = $_POST["postcandname"];
        $poststate = $_POST["poststate"];
        $postsex = $_POST["postsex"];
        $postdept = $_POST["postdept"];
        $highqual = $_POST["highqual"];
        $nd_result = $hnd_result = $education = $major1 = $IJMBsub1 = $IJMBsub2 = $IJMBsub3 = $IJMBgrade1 = $IJMBgrade2 = $IJMBgrade3 = "-";


        $remark = $_POST["remark"];

        if (isset($_POST["fut"])) {
            $fut_IJMB = "YES";
        } else {
            $fut_IJMB = "NO";
        }
        if ($remark == "NQ") {
            $tot_score = 0;
            $level_admt = 0;
            //$nd_result = $hnd_result = $education = $major1 = "-";
            $sql = "SELECT * FROM de_screening WHERE RegNumb = '$postJAMB'";
            $result = $conn11->query($sql);
            if ($result->num_rows > 0) {
                $sql2 = "UPDATE de_screening set high_qual = '$highqual', nd_result = '$nd_result', hnd_result = '$hnd_result', nce_education = '$education', nce_major1 = '$major1', tot_score = '$tot_score', remark = '$remark', level_admt = '$level_admt' WHERE RegNumb = '$postJAMB'";
                $result2 = $conn11->query($sql2);
            } else {
                $sql2 = "INSERT INTO de_screening (RegNumb, CandName, StateOfOrigin, Sex, FUTMX_DEPT_CODE, FUTMX_SCH_CODE, nd_result, hnd_result, nce_education, nce_major1, tot_score, remark, high_qual, level_admt, user1, year1) VALUES ('$postJAMB', '$postcandname', '$poststate', '$postsex', '$postdept', '$schcode', '$nd_result', '$hnd_result', '$education', '$major1', '$tot_score', '$remark', '$highqual', '$level_admt', '$staffid', '$getyear')";
                $result2 = $conn11->query($sql2);
            }
        } else {
            if ($highqual == "NCE") {
                $education = $_POST["education"];
                $major1 = $_POST["major1"];
                if ($education == "A") {
                    $edupoint = 5;
                } elseif ($education == "B") {
                    $edupoint = 4;
                } elseif ($education == "C") {
                    $edupoint = 3;
                } elseif ($education == "D") {
                    $edupoint = 2;
                } elseif ($education == "E") {
                    $edupoint = 1;
                }

                if ($major1 == "A") {
                    $majpoint = 5;
                } elseif ($major1 == "B") {
                    $majpoint = 4;
                } elseif ($major1 == "C") {
                    $majpoint = 3;
                } elseif ($major1 == "D") {
                    $majpoint = 2;
                } elseif ($major1 == "E") {
                    $majpoint = 1;
                }

                $tot_point = $edupoint + $majpoint;
                $tot_score = $tot_point * 40;
                if ($education == "-" || $major1 == "-") {
                    $error2 = "Select all Grades for the NCE Program";
                } else {
                    if ($postdept == "ITE" || $postdept == "EDB" || $postdept == "EDM" || $postdept == "EDP" || $postdept == "EDT" || $postdept == "EDG") {
                        $level_admt = 300;
                    }
                    if ($tot_point < 8) {
                        $remark = "NQ";
                        $tot_score = 0;
                        $level_admt = 0;
                    }
                    $sql = "SELECT * FROM de_screening WHERE RegNumb = '$postJAMB'";
                    $result = $conn11->query($sql);
                    if ($result->num_rows > 0) {
                        $sql2 = "UPDATE de_screening set high_qual = '$highqual', nd_result = '$nd_result', hnd_result = '$hnd_result', nce_education = '$education', nce_major1 = '$major1', tot_score = '$tot_score', remark = '$remark', level_admt = '$level_admt' WHERE RegNumb = '$postJAMB'";
                        $result2 = $conn11->query($sql2);
                    } else {
                        $sql2 = "INSERT INTO de_screening (RegNumb, CandName, StateOfOrigin, Sex, FUTMX_DEPT_CODE, FUTMX_SCH_CODE, nd_result, hnd_result, nce_education, nce_major1, tot_score, remark, high_qual, level_admt, user1, year1) VALUES ('$postJAMB', '$postcandname', '$poststate', '$postsex', '$postdept', '$schcode', '$nd_result', '$hnd_result', '$education', '$major1', '$tot_score', '$remark', '$highqual', '$level_admt', '$staffid', '$getyear')";
                        $result2 = $conn11->query($sql2);
                    }
                }
            } elseif ($highqual == "IJMB") {
                $IJMBsub1 = $_POST["ijmb_sub1"];
                $IJMBsub2 = $_POST["ijmb_sub2"];
                $IJMBsub3 = $_POST["ijmb_sub3"];
                $IJMBgrade1 = $_POST["sub1_grade"];
                $IJMBgrade2 = $_POST["sub2_grade"];
                $IJMBgrade3 = $_POST["sub3_grade"];

                if ($IJMBsub1 == $IJMBsub2) {
                    $error2 = "IJMB subjects selection inappropriate";
                } elseif ($IJMBsub1 == $IJMBsub3) {
                    $error2 = "IJMB subjects selection inappropriate";
                } elseif ($IJMBsub2 == $IJMBsub3) {
                    $error2 = "IJMB subjects selection inappropriate";
                }

                if ($IJMBgrade1 == "A") {
                    $sub1point = 5;
                } elseif ($IJMBgrade1 == "B") {
                    $sub1point = 4;
                } elseif ($IJMBgrade1 == "C") {
                    $sub1point = 3;
                } elseif ($IJMBgrade1 == "D") {
                    $sub1point = 2;
                } elseif ($IJMBgrade1 == "E") {
                    $sub1point = 1;
                }

                if ($IJMBgrade2 == "A") {
                    $sub2point = 5;
                } elseif ($IJMBgrade2 == "B") {
                    $sub2point = 4;
                } elseif ($IJMBgrade2 == "C") {
                    $sub2point = 3;
                } elseif ($IJMBgrade2 == "D") {
                    $sub2point = 2;
                } elseif ($IJMBgrade2 == "E") {
                    $sub2point = 1;
                }

                if ($IJMBgrade3 == "A") {
                    $sub3point = 5;
                } elseif ($IJMBgrade3 == "B") {
                    $sub3point = 4;
                } elseif ($IJMBgrade3 == "C") {
                    $sub3point = 3;
                } elseif ($IJMBgrade3 == "D") {
                    $sub3point = 2;
                } elseif ($IJMBgrade3 == "E") {
                    $sub3point = 1;
                }

                $tot_point = $sub1point + $sub2point + $sub3point;
                $tot_score = round($tot_point * 26.67);
                if ($fut_IJMB == "YES") {
                    if ($tot_point < 4) {
                        $remark = "NQ";
                        $tot_score = 0;
                        $level_admt = 0;
                    }
                } else {
                    if ($tot_point < 5) {
                        $remark = "NQ";
                        $tot_score = 0;
                        $level_admt = 0;
                    }
                }



                $sql = "SELECT * FROM de_screening WHERE RegNumb = '$postJAMB'";
                $result = $conn11->query($sql);
                if ($result->num_rows > 0) {
                    $sql2 = "UPDATE de_screening set high_qual = '$highqual', nd_result = '$nd_result', hnd_result = '$hnd_result', nce_education = '$education', nce_major1 = '$major1', tot_score = '$tot_score', remark = '$remark', level_admt = '$level_admt' WHERE RegNumb = '$postJAMB'";
                    $result2 = $conn11->query($sql2);
                } else {
                    $sql2 = "INSERT INTO de_screening (RegNumb, CandName, StateOfOrigin, Sex, FUTMX_DEPT_CODE, FUTMX_SCH_CODE, nd_result, hnd_result, nce_education, nce_major1, tot_score, remark, high_qual, level_admt, user1, year1) VALUES ('$postJAMB', '$postcandname', '$poststate', '$postsex', '$postdept', '$schcode', '$nd_result', '$hnd_result', '$education', '$major1', '$tot_score', '$remark', '$highqual', '$level_admt', '$staffid', '$getyear')";
                    $result2 = $conn11->query($sql2);
                }

                $sql = "SELECT * FROM de_ijmb_subject WHERE JAMB_No = '$postJAMB'";
                $result = $conn11->query($sql);
                if ($result->num_rows > 0) {
                    $sql2 = "UPDATE de_ijmb_subject set sub1 = '$IJMBsub1', sub2 = '$IJMBsub2', sub3 = '$IJMBsub3', grade1 = '$IJMBgrade1', grade2 = '$IJMBgrade2', grade3 = '$IJMBgrade3', fut_IJMB = '$fut_IJMB' WHERE JAMB_No = '$postJAMB'";
                    $result2 = $conn11->query($sql2);
                } else {
                    $sql2 = "INSERT INTO de_ijmb_subject (JAMB_No, sub1, sub2, sub3, grade1, grade2, grade3, fut_IJMB) VALUES ('$postJAMB', '$IJMBsub1', '$IJMBsub2', '$IJMBsub3', '$IJMBgrade1', '$IJMBgrade2', '$IJMBgrade3', '$fut_IJMB')";
                    $result2 = $conn11->query($sql2);
                }
            } elseif ($highqual == "HND") {
                $nd_result = $_POST["nd_result"];
                if ($nd_result == "Distinction") {
                    $tot_score = 400;
                } elseif ($nd_result == "Upper_Credit") {
                    $tot_score = 300;
                } elseif ($nd_result == "Lower_Credit") {
                    $tot_score = 200;
                } elseif ($nd_result == "Pass") {
                    $tot_score = 0;
                    $remark = "NQ";
                    $level_admt = 0;
                }

                $highqual = "HND";
                if ($hnd_result !== "Pass") {
                    if ($nd_result == "Pass") {
                        $level_admt = 0;
                    } else {
                        $level_admt = 300;
                    }
                }
                $sql = "SELECT * FROM de_screening WHERE RegNumb = '$postJAMB'";
                $result = $conn11->query($sql);
                if ($result->num_rows > 0) {
                    $sql2 = "UPDATE de_screening set high_qual = '$highqual', nd_result = '$nd_result', hnd_result = '$hnd_result', nce_education = '$education', nce_major1 = '$major1', tot_score = '$tot_score', remark = '$remark', level_admt = '$level_admt' WHERE RegNumb = '$postJAMB'";
                    $result2 = $conn11->query($sql2);
                } else {
                    $sql2 = "INSERT INTO de_screening (RegNumb, CandName, StateOfOrigin, Sex, FUTMX_DEPT_CODE, FUTMX_SCH_CODE, nd_result, hnd_result, nce_education, nce_major1, tot_score, remark, high_qual, level_admt, user1, year1) VALUES ('$postJAMB', '$postcandname', '$poststate', '$postsex', '$postdept', '$schcode', '$nd_result', '$hnd_result', '$education', '$major1', '$tot_score', '$remark', '$highqual', '$level_admt', '$staffid', '$getyear')";
                    $result2 = $conn11->query($sql2);
                }
            } elseif ($highqual == "ND") {

                $nd_result = $_POST["nd_result"];
                if ($nd_result == "Distinction") {
                    $tot_score = 400;
                } elseif ($nd_result == "Upper_Credit") {
                    $tot_score = 300;
                } elseif ($nd_result == "Lower_Credit") {
                    $tot_score = 200;
                } elseif ($nd_result == "Pass") {
                    $tot_score = 0;
                    $remark = "NQ";
                    $level_admt = 0;
                }

                $sql = "SELECT * FROM de_screening WHERE RegNumb = '$postJAMB'";
                $result = $conn11->query($sql);
                if ($result->num_rows > 0) {
                    $sql2 = "UPDATE de_screening set high_qual = '$highqual', nd_result = '$nd_result', hnd_result = '$hnd_result', nce_education = '$education', nce_major1 = '$major1', tot_score = '$tot_score', remark = '$remark', level_admt = '$level_admt' WHERE RegNumb = '$postJAMB'";
                    $result2 = $conn11->query($sql2);
                } else {
                    $sql2 = "INSERT INTO de_screening (RegNumb, CandName, StateOfOrigin, Sex, FUTMX_DEPT_CODE, FUTMX_SCH_CODE, nd_result, hnd_result, nce_education, nce_major1, tot_score, remark, high_qual, level_admt, user1, year1) VALUES ('$postJAMB', '$postcandname', '$poststate', '$postsex', '$postdept', '$schcode', '$nd_result', '$hnd_result', '$education', '$major1', '$tot_score', '$remark', '$highqual', '$level_admt', '$staffid', '$getyear')";
                    $result2 = $conn11->query($sql2);
                }
            }
        }
    }


    ?>

    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>DE Admission Screening</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>DE Admission Screening</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            DE Admission Screening for the year <?php echo $getyear ?>
                        </div>
                        <div class="panel-body">
                            <div style="text-align: right">
                                <form class="form-horizontal" role="form" method="post"
                                    action="admission_de_screening_download.php">
                                    <button type="submit" name="submit_download" class="btn btn-info btn-sm">Download
                                        Screened Candidate</button>
                                </form>
                            </div>
                            <form class="form-horizontal" role="form" method="post" action="">
                                <div class="row">
                                    <h2 style="text-align: center; color: red"><?php echo $error1 ?></h2>
                                    <h2 style="text-align: center; color: red"><?php echo $error2 ?></h2>
                                    <?php if (isset($_POST["view"])) { ?>


                                    <!-- Content -->
                                    <input type="hidden" name="postdept" id="postdept" value="<?php echo $getdept ?>">
                                    <input type="hidden" name="poststate" id="poststate"
                                        value="<?php echo $getstate ?>">
                                    <input type="hidden" name="postsex" id="postsex" value="<?php echo $getsex ?>">



                                    <div class="col-lg-3 col-md-3">
                                        <div class="form-group">
                                            <label class="control-label col-lg-2"
                                                for="regid"><strong>Name:</strong></label>

                                            <div class="col-lg-10">
                                                <label class="control-label"><?php echo $candname ?></label>
                                                <input type="hidden" name="postcandname" id="postcandname"
                                                    value="<?php echo $candname ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-2">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="regid"><strong>JAMB
                                                    No:</strong></label>
                                            <div class="col-lg-6">
                                                <label class="control-label"><?php echo $getJAMB ?></label>
                                                <input type="hidden" name="postJAMB" id="postJAMB"
                                                    value="<?php echo $getJAMB ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-2">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5"
                                                for="regid"><strong>Department:</strong></label>
                                            <div class="col-lg-6">
                                                <label class="control-label"><?php echo $getdept ?></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="regid"><strong>State of
                                                    Origin:</strong></label>
                                            <div class="col-lg-6">
                                                <label class="control-label"><?php echo $getstate ?></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-md-2">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5"
                                                for="regid"><strong>Sex:</strong></label>
                                            <div class="col-lg-6">
                                                <label class="control-label"><?php echo $getsex ?></label>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-lg-4 col-md-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-8" for="regid"><strong>Select Highest
                                                    Qualification:</strong></label>

                                            <div class="col-lg-4">
                                                <select name="getyearAdt" id="YGradSel" class="form-control"
                                                    style="color:#000000" id="getyearAdt" required="required">
                                                    <option value=''>Select Year</option>
                                                    <option value='HND'>HND</option>
                                                    <option value='ND'>ND</option>
                                                    <option value='NCE'>NCE</option>
                                                    <option value='IJMB'>IJMB</option>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4" id="YGrad">

                                    </div>
                                    <div class="col-lg-2 col-md-2">

                                        <div class="form-group">
                                            <label class="col-lg-5 control-label"><strong>Remark:</strong></label>
                                            <div class="col-lg-7">

                                                <select name="remark" class="form-control" style="color:#000000"
                                                    id="remark" required>
                                                    <option value=""></option>
                                                    <option value="Qualified">Qualified</option>
                                                    <option value="NQ">Not Qualify</option>

                                                </select>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="col-lg-2 col-md-2">
                                        <div class="form-group">
                                            <label class="col-lg-5 control-label"></label>
                                            <div class="col-lg-7" style="text-align: right">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <hr>

                            </form>

                            <hr>
                            <div class="row">

                                <!-- <div class="col-lg-2 col-md-4">
                                        <a href="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                ?>____first.jpg"
                                            target="_blank">
                                            <img src="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                    ?>____first.jpg"
                                                alt="" height="300" width="250"
                                                style="padding-right: 1em; padding-left: 1em" />
                                        </a>
                                    </div>
                                    <div class="col-lg-2 col-md-4">
                                        <a href="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                ?>____second.jpg"
                                            target="_blank">
                                            <img src="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                    ?>____second.jpg"
                                                alt="" height="300" width="250"
                                                style="padding-right: 1em; padding-left: 1em" />
                                        </a>
                                    </div>
                                    <div class="col-lg-2 col-md-4">
                                        <a href="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                ?>____nce.jpg"
                                            target="_blank">
                                            <img src="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                    ?>____nce.jpg"
                                                alt="" height="300" width="250"
                                                style="padding-right: 1em; padding-left: 1em" />
                                        </a>
                                    </div>
                                    <div class="col-lg-2 col-md-4">
                                        <a href="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                ?>____ond.jpg"
                                            target="_blank">
                                            <img src="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                    ?>____ond.jpg"
                                                alt="" height="300" width="250"
                                                style="padding-right: 1em; padding-left: 1em" />
                                        </a>
                                    </div>
                                    <div class="col-lg-2 col-md-4">
                                        <a href="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                ?>____hnd.jpg"
                                            target="_blank">
                                            <img src="https://eportal.futminna.edu.ng/upase_screening/screen_docs/<?php //echo $getJAMB 
                                                                                                                    ?>____hnd.jpg"
                                                alt="" height="300" width="250"
                                                style="padding-right: 1em; padding-left: 1em" />
                                        </a>
                                    </div> -->



                                <div class="col-lg-2 col-md-4">
                                    <a href="Content/202290097100DF____first.jpg" target="_blank">
                                        <img src="Content/202290097100DF____first.jpg" alt="" height="300" width="250"
                                            style="padding-right: 1em; padding-left: 1em" />
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <a href="Content/202290097100DF____second.jpg" target="_blank">
                                        <img src="Content/202290097100DF____second.jpg" alt="" height="300" width="250"
                                            style="padding-right: 1em; padding-left: 1em" />
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <a href="Content/202290097100DF____nce.jpg" target="_blank">
                                        <img src="Content/202290097100DF____nce.jpg" alt="" height="300" width="250"
                                            style="padding-right: 1em; padding-left: 1em" />
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <a href="Content/202290097100DF____ond.jpg" target="_blank">
                                        <img src="Content/202290097100DF____ond.jpg" alt="" height="300" width="250"
                                            style="padding-right: 1em; padding-left: 1em" />
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4">
                                    <a href="Content/202290097100DF____hnd.jpg" target="_blank">
                                        <img src="Content/202290097100DF____hnd.jpg" alt="" height="300" width="250"
                                            style="padding-right: 1em; padding-left: 1em" />
                                    </a>
                                </div>

                                <?php } ?>
                            </div>
                            <hr>
                            <div class="col-lg-12 col-md-12">

                                <center>
                                    <h3>Candidates' List from JAMB(<?php echo $schcode ?>)</h3>
                                </center>

                                <br>
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th>S/No</th>
                                            <th>JAMB No.</th>
                                            <th>Name</th>
                                            <th>Sex</th>
                                            <th>State Origin</th>
                                            <th>Dept</th>
                                            <th>School</th>
                                            <th>High Quali</th>
                                            <th>ND Grade</th>
                                            <th>HND Grade</th>
                                            <th>NCE Edu</th>
                                            <th>NCE Major</th>
                                            <th>IJMB Subjects</th>
                                            <th>FUT IJMB</th>
                                            <th>Score</th>
                                            <th>Level Admt</th>
                                            <th>Remark</th>
                                            <?php if ($cat_Acad_Ofice == "YES" || $cat_Administrator == "YES") { ?>
                                            <th>Action</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                        $sno = 0;
                                        if ($cat_Acad_Ofice == "YES") {
                                            $sql2 = "SELECT * FROM de_screening WHERE FUTMX_SCH_CODE = '$schcode' ORDER BY CandName";
                                        } elseif ($cat_AcadSec == "YES" || $cat_Administrator == "YES") {
                                            $sql2 = "SELECT * FROM de_screening ORDER BY CandName";
                                        }
                                        $result2 = $conn11->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $HQual = $NDgrade = $HNDgrade = $NCEEdu = $NCEGS = $NCEMj = "-";
                                                $Remk = "Yet";
                                                $tot_score = 0;
                                                $MyJAMBNo = $row2["RegNumb"];
                                                $HQual = $row2["high_qual"];
                                                $NDgrade = $row2["nd_result"];
                                                $HNDgrade = $row2["hnd_result"];
                                                $NCEEdu = $row2["nce_education"];
                                                $level_admt = $row2["level_admt"];
                                                $NCEMj = $row2["nce_major1"];
                                                $Remk = $row2["remark"];
                                                $tot_score = $row2["tot_score"];

                                                $IJMB_Subjects = "-";
                                                $fut_IJMB2 = "-";
                                                if ($HQual == "IJMB") {
                                                    $sql = "SELECT * FROM de_ijmb_subject WHERE JAMB_No = '$MyJAMBNo'";
                                                    $result = $conn11->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $IJMB_Subjects = $row['sub1'] . "(" . $row['grade1'] . ")" . " " . $row['sub2'] . "(" . $row['grade2'] . ")" . " " . $row['sub3'] . "(" . $row['grade3'] . ")";
                                                            $fut_IJMB2 = $row['fut_IJMB'];
                                                        }
                                                    }
                                                }
                                                $sql = "SELECT * FROM fchoice_" . $getyear . " WHERE RegNumb = '$MyJAMBNo'";
                                                $result = $conn11->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        echo "<tr><td>$sno</td><td>{$row['RegNumb']}</td><td>{$row['CandName']}</td><td>{$row['Sex']}</td><td>{$row['StateOfOrigin']}</td><td>{$row['FUTMX_DEPT_CODE']}</td><td>{$row['FUTMX_SCH_CODE']}</td><td>$HQual</td><td>$NDgrade</td><td>$HNDgrade</td><td>$NCEEdu</td><td>$NCEMj</td><td>$IJMB_Subjects</td><td>$fut_IJMB2</td><td>$tot_score</td><td>$level_admt</td><td>$Remk</td>";

                                                        if ($cat_Acad_Ofice == "YES" || $cat_Administrator == "YES") {
                                                            echo "<form action='' method='post'><td>
                                                          <input type='hidden' value=$MyJAMBNo name='id'>
                                                          <input type='submit' name = 'view' class='btn btn-primary btn-xs' value='View'>
                                                          
                                                         </td>
                                                      
                                                        </form>";
                                                        }
                                                        echo "</tr>\n";
                                                    }
                                                }
                                            }
                                        }

                                        $HQual = $NDgrade = $HNDgrade = $NCEEdu = $NCEGS = $NCEMj = "-";
                                        $Remk = "Yet";
                                        $tot_score = 0;

                                        if ($cat_Acad_Ofice == "YES") {
                                            /*if($getyear < 2020){
                                            $sql = "SELECT * FROM de_".$getyear." WHERE FUTMX_SCH_CODE = '$schcode' ORDER BY CandName";
                                        }else{
                                            $sql = "SELECT * FROM fchoice_".$getyear." WHERE FUTMX_SCH_CODE = '$schcode' AND MODE = 'DE' ORDER BY CandName";
                                        }*/
                                            $sql = "SELECT * FROM fchoice_" . $getyear . " WHERE FUTMX_SCH_CODE = '$schcode' AND MODE = 'DE' ORDER BY CandName";
                                        } elseif ($cat_AcadSec == "YES" || $cat_Administrator == "YES") {
                                            /*if($getyear < 2020){
                                            $sql = "SELECT * FROM de_".$getyear." ORDER BY CandName";
                                        }else{
                                            $sql = "SELECT * FROM fchoice_".$getyear." WHERE MODE = 'DE' ORDER BY CandName";
                                        }*/
                                            $sql = "SELECT * FROM fchoice_" . $getyear . " WHERE MODE = 'DE' ORDER BY CandName";
                                        }

                                        //$sno=0;
                                        $result = $conn11->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {


                                                $id = $row['RegNumb'];

                                                $sql2 = "SELECT * FROM de_screening WHERE RegNumb = '$id'";
                                                $result2 = $conn11->query($sql2);
                                                if ($result2->num_rows == 0) {
                                                    $sno++;
                                                    /*if($getyear < 2020){
                                                    echo "<tr><td>$sno</td><td>{$row['RegNumb']}</td><td>{$row['CandName']}</td><td>{$row['Sex']}</td><td>{$row['StateOfOrigin']}</td><td></td><td>{$row['FUTMX_SCH_CODE']}</td><td>$HQual</td><td>$NDgrade</td><td>$HNDgrade</td><td>$NCEEdu</td><td>$NCEMj</td><td>-</td><td>-</td><td>$tot_score</td><td>0</td><td>$Remk</td>";
                                                }else{
                                                    echo "<tr><td>$sno</td><td>{$row['RegNumb']}</td><td>{$row['CandName']}</td><td>{$row['Sex']}</td><td>{$row['StateOfOrigin']}</td><td>{$row['FUTMX_DEPT_CODE']}</td><td>{$row['FUTMX_SCH_CODE']}</td><td>$HQual</td><td>$NDgrade</td><td>$HNDgrade</td><td>$NCEEdu</td><td>$NCEMj</td><td>-</td><td>-</td><td>$tot_score</td><td>0</td><td>$Remk</td>";
                                                }*/

                                                    echo "<tr><td>$sno</td><td>{$row['RegNumb']}</td><td>{$row['CandName']}</td><td>{$row['Sex']}</td><td>{$row['StateOfOrigin']}</td><td>{$row['FUTMX_DEPT_CODE']}</td><td>{$row['FUTMX_SCH_CODE']}</td><td>$HQual</td><td>$NDgrade</td><td>$HNDgrade</td><td>$NCEEdu</td><td>$NCEMj</td><td>-</td><td>-</td><td>$tot_score</td><td>0</td><td>$Remk</td>";
                                                    if ($cat_Acad_Ofice == "YES" || $cat_Administrator == "YES") {
                                                        echo "<form action='' method='post'><td>
                                                      <input type='hidden' value=$id name='id'>
                                                      <input type='submit' name = 'view' class='btn btn-primary btn-xs' value='View'>
                                                      
                                                     </td>
                                                      
                                                    </form>";
                                                    }
                                                    echo "</tr>\n";
                                                }
                                            }
                                        }


                                        ?>

                                    </tbody>
                                </table>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <script>
    $(document).ready(function() {
        $('#YGradSel').on('change', function() {
            var SelID = $(this).val();
            if (SelID) {
                $.ajax({
                    type: 'POST',
                    url: 'ajax_save_rec/ajaxData_DE_screan.php',
                    data: 'sel_id=' + SelID,
                    success: function(html) {
                        $('#YGrad').html(html);

                    }
                });
            } else {

            }
        });


    });
    </script>
</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';


?>


<!doctype html>
<html class="fixed">

<head>

	<?php include_once 'includes/header_top.php'; ?>
	<link href="css/animate.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">



	<!--To Prevent Backward-->
	<script type="text/javascript">
		window.history.forward();

		function noBack() {
			window.history.forward();
		}
	</script>
	<?php
	$autologoutURL = "";
	include_once 'includes/autologout_stu.php';
	?>
</head>


<body>
	<?php $stutype = $_SESSION['stutype']; ?>
	<div id="wrapper">
		<nav class="navbar-default navbar-static-side" role="navigation">
			<?php include_once 'includes/aside_menu.php'; ?>
		</nav>

		<div id="page-wrapper" class="gray-bg">
			<div class="row border-bottom">
				<nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
					<?php include_once 'includes/header2.php'; ?>
				</nav>
			</div>
			<div class="wrapper wrapper-content">


				<div class="row wrapper border-bottom white-bg page-heading">
					<div class="col-lg-10">
						<h2>Lecture Timetable</h2>
						<ol class="breadcrumb">
							<li>
								<a href="home_stu.php">Home</a>
							</li>
							<li class="active">
								<strong>Lecture Timetable</strong>
							</li>
						</ol>


					</div>
					<div class="col-lg-2">

					</div>
				</div>

				<div class="wrapper wrapper-content animated fadeInRight">

					<div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
						<div class="panel-heading">
							Lecture Timetable
						</div>
						<div class="panel-body">

							<div class="col-md-1">
							</div>
							<div class="col-md-10">

								<?php
								$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
								if ($conn->connect_error) {
									die("Connection failed: " . $conn->connect_error);
								}

								$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
								if ($conn2->connect_error) {
									die("Connection failed: " . $conn2->connect_error);
								}

								$conn5 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE5);
								if ($conn5->connect_error) {
									die("Connection failed: " . $conn5->connect_error);
								}
								?>
								<div class="panel panel-default">
									<div class="panel-heading">
										Lecture Timetable
									</div>
									<div class="panel-body">
										<form class="form-horizontal form-bordered" method="post">
											<table class="table mb-none">
												<thead>
													<tr>
														<th>Day</th>
														<th>8:00AM</th>
														<th>9:00AM</th>
														<th>10:00AM</th>
														<th>11:00AM</th>
														<th>12:00PM</th>
														<th>1:00PM</th>
														<th>2:00PM</th>
														<th>3:00PM</th>
														<th>4:00PM</th>
														<th>5:00PM</th>
														<th>6:00PM</th>

													</tr>
												</thead>
												<?php
												$x = 0;
												$ccodearry2[] = "";
												$ccurriarry2[] = "";
												$corntsession2 = str_replace("/", "_", $corntsession);
												$sql2 = "SELECT * FROM courses_register_" . $corntsession2 . " WHERE Regn1 = '$regid' AND SemTaken = '$cursemester'";
												$result2 = $conn->query($sql2);
												if ($result2->num_rows > 0) {
													while ($row2 = $result2->fetch_assoc()) {
														$ccodearry2[$x] = $row2['CCode'];
														$ccurriarry2[$x] = $row2['Nature'];
														$x++;
													}
												}
												?>
												<tbody>
													<?php if ($getday == "M") { ?>
														<tr style=" background-color: <?php echo $_SESSION['sch_color'] ?> color: #ffffff">
														<?php } else { ?>
														<tr>
														<?php } ?>

														<th>Mon</th>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '8AM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '9AM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '10AM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '11AM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '12PM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '1PM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '2PM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '3PM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '4PM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '5PM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>
														<td style="font-size:12px">
															<?php

															for ($i = 0; $i < $x; $i++) {
																$CCode = $ccodearry2[$i];
																$curri = $ccurriarry2[$i];
																$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND M = '6PM'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		echo $CCode . " (" . $row["MHr"] . "hr(s))";
																	}
																}
															}

															?>
														</td>

														</tr>
														<?php if ($getday == "T") { ?>
															<tr style=" background-color: <?php echo $_SESSION['sch_color'] ?> color: #ffffff">
															<?php } else { ?>
															<tr>
															<?php } ?>
															<th>Tue</th>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '8AM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '9AM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '10AM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '11AM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '12PM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '1PM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '2PM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '3PM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '4PM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '5PM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>
															<td style="font-size:12px">
																<?php

																for ($i = 0; $i < $x; $i++) {
																	$CCode = $ccodearry2[$i];
																	$curri = $ccurriarry2[$i];
																	$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND T = '6PM'";
																	$result = $conn->query($sql);
																	if ($result->num_rows > 0) {
																		while ($row = $result->fetch_assoc()) {
																			echo $CCode . " (" . $row["THr"] . "hr(s))";
																		}
																	}
																}

																?>
															</td>

															</tr>
															<?php if ($getday == "W") { ?>
																<tr style=" background-color: <?php echo $_SESSION['sch_color'] ?> color: #ffffff">
																<?php } else { ?>
																<tr>
																<?php } ?>
																<th>Wed</th>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '8AM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '9AM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '10AM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '11AM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '12PM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '1PM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '2PM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '3PM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '4PM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '5PM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>
																<td style="font-size:12px">
																	<?php

																	for ($i = 0; $i < $x; $i++) {
																		$CCode = $ccodearry2[$i];
																		$curri = $ccurriarry2[$i];
																		$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND W = '6PM'";
																		$result = $conn->query($sql);
																		if ($result->num_rows > 0) {
																			while ($row = $result->fetch_assoc()) {
																				echo $CCode . " (" . $row["WHr"] . "hr(s))";
																			}
																		}
																	}

																	?>
																</td>

																</tr>
																<?php if ($getday == "Th") { ?>
																	<tr style=" background-color: <?php echo $_SESSION['sch_color'] ?> color: #ffffff">
																	<?php } else { ?>
																	<tr>
																	<?php } ?>
																	<th>Thur</th>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '8AM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '9AM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '10AM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '11AM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '12PM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '1PM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '2PM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '3PM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '4PM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '5PM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>
																	<td style="font-size:12px">
																		<?php

																		for ($i = 0; $i < $x; $i++) {
																			$CCode = $ccodearry2[$i];
																			$curri = $ccurriarry2[$i];
																			$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND Th = '6PM'";
																			$result = $conn->query($sql);
																			if ($result->num_rows > 0) {
																				while ($row = $result->fetch_assoc()) {
																					echo $CCode . " (" . $row["ThHr"] . "hr(s))";
																				}
																			}
																		}

																		?>
																	</td>

																	</tr>
																	<?php if ($getday == "F") { ?>
																		<tr style=" background-color: <?php echo $_SESSION['sch_color'] ?> color: #ffffff">
																		<?php } else { ?>
																		<tr>
																		<?php } ?>
																		<th>Fri</th>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '8AM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '9AM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '10AM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '11AM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '12PM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '1PM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '2PM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '3PM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '4PM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '5PM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>
																		<td style="font-size:12px">
																			<?php

																			for ($i = 0; $i < $x; $i++) {
																				$CCode = $ccodearry2[$i];
																				$curri = $ccurriarry2[$i];
																				$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND F = '6PM'";
																				$result = $conn->query($sql);
																				if ($result->num_rows > 0) {
																					while ($row = $result->fetch_assoc()) {
																						echo $CCode . " (" . $row["FHr"] . "hr(s))";
																					}
																				}
																			}

																			?>
																		</td>

																		</tr>
																		<?php if ($getday == "S") { ?>
																			<tr style=" background-color: <?php echo $_SESSION['sch_color'] ?> color: #ffffff">
																			<?php } else { ?>
																			<tr>
																			<?php } ?>
																			<th>Sat</th>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '8AM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '9AM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '10AM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '11AM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '12PM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '1PM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '2PM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '3PM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '4PM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '5PM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>
																			<td style="font-size:12px">
																				<?php

																				for ($i = 0; $i < $x; $i++) {
																					$CCode = $ccodearry2[$i];
																					$curri = $ccurriarry2[$i];
																					$sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri' AND S = '6PM'";
																					$result = $conn->query($sql);
																					if ($result->num_rows > 0) {
																						while ($row = $result->fetch_assoc()) {
																							echo $CCode . " (" . $row["SHr"] . "hr(s))";
																						}
																					}
																				}

																				?>
																			</td>

																			</tr>
												</tbody>
											</table>

										</form>
									</div>
								</div>

								<br>
								<div class="panel panel-default">
									<div class="panel-heading">
										Details
									</div>
									<div class="panel-body">
										<form class="form-horizontal form-bordered" method="post">
											<table class="table mb-none">
												<thead>
													<tr>
														<th>Courses</th>
														<th>Venue</th>
														<th>Lecturer(s)</th>
													</tr>
												</thead>
												<tbody>
													<?php
													for ($i = 0; $i < $x; $i++) {
														$staffdetail = "";
														$venue = "";
														$CCode = $ccodearry2[$i];
														$curri = $ccurriarry2[$i];
														$sql3 = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri'";
														$result3 = $conn->query($sql3);
														if ($result3->num_rows > 0) {
															while ($row3 = $result3->fetch_assoc()) {
																$venue = $row3["venue"];
																$fileno = $staname = $phone = $email = "";
																$sql = "Select * from coursealocation WHERE CCode = '$CCode' AND SessionReg = '$corntsession'";
																$result = $conn->query($sql);
																if ($result->num_rows > 0) {
																	while ($row = $result->fetch_assoc()) {
																		$fileno = $row["PFNo"];
																		$sql2 = "Select * from users WHERE staffid = '$fileno'";
																		if ($stutype == "UG") {
																			$result2 = $conn->query($sql2);
																		} else {
																			$result2 = $conn5->query($sql2);
																		}

																		if ($result2->num_rows > 0) {
																			while ($row2 = $result2->fetch_assoc()) {
																				$staname = $row2["full_name"];
																				$phone = $row2["phone"];
																				$email = $row2["emailAdd"];
																				$staffdept = strtoupper($row2["staffacddept"]);
																				$officeadd = $row2["office_address"];
																			}
																		}

																		$sql2 = "Select * from deptcoding WHERE DeptCode = '$staffdept'";
																		$result2 = $conn->query($sql2);
																		if ($result2->num_rows > 0) {
																			while ($row2 = $result2->fetch_assoc()) {
																				$staffdept2 = $row2["DeptName"];
																			}
																		}
																		$staffdetail = $staffdetail . "<strong>Staff Name: " . $staname . "</strong><br> Department of " . $staffdept2 . "<br> Contact No/email: " . $phone . "<br> email: " . $email . "<br> Office: " . $officeadd . "<br><br>";
																	}
																}
															}
														}
														echo "<tr><td>$CCode</td><td>$venue</td><td>$staffdetail</td></tr>";
													}
													?>
												</tbody>
											</table>
										</form>
									</div>
								</div>
								<?php
								$conn->close();
								$conn2->close();
								$conn5->close();
								?>
							</div>
							<div class="col-md-1">
							</div>

						</div>
					</div>



				</div>
			</div>

			<div class="footer">
				<?php
				include_once 'includes/footer2.php';
				?>
			</div>
		</div>
		<div id="right-sidebar">

			<?php
			include_once 'includes/aside_right.php';
			?>

		</div>

	</div>

	<?php
	include_once 'includes/footer.php';
	?>


</body>

</html>
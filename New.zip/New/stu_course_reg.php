<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';


$regid = $_SESSION['regid'];
$corntsession = $_SESSION['corntsession'];

    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }

$sql = "SELECT * FROM std_data_payment WHERE Matriculation_no = '$regid' AND session = '$corntsession' AND (payment_cat = 'registration' OR payment_cat = 'registration_dce') AND (pay_or_skip LIKE 'pay' OR pay_or_skip LIKE 'skip')";
$result = $conn2->query($sql);

if ($result->num_rows == 0) {
    header('Location: home_stu.php');
}
$conn2->close();

$regid = $_SESSION["regid"];
$dept = $_SESSION['deptcode'];
$corntsession = $_SESSION['corntsession'];
$engrrep100level = $_SESSION['engrrep100level'];
$modeofentry = $_SESSION['modeofentry'];

if ($regid !== "CIV/21U/2898") {
    header('Location: home_stu.php');
}

/* //$sql = "SELECT * FROM stdprofile WHERE stdid = '$stdid' AND getme = 'YES'";
//$result = $conn2->query($sql);
//if ($result->num_rows == 0) {
$sql2 = "SELECT * FROM setting WHERE CourseREg = 'Closed'";
$result2 = $conn->query($sql2);
if ($result2->num_rows > 0) {
    header('Location:home_stu.php');
}

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$sql2 = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate'";
$result2 = $conn_stu->query($sql2);
if ($result2->num_rows > 0) {
    header('Location:home_stu.php');
}
//} */





$_SESSION['noresult'] = "NO";
$tot1outunit = $tot2outunit = 0;
include_once 'includes/get_stu_level.php';
require 'includes/reginclude1.php';
?>




<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Check All checkbox-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        var $selectAll = $('#selectAll1'); // main checkbox inside table thead
        var $table = $('.tablechk1'); // table selector 
        var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
        var tdCheckboxChecked = 0; // checked checboxes

        // Select or deselect all checkboxes depending on main checkbox change
        $selectAll.on('click', function() {
            $tdCheckbox.prop('checked', this.checked);
        });

        // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
        $tdCheckbox.on('change', function(e) {
            tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                .length; // Get count of checkboxes that is checked
            // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
            $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
        })
    });
    </script>
    <script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        var $selectAll = $('#selectAll2'); // main checkbox inside table thead
        var $table = $('.tablechk2'); // table selector 
        var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
        var tdCheckboxChecked = 0; // checked checboxes

        // Select or deselect all checkboxes depending on main checkbox change
        $selectAll.on('click', function() {
            $tdCheckbox.prop('checked', this.checked);
        });

        // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
        $tdCheckbox.on('change', function(e) {
            tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                .length; // Get count of checkboxes that is checked
            // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
            $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
        })
    });
    </script>
    <script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        var $selectAll = $('#selectAll3'); // main checkbox inside table thead
        var $table = $('.tablechk3'); // table selector 
        var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
        var tdCheckboxChecked = 0; // checked checboxes

        // Select or deselect all checkboxes depending on main checkbox change
        $selectAll.on('click', function() {
            $tdCheckbox.prop('checked', this.checked);
        });

        // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
        $tdCheckbox.on('change', function(e) {
            tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                .length; // Get count of checkboxes that is checked
            // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
            $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
        })
    });
    </script>
    <script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        var $selectAll = $('#selectAll4'); // main checkbox inside table thead
        var $table = $('.tablechk4'); // table selector 
        var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
        var tdCheckboxChecked = 0; // checked checboxes

        // Select or deselect all checkboxes depending on main checkbox change
        $selectAll.on('click', function() {
            $tdCheckbox.prop('checked', this.checked);
        });

        // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
        $tdCheckbox.on('change', function(e) {
            tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                .length; // Get count of checkboxes that is checked
            // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
            $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
        })
    });
    </script>


    <!--To Prevent Backward-->
    <!--
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    -->
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>

</head>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Course Registration</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_stu.php">Home</a>
                        </li>
                        <li>
                            Course Registration
                        </li>

                        <li class="active">
                            <strong>Course Registration(Current)</strong>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper wrapper-content animated fadeInUp">

                        <div class="ibox">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10 panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                                <div class="panel-heading">
                                    <h5>Course Registration for <?php echo $_SESSION['corntsession'] ?>
                                        Session</h5>

                                </div>
                                <div class="panel-body">
                                    <form class="form-horizontal" method="post" action="stu_course_reg_preview.php">
                                        <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        // sql to delete a record
                                        $sql = "DELETE FROM coursesregis WHERE Regn1 ='$regid'";
                                        $result = $conn_stu->query($sql);

                                        $sql = "SELECT * FROM diff_outs_courses WHERE regn1 = '$regid' AND SemTaken = '1ST'";
                                        $result = $conn_stu->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                        ?>
                                        <h4>
                                            <center>Outstanding 1ST Semester Courses</center>
                                        </h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <?php
                                                        if ($tot1outunit > 24) {
                                                            echo "<th>Select</th>";
                                                        }
                                                        ?>

                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["sn"];
                                                        $ccode = $row["CCode"];
                                                        $CTitle = $row["CTitle"];
                                                        $CUnit = $row["CUnit"];
                                                        $SemTaken = $row["SemTaken"];
                                                        $Nature = "Core";

                                                        if ($tot1outunit > 24) {
                                                            echo "<tr>
														<td><input type='checkbox' name='chosen1c[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccodec1' name='ccodec1[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccodec1' name='ccodec1[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitlec1' name='CTitlec1[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitlec1' name='CTitlec1[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnitc1' name='CUnitc1[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnitc1' name='CUnitc1[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTakenc1' name='SemTakenc1[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTakenc1' name='SemTakenc1[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														<td hidden='hidden'>
														<label id='Naturec1' name='Naturec1[" . $id . "]'>$Nature</label>
														<input type='hidden' id='Naturec1' name='Naturec1[" . $id . "]' value='" . $Nature . "'/>
														</td>
														
														</tr>\n";
                                                        } else {
                                                            echo "<tr>
														<td hidden='hidden'><input type='checkbox' checked='checked' name='chosen1c[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccodec1' name='ccodec1[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccodec1' name='ccodec1[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitlec1' name='CTitlec1[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitlec1' name='CTitlec1[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnitc1' name='CUnitc1[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnitc1' name='CUnitc1[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTakenc1' name='SemTakenc1[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTakenc1' name='SemTakenc1[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														<td hidden='hidden'>
														<label id='Naturec1' name='Naturec1[" . $id . "]'>$Nature</label>
														<input type='hidden' id='Naturec1' name='Naturec1[" . $id . "]' value='" . $Nature . "'/>
														</td>
														
														</tr>\n";
                                                        }
                                                    }
                                                    ?>

                                            </tbody>
                                        </table>

                                        <?php

                                        }
                                        if ($tot1outunit <> 0) {
                                            echo "<center> Total Credit Units : $tot1outunit</center>";
                                        }
                                        ?>

                                        <br /><br />
                                        <?php
                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $siwes = $row["siwes"];
                                                $siwes_level = $row["siwes_level"];
                                                $siwes_unit = $row["siwes_unit"];
                                                $siwes_semester = $row["siwes_semester"];
                                            }
                                        }
                                        ?>
                                        <?php if ($level == $siwes_level && $_SESSION['InstType'] == "University") { ?>

                                        <?php } else { ?>
                                        <?php
                                            $sql = "SELECT * FROM diff_outs_courses WHERE regn1 = '$regid' AND SemTaken = '2ND'";
                                            $result = $conn_stu->query($sql);

                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                            ?>
                                        <h4>
                                            <center> Outstanding 2ND Semester Courses</center>
                                        </h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <?php
                                                            if ($tot2outunit > 24) {
                                                                echo "<th>Select</th>";
                                                            }
                                                            ?>

                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                        while ($row = $result->fetch_assoc()) {

                                                            $id = $row["sn"];
                                                            $ccode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $Nature = "Core";

                                                            if ($tot2outunit > 24) {
                                                                echo "<tr>
														<td><input type='checkbox' name='chosen2c[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccodec2' name='ccodec2[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccodec2' name='ccodec2[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitlec2' name='CTitlec2[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitlec2' name='CTitlec2[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnitc2' name='CUnitc2[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnitc2' name='CUnitc2[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTakenc2' name='SemTakenc2[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTakenc2' name='SemTakenc2[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														<td hidden='hidden'>
														<label id='Naturec2' name='Naturec2[" . $id . "]'>$Nature</label>
														<input type='hidden' id='Naturec2' name='Naturec2[" . $id . "]' value='" . $Nature . "'/>
														</td>
														
														</tr>\n";
                                                            } else {
                                                                echo "<tr>
														<td hidden='hidden'><input type='checkbox' checked='checked' name='chosen2c[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccodec2' name='ccodec2[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccodec2' name='ccodec2[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitlec2' name='CTitlec2[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitlec2' name='CTitlec2[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnitc2' name='CUnitc2[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnitc2' name='CUnitc2[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTakenc2' name='SemTakenc2[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTakenc2' name='SemTakenc2[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														<td hidden='hidden'>
														<label id='Naturec2' name='Naturec2[" . $id . "]'>$Nature</label>
														<input type='hidden' id='Naturec2' name='Naturec2[" . $id . "]' value='" . $Nature . "'/>
														</td>
														
														</tr>\n";
                                                            }
                                                        }
                                                        ?>
                                            </tbody>
                                        </table>

                                        <?php

                                            }
                                            $conn->close();
                                            $conn_stu->close();
                                            ?>

                                        <?php } ?>

                                        <?php
                                        if ($tot2outunit <> 0) {
                                            echo "<center> Total Credit Units : $tot2outunit</center>";
                                        }
                                        //echo $level;
                                        ?>
                                        <?php
                                        if ($engrrep100level == "YES" && $level == "200") {
                                            include_once 'includes/getnewcourse_toreg_eng_rept.php';
                                        } else {
                                            /* if ($_SESSION['InstType'] == "University") {
                                                include_once 'includes/getnewcourse_toreg.php';
                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                if ($modeofentry == "ND") {
                                                    if ($level <= 400) {
                                                        include_once 'includes/getnewcourse_toreg.php';
                                                    }
                                                } else {
                                                    if ($level <= 600) {
                                                        include_once 'includes/getnewcourse_toreg.php';
                                                    }
                                                }
                                            } */
                                            include_once 'includes/getnewcourse_toreg.php';
                                        }

                                        ?>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <?php if ($engrrep100level == "YES" && $level == "200") { ?>
                                                <?php } else { ?>
                                                <a class="" href="addcoursesreg.php"><span>Add Courses from other
                                                        Dept</span></a>
                                                <?php } ?>
                                            </div>
                                            <div class="col-lg-6" style="text-align:right; padding-right:2em">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Preview</button>
                                            </div>
                                        </div>


                                        <br /><br />

                                        <br /><br />
                                    </form>
                                    <br /><br />
                                </div>
                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

</body>

</html>
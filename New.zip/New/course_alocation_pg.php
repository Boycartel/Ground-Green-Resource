<?php
require_once 'includes/db_connect.php';

require_once 'includes/check_validity.php';

if ($_SESSION['course_alocation'] == false) {
    header('Location: Home_Staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--To Delete
		<link href='delete_res/bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>-->
    <script src='delete_res/jquery-3.3.1.js' type='text/javascript'> </script>
    <script src='delete_res/bootstrap/js/bootstrap.min.js'> </script>
    <script src='delete_res/bootbox.min.js'> </script>

    <!-- End To Delete -->

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Allocation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Allocation</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Allocation
                        </div>
                        <div class="panel-body">
                            <div>
                                <?php

                                $curtsession = $_SESSION['corntsession'];
                                $dept = $_SESSION['deptcode'];

                                $inserted = "";
                                if (isset($_POST["submit"])) {
                                    $staffid = $_POST["getstaffid"];

                                    if (!empty($_POST["chosen"])) {
                                        foreach ($_POST["chosen"] as $key => $value) {

                                            //echo $_POST["chosen"][$key];


                                            $ccode = $_POST["ccode"][$key];
                                            $CTitle = str_replace("'", "''", $_POST["CTitle"][$key]);
                                            $CUnit = $_POST["CUnit"][$key];
                                            $SemTaken = $_POST["SemTaken"][$key];

                                            $sql = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND CCode = '$ccode' AND SessionReg = '$curtsession'";
                                            $result = $conn5->query($sql);

                                            if ($result->num_rows > 0) {
                                            } else {
                                                // sql to insert record
                                                $sql = "INSERT INTO coursealocation (PFNo, CCode, CTitle, CUnit, Semester, SessionReg, Department) VALUES ('$staffid', '$ccode', '$CTitle', '$CUnit', '$SemTaken', '$curtsession', '$dept')";
                                                $result = $conn5->query($sql);
                                            }
                                        }
                                        $inserted = "Record Inserted";
                                    }
                                }
                                ?>




                                <div class="row" style="color:#000">

                                    <div class="col-lg-5 col-md-5">
                                        <h4>
                                            <center>Current Session: <?php echo $curtsession ?></center>
                                        </h4>
                                        <form class="form-horizontal" method="post">
                                            <div class="form-group">
                                                <label class="control-label col-lg-4" for="regid">Select
                                                    Status:</label>
                                                <div class="col-lg-6">
                                                    <select name="staffcat" class="country form-control"
                                                        style="color:#000000" id="staffcat">
                                                        <option value=SelectItem>Select Item</option>
                                                        <option value=deptstaff>Departmental Staff</option>
                                                        <option value=outstaff>Outside Department</option>
                                                    </select>

                                                </div>
                                                <div class="col-lg-2">
                                                    <button type="submit" name="liststatus"
                                                        class="btn btn-primary btn-sm">OK</button>
                                                </div>
                                            </div>

                                            <?php
                                            if (isset($_POST["liststatus"])) {

                                                // Capture selected country
                                                $catstaff = $_POST["staffcat"];
                                                $dept = $_SESSION['deptcode'];

                                            ?>

                                            <div class="form-group">
                                                <label class="control-label col-lg-6" for="regid">Select Course
                                                    Lecturer:</label>
                                                <div class="col-lg-6">
                                                    <div class="form-group">



                                                        <select name="getstaffid" class="form-control"
                                                            style="color:#000000" id="getstaffid">
                                                            <?php
                                                                if ($catstaff == "deptstaff")
                                                                    $sql = "SELECT * FROM users WHERE staffacddept = '$dept' ORDER BY staffid";
                                                                elseif ($catstaff == "outstaff")
                                                                    $sql = "SELECT * FROM users ORDER BY staffid";

                                                                $result = $conn->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $staffid = $row["staffid"];
                                                                        $staffname = $row["full_name"];
                                                                ?>
                                                            <option value=<?php echo $staffid ?>>
                                                                <?php echo $staffid . " " . $staffname ?>
                                                            </option>
                                                            <?php

                                                                    }
                                                                }

                                                                ?>
                                                        </select>



                                                    </div>

                                                </div>
                                            </div>
                                            <?php
                                            }
                                            ?>

                                            <br />
                                            <?php

                                            echo "<center><h4 style='color:#009'>$inserted</h4></center>";
                                            $sql = "SELECT * FROM gencoursesupload WHERE Department = '$dept' ORDER BY C_codding";
                                            $result = $conn5->query($sql);

                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                            ?>

                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>

                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["id"];
                                                            $ccode = $row["C_codding"];
                                                            $CTitle = $row["C_title"];
                                                            $CUnit = $row["credit"];
                                                            $SemTaken = $row["semester"];

                                                            echo "<tr>
														<td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccode' name='ccode[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccode' name='ccode[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitle' name='CTitle[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitle' name='CTitle[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnit' name='CUnit[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnit' name='CUnit[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTaken' name='SemTaken[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTaken' name='SemTaken[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														
														</tr>\n";
                                                        }
                                                        ?>
                                                </tbody>
                                            </table>

                                            <?php

                                            }
                                            ?>
                                            <br /><br />
                                            <div class="row" style="text-align:right">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                            <br /><br />
                                        </form>
                                    </div>
                                    <div class="col-lg-2 col-md-2">

                                    </div>
                                    <div class="col-lg-5 col-md-5">
                                        <center>
                                            <h4>Edit Course Allocation</h4>
                                        </center>
                                        <center>
                                            <h4> <?php echo $curtsession . " " ?>Session</h4>
                                        </center>
                                        <br>
                                        <?php
                                        $deleted = "";
                                        //if(isset($_POST["remove"])){

                                        //}

                                        echo "<center><h3 style='color:#009'>$deleted</h3></center>";
                                        $sql = "SELECT * FROM coursealocation WHERE SessionReg = '$curtsession' AND Department = '$dept' ORDER BY ccode";
                                        $result = $conn5->query($sql);

                                        if ($result->num_rows > 0) {

                                        ?>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th>PF No.</th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["sn"];

                                                        echo "<tr><td>{$row['PFNo']}</td><td>{$row['CCode']}</td><td>{$row['CTitle']}</td>
														<td>
														 
															<button class='delete_course btn btn-danger btn-xs' id='del_.$id' data-id='$id'>Remove</button>
														</td></tr>\n";
                                                    }
                                                    ?>
                                            </tbody>
                                        </table>

                                        <?php

                                        }
                                        //$conn->close();
                                        ?>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
    $(document).ready(function() {

        // Delete 
        $('.delete_course').click(function() {
            var el = this;

            // Delete id
            var deleteid = $(this).data('id');

            // Confirm box
            bootbox.confirm("Do you really want to delete record?", function(result) {

                if (result) {
                    // AJAX Request
                    $.ajax({
                        url: 'delete_res/delete_coures_alocat_pg.php',
                        type: 'POST',
                        data: {
                            id: deleteid
                        },
                        success: function(response) {

                            // Removing row from HTML Table
                            if (response == 1) {
                                $(el).closest('tr').css('background', 'tomato');
                                $(el).closest('tr').fadeOut(800, function() {
                                    $(this).remove();
                                });
                            } else {
                                bootbox.alert('Record not deleted.');
                            }

                        }
                    });
                }

            });

        });

    });
    </script>

</body>

</html>
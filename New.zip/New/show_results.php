<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">


</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Enable Results for Students</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Settings
                            </li>

                            <li class="active">
                                <strong>Enable Results for Students</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Enable Results for Students
                        </div>
                        <div class="panel-body">
                            <!-- start: page -->
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $success = "";
                            $sql = "SELECT * FROM sessions WHERE getkey = 'key1'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $reg_session = $row["session_title"];
                                    $reg_semester = $row["semester"];
                                    $results_session = $row["result_session"];
                                    $results_semester = $row["result_semester"];
                                    $stu_results = $row["stu_results"];
                                }
                            }

                            if (isset($_POST["submit"])) {

                                $sql = "SELECT * FROM sessions WHERE getkey = 'key1'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $stu_results = $row["stu_results"];
                                    }
                                }

                                if ($stu_results == "Enable") {
                                    $getStatus = "Disable";
                                } else {
                                    $getStatus = "Enable";
                                }

                                $sql = "UPDATE sessions SET stu_results = '$getStatus' WHERE getkey = 'key1'";
                                $result = $conn->query($sql);
                            }

                            $sql = "SELECT * FROM sessions WHERE getkey = 'key1'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $stu_results = $row["stu_results"];
                                }
                            }

                            if ($stu_results == "Enable") {
                                $getStatus = "Disable";
                            } else {
                                $getStatus = "Enable";
                            }
                            ?>
                            <div class="row">

                                <h2 style="color: blue; text-align: center"><?php echo $success ?></h2>
                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="row">
                                        <div class="col-lg-2">

                                        </div>
                                        <div class="col-lg-8">
                                            <h2 style="text-align: center;">Students Results Status</h2>
                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Session</th>
                                                        <th>Semester</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td><?php echo $results_session ?> </td>
                                                        <td><?php echo $results_semester ?> </td>
                                                        <?php if ($getStatus == "Enable") { ?>
                                                            <td class="client-status"><span class="label label-danger"><?php echo $stu_results ?></span>
                                                            </td>
                                                            <td>
                                                                <input type='submit' name="submit" class='btn btn-info btn-sm' value='<?php echo $getStatus ?>'>
                                                            </td>
                                                        <?php } else { ?>
                                                            <td class="client-status"><span class="label label-info"><?php echo $stu_results ?></span>
                                                            </td>
                                                            <td>
                                                                <input type='submit' name="submit" class='btn btn-danger btn-sm' value='<?php echo $getStatus ?>'>
                                                            </td>
                                                        <?php } ?>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-2">

                                        </div>

                                    </div>

                                </form>
                            </div>
                            <?php
                            $conn->close();
                            ?>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
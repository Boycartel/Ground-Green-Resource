<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/select2/select2.css" />
    <link rel="stylesheet" href="assets/vendor/jquery-datatables-bs3/assets/css/datatables.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <script src="inline_edit/jquery.min.js"></script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">


        <!-- end: header -->

        <div class="inner-wrapper">

            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header">
                    <h2>Sport</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-file"></i>
                                </a>
                            </li>
                            <li><span>Sport</span></li>

                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">
                    <form class="form-horizontal form-bordered" method="post">

                        <div class="form-group">
                            <label class="control-label col-lg-3" for="content">Matric Number:</label>
                            <div class="col-lg-6">
                                <input type="text" name="matno" id="matno" value="">
                            </div>
                            <div class="col-lg-2">
                                <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                            </div>
                        </div>

                    </form>
                </div>
                <hr class="separator" />
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/select2/select2.js"></script>
    <script src="assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
    <script src="assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
    <script src="assets/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/tables/examples.datatables.default.js"></script>
    <script src="assets/javascripts/tables/examples.datatables.row.with.details.js"></script>
    <script src="assets/javascripts/tables/examples.datatables.tabletools.js"></script>

    <script>
        $(document).ready(function() {
            //fetch table data
            fetch();
            //clicking edit button
            $(document).on('click', '.editbutton', function() {
                var row = $(this).closest('tr');
                //hide values
                row.find('.editValue').hide();
                //show edit input
                row.find('.editInput').show();
                //show save button
                row.find('.savebutton').show();
                //hide edit button
                $(this).hide();
            });
            //save
            $(document).on('click', '.savebutton', function() {
                var row = $(this).closest('tr');
                //hide textbox
                row.find('.editInput').hide();
                //show value
                row.find('.editValue').show();
                //show edit button
                row.find('.editbutton').show();
                //hide save button
                $(this).hide();
                var id = row.attr('id');
                var form = row.find('.editInput').serializeArray();
                form.push({
                    name: 'id',
                    value: id
                });
                $.ajax({
                    method: 'POST',
                    url: 'inline_edit/secrutiny_edit.php',
                    data: form,
                    dataType: 'json',
                    success: function(response) {
                        if (response.error) {
                            $('#response').show().removeClass('alert-sucess').addClass(
                                'alert-danger');
                            $('#message').html(response.message);
                        } else {
                            $('#response').show().removeClass('alert-danger').addClass(
                                'alert-success');
                            $('#message').html(response.message);

                            //populate table with updated row
                            row.find('.editValue.scru_aprove').html(response.member
                                .scru_aprove);
                            row.find('.editValue.scru_comment').html(response.member
                                .scru_comment);
                            //row.find('.editValue.pct').html(response.member.pct);
                            //row.find('.editValue.address').html(response.member.address);

                            row.find('.editInput.scru_aprove').val(response.member.scru_aprove);
                            row.find('.editInput.scru_comment').val(response.member
                                .scru_comment);
                            //row.find('.editInput.pct').val(response.member.pct);
                            //row.find('.editInput.address').val(response.member.address);
                        }
                    }
                });
            });
            //clear msg
            $('#clearMsg').click(function() {
                $('#response').hide();
            });
        });
    </script>
</body>

</html>
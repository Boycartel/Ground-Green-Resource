<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Setup Summary</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Course Managment
                            </li>

                            <li class="active">
                                <strong>Course Setup Summary</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Setup Summary
                        </div>
                        <div class="panel-body table-responsive">
                            <?php
                            $msg = "";
                            $success_upl = "no";
                            $cursession = $_SESSION['corntsession'];
                            $prevsession = $_SESSION['prevsession'];


                            ?>

                            <br>
                            <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
                            $sql = "SELECT * FROM deptcoding WHERE students = 'yes'";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                            ?>
                            <table class="table mb-none">
                                <thead>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Department</th>
                                        <th colspan='6' style="text-align: center;">Number of Courses</th>

                                    </tr>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th style='text-align: center;'>100 Level</th>
                                        <th style='text-align: center;'>200 Level</th>
                                        <th style='text-align: center;'>300 Level</th>
                                        <th style='text-align: center;'>400 Level</th>
                                        <th style='text-align: center;'>500 Level</th>
                                        <th style='text-align: center;'>Total</th>
                                    </tr>
                                </thead>
                                <tbody>


                                    <?php


                                        $sno = 0;
                                        while ($row = $result->fetch_assoc()) {
                                            $get100 = $get200 = $get300 = $get400 = $get500 = $totcourse = 0;
                                            $dept2 = $row["DeptCode"];
                                            $depttitle = $row["DeptName"];
                                            $sql2 = "SELECT * FROM deptcourses WHERE dept LIKE '$dept2'";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $totcourse++;
                                                    if ($row2["level"] == 100) {
                                                        $get100++;
                                                        $level2 = 100;
                                                    } elseif ($row2["level"] == 200) {
                                                        $get200++;
                                                        $level2 = 200;
                                                    } elseif ($row2["level"] == 300) {
                                                        $get300++;
                                                        $level2 = 300;
                                                    } elseif ($row2["level"] == 400) {
                                                        $get400++;
                                                        $level2 = 400;
                                                    } elseif ($row2["level"] == 500) {
                                                        $get500++;
                                                        $level2 = 500;
                                                    }
                                                }
                                            }

                                            $sno++;

                                            echo "<tr><td>$sno</td><td>$depttitle</td>";

                                            echo "
												 <td style='text-align: center;'>$get100 <form action='' method='post'>
													  <input type='hidden' value='100' name='level2'>
													  <input type='hidden' value='$dept2' name='dept2'>
                                                      <input type='hidden' value='$depttitle' name='depttitle'>
													  <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
												 </form></td>";
                                            echo "<td style='text-align: center;'>$get200 <form action='' method='post'>
													  <input type='hidden' value='200' name='level2'>
													  <input type='hidden' value='$dept2' name='dept2'>
                                                      <input type='hidden' value='$depttitle' name='depttitle'>
													  <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
												 </form></td>";
                                            echo "<td style='text-align: center;'>$get300 <form action='' method='post'>
													  <input type='hidden' value='300' name='level2'>
													  <input type='hidden' value='$dept2' name='dept2'>
                                                      <input type='hidden' value='$depttitle' name='depttitle'>
													  <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
												 </form></td>";
                                            echo "<td style='text-align: center;'>$get400 <form action='' method='post'>
													  <input type='hidden' value='400' name='level2'>
													  <input type='hidden' value='$dept2' name='dept2'>
                                                      <input type='hidden' value='$depttitle' name='depttitle'>
													  <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
												 </form></td>";
                                            echo "<td style='text-align: center;'>$get500 <form action='' method='post'>
													  <input type='hidden' value='500' name='level2'>
													  <input type='hidden' value='$dept2' name='dept2'>
                                                      <input type='hidden' value='$depttitle' name='depttitle'>
													  <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
												 </form></td>";

                                            //echo '<a href="#viewRecModal100" class="view100"><b style="color:green"><i class="fa fa-folder" data-toggle="tooltip" title="Click to View"> View</i></b></a>';

                                            echo "<th style='text-align: center;'>$totcourse</th></tr>\n";
                                        }
                                        ?>
                                </tbody>
                            </table>
                            <?php } ?>
                            <?php
$conn->close();
?>

                        </div>
                    </div>
                    <?php if (isset($_POST["view"])) { ?>
                    <?php
                        $level2 = $_POST["level2"];
                        $dept2 = $_POST["dept2"];
                        $depttitle = $_POST["depttitle"];
                        ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            <?php echo $depttitle ?> Department, <?php echo $level2 ?> Level
                        </div>
                        <div class="panel-body table-responsive">
                            <table class="table mb-none">
                                <thead>

                                    <tr>
                                        <th>S/No</th>
                                        <th>Course Code</th>
                                        <th>Course Title</th>
                                        <th>Credit Unit</th>
                                        <th>Semester</th>
                                        <th>Nature</th>
                                        <th>Corriculum</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }
                                        $sno2 = 0;
                                        $sql2 = "SELECT * FROM deptcourses WHERE dept = '$dept2' AND level = '$level2' ORDER BY SemTaken, CCode";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $sno2++;
                                                $CCode = $row2["CCode"];
                                                $CTitle = $row2["CTitle"];
                                                $CUnit = $row2["CUnit"];
                                                $SemTaken = $row2["SemTaken"];
                                                $Nature = $row2["Nature"];
                                                $type1 = $row2["type1"];

                                                echo "<tr><td>$sno2</td><td>$CCode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$type1</td></tr>";
                                            }
                                        }
                                        $conn->close();
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php } ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>





    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
    $(function() {
        $('a.view100').click(function(e) {
            e.preventDefault();
            var link = this;
            var deleteModal = $("#viewRecModal100");
            // store the ID inside the modal's form
            deleteModal.find('input[name=id]').val(link.dataset.id);

            // open modal
            deleteModal.modal();
        });
    });
    </script>
</body>

</html>
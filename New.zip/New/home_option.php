<?php
require_once 'includes/db_connect2.php';
//require_once 'includes/check_validity.php';


if (isset($_SESSION['loggedin']) || $_SESSION['loggedin'] == true) {
    if ($_SESSION['countprog'] > 1) {
        if ($_SESSION["seldeptLogin"] == true) {
            header('Location: home_staff.php');
        }
    } else {
        header('Location: home_staff.php');
    }
} else {
    session_destroy();
    header('Location: index_staff.php');
}


?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Programme Page</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">


    <div class="middle-box text-center animated fadeInDown">
        <h2><strong>Select Programme</strong></h2>

        <div class="error-desc">
            <?php
            $staffid = $_SESSION['staffid'];
            $dept = $_SESSION['deptcode'];
            ?>

            <table style="width: 90%; color:black">
                <tr>
                    <td style='padding: 2em; text-align:left'></td>
                    <td style='padding: 2em;'><a href="includes/logout.php" style="font-size: larger;">
                            <i class="fa fa-sign-out"></i> Log out
                        </a></td>
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = "SELECT * FROM deptcoding WHERE hostdept = '$dept'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $deptselcode = $row["DeptCode"];
                            $deptselname = $row["DeptName"];
                            echo "<tr><td style='padding: 0.5em; text-align:left'>$deptselname</td><td style='padding: 0.5em;'>";
                            echo "<form class='form-horizontal form-bordered' method='post' action='home_staff.php'>";
                            echo "<input type='hidden' value='$deptselcode' name='seldeptcode'>";
                            echo "<button name='view_home_option' class='btn btn-primary btn-xs'>Select</button>";
                            echo "</form>";
                            echo "</td></tr>";
                        }
                    }
                    $conn->close();
                    ?>

            </table>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
    var timeoutTimer;
    var expireTime = 1000 * 60 * 15;

    function expireSession() {
        clearTimeout(timeoutTimer);
        timeoutTimer = setTimeout("IdleTimeout()", expireTime);
    }

    function IdleTimeout() {
        localStorage.setItem("logoutMessage", true);
        <?php if ($_SESSION['logintype'] == "staff") { ?>
        window.location.href = "includes/logout.php";
        <?php } else { ?>
        window.location.href = "includes/logout_stu.php";
        <?php } ?>
    }
    $(document).on('click mousemove scroll', function() {
        expireSession();
    });
    expireSession();
    </script>
</body>

</html>
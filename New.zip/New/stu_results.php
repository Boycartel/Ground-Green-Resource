<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';


$paystatus = "NO";
$regid = $_SESSION['regid'];
if ($regid !== "CIV/21U/2898") {
    header('Location: home_stu.php');
}
$corntsession = $_SESSION['corntsession'];
$modeofentry = $_SESSION['modeofentry'];
if ($modeofentry == "ND") {
    $prog = "National Diploma";
} elseif ($modeofentry == "HND") {
    $prog = "Higher National Diploma";
}



$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$sql = "SELECT * FROM std_data_payment WHERE Matriculation_no = '$regid' AND session = '$corntsession' AND payment_cat = 'registration' AND (pay_or_skip = 'pay' || pay_or_skip = 'skip')";
$result = $conn2->query($sql);

if ($result->num_rows == 0) {
    header('Location: home_stu.php');
}
$conn2->close();
//include_once 'includes/check_stu_status.php';

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Print Div-->
    <script type="text/javascript">
        function printDiv(div_id) {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var content_vlue = document.getElementById(div_id).innerHTML;

            var docprint = window.open("", "", disp_setting);

            ///// Enable Bootstrap CSS
            //// Can also add customise CSS
            docprint.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
            );
            docprint.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <!--
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    -->
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <?php

    $regid = $_SESSION["regid"];
    $studept = $_SESSION['deptcode'];
    $curtsession = $_SESSION['corntsession'];
    $names = $_SESSION['names'];
    $resultsession = $_SESSION['resultsession'];
    $resultsemester = $_SESSION['resultsemester'];
    $entry_session = $_SESSION['entry_session'];

    $cgpa = $totsumunits = $totsumgp = 0;
    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Results</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Results</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php

                $FinalYear = substr($resultsession, 0, 4);
                $StartYear = substr($entry_session, 0, 4);
                $countses = 0;
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $dept_db = $_SESSION['deptdb'] . strtolower($studept);
                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                if ($conn_stu->connect_error) {
                    die("Connection failed: " . $conn_stu->connect_error);
                }

                $sql = "SELECT * FROM sessions WHERE getkey = 'key1'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $reg_session = $row["session_title"];
                        $reg_semester = $row["semester"];
                        $results_session = $row["result_session"];
                        $results_semester = $row["result_semester"];
                        $stu_results = $row["stu_results"];
                    }
                }

                for ($x = $StartYear; $x <= $FinalYear; $x++) {
                    $getstuSession2 = $x . "/" . ($x + 1);

                    $StuCurSess = str_ireplace("/", "_", $getstuSession2);

                    if ($StartYear < 2015) {
                        $deptcorreg = "correg";
                    } else {
                        $deptcorreg = "correg_" . $StuCurSess;
                    }

                    //$deptcorreg = "correg_" . $StuCurSess;
                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis = '$getstuSession2'";
                    $result = $conn_stu->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $countses++;
                            $getSessionUnGrad[$countses] = $row['SessionRegis'];
                        }
                    } else {
                        $countses++;
                        $getSessionUnGrad[$countses] = "XXXX";
                    }
                    $getSessionUnGrad2 = array_unique($getSessionUnGrad);
                    $lastsession = max($getSessionUnGrad2);
                }
                $conn->close();
                $conn_stu->close();

                $finalyear = substr($lastsession ?? '', 5);

                $sessionarry[] = "";
                $addyear = 0;
                $noarry = 0;
                $yearadmt = substr($entry_session, 0, 4);
                for ($x = 0; $addyear <= $finalyear; $x++) {
                    $addyear = $yearadmt + 1;
                    $sessionarry[$x] = "$yearadmt/$addyear";
                    $yearadmt++;
                    $noarry++;
                    if ($lastsession == $sessionarry[$x]) {
                        break;
                    }
                }


                $cgpa = $totsumunits = $totsumgp = 0;
                ?>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Results
                        </div>
                        <div class="panel-body">
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <div class="tabs tabs-primary">
                                    <ul class="nav nav-tabs">
                                        <li class="active">
                                            <a href="#1" data-toggle="tab"><i class="fa fa-star"></i>
                                                <?php echo $sessionarry[0] ?></a>
                                        </li>
                                        <?php for ($i = 1; $i < $noarry; $i++) { ?>
                                            <li>
                                                <a href="#<?php echo $i + 1 ?>" data-toggle="tab"><?php echo $sessionarry[$i] ?></a>
                                            </li>
                                        <?php } ?>
                                        <li>
                                            <a href="#all" data-toggle="tab"> All</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <div id="1" class="tab-pane active">
                                            <p><?php echo $sessionarry[0] ?></p>
                                            <div id="printableArea">

                                                <table style="width: 100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="width: 40%">
                                                                Matric Number: <?php echo $regid ?><br>

                                                                Name : <?php echo $names ?><br>
                                                                Department: <?php echo $deptname ?><br>
                                                                <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                                                    Programme: <?php echo $prog ?>
                                                                <?php } ?>
                                                            </td>
                                                            <td style="width: 40%">
                                                                <?php
                                                                echo "<center><img alt='testing' src='includes/barcode.php?codetype=code39&size=50&text=" . $names . "'/></center>";
                                                                ?>
                                                            </td>
                                                            <td>
                                                                <figure class="profile-picture">
                                                                    <?php

                                                                    $matpassport = str_replace("/", "_", $regid);
                                                                    echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='100'>";
                                                                    ?>
                                                                </figure>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <?php
                                                $sumunits = $sumgp = $point = $gp = $gpa = 0;
                                                $grade = "";
                                                $session1 = $sessionarry[0];
                                                $_SESSION["mysession"] = $sessionarry[0];

                                                include 'includes/result_stu.php';
                                                ?>
                                            </div>
                                            <div class="row" style="text-align: right">
                                                <br>
                                                <input type="button" onclick="printDiv('printableArea')" value="print" class="btn-success" />
                                            </div>
                                        </div>
                                        <?php for ($i = 1; $i < $noarry; $i++) { ?>
                                            <div id="<?php echo $i + 1 ?>" class="tab-pane">
                                                <p><?php echo $sessionarry[$i] ?></p>
                                                <div id="printableArea<?php echo $i ?>">

                                                    <table style="width: 100%">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width: 40%">
                                                                    Matric Number: <?php echo $regid ?><br>

                                                                    Name : <?php echo $names ?><br>
                                                                    Department: <?php echo $deptname ?><br>
                                                                    <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                                                        Programme: <?php echo $prog ?>
                                                                    <?php } ?>
                                                                </td>
                                                                <td style="width: 40%">
                                                                    <?php
                                                                    echo "<center><img alt='testing' src='includes/barcode.php?codetype=code39&size=50&text=" . $names . "'/></center>";
                                                                    ?>
                                                                </td>
                                                                <td>
                                                                    <figure class="profile-picture">
                                                                        <?php
                                                                        $matpassport = str_replace("/", "_", $regid);
                                                                        echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='100'>";
                                                                        ?>
                                                                    </figure>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <?php
                                                    $sumunits = $sumgp = $point = $gp = $gpa = 0;
                                                    $grade = "";
                                                    $session1 = $sessionarry[$i];
                                                    $_SESSION["mysession"] = $sessionarry[$i];

                                                    include 'includes/result_stu.php';
                                                    ?>

                                                </div>
                                                <div style="text-align: right">
                                                    <input type="button" onclick="printDiv('printableArea<?php echo $i ?>')" value="print" class="btn-success" />
                                                </div>
                                            </div>
                                        <?php } ?>
                                        <div id="all" class="tab-pane">
                                            <p>All</p>
                                            <div id="printableAreaAll">
                                                <table style="width: 100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="width: 40%">
                                                                Matric Number: <?php echo $regid ?><br>

                                                                Name : <?php echo $names ?><br>
                                                                Department: <?php echo $deptname ?><br>
                                                                <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                                                    Programme: <?php echo $prog ?>
                                                                <?php } ?>
                                                            </td>
                                                            <td style="width: 40%">
                                                                <?php
                                                                echo "<center><img alt='testing' src='includes/barcode.php?codetype=code39&size=50&text=" . $names . "'/></center>";
                                                                ?>
                                                            </td>
                                                            <td>
                                                                <figure class="profile-picture">
                                                                    <?php
                                                                    $matpassport = str_replace("/", "_", $regid);
                                                                    echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='100'>";
                                                                    ?>
                                                                </figure>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <?php
                                                $sumunits = $sumgp = $point = $gp = $gpa = 0;
                                                /*$grade="";
                                            $_SESSION["mysession"]="";
                                            $session2="";
                                            $session3="";
                                               include 'includes/result_stu.php'; */
                                                ?>

                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th>Course Code</th>
                                                            <th>Course Title</th>
                                                            <th>Unit</th>
                                                            <th>Semester</th>
                                                            <th>Session</th>
                                                            <th>Grade</th>
                                                            <th>GP</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $dept_db = $_SESSION['deptdb'] . strtolower($studept);
                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                        if ($conn_stu->connect_error) {
                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                        }

                                                        for ($i = 0; $i < $noarry; $i++) {
                                                            $session1 =  $sessionarry[$i];

                                                            $StuCurSess = str_ireplace("/", "_", $session1);
                                                            $deptcorreg = "correg_" . $StuCurSess;
                                                            if ($resultsemester == "1ST") {
                                                                if ($session1 == $resultsession) {
                                                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis  = '$session1' AND SemTaken  = '1ST' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
                                                                } else {
                                                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis  = '$session1' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
                                                                }
                                                            } else {
                                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis  = '$session1' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
                                                            }

                                                            $result = $conn_stu->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {

                                                                    $grade = $row['grade'];
                                                                    $gp = $row['point'];
                                                                    $CCode = $row['CCode'];
                                                                    $SemTaken = $row['SemTaken'];
                                                                    if ($stu_results == "Disable" && $session1 == $results_session && $SemTaken == $results_semester) {
                                                                    } else {

                                                                        echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['SessionRegis']}</td><td>$grade</td><td>$gp</td></tr>\n";

                                                                        if ($_SESSION['instcode'] == "FPB") {
                                                                            $sql2 = "SELECT * FROM absent_students WHERE matric_no = '$regid' AND CCode = '$CCode' AND status1 = 'R'";
                                                                            $result2 = $conn_stu->query($sql2);
                                                                            if ($result2->num_rows > 0) {
                                                                                if ($grade == "F") {
                                                                                } else {
                                                                                    $sumgp += $gp;
                                                                                    $sumunits += $row['CUnit'];
                                                                                }
                                                                            } else {
                                                                                $sumgp += $gp;
                                                                                $sumunits += $row['CUnit'];
                                                                            }
                                                                        } else {
                                                                            $sumgp += $gp;
                                                                            $sumunits += $row['CUnit'];
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        $conn_stu->close();

                                                        echo "<tr><td></td><th>Total</th><th>$sumunits</th><td></td><td></td><td></td><th>$sumgp</th></tr>";
                                                        ?>
                                                    </tbody>
                                                </table>
                                                <br>
                                                <center>
                                                    <?php
                                                    $totsumunits += $sumunits;
                                                    $totsumgp += $sumgp;

                                                    if ($sumunits !== 0) {
                                                        echo "GPA = " . number_format((float)$sumgp / $sumunits, 2, '.', '') . "<br>";
                                                    }
                                                    if ($totsumunits !== 0) {
                                                        echo "CGPA = " . number_format((float)$totsumgp / $totsumunits, 2, '.', '');
                                                    }
                                                    ?>

                                                </center>




                                            </div>
                                            <div style="text-align: right">
                                                <input type="button" onclick="printDiv('printableAreaAll')" value="print" class="btn-success" />
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                            </div>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
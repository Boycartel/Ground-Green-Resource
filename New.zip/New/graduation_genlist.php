<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_edit'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <script src="js/getexcel/tableToExcel_D.js"> </script>
    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>



</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Graduation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Graduation
                            </li>

                            <li class="active">
                                <strong>Students Record</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students Record
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal bucket-form" method="post" action="">
                                <div class="row">
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Session of Graduation:</label>
                                            <div class="col-sm-7">
                                                <select class="scale form-control m-bot15" name="sessiongrad"
                                                    required="required">
                                                    <option></option>
                                                    <?php
                                                    $finalyear = substr($_SESSION['resultsession'], 0, 4);
                                                    for ($x = 2018; $x <= $finalyear; $x++) {
                                                        $x2 = $x + 1;
                                                    ?>
                                                    <option><?php echo $x . "/" . $x2; ?></option>

                                                    <?php } ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Gender:</label>
                                            <div class="col-sm-7">
                                                <select class="form-control m-bot15" name="sex">
                                                    <option value='All'>All</option>
                                                    <option value='Male'>Male</option>
                                                    <option value='Female'>Female</option>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">School:</label>
                                            <div class="col-sm-7">
                                                <select class="form-control m-bot15" name="school" id="school">
                                                    <option>All</option>

                                                    <?php
                                                    $sql = "SELECT * FROM schoolname ORDER BY SchName";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $schtcode = $row["SchCode"];
                                                            $schname = $row["SchName"];
                                                            echo "<option value=$schtcode>$schname</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Department:</label>
                                            <div class="col-sm-7">
                                                <select class="form-control m-bot15" name="dept" id="dept">
                                                    <option>All</option>

                                                    <?php
                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode = $row["DeptCode"];
                                                            $deptname = $row["DeptName"];
                                                            echo "<option value=$deptcode>$deptname</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">State of Origin</label>
                                            <div class="col-sm-7">
                                                <select class="state1 form-control m-bot15" name="stateorigin"
                                                    required="required">
                                                    <option></option>
                                                    <option>All</option>
                                                    <?php
                                                    $sql = "SELECT * FROM states ORDER BY state";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $statename = $row["state"];
                                                            //$statename = $row["StateName"];
                                                            echo "<option value='$statename'>$statename</option>";
                                                        }
                                                    }

                                                    //$conn->close();
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class='form-group'>
                                            <label class='col-sm-5 control-label'>LGA:</label>
                                            <div class='col-sm-7' id='getlga'>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Semester of Graduation:</label>
                                            <div class="col-sm-7">
                                                <select class="form-control m-bot15" name="semes" id="semes" required>
                                                    <option value="">Select Item</option>
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label"></label>
                                            <div class="col-sm-7">

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label"></label>
                                            <div class="col-sm-7" style="text-align: right;">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>


                                </div>

                            </form>

                            <?php
                            //for ($i = 1; $i <= 10000; $i++) {
                            //echo addOrdinalNumberSuffix($i) . "\t";
                            //if ($i % 10 == 0) {
                            //echo "\n";
                            //}
                            //}

                            if (isset($_POST["submit"])) {
                                $sessiongradpost3 = $sexpost3 = $schoolpost3 = $deptpost3 = $stateoriginpost3 = $lgapost3 = "";

                                $sessiongradpost = $_POST["sessiongrad"];
                                $sexpost = $_POST["sex"];
                                $schoolpost = $_POST["school"];
                                $deptpost = $_POST["dept"];
                                $stateoriginpost = $_POST["stateorigin"];
                                $lgapost = $_POST["lga"];
                                $semespost = $_POST["semes"];


                                if ($sessiongradpost == "All") {
                                    $sessiongradpost2 = "";
                                } else {

                                    if ($sexpost == "All" && $stateoriginpost == "All" && $lgapost == "All") {
                                        $sessiongradpost2 = "session1 = '$sessiongradpost'";
                                    } else {
                                        $sessiongradpost2 = "session1 = '$sessiongradpost' AND ";
                                    }
                                    $sessiongradpost3 = "Session Graduated = " . $sessiongradpost;
                                }

                                if ($sexpost == "All") {
                                    $sexpost2 = "";
                                } else {

                                    if ($stateoriginpost == "All" && $lgapost == "All") {
                                        $sexpost2 = "sex = '$sexpost'";
                                    } else {
                                        $sexpost2 = "sex = '$sexpost' AND ";
                                    }
                                    $sexpost3 = "Gender = " . $sexpost;
                                }


                                if ($stateoriginpost == "All") {
                                    $stateoriginpost2 = "";
                                } else {

                                    if ($lgapost == "All") {
                                        $stateoriginpost2 = "stateOfOrigin='$stateoriginpost'";
                                    } else {
                                        $stateoriginpost2 = "stateOfOrigin='$stateoriginpost' AND ";
                                    }
                                    $stateoriginpost3 = "State of Oringin = " . $stateoriginpost;
                                }

                                if ($lgapost == "All") {
                                    $lgapost2 = "";
                                } else {
                                    $lgapost2 = "lga='$lgapost'";
                                    $lgapost3 = "lga = " . $lgapost;
                                }


                                echo $sessiongradpost3 . ", " . $sexpost3 . ", " . $schoolpost3 . ", " . $deptpost3 . ", " . $stateoriginpost3 . ", " . $lgapost3;

                            ?>
                            <table id="myTable" style="font-size:12px" summary="" rules="groups" frame="hsides"
                                border="2" class="table mb-none">
                                <caption>Students List</caption>
                                <colgroup align="left"></colgroup>
                                <colgroup align="left"></colgroup>
                                <colgroup span="2"></colgroup>
                                <colgroup span="3" align="left"></colgroup>
                                <thead style='text-align:center'>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Matric No.</th>
                                        <th>Name</th>
                                        <th>Gender</th>
                                        <th>Parmenant Hone Address</th>
                                        <th>Year Admitted</th>
                                        <th>Department</th>
                                        <th>State of Origin</th>
                                        <th>LGA</th>
                                        <th>Programme</th>
                                        <th>Date of Birth</th>
                                        <th>Year of Graduation</th>
                                        <th>Session Graduate</th>
                                        <th>CGPA</th>
                                        <th>Position</th>
                                        <th>Class of Degree</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                        set_time_limit(5000);
                                        $sno = 0;

                                        $position = 0;
                                        $position2 = "";
                                        $cgpa = 0;
                                        $cgpaprev = 5;
                                        $nullposition = 0;
                                        if ($deptpost == "All" && $schoolpost == "All") {
                                            $sql2 = "SELECT DeptCode, DeptName FROM deptcoding ORDER BY DeptName";
                                        } elseif ($deptpost == "All" && $schoolpost !== "All") {
                                            $sql2 = "SELECT DeptCode, DeptName FROM deptcoding WHERE School = '$schoolpost' ORDER BY DeptName";
                                        } elseif ($deptpost !== "All" && $schoolpost == "All") {
                                            $sql2 = "SELECT DeptCode, DeptName FROM deptcoding WHERE DeptCode = '$deptpost' ORDER BY DeptName";
                                        } elseif ($deptpost !== "All" && $schoolpost !== "All") {
                                            $sql2 = "SELECT DeptCode, DeptName FROM deptcoding WHERE DeptCode = '$deptpost' ORDER BY DeptName";
                                        }
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $DeptCode = $row2["DeptCode"];
                                                $dept_db = $_SESSION['deptdb'] . strtolower($DeptCode);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                if ($_SESSION['InstType'] == "University") {
                                                    $sql = "SELECT * FROM scrutiny_senate WHERE " . $sessiongradpost2 . $sexpost2 . $stateoriginpost2 . $lgapost2 .  " AND semester = '$semespost' AND graduated = 'YES' ORDER BY CGPA DESC";
                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                    $sql = "SELECT * FROM scrutiny_senate WHERE " . $sessiongradpost2 . $sexpost2 . $stateoriginpost2 . $lgapost2 .  " AND semester = '$semespost' AND graduated = 'YES' AND mode_entry = 'HND' ORDER BY CGPA DESC";
                                                }
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $Regn = $row["Regn"];
                                                        $Name_full = $row["Name1"];
                                                        $Sex = $row["sex"];
                                                        $ParmtAdress = $row["p_address"];
                                                        $YAddmitted = $row["yearadmt"];
                                                        $Department = $row["deptfull"];
                                                        $deptcode = $DeptCode;
                                                        $stateOfOrigin = $row["stateOfOrigin"];
                                                        $LGA = $row["lga"];
                                                        $programme = $row["progfull"];
                                                        $dob = $row["dob"];
                                                        $yearGrd = $row["yearGrad"];
                                                        $session = $row["session1"];
                                                        $cgpa = number_format((float)$row["CGPA"], 2, '.', '');

                                                        if ($cgpaprev == $cgpa) {
                                                            $position = $position;
                                                            $nullposition++;
                                                        } else {
                                                            $position = $position + 1;
                                                            $position = $position + $nullposition;
                                                            $nullposition = 0;
                                                        }

                                                        $classdegree = $row["classdegree"];
                                                        $cgpaprev = $cgpa;
                                                        $position2 = addOrdinalNumberSuffix($position);
                                                        echo "<tr><td>$sno</td><td>$Regn</td><td>$Name_full</td><td>$Sex</td><td>$ParmtAdress</td><td>$YAddmitted</td><td>$Department</td><td>$stateOfOrigin</td><td>$LGA</td><td>$programme</td><td>$dob</td><td>$yearGrd</td><td>$session</td><td>$cgpa</td><td>$position2</td><td>$classdegree</td></tr>\n";
                                                    }
                                                }
                                                $conn_stu->close();
                                            }
                                        }
                                        ?>
                                </tbody>
                            </table>

                            <br><br>
                            <div class="form-group">
                                <!-- Buttons -->
                                <div class="col-lg-offset-2 col-lg-9" style="text-align: right;">
                                    <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                        class="btn btn-primary">Download</a>
                                </div>
                            </div>

                            <?php
                            }    //End Submit
                            ?>


                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script type="text/javascript">
    $(document).ready(function() {
        $("select.state1").change(function() {
            var selectedState = $(".state1 option:selected").val();
            $.ajax({
                type: "POST",
                url: 'ajax_save_rec/lga_ddown.php',
                data: {
                    state1: selectedState
                }
            }).done(function(data) {
                $("#getlga").html(data);
            });
        });
    });
    </script>

    <?php

    function addOrdinalNumberSuffix($num)
    {
        if (!in_array(($num % 100), array(11, 12, 13))) {
            switch ($num % 10) {
                    // Handle 1st, 2nd, 3rd
                case 1:
                    return $num . '<sup>st</sup>';
                case 2:
                    return $num . '<sup>nd</sup>';
                case 3:
                    return $num . '<sup>rd</sup>';
            }
        }
        return $num . '<sup>th</sup>';
    }

    ?>

</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false && $_SESSION['acad_office_request'] == false) {
    header('Location: home_staff.php');
}


?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Enrolment</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Statistical Digest
                            </li>
                            <li class="active">
                                Enrolment
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Enrolment
                        </div>
                        <div class="panel-body">

                            <div class="row">

                                <div class="col-md-1">
                                </div>
                                <div class="col-md-10">


                                    <?php

                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                    if ($conn2->connect_error) {
                                        die("Connection failed: " . $conn2->connect_error);
                                    }

                                    $sql = "SELECT * FROM sessions WHERE getkey = 'key1'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $reg_session = $row["session_title"];
                                            $reg_semester = $row["semester"];
                                            $results_session = $row["result_session"];
                                            $results_semester = $row["result_semester"];
                                            $stu_results = $row["stu_results"];
                                        }
                                    }
                                    //$session1 = $_POST["session1"];
                                    unset($male);
                                    $male[] = 0;
                                    unset($female);
                                    $female[] = 0;
                                    unset($deptArray);
                                    $deptArray[] = "";
                                    $totMale = $totFemale = 0;
                                    $count = 0;
                                    $sql2 = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptName";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $deptcode = $row2["DeptCode"];
                                            $deptname = $row2["DeptName"];
                                            $countmale = $countfemale = 0;
                                            $count++;
                                            $sql = "SELECT * FROM std_data_view WHERE (status = 5 OR status = 6) AND dept_code = '$deptcode'";
                                            $result = $conn2->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    if (strtoupper($row["gender"]) == "M" || strtoupper($row["gender"]) == "MALE") {
                                                        $countmale++;
                                                    } else {
                                                        $countfemale++;
                                                    }
                                                }
                                            }
                                            $deptArray[$count] = $deptname;
                                            $male[$count] = $countmale;
                                            $female[$count] = $countfemale;
                                            $totMale += $countmale;
                                            $totFemale += $countfemale;
                                        }
                                    }



                                    $conn->close();
                                    $conn2->close();


                                    ?>

                                    <section class="panel panel-default">
                                        <header class="panel-heading">

                                            <h2 class="panel-title"><?php //echo $names 
                                                                    ?></h2>
                                        </header>
                                        <div class="panel-body">

                                            <div id="printableArea">
                                                <h1><strong> Table 1a: Enrolment</strong></h1>
                                                <h2><strong>Undergraduate Enrolment(Full Time and Part Time) as at
                                                        <?php echo $reg_session ?> Session</strong>
                                                </h2>
                                                <table class="table mb-none" style="width: 100%">
                                                    <thead>
                                                        <tr>
                                                            <th>S/No</th>
                                                            <th>Department</th>
                                                            <th>Male</th>
                                                            <th>Female</th>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        for ($x = 1; $x <= $count; $x++) {
                                                            $total = $male[$x] + $female[$x];
                                                            echo "<tr><td>$x</td><td>$deptArray[$x]</td><td>$male[$x]</td><td>$female[$x]</td><td>$total</td></tr>";
                                                        }
                                                        $tot_total = $totMale + $totFemale;
                                                        ?>
                                                        <tr>
                                                            <th></th>
                                                            <th>Total</th>
                                                            <th><?php echo $totMale ?></th>
                                                            <th><?php echo $totFemale ?></th>
                                                            <th><?php echo $tot_total ?></th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <br><br>
                                                <h2><strong>Postgraduate Enrolment(Full Time and Part Time) as at
                                                        <?php echo $reg_session ?> Session</strong>
                                                </h2>
                                                <table class="table mb-none" style="width: 100%">
                                                    <thead>
                                                        <tr>
                                                            <th>S/No</th>
                                                            <th>Department</th>
                                                            <th>Male</th>
                                                            <th>Female</th>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        for ($x = 1; $x <= $count; $x++) {
                                                            //$total = $male[$x] + $female[$x];
                                                            echo "<tr><td>$x</td><td>$deptArray[$x]</td><td>0</td><td>0</td><td>0</td></tr>";
                                                        }
                                                        //$tot_total = $totMale + $totFemale;
                                                        ?>
                                                        <tr>
                                                            <th></th>
                                                            <th>Total</th>
                                                            <th>0</th>
                                                            <th>0</th>
                                                            <th>0</th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <br>
                                            <div style="text-align: right">
                                                <input type="button" onclick="printDiv('printableArea')" value="print"
                                                    class="btn-success" />
                                            </div>

                                        </div>
                                    </section>

                                </div>
                                <div class="col-md-1">
                                </div>

                            </div>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
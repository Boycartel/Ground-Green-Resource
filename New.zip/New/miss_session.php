<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <?php $stutype = $_SESSION['stutype']; ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Missing Session</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Missing Session</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Missing Session
                        </div>
                        <div class="panel-body">
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th>S/No</th>
                                            <th>Response</th>
                                            <th>Session</th>
                                            <th>Semester</th>
                                            <th>Comment</th>
                                            <th>Approval</th>
                                            <th>Senate Number</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $matno = $_SESSION["regid"];
                                        $sql = "SELECT * FROM missing_session WHERE matno = '$matno' ORDER BY session";
                                        $result = $conn->query($sql);
                                        $sno = 0;
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $sno++;
                                                $id = $row['id'];
                                                $semester = $row['semester'];

                                                $response = $row['response'];
                                                if ($response == "Deferment") {
                                                    $response_full = "Deferment";
                                                } else if ($response == "Abscond") {
                                                    $response_full = "Abscond";
                                                } else if ($response == "Condonation") {
                                                    $response_full = "Condonation";
                                                } else if ($response == "Suspension") {
                                                    $response_full = "Suspension";
                                                } else if ($response == "Expulsion") {
                                                    $response_full = "Expulsion";
                                                    $semester = "";
                                                } else if ($response == "VolWithdrawal") {
                                                    $response_full = "Voluntary Withdrawal";
                                                    $semester = "";
                                                } else if ($response == "PoorWithdrawal") {
                                                    $response_full = "Withdrawal(Poor Acad Performance)";
                                                    $semester = "";
                                                } else if ($response == "Notification_illhealth") {
                                                    $response_full = "Notification of ill-health";
                                                    $semester = "";
                                                } else if ($response == "recall_susp") {
                                                    $response_full = "Recall from Suspension";
                                                    $semester = "";
                                                } else if ($response == "recall_expul") {
                                                    $response_full = "Recall from Expulsion";
                                                    $semester = "";
                                                }
                                                echo "<tr><td>$sno</td><td>$response_full</td><td>{$row['session']}</td><td>$semester</td><td>{$row['coment']}</td><td>{$row['approval']}</td><td>{$row['senateno']}</td>
			                                        <td>												
			                                            <form action='staf_condone_defer_result.php' method='post'>
			                                                  <input type='hidden' value=$id name='id'>
			                                                  <a href='miss_session_print.php?id2=$id' class='btn btn-primary btn-xs'>Print</a>
			                                             </form>
			                                        </td></tr>\n";
                                            }
                                        }
                                        $conn->close();
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-1">
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

</body>

</html>
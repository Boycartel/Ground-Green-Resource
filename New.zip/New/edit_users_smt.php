<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

$recsaved = $errorpf = "";
$errorcode = "NO";
$schcode = $_SESSION['schcode'];

$dept = $_SESSION['selectdept'];
//if(isset($_POST['submit']))  {
$pfno = $fullname = $phoneno = $email = $responsblty = "";
$pfno = $_POST['pfno'];
$fullname = $_POST['fullname'];
$fullname = validate_input($fullname);
$phoneno = $_POST['phoneno'];
$phoneno = validate_input($phoneno);
$email = $_POST['email'];
$email = validate_input($email);

$Examiner = $_POST['Examiner'];
$Ass_Examiner = $_POST['Ass_Examiner'];
$Seminer_Coord = $_POST['Seminer_Coord'];
$SIWES_Coord = $_POST['SIWES_Coord'];
$spill_over = $_POST['spill_over'];
$CourseLec = $_POST['CourseLec'];
$L100 = $_POST['L100'];
$L200 = $_POST['L200'];
$L300 = $_POST['L300'];
$L400 = $_POST['L400'];
if ($_SESSION['InstType'] == "University") {

    $PG_Coord = $_POST['PG_Coord'];
    $L500 = $_POST['L500'];
}

if ($_POST['fullname'] == "" || $_POST['phoneno'] == "" || $_POST['email'] == "") {
    $errorpf = "All Fields Required";
} else {
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    //$dept = $_SESSION['deptcode'];
    $sql = "SELECT sn, staffid, full_name, cat, Level1 FROM users WHERE staffid = '$pfno'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {

        $sql3 = "UPDATE users SET full_name='$fullname', phone='$phoneno', emailAdd = '$email' WHERE staffid = '$pfno'";
        $result3 = $conn->query($sql3);

        if ($Examiner == "YES") {
            $sql3 = "UPDATE users SET Examiner = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($Ass_Examiner == "YES") {
            $sql3 = "UPDATE users SET Ass_Examiner = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($Seminer_Coord == "YES") {
            $sql3 = "UPDATE users SET Seminer_Coord = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($SIWES_Coord == "YES") {
            $sql3 = "UPDATE users SET SIWES_Coord = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($spill_over == "YES") {
            $sql3 = "UPDATE users SET spill_over = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($CourseLec == "YES") {
            $sql3 = "UPDATE users SET CourseLec = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($L100 == "YES") {
            $sql3 = "UPDATE users SET L100 = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($L200 == "YES") {
            $sql3 = "UPDATE users SET L200 = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($L300 == "YES") {
            $sql3 = "UPDATE users SET L300 = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }
        if ($L400 == "YES") {
            $sql3 = "UPDATE users SET L400 = 'NO' WHERE staffacddept = '$dept'";
            $result3 = $conn->query($sql3);
        }

        if ($_SESSION['InstType'] == "University") {
            if ($PG_Coord == "YES") {
                $sql3 = "UPDATE users SET PG_Coord = 'NO' WHERE staffacddept = '$dept'";
                $result3 = $conn->query($sql3);
            }

            if ($L500 == "YES") {
                $sql3 = "UPDATE users SET L500 = 'NO' WHERE staffacddept = '$dept'";
                $result3 = $conn->query($sql3);
            }
        }

        $sql3 = "UPDATE users SET Examiner = '$Examiner', Ass_Examiner = '$Ass_Examiner', Seminer_Coord = '$Seminer_Coord', SIWES_Coord = '$SIWES_Coord', spill_over = '$spill_over', CourseLec = '$CourseLec', L100 = '$L100', L200 = '$L200', L300 = '$L300', L400 = '$L400' WHERE staffid = '$pfno'";
        $result3 = $conn->query($sql3);

        if ($_SESSION['InstType'] == "University") {
            $sql3 = "UPDATE users SET PG_Coord = '$PG_Coord', L500 = '$L500' WHERE staffid = '$pfno'";
            $result3 = $conn->query($sql3);
        }
    }
    $conn->close();
}

if (count($_FILES) > 0) {
    //$filename = validate_input($_POST['filename']);


    $staff_pic_folder = $_SESSION['staff_pic_folder'];



    $valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp', 'pdf', 'doc', 'docx', 'ppt', 'pptx'); // valid extensions
    $path = $staff_pic_folder;  // upload directory

    //if (!empty($_POST['filename'])) {
    $img = $_FILES['uploaded']['name'];
    $tmp = $_FILES['uploaded']['tmp_name'];
    // get uploaded file's extension
    $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
    // can upload same image using rand function
    //$imageid = rand(1000, 1000000);
    $final_image = strtoupper($pfno) . '.jpg';

    // check's valid format
    if (in_array($ext, $valid_extensions)) {
        $path = $path . $final_image;
        if (move_uploaded_file($tmp, $path)) {
        }
    }
    //}
}

$recsaved = "Record Saved";

?>
<script type="text/javascript">
location = "create_user.php";
</script>
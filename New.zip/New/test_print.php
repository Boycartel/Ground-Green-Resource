<html>
<head>
    <link rel="stylesheet" type="text/css" href="message_style.css">
    <script type="text/javascript" src="jquery.js"></script>
        <script type="text/javascript">

            $(document).ready(function(){
                $("#test_delete").click(function(){
                    message();
                });
                $("#cancel").click(function(){
                    hide();
                });
            });

        function message()
        {
            $("#delete_message").slideDown();
        }

        function hide()
        {
            $("#delete_message").slideUp();
        }
    </script>

</head>
<body>

<div id="delete_message">
    <h2>Are You Sure You Want To Delete This</h2>
    <input type="button" value="Delete" id="delete">
    <input type="button" value="Cancel" id="cancel">
</div>

<h1>Simple And Best Delete Confirmation Message Using jQuery,HTML And CSS</h1>
<center>
    <input type="button" id="test_delete" value="Click To Test Delete Confirmation Message">
</center>

</body>
</html>
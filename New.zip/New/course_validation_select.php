<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_validation'] == false) {
    header('Location: Home_Staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>

</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Validation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Course
                            </li>
                            <li class="active">
                                <strong>Course Validation</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php
                $staffnames = $_SESSION['names'];
                $staffid = $_SESSION['staffid'];
                ?>
                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Validation
                        </div>
                        <?php $_SESSION['loadformval'] = "YES"; ?>
                        <div class="panel-body">
                            <div>
                                <form class="form-horizontal" method="post" action="course_validation.php">
                                    <div class="row">
                                        <div class="form-group">
                                            <div class="col-lg-1">
                                            </div>
                                            <div class="col-lg-3">
                                                <input type="radio" name="seloption" value="LevelAdviser"> As Level
                                                Advicer
                                            </div>
                                            <div class="col-lg-3">
                                                <input type="radio" name="seloption" value="HOD"> As HOD
                                            </div>

                                            <div class="col-lg-3">
                                                <button type='submit' name='submit_selval'
                                                    class='btn btn-primary btn-sm'>Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="separator" />


                                </form>
                            </div>





                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>


</body>

</html>
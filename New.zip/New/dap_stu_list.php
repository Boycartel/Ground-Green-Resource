<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>
    <script src="js/getexcel/tableToExcel_Staff.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li><span>APU</span></li>
                            <li><span>Students Record</span></li>
                            <?php
                            if (isset($_POST["view"])) {
                                $deptstate = $_POST["deptstate"];
                                if ($deptstate == "yesdept") {
                                    echo "<li><span>By Department</span></li>";
                                } else {
                                    echo "<li><span>By State of Origin</span></li>";
                                }
                            }

                            ?>
                            <li class="active">
                                <strong>Students List</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students List
                        </div>
                        <div class="panel-body">
                            <div class="row">

                                <?php
                                set_time_limit(1000);
                                if (isset($_POST["view"])) {
                                    $deptstate = $_POST["deptstate"];
                                    $id = $_POST["id"];
                                    $getsession = $_POST["mysession"];
                                    $semester = $_POST["mysemester"];
                                    if ($deptstate == "yesdept") {

                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode='$id'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $GetTitle = $row["DeptName"] . " Department(" . $getsession . " Session)";
                                            }
                                        }
                                    } else {
                                        $id2 = $_POST["id2"];
                                        $sql = "SELECT * FROM states WHERE StateCode='$id'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $GetTitle = $row["state"] . " State(" . $getsession . " Session)";
                                            }
                                        }
                                    }
                                }

                                ?>
                                <h2 class="panel-title"><?php echo $GetTitle ?></h2>
                                <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                    <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                        <caption><?php echo $GetTitle ?></caption>
                                        <colgroup align="center"></colgroup>
                                        <colgroup align="left"></colgroup>
                                        <colgroup span="2"></colgroup>
                                        <colgroup span="3" align="center"></colgroup>
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Stu ID</th>
                                                <th>Matric No</th>
                                                <th>Surname</th>
                                                <th>First Name</th>
                                                <th>Other Names</th>
                                                <th>Department</th>
                                                <th>Level</th>
                                                <th>Mode of Entry</th>
                                                <th>Sex</th>
                                                <th>Nationality</th>
                                                <th>State of Origin</th>
                                                <th>LGA</th>
                                                <th>Contact Address</th>
                                                <th>Date of Birth</th>
                                                <th>Place of Birth</th>
                                                <th>Next of Kin</th>
                                                <th>Phone No</th>
                                                <th>email</th>
                                                <th>Matric No</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sno = 0;
                                            if ($deptstate == "yesdept") {
                                                //$getdept = strtolower($id) . "_hod_list";
                                                $dept_db = $_SESSION['deptdb'] . strtolower($id);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }
                                                $sql2 = "SELECT * FROM scrutiny_senate WHERE session1 = '$getsession' AND semester = '$semester'";
                                                //$sql2 = "SELECT * FROM hod_list WHERE Session1 = '$getsession'";
                                                $result2 = $conn_stu->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $sno++;
                                                        $matricno = $row2["Regn"];
                                                        $StuLevel = $row2["Level1"];
                                                        //$matriclen = strlen($matricno);
                                                        //if ($matriclen >= 10) {
                                                        $sql = "SELECT * FROM std_data_view WHERE matric_no = '$matricno'";
                                                        $result = $conn2->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                //$stdid = $row["stdid"];
                                                                $regid = $row["matric_no"];
                                                                $surname = $row["surname"];
                                                                $firstname = $row["first_name"];
                                                                $othername = $row["other_name"];
                                                                $Dept = $row["dept_code"];
                                                                //if (strlen($row["ContAddress"]) > 100) {
                                                                //$ContAddress = substr($row["ContAddress"], 0, 100);
                                                                //} else {
                                                                $ContAddress = $row["c_address"];
                                                                //}

                                                                $Nationality = $row["nationality"];
                                                                $stateOfOrigin = $row["state"];

                                                                /* $sql3 = "SELECT * FROM states WHERE StateCode = '$stateOfOrigin'";
                                                                $result3 = $conn->query($sql3);
                                                                if ($result3->num_rows > 0) {
                                                                    while ($row3 = $result3->fetch_assoc()) {
                                                                        $stateOfOrigin = $row3["state"];
                                                                    }
                                                                } */

                                                                $lga = $row["lga"];
                                                                $dob = $row["dob"];
                                                                $sex = $row["gender"];
                                                                $modeofentry = $row["modeofentry"];
                                                                $email = $row["sch_email"];
                                                                $Phone = $row["phone_number"];
                                                                $PlaceBirth = "XX";
                                                                $next_name = $row["next_name"];
                                                            }
                                                        }
                                                        //}

                                                        echo "<tr><td>$sno</td><td>$stdid</td><td>$regid</td><td>$surname</td><td>$firstname</td><td>$othername</td><td>$Dept</td><td>$StuLevel</td><td>$modeofentry</td><td>$sex</td><td>$Nationality</td>
                                                <td>$stateOfOrigin</td><td>$lga</td><td>$ContAddress</td><td>$dob</td><td>$PlaceBirth</td><td>$next_name</td><td>$Phone</td><td>$email</td>";
                                                        echo "<td>$regid</td><td>
                                            <form action='dap_stu_biodata.php' method='post'>
                                                <input type='hidden' value='$regid' name='id'>
                                                <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                            </form>
                                            </td>
                                                
                                            </tr>\n";
                                                    }
                                                }
                                            } else {
                                                $sno = 0;
                                                $state2 = strtoupper($id2);
                                                $sql = "SELECT * FROM std_data_view WHERE state = '$id' OR state = '$state2' ORDER BY matric_no";
                                                $result = $conn2->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {

                                                        $Dept = $row["dept_code"];
                                                        $regid = $row["matric_no"];
                                                        $matriclen = strlen($regid);
                                                        $meexist = 0;
                                                        if ($matriclen >= 10) {
                                                            //$getdept = strtolower($Dept) . "_hod_list";
                                                            $dept_db = $_SESSION['deptdb'] . strtolower($Dept);
                                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                            if ($conn_stu->connect_error) {
                                                                die("Connection failed: " . $conn_stu->connect_error);
                                                            }
                                                            $sql2 = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$getsession'";
                                                            $result2 = $conn_stu->query($sql2);

                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $StuLevel = $row2["StuLevel"];
                                                                    if ($StuLevel == "400P") {
                                                                        $StuLevel = "400";
                                                                    }
                                                                    $meexist++;
                                                                }
                                                            }
                                                        }

                                                        if ($meexist > 0) {
                                                            $sno++;
                                                            //$stdid = $row["stdid"];

                                                            $surname = $row["surname"];
                                                            $firstname = $row["first_name"];
                                                            $othername = $row["other_name"];

                                                            if (strlen($row["c_address"]) > 100) {
                                                                $ContAddress = substr($row["c_address"], 0, 100);
                                                            } else {
                                                                $ContAddress = $row["c_address"];
                                                            }

                                                            $Nationality = $row["nationality"];
                                                            $stateOfOrigin = $row["state"];
                                                            $lga = $row["lga"];
                                                            $dob = $row["dob"];
                                                            $sex = $row["gender"];
                                                            $modeofentry = $row["modeofentry"];
                                                            $email = $row["sch_email"];
                                                            $Phone = $row["phone_number"];
                                                            $PlaceBirth = "XX";
                                                            $next_name = $row["next_name"];

                                                            echo "<tr><td>$sno</td><td>$stdid</td><td>$regid</td><td>$surname</td><td>$firstname</td><td>$othername</td><td>$Dept</td><td>$StuLevel</td><td>$modeofentry</td><td>$sex</td><td>$Nationality</td>
                                                <td>$id2</td><td>$lga</td><td>$ContAddress</td><td>$dob</td><td>$PlaceBirth</td><td>$next_name</td><td>$Phone</td><td>$email</td>";
                                                            echo "<td>$regid</td><td>
                                                <form action='dap_stu_biodata.php' method='post'>
                                                    <input type='hidden' value='$regid' name='id'>
                                                    <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                                </form>
                                                </td>
                                                    
                                                </tr>\n";
                                                        }
                                                    }
                                                }
                                            }

                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                                <br><br>
                                <div style="text-align: right">
                                    <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                </div>


                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
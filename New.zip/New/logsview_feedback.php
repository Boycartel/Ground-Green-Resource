<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">



</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Logs Viewer</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Logs Viewer</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Logs Viewer
                        </div>
                        <div class="panel-body">
                            <!-- start: page -->
                            <div class="inner-toolbar clearfix">
                                <ul>

                                    <li>
                                        <ul class="nav nav-tabs">

                                            <li class="active"><a data-toggle="tab" href="#feedback"> Users Feedback</a>
                                            </li>
                                            <li class=""><a data-toggle="tab" href="#error-log">Error Log</a></li>
                                            <li class=""><a data-toggle="tab" href="#custom-log">Custom Log</a></li>
                                        </ul>

                                    </li>
                                </ul>
                            </div>
                            <br>
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                            if ($conn2->connect_error) {
                                die("Connection failed: " . $conn2->connect_error);
                            }

                            if (isset($_POST['delete'])) {
                                $id =  $_POST['id'];

                                $sql = "DELETE FROM feedback WHERE sn ='$id'";
                                $result = $conn->query($sql);
                            }
                            ?>
                            <section class="panel">
                                <div class="panel-body tab-content">
                                    <div id="feedback" class="tab-pane active">
                                        <table
                                            class="table table-striped table-bordered table-hover dataTables-example">
                                            <thead>
                                                <tr>
                                                    <th>SNo</th>
                                                    <th>User Name</th>
                                                    <th>User ID</th>
                                                    <th>email</th>
                                                    <th>Message</th>
                                                    <th>Date</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sql = "SELECT * FROM feedback ORDER BY date1 DESC";
                                                $result = $conn->query($sql);
                                                $sno = 0;
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $id = $row["sn"];
                                                        $fname = $row["fname"];
                                                        $regid = $row["regid"];
                                                        $email = $row["email"];
                                                        $message = $row["message"];
                                                        $date1 = $row["date1"];
                                                        echo "<tr><td>$sno</td><td>$fname</td><td>$regid</td><td>$email</td><td>$message</td><td>$date1</td>
												<td>
												<form action='' method='post'>
	                                                  <input type='hidden' value=$id name='id'>
	                                                  <input type='submit' name = 'delete' class='btn btn-danger btn-xs' value='Delete'>
	                                             </form>
	                                             </td
												</tr>";
                                                    }
                                                }
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
                                    <div id="error-log" class="tab-pane">

                                    </div>
                                    <div id="custom-log" class="tab-pane">

                                    </div>
                                </div>
                            </section>
                            <?php
                            $conn->close();
                            $conn2->close();
                            ?>
                            <!-- end: page -->

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <script>
    $(document).ready(function() {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [{
                    extend: 'copy'
                },
                {
                    extend: 'csv'
                },
                {
                    extend: 'excel',
                    title: 'ExampleFile'
                },
                {
                    extend: 'pdf',
                    title: 'ExampleFile'
                },

                {
                    extend: 'print',
                    customize: function(win) {
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });

    });
    </script>

</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_validation'] == false) {
    header('Location: Home_Staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_Val.js"></script>


    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php
    $dept = $_SESSION['deptcode'];
    $_SESSION['loadformval'] = "YES";
    //$cat = $_SESSION['cat'];
    $corntsession = $_SESSION['corntsession'];
    //$staflevel = $_SESSION['staflevel'];
    $GetTitle = "List of Validated Students";

    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
    if ($conn_stu->connect_error) {
        die("Connection failed: " . $conn_stu->connect_error);
    }
    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Validation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>
                            <li>
                                Course Validation
                            </li>
                            <li class="active">
                                <strong>Validated List</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Validation
                            <?php echo " " . $_SESSION['corntsession'] . " " ?>Session
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <form class="form-horizontal" method="post" action="course_validation.php">
                                    <table id="myTable" class="table mb-none" style="font-size:15px" summary="" rules="groups" frame="hsides" border="2">
                                        <caption><?php echo $GetTitle ?></caption>
                                        <colgroup align="center"></colgroup>
                                        <colgroup align="left"></colgroup>
                                        <colgroup span="2"></colgroup>
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Matric No.</th>
                                                <th>Name</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $dept = $_SESSION["deptcode"];
                                            $sno = 0;

                                            if ($cat_HOD == "YES") {
                                                $sql = "SELECT * FROM hod_list WHERE HOD = 'Validate' AND Session1 = '$corntsession'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $matno = $row['matricno'];
                                                        $names = $row["name1"];
                                                        $sno++;

                                                        echo "<tr><td>$sno</td><td>$matno</td><td>$names</td></tr>\n";
                                                    }
                                                }
                                            } else {
                                                if ($cat_L100 == "YES") {
                                                    $sql = "SELECT * FROM hod_list WHERE  StuLevel = '100' AND LevelAdvice = 'Validate' AND Session1 = '$corntsession'";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $matno = $row['matricno'];
                                                            $names = $row["name1"];
                                                            $sno++;

                                                            echo "<tr><td>$sno</td><td>$matno</td><td>$names</td></tr>\n";
                                                        }
                                                    }
                                                }

                                                if ($cat_L200 == "YES") {
                                                    $sql = "SELECT * FROM hod_list WHERE  StuLevel = '200' AND LevelAdvice = 'Validate' AND Session1 = '$corntsession'";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $matno = $row['matricno'];
                                                            $names = $row["name1"];
                                                            $sno++;

                                                            echo "<tr><td>$sno</td><td>$matno</td><td>$names</td></tr>\n";
                                                        }
                                                    }
                                                }

                                                if ($cat_L300 == "YES") {
                                                    $sql = "SELECT * FROM hod_list WHERE  StuLevel = '300' AND LevelAdvice = 'Validate' AND Session1 = '$corntsession'";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $matno = $row['matricno'];
                                                            $names = $row["name1"];
                                                            $sno++;

                                                            echo "<tr><td>$sno</td><td>$matno</td><td>$names</td></tr>\n";
                                                        }
                                                    }
                                                }

                                                if ($cat_L400 == "YES") {
                                                    $sql = "SELECT * FROM hod_list WHERE  StuLevel = '400' AND LevelAdvice = 'Validate' AND Session1 = '$corntsession'";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $matno = $row['matricno'];
                                                            $names = $row["name1"];

                                                            $sno++;

                                                            echo "<tr><td>$sno</td><td>$matno</td><td>$names</td></tr>\n";
                                                        }
                                                    }
                                                }

                                                if ($cat_L500 == "YES") {
                                                    $sql = "SELECT * FROM hod_list WHERE  StuLevel = '500' AND LevelAdvice = 'Validate' AND Session1 = '$corntsession'";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $matno = $row['matricno'];
                                                            $names = $row["name1"];
                                                            $sno++;

                                                            echo "<tr><td>$sno</td><td>$matno</td><td>$names</td></tr>\n";
                                                        }
                                                    }
                                                }

                                                if ($cat_spill_over == "YES") {
                                                    $sql = "SELECT * FROM hod_list WHERE  StuLevel = '600' AND LevelAdvice = 'Validate' AND Session1 = '$corntsession'";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $matno = $row['matricno'];
                                                            $names = $row["name1"];
                                                            $sno++;

                                                            echo "<tr><td>$sno</td><td>$matno</td><td>$names</td></tr>\n";
                                                        }
                                                    }
                                                }
                                            }


                                            ?>
                                        </tbody>
                                    </table>
                                    <br><br>
                                    <div class="form-group">
                                        <!-- Buttons -->
                                        <div class="col-lg-offset-2 col-lg-9">
                                            <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                        </div>
                                    </div>
                                    <br>
                                </form>


                            </div>
                            <div class="col-lg-1">

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    $conn_stu->close();
    include_once 'includes/footer.php';
    ?>

</body>

</html>
<?php
require_once 'includes/db_connect.php';

require_once 'includes/check_validity.php';

if ($_SESSION['pg_course_setup'] == false) {
    header('Location: Home_Staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Validation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Validation</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Validation
                        </div>
                        <?php $_SESSION['loadformval'] = "YES"; ?>
                        <div class="panel-body">
                            <div>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="row">
                                        <div class="form-group">
                                            <div class="col-lg-1">
                                            </div>
                                            <div class="col-lg-3">
                                                <input type="radio" name="validation" value="validated"> Validated
                                            </div>
                                            <div class="col-lg-3">
                                                <input type="radio" name="validation" value="yetvalidate"> Yet to
                                                Validate
                                            </div>
                                            <div class="col-lg-2">
                                                <input type="radio" name="validation" value="all" checked> All
                                            </div>
                                            <div class="col-lg-3">
                                                <?php
                                                if ($cat_PG_Coord == "YES") {
                                                    echo "<a class='' href='validation_list_pg.php'>Get Validated List</a>";
                                                }
                                                ?>

                                            </div>
                                        </div>
                                    </div>
                                    <hr class="separator" />
                                    <div class="row">

                                        <div class="form-group">
                                            <label class="control-label col-lg-3" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-6">
                                                <select class="country form-control" style="color:#000000" name="dept">

                                                    <?php
                                                    $_SESSION['valdept'] = "";
                                                    //$cat = $_SESSION['cat'];

                                                    //$_SESSION['cat'] = "PG";
                                                    $schcode = $_SESSION['schcode'];
                                                    $dept = $_SESSION['deptcode'];
                                                    if ($cat_PG_Coord == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                    } else {
                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    }

                                                    $result = $conn5->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = $row["DeptCode"];
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }

                                                    ?>

                                                </select>

                                            </div>
                                            <div class="col-lg-3">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>


                                    </div>


                                </form>
                            </div>

                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"]) || isset($_POST["validate"])) { ?>
                                <div class="col-lg-12  col-md-12">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <section class="panel panel-success">
                                            <header class="panel-heading">
                                                <div class="panel-actions">
                                                    <a href="#" class="fa fa-caret-down"></a>
                                                    <a href="#" class="fa fa-times"></a>
                                                </div>

                                                <h2 class="panel-title"> Course Validation
                                                    <?php echo " " . $_SESSION['corntsession'] . " " ?>Session</h2>
                                            </header>
                                            <div class="panel-body">


                                                <div class="col-lg-3">
                                                    <?php
                                                        $valregid = $valname = $valcoment = $valcat = "";

                                                        //$cat = $_SESSION['cat'];
                                                        $corntsession = $_SESSION['corntsession'];
                                                        $staffid = $_SESSION['staffid'];

                                                        //$staflevel = $_SESSION['staflevel'];
                                                        if (isset($_POST["submit"])) {
                                                            $dept = strtolower($_POST["dept"]);
                                                            $valoption = $_POST["validation"];

                                                            $_SESSION['loadformval'] = "NO";
                                                            $_SESSION['valoption'] = $valoption;
                                                            $_SESSION['valcoment'] = "";
                                                        }

                                                        if (isset($_POST["validate"])) {
                                                            //if($_SESSION['loadformval']=="YES"){

                                                            //}else{
                                                            $valregid = $_POST["valregid"];
                                                            $valcat = $_POST["valcat"];
                                                            $getvalcat = $_POST["getvalcat"];
                                                            $getfieldcomt = $_POST["getfieldcomt"];
                                                            if ($_POST["comment"] == "") {
                                                                $comment = "_";
                                                            } else {
                                                                $comment = str_replace("'", "", $_POST["comment"]);
                                                                $comment = filter_var($comment, FILTER_SANITIZE_STRING);
                                                            }


                                                            $sql = "SELECT * FROM e_data_profile WHERE regid = '$valregid'";
                                                            $result = $conn4->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $stdid =  $row["stdid"];
                                                                }
                                                            }

                                                            $sql = "SELECT * FROM reg_password WHERE stdid = '$stdid'";
                                                            $result = $conn4->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $valname = $row["CandName"];
                                                                }
                                                            }

                                                            $valgetval = $_POST["valcoment"];
                                                            if ($_POST["valcoment"] == "Yet") {
                                                                $_SESSION['valcoment'] = "Validation Cancel, Select next Matric No.";
                                                            } else {
                                                                $_SESSION['valcoment'] = "Validated, Select next Matric No.";
                                                            }

                                                            //echo $getvalcat.", ";
                                                            //echo $valgetval.", ";
                                                            //echo $getfieldcomt;

                                                            $sql = "UPDATE " . $dept . "_hod_list SET LevelAdvice = '$valgetval', LAComment = '$comment' WHERE matricno = '$valregid' AND Session1 = '$corntsession'";
                                                            $result = $conn5->query($sql);
                                                            //}

                                                        }
                                                        //echo $dept;
                                                        $_SESSION['valdept'] = $dept;

                                                        ?>
                                                    <select name="courses" class="form-control" style="color:#000000"
                                                        id="courses" size="20" onChange="showUser(this.value)">
                                                        <?php
                                                            if ($_SESSION['valoption'] == "validated") {
                                                                $sql = "SELECT * FROM " . $dept . "_hod_list WHERE Session1 = '$corntsession' AND LevelAdvice = 'Validate' ORDER BY matricno";
                                                            } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                $sql = "SELECT * FROM " . $dept . "_hod_list WHERE Session1 = '$corntsession'  AND LevelAdvice = 'Yet' ORDER BY matricno";
                                                            } elseif ($_SESSION['valoption'] == "all") {
                                                                $sql = "SELECT * FROM " . $dept . "_hod_list WHERE Session1 = '$corntsession'  AND LevelAdvice = 'Yet' OR LevelAdvice = 'Validate' ORDER BY matricno";
                                                            }

                                                            $result = $conn5->query($sql);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $matricno = $row["matricno"];
                                                                    if ($matricno == $valregid) {
                                                                        echo "<option value=$matricno selected>$matricno</option>";
                                                                    } else {
                                                                        echo "<option value=$matricno>$matricno</option>";
                                                                    }
                                                                }
                                                            }
                                                            //$conn->close();
                                                            //$mysqli->close();

                                                            ?>


                                                    </select>


                                                </div>
                                                <div class="col-lg-9" style="color:#000">

                                                    <center><strong> <?php echo $valregid ?></strong></center>
                                                    <center><strong> <?php echo $valname ?></strong></center>
                                                    <center><strong> <?php echo $_SESSION['valcoment'] ?></strong>
                                                    </center>

                                                    <div id="txtHint"></div>
                                                    <br>

                                                </div>

                                            </div>

                                        </section>


                                    </div>
                                    <div class="col-lg-1">

                                    </div>


                                </div>



                                <?php } ?>

                            </div>
                            <!-- end: page -->


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>

        <script>
        function showUser(str) {
            if (str == "") {
                document.getElementById("txtHint").innerHTML = "";
                return;
            } else {
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("txtHint").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "course_validation_inc_pg.php?q=" + str, true);
                xmlhttp.send();
            }
        }
        </script>
</body>

</html>
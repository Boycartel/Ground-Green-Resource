<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$month = "march";
$year = "2022";
$sql = "SELECT * FROM payslip_emaillist ORDER BY PSN";
$sno = 0;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$PSN = $row["PSN"];
		$email = $row["email"];

		// just edit these 
		$to          = $email; // addresses to email pdf to
		$from        = "payslip@futminna.edu.ng"; // address message is sent from
		$subject     = $month . ", " . $year . " Payslip"; // email subject
		$body        = "<p>Find attached " . $month . ", " . $year . " Payslip</p>"; // email body
		$pdfLocation = "payslip/" . $PSN . ".pdf"; // file location
		$pdfName     = "Payslip.pdf"; // pdf file name recipient will get
		$filetype    = "application/pdf"; // type

		// creates headers and mime boundary
		$eol = PHP_EOL;
		$semi_rand     = md5(time());
		$mime_boundary = "==Multipart_Boundary_$semi_rand";
		$headers       = "From: $from$eolMIME-Version: Payslip$eol" .
			"Content-Type: multipart/mixed;$eol boundary=\"$mime_boundary\"";

		// add html message body
		$message = "--$mime_boundary$eol" .
			"Content-Type: text/html; charset=\"iso-8859-1\"$eol" .
			"Content-Transfer-Encoding: 7bit$eol$eol$body$eol";

		// fetches pdf
		$file = fopen($pdfLocation, 'rb');
		$data = fread($file, filesize($pdfLocation));
		fclose($file);
		$pdf = chunk_split(base64_encode($data));

		// attaches pdf to email
		$message .= "--$mime_boundary$eol" .
			"Content-Type: $filetype;$eol name=\"$pdfName\"$eol" .
			"Content-Disposition: attachment;$eol filename=\"$pdfName\"$eol" .
			"Content-Transfer-Encoding: base64$eol$eol$pdf$eol--$mime_boundary--";

		// Sends the email
		if (mail($to, $subject, $message, $headers)) {
			echo $PSN . " sent,";
		} else {
			echo $PSN . "NOT Sent,";
		}
	}
}

$conn->close();

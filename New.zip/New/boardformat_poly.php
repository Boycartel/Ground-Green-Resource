<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['board_format'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php $_SESSION['instcode'] ?> Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword" content="Results, Result, eresults, e-results, portal">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>

    <style>
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }
    </style>


    <style>
        .btn-xs,
        .btn-group-xs>.btn {
            padding: 1px 5px;
            font-size: 11px;
            line-height: 1.5;
            border-radius: 3px;
        }
    </style>


    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';

    ?>
</head>

<body>
    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
        <form class="form-horizontal form-bordered" method="post">

            <div class="row">
                <h2 class="panel-title" style="text-align: center">EXAMINATION RESULTS BROADSHEET REPORT</h2>
                <br><br><br>
                <div class="col-lg-4">
                    <div class="row">
                        <label class="control-label col-lg-5" for="content">Select Department:</label>
                        <div class="col-lg-7">
                            <select class="country form-control" style="color:#000000" name="dept">
                                <option value="SelectItem">Select Item</option>
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }


                                $dept = $_SESSION['deptcode'];


                                if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                } else {
                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                }


                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $deptcode2 = strtolower($row["DeptCode"]);
                                        $deptname2 = $row["DeptName"];
                                        echo "<option value=$deptcode2>$deptname2</option>";
                                    }
                                }
                                $conn->close();
                                ?>

                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="row">
                        <label class="control-label col-lg-5" for="regid">Level:</label>
                        <div class="col-lg-7">
                            <select name="getlevel" class="form-control" style="color:#000000" id="getlevel">
                                <option value="100">ND I</option>
                                <option value="200">ND II</option>
                                <option value="300">HND I</option>
                                <option value="400">HND II</option>


                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="row">
                        <label class="control-label col-lg-5" for="regid">Session:</label>
                        <div class="col-lg-7">
                            <?php
                            $iniyear = 2015;
                            $finalyear = substr($_SESSION['corntsession'], 5);

                            ?>
                            <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                    <?php echo $_SESSION['corntsession'] ?></option>
                                <?php
                                while ($iniyear <= $finalyear) {
                                    $addyear = $iniyear + 1;

                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                    $iniyear++;
                                }

                                ?>


                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="row">
                        <label class="control-label col-lg-6" for="regid">Semester:</label>
                        <div class="col-lg-6">
                            <select name="getsemester" class="form-control" style="color:#000000" id="getsemester">
                                <option value="1ST">1ST</option>
                                <option value="2ND">2ND</option>

                            </select>
                        </div>

                    </div>
                </div>
                <div class="col-lg-2">
                    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>

            </div>
        </form>
        <hr class="separator" />
        <?php if (isset($_POST["submit"])) { ?>
            <?php
            $_SESSION['dept_sctny'] = $_POST["dept"];
            $_SESSION['getsession_sctny'] = $_POST["getsession"];
            $_SESSION['getsemester_sctny'] = $_POST["getsemester"];
            $_SESSION['getlevel_sctny'] = $_POST["getlevel"];
            $dept = $_SESSION['dept_sctny'];
            ?>
            <form class="form-horizontal form-bordered" method="post">
                <div class="row">
                    <div class="col-lg-4" style="text-align: right;">
                        <label class="control-label" for="regid">Select Department Option:</label>
                    </div>

                    <div class="col-lg-4">
                        <select name="getoptn" class="form-control" style="color:#000000" id="getgroup">
                            <option value="NOP">No Option</option>
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept' AND Opt_Code <> 'NOP' ORDER BY Opt_Title";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $Opt_Code = $row["Opt_Code"];
                                    $Opt_Title = $row["Opt_Title"];
                                    echo "<option value=$Opt_Code>$Opt_Title</option>";
                                }
                            }
                            $conn->close();
                            ?>
                        </select>
                    </div>
                    <div class="col-lg-2">
                        <button type="submit" name="submitopt" class="btn btn-primary btn-sm">Submit</button>
                    </div>

                </div>
            </form>
        <?php } ?>

        <?php if (isset($_POST["submitopt"])) { ?>
            <?php
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }


            $_SESSION['dept_option'] = $_POST["getoptn"];
            $deptopt = $_SESSION['dept_option'];
            $dept = $_SESSION['dept_sctny'];
            if ($_SESSION['getlevel_sctny'] == "100" || $_SESSION['getlevel_sctny'] == "200") {
                $prog = "ND";
            } else {
                $prog = "HND";
            }
            ?>
            <form class="form-horizontal form-bordered" method="post">
                <div class="row">
                    <div class="col-lg-4" style="text-align: right;">
                        <label class="control-label" for="regid">Select Group:</label>
                    </div>

                    <div class="col-lg-4">
                        <select name="getgroup" class="form-control" style="color:#000000">
                            <option value='NG'>No Group</option>
                            <?php
                            $sql = "SELECT * FROM dept_stu_group WHERE deptcode = '$dept' AND PROG = '$prog' AND deptoption = '$deptopt' AND group_Title <> 'No Group'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $group_Code = $row["group_Code"];
                                    $group_Title = $row["group_Title"];
                                    echo "<option value=$group_Code>$group_Title</option>";
                                }
                            }
                            $conn->close();
                            ?>
                        </select>
                    </div>
                    <div class="col-lg-2">
                        <button type="submit" name="submitgroup" class="btn btn-primary btn-sm">Submit</button>

                    </div>

                </div>
            </form>
        <?php } ?>


        <hr class="separator" />
    </div>

    <div style="padding-left:3em; padding-right: 3em">
        <?php
        set_time_limit(500);

        if (isset($_POST["submitAll"])) {
            $getstatus = $_POST["getstatus"];
            $getdept = $_SESSION['dept_sctny'];
            $getsession = $_SESSION['getsession_sctny'];
            $getsemester = $_SESSION['getsemester_sctny'];
            $getlevel = $_SESSION['getlevel_sctny'];
            $getgroup = $_SESSION['getgroup'];
            $dept_option = $_SESSION['dept_option'];

            $deptdb = $_SESSION['deptdb'];
            $dept_db = $deptdb . strtolower($getdept);
            //$dept_db = "poly_dept_" . $getdept;
            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
            if ($conn_stu->connect_error) {
                die("Connection failed: " . $conn_stu->connect_error);
            }

            $sql2 = "UPDATE scrutiny_senate SET board_aproval = '$getstatus' WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND stu_group = '$getgroup' AND DeptOpt = '$dept_option' AND secrutiny_aproval <> 'Approve'";
            $result2 = $conn_stu->query($sql2);
            $conn_stu->close();
        }

        ?>
        <?php if (isset($_POST["submitgroup"])) { ?>
            <?php
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
            if ($conn2->connect_error) {
                die("Connection failed: " . $conn2->connect_error);
            }

            set_time_limit(1000);
            $DegType = $_SESSION['DegType'];

            $getdept = $_SESSION['dept_sctny'];
            $getsession = $_SESSION['getsession_sctny'];
            $getsemester = $_SESSION['getsemester_sctny'];
            $getlevel = $_SESSION['getlevel_sctny'];
            $_SESSION['getgroup'] = $_POST["getgroup"];
            $getgroup = $_SESSION['getgroup'];
            $dept_option = $_SESSION['dept_option'];

            //echo $getdept . "<br>" . $getsession . "<br>" . $getsemester . "<br>" . $getlevel . "<br>" . $getgroup . "<br>" . $dept_option;

            $_SESSION['sn'] = 0;

            $deptname = "";



            $sql = "SELECT DeptName, DeptCode, School FROM deptcoding WHERE DeptCode = '$getdept'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $deptname = $row["DeptName"];
                    $schcode = $row["School"];
                }
            }

            $sql = "SELECT * FROM schoolname WHERE SchCode = '$schcode'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $schname = $row["SchName"];
                }
            }

            if ($_SESSION['getlevel_sctny'] == 100 || $_SESSION['getlevel_sctny'] == 300) {
                if ($getsemester == "1ST") {
                    $contactSem = "1<sup>st</sup>";
                } else {
                    $contactSem = "2<sup>nd</sup>";
                }
            } elseif ($_SESSION['getlevel_sctny'] == 200 || $_SESSION['getlevel_sctny'] == 400) {
                if ($getsemester == "1ST") {
                    $contactSem = "3<sup>rd</sup>";
                } else {
                    $contactSem = "4<sup>th</sup>";
                }
            }
            ?>
            <section class="panel panel-success">
                <!--<div style="text-align: center"><h2 class="panel-title"><?php /*echo $deptname */ ?> Department</h2></div>
                <br><br>-->
                <div class="panel-body">
                    <form class="form-horizontal form-bordered" method="post">
                        <div class="row">
                            <div class="col-lg-6">

                            </div>
                            <label class="control-label col-lg-2" for="regid">Select Status:</label>
                            <div class="col-lg-3">
                                <select name="getstatus" class="form-control" style="color:#000000" id="getstatus" required>
                                    <option value='Yet'>Yet</option>
                                    <option value='Approve'>Approve</option>
                                    <option value='Not Approve'>Not Approve</option>

                                </select>

                            </div>
                            <div class="col-lg-1" style="text-align: right">
                                <button type="submit" name="submitAll" class="btn btn-primary btn-xs">Submit All
                                </button>
                            </div>
                        </div>
                    </form>

                    <hr class="separator" />
                    <br>
                    <div class="col-lg-12">
                        <?php

                        $deptdb = $_SESSION['deptdb'];
                        $dept_db = $deptdb . strtolower($getdept);
                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                        if ($conn_stu->connect_error) {
                            die("Connection failed: " . $conn_stu->connect_error);
                        }


                        $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;
                        unset($LblCodeArray);
                        $LblCodeArray[] = "";
                        unset($CourseCodeArray);
                        $CourseCodeArray[] = "";
                        unset($CourseUnitArray);
                        $CourseUnitArray[] = "";

                        unset($CourseCodeArray2);
                        $CourseCodeArray2[] = "";

                        $countCCode = 0;
                        $countCCode2 = 0;

                        $deptgencourses = "gencourses";

                        $sql = "SELECT DISTINCT CCode, session1, Level1, DeptCode, SemTaken, levelCode, split_two, CUnit FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {

                                $C_codding = $row["CCode"];

                                $sql2 = "SELECT Core, semester FROM gencourses WHERE C_codding = '$C_codding'";
                                $result2 = $conn_stu->query($sql2);
                                if ($result2->num_rows > 0) {
                                    while ($row2 = $result2->fetch_assoc()) {
                                        $Core = $row2["Core"];
                                        $semester = $row2["semester"];
                                    }
                                }
                                if ($semester == $getsemester) {
                                    $countCCode++;
                                    $CourseCodeArray[$countCCode] = $row["CCode"];
                                    $CCode = $row["split_two"];
                                    $LblCodeArray[$countCCode] = $CCode;
                                    if ($Core == "YES") {
                                        $CourseUnitArray[$countCCode] = $row["CUnit"] . '  C';
                                    } else {
                                        $CourseUnitArray[$countCCode] = $row["CUnit"] . '  E';
                                    }
                                }
                            }
                        }


                        $sql = "SELECT DISTINCT CCode, session1, Level1, DeptCode, SemTaken, levelCode, split_two, CUnit FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {

                                $C_codding = $row["CCode"];

                                $sql2 = "SELECT Core, semester FROM gencourses WHERE C_codding = '$C_codding'";
                                $result2 = $conn_stu->query($sql2);
                                if ($result2->num_rows > 0) {
                                    while ($row2 = $result2->fetch_assoc()) {
                                        $Core = $row2["Core"];
                                        $semester = $row2["semester"];
                                    }
                                }
                                if ($semester !== $getsemester) {
                                    $countCCode++;
                                    $CourseCodeArray[$countCCode] = $row["CCode"];
                                    $CCode = $row["split_two"];
                                    $LblCodeArray[$countCCode] = $CCode;
                                    if ($Core == "YES") {
                                        $CourseUnitArray[$countCCode] = $row["CUnit"] . '  C';
                                    } else {
                                        $CourseUnitArray[$countCCode] = $row["CUnit"] . '  E';
                                    }
                                }
                            }
                        }


                        if ($_SESSION['getlevel_sctny'] == 100) {
                            $gLevel = "ND I";
                        } elseif ($_SESSION['getlevel_sctny'] == 200) {
                            $gLevel = "ND II";
                        } elseif ($_SESSION['getlevel_sctny'] == 300) {
                            $gLevel = "HND I";
                        } elseif ($_SESSION['getlevel_sctny'] == 400) {
                            $gLevel = "HND II";
                        }
                        //echo $numbelemt . "<br>";
                        if ($getlevel == 100 || $getlevel == 200) {
                            $progtype = "ND";
                        } else {
                            $progtype = "HD";
                        }

                        $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND stu_group = '$getgroup' AND DeptOpt = '$dept_option' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";
                        //$sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' ORDER BY Regn";
                        $result = $conn_stu->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $codeyearadmt = substr($row["yearadmt"], 2, 2);
                                break;
                            }
                        }

                        if ($getgroup == "G10" || $getgroup == "G20") {
                            $Gcode = $getgroup;
                        } else {
                            $Gcode = str_replace("0", "", $getgroup);
                        }

                        if ($getgroup == "NG") {
                            $Gcode = "G1";
                        }
                        $stugroupcode = strtoupper($getdept) . $progtype . $codeyearadmt . $Gcode;

                        ?>
                        <table class="table table-striped">
                            <thead style='text-align:center'>
                                <tr>
                                    <th colspan="2">
                                        <img src="img/logo.ico" height="120" width="120" alt="Logo" />
                                    </th>
                                    <th colspan="<?php echo $countCCode + 7 ?>">
                                        <table>
                                            <tr>
                                                <th style="font-size: xx-large; text-align:left">
                                                    <?php echo $_SESSION['instname'] ?></th>
                                            </tr>
                                            <tr>
                                                <th style="font-size: large; text-align:left">SCHOOL OF
                                                    <?php echo strtoupper($schname) ?>, DEPARTMENT OF
                                                    <?php echo strtoupper($deptname) ?>
                                                </th>
                                            </tr>
                                            <tr>
                                                <th style="text-align:left">
                                                    <?php if ($_SESSION['getlevel_sctny'] == 100 || $_SESSION['getlevel_sctny'] == 200) { ?>
                                                        NATIONAL DIPLOMA PROGRAMME, *
                                                    <?php } else { ?>
                                                        HIGHER NATIONAL DIPLOMA PROGRAMME, *
                                                    <?php } ?>
                                                    (<?php echo $gLevel ?> [FT-*/REGULAR]),
                                                    <?php echo $contactSem ?>
                                                    SEMESTER, <?php echo $_SESSION['getsession_sctny']; ?> SESSION</th>
                                            </tr>
                                            <tr>
                                                <th style="font-size: x-large; text-align:left">EXAMINATION RESULTS
                                                    BROADSHEET REPORT - MONTH/YEAR OF GRADUATION</th>
                                            </tr>
                                        </table>
                                    </th>
                                </tr>
                                <tr>
                                    <th colspan="2" style="border: 1px solid;">Date: <?php echo date("d F, Y") ?></th>
                                    <th colspan="<?php echo $countCCode ?>" style="border: 1px solid;">Courses Examined
                                        (Core and Electives)</th>
                                    <th colspan="5" style="border: 1px solid;">Summaries</th>
                                    <th colspan="2" style="border: 2px solid;"><?php echo $stugroupcode ?></th>
                                    <th colspan="2" style="border: 1px solid;"></th>
                                </tr>
                                <tr>
                                    <th colspan="2" style="border: 1px solid; text-align:left">Course<br> Code<br>
                                        Units/Status</th>
                                    <?php for ($i = 1; $i <= $countCCode; $i++) { ?>
                                        <th style="border: 1px solid;">
                                            <?php echo $LblCodeArray[$i] . "<br>" . $CourseUnitArray[$i] ?></th>
                                    <?php } ?>
                                    <th colspan="5" style="border: 1px solid;">Previous Semesters<br>
                                        Current Semester<br>
                                        Cumulative</th>
                                    <th colspan="2" style="border: 1px solid;">Academic
                                        Standing</th>
                                    <th colspan="2" style="border: 1px solid;"></th>
                                </tr>
                                <tr>
                                    <th style="border: 1px solid;">S/ No</th>
                                    <th style="border: 1px solid;">Matric_No/ Name</th>
                                    <th colspan="<?php echo $countCCode ?>" style="border: 1px solid;">Scores (%), Letter
                                        Grades and Weighted Grade
                                        Points</th>


                                    <th style="border: 1px solid;">TUA</th>
                                    <th style="border: 1px solid;">TUP</th>
                                    <th style="border: 1px solid;">TGP</th>
                                    <th style="border: 1px solid;">GPA</th>
                                    <th style="border: 1px solid;">TUO</th>
                                    <th style="border: 1px solid;">Past</th>

                                    <th style="border: 1px solid;">Curr</th>

                                    <th style="border: 1px solid;">Approval</th>
                                    <th style="border: 1px solid;">Comment</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sno = 0;
                                $DEFCount = 0;
                                $IGSCount = 0;
                                $SP1Count = 0;
                                $SP2Count = 0;
                                $PCount = 0;
                                $DLCount = 0;
                                $VCLCount = 0;
                                $Ten88Count = 0;
                                $BL2Count = 0;



                                $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND stu_group = '$getgroup' AND DeptOpt = '$dept_option' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";
                                //$sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $sno++;
                                        $regid = $row["Regn"];
                                        $names = $row["Name1"];
                                        $fname = strtoupper($row["fname"]);
                                        $sname = strtoupper($row["sname"]);
                                        $oname = strtoupper($row["oname"]);
                                        //$sex = $row["sex"];
                                        if ($row["sex"] == "Male") {
                                            $sex = "M";
                                        } elseif ($row["sex"] == "Female") {
                                            $sex = "F";
                                        } else {
                                            $sex = $row["sex"];
                                        }
                                        $id = $row["sn"];
                                        $aproval = $row['board_aproval'];
                                        $coment = $row["board_comment"];

                                        $defout = $def = $out = $rmk = $grade = $COcourses = "";


                                        $unit = $ptct = $ptcp = $pgp = $pcgpa = $stct = $stcp = $sgp = $scgpa = $tct = $tcp = $tgp = $cgpa = 0;

                                        $ptct = $row['PCT'];
                                        $ptcp = $row['PCP'];
                                        $pgp = $row['PGP'];
                                        $pcgpa = $row['PCGPA'];

                                        $stct = $row['SCT'];
                                        $stcp = $row['SCP'];
                                        $sgp = $row['SGP'];
                                        $scgpa = $row['SGPA'];
                                        $tct = $row['TCT'];
                                        $tcp = $row['TCP'];
                                        $tgp = $row['CGP'];
                                        $cgpa = $row['CGPA'];

                                        $sem_C_F = $row['sem_C_F'];
                                        $prev_C_F = $row['prev_C_F'];
                                        $cum_C_F = $row['cum_C_F'];
                                        $numb_Course_failed = $row['numb_Course_failed'];

                                        $rmk = $row['RMK'];
                                        $defout = $row['def_out'];

                                        $defout1ST = "";
                                        if ($getsemester == "2ND") {
                                            $sql2 = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '1ST' AND Regn = '$regid'";
                                            $result2 = $conn_stu->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $defout1ST = $row2['def_out'];
                                                }
                                            }
                                        }


                                        if ($rmk == "P") {
                                            $PCount++;
                                        } elseif ($rmk == "IGS") {
                                            $IGSCount++;
                                        } elseif ($rmk == "DEF") {
                                            $DEFCount++;
                                        } elseif ($rmk == "SP1") {
                                            $SP1Count++;
                                        } elseif ($rmk == "SP2") {
                                            $SP2Count++;
                                        } elseif ($rmk == "DL") {
                                            $DLCount++;
                                        } elseif ($rmk == "VL") {
                                            $VCLCount++;
                                        } elseif ($rmk == "8-7-6") {
                                            $Ten88Count++;
                                        } elseif ($rmk == "BL2") {
                                            $BL2Count++;
                                        }

                                        if ($scgpa >= 3.495) {
                                            if (empty($defout)) {
                                                $dclasscode = "RHL";
                                                $COcourses = "PASSED";
                                            } else {
                                                $COcourses = $defout;
                                                $dclasscode = "COV";
                                            }
                                        } elseif ($scgpa >= 3.245) {
                                            if (empty($defout)) {
                                                $dclasscode = "DHL";
                                                $COcourses = "PASSED";
                                            } else {
                                                $COcourses = $defout;
                                                $dclasscode = "COV";
                                            }
                                        } elseif ($scgpa >= 2) {
                                            if ($cgpa >= 2) {
                                                if ($defout == "") {
                                                    $dclasscode = "PAS";
                                                    $COcourses = "PASSED";
                                                } else {
                                                    $COcourses = $defout;
                                                    $dclasscode = "COV";
                                                }
                                            } else {
                                                if ($defout == "") {
                                                    $COcourses = "PASSED";
                                                } else {
                                                    $COcourses = $defout;
                                                }
                                                $dclasscode = "WAR";
                                            }
                                        } else {
                                            if ($cgpa >= 2) {
                                                if ($defout == "") {
                                                    $COcourses = "PASSED";
                                                } else {
                                                    $COcourses = $defout;
                                                }
                                                $dclasscode = "WAR";
                                            } else {
                                                if ($defout == "") {
                                                    $COcourses = "PASSED";
                                                } else {
                                                    $COcourses = $defout;
                                                }
                                                $dclasscode = "PRO";
                                            }
                                        }


                                        if ($row["no_semester"] > 3) {
                                            if ($defout == "") {
                                                include 'modulesInSess/classofdegree_inc.php';
                                                $dclass = $classdegree;
                                                $dclasscode = $classdegree_code;
                                            }
                                        }




                                        if ($row["no_semester"] > 3) {
                                            if ($pcgpa >= 3.5) {

                                                $prevdclasscode = "D";
                                            } elseif ($pcgpa >= 3) {

                                                $prevdclasscode = "U/C";
                                            } elseif ($pcgpa >= 2.5) {

                                                $prevdclasscode = "L/C";
                                            } elseif ($pcgpa >= 2) {

                                                $prevdclasscode = "PAS";
                                            } else {

                                                $prevdclasscode = "F";
                                            }
                                        } else {
                                            $prevdclasscode = "PAS";
                                        }

                                        if ($defout1ST == "") {
                                            if ($pcgpa >= 3.495) {
                                                $prevdclasscode = "RHL";
                                            } elseif ($pcgpa >= 3.245) {
                                                $prevdclasscode = "DHL";
                                            } else {
                                                $prevdclasscode = "PAS";
                                            }
                                        } else {
                                            $prevdclasscode = "COV";
                                        }


                                        if ($pcgpa < 1.5) {
                                            $prevdclasscode = "PRO";
                                        } elseif ($pcgpa < 2) {
                                            $prevdclasscode = "WAR";
                                        }

                                        if ($row["no_semester"] == 1) {
                                            $prevdclasscode = "-";
                                        }

                                        if ($row2["no_semester"] > 1) {
                                            if ($scgpa < 1.5 && $cgpa < 1) {
                                                $dclasscode++;
                                            }
                                        }


                                        $totalArray[] = "";
                                        $gradeArray[] = "";
                                        $pointArray[] = "";

                                        for ($i = 1; $i <= $countCCode; $i++) {
                                            $grade = "-";

                                            $StuCurSess = str_ireplace("/", "_", $getsession);
                                            $deptcorreg = "correg_" . $StuCurSess;
                                            $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND CCode  = '$CourseCodeArray[$i]' AND SemTaken = '$getsemester' AND SessionRegis =  '$getsession'";
                                            $result2 = $conn_stu->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $grade = $row2["grade"];
                                                    $CA = $row2["CA"];
                                                    $Exam = $row2["Exam"];
                                                    $gpoint = $row2["point"];
                                                    $total = $CA + $Exam;

                                                    $totalArray[$i] = $total;
                                                    $gradeArray[$i] = $grade;
                                                    $pointArray[$i] = $gpoint;
                                                }
                                            } else {
                                                $sql3 = "SELECT * FROM absent_students WHERE matric_no  = '$regid' AND CCode  = '$CourseCodeArray[$i]' AND semtaken = '$getsemester' AND session1 =  '$getsession'";
                                                $result3 = $conn_stu->query($sql3);
                                                if ($result3->num_rows > 0) {
                                                    while ($row3 = $result3->fetch_assoc()) {

                                                        if ($row3["status1"] == "R") {
                                                            $UploadUnit = $row3["CUnit"];
                                                            $getTotal = $row3["CA"] + $row3["Exam"];
                                                            $totalArray[$i] = $getTotal;
                                                            if ($getTotal >= 75) {
                                                                $gp = $UploadUnit * 4;
                                                                $grade = "A";
                                                            } elseif ($getTotal >= 70) {
                                                                $gp = $UploadUnit * 3.5;
                                                                $grade = "AB";
                                                            } elseif ($getTotal >= 65) {
                                                                $gp = $UploadUnit * 3.25;
                                                                $grade = "B";
                                                            } elseif ($getTotal >= 60) {
                                                                $gp = $UploadUnit * 3;
                                                                $grade = "BC";
                                                            } elseif ($getTotal >= 55) {
                                                                $gp = $UploadUnit * 2.75;
                                                                $grade = "C";
                                                            } elseif ($getTotal >= 50) {
                                                                $gp = $UploadUnit * 2.5;
                                                                $grade = "CD";
                                                            } elseif ($getTotal >= 45) {
                                                                $gp = $UploadUnit * 2.25;
                                                                $grade = "D";
                                                            } elseif ($getTotal >= 40) {
                                                                $gp = $UploadUnit * 2;
                                                                $grade = "E";
                                                            } else {
                                                                $gp = $UploadUnit * 0;
                                                                $grade = "F";
                                                            }
                                                            $gradeArray[$i] = $grade;
                                                            $pointArray[$i] = $gp;
                                                        } else {
                                                            if ($row3["status1"] == "X") {
                                                                $totalArray[$i] = "ABS";
                                                            } elseif ($row3["status1"] == "D") {
                                                                $totalArray[$i] = "DEF";
                                                            } elseif ($row3["status1"] == "I") {
                                                                $totalArray[$i] = "INC";
                                                            } elseif ($row3["status1"] == "S") {
                                                                $totalArray[$i] = "SIC";
                                                            } elseif ($row3["status1"] == "N") {
                                                                $totalArray[$i] = "NA";
                                                            }

                                                            $gradeArray[$i] = "";
                                                            $pointArray[$i] = "";
                                                        }
                                                    }
                                                } else {
                                                    $totalArray[$i] = "";
                                                    $gradeArray[$i] = "";
                                                    $pointArray[$i] = "";
                                                }
                                            }
                                        }

                                        $pcgpa = number_format($row['PCGPA'], 2, '.', ',');
                                        $scgpa = number_format($row['SGPA'], 2, '.', ',');
                                        $cgpa = number_format($row['CGPA'], 2, '.', ',');

                                        $colaprows = $countCCode + 7;


                                        echo "<tr><td style='border-left: 1px solid;'>$sno</td><td style='border-left: 1px solid;'>$regid</td>";
                                        for ($j = 1; $j <= $countCCode; $j++) {

                                            echo "<td style='border-left: 1px solid;'>$totalArray[$j]</td>";
                                        }
                                        echo "<td style='border-left: 1px solid;'>$ptct</td><td style='border-left: 1px solid;'>$ptcp</td><td style='border-left: 1px solid;'>$pgp</td><td style='border-left: 1px solid;'>$pcgpa</td><td style='border-left: 1px solid;'>$prev_C_F</td><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid;'></td>";
                                        echo "<td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; border-right: 1px solid;'></td>";


                                        echo "</tr>";
                                        echo "<tr><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; text-align: right'>$sex</td>";
                                        for ($j = 1; $j <= $countCCode; $j++) {
                                            echo "<td style='border-left: 1px solid;'>$gradeArray[$j]</td>";
                                        }
                                        echo "<td style='border-left: 1px solid;'>$stct</td><td style='border-left: 1px solid;'>$stcp</td><td style='border-left: 1px solid;'>$sgp</td><td style='border-left: 1px solid;'>$scgpa</td><td style='border-left: 1px solid;'>$sem_C_F</td><td style='border-left: 1px solid;'>$prevdclasscode</td><td style='border-left: 1px solid;'>$dclasscode</td>";

                                        echo '<td style="border-left: 1px solid;"><a href="#" class="board_aproval" id="board_aproval_' . $row["sn"] . '" data-type="select" data-pk="' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="board_aproval">' . $row["board_aproval"] . '</a></td>
                                           <td style="border-left: 1px solid; border-right: 1px solid;"><a href="#" class="board_comment" id="board_comment_' . $row["sn"] . '" data-type="text" data-pk = "' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="board_comment">' . $row["board_comment"] . '</a></td>
                                          ';
                                        echo "</tr>";
                                        echo "<tr><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid;'>$sname</td>";
                                        for ($j = 1; $j <= $countCCode; $j++) {
                                            echo "<td style='border-left: 1px solid;'>$pointArray[$j]</td>";
                                        }
                                        echo "<td style='border-left: 1px solid;'>$tct</td><td style='border-left: 1px solid;'>$tcp</td><td style='border-left: 1px solid;'>$tgp</td><td style='border-left: 1px solid;'>$cgpa</td><td style='border-left: 1px solid;'>$cum_C_F</td><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid;'></td>";
                                        echo "<td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; border-right: 1px solid;'></td>";
                                        echo "</tr>";
                                        if ($defout == "") {
                                            echo "<tr style='border-bottom: 1px solid;'><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid;'>$fname $oname</td><td colspan= '$colaprows'>$COcourses</td><td></td><td style='border-right: 1px solid;'></td></tr>\n";
                                        } else {
                                            echo "<tr style='border-bottom: 1px solid;'><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid;'>$fname $oname</td><td colspan= '$colaprows'>CO: $numb_Course_failed - $COcourses</td><td></td><td style='border-right: 1px solid;'></td></tr>\n";
                                        }
                                    }
                                }
                                $SubTotal = $PCount + $IGSCount + $DEFCount + $SP1Count + $SP2Count + $DLCount + $VCLCount + $Ten88Count + $BL2Count;

                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <p style="font-size: 14px">
                            <?php
                            /*  if ($DegType == "BEng") {
                                echo "SUMMARY<br>  VCL = " . $VCLCount . ",  DL = " . $DLCount . ",  IGS = " . $IGSCount . ",   DEF = " . $DEFCount . ",  P = " . $PCount . ",   SP1 = " . $SP1Count . ",  SP2 = " . $SP2Count . ",  8-7-6 = " . $Ten88Count . ",  BL2 = " . $BL2Count . ",  Total = " . $SubTotal;
                            } else {
                                echo "SUMMARY<br>  VCL = " . $VCLCount . ",  DL = " . $DLCount . ",  IGS = " . $IGSCount . ",   DEF = " . $DEFCount . ",  P = " . $PCount . ",   SP1 = " . $SP1Count . ",  SP2 = " . $SP2Count . ",  Total = " . $SubTotal;
                            } */

                            ?>
                        </p>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    $conn_stu->close();
                    ?>
                </div>
                <br><br>
                <div class="row" style="text-align: right">
                    <form action='Print_rec/print_schboard_poly.php' method='post' target='_blank'>
                        <input type='submit' name='print' class='btn btn-outline-success btn-sm' value='Print Preview'>
                    </form>
                </div>
                <br><br>
            </section>
        <?php
        }

        ?>

    </div>


    <script>
        //For Last Name Table Column Data

        const board_comment = document.getElementsByClassName('board_comment');

        for (var count = 0; count < board_comment.length; count++) {
            const board_comment_data = document.getElementById(board_comment[count].getAttribute('id'));

            const board_comment_popover = new DarkEditable(board_comment_data);
        }


        //For Gender Table column Data

        const board_aproval = document.getElementsByClassName('board_aproval');

        for (var count = 0; count < board_aproval.length; count++) {
            const board_aproval_data = document.getElementById(board_aproval[count].getAttribute("id"));

            const board_aproval_popover = new DarkEditable(board_aproval_data, {
                source: [{
                        value: 'Yet',
                        text: 'Yet'
                    },
                    {
                        value: 'Approve',
                        text: 'Approve'
                    },
                    {
                        value: 'Not Approve',
                        text: 'Not Approve'
                    }
                ]
            });
        }
    </script>

</body>

</html>
<?php

// Database Credentials
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'naub_results');
//define('DB_DATABASE', 'futcoursereg2_new');
define('DB_DATABASE2', 'std_profile_naub_old');
//define('DB_DATABASE2', 'std_profile');
define('DB_DATABASE4', 'pg_database');
define('DB_DATABASE5', 'futcoursereg2_pg');
define('DB_DATABASE6', 'staff_website');
define('DB_DATABASE7', 'staff_record');
define('DB_DATABASE8', 'classroom');
define('DB_DATABASE9', 'trans_request');
define('DB_DATABASE12', 'staff_passport');

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$conn4 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE4);
if ($conn4->connect_error) {
    die("Connection failed: " . $conn4->connect_error);
}

$conn5 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE5);
if ($conn5->connect_error) {
    die("Connection failed: " . $conn5->connect_error);
}

$conn6 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE6);
if ($conn6->connect_error) {
    die("Connection failed: " . $conn6->connect_error);
}

$conn7 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE7);
if ($conn7->connect_error) {
    die("Connection failed: " . $conn7->connect_error);
}

$conn8 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE8);
if ($conn8->connect_error) {
    die("Connection failed: " . $conn8->connect_error);
}

$conn9 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE9);
if ($conn9->connect_error) {
    die("Connection failed: " . $conn9->connect_error);
}

$conn12 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE12);
if ($conn12->connect_error) {
    die("Connection failed: " . $conn12->connect_error);
}






/*
function connect()
{
    $C = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($C->connect_error) {
        return false;
    }
    return $C;
}


function sqlSelect($C, $query, $format = false, ...$vars)
{
    $stmt = $C->prepare($query);
    if ($format) {
        $stmt->bind_param($format, ...$vars);
    }
    if ($stmt->execute()) {
        $res = $stmt->get_result();
        $stmt->close();
        return $res;
    }
    $stmt->close();
    return false;
}


function connect2()
{
    $C = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($C->connect_error) {
        return false;
    }
    return $C;
}



function sqlSelect2($C, $query, $format = false, ...$vars)
{
    $stmt = $C->prepare($query);
    if ($format) {
        $stmt->bind_param($format, ...$vars);
    }
    if ($stmt->execute()) {
        $res = $stmt->get_result();
        $stmt->close();
        return $res;
    }
    $stmt->close();
    return false;
}



// Email Credentials
define('SMTP_HOST', 'mail.mydomain.com');
define('SMTP_PORT', 465);
define('SMTP_USERNAME', 'name@mydomain.com');
define('SMTP_PASSWORD', '<my password>');
define('SMTP_FROM', 'noreply@mydomain.com');
define('SMTP_FROM_NAME', '<your name>');

// Global Variables
define('MAX_LOGIN_ATTEMPTS_PER_HOUR', 5);
define('MAX_EMAIL_VERIFICATION_REQUESTS_PER_DAY', 3);
define('MAX_PASSWORD_RESET_REQUESTS_PER_DAY', 3);
define('PASSWORD_RESET_REQUEST_EXPIRY_TIME', 60 * 60);
define('CSRF_TOKEN_SECRET', '<change me to something random>');
define('VALIDATE_EMAIL_ENDPOINT', 'http://localhost/YouTube/SecureAccountSystem/validate'); #Do not include trailing /
define('RESET_PASSWORD_ENDPOINT', 'http://localhost/Youtube/SecureAccountSystem/resetpassword'); #Do not include trailing /

// Code we want to run on every page/script
date_default_timezone_set('UTC');
*/




function validate_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

//error_reporting(0);
session_set_cookie_params(['samesite' => 'Strict']);
session_start();


/* $session_name = 'sec_session_id';   // Set a custom session name
$secure = true;
// This stops JavaScript being able to access the session id.
$httponly = true;
// Forces sessions to only use cookies.
if (ini_set('session.use_only_cookies', 1) === FALSE) {
    header("Location: ../error.php?err=Could not initiate a safe session (ini_set)");
    exit();
}
// Gets current cookies params.
$cookieParams = session_get_cookie_params();
session_set_cookie_params(
    $cookieParams["lifetime"],
    $cookieParams["path"],
    $cookieParams["domain"],
    $secure,
    $httponly
);
// Sets the session name to the one set above.
session_name($session_name);
session_start();            // Start the PHP session
session_regenerate_id(true);    // regenerated the session, delete the old one. */

$_SESSION['errormsg'] = "";

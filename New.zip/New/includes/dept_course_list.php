<?php
require_once 'db_connect2.php';
$stutype = $_SESSION['stutype'];
//if($stutype=="UG"){
include_once 'get_stu_level.php';
//}else{
//include 'db_connect.php';
//}
$regid = $_SESSION["regid"];
if (isset($_POST["country"])) {

	// Capture selected country
	$pickdept = $_POST["country"];
	//if($stutype=="UG"){
	$levelcode = substr($level, 0, 1);
	//}
	$totoutunit = 0;
	$dept_db = $_SESSION['deptdb'] . strtolower($dept);
	$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
	if ($conn_stu->connect_error) {
		die("Connection failed: " . $conn_stu->connect_error);
	}

	$sql = "SELECT * FROM diff_outs_courses WHERE regn1 = '$regid'";
	$result = $conn_stu->query($sql);
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
			$totoutunit = $totoutunit + $row["CUnit"];
		}
	}
	if ($level == 400) {
		if ($totoutunit >= 16) {
			$levelcode = $levelcode - 1;
		}
	}
	$conn_stu->close();


	if ($pickdept !== "No") {
?>
		<h2>
			<center>Pick Courses from Other Department</center>
		</h2>
		<?php
		$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}

		$sql = "SELECT * FROM gencoursesupload WHERE Department = '$pickdept' ORDER BY C_codding";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			// output data of each row
		?>

			<table class="table mb-none">
				<thead>
					<tr>
						<th></th>
						<th>Course Code</th>
						<th>Course Title</th>
						<th>Unit</th>
						<th>Semester</th>
						<th>Curriculum</th>
					</tr>
				</thead>
				<tbody>


					<?php

					while ($row = $result->fetch_assoc()) {
						$id = $row["id"];
						$ccode = $row["C_codding"];
						$CTitle = $row["C_title"];
						$CUnit = $row["credit"];
						$SemTaken = $row["semester"];
						$Nature = "Core";
						$type1 = $row["type1"];

						//if($stutype=="UG"){
						$subcode = substr($ccode, 3, 1);
						if ($subcode < ($levelcode + 1)) {
							echo "<tr>
								<td><input type='checkbox' name='chosenalldept[" . $id . "]' value='" . $id . "'/></td>
								
								<td>
								<label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
								<input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
								</td>
								<td>
								<label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
								<input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
								</td>
								<td>
								<label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
								<input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
								</td>
								<td>
								<label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
								<input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>
								</td>
								</td>
								<td hidden='hidden'>
								<label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
								<input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
								</td>
								<td>$type1</td>
								
								</tr>\n";
						}

						//}


					}
					?>
				</tbody>
			</table>

<?php
		} else {
		}
		$conn->close();
	}
}

?>
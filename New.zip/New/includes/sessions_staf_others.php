<?php
$userID = $_SESSION['userID'];
//$res = sqlSelect($C, 'SELECT * FROM users WHERE sn=?', 'i', $_SESSION['userID']);
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM users WHERE sn = '$userID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $names = $row["full_name"];
        $staffid = $row["staffid"];
        $dept = $row["staffacddept"];
        //$cat = $row["cat"];
        $email = $row["emailAdd"];
        $phone = $row["phone"];
        $staflevel = $row["Level1"];
        //$ecptdpassword = $row["password"];
        $schcode2 = $row["SchCode"];
        $staffoffice = $row["office_address"];

        $Administrator = $row["Administrator"];
        $Sub_Admin = $row["Sub_Admin"];
        $Dean = $row["Dean"];
        $HOD = $row["HOD"];
        $Examiner = $row["Examiner"];
        $Ass_Examiner = $row["Ass_Examiner"];
        $PG_Coord = $row["PG_Coord"];
        $Seminer_Coord = $row["Seminer_Coord"];
        $SIWES_Coord = $row["SIWES_Coord"];
        $L100 = $row["L100"];
        $L200 = $row["L200"];
        $L300 = $row["L300"];
        $L400 = $row["L400"];
        $L500 = $row["L500"];
        $spill_over = $row["spill_over"];

        $SchExaminer = $row["SchExaminer"];
        $POs = $row["POs"];
        $APU = $row["APU"];
        $QAP = $row["QAP"];
        $AcadSec = $row["AcadSec"];
        $Acad_Ofice = $row["Acad_Ofice"];
        $CourseLec = $row["CourseLec"];
        $transcript = $row["transcript"];
    }
}


$_SESSION['names'] = $_SESSION['regid'] = $_SESSION['deptname'] = $_SESSION['deptcode'] = $_SESSION['stdid'] = $_SESSION['othername'] = $_SESSION['corntsession'] = $_SESSION['defer1st'] = $_SESSION['siwesstatus'] = $_SESSION['email'] = $_SESSION['staffid'] = $_SESSION['cat'] = $_SESSION['usertype'] = $_SESSION['ecptdpassword'] = $_SESSION['getcat'] = "";
$_SESSION['course_alocation'] = $_SESSION['course_alocation_pg'] = $_SESSION['course_setup'] = $_SESSION['course_validation'] = $_SESSION['sta_stu_course_reg'] = $_SESSION['reg_stu_per_courses'] = $_SESSION['staff_results'] = $_SESSION['grad_list_result'] = $_SESSION['e_exam_results'] = $_SESSION['secrutiny_format'] = $_SESSION['board_format'] = $_SESSION['senate_format'] = $_SESSION['board_format'] = $_SESSION['stu_perform_graph'] = $_SESSION['download_stu_reg_courses'] = $_SESSION['stu_reg_courses_all'] = $_SESSION['submited_results'] = $_SESSION['download_stu_biodata'] = $_SESSION['upload_result(in_session)'] = $_SESSION['upload_result(graduated)'] = $_SESSION['e_exam_results'] = $_SESSION['download_stu_result(e-exam)'] = $_SESSION['upload_result(e-exam)'] = $_SESSION['create_users'] = $_SESSION['pass_reset_admin'] = $_SESSION['ind_stu_biodata'] = $_SESSION['qap_request'] = $_SESSION['pg_stu_course_reg'] = $_SESSION['pg_staff_results'] = $_SESSION['upload_result(pg)'] = $_SESSION['pg_course_setup'] = $_SESSION['pg_reg_students'] = $_SESSION['staf_condone_defer'] = $_SESSION['staf_condone_defer_view'] = $_SESSION['staf_condone_defer_edit'] = $_SESSION['not_for_acad'] = $_SESSION['stu_biodata_grad'] = $_SESSION['course_all'] = $_SESSION['pg_project_alocation'] = $_SESSION['apu_request'] = false;

$schname = "XXX";
$deptname = "XXX";
$siwesstatus = "NO";
$schcode = "XX";
$deptoption = "NOP";
$DegType = "NO";
$curricul = "OLD";
$dept_id = 0;
$prog_no_years = 0;

$sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $deptname = $row["DeptName"];
        $siwesstatus = $row["siwes"];
        $schcode = $row["School"];
        $deptoption = $row["deptoption"];
        $DegType = $row["DegreeAward"];
        $curricul = $row["curriculum"];
        $dept_id = $row["id"];
        $prog_no_years = $row["prog_no_years"];
    }
} else {
    $sql = "SELECT DeptName, DeptCode, School FROM deptcoding_non_acad WHERE DeptCode = '$dept'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $deptname = $row["DeptName"];
        }
    }
}

$sql = "SELECT SchCode, SchName FROM schoolname WHERE SchCode = '$schcode'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $schname = $row["SchName"];
    }
}

$numbschCurri = 0;
$sql2 = "SELECT * FROM sch_curriculum";
$result2 = $conn->query($sql2);
if ($result2->num_rows > 0) {
    while ($row2 = $result2->fetch_assoc()) {
        $numbschCurri++;
    }
}

$sql = "SELECT * FROM sessions WHERE getkey='key1'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $corntsession = $row["session_title"];
        $cursemester = $row["semester"];
        $resultsession = $row["result_session"];
        $resultsemester = $row["result_semester"];
    }
}


$sessionprevy = substr($corntsession, 0, 4) - 1;
$_SESSION['logintype'] = "staff";
$_SESSION['prevsession'] = $sessionprevy . "/" . substr($corntsession, 0, 4);
$_SESSION["siwesstatus"] = $siwesstatus;
if (strtoupper($dept) == "NONE") {
    $_SESSION['deptname'] = "Non Academic Department";
} else {
    $_SESSION['deptname'] = $deptname;
}
$_SESSION['deptcode'] = strtolower($dept);
$_SESSION['dept_id'] = $dept_id;
$_SESSION['deptcode_grad'] = $dept;
$_SESSION['schname'] = $schname;
$_SESSION['schcode'] = $schcode;
$_SESSION['schcode2'] = $schcode2;
$_SESSION['corntsession'] = $corntsession;
$_SESSION['cursemester'] = $cursemester;
$_SESSION['resultsession'] = $resultsession;
$_SESSION['resultsemester'] = $resultsemester;
$_SESSION['staffoffice'] = $staffoffice;
$_SESSION["getsession"] = $corntsession;
$_SESSION['downlcurse'] = "";
$_SESSION['downlsession'] = "";
$_SESSION['deptoption'] = $deptoption;
$_SESSION['DegType'] = $DegType;
$_SESSION['curricul'] = $curricul;

//$_SESSION['ecptdpassword'] = $ecptdpassword;
$_SESSION['names'] = $names;
$_SESSION['staffid'] = strtoupper($staffid);
//$_SESSION['cat'] = $cat;
$_SESSION['email'] = $email;
$_SESSION['phone'] = $phone;
$_SESSION['staflevel'] = $staflevel;
$_SESSION['usertype'] = "Staff";
$_SESSION['getPassw'] = $password;
$_SESSION['courseRegSplitSess'] = "2019/2020";
$_SESSION['prog_no_years'] = $prog_no_years;
$_SESSION['countnewmsg'] = 0;
$_SESSION['numbschCurri'] = $numbschCurri;
$_SESSION['selAdminDept'] = "All";
$_SESSION["seloption"] = "XXXX";
$_SESSION['selectdept'] = $dept;


$_SESSION['Administrator'] = $Administrator;
$_SESSION['Sub_Admin'] = $Sub_Admin;
$_SESSION['Dean'] = $Dean;
$_SESSION['HOD'] = $HOD;
$_SESSION['Examiner'] = $Examiner;
$_SESSION['Ass_Examiner'] = $Ass_Examiner;
$_SESSION['PG_Coord'] = $PG_Coord;
$_SESSION['Seminer_Coord'] = $Seminer_Coord;
$_SESSION['SIWES_Coord'] = $SIWES_Coord;
$_SESSION['L100'] = $L100;
$_SESSION['L200'] = $L200;
$_SESSION['L300'] = $L300;
$_SESSION['L400'] = $L400;
$_SESSION['L500'] = $L500;
$_SESSION['spill_over'] = $spill_over;

$_SESSION['SchExaminer'] = $SchExaminer;
$_SESSION['POs'] = $POs;
$_SESSION['APU'] = $APU;
$_SESSION['QAP'] = $QAP;
$_SESSION['AcadSec'] = $AcadSec;
$_SESSION['Acad_Ofice'] = $Acad_Ofice;
$_SESSION['CourseLec'] = $CourseLec;
$_SESSION['transcript'] = $transcript;


//$timestamp = time();
//$_SESSION['lasttime_chat'] = date('h:i:s A', $timestamp);

$sql2 = "DELETE FROM small_chat WHERE date_time < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 DAY))";
$result2 = $conn->query($sql2);



include_once 'change_it.php';

include_once 'otherconditn.inc.php';

$countprog = 0;

try {
    $sql = "SELECT * FROM deptcoding WHERE hostdept = '$dept'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $countprog++;
        }
    }
} catch (Exception $e) {
}
$_SESSION["countprog"] = $countprog;

$conn->close();

if ($countprog > 1) {

    $_SESSION["seldeptLogin"] = false;
    header('Location: ../home_option.php');
} else {

    header('Location: ../home_staff.php');
}

<?php
// Store the cipher method
$ciphering = "AES-128-CTR";

// Use OpenSSl Encryption method
$iv_length = openssl_cipher_iv_length($ciphering);
$options = 0;


// Non-NULL Initialization Vector for decryption
$decryption_iv = '1999201920202021';

// Store the decryption key
$decryption_key = "FUTMinnaEresults";

// Use openssl_decrypt() function to decrypt the data
$decryption=openssl_decrypt ($encryption, $ciphering,
    $decryption_key, $options, $decryption_iv);
?>
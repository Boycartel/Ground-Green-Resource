<?php
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    session_destroy();
    header("Location: index_stu.php");
    exit;
} else {
    if ($_SESSION['logintype'] !== "student") {
        session_destroy();
        header('Location: index_stu.php');
    }
}


/* if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    session_destroy();
    header("Location: index");
    exit;
}

$user = [];
$C = connect2();
if ($C) {
    $res = sqlSelect($C, 'SELECT * FROM std_login WHERE id=?', 'i', $_SESSION['userID']);
    if ($res && $res->num_rows === 1) {
        $user = $res->fetch_assoc();
        if ($_SESSION['logintype'] !== "student") {
            session_destroy();
            header('Location: index');
        }
    } else {

        session_destroy();
        header('Location: index');
    }
} else {
    //exit;
    session_destroy();
    header('Location: index');
} */
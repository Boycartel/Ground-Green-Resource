<?php
/*
* iTech Empires:  Export Data from MySQL to CSV Script
* Version: 1.0.0
* Page: Export
*/
require_once 'db_connect.php';

// get Users
$dept = $_SESSION['deptcode'];

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$resultsession = $_SESSION['resultsession'];

$StuCurSess = str_ireplace("/", "_", $resultsession);
$deptcorreg = $dept . "_correg_" . $StuCurSess;
$user_arr = array();
$query = "SELECT * FROM " . $deptcorreg;
//$query = "SELECT * FROM users";
if (!$result = mysqli_query($conn_stu, $query)) {
    exit(mysqli_error($conn_stu));
}

$users = array();
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $users[] = $row;
    }
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=Users.csv');
$output = fopen('php://output', 'w');
fputcsv($output, array('No', 'First Name', 'Last Name', 'Email'));

if (count($users) > 0) {
    foreach ($users as $row) {
        fputcsv($output, $row);
    }
}
?>






<!--<div class="container">

    <form method='post' action='includes/database_backup_inc.php'>


        <table border='1' style='border-collapse:collapse;'>
            <tr>
                <th>Course Code</th>
                <th>Course Title</th>
                <th>Course Nature</th>
                <th>Unit</th>
                <th>Semester</th>
                <th>Session</th>
                <th>CA</th>
                <th>Exam</th>
                <th>Grade</th>
                <th>Grouping</th>
                <th>Reg Number</th>
                <th>Course Condune</th>
                <th>No Exam</th>
                <th>Dept Option</th>
                <th>Date</th>
            </tr>
            <?php
            /*            set_time_limit(1000);
            $dept = $_SESSION['deptcode'];
            $resultsession=$_SESSION['resultsession'];
            $sql = "SELECT * FROM session_interval WHERE sessions = '$resultsession'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $StuCurSess = $row["sess_interval"];
                }
            }
            $deptcorreg = $dept . "_correg_" . $StuCurSess;
            $user_arr = array();
            $sql = "SELECT * FROM " . $deptcorreg;
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $CCode = $row['CCode'];
                    $CTitle = $row['CTitle'];
                    $CNature = $row['CNature'];
                    $CUnit = $row['CUnit'];
                    $SemTaken = $row['SemTaken'];
                    $SessionRegis = $row['SessionRegis'];
                    $CA = $row['CA'];
                    $Exam = $row['Exam'];
                    $grade = $row['grade'];
                    $Grouping = $row['Grouping'];
                    $Regn1 = $row['Regn1'];
                    $coursecondon = $row['coursecondon'];
                    $noexam = $row['noexam'];
                    $deptOption = $row['deptOption'];
                    $date = $row['date'];

                    $user_arr[] = array($CCode,$CTitle,$CNature,$CUnit,$SemTaken, $SessionRegis, $CA, $Exam, $grade, $Grouping, $Regn1, $coursecondon, $noexam, $deptOption, $date);
                    */ ?>
                    <tr>
                        <td><?php /*echo $CCode; */ ?></td>
                        <td><?php /*echo $CTitle; */ ?></td>
                        <td><?php /*echo $CNature; */ ?></td>
                        <td><?php /*echo $CUnit; */ ?></td>
                        <td><?php /*echo $SemTaken; */ ?></td>
                        <td><?php /*echo $SessionRegis; */ ?></td>
                        <td><?php /*echo $CA; */ ?></td>
                        <td><?php /*echo $Exam; */ ?></td>
                        <td><?php /*echo $grade; */ ?></td>
                        <td><?php /*echo $Grouping; */ ?></td>
                        <td><?php /*echo $Regn1; */ ?></td>
                        <td><?php /*echo $coursecondon; */ ?></td>
                        <td><?php /*echo $noexam; */ ?></td>
                        <td><?php /*echo $deptOption; */ ?></td>
                        <td><?php /*echo $date; */ ?></td>

                    </tr>
                    <?php
                    /*                }
            }
            */ ?>
        </table>
        <?php
        /*        $serialize_user_arr = serialize($user_arr);
        */ ?>
        <textarea name='export_data' style='display: none;'><?php /*echo $serialize_user_arr; */ ?></textarea>
        <br>
        <input type='submit' value='Export' name='Export'>
        <br><br>
    </form>
</div>-->
<h3>
    <center>Pick Courses to register</center>
</h3>
<h4>
    <center>1ST Semester</center>
</h4>
<?php

$totoutunit = 0;
$regid = $_SESSION["regid"];
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$sql = "SELECT * FROM diff_outs_courses WHERE regn1 = '$regid'";
$result = $conn_stu->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $totoutunit = $totoutunit + $row["CUnit"];
    }
}


$sql = "SELECT * FROM deptcourses_engrept WHERE SemTaken = '1ST'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    if ($tot1outunit < 24) {
?>

        <table class="table mb-none tablechk1">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll1"></th>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Unit</th>
                    <th>Semester</th>
                    <th>Nature</th>
                </tr>
            </thead>
            <tbody>


                <?php

                while ($row = $result->fetch_assoc()) {
                    $id = $row["id"];
                    $ccode = $row["CCode"];
                    $CTitle = $row["CTitle"];
                    $CUnit = $row["CUnit"];
                    $SemTaken = $row["SemTaken"];
                    $Nature = "Elective";

                    $sql2 = "SELECT * FROM diff_outs_courses WHERE regn1 = '$regid' AND CCode = '$ccode'";
                    $result2 = $conn_stu->query($sql2);

                    if ($result2->num_rows == 0) {

                        echo "<tr>
                            <td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
                            
                            <td>
                            <label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
                            <input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
                            </td>
                            <td>
                            <label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
                            <input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
                            </td>
                            <td>
                            <label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
                            <input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
                            </td>
                            <td>
                            <label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
                            <input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>
                            </td>
                            
                            <td>
                            <label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
                            <input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
                            </td>
                            
                            </tr>\n";
                    }
                }
                ?>
            </tbody>
        </table>

<?php
    }
}

//$conn->close();
?>
<br /><br />
<h4>
    <center>2ND Semester</center>
</h4>
<?php


$sql = "SELECT * FROM deptcourses_engrept WHERE SemTaken = '2ND'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    if ($tot2outunit < 24) {
?>

        <table class="table mb-none tablechk3">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll3"></th>
                    <th>Course Code</th>
                    <th>Course Title</th>
                    <th>Unit</th>
                    <th>Semester</th>
                    <th>Nature</th>
                </tr>
            </thead>
            <tbody>


                <?php
                while ($row = $result->fetch_assoc()) {
                    $id = $row["id"];
                    $ccode = $row["CCode"];
                    $CTitle = $row["CTitle"];
                    $CUnit = $row["CUnit"];
                    $SemTaken = $row["SemTaken"];
                    $Nature = "Elective";

                    $sql2 = "SELECT * FROM diff_outs_courses WHERE regn1 = '$regid' AND CCode = '$ccode'";
                    $result2 = $conn_stu->query($sql2);

                    if ($result2->num_rows == 0) {
                        echo "<tr>
                            <td><input type='checkbox' class='checkbox' name='chosen2[" . $id . "]' value='" . $id . "'/></td>
                            
                            <td>
                            <label id='ccode2' name='ccode2[" . $id . "]'>$ccode</label>
                            <input type='hidden' id='ccode2' name='ccode2[" . $id . "]' value='" . $ccode . "'/>
                            </td>
                            <td>
                            <label id='CTitle2' name='CTitle2[" . $id . "]'>$CTitle</label>
                            <input type='hidden' id='CTitle2' name='CTitle2[" . $id . "]' value='" . $CTitle . "'/>
                            </td>
                            <td>
                            <label id='CUnit2' name='CUnit2[" . $id . "]'>$CUnit</label>
                            <input type='hidden' id='CUnit2' name='CUnit2[" . $id . "]' value='" . $CUnit . "'/>
                            </td>
                            <td>
                            <label id='SemTaken2' name='SemTaken2[" . $id . "]'>$SemTaken</label>
                            <input type='hidden' id='SemTaken2' name='SemTaken2[" . $id . "]' value='" . $SemTaken . "'/>
                            </td>
                            
                            <td>
                            <label id='Nature2' name='Nature2[" . $id . "]'>$Nature</label>
                            <input type='hidden' id='Nature2' name='Nature2[" . $id . "]' value='" . $Nature . "'/>
                            </td>
                            
                            </tr>\n";
                    }
                }
                ?>
            </tbody>
        </table>

<?php
    }
}

$conn->close();
$conn2->close();
$conn_stu->close();

?>
<br /><br />
<?php

$prevcgpa = $finalCGPA = 0;
$stustatus = "";

$regid = $_SESSION["regid"];
$dept = $_SESSION['deptcode'];
$curtsession = $_SESSION['corntsession'];
$resultsession = $_SESSION['resultsession'];
$names = $_SESSION['names'];
$entry_session = $_SESSION['entry_session'];
$FinalYear = substr($resultsession, 0, 4);
$StartYear = substr($entry_session, 0, 4);
$countses = 0;
unset($stuSessionArray);
$stuSessionArray[] = "";
for ($x = $StartYear; $x <= $FinalYear; $x++) {
    $countses++;
    $stuSessionArray[$countses] = $x . "/" . ($x + 1);
}



$session1 = $session2 = $session3 = $session4 = $session5 =  "XXXX";
$cgpa1 = $cgpa2 = $cgpa3 = $cgpa4 = $cgpa5 = $finalCGPA = 0;


if ($countses == 1) {

    $session1 = $stuSessionArray[1];
    $getsession = $stuSessionArray[1];
    include 'modulesInSess/getCGPA.php';

    $cgpa1 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;
}

if ($countses == 2) {

    $session1 = $stuSessionArray[1];
    $getsession = $stuSessionArray[1];
    include 'modulesInSess/getCGPA.php';

    $cgpa1 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session2 = $stuSessionArray[2];
    $getsession = $stuSessionArray[2];
    include 'modulesInSess/getCGPA.php';

    $cgpa2 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;
}

if ($countses == 3) {

    $session1 = $stuSessionArray[1];
    $getsession = $stuSessionArray[1];
    include 'modulesInSess/getCGPA.php';

    $cgpa1 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session2 = $stuSessionArray[2];
    $getsession = $stuSessionArray[2];
    include 'modulesInSess/getCGPA.php';

    $cgpa2 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session3 = $stuSessionArray[3];
    $getsession = $stuSessionArray[3];
    include 'modulesInSess/getCGPA.php';

    $cgpa3 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;
}

if ($countses == 4) {

    $session1 = $stuSessionArray[1];
    $getsession = $stuSessionArray[1];
    include 'modulesInSess/getCGPA.php';

    $cgpa1 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session2 = $stuSessionArray[2];
    $getsession = $stuSessionArray[2];
    include 'modulesInSess/getCGPA.php';

    $cgpa2 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session3 = $stuSessionArray[3];
    $getsession = $stuSessionArray[3];
    include 'modulesInSess/getCGPA.php';

    $cgpa3 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session4 = $stuSessionArray[4];
    $getsession = $stuSessionArray[4];
    include 'modulesInSess/getCGPA.php';

    $cgpa4 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;
}

if ($countses == 5) {

    $session1 = $stuSessionArray[1];
    $getsession = $stuSessionArray[1];
    include 'modulesInSess/getCGPA.php';

    $cgpa1 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session2 = $stuSessionArray[2];
    $getsession = $stuSessionArray[2];
    include 'modulesInSess/getCGPA.php';

    $cgpa2 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session3 = $stuSessionArray[3];
    $getsession = $stuSessionArray[3];
    include 'modulesInSess/getCGPA.php';

    $cgpa3 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session4 = $stuSessionArray[4];
    $getsession = $stuSessionArray[4];
    include 'modulesInSess/getCGPA.php';

    $cgpa4 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session5 = $stuSessionArray[5];
    $getsession = $stuSessionArray[5];
    include 'modulesInSess/getCGPA.php';

    $cgpa5 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;
}

if ($countses == 6) {

    $session1 = $stuSessionArray[1];
    $getsession = $stuSessionArray[1];
    include 'modulesInSess/getCGPA.php';

    $cgpa1 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session2 = $stuSessionArray[2];
    $getsession = $stuSessionArray[2];
    include 'modulesInSess/getCGPA.php';

    $cgpa2 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session3 = $stuSessionArray[3];
    $getsession = $stuSessionArray[3];
    include 'modulesInSess/getCGPA.php';

    $cgpa3 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session4 = $stuSessionArray[4];
    $getsession = $stuSessionArray[4];
    include 'modulesInSess/getCGPA.php';

    $cgpa4 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session5 = $stuSessionArray[5];
    $getsession = $stuSessionArray[5];
    include 'modulesInSess/getCGPA.php';

    $cgpa5 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session6 = $stuSessionArray[6];
    $getsession = $stuSessionArray[6];
    include 'modulesInSess/getCGPA.php';

    $cgpa6 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;
}

if ($countses == 7) {

    $session1 = $stuSessionArray[1];
    $getsession = $stuSessionArray[1];
    include 'modulesInSess/getCGPA.php';

    $cgpa1 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session2 = $stuSessionArray[2];
    $getsession = $stuSessionArray[2];
    include 'modulesInSess/getCGPA.php';

    $cgpa2 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session3 = $stuSessionArray[3];
    $getsession = $stuSessionArray[3];
    include 'modulesInSess/getCGPA.php';

    $cgpa3 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session4 = $stuSessionArray[4];
    $getsession = $stuSessionArray[4];
    include 'modulesInSess/getCGPA.php';

    $cgpa4 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session5 = $stuSessionArray[5];
    $getsession = $stuSessionArray[5];
    include 'modulesInSess/getCGPA.php';

    $cgpa5 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session6 = $stuSessionArray[6];
    $getsession = $stuSessionArray[6];
    include 'modulesInSess/getCGPA.php';

    $cgpa6 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;

    $session7 = $stuSessionArray[7];
    $getsession = $stuSessionArray[7];
    include 'modulesInSess/getCGPA.php';

    $cgpa7 = $prevcgpa;
    $stustatus =  $stustatus;
    $finalCGPA =  $finalCGPA;
}


$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$diff_outstand = 0;
$sql = "SELECT * FROM diff_outs_courses WHERE Regn1 = '$regid'";
$result = $conn_stu->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $diff_outstand += $row['CUnit'];
    }
}

$conn_stu->close();

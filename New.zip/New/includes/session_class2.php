<?php
//sessions_class.php
class DbSessionClass implements SessionHandlerInterface
{
    private $dbh;
    private $db_host = 'localhost';
    private $db_port = 3306;
    // private $db_name = 'futcoursereg2_new';
    //private $db_user = 'root';
    //private $db_pass = '';

    private $db_name = 'fedpolyb_results';
    private $db_user = 'fedpolyb_ihsan';
    private $db_pass = 'Ihsan@2001$';

    private $db_table = 'data_table';

    public function open($savePath, $sessionName): bool
    {
        $dsn = "mysql:host=$this->db_host;port=$this->db_port;dbname=$this->db_name";

        try {
            $this->dbh = new PDO($dsn, $this->db_user, $this->db_pass);
        } catch (PDOException $e) {
            echo 'Error!: ' . $e->getMessage();
            exit;
        }
        return true;
    }

    public function close(): bool
    {
        $this->dbh = null;
        return true;
    }

    public function read($id): string
    {
        $q = $this->dbh->prepare("SELECT data FROM $this->db_table WHERE id=?");
        $q->bindParam(1, $id);

        if ($q->execute()) {
            if ($q->rowCount() == 0)
                return '';
            return $q->fetchColumn();
        }
        return false;
    }

    public function write($id, $data): bool
    {
        $ts = date('YmdHis');

        $q = $this->dbh->prepare("REPLACE INTO $this->db_table VALUES(?, ?, ?)");
        $q->bindParam(1, $id);
        $q->bindParam(2, $data);
        $q->bindParam(3, $ts);
        return $q->execute();
    }

    public function destroy($id): bool
    {
        $q = $this->dbh->prepare("DELETE FROM $this->db_table WHERE id=?");
        $q->bindParam(1, $id);
        return $q->execute();
    }

    public function gc($maxlifetime): int
    {
        $ts = date('YmdHis', time() - $maxlifetime);
        $q = $this->dbh->prepare("DELETE FROM $this->db_table WHERE access < ?");
        $q->bindParam(1, $ts);
        if ($q->execute())
            return $q->rowCount();
        return false;
    }
}

$handler = new DbSessionClass();
session_set_save_handler($handler, true);

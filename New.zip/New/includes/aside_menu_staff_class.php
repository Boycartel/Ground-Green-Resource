<aside id="sidebar-left" class="sidebar-left">
				
	<div class="sidebar-header">
		<div class="sidebar-title">
			Navigation
		</div>
		<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
			<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
		</div>
	</div>

	<div class="nano">
		<div class="nano-content">
			<nav id="menu" class="nav-main" role="navigation">

                <ul class="nav nav-main">
                    <li class="nav-active">
                        <a href="home_staff.php">
                            <i class="fa fa-home" aria-hidden="true"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-user" aria-hidden="true"></i>
                            <span>Student Biodata</span>
                        </a>
                        <ul class="nav nav-children">
                            <?php if($_SESSION['course_validation']==true){ ?>
                                <li><a class="" href="ind_stu_biodata.php">Undergraduate</a></li>
                            <?php } ?>

                            <?php if($_SESSION['pg_course_setup']==true){ ?>
                                <li><a class="" href="ind_pg_biodata.php">Postgraduate</a></li>
                            <?php } ?>

                            <?php if($_SESSION['stu_biodata_grad']==true){ ?>
                                <li><a class="" href="stu_biodata_grad.php">Student Biodata(Grad)</a></li>
                            <?php } ?>
                        </ul>
                    </li>
                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-file" aria-hidden="true"></i>
                            <span>Results</span>
                        </a>
                        <ul class="nav nav-children">
                            <?php
                            if($_SESSION['staff_results']==true){
                                ?>
                                <li><a class="" href="staff_results.php">Student's Result</a></li>
                                <?php
                            }
                            if($_SESSION['pg_staff_results']==true){
                                ?>
                                <li><a class="" href="pg_staff_results.php">Postgraduate Results</a></li>
                                <?php
                            }
                            if($_SESSION['grad_list_result']==true){
                                ?>
                                <li><a class="" href="grad_list_result.php">Graduated List/Results</a></li>
                                <?php
                            }
                            if($_SESSION['e_exam_results']==true){
                                ?>
                                <li><a class="" href="e_exam_results.php">e-Exam Results</a></li>
                                <?php
                            }
                            if($_SESSION['board_format']==true){
                                ?>
                                <li class="nav-parent">
                                    <a>
                                        <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                                        <span>School Board</span>
                                    </a>
                                    <ul class="nav nav-children">
                                        <li><a class="" href="boardformat.php">Returning Students</a></li>
                                        <li><a class="" href="boardformat_grad.php">Graduating Students</a></li>

                                    </ul>
                                </li>
                                <?php
                            }
                            if($_SESSION['secrutiny_format']==true){
                                ?>
                                <li class="nav-parent">
                                    <a>
                                        <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                                        <span>Scrutiny Format</span>
                                    </a>
                                    <ul class="nav nav-children">
                                        <li><a class="" href="secrutiny_format.php">Returning Students</a></li>
                                        <li><a class="" href="secrutiny_format_grad.php">Graduating Students</a></li>

                                    </ul>
                                </li>
                                <?php
                            }
                            if($_SESSION['senate_format']==true){
                                ?>
                                <li class="nav-parent">
                                    <a>
                                        <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                                        <span>Senate Format</span>
                                    </a>
                                    <ul class="nav nav-children">
                                        <li><a class="" href="senate_format.php">Returning Students</a></li>
                                        <li><a class="" href="senate_format_grad.php">Graduating Students</a></li>

                                    </ul>
                                </li>
                                <?php
                            }
                            if($_SESSION['stu_perform_graph']==true){
                                ?>
                                <li><a class="" href="stu_perform_graph.php">Analysis By Graph</a></li>
                            <?php }
                            if($_SESSION['submited_results']==true){
                                ?>
                                <li><a class="" href="submited_results.php">Submited Results</a></li>
                            <?php }?>

                        </ul>
                    </li>
                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-list" aria-hidden="true"></i>
                            <span>Courses</span>
                        </a>
                        <ul class="nav nav-children">
                            <?php
                            if($_SESSION['course_validation']==true){
                                if($_SESSION['cat'] == "HODLAdvice"){
                                    ?>
                                    <li><a class="" href="hod_ladvise_validate.php">Course Validation</a></li>
                                    <?php

                                }else{
                                    ?>
                                    <li><a class="" href="course_validation.php">Course Validation</a></li>
                                    <?php

                                }
                            }
                            ?>
                            <?php if($_SESSION['pg_course_setup']==true){ ?>
                                <li><a class="" href="course_validation_pg.php">Course Validation(PG)</a></li>
                            <?php } ?>

                            <?php if($_SESSION['course_all']==true){ ?>
                                <li><a class="" href="course_all.php">Course Details</a></li>
                            <?php } ?>
                            <?php if($_SESSION['course_setup']==true){ ?>
                                <li><a class="" href="course_setup.php">Course Setup</a></li>
                            <?php } ?>
                            <?php if($_SESSION['pg_course_setup']==true){ ?>
                                <li><a class="" href="course_setup_pg.php">Course Setup(PG)</a></li>
                            <?php } ?>
                            <?php if($_SESSION['not_for_acad']==false){ ?>
                                <li><a class="" href="course_alocated.php">Course Allocated</a></li>
                            <?php } ?>
                            <?php if($_SESSION['course_alocation']==true){ ?>
                                <li><a class="" href="course_alocation.php">Course Allocation</a></li>
                                <?php
                            }
                            if($_SESSION['course_alocation_pg']==true){
                                ?>
                                <li><a class="" href="course_alocation_pg.php">Course Allocation (PG)</a></li>
                                <?php
                            }
                            if($_SESSION['sta_stu_course_reg']==true){
                                ?>
                                <li><a class="" href="sta_stu_course_reg.php">Registered Courses</a></li>
                                <?php
                            }

                            if($_SESSION['reg_stu_per_courses']==true){
                                ?>
                                <li><a class="" href="reg_stu_per_courses.php">Reg. Stu. per Courses</a></li>

                            <?php } ?>

                        </ul>
                    </li>
                    <li class="nav-parent">
                        <a>
                            <i class="fa fa-download" aria-hidden="true"></i>
                            <span>Download</span>
                        </a>
                        <ul class="nav nav-children">
                            <li><a class="" href="download_stu_result.php">Course(s) Results</a></li>
                            <?php
                            if($_SESSION['download_stu_reg_courses(e-center)']==true){
                                ?>
                                <li><a class="" href="download_stu_reg_courses(e-center).php">Reg. Courses(e-Center)</a></li>
                                <?php
                            }
                            if($_SESSION['download_stu_reg_courses']==true){
                                ?>
                                <li><a class="" href="download_stu_reg_courses.php">Registered Courses</a></li>
                                <?php
                            }
                            if($_SESSION['stu_reg_courses_all']==true){
                                ?>
                                <li><a class="" href="stu_reg_courses_all.php">Reg. Courses All</a></li>
                                <?php
                            }
                            if($_SESSION['download_stu_result(e-exam)']==true){
                                ?>
                                <li><a class="" href="download_stu_result(e-exam).php">Stu. Result(e-Exam)</a></li>
                                <?php
                            }
                            if($_SESSION['download_stu_biodata']==true){
                                ?>
                                <li><a class="" href="download_stu_biodata.php">Students' Biodata</a></li>
                            <?php } ?>
                        </ul>
                    </li>
                    <?php if($_SESSION['not_for_acad']==false){ ?>
                        <li class="nav-parent">
                            <a>
                                <i class="fa fa-upload" aria-hidden="true"></i>
                                <span>Upload</span>
                            </a>
                            <ul class="nav nav-children">
                                <li><a class="" href="upload_ind_result.php">My Course(s) Results</a></li>
                                <?php
                                if($_SESSION['upload_result(in_session)']==true){
                                    ?>
                                    <li><a class="" href="upload_result(in_session).php">Stu. Results(In Session)</a></li>
                                    <?php
                                }
                                if($_SESSION['upload_result(pg)']==true){
                                    ?>
                                    <li><a class="" href="upload_result(pg).php">Students Result(PG)</a></li>
                                    <?php
                                }
                                if($_SESSION['upload_result(graduated)']==true){
                                    ?>
                                    <li><a class="" href="upload_result(graduated).php">Students Result(Graduated)</a></li>
                                    <?php
                                }
                                if($_SESSION['upload_result(e-exam)']==true){
                                    ?>

                                    <li><a class="" href="upload_result(e-exam).php">Students Result(e-Exam)</a></li>
                                    <?php
                                }
                                if($_SESSION['upload_result(e-exam)']==true){
                                    ?>

                                    <li><a class="" href="drop_e_exam_results.php">Drop Result(e-Exam)</a></li>
                                <?php } ?>

                            </ul>
                        </li>
                    <?php } ?>
                    <?php if($_SESSION['staf_condone_defer_view']==true){ ?>
                        <li class="nav-parent">
                            <a>
                                <i class="fa fa-chain-broken" aria-hidden="true"></i>
                                <span>Missing Session</span>
                            </a>
                            <ul class="nav nav-children">
                                <?php
                                if($_SESSION['staf_condone_defer']==true){
                                    ?>
                                    <li><a class="" href="staf_condone_defer.php">Add</a></li>
                                <?php } ?>
                                <li><a class="" href="staf_condone_defer_view.php">View</a></li>
                                <?php
                                if($_SESSION['staf_condone_defer_edit']==true){
                                    ?>
                                    <li><a class="" href="staf_condone_defer_edit.php">Edit</a></li>
                                <?php } ?>
                            </ul>
                        </li>
                    <?php } ?>
                    <?php if($_SESSION['qap_request']==true){ ?>
                        <li class="nav-parent">
                            <a>
                                <i class="fa fa-th-list" aria-hidden="true"></i>
                                <span>QAP</span>
                            </a>
                            <ul class="nav nav-children">
                                <li><a class="" href="qap_results.php">Results(Courses) Analysis</a></li>
                                <li><a class="" href="qap_request.php">Stu List with CGPA</a></li>
                            </ul>
                        </li>
                    <?php } ?>
                    <?php if($_SESSION['apu_request']==true){ ?>
                        <li class="nav-parent">
                            <a>
                                <i class="fa fa-mortar-board (alias)" aria-hidden="true"></i>
                                <span>APU</span>
                            </a>
                            <ul class="nav nav-children">
                                <li class="nav-parent">
                                    <a>
                                        <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                                        <span>Staff Record</span>
                                    </a>
                                    <ul class="nav nav-children">
                                        <li><a class="" href="dap_staff_dept.php">By Department</a></li>
                                        <li><a class="" href="dap_staff_state.php">By State of Origin</a></li>
                                        <li><a class="" href="dap_staff_dept_state.php">By Department and State</a></li>
                                    </ul>
                                </li>
                                <li class="nav-parent">
                                    <a>
                                        <i class="fa  fa-angle-double-right" aria-hidden="true"></i>
                                        <span>UG Students Record</span>
                                    </a>
                                    <ul class="nav nav-children">
                                        <li><a class="" href="dap_stu_dept.php">By Department</a></li>
                                        <li><a class="" href="dap_stu_state.php">By State of Origin</a></li>
                                        <li><a class="" href="dap_stu_dept_state.php">By Department and State</a></li>
                                    </ul>
                                </li>
                                <li class="nav-parent">
                                    <a>
                                        <i class="fa  fa-angle-double-right" aria-hidden="true"></i>
                                        <span>PG Students Record</span>
                                    </a>
                                    <ul class="nav nav-children">
                                        <li><a class="" href="dap_pg_dept.php">By Department</a></li>
                                        <li><a class="" href="dap_pg_state.php">By State of Origin</a></li>
                                        <li><a class="" href="dap_pg_dept_state.php">By Department and State</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a class="" href="dap_dept_accreditation.php">
                                        <i class="fa fa-edit (alias)"></i>
                                        <span>Department Accreditation</span>
                                    </a>
                                </li>
                            </ul>
                        </li>

                    <?php } ?>
                    <?php if ($_SESSION['pg_project_alocation']==true) { ?>
                        <li class="nav-parent">
                            <a>
                                <i class="fa fa-support (alias)" aria-hidden="true"></i>
                                <span>PG Pregress Report</span>
                            </a>
                            <ul class="nav nav-children">
                                <li><a class="" href="pg_request_defence.php">Defence Request</a></li>
                                <li><a class="" href="pg_project_alocation.php">Project Allocation</a></li>
                            </ul>
                        </li>
                    <?php } ?>
                    <?php if($_SESSION['create_users']==true){ ?>
                        <li class="nav-parent">
                            <a>
                                <i class="fa fa-users" aria-hidden="true"></i>
                                <span>Users</span>
                            </a>
                            <ul class="nav nav-children">
                                <li><a class="" href="create_user.php">Create Users</a></li>
                                <li><a class="" href="edit_users.php">Edit Users</a></li>
                            </ul>
                        </li>
                    <?php } ?>
                    <?php if($_SESSION['not_for_acad']==false){ ?>
                        <li>
                            <a class="" href="includes/edit_create_site.php">
                                <i class="fa fa-life-saver (alias)"></i>
                                <span>My Website</span>
                            </a>
                        </li>
                        <li>
                            <a class="" href="staf_courseware.php">
                                <i class="fa fa-briefcase"></i>
                                <span>Courseware</span>
                            </a>
                        </li>
                    <?php } ?>
                    <?php if($_SESSION['pass_reset_admin']==true){ ?>
                        <li>
                            <a class="" href="id_card.php">
                                <i class="fa fa-edit (alias)"></i>
                                <span>ID Card</span>
                            </a>
                        </li>
                        <li>
                            <a class="" href="password_get.php">
                                <i class="fa fa-chain (alias)"></i>
                                <span>Get Password</span>
                            </a>
                        </li>
                        <li>
                            <a class="" href="database_backup.php">
                                <i class="fa fa-truck"></i>
                                <span>Backup Database</span>
                            </a>
                        </li>
                        <li class="nav-parent">
                            <a>
                                <i class="fa fa-exchange" aria-hidden="true"></i>
                                <span>Change Department</span>
                            </a>
                            <ul class="nav nav-children">
                                <li><a class="" href="change_dept_new.php">New Students</a></li>
                                <li><a class="" href="change_dept.php">Returning Students</a></li>
                            </ul>
                        </li>


                    <?php } ?>
                    <?php if($_SESSION['not_for_acad']==false){ ?>
                        <li>
                            <a class="" href="staf_lecturetimetableinpt.php">
                                <i class="fa fa-calendar"></i>
                                <span>Lecture Timetable</span>
                            </a>
                        </li>
                        <li>
                            <a class="" href="classroom_start.php">
                                <i class="fa fa-comment-o"></i>
                                <span>Classroom</span>
                            </a>
                        </li>
                        <li>
                            <a class="" href="staf_messages.php">
                                <i class="fa fa-envelope"></i>
                                <span>Messages</span>
                            </a>
                        </li>
                    <?php } ?>

                    <li>
                        <a class="" href="feedback.php">
                            <i class="fa fa-envelope"></i>
                            <span>Portal Feedback</span>
                        </a>
                    </li>
                    <?php if($_SESSION['cat'] =="Administrator"){ ?>
                        <li>
                            <a class="" href="logsview_feedback.php">
                                <i class="fa fa-home"></i>
                                <span>Portal Feedback Report</span>
                            </a>
                        </li>
                    <?php } ?>

                </ul>
		    </nav>
		    
			<hr class="separator" />
			
		</div>

	</div>

</aside>
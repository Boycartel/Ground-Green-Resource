<?php
require_once 'db_connect2.php';



//if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['csrf_token']) && validateToken($_POST['csrf_token'])) {
if (isset($_POST['username']) && isset($_POST['password'])) {
	$staffid = $_POST['username'];
	$password = $_POST['password'];

	$staffid = stripslashes($staffid);
	$password = stripslashes($password);

	$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	$yesLogin = false;
	$sql2 = "SELECT sn, password2, staffid FROM users WHERE staffid= '$staffid' AND active_status = 1";
	$result2 = $conn->query($sql2);
	if ($result2->num_rows > 0) {
		while ($row2 = $result2->fetch_assoc()) {
			if (md5($password) == $row2['password2']) {
				// Log user in
				session_regenerate_id();
				$_SESSION['loggedin'] = true;
				$_SESSION['userID'] = $row2['sn'];
				$_SESSION['fileNo'] = $row2['staffid'];
				$sn = $row2['sn'];
				$sql = "UPDATE users SET online_status ='Online' WHERE sn = '$sn'";
				$result = $conn->query($sql);
				$yesLogin = true;
				//include_once 'sessions_staf_others.php';
			} else {
				// Incorrect password
				$_SESSION['errormsg'] = 'Incorrect password!';
				header('Location: ../index_staff.php');
			}
		}
	} else {
		// Not an active user
		$_SESSION['errormsg'] = 'Not an active user!';
		header('Location: ../index_staff.php');
	}

	$conn->close();

	if ($yesLogin == true) {

		include_once 'sessions_staf_others.php';
	}
	/*
	$C = connect();
	if ($C) {
		$staffid = stripslashes($staffid);
		$staffid = mysqli_real_escape_string($C, $staffid);

		$password = stripslashes($password);
		$password = mysqli_real_escape_string($C, $password);


		//$hourAgo = time() - 60 * 60;
		$res = sqlSelect($C, "SELECT sn, password2, staffid FROM users WHERE staffid= '$staffid' AND active_status = 1");
		//$res = sqlSelect($C, 'SELECT staffid, password2 FROM users WHERE email=? GROUP BY users.id', 'is', $hourAgo, $email);

		if ($res && $res->num_rows === 1) {
			$user = $res->fetch_assoc();
			//if (password_verify($_POST['password'], $user['password2'])) {
			if (md5($password) == $user['password2']) {
				// Log user in
				session_regenerate_id();
				$_SESSION['loggedin'] = true;
				$_SESSION['userID'] = $user['sn'];
				$_SESSION['fileNo'] = $user['staffid'];
				$sn = $user['sn'];
				$sql = "UPDATE users SET online_status ='Online' WHERE sn = '$sn'";
				$result = $conn->query($sql);

				include_once 'sessions_staf_others.php';
			} else {
				// Incorrect password
				$_SESSION['errormsg'] = 'Incorrect password!';
				header('Location: ../index_staff.php');
			}

			$res->free_result();
		} else {
			// Incorrect username
			$_SESSION['errormsg'] = 'Incorrect File Number!/or password! or not an active user!';
			header('Location: ../index_staff.php');
		}
		$C->close();
	} else {
		// Incorrect username
		$_SESSION['errormsg'] = 'Incorrect File Number and/or password!';
		header('Location: ../index_staff.php');
	}
	*/
} else {
	$_SESSION['errormsg'] = 'Incorrect File Number and/or password!';
	header('Location: ../index_staff.php');
}

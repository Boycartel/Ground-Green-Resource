<aside id="sidebar-left" class="sidebar-left">
				
	<div class="sidebar-header">
		<div class="sidebar-title">
			Navigation
		</div>
		<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
			<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
		</div>
	</div>

	<div class="nano">
		<div class="nano-content">
			<nav id="menu" class="nav-main" role="navigation">
				<div style="text-align:center">
		            
		            <span class="profile-ava">  
		                       	
		                <?php
		                    echo "<img alt=''  class='img-circle' src='https://eportal.futminna.edu.ng/pg/uploads/".$_SESSION['stdid']."_passport.jpg' width='100' height='100'>";
		                ?>                             
		            </span>
		        </div>
				<ul class="nav nav-main">
					<li class="nav-active">
						<a href="home_pg.php">
							<i class="fa fa-home" aria-hidden="true"></i>
							<span>Dashboard</span>
						</a>
					</li>
					<li class="nav">
						<a href="pg_results.php">
							<i class="fa fa-file"></i>
							<span>Result</span>
						</a>
					</li>
					<li class="nav-parent">
						<a>
							<i class="fa fa-list" aria-hidden="true"></i>
							<span>Course Reg.</span>
						</a>
						<ul class="nav nav-children">
							<li><a class="" href="pg_course_reg.php">New Course Registration</a></li>
		                  	<li><a class="" href="stu_registered_course.php">Registered Courses</a></li>
						</ul>
					</li>
		            <li class="nav">
						<a href="stu_courseware.php">
							<i class="fa fa-briefcase"></i>
							<span>Courseware</span>
						</a>
					</li>
					<li class="nav">
						<a href="mydept.php">
							<i class="fa fa-institution (alias)"></i>
							<span>My Department</span>
						</a>
					</li>
                    <li>
                        <a class="" href="classroom_stu_start.php">
                            <i class="fa fa-comment-o"></i>
                            <span>Classroom</span>
                        </a>
                    </li>
					<li class="nav">
						<a href="stu_library.php">
							<i class="fa fa-book"></i>
							<span>Dept. e-Resources</span>
						</a>
					</li>
					<li class="nav">
						<a href="stu_lecturetimetable.php">
							<i class="fa fa-calendar"></i>
							<span>Lecture Timetable</span>
						</a>
					</li>
					<li class="nav">
						<a href="stu_messages.php">
							<i class="fa fa-envelope"></i>
							<span>Messages</span>
						</a>
					</li>
					<li class="nav">
						<a href="miss_session.php">
							<i class="fa fa-tasks"></i>
							<span>Missing Session(s)</span>
						</a>
					</li> 
					<li class="nav">
						<a href="feedback.php">
							<i class="fa fa-comment-o"></i>
							<span>Portal Feedback</span>
						</a>
					</li>    
		         	
		        </ul>
		    </nav>
		    
			<hr class="separator" />
			
			<br />
      		<center><a class="" href=""><span><p>Powered by ITS</p></span></a></center>
		</div>

	</div>

</aside>
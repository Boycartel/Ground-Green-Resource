<?php

// Database Credentials
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'naub_results');
//define('DB_DATABASE', 'futcoursereg2_new');
define('DB_DATABASE2', 'std_profile_naub_old');
//define('DB_DATABASE2', 'std_profile');
define('DB_DATABASE4', 'pg_database');
define('DB_DATABASE5', 'futcoursereg2_pg');
define('DB_DATABASE6', 'staff_website');
define('DB_DATABASE7', 'staff_record');
define('DB_DATABASE8', 'classroom');
define('DB_DATABASE9', 'trans_request');
define('DB_DATABASE12', 'staff_passport');




/*
function connect()
{
    $C = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($C->connect_error) {
        return false;
    }
    return $C;
}


function sqlSelect($C, $query, $format = false, ...$vars)
{
    $stmt = $C->prepare($query);
    if ($format) {
        $stmt->bind_param($format, ...$vars);
    }
    if ($stmt->execute()) {
        $res = $stmt->get_result();
        $stmt->close();
        return $res;
    }
    $stmt->close();
    return false;
}


function connect2()
{
    $C = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($C->connect_error) {
        return false;
    }
    return $C;
}



function sqlSelect2($C, $query, $format = false, ...$vars)
{
    $stmt = $C->prepare($query);
    if ($format) {
        $stmt->bind_param($format, ...$vars);
    }
    if ($stmt->execute()) {
        $res = $stmt->get_result();
        $stmt->close();
        return $res;
    }
    $stmt->close();
    return false;
}



// Email Credentials
define('SMTP_HOST', 'mail.mydomain.com');
define('SMTP_PORT', 465);
define('SMTP_USERNAME', 'name@mydomain.com');
define('SMTP_PASSWORD', '<my password>');
define('SMTP_FROM', 'noreply@mydomain.com');
define('SMTP_FROM_NAME', '<your name>');

// Global Variables
define('MAX_LOGIN_ATTEMPTS_PER_HOUR', 5);
define('MAX_EMAIL_VERIFICATION_REQUESTS_PER_DAY', 3);
define('MAX_PASSWORD_RESET_REQUESTS_PER_DAY', 3);
define('PASSWORD_RESET_REQUEST_EXPIRY_TIME', 60 * 60);
define('CSRF_TOKEN_SECRET', '<change me to something random>');
define('VALIDATE_EMAIL_ENDPOINT', 'http://localhost/YouTube/SecureAccountSystem/validate'); #Do not include trailing /
define('RESET_PASSWORD_ENDPOINT', 'http://localhost/Youtube/SecureAccountSystem/resetpassword'); #Do not include trailing /

// Code we want to run on every page/script
date_default_timezone_set('UTC');
*/




function validate_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

//error_reporting(0);
session_set_cookie_params(['samesite' => 'Strict']);
session_start();


/* $session_name = 'sec_session_id';   // Set a custom session name
$secure = true;
// This stops JavaScript being able to access the session id.
$httponly = true;
// Forces sessions to only use cookies.
if (ini_set('session.use_only_cookies', 1) === FALSE) {
    header("Location: ../error.php?err=Could not initiate a safe session (ini_set)");
    exit();
}
// Gets current cookies params.
$cookieParams = session_get_cookie_params();
session_set_cookie_params(
    $cookieParams["lifetime"],
    $cookieParams["path"],
    $cookieParams["domain"],
    $secure,
    $httponly
);
// Sets the session name to the one set above.
session_name($session_name);
session_start();            // Start the PHP session
session_regenerate_id(true);    // regenerated the session, delete the old one. */

$_SESSION['errormsg'] = "";

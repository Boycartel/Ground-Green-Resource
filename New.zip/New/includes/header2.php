<?php
$stutype = $_SESSION['stutype'];
if ($stutype == "UG") {
    include_once 'get_stu_level.php';
}
$dept = $_SESSION['deptcode'];
$regid = $_SESSION["regid"];
//$stdid = $_SESSION["stdid"];
$names = $_SESSION['names'];
$email = $_SESSION['email'];
$deptname = $_SESSION['deptname'];
$corntsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$staff_pic_folder = $_SESSION['staff_pic_folder'];
$getday = date('D');
if ($getday == "Mon") {
    $getday = "M";
} elseif ($getday == "Tue") {
    $getday = "T";
} elseif ($getday == "Wed") {
    $getday = "W";
} elseif ($getday == "Thu") {
    $getday = "Th";
} elseif ($getday == "Fri") {
    $getday = "F";
} elseif ($getday == "Sat") {
    $getday = "S";
}

$closemsg = 0;
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$level_code = "L" . $level;
$level_code_all = "L" . $level . "_stu";

$sql2 = "SELECT * FROM comment WHERE (matricno = '$regid' or matricno = '$level_code' or matricno = '$level_code_all' or matricno = 'All' or matricno = 'All_stu')";
$result2 = $conn_stu->query($sql2);
$totmsg = mysqli_num_rows($result2);

$sql = "SELECT * FROM comment WHERE (matricno = '$regid' or matricno = '$level_code' or matricno = '$level_code_all' or matricno = 'All' or matricno = 'All_stu') AND msgopen = 'NO' ORDER BY id DESC";
$result = $conn_stu->query($sql);
$closemsg = mysqli_num_rows($result);




?>


<div class="navbar-header">
    <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
    <form role="search" class="navbar-form-custom" action="search_results.html">
        <div class="form-group">
            <input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
        </div>
    </form>
    <img src="img/logo.ico" height="50" alt="logo" />
</div>
<ul class="nav navbar-top-links navbar-right">
    <li>
        <span class="m-r-sm text-muted welcome-message" style="color: <?php echo $_SESSION['sch_color'] ?>; font-size:large">Welcome to
            <?php echo $_SESSION['instname'] ?></span>
    </li>
    <li class="dropdown">
        <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
            <i class="fa fa-envelope"></i> <span class="label label-warning"><?php echo $closemsg ?></span>
        </a>
        <ul class="dropdown-menu dropdown-messages">

            <?php
            $sql = "SELECT * FROM comment WHERE (matricno = '$regid' or matricno = '$level_code' or matricno = '$level_code_all' or matricno = 'All' or matricno = 'All_stu') AND msgopen = 'NO' ORDER BY id DESC";
            $result = $conn_stu->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $cat = $row['cat_coment'];
                    if (is_null($row['recieve_coment'])) {
                        $reccomment = $row['sent_coment'];
                    } else {
                        $reccomment = $row['recieve_coment'];
                    }

                    if ($cat == "Examiner" || $cat == "Ass_Examiner") {
                        $catfull = "Exam Officer";
                    } elseif ($cat == "HOD") {
                        $catfull = "HOD";
                    } elseif ($cat == "L100" || $cat == "L200" || $cat == "L300" || $cat == "L400" || $cat == "L500" || $cat == "spill_over") {
                        $catfull = "Level Adviser";
                    } elseif ($cat == "Sub_Admin" || $cat == "Administrator") {
                        $catfull = "Admin";
                    } else {
                        $catfull = $cat;
                    }
                    //if($cat==""){
            ?>
                    <li>

                        <div class="dropdown-messages-box">
                            <a href="#" class="pull-left">
                                <?php if ($cat == "Dean" || $cat == "HOD" || $cat == "Examiner" || $cat == "L100" || $cat == "L200" || $cat == "L300" || $cat == "L400" || $cat == "L500" || $cat == "spill_over" || $cat == "Administrator" || $cat == "Sub_Admin") { ?>
                                    <?php
                                    $staff_pic_folder = $_SESSION['staff_pic_folder'];
                                    $filename = $staff_pic_folder . $row['msgid'] . '.jpg';

                                    if (file_exists($filename)) {
                                        echo "<img alt=''  class='img-circle' src='$staff_pic_folder" . $row['msgid'] . ".jpg' width='35' height='35'>";
                                    } else {
                                        echo "<img alt=''  class='img-circle' src='img/logo.ico' width='50' height='50'>";
                                    }


                                    ?>
                                <?php } else { ?>
                                    <?php
                                    $sql3 = "SELECT matric_no, dept_code FROM std_data_view WHERE matric_no = '$cat'";
                                    $result3 = $conn2->query($sql3);
                                    if ($result3->num_rows > 0) {
                                        while ($row3 = $result3->fetch_assoc()) {
                                            //$getstdid = $row3['stdid'];
                                            $deptother = strtolower($row3['dept_code']);
                                        }
                                    }

                                    $matpassport = str_replace("/", "_", $regid);
                                    echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='50' height='50'>";
                                    ?>

                                <?php } ?>
                            </a>
                            <div>
                                <small class="pull-right"><?php echo date("d/m/Y", strtotime($row['date_time'])) ?></small>
                                <strong><?php echo $catfull ?></strong>. <br>
                                <small class="text-muted"><?php echo $reccomment ?></small>
                            </div>
                        </div>




                    </li>
                    <li class="divider"></li>
            <?php

                    //}
                }
            }
            //
            ?>



            <li>
                <div class="text-center link-block">
                    <a href="stu_messages.php">
                        <i class="fa fa-envelope"></i> <strong>View All</strong>
                    </a>
                </div>
            </li>

        </ul>

    </li>
    <li class="dropdown">
        <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
            <?php
            $sql = "select count('1') from gettimetable WHERE matric_no = '$regid'";
            $result = $conn->query($sql);
            $nrow = mysqli_fetch_array($result);
            ?>
            <i class="fa fa-bell"></i> <span class="label label-primary"><?php echo $nrow[0] ?></span>
        </a>
        <ul class="dropdown-menu dropdown-alerts">
            <?php if ($nrow[0] > 0) { ?>
                <li>Your today's lecture</li>
                <li class="divider"></li>
            <?php } ?>
            <?php

            $sql = "SELECT * FROM gettimetable WHERE matric_no = '$regid' ORDER BY thetime";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $ccodearry = $row["ccode"];
                    $timearry = $row["thetime"];
            ?>
                    <li>

                        <div>
                            <i class="fa fa-envelope fa-fw"></i> </i><?php echo $ccodearry ?>
                            <span class="pull-right text-muted small"><?php echo $timearry ?></span>
                        </div>
                    </li>
                    <li class="divider"></li>
            <?php
                }
            }
            ?>
            <li>
                <div class="text-center link-block">
                    <a href="stu_lecturetimetable.php">
                        <strong>View All</strong>
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>
            </li>

        </ul>

    </li>

    <li>
        <a href="faq_stu.php">
            <i class="fa fa-star"></i> FAQ
        </a>
    </li>
    <li>
        <a href="includes/logout_stu.php">
            <i class="fa fa-sign-out"></i> Log out
        </a>
    </li>

</ul>
<?php
$conn_stu->close();
$conn2->close();
$conn->close();
?>
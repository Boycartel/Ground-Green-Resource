<?php
//include_once 'db_connect.php';
//include_once 'functions.php';
//sec_session_start(); // Our custom secure way of starting a PHP session.
//include_once 'my_db.php';

$servername = "localhost";
$loginusername = "root";
$loginpassword = "";
$dbname = "pg_database";

//$servername = "localhost";
//$loginusername = "futdbuser2";
//$loginpassword = "$65^432#";
//$dbname = "pg_database";




if (isset($_POST['login'])) {
	$username = $_POST['username'];
	$password = $_POST['password']; // The hashed password.
	$mysqli = new mysqli($servername, $loginusername, $loginpassword, $dbname);
	// Check connection
	if ($mysqli->connect_error) {
		die("Connection failed: " . $mysqli->connect_error);
	}
	include_once 'getencrypt.php';
	$sql = "SELECT * FROM reg_password WHERE stdid = '$username' AND pword2 = '$encryption'";
	$result = $mysqli->query($sql);
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
			$names = $row["CandName"];
		}

		$servername = "localhost";

		$db_username = "root";
		$db_password = "";

		//$db_username = "futdbuser2";
		//$db_password = "$65^432#";

		$dbname = "futcoursereg2_pg";
		$dbname2 = "stdlogin";
		$dbname3 = "eportal";
		$dbname4 = "pg_database";
		$dbname5 = "futcoursereg2";
		$dbname6 = "staff_website";
		$dbname7 = "staff_record";
		$dbname8 = "classroom";

		session_start();

		$_SESSION['servername'] = $servername;
		$_SESSION['db_username'] = $db_username;
		$_SESSION['db_password'] = $db_password;

		$_SESSION['dbname'] = $dbname;
		$_SESSION['dbname2'] = $dbname2;
		$_SESSION['dbname3'] = $dbname3;
		$_SESSION['dbname4'] = $dbname4;
		$_SESSION['dbname5'] = $dbname5;
		$_SESSION['dbname6'] = $dbname6;
		$_SESSION['dbname7'] = $dbname7;
		$_SESSION['dbname8'] = $dbname8;

		$conn = new mysqli($servername, $db_username, $db_password, $dbname);
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}


		$conn4 = new mysqli($servername, $db_username, $db_password, $dbname4);
		if ($conn4->connect_error) {
			die("Connection failed: " . $conn4->connect_error);
		}

		$sql = "SELECT * FROM e_data_profile WHERE stdid = '$username'";
		$result = $conn4->query($sql);
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				$regid = $row["regid"];
			}
		}

		$sql = "SELECT * FROM pgapplication WHERE applicant_id = '$username'";
		$result = $conn4->query($sql);
		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				$email = $row["email"];
				$dept = $row["deptcode"];
			}
		}

		$sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			// output data of each row
			while ($row = $result->fetch_assoc()) {
				$deptname = $row["DeptName"];
				$schcode = $row["School"];
			}
		}

		$sql = "SELECT SchCode, SchName FROM schoolname WHERE SchCode = '$schcode'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			while ($row = $result->fetch_assoc()) {
				$schname = $row["SchName"];
			}
		}

		$sql = "SELECT session_title, semester FROM sessions";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			// output data of each row
			while ($row = $result->fetch_assoc()) {
				$corntsession = $row["session_title"];
				$cursemester = $row["semester"];
			}
		}

		$sessionprevy = substr($corntsession, 0, 4) - 1;
		$_SESSION['prevsession'] = $sessionprevy . "/" . substr($corntsession, 0, 4);
		$_SESSION['logintype'] = "student";
		$_SESSION['stutype'] = "PG";
		$_SESSION['deptname'] = $deptname;
		$_SESSION['deptcode'] = strtolower($dept);
		$_SESSION['schname'] = $schname;
		$_SESSION['schcode'] = $schcode;
		$_SESSION['corntsession'] = $corntsession;
		$_SESSION['downlcurse'] = "";
		$_SESSION['downlsession'] = "";


		$sql = "DELETE FROM add_courses_cat WHERE Regn1 ='$regid'";
		$result = $conn->query($sql);

		$_SESSION['names'] = $names;
		$_SESSION['regid'] = $regid;
		$_SESSION['stdid'] = $username;
		$_SESSION['othername'] = $othername;
		$_SESSION['defer1st'] = $defer1st;
		$_SESSION['siwesstatus'] = $siwesstatus;
		$_SESSION['email'] = $email;
		$_SESSION['usertype'] = "Student";
		$_SESSION['progtype'] = "PG";

		date_default_timezone_set("Africa/Lagos");
		$lastlogtime = date("l d/m/Y h:i:sa");


		//$_SESSION['fulname'] = $fulname;

		$conn->close();
		$conn4->close();
		header('Location: ../home_pg.php');
	} else {
		header('Location: ../login_pg.php?error=1');
	}
	$mysqli->close();
} else {
	// The correct POST variables were not sent to this page.
	echo 'Invalid Request';
}
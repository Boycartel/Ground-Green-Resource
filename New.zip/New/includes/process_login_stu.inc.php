<?php

require_once 'db_connect2.php';

$_SESSION['errormsg'] = "";


//if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['csrf_token']) && validateToken($_POST['csrf_token'])) {
if (isset($_POST['username']) && isset($_POST['password'])) {
    $regid = strtoupper($_POST['username']);
    $password = $_POST['password'];

    $regid = stripslashes($regid);
    $password = stripslashes($password);

    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }

    $sql3 = "SELECT * FROM std_data_view WHERE matric_no= '$regid'";
    $result3 = $conn2->query($sql3);
    if ($result3->num_rows > 0) {
        while ($row3 = $result3->fetch_assoc()) {
            $stdid = $row3["stdid"];
            $sql = "UPDATE std_login SET matric_no = '$regid' WHERE stdid ='$stdid'";
            $result = $conn2->query($sql);
        }
    }
    $yesLogin = false;

    $sql2 = "SELECT * FROM std_login WHERE matric_no= '$regid'";
    $result2 = $conn2->query($sql2);
    if ($result2->num_rows > 0) {
        while ($row2 = $result2->fetch_assoc()) {
            if (md5($password) == $row2['password']) {
                session_regenerate_id();
                $_SESSION['loggedin'] = true;
                $_SESSION['userID'] = $row2['id'];
                $_SESSION['regid'] = $row2['matric_no'];

                $yesLogin = true;
                //include_once 'sessions_stu_others.php';
            } else {
                $_SESSION['userConnect'] = false;
                $_SESSION['errormsg'] = 'Incorrect password!';
                header('Location: ../index_stu.php');
            }
        }
    } else {
        // Not an active user
        $_SESSION['userConnect'] = false;
        $_SESSION['errormsg'] = 'Not an active user!';
        header('Location: ../index_stu.php');
    }
    $conn2->close();

    if ($yesLogin == true) {
        $regid = $_SESSION['regid'];
        include_once 'sessions_stu_others.php';
    }
} else {
    $_SESSION['errormsg'] = 'Incorrect Matric Number and/or password!';
    header('Location: ../index_stu.php');
}


/* //if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['csrf_token']) && validateToken($_POST['csrf_token'])) {
if (isset($_POST['username']) && isset($_POST['password'])) {
    $regid = $_POST['username'];
    $password = $_POST['password'];

    $C = connect2();
    if ($C) {
        $regid = stripslashes($regid);
        $regid = mysqli_real_escape_string($C, $regid);

        $password = stripslashes($password);
        $password = mysqli_real_escape_string($C, $password);
        //$hourAgo = time() - 60 * 60;
        $res = sqlSelect2($C, "SELECT * FROM std_login WHERE stdid= '$regid' AND active_status = 1");
        //$res = sqlSelect($C, 'SELECT staffid, password2 FROM users WHERE email=? GROUP BY users.id', 'is', $hourAgo, $email);

        if ($res && $res->num_rows === 1) {
            $user = $res->fetch_assoc();
            //if (password_verify($_POST['password'], $user['password2'])) {
            if (md5($password) == $user['password']) {
                // Log user in
                session_regenerate_id();
                $_SESSION['loggedin'] = true;
                $_SESSION['userID'] = $user['id'];
                $_SESSION['regid'] = $user['stdid'];
                $regid = $user['stdid'];
                include_once 'sessions_stu_others.php';
            } else {
                // Incorrect password
                $_SESSION['errormsg'] = 'Incorrect password!';
                header('Location: ../index.php');
            }

            $res->free_result();
        } else {
            // Incorrect username
            $_SESSION['errormsg'] = 'Incorrect Matric Number!/or password! or not an active user!';
            header('Location: ../index.php');
        }
        $C->close();
    } else {
        // Incorrect username
        $_SESSION['errormsg'] = 'Incorrect Matric Number and/or password!';
        header('Location: ../index.php');
    }
} else {
    $_SESSION['errormsg'] = 'Incorrect Matric Number and/or password!';
    header('Location: ../index.php');
} */
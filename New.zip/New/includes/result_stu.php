<table class="table table-bordered" cellspacing="0" rules="all" border="1">
    <thead>
        <tr>
            <th>Course Code</th>
            <th>Course Title</th>
            <th>Unit</th>
            <th>Semester</th>
            <th>Session</th>
            <th>Grade</th>
            <th>GP</th>
        </tr>
    </thead>
    <tbody>
        <?php
        //echo $studept . "XXXXX";
        $getprevY = substr($session1, 0, 4);
        $StuCurSess = str_ireplace("/", "_", $session1);

        $deptcorreg = "correg_" . $StuCurSess;

        $dept_db = $_SESSION['deptdb'] . strtolower($studept);
        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
        if ($conn_stu->connect_error) {
            die("Connection failed: " . $conn_stu->connect_error);
        }

        $sql = "SELECT * FROM sessions WHERE getkey = 'key1'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $reg_session = $row["session_title"];
                $reg_semester = $row["semester"];
                $results_session = $row["result_session"];
                $results_semester = $row["result_semester"];
                $stu_results = $row["stu_results"];
            }
        }

        if (!empty($session1)) {
            if ($resultsemester == "1ST") {
                if ($session1 == $resultsession) {
                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis = '$session1' AND SemTaken  = '1ST' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
                } else {
                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis = '$session1' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
                }
            } else {
                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis = '$session1' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
            }

            $result = $conn_stu->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $grade = $row['grade'];
                    $gp = $row['point'];
                    $CCode = $row['CCode'];
                    $SemTaken = $row['SemTaken'];
                    if ($stu_results == "Disable" && $session1 == $results_session && $SemTaken == $results_semester) {
                    } else {
                        echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['SessionRegis']}</td><td>$grade</td><td>$gp</td></tr>\n";

                        if ($_SESSION['instcode'] == "FPB") {
                            $sql2 = "SELECT * FROM absent_students WHERE matric_no = '$regid' AND CCode = '$CCode' AND status1 = 'R'";
                            $result2 = $conn_stu->query($sql2);
                            if ($result2->num_rows > 0) {
                                if ($grade == "F") {
                                } else {
                                    $sumgp += $gp;
                                    $sumunits += $row['CUnit'];
                                }
                            } else {
                                $sumgp += $gp;
                                $sumunits += $row['CUnit'];
                            }
                        } else {
                            $sumgp += $gp;
                            $sumunits += $row['CUnit'];
                        }
                    }
                }
            }
        }
        $conn_stu->close();

        echo "<tr><td></td><th>Total</th><th>$sumunits</th><td></td><td></td><td></td><th>$sumgp</th></tr>";
        ?>
    </tbody>
</table>
<br>
<center>
    <?php
    $totsumunits += $sumunits;
    $totsumgp += $sumgp;
    ?>
    <?php if ($sumunits !== 0) {
        if ($sumunits == 0) {
            echo "GPA = " . 0;
        } else {
            echo "GPA = " . number_format((float)$sumgp / $sumunits, 2, '.', '');
        }

        echo "<br>";
    } else {
    }

    ?>

    <?php if ($totsumunits !== 0) ?>
    CGPA = <?php
            if ($totsumunits == 0) {
                echo "0";
            } else {
                echo number_format((float)$totsumgp / $totsumunits, 2, '.', '');
            }

            ?>

</center>
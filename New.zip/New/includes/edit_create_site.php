<?php
//include_once 'includes/functions.php';
//sec_session_start();
require_once 'db_connect.php';


$staffid = $_SESSION['staffid'];
$dept = $_SESSION['deptcode'];
$names = $_SESSION['names'];
$deptname = $_SESSION['deptname'];
$ecptdpassword = $_SESSION['ecptdpassword'];

$stafid = str_replace(".", "_", $staffid);

$sql = "SELECT * FROM stafflist WHERE staffid = '$staffid'";
$result = $conn6->query($sql);

if ($result->num_rows > 0) {
	echo "<center><a href='http://staff.futminna.edu.ng'><span><h3>Click to Login</h3></span></a></center>";
	//header('Location: localhost/staffsite/MAT.php');
	//header('Location: https://www.futminna.edu.ng');
	exit;
} else {
	$sql = "INSERT INTO stafflist (staffid, password, nametitle, fullname, deptcode, department, PresRank, YearObtain) values('$staffid', '$ecptdpassword','XX', '$names', '$dept','$deptname', '8', '8888')";
	$result = $conn6->query($sql);

	// sql to create table
	$TabCreate = strtolower($staffid) . "_journals";
	$sql = "CREATE TABLE " . $TabCreate . " (sn INT NOT NULL AUTO_INCREMENT PRIMARY KEY, id int, journal_title Text, abstract Text, downlodable Text, paperauthor Text, paperyera Text, paperpublisher Text)";
	$result = $conn6->query($sql);

	$TabCreate = strtolower($staffid) . "_journals2";
	$sql = "CREATE TABLE " . $TabCreate . " (sn INT NOT NULL AUTO_INCREMENT PRIMARY KEY, id int, titleyearauthor Text, paperyear Text)";
	$result = $conn6->query($sql);



	echo "<center><a href='http://staff.futminna.edu.ng'><span><h3>Click to Login</h3></span></a></center>";
}

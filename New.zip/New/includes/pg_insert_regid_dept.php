<?php
require_once 'db_connect.php';
include_once 'includes/functions2.php';
//include_once 'includes/passw_reset_staff.inc.php';


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Federal University of Technology, Minna">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="FUT, FUTMinna, Minna, Federal, Result, Results, Academic">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>FUT Minna e-Portal</title>

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
    <script type="text/JavaScript" src="js/sha512.js"></script>
    <script type="text/JavaScript" src="js/forms.js"></script>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

<body class="login-img3-body" style="background-image:url(img/bg-1.jpg)">

    <div class="container">
        <form action="includes/passw_reset_stu.inc.php" method="post" name="login_form">
            <div class="row">
                <div class="col-lg-4">

                </div>
                <div class="col-lg-4" style="color:#000">
                    <center>
                        <h3>Enter Registration Number and Department<h3>
                    </center>

                    <div style="color:#000">

                        <?php
                        $_SESSION['iniregid'] = $username;
                        ?>
                        <div class="input-group">
                            <label class="control-label col-lg-3" for="content">Student's ID :</label>
                            <div class="col-lg-8">
                                <input type="text" name="stdid" class="form-control" value="<?php echo $_SESSION['iniregid'] ?>" readonly="readonly">
                            </div>
                        </div>
                        <div class="input-group">
                            <label class="control-label col-lg-3" for="content">Registration's No. :</label>
                            <div class="col-lg-8">
                                <input type="text" name="regid" id="regid" class="form-control" value="" autofocus>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-lg-3" for="content">Select Department:</label>
                            <div class="col-lg-8">
                                <select class="country form-control" style="color:#000000" name="dept">
                                    <option value="SelectItem">Select Item</option>
                                    <?php

                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                    $result = $mysqli4->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $deptcode2 = strtolower($row["DeptCode"]);
                                            $deptname2 = $row["DeptName"];
                                            echo "<option value=$deptcode2>$deptname2</option>";
                                        }
                                    }

                                    //$mysqli2->close();


                                    ?>

                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <!-- Buttons -->
                            <div class="col-lg-offset-2 col-lg-9">
                                <button type="submit" class="btn btn-primary">Submit</button>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-4">

                </div>
            </div>

        </form>



</body>

</html>
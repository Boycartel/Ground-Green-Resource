<?php


$userdept = $_SESSION['deptcode'];
$userid = $_SESSION["staffid"];
$usernames = $_SESSION['names'];
$names = $_SESSION['names'];
$useremail = $_SESSION['email'];
$deptname = $_SESSION['deptname'];
//$cat = $_SESSION['cat'];
$corntsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$getday = date('D');
if ($getday == "Mon") {
    $getday = "M";
} elseif ($getday == "Tue") {
    $getday = "T";
} elseif ($getday == "Wed") {
    $getday = "W";
} elseif ($getday == "Thu") {
    $getday = "Th";
} elseif ($getday == "Fri") {
    $getday = "F";
} elseif ($getday == "Sat") {
    $getday = "S";
}

$closemsg = 0;

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$sql2 = "SELECT * FROM staff_comment WHERE msgid = '$userid' AND msgopen = 'NO'";
$result2 = $conn->query($sql2);
$totmsg = mysqli_num_rows($result2);

//$matricno = "";
$sql = "SELECT * FROM staff_comment WHERE msgid = '$userid' AND msgopen = 'NO' ORDER BY id DESC";
$result = $conn->query($sql);
$closemsg = mysqli_num_rows($result);


?>


<div class="navbar-header">

    <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>

    <form role="search" class="navbar-form-custom" action="search_results.html">
        <div class="form-group">
            <input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
        </div>
    </form>
    <img src="img/logo.ico" height="50" alt="logo" />
</div>
<ul class="nav navbar-top-links navbar-right">
    <li>
        <span class="m-r-sm text-muted welcome-message" style="color: <?php echo $_SESSION['sch_color'] ?>; font-size:large"><strong>Welcome to
                <?php echo $_SESSION['instname'] ?></strong></span>
    </li>
    <li class="dropdown">
        <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">
            <i class="fa fa-envelope"></i> <span class="label label-warning"><?php echo $closemsg ?></span>
        </a>
        <ul class="dropdown-menu dropdown-messages">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $matricno = $row['matricno'];
                    //$reccomment = $row['recieve_coment'];
                    if (is_null($row['recieve_coment'])) {
                        $reccomment = $row['sent_coment'];
                    } else {
                        $reccomment = $row['recieve_coment'];
                    }
                    $sql2 = "SELECT * FROM std_data_view WHERE matric_no = '$matricno'";
                    $result2 = $conn2->query($sql2);
                    if ($result2->num_rows > 0) {
                        while ($row2 = $result2->fetch_assoc()) {
                            $stdid = $row2["stdid"];
                            $stuname = $row2['first_name'] . " " . $row2['other_name'] . " " . $row2['surname'];
                            //$dept_id = $row2['dept_id'];
                            $deptother = $row2['dept_code'];
                        }
                    }

                    $sql2 = "SELECT * FROM std_login WHERE stdid = '$stdid'";
                    $result2 = $conn2->query($sql2);
                    if ($result2->num_rows > 0) {
                        $passportid = $stdid;
                    } else {
                        $passportid = $matricno;
                    }
                    //if($cat==""){
            ?>

                    <?php //if(strlen($row['sent_coment'])<2){ 
                    ?>

                    <li>
                        <div class="dropdown-messages-box">
                            <a href="#" class="pull-left">
                                <?php

                                $matpassport = str_replace("/", "_", $matricno);
                                echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='50' height='50'>";
                                ?>

                            </a>
                            <div>
                                <small class="pull-right"><?php echo date_format(date_create($row['date_time']), "d/m/Y") ?></small>
                                <strong><?php echo $stuname ?>(<?php echo $matricno ?>)</strong>. <br>
                                <small class="text-muted"><?php echo $reccomment ?></small>
                            </div>
                        </div>
                    </li>
                    <li class="divider"></li>


            <?php

                    //}
                }
            }
            //
            ?>

            <li>
                <div class="text-center link-block">
                    <a href="staf_messages.php">
                        <i class="fa fa-envelope"></i> <strong>View All</strong>
                    </a>
                </div>
            </li>

        </ul>

    </li>
    <li class="dropdown">
        <?php
        $sql = "select count('1') from gettimetable WHERE matric_no = '$userid'";
        $result = $conn->query($sql);
        $nrow = mysqli_fetch_array($result);
        ?>
        <?php if ($nrow[0] !== 0) { ?>

            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">

                <i class="fa fa-bell"></i> <span class="label label-primary"><?php echo $nrow[0] ?></span>
            </a>
        <?php } else { ?>
            <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">

                <i class="fa fa-bell"></i> <span class="label label-primary">0</span>
            </a>
        <?php } ?>
        <ul class="dropdown-menu dropdown-alerts">
            <?php if ($nrow[0] > 0) { ?>
                <li>Your today's lecture</li>
                <li class="divider"></li>
            <?php } ?>
            <?php

            $sql = "SELECT * FROM gettimetable WHERE matric_no = '$userid' ORDER BY thetime";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $ccodearry = $row["ccode"];
                    $timearry = $row["thetime"];
            ?>


                    <li>
                        <div>
                            <i class="fa fa-book fa-fw"></i><?php echo $ccodearry ?>
                            <span class="pull-right text-muted small"><?php echo $timearry ?></span>
                        </div>
                    </li>
                    <li class="divider"></li>

            <?php
                }
            }
            ?>
            <li>
                <div class="text-center link-block">
                    <a href="staf_lecturetimetableinpt.php">
                        <strong>View All</strong>
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>
            </li>



        </ul>



    </li>
    <?php
    $conn->close();
    $conn2->close();
    ?>


    <li>
        <a href="user_guide.php">
            <i class="fa fa-eye"></i> User's Guide
        </a>
    </li>
    <li>
        <a href="includes/logout.php">
            <i class="fa fa-sign-out"></i> Log out
        </a>
    </li>
    <li>
        <a class="right-sidebar-toggle">
            <i class="fa fa-tasks"></i>
        </a>
    </li>
</ul>
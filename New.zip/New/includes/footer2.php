<div class="pull-right">
    IHSAN Technology Solution ltd
</div>
<div>
    <strong>Copyright</strong> ICT, <?php echo $_SESSION['instcode'] ?> &copy; 2023-2028
</div>
<?php
//require_once 'db_connect.php';
$stuwithdrawn = false;
$graduate = false;

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
$result = $conn2->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $stdid = $row["stdid"];
        $first_name = $row["first_name"];
        $other_name = $row["other_name"];
        $surname = strtolower($row["surname"]);
        $surname = ucwords($surname);
        $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
        $names = strtolower($names);
        $names = ucwords($names);

        $dept = strtolower($row["dept_code"]);

        $defer1st = $row["defer1styear"];
        $email = $row["sch_email"];
        $jamb = $row["jamb_appl_no"];
        $engrrep100level = $row["engrrep100level"];
        $Dept_Option = $row["Dept_Option"];
        $curriculum = $row["curriculum"];
        $stateorigin = $row["state"];
        $lga = $row["lga"];
        $entry_session = $row["entry_session"];
        $modeofentry = $row["modeofentry"];
        $entry_level = $row["entry_level"];
        $YAddmitted = $row["YAddmitted"];
        $level = $row["level"];
    }
}
//$regid = $username;
//session_destroy();
$sql = "SELECT * FROM std_login WHERE stdid = '$stdid'";
$result = $conn2->query($sql);
if ($result->num_rows > 0) {
    $passportid = $stdid;
} else {
    $passportid = $regid;
}


$_SESSION['dbname1'] = $_SESSION['dbname2'] = $_SESSION['dbname3'] = $_SESSION['dbname4'] = $_SESSION['dbname5'] = $_SESSION['dbname6'] = $_SESSION['dbname7'] = $_SESSION['dbname8'] = $_SESSION['dbname9'] = $_SESSION['dbname10'] = $_SESSION['dbname11'] = "";

$sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        $deptname = $row["DeptName"];
        $siwesstatus = $row["siwes"];
        $schcode = $row["School"];
        $deptoption = $row["deptoption"];
        $prog_no_years = $row["prog_no_years"];
    }
}

$sql = "SELECT * FROM withdraw_stu WHERE matno = '$regid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $_SESSION['widnames'] = $row["name1"];
        $_SESSION['widdate'] = $row["date1"];
        $_SESSION['widregid'] = $regid;
    }
    $stuwithdrawn = true;
}

$sql = "SELECT * FROM register WHERE Regn = '$regid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $_SESSION['gradregid'] = $regid;
        $_SESSION['gradnames'] = $row["Name_full"];
        $_SESSION['yearGrd'] = $row["yearGrd"];
        $_SESSION['GradDept'] = $row["DeptCode"];
    }
    $graduate = true;
}
$sql = "SELECT SchCode, SchName FROM schoolname WHERE SchCode = '$schcode'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $schname = $row["SchName"];
    }
}

$sql = "SELECT * FROM sessions WHERE getkey='key1'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $corntsession = $row["session_title"];
        $cursemester = $row["semester"];
        $resultsession = $row["result_session"];
        $resultsemester = $row["result_semester"];
    }
}

$sessionprevy = substr($corntsession, 0, 4) - 1;
$_SESSION['prevsession'] = $sessionprevy . "/" . substr($corntsession, 0, 4);

if ($_SESSION['prevsession'] == "2020/2021") {
    $_SESSION['prevsession'] = "2019/2020";
}
$_SESSION['logintype'] = "student";
$_SESSION['stutype'] = "UG";
$_SESSION['deptname'] = $deptname;
$_SESSION['deptcode'] = strtolower($dept);
$_SESSION['stucurriculum'] = strtolower($curriculum);
$_SESSION['schname'] = $schname;
$_SESSION['schcode'] = $schcode;
$_SESSION['stulevel'] = $level;
$_SESSION['corntsession'] = $corntsession;
$_SESSION['cursemester'] = $cursemester;
$_SESSION['downlcurse'] = "";
$_SESSION['downlsession'] = "";
$_SESSION['deptoption'] = $deptoption;
$_SESSION['Dept_Option'] = $Dept_Option;
$_SESSION['resultsession'] = $resultsession;
$_SESSION['resultsemester'] = $resultsemester;

$sql = "DELETE FROM add_courses_cat WHERE Regn1 ='$regid'";
$result = $conn->query($sql);

$_SESSION['names'] = $names;
$_SESSION['regid'] = $regid;
$_SESSION['first_name'] = $first_name;
$_SESSION['other_name'] = $other_name;
$_SESSION['surname'] = $surname;
$_SESSION['defer1st'] = $defer1st;
$_SESSION['siwesstatus'] = $siwesstatus;
$_SESSION['email'] = $email;
$_SESSION['jamb'] = $jamb;
$_SESSION['noresult'] = "NO";
$_SESSION['usertype'] = "Student";
$_SESSION['progtype'] = "UG";
$_SESSION['engrrep100level'] = $engrrep100level;
$_SESSION['courseRegSplitSess'] = "2019/2020";
$_SESSION['stateorigin'] = $stateorigin;
$_SESSION['lga'] = $lga;
$_SESSION['entry_session'] = $entry_session;
$_SESSION['modeofentry'] = $modeofentry;
$_SESSION['entry_level'] = $entry_level;
$_SESSION['prog_no_years'] = $prog_no_years;
$_SESSION['passportid'] = $passportid;

$_SESSION['countnewmsg'] = 0;


$timestamp = time();
$_SESSION['lasttime_chat'] = date('h:i:s A', $timestamp);

include_once 'change_it.php';

$_SESSION['YAddmitted'] = $YAddmitted;

/* $stu_pic_folder = $_SESSION['stu_pic_folder'];
$passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
// URL of the image to be downloaded
$imageUrl = $stu_pic_folder . '/' . $passptfile;

// Path where the image will be saved
$matpassport = str_replace("/", "_", $regid);
$savePath = "img/stupassport/$matpassport.jpg";

$ch = curl_init($imageUrl);
$fp = fopen($savePath, "wb");
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_exec($ch);
curl_close($ch);
fclose($fp); */

$sql2 = "DELETE FROM small_chat WHERE date_time < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 DAY))";
$result2 = $conn->query($sql2);

$conn->close();
$conn2->close();

if ($stuwithdrawn == true) {
    header('Location: ../withdrawn.php');
} elseif ($graduate == true) {
    header('Location: ../graduated.php');
} else {
    header('Location: ../home_stu.php');
}

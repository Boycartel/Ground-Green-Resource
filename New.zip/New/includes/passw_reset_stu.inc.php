<?php
require_once 'db_connect.php';
include_once 'config.php';
include_once 'my_db.php';


$error_msg = "";
if (isset($_POST['username'], $_POST['p'])) {
    $username = $_POST['username'];
	$oldpassword = $_POST['oldpassword'];
	$oldpassword = filter_var($oldpassword, FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'p', FILTER_SANITIZE_STRING);
	
	$conn = new mysqli($servernameold, $usernameold, $passwordrootold, $dbnameold);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	$sql = "SELECT * FROM passwcheck_stu WHERE matno = '$username' AND password = '$oldpassword'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		if (strlen($password) != 128) {
			// The hashed pwd should be 128 characters long.
			// If it's not, something really odd has happened
			$error_msg .= '<p class="error">Invalid password configuration.</p>';
		}
		
		if (empty($error_msg)) {
			// Create hashed password using the password_hash function.
			// This function salts it with a random salt and can be verified with
			// the password_verify function.
			$password = password_hash($password, PASSWORD_BCRYPT);
			// Insert the new user into the database
			if ($update_stmt = $mysqli->prepare("UPDATE account SET password = ? WHERE stdid = '$username'")) {
				$update_stmt->bind_param('s', $password);
				// Execute the prepared query.
				if (! $update_stmt->execute()) {
					header('Location: ../error.php?err=Password Change failure: UPDATE');
				}
			}
			$sql2 = "DELETE FROM passwcheck_stu WHERE matno = '$username'";
			$result2 = $conn->query($sql2);
			
			header('Location: ../login_stu.php');
		}
	}else{
		//$error_msg .= '<p class="error">Invalid old password .</p>';
		header('Location: ../passw_reset_stu.php?error=1');
	}
    $conn->close();
}

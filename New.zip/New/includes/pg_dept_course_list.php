<?php
require_once 'db_connect.php';
//include_once 'get_stu_level.php';
if (isset($_POST["country"])) {

	// Capture selected country
	$pickdept = $_POST["country"];
	//$levelcode = substr($level, 0, 1);

	if ($pickdept <> "No") {
?>
		<h2>
			<center>Pick Courses from Other Department</center>
		</h2>
		<?php

		$sql = "SELECT * FROM gencoursesupload WHERE Department = '$pickdept' ORDER BY C_codding";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			// output data of each row
		?>

			<table>
				<thead style="background-color:#000; color:#FFFFFF">
					<tr>
						<th style="color:#FFFFFF"></th>
						<th style="color:#FFFFFF">Course Code</th>
						<th style="color:#FFFFFF">Course Title</th>
						<th style="color:#FFFFFF">Unit</th>
						<th style="color:#FFFFFF">Semester</th>

					</tr>
				</thead>
				<tbody>


					<?php

					while ($row = $result->fetch_assoc()) {
						$id = $row["id"];
						$ccode = $row["C_codding"];
						$CTitle = $row["C_title"];
						$CUnit = $row["credit"];
						$SemTaken = $row["semester"];
						$Nature = "Core";

						echo "<tr>
							<td><input type='checkbox' name='chosenalldept[" . $id . "]' value='" . $id . "'/></td>
							
							<td>
							<label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
							<input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
							</td>
							<td>
							<label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
							<input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
							</td>
							<td>
							<label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
							<input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
							</td>
							<td>
							<label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
							<input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>
							</td>
							</td>
							<td hidden='hidden'>
							<label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
							<input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
							</td>
							
							</tr>\n";
					}
					?>
				</tbody>
			</table>

<?php
		}

		$conn->close();
	}
}

?>
<?PHP

require_once 'db_connect.php';

$header = '';
$result = '';


$eachheader[] = "";
//$eachheader[0] = "S/No";
$eachheader[0] = "Matric No";
$eachheader[1] = "Corse Code";
$eachheader[2] = "Course Title";
$eachheader[3] = "Unit";
$eachheader[4] = "Semester";
$eachheader[5] = "CA";
$eachheader[6] = "Exam";
$eachheader[7] = "Session";
//$eachheader[10] = "Depart";

$course = $_POST['course'];
$session = $_POST['getsession'];

$sql = "SELECT matno, ccode, ctitle, unit, Semester, CA, Exam, session_regist FROM e_exam_results WHERE ccode= '$course' AND session_regist= '$session' ORDER BY matno";
//$sql = "SELECT Regn1, CCode, CTitle, CUnit, SemTaken, CA, Exam, grade, SessionRegis FROM correg ORDER BY Regn1";
$exportData = $conn->query($sql);

$fields = mysqli_num_fields($exportData);

for ($i = 0; $i < $fields; $i++) {
    //$header .= mysqli_fetch_field_direct( $exportData , $i )->name . "\t";
    $header .= $eachheader[$i] . "\t";
}

while ($row = $exportData->fetch_assoc()) {
    $line = '';
    foreach ($row as $value) {
        if ((!isset($value)) || ($value == "")) {
            $value = "\t";
        } else {
            $value = str_replace('"', '""', $value);
            $value = '"' . $value . '"' . "\t";
        }
        $line .= $value;
    }
    $result .= trim($line) . "\n";
}
$result = str_replace("\r", "", $result);

if ($result == "") {
    $result = "\nNo Record(s) Found!\n";
}

header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=" . $course . ".xls");
header("Pragma: no-cache");
header("Expires: 0");
print "$header\n$result";

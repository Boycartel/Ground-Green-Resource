<?php
require_once 'db_connect.php';
if (isset($_POST["country"])) {

	// Capture selected country
	$pickdept = $_POST["country"];
	$_SESSION['deptcode_grad'] = $pickdept;
	//$level = $_SESSION['level'];
	//$levelcode = substr($level, 0, 1);
	//if ($pickdept <> "No"){

?>

	<?php

	//$dept = $_SESSION['deptcode'];
	$sql = "SELECT * FROM register WHERE DeptCode = '$pickdept' ORDER BY Regn";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
	?>
		<table class="table mb-none">
			<thead>
				<tr>
					<th>Matric No.</th>
					<th>Name</th>
					<th></th>
				</tr>
			</thead>
			<tbody>


				<?php
				while ($row = $result->fetch_assoc()) {
					$id = $row["sn"];

					echo "<tr><td>{$row['Regn']}</td><td>{$row['Name_full']}</td>
					<td>
					 <form action='grad_list_result.php' method='post'>
						  <input type='hidden' value=$id name='id'>
						  <input type='submit' class='btn btn-primary btn-xs' value='View'>
					 </form>
					
					</td></tr>\n";
				}
				?>
			</tbody>
		</table>

<?php

	} else {
	}
	$conn->close();
	//}else {

	//}
}

?>
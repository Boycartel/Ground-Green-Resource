<?php

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {

    session_destroy();
    header("Location: index_staff.php");
    exit;
} else {
    if ($_SESSION['logintype'] !== "staff") {
        session_destroy();
        header('Location: index_staff.php');
    } else {
        if ($_SESSION['countprog'] > 1) {
            if ($_SESSION["seldeptLogin"] == false) {
                session_destroy();
                header('Location: index_staff.php');
            }
        }
    }
}

$cat_Administrator = $_SESSION['Administrator'];
$cat_Sub_Admin = $_SESSION['Sub_Admin'];
$cat_Dean = $_SESSION['Dean'];
$cat_HOD = $_SESSION['HOD'];
$cat_Examiner = $_SESSION['Examiner'];
$cat_Ass_Examiner = $_SESSION['Ass_Examiner'];
$cat_PG_Coord = $_SESSION['PG_Coord'];
$cat_Seminer_Coord = $_SESSION['Seminer_Coord'];
$cat_SIWES_Coord = $_SESSION['SIWES_Coord'];
$cat_L100 = $_SESSION['L100'];
$cat_L200 = $_SESSION['L200'];
$cat_L300 = $_SESSION['L300'];
$cat_L400 = $_SESSION['L400'];
$cat_L500 = $_SESSION['L500'];
$cat_spill_over = $_SESSION['spill_over'];

$cat_SchExaminer = $_SESSION['SchExaminer'];
$cat_POs = $_SESSION['POs'];
$cat_APU = $_SESSION['APU'];
$cat_QAP = $_SESSION['QAP'];
$cat_AcadSec = $_SESSION['AcadSec'];
$cat_Acad_Ofice = $_SESSION['Acad_Ofice'];
$cat_CourseLec = $_SESSION['CourseLec'];
$cat_transcript = $_SESSION['transcript'];

/*
if ($_SESSION['userConnect'] === true) {
    $userID = $_SESSION['userID'];
    $sql2 = "SELECT sn, online_status FROM users WHERE sn= '$userID'";
    $result2 = $conn->query($sql2);
    if ($result2->num_rows > 1) {
        while ($row2 = $result2->fetch_assoc()) {
           if ($row2['online_status'] == "Online") {
            
                if ($_SESSION['logintype'] !== "staff") {
                    session_destroy();
                    header('Location: index_staff.php');
                }
                
            } else {
                session_destroy();
                header('Location: index_staff.php');
            } 
        }
    } else {

        session_destroy();
        header('Location: index_staff.php');
    }
    
    
} else {
    //exit;
    session_destroy();
    header('Location: index_staff.php');
}
*/
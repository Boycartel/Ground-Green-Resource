<?php
require_once 'db_connect.php';
if (isset($_POST["country"])) {

	// Capture selected country
	$pickdept = $_POST["country"];
	//$_SESSION['deptcode'] = $pickdept;
	//$level = $_SESSION['level'];
	//$levelcode = substr($level, 0, 1);
	//if ($pickdept <> "No"){
?>

	<?php

	//$dept = $_SESSION['deptcode'];
	$sql = "SELECT * FROM gencoursesupload WHERE Department = '$pickdept' ORDER BY C_codding";
	$result = $conn5->query($sql);

	if ($result->num_rows > 0) {
	?>
		<table class="table mb-none">
			<thead>
				<tr>
					<th></th>
					<th>Course Code</th>
					<th>Course Title</th>
					<th>Unit</th>
					<th>Semester</th>
					<th>Nature</th>

				</tr>
			</thead>
			<tbody>
				<?php
				// output data of each row
				while ($row = $result->fetch_assoc()) {
					$id = $row["id"];
					$ccode = $row["C_codding"];
					$CTitle = $row["C_title"];
					$CUnit = $row["credit"];
					$SemTaken = $row["semester"];

					echo "<tr>
					<td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
					
					
					<td>
					<label id='ccode' name='ccode[" . $id . "]'>$ccode</label>
					<input type='hidden' id='ccode' name='ccode[" . $id . "]' value='" . $ccode . "'/>
					</td>
					<td>
					<label id='CTitle' name='CTitle[" . $id . "]'>$CTitle</label>
					<input type='hidden' id='CTitle' name='CTitle[" . $id . "]' value='" . $CTitle . "'/>
					</td>
					<td>
					<label id='CUnit' name='CUnit[" . $id . "]'>$CUnit</label>
					<input type='hidden' id='CUnit' name='CUnit[" . $id . "]' value='" . $CUnit . "'/>
					</td>
			
				<td>
				
					<select class='form-control' id='SemTaken1' style='color:#000000' name='SemTaken[" . $id . "]'>
						<option value = '$SemTaken'>$SemTaken</option>
						<option value = '1ST'>1ST</option>
						<option value = '2ND'>2ND</option>
					</select>
					</td>
					<td>
					<select class='form-control' id='Nature1' style='color:#000000' name='Nature[" . $id . "]'>
						<option value = 'Core'>Core</option>
						<option value = 'Elective'>Elective</option>
					</select>
					</td>
					
					</tr>\n";
				}
				?>
			</tbody>
		</table>

<?php
	}
}

?>
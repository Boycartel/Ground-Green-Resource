<?php
        
    
    $dept = $_SESSION['deptcode'];
    $regid = $_SESSION["regid"];
    $stdid = $_SESSION["stdid"];
    $names=$_SESSION['names'];
    $email=$_SESSION['email'];
    $deptname=$_SESSION['deptname'];
    $corntsession=$_SESSION['corntsession'];
    $cursemester=$_SESSION['cursemester'];
    $getday=date('D');
    if($getday=="Mon"){
    	$getday="M";
    }elseif($getday=="Tue"){
    	$getday="T";
    }elseif($getday=="Wed"){
    	$getday="W";
    }elseif($getday=="Thu"){
    	$getday="Th";
    }elseif($getday=="Fri"){
    	$getday="F";
    }elseif($getday=="Sat"){
    	$getday="S";
   
	}
	
    $closemsg=0;
    $ccodearry[]="";
    $timearry[]="";
    $x=0;
    $sql2 = "SELECT * FROM courses_register WHERE Regn1 = '$regid' AND session = '$corntsession' AND SemTaken = '$cursemester'";
    $result2 = $conn->query($sql2);
    if ($result2->num_rows > 0) {
        while($row2 = $result2->fetch_assoc()) {
            $CCode = $row2['CCode'];
            $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode'";
		    $result = $conn->query($sql);
		    if ($result->num_rows > 0) {
		        while($row = $result->fetch_assoc()) {
		        	if($getday=="M" || $getday=="T" || $getday=="W" || $getday=="Th" || $getday=="F" || $getday=="S"){
		        		$thetimearry = $row[$getday];
			        	if(strlen($thetimearry) > 1){
			        		$timearry[$x]=$thetimearry;
			        		$ccodearry[$x]=$CCode;
			        		$x++;
			        	}
					}
		        	
				}
			}
		}
	}

$sql2 = "SELECT * FROM ".$dept."_comment WHERE matricno = '$regid'";
$result2 = $conn->query($sql2);
$totmsg = mysqli_num_rows($result2);

$sql = "SELECT * FROM ".$dept."_comment WHERE matricno = '$regid' AND msgopen = 'NO' ORDER BY id DESC";
$result = $conn->query($sql);
$closemsg = mysqli_num_rows($result);


?>
<header class="header">
    <div class="logo-container">
        <a href="../" class="logo">
            <img src="assets/images/futlogo.png" height="35" alt="FUTMinna" />
        </a>
        <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
        </div>
    </div>

    <!-- start: search & user box -->
    <div class="header-right">

        <span class="separator"></span>
        <ul class="notifications">

            <li>
                <a href="#" class="dropdown-toggle notification-icon" data-toggle="dropdown">
                    <i class="fa fa-envelope"></i>
                    <?php if($closemsg !== 0){ ?>
                        <span class="badge"><?php echo $closemsg ?></span>
                    <?php } ?>
                </a>

                <div class="dropdown-menu notification-menu">
                    <div class="notification-title">
                        <span class="pull-right label label-default"><?php echo $totmsg ?></span>
                        Messages
                    </div>

                    <div class="content">
                        <ul>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    $cat = $row['cat_coment'];
                                    $reccomment = $row['recieve_coment'];

                                    if($cat=="PG" || $cat=="PGLAdvice" || $cat=="PGExam" || $cat=="PGHOD"){
                                        $catfull="PG Coordiator";
                                    }else{
                                        $catfull=$cat;
                                    }
                                    //if($cat==""){
                                    ?>
                                    <li>
                                        <a href="stu_messages.php" class="clearfix">

                                            <?php
                                            if($cat=="PG" || $cat=="PGLAdvice" || $cat=="PGExam" || $cat=="PGHOD" || $cat=="Administrator"){

                                                ?>
                                                <figure class="image">
                                                    <?php echo "<img alt='No Image' src = 'https://staff.futminna.edu.ng/".strtoupper($_SESSION['deptcode'])."/images/".$row['msgid']."/MyPic1.jpg'  class='img-circle'>"; ?>

                                                </figure>

                                            <?php }else{
                                                $sql2 = "SELECT regid, stdid FROM e_data_profile WHERE regid = '$cat'";
                                                $result2 = $conn4->query($sql2);

                                                if ($result2->num_rows > 0) {
                                                    while($row2 = $result2->fetch_assoc()) {
                                                        if(strlen($row2["regid"]) > 4){
                                                            $getstdid = $row2['stdid'];
                                                        }

                                                    }
                                                }
                                                ?>
                                                <figure class="image">
                                                    <?php echo "<img alt='No Image' src = 'https://eportal.futminna.edu.ng/pg/uploads/".$getstdid."_passport.jpg'  width='50' height='50' alt=''>"; ?>

                                                </figure>

                                            <?php } ?>
                                            <span class="title"><?php echo $catfull ?></span>
                                            <span class="message truncate"><?php echo $reccomment ?></span>


                                        </a>
                                    </li>
                                    <?php

                                    //}
                                }
                            }
                            //
                            ?>

                        </ul>

                        <hr />

                        <div class="text-right">
                            <a href="stu_messages.php" class="view-more">View All</a>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <a href="#" class="dropdown-toggle notification-icon" data-toggle="dropdown">
                    <i class="fa fa-bell"></i>
                    <?php
                    $sql="select count('1') from gettimetable WHERE stuid = '$stdid'";
                    $result = $conn4->query($sql);
                    $nrow=mysqli_fetch_array($result);
                    ?>
                    <?php if($nrow[0] !== 0){ ?>
                        <span class="badge"><?php echo $nrow[0] ?></span>
                    <?php } ?>

                </a>

                <div class="dropdown-menu notification-menu">
                    <div class="notification-title">
                        <span class="pull-right label label-default"><?php echo $nrow[0] ?></span>
                        Today's' Lecture(s)
                    </div>

                    <div class="content">
                        <ul>
                            <?php

                            $sql = "SELECT * FROM gettimetable WHERE stuid = '$stdid' ORDER BY thetime";
                            $result = $conn4->query($sql);
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    $ccodearry=$row["ccode"];
                                    $timearry=$row["thetime"];
                                    ?>
                                    <li>
                                        <a href="#" class="clearfix">
                                            <div class="image">
                                                <i class="fa fa-thumbs-down bg-info"></i>
                                            </div>
                                            <span class="title"><?php echo $ccodearry ?></span>
                                            <span class="message"><?php echo $timearry ?></span>
                                        </a>
                                    </li>
                                    <?php
                                }
                            }
                            ?>

                        </ul>

                        <hr />

                        <div class="text-right">
                            <a href="stu_lecturetimetable.php" class="view-more">View All</a>
                        </div>
                    </div>
                </div>
            </li>
        </ul>

        <span class="separator"></span>


        <div id="userbox" class="userbox">
            <a href="#" data-toggle="dropdown">
                <figure class="profile-picture">
                    <?php

                    echo "<img src='https://eportal.futminna.edu.ng/pg/uploads/".$_SESSION['stdid']."_passport.jpg' alt='$names' class='img-circle' width='50' height='50' data-lock-picture='https://eportal.futminna.edu.ng/pg/uploads/".$_SESSION['stdid']."_passport.jpg' />";
                    ?>
                </figure>
                <div class="profile-info" data-lock-name="<?php echo $_SESSION['stdid'] ?>" data-lock-email="<?php echo $email ?>">
                    <span class="name"><?php echo $names ?></span>
                    <span class="role"><?php echo $_SESSION['stdid']." (".$regid.")" ?></span>
                </div>

                <i class="fa custom-caret"></i>
            </a>

            <div class="dropdown-menu">
                <ul class="list-unstyled">
                    <li class="divider"></li>
                    <li>
                        <a role="menuitem" tabindex="-1" href="profile_pg.php"><i class="fa fa-user"></i> My Profile</a>
                    </li>
                    <li>
                        <a role="menuitem" tabindex="-1" href="changepassw_pg.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                    </li>
                    <li>
                        <a role="menuitem" tabindex="-1" href="includes/logout_pg.php"><i class="fa fa-power-off"></i> Logout</a>
                    </li>
                    <!--<li>
                        <a role="menuitem" tabindex="-1" href="lock_screen_stu.php" data-lock-screen="true"><i class="fa fa-lock"></i> Lock Screen</a>
                    </li>-->



                </ul>
            </div>
        </div>
    </div>
    <!-- end: search & user box -->

</header>
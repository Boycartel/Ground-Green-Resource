 <?php include_once 'small_chat.php' ?>
 <!-- Mainly scripts -->
 <script src="js/jquery-3.1.1.min.js"></script>
 <script src="js/bootstrap.min.js"></script>
 <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
 <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>


 <!-- Custom and plugin javascript -->
 <script src="js/inspinia.js"></script>
 <script src="js/plugins/pace/pace.min.js"></script>
 <script src="js/plugins/dataTables/datatables.min.js"></script>
 <!-- jQuery UI -->
 <script src="js/plugins/jquery-ui/jquery-ui.min.js"></script>

 <script src="js/helpdesk_chat.js"></script>
 <script>
     $(document).ready(function() {
         setInterval(function() {
             $("#small_chat_body").load(window.location.href + " #small_chat_body");
         }, 3000);
     });
 </script>
 <script>
     $(document).ready(function() {
         setInterval(function() {
             $("#smallchat_lasttime").load(window.location.href + " #smallchat_lasttime");
         }, 3000);
     });
 </script>
 <!--
 <script type="text/javascript">
idleMax = 1 * 60; // Logout after 15 minutes of IDLE
idleTime = 0;
$(document).ready(function() {
    var idleInterval = setInterval("timerIncrement()", 100);
    $(this).mousemove(function(e) {
        idleTime = 0;
    });
    $(this).keypress(function(e) {
        idleTime = 0;
    });
})
<?php if ($_SESSION['logintype'] == "staff") { ?>

function timerIncrement() {
    idleTime = idleTime + 1;
    if (idleTime > idleMax) {
        window.location = "includes/logout.php";
    }
}
<?php } else { ?>

function timerIncrement() {
    idleTime = idleTime + 1;
    if (idleTime > idleMax) {
        window.location = "includes/logout_stu.php";
    }
}
<?php } ?>
 </script>
-->

 <script type="text/javascript">
     var timeoutTimer;
     var expireTime = 1000 * 60 * 15;

     function expireSession() {
         clearTimeout(timeoutTimer);
         timeoutTimer = setTimeout("IdleTimeout()", expireTime);
     }

     function IdleTimeout() {
         localStorage.setItem("logoutMessage", true);
         <?php if ($_SESSION['logintype'] == "staff") { ?>
             window.location.href = "includes/logout.php";
         <?php } else { ?>
             window.location.href = "includes/logout_stu.php";
         <?php } ?>
     }
     $(document).on('click mousemove scroll', function() {
         expireSession();
     });
     expireSession();
 </script>

 <script>
     $(document).ready(function() {
         $("#sub_post_small").click(function() {
             var mychat_small = $("#mychat_small").val();
             var user_id_small = $("#user_id_small").val();
             var user_full_name = $("#user_full_name").val();
             var user_helpdesk = $("#user_helpdesk").val();
             $.ajax({
                 url: 'ajax_save_rec/smallchat_insert.php',
                 method: 'POST',
                 data: {
                     mychat_small: mychat_small,
                     user_id_small: user_id_small,
                     user_full_name: user_full_name,
                     user_helpdesk: user_helpdesk
                 } //,
                 //success: function(data) {
                 //alert(data);
                 //}
             });
             document.getElementById("mychat_small").value = "";
             //document.getElementById("recip_id").value = "";
         });
     });
 </script>
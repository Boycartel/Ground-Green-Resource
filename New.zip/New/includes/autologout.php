<?php

/* $inactivity_time = 1 * 60; // 10 Minis Inactive
if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > $inactivity_time) {
    session_unset(); // unset $_SESSION variable 
    session_destroy(); // destroy session data in storage
    header("Location: login.php"); // redirect to login page
}
$_SESSION['last_activity'] = time(); // update last activity time stamp */
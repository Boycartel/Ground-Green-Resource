<?php
require_once 'db_connect2.php';
$staffid = $_SESSION['staffid'];
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
}
$sql = "UPDATE users SET online_status ='Offline' WHERE staffid = '$staffid'";
$result = $conn->query($sql);

$conn->close();

$_SESSION = array();

// get session parameters
$params = session_get_cookie_params();
// Delete the actual cookie.
setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
);



// Destroy session
session_destroy();
header('Location: ../index_staff.php');

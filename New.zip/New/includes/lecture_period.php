<?php
if($Hr==1){
	if($Tm=="7AM"){
		$NTm="8AM";
	}else if($Tm=="8AM"){
		$NTm="9AM";
	}else if($Tm=="9AM"){
		$NTm="10AM";
	}else if($Tm=="10AM"){
		$NTm="11AM";
	}else if($Tm=="11AM"){
		$NTm="12PM";
	}else if($Tm=="12PM"){
		$NTm="1PM";
	}else if($Tm=="1PM"){
		$NTm="2PM";
	}else if($Tm=="2PM"){
		$NTm="3PM";
	}else if($Tm=="3PM"){
		$NTm="4PM";
	}else if($Tm=="4PM"){
		$NTm="5PM";
	}else if($Tm=="5PM"){
		$NTm="6PM";
	}else if($Tm=="6PM"){
		$NTm="7PM";
	}else if($Tm=="7PM"){
		$NTm="8PM";
	}
}else if($Hr==2){
	if($Tm=="7AM"){
		$NTm="9AM";
	}else if($Tm=="8AM"){
		$NTm="10AM";
	}else if($Tm=="9AM"){
		$NTm="11AM";
	}else if($Tm=="10AM"){
		$NTm="12PM";
	}else if($Tm=="11AM"){
		$NTm="1PM";
	}else if($Tm=="12PM"){
		$NTm="2PM";
	}else if($Tm=="1PM"){
		$NTm="3PM";
	}else if($Tm=="2PM"){
		$NTm="4PM";
	}else if($Tm=="3PM"){
		$NTm="5PM";
	}else if($Tm=="4PM"){
		$NTm="6PM";
	}else if($Tm=="5PM"){
		$NTm="7PM";
	}else if($Tm=="6PM"){
		$NTm="8PM";
	}else if($Tm=="7PM"){
		$NTm="9PM";
	}
}else if($Hr==3){
	if($Tm=="7AM"){
		$NTm="10AM";
	}else if($Tm=="8AM"){
		$NTm="11AM";
	}else if($Tm=="9AM"){
		$NTm="12PM";
	}else if($Tm=="10AM"){
		$NTm="1PM";
	}else if($Tm=="11AM"){
		$NTm="2PM";
	}else if($Tm=="12PM"){
		$NTm="3PM";
	}else if($Tm=="1PM"){
		$NTm="4PM";
	}else if($Tm=="2PM"){
		$NTm="5PM";
	}else if($Tm=="3PM"){
		$NTm="6PM";
	}else if($Tm=="4PM"){
		$NTm="7PM";
	}else if($Tm=="5PM"){
		$NTm="8PM";
	}else if($Tm=="6PM"){
		$NTm="9PM";
	}else if($Tm=="7PM"){
		$NTm="10PM";
	}
}else if($Hr==4){
	if($Tm=="7AM"){
		$NTm="11AM";
	}else if($Tm=="8AM"){
		$NTm="12PM";
	}else if($Tm=="9AM"){
		$NTm="1PM";
	}else if($Tm=="10AM"){
		$NTm="2PM";
	}else if($Tm=="11AM"){
		$NTm="3PM";
	}else if($Tm=="12PM"){
		$NTm="4PM";
	}else if($Tm=="1PM"){
		$NTm="5PM";
	}else if($Tm=="2PM"){
		$NTm="6PM";
	}else if($Tm=="3PM"){
		$NTm="7PM";
	}else if($Tm=="4PM"){
		$NTm="8PM";
	}else if($Tm=="5PM"){
		$NTm="9PM";
	}else if($Tm=="6PM"){
		$NTm="10PM";
	}else if($Tm=="7PM"){
		$NTm="11PM";
	}

}
?>
<?php
require_once 'db_connect.php';
if (isset($_POST["country"])) {

	// Capture selected country
	$pickdept = $_POST["country"];
	//$_SESSION['deptcode'] = $pickdept;
	//$level = $_SESSION['level'];
	//$levelcode = substr($level, 0, 1);
	//if ($pickdept <> "No"){
?>

	<?php
	$numbschCurri = $_SESSION['numbschCurri'];
	$dept = $_SESSION['deptcode'];
	$sql = "SELECT * FROM gencoursesupload WHERE Department = '$pickdept' ORDER BY C_codding";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	?>
		<table class="table mb-none">
			<thead>
				<tr>
					<th></th>
					<th>Course Code</th>
					<th>Course Title</th>
					<th>Unit</th>
					<th>Semester</th>
					<th>Nature</th>
					<th>Level</th>
					<?php if ($_SESSION['deptoption'] == "YES") { ?>
						<th>Department Option</th>
					<?php } ?>
					<?php if ($numbschCurri > 1) { ?>
						<th>Curriculum</th>
					<?php } ?>
				</tr>
			</thead>
			<tbody>
				<?php
				// output data of each row
				while ($row = $result->fetch_assoc()) {
					$id = $row["id"];
					$ccode = $row["C_codding"];
					$CTitle = $row["C_title"];
					$CUnit = $row["credit"];
					$SemTaken = $row["semester"];
					$type1 = $row["type1"];

					$sql2 = "SELECT * FROM sch_curriculum WHERE curri_Code = '$type1'";
					$result2 = $conn->query($sql2);
					if ($result2->num_rows > 0) {
						while ($row2 = $result2->fetch_assoc()) {
							$type2 = $row2["curri_Title"];
						}
					}

					echo "<tr>
					<td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
					
					
					<td>
					<label id='ccode' name='ccode[" . $id . "]'>$ccode</label>
					<input type='hidden' id='ccode' name='ccode[" . $id . "]' value='" . $ccode . "'/>
					</td>
					<td>
					<label id='CTitle' name='CTitle[" . $id . "]'>$CTitle</label>
					<input type='hidden' id='CTitle' name='CTitle[" . $id . "]' value='" . $CTitle . "'/>
					</td>
					<td>
					<label id='CUnit' name='CUnit[" . $id . "]'>$CUnit</label>
					<input type='hidden' id='CUnit' name='CUnit[" . $id . "]' value='" . $CUnit . "'/>
					</td>
			
				<td>
				
					<select class='form-control' id='SemTaken1' style='color:#000000' name='SemTaken[" . $id . "]'>
						<option value = '$SemTaken'>$SemTaken</option>
						<option value = '1ST'>1ST</option>
						<option value = '2ND'>2ND</option>
					</select>
					</td>
					<td>
					<select class='form-control' id='Nature1' style='color:#000000' name='Nature[" . $id . "]'>
						<option value = 'Core'>Core</option>
						<option value = 'Elective'>Elective</option>
					</select>
					</td>
					<td>";
					if ($_SESSION['InstType'] == "University") {
						echo "<select class='form-control' id='level1' style='color:#000000' name='level[" . $id . "]'>
                                                            <option value = '100'>100</option>
                                                            <option value = '200'>200</option>
                                                            <option value = '300'>300</option>
                                                            <option value = '400'>400</option>
                                                            <option value = '500'>500</option>
                                                        </select>";
					} elseif ($_SESSION['InstType'] == "Polytechnic") {

						echo "<select class='form-control' id='level1' style='color:#000000' name='level[" . $id . "]'>
                                                            <option value = '100'>ND I</option>
                                                            <option value = '200'>ND II</option>
                                                            <option value = '300'>HND I</option>
                                                            <option value = '400'>HND II</option>
                                                            
                                                        </select>";
					} else {
					}

					echo "</td>";
					if ($_SESSION['deptoption'] == "YES") {
						echo "<td>";
						echo "<select class='form-control' id='deptoptn' style='color:#000000' name='deptoptn[" . $id . "]'>";
						$sql2 = "SELECT * FROM dept_option WHERE deptcode = '$dept'";
						$result2 = $conn->query($sql2);
						if ($result2->num_rows > 0) {
							while ($row2 = $result2->fetch_assoc()) {
								$Opt_Code = $row2["Opt_Code"];
								$opttitle = $row2["Opt_Title"];
								echo "<option value = '$Opt_Code'>$opttitle</option>";
							}
						}
						echo "</select>";
						echo "</td>";
					}
					if ($numbschCurri > 1) {
						echo "<td>
                                                        
						<label id='Ctype' name='Ctype[" . $id . "]'>$type2</label>
						<input type='hidden' id='Ctype' name='Ctype[" . $id . "]' value='" . $type1 . "'/>
						
						</td>";
					}
					echo "</tr>\n";
				}
				?>
			</tbody>
		</table>

<?php
	}
}

?>
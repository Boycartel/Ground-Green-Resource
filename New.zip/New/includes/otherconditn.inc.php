<?php


if ($Administrator == "YES" || $Sub_Admin == "YES" || $HOD == "YES" || $Dean == "YES") {
	$_SESSION['course_alocation'] = true;
	$_SESSION['course_alocation_pg'] = true;
} else {
	$_SESSION['course_alocation'] = false;
	$_SESSION['course_alocation_pg'] = false;
}
if ($Administrator == "YES" || $Sub_Admin == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES") {
	$_SESSION['course_setup'] = true;
} else {
	$_SESSION['course_setup'] = false;
}

if ($Administrator == "YES"  || $Sub_Admin == "YES" || $HOD == "YES" || $L100 == "YES" || $L200 == "YES" || $L300 == "YES" || $L400 == "YES" || $L500 == "YES" || $spill_over == "YES") {
	$_SESSION['course_validation'] = true;
} else {
	$_SESSION['course_validation'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $Dean == "YES" || $HOD == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES" || $L100 == "YES" || $L200 == "YES" || $L300 == "YES" || $L400 == "YES" || $L500 == "YES" || $spill_over == "YES" || $SchExaminer == "YES" || $POs == "YES" || $APU == "YES" || $QAP == "YES" || $AcadSec == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['sta_stu_course_reg'] = true;
	$_SESSION['reg_stu_per_courses'] = true;
	$_SESSION['staff_results'] = true;
} else {
	$_SESSION['sta_stu_course_reg'] = false;
	$_SESSION['reg_stu_per_courses'] = false;
	$_SESSION['staff_results'] = false;
}

if ($PG_Coord == "PG" || $Administrator == "YES" || $Sub_Admin == "YES" || $Dean == "YES" || $HOD == "YES" || $POs == "YES" || $APU == "YES" || $QAP == "YES" || $AcadSec == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['pg_stu_course_reg'] = true;
	$_SESSION['pg_staff_results'] = true;
} else {
	$_SESSION['pg_stu_course_reg'] = false;
	$_SESSION['pg_staff_results'] = false;
}

if ($CourseLec == "YES"  || $Administrator == "YES" || $Sub_Admin == "YES" || $Dean == "YES" || $HOD == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES" || $L100 == "YES" || $L200 == "YES" || $L300 == "YES" || $L400 == "YES" || $L500 == "YES" || $spill_over == "YES" || $SchExaminer == "YES" || $POs == "YES" || $APU == "YES" || $QAP == "YES" || $AcadSec == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['stu_reg_courses'] = true;
} else {
	$_SESSION['stu_reg_courses'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $Dean == "YES" || $HOD == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES" || $SchExaminer == "YES" || $POs == "YES" || $APU == "YES" || $QAP == "YES" || $AcadSec == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['grad_list_result'] = true;
	$_SESSION['secrutiny_format'] = true;
	$_SESSION['senate_format'] = true;
	$_SESSION['board_format'] = true;
	$_SESSION['stu_perform_graph'] = true;
	$_SESSION['submited_results'] = true;
	$_SESSION['ind_stu_biodata'] = true;
} else {
	$_SESSION['grad_list_result'] = false;
	$_SESSION['secrutiny_format'] = false;
	$_SESSION['senate_format'] = false;
	$_SESSION['board_format'] = false;
	$_SESSION['stu_perform_graph'] = false;
	$_SESSION['submited_results'] = false;
	$_SESSION['ind_stu_biodata'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $Dean == "YES" || $HOD == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['download_stu_biodata'] = true;
} else {
	$_SESSION['download_stu_biodata'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $Dean == "YES" || $HOD == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES" || $AcadSec == "YES" || $Acad_Ofice == "YES" || $L100 == "YES" || $L200 == "YES" || $L300 == "YES" || $L400 == "YES" || $L500 == "YES" || $spill_over == "YES") {
	$_SESSION['download_stu_reg_courses'] = true;
} else {
	$_SESSION['download_stu_reg_courses'] = false;
}



if ($Administrator == "YES" || $Sub_Admin == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES") {
	$_SESSION['upload_result(in_session)'] = true;
	$_SESSION['upload_result(graduated)'] = true;
} else {
	$_SESSION['upload_result(in_session)'] = false;
	$_SESSION['upload_result(graduated)'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $PG_Coord == "YES") {
	$_SESSION['upload_result(pg)'] = true;
	$_SESSION['pg_course_setup'] = true;
	$_SESSION['pg_reg_students'] = true;
	$_SESSION['pg_project_alocation'] = true;
} else {
	$_SESSION['upload_result(pg)'] = false;
	$_SESSION['pg_course_setup'] = false;
	$_SESSION['pg_reg_students'] = false;
	$_SESSION['pg_project_alocation'] = false;
}


if ($Administrator == "YES" || $HOD == "YES") {
	$_SESSION['create_users'] = true;
} else {
	$_SESSION['create_users'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $HOD == "YES") {
	$_SESSION['manage_users'] = true;
} else {
	$_SESSION['manage_users'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $HOD == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES" || $AcadSec == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['stu_reg_courses_all'] = true;
} else {
	$_SESSION['stu_reg_courses_all'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES") {
	$_SESSION['pass_reset_admin'] = true;
} else {
	$_SESSION['pass_reset_admin'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $QAP == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES") {
	$_SESSION['qap_request'] = true;
} else {
	$_SESSION['qap_request'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $APU == "YES") {
	$_SESSION['apu_request'] = true;
} else {
	$_SESSION['apu_request'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $AcadSec == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['acad_office_request'] = true;
} else {
	$_SESSION['acad_office_request'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['staf_condone_defer'] = true;
	$_SESSION['staf_condone_defer_view'] = true;
} else {
	$_SESSION['staf_condone_defer'] = false;
	$_SESSION['staf_condone_defer_view'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $Dean == "YES" || $HOD == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES" || $AcadSec == "YES" || $Acad_Ofice == "YES") {
	$_SESSION['staf_condone_defer_view'] = true;
} else {
	$_SESSION['staf_condone_defer_view'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $AcadSec == "YES") {
	$_SESSION['staf_condone_defer_edit'] = true;
} else {
	$_SESSION['staf_condone_defer_edit'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $transcript == "YES") {
	$_SESSION['transcript_email'] = true;
} else {
	$_SESSION['transcript_email'] = false;
}

if ($Acad_Ofice == "YES" || $AcadSec == "YES") {
	$_SESSION['not_for_acad'] = true;
}
if ($Administrator == "YES" || $Sub_Admin == "YES" || $Acad_Ofice == "YES" || $AcadSec == "YES") {
	$_SESSION['stu_biodata_grad'] = true;
} else {
	$_SESSION['stu_biodata_grad'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $HOD == "YES" || $Examiner == "YES" || $Ass_Examiner == "YES" || $APU == "YES") {
	$_SESSION['course_all'] = true;
} else {
	$_SESSION['course_all'] = false;
}

if ($Administrator == "YES" || $Sub_Admin == "YES" || $AcadSec == "YES" || $QAP == "YES" || $APU == "YES" || $Acad_Ofice == "YES" || $Dean == "YES" || $HOD == "YES") {
	$_SESSION['notice_board'] = true;
} else {
	$_SESSION['notice_board'] = false;
}

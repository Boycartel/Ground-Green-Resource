<?php
echo "<table style='font-size:13px; width: 100%'>";
echo "<thead style='text-align:center;'>";
echo "<tr>";
echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

echo "</tr>";
echo "</thead>";
echo "<tbody>";


$gtotgp = 0;
$stcp = 0;
//unset($LevelArray);
//$LevelArray[]=0;
$countOneLev = $countTwoLev = $countThreLev = $countFivLev = $countFourLev = $getlevel = 0;

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$sql = "SELECT * FROM correg WHERE Regn1 = '$matno' AND SessionRegis = '$session1' ORDER BY SemTaken, CCode";
$result = $conn_stu->query($sql);
$totunit = $totgp = $cgpa = $gtotgp = $gtotunit = 0;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        $ccode = $row['CCode'];
        $ctitle = $row['CTitle'];
        $cunit = $row['CUnit'];
        if ((int)substr($ccode, 3, 1) == 5) {
            $countFivLev++;
        } elseif ((int)substr($ccode, 3, 1) == 4) {
            $countFourLev++;
        } elseif ((int)substr($ccode, 3, 1) == 3) {
            $countThreLev++;
        } elseif ((int)substr($ccode, 3, 1) == 2) {
            $countTwoLev++;
        } elseif ((int)substr($ccode, 3, 1) == 1) {
            $countOneLev++;
        }
        if ($row['CA'] + $row['Exam'] >= 70) {
            $gpoint = $cunit * 5;
            $grade = "A";
            $stcp = $stcp + $cunit;
        } elseif ($row['CA'] + $row['Exam'] >= 60) {
            $gpoint = $cunit * 4;
            $grade = "B";
            $stcp = $stcp + $cunit;
        } elseif ($row['CA'] + $row['Exam'] >= 50) {
            $gpoint = $cunit * 3;
            $grade = "C";
            $stcp = $stcp + $cunit;
        } elseif ($row['CA'] + $row['Exam'] >= 45) {
            $gpoint = $cunit * 2;
            $grade = "D";
            $stcp = $stcp + $cunit;
        } elseif ($row['CA'] + $row['Exam'] >= 40) {
            $gpoint = $cunit * 1;
            $grade = "E";
            $stcp = $stcp + $cunit;
        } elseif ($row['CA'] + $row['Exam'] < 40) {
            $gpoint = 0;
            $grade = "F";
        }
        $totunit = $totunit + $cunit;
        $totgp = $totgp + $gpoint;

        if ($ccode == "Abscond" || $ccode == "Condone" || $ccode == "Cancel" || $ccode == "Expulsion" || $ccode == "Deferment" || $ccode == "Abscond") {
            echo "<tr><td style='border-right-style:solid; border-right-width:thin; text-align:center'></td><td style='border-right-style:solid; border-right-width:thin; ; padding-left:0.5em'>
						
						<center><img src='images/$ccode.jpg'  width='150' height='100' alt=''></center>
						</td><td style='border-right-style:solid; border-right-width:thin; text-align:center'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center'></td>\n";
        } else {
            echo "<tr><td style='border-right-style:solid; border-right-width:thin; font-size: 9px'>$ccode</td><td style='border-right-style:solid; border-right-width:thin; font-size: 9px'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center; font-size: 9px'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;; font-size: 9px'>$grade</td><td style='border-right-style:solid; border-right-width:thin; text-align:center; font-size: 9px'>$gpoint</td>\n";
        }
    }
}
//$LevelArray=array($countOneLev, $countTwoLev, $countThreLev, $countFivLev, $countFourLev);

//$cgpa = $totgp/$totunit;
//$conn->close();
if ($totunit != 0) {
    echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center; font-size: 10px'>$totunit</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center; font-size: 10px'>$totgp</th>\n";
}

echo "</tbody>";
echo "</table>";

?>
<center>
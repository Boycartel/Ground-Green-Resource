<?php
require_once 'db_connect2.php';
$tot1stoutunit = $tot2ndoutunit = 0;

//$regid = $_SESSION["regid"];

$curtsession = $_SESSION['corntsession'];
$prevsession = $_SESSION['prevsession'];
$resultsession = $_SESSION['resultsession'];
$yearsession = substr($curtsession, 0, 4);

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
$result = $conn2->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $dept = strtolower($row["dept_code"]);
        $deptname = $row["department"];
        $yearadmtd = substr($row["entry_session"], 0, 4);
        $modeofentry = $row["modeofentry"];
        if ($modeofentry == "ND") {
            $prog = "National Diploma";
        } elseif ($modeofentry == "HND") {
            $prog = "Higher National Diploma";
        }
        $entry_level = $row["entry_level"];
        $entry_session = $row["entry_session"];
    }
}

//$yearadmtd = substr($entry_session, 0, 4);

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

//$sql2 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND semester ='2ND' AND session1 ='$resultsession'";
$sql2 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND session1 ='$resultsession'";
$result2 = $conn_stu->query($sql2);
if ($result2->num_rows > 0) {
    while ($row2 = $result2->fetch_assoc()) {

        if ($yearadmtd == $yearsession) {
            if ($entry_level == 300) {
                $level = "300";
            } elseif ($entry_level == 200) {
                $level = "200";
            } else {
                $level = "100";
            }
        } else {
            $level = $row2["Level1"] + 100;
        }
    }
} else {
    if ($_SESSION['InstType'] == "Polytechnic") {
        if ($yearadmtd == $yearsession) {
            if ($modeofentry == "ND") {
                $level = "100";
            } elseif ($modeofentry == "HND") {
                $level = "300";
            }
        } else {
            if ($yearadmtd < 2022) {
                $level = "600";
            } else {
                if ($modeofentry == "ND") {
                    $level = "200";
                } elseif ($modeofentry == "HND") {
                    $level = "400";
                }
            }
        }
    } else {
        if ($yearadmtd == $yearsession) {
            if ($entry_level == 300) {
                $level = "300";
            } elseif ($entry_level == 200) {
                $level = "200";
            } else {
                $level = "100";
            }
        } else {
            $level = "100";
        }
    }
}
$conn2->close();
$conn_stu->close();

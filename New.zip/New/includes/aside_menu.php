<div class="sidebar-collapse">
    <ul class="nav metismenu" id="side-menu">
        <li class="nav-header">
            <div class="dropdown profile-element"> <span>
                    <?php
                    $regid = $_SESSION['regid'];
                    $dept = $_SESSION['deptcode'];

                    $matpassport = str_replace("/", "_", $regid);
                    echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='50' height='50'>";

                    ?>

                </span>
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $_SESSION['names'] ?></strong>
                        </span> <span class="text-muted text-xs block"><?php echo $_SESSION['regid'] ?> <b class="caret"></b></span> </span> </a>
                <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="faq_stu.php">FAQ</a></li>
                    <li><a href="changepassw_stu.php">Change Password</a></li>
                    <li class="divider"></li>
                    <li><a href="includes/logout_stu.php">Logout</a></li>
                </ul>
            </div>

        </li>

        <li class="active">
            <a href="home_stu.php">
                <i class="fa fa-home" aria-hidden="true"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="stu_results.php">
                <i class="fa fa-file"></i>
                <span>Result</span>
            </a>
        </li>
        <li>
            <a>
                <i class="fa fa-list" aria-hidden="true"></i>
                <span>Course Reg.</span><span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level">
                <li><a class="" href="stu_course_reg.php">New Course Registration</a></li>
                <li><a class="" href="stu_registered_course.php">Registered Courses</a></li>
            </ul>
        </li>
        <li>
            <a href="exam_card_pdf.php" target="_blank">
                <i class="fa fa-file"></i>
                <span>Exam Card</span>
            </a>
        </li>
        <li>
            <a href="stu_courseware.php">
                <i class="fa fa-briefcase"></i>
                <span>Courseware</span>
            </a>
        </li>
        <li>
            <a href="mydept.php">
                <i class="fa fa-institution (alias)"></i>
                <span>My Department</span>
            </a>
        </li>
        <li>
            <a href="stu_library.php">
                <i class="fa fa-book"></i>
                <span>Dept. e-Resources</span>
            </a>
        </li>
        <li>
            <a href="stu_lecturetimetable.php">
                <i class="fa fa-calendar"></i>
                <span>Lecture Timetable</span>
            </a>
        </li>
        <!--
        <li>
            <a class="" href="classroom_stu_start.php">
                <i class="fa fa-comment-o"></i>
                <span>Classroom (<i style="color: red;">*New</i>)</span>
            </a>
        </li>
        -->
        <li>
            <a href="stu_messages.php">
                <i class="fa fa-envelope"></i>
                <span>Messages</span>
            </a>
        </li>
        <li>
            <a href="miss_session.php">
                <i class="fa fa-tasks"></i>
                <span>Missing Session(s)</span>
            </a>
        </li>
        <li>
            <a href="feedback.php">
                <i class="fa fa-envelope"></i>
                <span>Portal Feedback</span>
            </a>
        </li>
        <li>
            <a href="<?php echo $_SESSION['eportal_link'] ?>/" target="_blank">
                <i class="fa fa-file"></i>
                <span>ePortal</span>
            </a>
        </li>




        <li class="special_link">
            <a href="#"><i></i> <span class="nav-label"></span>ICT Unit</a>
        </li>
    </ul>

</div>

      
            <?php
            
            
            $regid = $_SESSION["regid"];
            // sql to delete a record
            //$sql = "DELETE FROM coursesregis WHERE Regn1 ='$regid'";
            //$result = $conn->query($sql);
                            
            $ccode1arr[]=$CTitle1arr[]=$CUnit1arr[]=$SemTaken1arr[]=$Nature1arr[]="";
            $ccode2arr[]=$CTitle2arr[]=$CUnit2arr[]=$SemTaken2arr[]=$Nature2arr[]="";
            $sn1=$sn2=0;
            
            if (!empty($_POST["chosen1c"])) {
                foreach($_POST["chosen1c"] as $key=>$value){
                         
                     //echo $_POST["chosen"][$key];
                    
                    $ccode1c = $_POST["ccodec1"][$key];
                     $CTitle1c = $_POST["CTitlec1"][$key];
                    $CUnit1c = $_POST["CUnitc1"][$key];
                    $SemTaken1c = $_POST["SemTakenc1"][$key];
                    $Nature1c = $_POST["Naturec1"][$key];
                    
                    //echo "<tr><td>$ccode1c</td><td>$CTitle1c</td><td>$CUnit1c</td><td>$SemTaken1c</td><td>$Nature1c</td></tr>\n";
                    // sql to insert record
                    //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode1c', '$CUnit1c', '$CTitle1c', '$SemTaken1c', '$Nature1c')";
                    //$result = $conn->query($sql);
                }
            }
            
                //$array = $_POST["chosen"];
                if (!empty($_POST["chosen"])) {
                    foreach($_POST["chosen"] as $key=>$value){
                            
                     $ccode = $_POST["ccode1"][$key];
                     $CTitle = $_POST["CTitle1"][$key];
                     $CUnit = $_POST["CUnit1"][$key];
                     $SemTaken = $_POST["SemTaken1"][$key];
                     $Nature = $_POST["Nature1"][$key];
                    
                     //echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td></tr>\n";
                     // sql to insert record
                    //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature')";
                    //$result = $conn->query($sql);
                        
                    }
                } else {
                    //echo 'No item selected';
                    // exit from loop
                }

                
                             
                    ?>
                 
            <?php
            if (!empty($_POST["chosen2c"])) {
                foreach($_POST["chosen2c"] as $key=>$value){
                         
                //echo $_POST["chosen"][$key];
            
                $ccode2c = $_POST["ccodec2"][$key];
                $CTitle2c = $_POST["CTitlec2"][$key];
                $CUnit2c = $_POST["CUnitc2"][$key];
                $SemTaken2c = $_POST["SemTakenc2"][$key];
                $Nature2c = $_POST["Naturec2"][$key];
                
                //echo "<tr><td>$ccode2c</td><td>$CTitle2c</td><td>$CUnit2c</td><td>$SemTaken2c</td><td>$Nature2c</td></tr>\n";
                // sql to insert record
                //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode2c', '$CUnit2c', '$CTitle2c', '$SemTaken2c', '$Nature2c')";
                //$result = $conn->query($sql);
                        }
            }
            
            if (!empty($_POST["chosen2"])) {
                foreach($_POST["chosen2"] as $key=>$value){
                         
                     //echo $_POST["chosen"][$key];
                         
                     $ccode2 = $_POST["ccode2"][$key];
                    $CTitle2 = $_POST["CTitle2"][$key];
                    $CUnit2 = $_POST["CUnit2"][$key];
                    $SemTaken2 = $_POST["SemTaken2"][$key];
                    $Nature2 = $_POST["Nature2"][$key];
                    
                    //echo "<tr><td>$ccode2</td><td>$CTitle2</td><td>$CUnit2</td><td>$SemTaken2</td><td>$Nature2</td></tr>\n";
                    // sql to insert record
                    //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode2', '$CUnit2', '$CTitle2', '$SemTaken2', '$Nature2')";
                    //$result = $conn->query($sql);	
                    }
            }
                
                ?>
              
<div class="sidebar-collapse">
    <ul class="nav metismenu" id="side-menu">
        <li class="nav-header">
            <div class="dropdown profile-element">
                <span>

                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $staff_pic_folder = $_SESSION['staff_pic_folder'];
                    $filename = $staff_pic_folder . $_SESSION['staffid'] . '.jpg';
                    $filename2 = $staff_pic_folder . $_SESSION['staffid'] . '.jpeg';

                    if (file_exists($filename)) {
                        echo "<img alt=''  class='img-circle' src='$staff_pic_folder" . $_SESSION['staffid'] . ".jpg' width='50' height='50'>";
                    } elseif (file_exists($filename2)) {
                        echo "<img alt=''  class='img-circle' src='$staff_pic_folder" . $_SESSION['staffid'] . ".jpeg' width='50' height='50'>";
                    } else {
                        echo "<img alt=''  class='img-circle' src='img/favicon.ico' width='50' height='50'>";
                    }



                    $rolls = "";
                    if ($cat_Administrator == "YES") {
                        $rolls = $rolls . "Administrator, ";
                    }
                    if ($cat_Sub_Admin == "YES") {
                        $rolls = $rolls . "Administrator, ";
                    }
                    if ($cat_Dean == "YES") {
                        $rolls = $rolls . "Dean, ";
                    }
                    if ($cat_HOD == "YES") {
                        $rolls = $rolls . "HOD, ";
                    }
                    if ($cat_Examiner == "YES") {
                        $rolls = $rolls . "Exam Officer, ";
                    }
                    if ($cat_Ass_Examiner == "YES") {
                        $rolls = $rolls . "Ass. Exam Officer, ";
                    }
                    if ($cat_PG_Coord == "YES") {
                        $rolls = $rolls . "PG Coordinator, ";
                    }
                    if ($cat_Seminer_Coord == "YES") {
                        $rolls = $rolls . "Seminer Coordinator, ";
                    }
                    if ($cat_SIWES_Coord == "YES") {
                        $rolls = $rolls . "SIWES Coordinator, ";
                    }

                    if ($_SESSION['InstType'] == "University") {
                        if ($cat_L100 == "YES") {
                            $rolls = $rolls . "100 Level Adviser, ";
                        }
                        if ($cat_L200 == "YES") {
                            $rolls = $rolls . "200 Level Adviser, ";
                        }
                        if ($cat_L300 == "YES") {
                            $rolls = $rolls . "300 Level Adviser, ";
                        }
                        if ($cat_L400 == "YES") {
                            $rolls = $rolls . "400 Level Adviser, ";
                        }
                        if ($cat_L500 == "YES") {
                            $rolls = $rolls . "500 Level Adviser, ";
                        }
                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                        if ($cat_L100 == "YES") {
                            $rolls = $rolls . "ND I Adviser, ";
                        }
                        if ($cat_L200 == "YES") {
                            $rolls = $rolls . "ND II Adviser, ";
                        }
                        if ($cat_L300 == "YES") {
                            $rolls = $rolls . "HND I Adviser, ";
                        }
                        if ($cat_L400 == "YES") {
                            $rolls = $rolls . "HND II Adviser, ";
                        }
                    }
                    if ($cat_spill_over == "YES") {
                        $rolls = $rolls . "Spill Over Adviser, ";
                    }
                    if ($cat_SchExaminer == "YES") {
                        $rolls = $rolls . "School/Faculty Exam Officer, ";
                    }
                    if ($cat_POs == "YES") {
                        $rolls = $rolls . "Principal Officer, ";
                    }
                    if ($cat_APU == "YES") {
                        $rolls = $rolls . "Academic Planning Unit, ";
                    }
                    if ($cat_QAP == "YES") {
                        $rolls = $rolls . "Quality Assurance, ";
                    }
                    if ($cat_AcadSec == "YES") {
                        $rolls = $rolls . "Academic Secretary, ";
                    }
                    if ($cat_Acad_Ofice == "YES") {
                        $rolls = $rolls . "Academic Office, ";
                    }
                    if ($cat_CourseLec == "YES") {
                        $rolls = $rolls . "Course Lecturer, ";
                    }
                    if ($cat_transcript == "YES") {
                        $rolls = $rolls . "Transcript Officer, ";
                    }

                    $OnGroup = false;
                    $dept = strtoupper($_SESSION['deptcode']);

                    $sql = "SELECT * FROM dept_stu_group WHERE deptcode = '$dept'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 1) {
                        $OnGroup = true;
                    }

                    $conn->close();
                    ?>
                </span>
                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                    <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $_SESSION['names'] ?></strong>
                        </span> <span class="text-muted text-xs block"><?php echo $_SESSION['cat'] . "(" . strtoupper($_SESSION['deptcode']) . " - " . $rolls . ")" ?>
                            <b class="caret"></b></span>
                </a>
                <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    <!-- <li><a href="staff_profile.php">Profile</a></li> -->
                    <li><a href="user_guide.php">User's Guide</a></li>
                    <li><a href="changepassw_staff.php">Change Password</a></li>
                    <li class="divider"></li>
                    <li><a href="includes/logout.php">Logout</a></li>
                </ul>
            </div>
            <div class="logo-element">
                IN+
            </div>
        </li>

        <li class="active">
            <a href="home_staff.php">
                <i class="fa fa-home" aria-hidden="true"></i>
                <span>Dashboard</span>
            </a>
        </li>


        <li>
            <a>
                <i class="fa fa-list" aria-hidden="true"></i>
                <span>Course Management</span><span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level">
                <?php if ($_SESSION['course_setup'] == true) { ?>
                    <li><a class="" href="course_setup.php">Course Setup</a></li>
                <?php } ?>
                <?php
                if ($_SESSION['course_validation'] == true) {
                    if ($_SESSION['HOD'] == "YES" && ($_SESSION['L100'] == "YES" || $_SESSION['L200'] == "YES" || $_SESSION['L300'] == "YES" || $_SESSION['L400'] == "YES" || $_SESSION['L500'] == "YES" || $_SESSION['spill_over'] == "YES")) {
                ?>
                        <li><a class="" href="course_validation_select.php">Course Validation</a></li>
                    <?php

                    } else {
                    ?>
                        <li><a class="" href="course_validation.php">Course Validation</a></li>
                <?php

                    }
                }
                ?>
                <?php if ($_SESSION['pg_course_setup'] == true) { ?>
                    <!-- <li><a class="" href="course_validation_pg.php">Course Validation(PG)</a></li> -->
                <?php } ?>

                <?php if ($_SESSION['course_all'] == true) { ?>
                    <li><a class="" href="course_all.php">Course Details</a></li>
                <?php } ?>

                <?php if ($_SESSION['pg_course_setup'] == true) { ?>
                    <!-- <li><a class="" href="course_setup_pg.php">Course Setup(PG)</a></li> -->
                <?php } ?>
                <?php if ($_SESSION['not_for_acad'] == false) { ?>
                    <li><a class="" href="course_alocated.php">Course Allocated</a></li>
                <?php } ?>
                <?php if ($_SESSION['course_alocation'] == true) { ?>
                    <li><a class="" href="course_alocation.php">Course Allocation</a></li>
                <?php
                }
                if ($_SESSION['course_alocation_pg'] == true) {
                ?>
                    <!-- <li><a class="" href="course_alocation_pg.php">Course Allocation (PG)</a></li> -->
                <?php
                }
                if ($_SESSION['sta_stu_course_reg'] == true) {
                ?>
                    <li><a class="" href="sta_stu_course_reg.php">Registered Courses</a></li>
                <?php
                }
                ?>
                <?php
                if ($_SESSION['reg_stu_per_courses'] == true) {
                ?>
                    <li><a class="" href="reg_stu_per_courses.php">Reg. Stu. per Courses</a></li>

                <?php } ?>
                <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
                    <li><a class="" href="course_setup_summary.php">Course Setup Summary</a></li>
                    <li><a class="" href="course_alocation_summary.php">Course Allocation Summary</a></li>
                <?php } ?>

            </ul>
        </li>

        <li>
            <a>
                <i class="fa fa-upload" aria-hidden="true"></i>
                <span>Upload</span><span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level">
                <?php if ($_SESSION['not_for_acad'] == false) { ?>
                    <?php if ($_SESSION['instcode'] == "FPB") { ?>
                        <li><a class="" href="upload_ind_resultFPB.php">My Course(s) Results</a></li>
                    <?php } else { ?>
                        <li><a class="" href="upload_ind_result.php">My Course(s) Results</a></li>
                    <?php } ?>


                    <?php if ($_SESSION['upload_result(e-exam)'] == true) { ?>
                        <!-- <li><a class="" href="upload_result(e-exam).php">Students Result(e-Exam)</a></li>
                            <li><a class="" href="drop_e_exam_results.php">Drop Result(e-Exam)</a></li> -->
                    <?php } ?>
                    <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
                        <li><a class="" href="upload_courses.php">Upload Courses</a></li>
                        <li><a class="" href="acadcalendar.php">Academic Calendar</a></li>
                    <?php } ?>
                    <?php if ($_SESSION['course_setup'] == true && $_SESSION['instcode'] == "FPB") { ?>
                        <li><a class="" href="upload_results_22_23.php">Upload Results 2022/2023</a></li>
                        <?php if ($OnGroup == true) { ?>
                            <li><a class="" href="upload_stu_grouping.php">Upload Students Grouping</a></li>
                        <?php } ?>
                    <?php } ?>
                <?php } ?>

            </ul>
        </li>


        <li>
            <a>
                <i class="fa fa-file" aria-hidden="true"></i>
                <span>Results</span><span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level">
                <?php if ($_SESSION['course_setup'] == true) { ?>
                    <li><a class="" href="missing_result_update.php">Results Update</a></li>
                <?php } ?>
                <?php if ($_SESSION['upload_result(in_session)'] == true) { ?>
                    <li><a class="" href="generate_results.php">Generate Result</a></li>
                <?php } ?>
                <?php
                if ($_SESSION['staff_results'] == true) {
                ?>
                    <li>
                        <a>
                            <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                            <span>Students' Result</span><span class="fa arrow"></span>
                        </a>
                        <ul class="nav nav-third-level">
                            <li><a class="" href="staff_results.php">Format I</a></li>
                            <?php if ($_SESSION['course_setup'] == true) { ?>
                                <li><a class="" href="stu_sem_results.php">Format II</a></li>
                            <?php } ?>
                        </ul>
                    </li>
                <?php } ?>

                <?php if ($_SESSION['board_format'] == true) { ?>
                    <li>
                        <a>
                            <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                            <span>Students' Spreadsheet</span><span class="fa arrow"></span>
                        </a>
                        <ul class="nav nav-third-level">
                            <li><a class="" href="spreadsheet.php">Returning Students</a></li>
                            <li><a class="" href="spreadsheet_sel_appr.php">Graduating Students</a></li>
                        </ul>

                    </li>
                    <li><a class="" href="spreadsheet_1st_grad_sel.php">Graduation(1ST Semester) </a></li>

                    <?php if ($_SESSION['instcode'] == "IBBU") {
                    ?>
                        <li><a class="" href="boardformat.php" target="_blank">Faculty Board Format</a></li>
                    <?php } elseif ($_SESSION['instcode'] == "NAUB") {
                    ?>
                        <li><a class="" href="boardformat_naub.php" target="_blank">Faculty Board Format(NAUB)</a></li>
                    <?php } elseif ($_SESSION['instcode'] == "FPB") {
                    ?>
                        <li><a class="" href="boardformat_poly.php" target="_blank">Examination Results Broadsheet
                                Report</a></li>
                        <li><a class="" href="boardformat_sumary_poly.php" target="_blank">Examination Results Summary
                                Report</a></li>
                    <?php }
                    ?>

                <?php } ?>



                <?php if ($_SESSION['secrutiny_format'] == true) { ?>
                    <?php if ($_SESSION['InstType'] == "University") { ?>
                        <li><a class="" href="secrutiny_format.php" target="_blank">Senate Business Committee Format</a>
                        </li>
                    <?php } ?>
                <?php
                }
                if ($_SESSION['senate_format'] == true) {
                ?>
                    <!-- <li><a class="" href="senate_format.php" target="_blank">Senate Format</a></li> -->
                <?php
                }
                if ($_SESSION['stu_perform_graph'] == true) {
                ?>
                    <li><a class="" href="stu_perform_graph.php">Analysis By Graph</a></li>
                <?php }
                if ($_SESSION['submited_results'] == true) {
                ?>
                    <li><a class="" href="submited_results.php">Submited Results</a></li>
                <?php } ?>

                <?php if ($_SESSION['course_setup'] == true) { ?>
                    <li><a class="" href="special_list.php">Special List</a></li>
                <?php } ?>
                <?php
                if ($_SESSION['pg_staff_results'] == true) {
                ?>
                    <!-- <li><a class="" href="pg_staff_results.php">Postgraduate Results</a></li> -->
                <?php
                }
                if ($_SESSION['grad_list_result'] == true) {
                ?>
                    <li><a class="" href="grad_list_result.php">Graduated List/Results</a></li>
                <?php
                }
                if ($_SESSION['e_exam_results'] == true) {
                ?>
                    <!-- <li><a class="" href="e_exam_results.php">e-Exam Results</a></li> -->
                <?php
                }
                ?>

                <?php if ($_SESSION['transcript_email'] == true) { ?>

                    <li>
                        <a>
                            Students' Transcript<span class="fa arrow"></span>
                        </a>
                        <ul class="nav nav-third-level">

                            <?php if ($_SESSION['instcode'] == "IBBU") {
                            ?>
                                <li><a class="" href="transcript_comp.php">Transcript Computation</a></li>
                            <?php } elseif ($_SESSION['instcode'] == "NAUB") {
                            ?>
                                <li><a class="" href="transcript_comp_naub.php">Transcript Computation</a></li>
                            <?php } elseif ($_SESSION['instcode'] == "FPB") {
                            ?>
                                <li><a class="" href="transcript_comp_poly.php">Transcript Computation</a></li>
                            <?php }
                            ?>


                            <li><a class="" href="transcript_email.php">email Students' Copy</a></li>
                            <li><a class="" href="transcript_original.php">email Original Copy</a></li>
                        </ul>
                    </li>
                <?php } ?>
            </ul>
        </li>

        <li>
            <a>
                <i class="fa fa-cogs" aria-hidden="true"></i>
                <span>Settings</span><span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level">
                <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
                    <li><a class="" href="create_dept_curriculum.php">Department Curriculum</a></li>
                    <li><a class="" href="create_dept_option.php">Departmental Option</a></li>
                    <li><a class="" href="create_stu_group.php">Create Students Group</a></li>
                <?php } ?>
                <?php if ($_SESSION['course_setup'] == true) { ?>
                    <?php if ($_SESSION['deptoption'] == "YES") { ?>
                        <li><a class="" href="setup_courses_deptoption.php">Setup Courses</a></li>
                    <?php } else { ?>
                        <li><a class="" href="setup_courses.php" target="_blank">Setup Courses</a></li>
                    <?php } ?>
                    <li><a class="" href="course_grouping.php">Course Grouping</a></li>
                    <?php if ($_SESSION['deptoption'] == "YES") { ?>
                        <li><a class="" href="dept_option.php" target="_blank">Set Students' Dept. Option</a></li>
                    <?php } ?>
                    <?php if ($_SESSION['curricul'] == "YES") { ?>
                        <li><a class="" href="stu_curriculum.php" target="_blank">Set Students' Curriculum</a></li>
                    <?php } ?>
                    <li><a class="" href="change_stu_status.php" target="_blank">Change Students' Status</a></li>
                    <li><a class="" href="minimum_Cr_Require.php" target="_blank">Minimum Credit Requirement</a>
                    </li>
                <?php } ?>
                <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
                    <li><a class="" href="set_session.php">Set Session and Others</a></li>
                    <li><a class="" href="close_open_course_reg.php">Open/Close Course Reg</a></li>
                    <li><a class="" href="show_results.php">Enable Results for Students</a></li>
                    <li><a class="" href="modulesInSess/database_data_update.php">Database/Data Update</a></li>
                <?php } ?>

            </ul>
        </li>
        <li>
            <a>
                <i class="fa fa-user" aria-hidden="true"></i>
                <span>Results and Profile Approval</span><span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level">
                <?php if ($_SESSION['course_alocation'] == true) { ?>
                    <li><a class="" href="raw_results_approval.php">Uploaded Results</a></li>
                    <li><a class="" href="semester_res_approval.php">Semester Results Formats</a></li>
                    <li><a class="" href="profile_approval.php">Staff Profile</a></li>

                <?php } ?>


            </ul>
        </li>

        <li>
            <a>
                <i class="fa fa-download" aria-hidden="true"></i>
                <span>Download</span><span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level">
                <li><a class="" href="download_stu_result.php">Course(s) Results</a></li>
                <?php
                if ($_SESSION['staf_condone_defer'] == true) {
                ?>
                    <li><a class="" href="download_senate_summary.php">Senate Summary</a></li>
                <?php } ?>
                <?php
                //if ($_SESSION['download_stu_reg_courses(e-center)'] == true) {
                ?>
                <!-- <li><a class="" href="download_stu_reg_courses(e-center).php">Reg. Courses(e-Center)</a></li> -->
                <?php
                //}
                if ($_SESSION['download_stu_reg_courses'] == true) {
                ?>
                    <li><a class="" href="download_course_reg.php">Registered Courses</a></li>
                <?php
                }
                if ($_SESSION['download_stu_reg_courses'] == true) {
                ?>
                    <li><a class="" href="download_stu_reg_courses.php">Registered Courses Per Course</a></li>
                <?php
                }
                if ($_SESSION['stu_reg_courses_all'] == true) {
                ?>
                    <li><a class="" href="stu_reg_courses_all.php">All Reg. Courses for the Session</a></li>
                <?php
                }
                //if ($_SESSION['download_stu_result(e-exam)'] == true) {
                ?>
                <!-- <li><a class="" href="download_stu_result(e-exam).php">Stu. Result(e-Exam)</a></li> -->
                <?php
                //}
                if ($_SESSION['download_stu_biodata'] == true) {
                ?>
                    <li><a class="" href="download_stu_biodata.php">Students' Biodata</a></li>
                <?php } ?>
                <?php
                if ($_SESSION['pg_staff_results'] == true) {
                ?>
                    <!-- <li><a class="" href="download_stu_biodata_pg.php">Students' Biodata(PG)</a></li> -->
                <?php } ?>
                <?php
                if ($_SESSION['transcript_email'] == true) {
                ?>
                    <!-- <li><a class="" href="download_transcript.php">Transcript e-Copy</a></li> -->
                <?php } ?>
                <?php
                if ($_SESSION['pass_reset_admin'] == true) {
                ?>
                    <li><a class="" href="download_adm_list.php">Admission List</a></li>
                <?php } ?>
                <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
                    <li><a class="" href="download_all_courses.php">Dowload Courses</a></li>
                <?php } ?>
            </ul>
        </li>

        <?php if ($_SESSION['pass_reset_admin'] == true || $_SESSION['AcadSec'] == "YES" || $_SESSION['Acad_Ofice'] == "YES") { ?>
            <?php if ($_SESSION['instcode'] == "FPB") { ?>
                <li>
                    <a class="" href="drop_2022_23_results.php">
                        <i class="fa fa-edit (alias)"></i>
                        <span>Drop 2022/2023 Results</span>
                    </a>
                </li>
            <?php } ?>
            <li>
                <a class="" href="exam_card_staff.php">
                    <i class="fa fa-edit (alias)"></i>
                    <span>Exam Card</span>
                </a>
            </li>
        <?php } ?>

        <?php if ($_SESSION['staf_condone_defer_edit'] == true) { ?>
            <li>
                <a>
                    <i class="fa fa-mortar-board (alias)" aria-hidden="true"></i>
                    <span>Graduation List</span><span class="fa arrow"></span>
                </a>
                <ul class="nav nav-second-level">
                    <li><a href="graduation_courses.php">Best Graduating Stu in a Course</a></li>
                    <li><a href="graduation_genlist.php">Convocation List</a></li>
                    <li><a href="graduation_summary.php">Summary</a></li>
                    <li><a href="graduation_summarysex.php">Summary by Sex</a></li>
                    <li><a href="graduation_NYSC_mob.php">NYSC List</a></li>
                </ul>
            </li>

        <?php } ?>

        <?php if ($_SESSION['staf_condone_defer_view'] == true) { ?>
            <li>
                <a>
                    <i class="fa fa-chain-broken" aria-hidden="true"></i>
                    <span>Missing Session</span><span class="fa arrow"></span>
                </a>
                <ul class="nav nav-second-level">
                    <?php
                    if ($_SESSION['staf_condone_defer'] == true) {
                    ?>
                        <li><a class="" href="staf_condone_defer.php">Add</a></li>
                    <?php } ?>
                    <li><a class="" href="staf_condone_defer_view.php">View</a></li>

                    <?php
                    if ($_SESSION['staf_condone_defer_edit'] == true) {
                    ?>
                        <li><a class="" href="staf_condone_defer_edit.php">Edit</a></li>

                    <?php } ?>
                </ul>
            </li>

        <?php } ?>


        <?php if ($_SESSION['staf_condone_defer_edit'] == true) { ?>
            <li>
                <a class="" href="CGPA.php">
                    <i class="fa fa-life-saver (alias)"></i>
                    <span>Sessional CGPA</span>
                </a>
            </li>

        <?php } ?>
        <?php if ($_SESSION['not_for_acad'] == false) { ?>

            <li>
                <a class="" href="staf_courseware.php">
                    <i class="fa fa-briefcase"></i>
                    <span>Courseware</span>
                </a>
            </li>
        <?php } ?>
        <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
            <li>
                <a class="" href="id_card.php">
                    <i class="fa fa-edit (alias)"></i>
                    <span>ID Card Report</span>
                </a>
            </li>


            <li>
                <a class="" href="change_dept.php">
                    <i class="fa fa-exchange"></i>
                    <span>Change Department</span>
                </a>

            </li>
            <!-- <li>
                    <a class="" href="upload_engr_rept_100L.php">
                        <i class="fa fa-truck"></i>
                        <span>Upload Repeat 100 Level Engr</span>
                    </a>
                </li> -->


        <?php } ?>

        <?php if ($_SESSION['not_for_acad'] == false) { ?>
            <li>
                <a class="" href="staf_lecturetimetableinpt.php">
                    <i class="fa fa-calendar"></i>
                    <span>Lecture Timetable</span>
                </a>
            </li>

            <li>
                <a class="" href="staf_messages.php">
                    <i class="fa fa-envelope"></i>
                    <span>Messages</span>
                </a>
            </li>
        <?php } ?>
        <?php if ($_SESSION['notice_board'] == true) { ?>
            <li>
                <a class="" href="notice_board.php">
                    <i class="fa fa-desktop"></i>
                    <span>Notice Board</span>
                </a>
            </li>
        <?php } ?>
        <li>
            <a class="" href="feedback.php">
                <i class="fa fa-envelope"></i>
                <span>Portal Feedback</span>
            </a>
        </li>
        <li>
            <a class="" href="user_guide.php">
                <i class="fa fa-star"></i>
                <span>User's Guide</span>
            </a>
        </li>
        <li>
            <a class="" href="faq.php">
                <i class="fa fa-star"></i>
                <span>FAQ</span>
            </a>
        </li>

        <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
            <li>
                <a class="" href="updateStuLevel_Course.php">
                    <i class="fa fa-desktop"></i>
                    <span>Update Students Level & Outs Courses</span>
                </a>
            </li>
        <?php } ?>


        <?php if ($_SESSION['manage_users'] == true) { ?>
            <li>
                <a>
                    <i class="fa fa-exchange" aria-hidden="true"></i>
                    <span>Manage Users</span><span class="fa arrow"></span>
                </a>
                <ul class="nav nav-second-level">
                    <?php if ($_SESSION['create_users'] == true) { ?>
                        <li><a class="" href="create_user.php">Users(Create & Role)</a></li>
                    <?php } ?>
                    <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
                        <li><a class="" href="user_management.php">Users Status</a></li>
                        <li><a class="" href="reset_stu_password.php">Reset Students Password </a></li>
                    <?php } ?>
                </ul>
            </li>

            <li>
                <a class="" href="database_backup.php">
                    <i class="fa fa-truck"></i>
                    <span>Backup Data</span>
                </a>
            </li>


        <?php } ?>

        <?php if ($cat_Administrator == "YES") { ?>
            <li>
                <a class="" href="logsview_feedback.php">
                    <i class="fa fa-home"></i>
                    <span>Portal Feedback Report</span>
                </a>
            </li>
        <?php } ?>

        <?php if ($_SESSION['staf_condone_defer'] == true || $_SESSION['staf_condone_defer_edit'] == true) { ?>
            <!-- <li>
                <a class="" href="admission_de_screening.php">
                    <i class="fa fa-life-saver (alias)"></i>
                    <span>DE Admission Screening (<i style="color: red;">*New</i>)</span>
                </a>
            </li> -->
        <?php } ?>
        <!-- <li>
            <a class="" href="aor_form.php">
                <i class="fa fa-file-text"></i>
                <span>Assignment of Responsibility (AOR)<br> Form (<i style="color: red;">*New</i>)</span>
            </a>
        </li>

        <li>
            <a class="" href="classroom_start.php">
                <i class="fa fa-comment-o"></i>
                <span>Classroom (<i style="color: red;">*New</i>)</span>
            </a>
        </li> -->
        <?php if ($_SESSION['qap_request'] == true) { ?>
            <li>
                <a>
                    <i class="fa fa-th-list" aria-hidden="true"></i>
                    <span>QAP (<i style="color: red;">*New</i>)</span><span class="fa arrow"></span>
                </a>
                <ul class="nav nav-second-level">
                    <li><a class="" href="qap_results.php">Results(Courses) Analysis</a></li>
                    <li><a class="" href="qap_request.php">Stu List with CGPA</a></li>
                    <li><a class="" href="aor_report_qap.php">AOR Report</a></li>
                </ul>
            </li>
        <?php } ?>
        <?php if ($_SESSION['Administrator'] == "YES") { ?>
            <?php if ($_SESSION['apu_request'] == true || $_SESSION['acad_office_request'] == true) { ?>
                <li>
                    <a>
                        <i class="fa fa-mortar-board (alias)" aria-hidden="true"></i>
                        <span>APU (<i style="color: red;">*New</i>)</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a>
                                <i class="fa fa-th-list" aria-hidden="true"></i>
                                <span>Statistical Digest</span><span class="fa arrow"></span>
                            </a>
                            <ul class="nav nav-second-level">
                                <li><a class="" href="sta_dig_enrolment.php">Enrolment</a></li>
                                <li><a class="" href="sta_dig_grad_output.php">Graduate Output</a></li>
                                <li><a class="" href="sta_dig_diversity.php">Diversity</a></li>
                            </ul>
                        </li>
                        <li><a class="" href="stu_profile.php">Students Profile</a></li>
                        <li><a class="" href="download_course_reg.php">Registered Courses</a></li>
                        <li><a class="" href="download_stu_reg_courses.php">Registered Courses Per Course</a></li>
                        <li><a class="" href="stu_reg_courses_all.php">All Reg. Courses for the Session</a></li>
                    </ul>
                </li>


                <li>
                    <a>
                        <i class="fa fa-mortar-board (alias)" aria-hidden="true"></i>
                        <span>APU (<i style="color: red;">*New</i>)</span><span class="fa arrow"></span>
                    </a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a>
                                <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                                <span>Staff Record</span><span class="fa arrow"></span>
                            </a>
                            <ul class="nav nav-third-level">
                                <li><a class="" href="dap_staff_dept.php">By Department</a></li>
                                <li><a class="" href="dap_staff_state.php">By State of Origin</a></li>
                                <li><a class="" href="dap_staff_dept_state.php">By Department and State</a></li>
                            </ul>
                        </li>
                        <li>
                            <a>
                                <i class="fa  fa-angle-double-right" aria-hidden="true"></i>
                                <span>UG Students Record</span><span class="fa arrow"></span>
                            </a>
                            <ul class="nav nav-third-level">
                                <li><a class="" href="dap_stu_dept.php">By Department</a></li>
                                <li><a class="" href="dap_stu_state.php">By State of Origin</a></li>
                                <li><a class="" href="dap_stu_dept_state.php">By Department and State</a></li>
                            </ul>
                        </li>
                        <li>
                            <a>
                                <i class="fa  fa-angle-double-right" aria-hidden="true"></i>
                                <span>PG Students Record</span><span class="fa arrow"></span>
                            </a>
                            <ul class="nav nav-third-level">
                                <li><a class="" href="dap_pg_dept.php">By Department</a></li>
                                <li><a class="" href="dap_pg_state.php">By State of Origin</a></li>
                                <li><a class="" href="dap_pg_dept_state.php">By Department and State</a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="" href="dap_dept_accreditation.php">
                                <i class="fa fa-edit (alias)"></i>
                                <span>Department Accreditation</span>
                            </a>
                        </li>
                    </ul>
                </li>

            <?php } ?>
        <?php } ?>

        <?php if ($_SESSION['pg_project_alocation'] == true) { ?>
            <!-- <li>
            <a>
                <i class="fa fa-support (alias)" aria-hidden="true"></i>
                <span>PG Pregress Report (<i style="color: red;">*New</i>)</span><span class="fa arrow"></span>
            </a>
            <ul class="nav nav-second-level">
                <li><a class="" href="pg_request_defence.php">Defence Request</a></li>
                <li><a class="" href="pg_project_alocation.php">Project Allocation</a></li>
            </ul>
        </li> -->
        <?php } ?>


        <?php if ($_SESSION['not_for_acad'] == false) { ?>
            <!-- <li>
            <a class="" href="includes/edit_create_site.php">
                <i class="fa fa-life-saver (alias)"></i>
                <span>My Website (<i style="color: red;">*New</i>)</span>
            </a>
        </li> -->

        <?php } ?>


        <li class="special_link">
            <a href=""><i></i> <span class="nav-label"></span></a>
        </li>
    </ul>

</div>
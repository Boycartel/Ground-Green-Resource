<?php
//require_once 'db_connect2.php';
$tot1stoutunit = $tot2ndoutunit = 0;

$regid = $_SESSION["regid"];
$dept = $_SESSION['deptcode'];
$curtsession = $_SESSION['corntsession'];
$prevsession = $_SESSION['prevsession'];
$resultsession = $_SESSION['resultsession'];
$resultsemester = $_SESSION['resultsemester'];

$entry_session = $_SESSION['entry_session'];
$yearadmtd = substr($entry_session, 0, 4);
$yearsession = substr($curtsession, 0, 4);
$siwesstatus = $_SESSION['siwesstatus'];
$modeofentry = $_SESSION['modeofentry'];
$entry_level = $_SESSION['entry_level'];
$stulevel = $_SESSION['stulevel'];
$GetLevel[] = 0;
$GetSession[] = "";
$tot1outunit = $tot2outunit = 0;

/* $FinalYear = substr($resultsession, 0, 4);
$StartYear = substr($entry_session, 0, 4);
$countses = 0;
unset($stuSessionArray);
$stuSessionArray[] = "";
for ($x = $StartYear; $x <= $FinalYear; $x++) {
    $countses++;
    $stuSessionArray[$countses] = $x . "/" . ($x + 1);
} */

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

//$sql2 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND semester ='2ND' AND session1 ='$resultsession'";
$sql2 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND session1 ='$resultsession' AND semester = '$resultsemester'";
$result2 = $conn_stu->query($sql2);
if ($result2->num_rows > 0) {
    while ($row2 = $result2->fetch_assoc()) {

        if ($yearadmtd == $yearsession) {
            if ($entry_level == 300) {
                $level = "300";
            } elseif ($entry_level == 200) {
                $level = "200";
            } else {
                $level = "100";
            }
        } else {
            $level = $row2["Level1"] + 100;
        }
    }
} else {
    if ($_SESSION['InstType'] == "Polytechnic") {
        if ($yearadmtd == $yearsession) {
            if ($modeofentry == "ND") {
                $level = "100";
            } elseif ($modeofentry == "HND") {
                $level = "300";
            }
        } else {
            if ($yearadmtd < 2022) {
                $level = "600";
            } else {
                if ($modeofentry == "ND") {
                    $level = "200";
                } elseif ($modeofentry == "HND") {
                    $level = "400";
                }
            }
        }
    } else {
        if ($yearadmtd == $yearsession) {
            if ($entry_level == 300) {
                $level = "300";
            } elseif ($entry_level == 200) {
                $level = "200";
            } else {
                $level = "100";
            }
        } else {
            $level = $stulevel;
        }
    }
}

$conn_stu->close();

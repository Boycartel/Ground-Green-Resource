<?php
//University BIU

$_SESSION['sch_color'] = "brown";
$_SESSION['palheadcolor'] = "primary";
$_SESSION['instname'] = "NIGERIAN ARMY UNIVERSITY, BIU";
$_SESSION['instcode'] = "NAUB";
$_SESSION['sch_faculty'] = "FACULTY";
$_SESSION['InstType'] = "University";
$_SESSION['mission'] = "To develop highly skilled military and civilian manpower with distinctive competence capable of providing technological solutions to the problems of the NA, the military and the nation.";
$_SESSION['vision'] = "To become a solution centre in technology, research and development for the promotion of self-reliance, creativity and innovation in addressing the challenges of the NA, the military as well as the nation.";
$_SESSION['InstAdrress'] = "No 1 Gombe Road, Biu, Borno State";
$_SESSION['deptdb'] = "naub_dept_";
$_SESSION['useDeptUnit'] = true;
$_SESSION['staff_pic_folder'] = "Content/Passport/";
$_SESSION['stu_pic_folder'] = "https://eportal.fedpolybida.edu.ng/uploads_acad/pics";
$_SESSION['stu_cred_folder'] = "https://eportal.fedpolybida.edu.ng/uploads_acad/credentials";
$_SESSION['eportal_link'] = "https://eportal.fedpolybida.edu.ng";
$_SESSION['minCredit'] = 15;
$_SESSION['MaxCredit'] = 22;

$_SESSION['minCreditNew'] = 15;
$_SESSION['MaxCreditNew'] = 24;


//University PRIME
/*
$_SESSION['sch_color'] = "brown";
$_SESSION['palheadcolor'] = "primary";
$_SESSION['instname'] = "PRIME UNIVERSITY ABUJA";
$_SESSION['instcode'] = "PRIME";
$_SESSION['sch_faculty'] = "FACULTY";
$_SESSION['InstType'] = "University";
$_SESSION['mission'] = "To deploy technology to nurture creativity and innovation, for preparing professionals, statesmen and business leaders.";
$_SESSION['vision'] = "To be a pacesetter in innovative Education in Nigeria.";
$_SESSION['InstAdrress'] = "Old Site of Capital Science Academy, Dafara Village, Kuje Area Council, FCT Abuja.";
$_SESSION['deptdb'] = "naub_dept_";
//$_SESSION['deptdb'] = "dept_";
$_SESSION['staff_pic_folder'] = "Content/Passport/";
$_SESSION['stu_pic_folder'] = "https://eportal.primeuniversity.edu.ng/uploads_acad/pics";
$_SESSION['eportal_link'] = "https://primeuniversity.edu.ng";
$_SESSION['minCredit'] = 16;
$_SESSION['MaxCredit'] = 24;
*/

//University SUMMIT OFFA
/* $_SESSION['sch_color'] = "green";
		$_SESSION['palheadcolor'] = "primary";
		$_SESSION['instname'] = "SUMMIT UNIVERSITY, OFFA";
		$_SESSION['instcode'] = "SUNO";
		$_SESSION['sch_faculty'] = "FACULTY";
		$_SESSION['InstType'] = "University";
		$_SESSION['mission'] = "To develop highly skilled military and civilian manpower with distinctive competence capable of providing technological solutions to the problems of the NA, the military and the nation.";
		$_SESSION['vision'] = "To become a solution centre in technology, research and development for the promotion of self-reliance, creativity and innovation in addressing the challenges of the NA, the military as well as the nation.";
		$_SESSION['InstAdrress'] = "Dr. Tunji Olagunju street (Irra road), P.M.B 4412 Offa, Kwara State";
		$_SESSION['deptdb'] = "naub_dept_";
		$_SESSION['staff_pic_folder'] = "https://staff.futminna.edu.ng"; */

//Polytechnic Bida
/* $_SESSION['sch_color'] = "blue";
$_SESSION['palheadcolor'] = "primary";
$_SESSION['instname'] = "THE FEDERAL POLYTECHNIC, BIDA";
$_SESSION['instcode'] = "FPB";
$_SESSION['sch_faculty'] = "SCHOOL";
$_SESSION['InstType'] = "Polytechnic";
$_SESSION['mission'] = "To build an enabling campus environment and train students in technology and management through the earned ‘Bida Standard’ for sustainable development.";
$_SESSION['vision'] = "A leading Polytechnic with enviable and excellent academic standard, training students to be technologically skilled, morally sound and entrepreneurial.";
$_SESSION['InstAdrress'] = "No 1 Poly Road, Bida, Niger State";
$_SESSION['deptdb'] = "poly_dept_";
$_SESSION['staff_pic_folder'] = "Content/Passport/";  
$_SESSION['stu_pic_folder'] = "https://eportal.fedpolybida.edu.ng/uploads_acad/pics"; 
$_SESSION['eportal_link'] = "https://eportal.fedpolybida.edu.ng";
$_SESSION['minCredit'] = 20;
$_SESSION['MaxCredit'] = 28;

*/

// Also Change on
// - ajax_save_rec/stafchatzone_load
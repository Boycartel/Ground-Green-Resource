<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';


include_once 'includes/get_stu_level.php';

?>
<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


</head>
<?php
$unuse = "YES";

$regid = $_SESSION["regid"];
$dept = $_SESSION['deptcode'];
$curtsession = $_SESSION['corntsession'];
$resultsession = $_SESSION['resultsession'];



$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$sql = "SELECT matric_no, next_email, next_name FROM std_data_view WHERE matric_no = '$regid' AND next_email <> ''";
$result = $conn2->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $paemail = $row["next_email"];
        $paname = $row["next_name"];
    }
}
$conn2->close();

$sumunits = $sumgp = $point = $cgpa = 0;
$grade = "";

//error_reporting(E_ERROR);

date_default_timezone_set("Africa/Lagos");
$prestimefull =  date("h:i:sa");

$prestime = date("ha");
$preday = date("l");



include_once 'includes/check_stu_status.php';

?>

<?php
$leveladvcom = false;
$hodcom = false;
$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$sql = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$curtsession'";
$result = $conn_stu->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $LevelAdvice = $row["LevelAdvice"];
        $HOD = $row["HOD"];

        $LAComment = $row["LAComment"];
        $HODComment = $row["HODComment"];
    }
}

$conn_stu->close();

if ($LevelAdvice !== "Validate" && strlen($LAComment) > 2) {
    $leveladvcom = true;
}
if ($HOD !== "Validate" && strlen($HODComment) > 2) {
    $hodcom = true;
}
?>

<body class="fixed-navigation">
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg sidebar-content">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="sidebar-panel">
                <div>
                    <h3>Notice Board</h3>
                    <div class="feed-element">
                        <?php
                        $dept2 = strtolower($dept);
                        $levelNB = "L" . $level;
                        $levelNB2 = "L" . $level . "_stu";

                        $ArryCCode[1] = $ArryCCode[2] = $ArryCCode[3] = $ArryCCode[4] = $ArryCCode[5] = $ArryCCode[6] = $ArryCCode[7] = $ArryCCode[8] = $ArryCCode[9] = $ArryCCode[10] = $ArryCCode[11] = $ArryCCode[12] = $ArryCCode[13] = $ArryCCode[14] = $ArryCCode[15] = $ArryCCode[16] = $ArryCCode[17] = $ArryCCode[18] = $ArryCCode[19] = $ArryCCode[20] = "";
                        $countArCode = 0;
                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                        if ($conn2->connect_error) {
                            die("Connection failed: " . $conn2->connect_error);
                        }

                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                        if ($conn_stu->connect_error) {
                            die("Connection failed: " . $conn_stu->connect_error);
                        }
                        $dbsession = str_replace("/", "_", $curtsession);
                        $sql = "SELECT CCode FROM courses_register_" . $dbsession . " WHERE Regn1 = '$regid' ORDER BY CCode";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $countArCode++;
                                $CCode = $row["CCode"];
                                $ArryCCode[$countArCode] = $row["CCode"];
                            }
                        }
                        ?>

                        <?php if ($leveladvcom == true || $hodcom == true) { ?>
                        <?php
                            $sql = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$curtsession'";
                            $result = $conn_stu->query($sql);
                            if ($result->num_rows > 0) {
                            ?>

                        <table style="width: 100%;">
                            <tbody>
                                <?php
                                        while ($row = $result->fetch_assoc()) {


                                        ?>
                                <?php if ($leveladvcom == true) { ?>
                                <tr>
                                    <td>
                                        <a href="#" class="pull-left">
                                            <i class="fa fa-long-arrow-right"></i>
                                        </a><b>From Level Adviser</b>
                                        <div class="media-body" style="padding-left: 1em;">
                                            <div style="text-align: justify;">
                                                <?php echo $LAComment ?>

                                            </div>
                                            <br>
                                            <div style="text-align: right;">

                                            </div>

                                        </div>
                                        <p class='alert alert-danger'></p>

                                    </td>
                                </tr>
                                <?php } ?>
                                <?php if ($hodcom == true) { ?>
                                <tr>
                                    <td>
                                        <a href="#" class="pull-left">
                                            <i class="fa fa-long-arrow-right"></i>
                                        </a><b>From HOD</b>
                                        <div class="media-body" style="padding-left: 1em;">
                                            <div style="text-align: justify;">
                                                <?php echo $HODComment ?>

                                            </div>
                                            <br>
                                            <div style="text-align: right;">

                                            </div>

                                        </div>
                                        <p class='alert alert-danger'></p>

                                    </td>
                                </tr>
                                <?php } ?>
                                <?php

                                        }
                                        ?>
                            </tbody>
                        </table>
                        <?php
                            }
                            ?>

                        <?php } ?>

                        <?php
                        $sql = "SELECT * FROM staff_comment WHERE (Dept = '$dept2' OR Dept = 'none') AND (matricno = '$regid' OR matricno = 'Dean' OR matricno = 'HOD' OR matricno = 'Examiner' OR matricno = 'All' OR matricno = 'All_stu' OR matricno = '$levelNB' OR matricno = '$levelNB2' OR matricno = '$ArryCCode[1]' OR matricno = '$ArryCCode[2]' OR matricno = '$ArryCCode[3]' OR matricno = '$ArryCCode[4]' OR matricno = '$ArryCCode[5]' OR matricno = '$ArryCCode[6]' OR matricno = '$ArryCCode[7]' OR matricno = '$ArryCCode[8]' OR matricno = '$ArryCCode[9]' OR matricno = '$ArryCCode[10]' OR matricno = '$ArryCCode[11]' OR matricno = '$ArryCCode[12]' OR matricno = '$ArryCCode[13]' OR matricno = '$ArryCCode[14]' OR matricno = '$ArryCCode[15]' OR matricno = '$ArryCCode[16]' OR matricno = '$ArryCCode[17]' OR matricno = '$ArryCCode[18]' OR matricno = '$ArryCCode[19]' OR matricno = '$ArryCCode[20]') ORDER BY id DESC";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                        ?>

                        <table style="width: 100%;">
                            <tbody>
                                <?php
                                    while ($row = $result->fetch_assoc()) {
                                        $isStu = false;
                                        $date = date_create($row["date_time"]);
                                        if (is_null($row["sent_coment"])) {
                                        } else {
                                            $matricno = $row["matricno"];
                                            $sql3 = "SELECT matric_no FROM std_data_view WHERE matric_no = '$matricno'";
                                            $result3 = $conn2->query($sql3);
                                            if ($result3->num_rows > 0) {
                                                $isStu = true;
                                            }

                                            if ($row["cat"] == "L100") {
                                                $headerstr1 = "Course Lecturer";
                                            } elseif ($row["cat"] == "Administrator" || $row["cat"] == "Sub_Admin") {
                                                $headerstr1 = "Admin";
                                            } else {
                                                $headerstr1 = $row["cat"];
                                            }

                                            if ($isStu == true) {
                                                $headerstr = " to you";
                                            } elseif ($row["matricno"] == "All") {
                                                $headerstr = " to all students in the department";
                                            } elseif ($row["matricno"] == "All_stu") {
                                                $headerstr = " to all students";
                                            } elseif (substr($row["matricno"], 0, 1) == "L") {
                                                $headerstr = " to all " . $Level . " students";
                                            } else {
                                                $headerstr = " to all " . $row["matricno"] . " registered students";
                                            }

                                            $dateString = $row["date1"];
                                            $current_timestamp = strtotime($dateString ?? '2024-01-01 00:00:00');



                                            //$current_timestamp = strtotime($row["date1"]);
                                            $midnight_timestamp = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
                                    ?>

                                <tr>
                                    <td>
                                        <a href="#" class="pull-left">
                                            <i class="fa fa-long-arrow-right"></i>
                                        </a><b>From <?php echo $headerstr1 . $headerstr ?></b>
                                        <div class="media-body" style="padding-left: 1em;">
                                            <div style="text-align: justify;">
                                                <?php echo $row["sent_coment"] ?>

                                            </div>
                                            <br>
                                            <div style="text-align: right;">
                                                <?php
                                                            if ($current_timestamp > $midnight_timestamp) {

                                                            ?>
                                                <small class="pull-right text-muted">Today
                                                    <?php echo date_format($date, "h:i A d D, Y"); ?></small>
                                                <?php
                                                            } else if ($current_timestamp > $midnight_timestamp - 86400) {

                                                            ?>
                                                <small class="pull-right text-muted">Yesterday
                                                    <?php echo date_format($date, "h:i A d D, Y"); ?></small>
                                                <?php
                                                            } else {

                                                            ?>
                                                <small
                                                    class="pull-right text-muted"><?php echo date_format($date, "l, h:i:s A d D, Y"); ?></small>
                                                <?php
                                                            }

                                                            ?>


                                            </div>

                                        </div>
                                        <p class='alert alert-danger'></p>

                                    </td>
                                </tr>
                                <?php
                                        }
                                    }
                                    ?>
                            </tbody>
                        </table>
                        <?php
                        }
                        ?>


                    </div>

                </div>

            </div>
            <div class="wrapper wrapper-content">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-content">
                                <div>

                                    <div class="col-lg-6">
                                        <h3>Academic Performance(CGPA)</h3>
                                    </div>
                                    <div class="col-lg-6" style="text-align: right;">
                                        <?php
                                        if ($_SESSION['InstType'] == "Polytechnic") {
                                            if ($_SESSION['modeofentry'] == "ND") {
                                                echo "<h3>Programme: National Diploma</h3>";
                                            } else {
                                                echo "<h3>Programme: Higher National Diploma</h3>";
                                            }
                                        }
                                        ?>


                                    </div>
                                </div>

                                <div>
                                    <canvas id="lineChart" height="70"></canvas>

                                </div>


                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">

                    <div class="col-lg-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <div class="col-lg-6">
                                    <h5>CGPA</h5>
                                </div>
                                <div class="col-lg-6" style="text-align: right;">
                                    Status: <?php echo $stustatus ?>
                                </div>

                            </div>
                            <div class="ibox-content">

                                <h2 class="no-margins"><?php echo number_format((float)$finalCGPA, 2, '.', '') ?></h2>
                                <div class="stat-percent font-bold text-navy"><a class="text-muted"
                                        href="stu_results.php">(View
                                        All)</a></div>
                                <small>.</small>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Diff/Outstanding Courses</h5>
                            </div>
                            <div class="ibox-content">
                                <h2 class="no-margins"><?php echo $diff_outstand ?> Unit(s)</h2>
                                <div class="stat-percent font-bold text-navy"><a class="text-muted"
                                        href="outstanding_course.php">(View
                                        All)</a></div>
                                <small>.</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="ibox float-e-margins">
                            <?php
                            $response = $session = $semester = "";
                                    
                            $matno = $_SESSION["regid"];
                            $sql = "SELECT * FROM missing_session WHERE matno = '$matno' ORDER BY session";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $response = $row["response"];
                                    $semester = $row["semester"];
                                    $session = $row["session"];
                                    break;
                                }
                            }
                            ?>
                            <div class="ibox-title">
                                <h5><?php echo $response ?></h5>
                            </div>
                            <div class="ibox-content">
                                <h2 class="no-margins"><?php echo $semester . ", " . $session ?></h2>
                                <div class="stat-percent font-bold text-navy"><a class="text-muted"
                                        href="miss_session.php">(View
                                        All)</a></div>
                                <small>.</small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-8">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <?php echo $_SESSION['corntsession'] . " ";  ?> Academic Calendar
                            </div>
                            <div class="panel-body">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Semester</th>
                                            <th>Activity</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        $sql = "SELECT * FROM acad_calendar";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $date1 = $row["date1"];
                                                $semester = $row["semester"];
                                                $activity1 = $row["activity1"];
                                                echo "<tr><td>$date1</td><td>$semester</td><td>$activity1</td></tr>\n";
                                            }
                                        }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                OUR VISION
                            </div>
                            <div class="panel-body">
                                <p style="text-align: justify;"><?php echo $_SESSION['vision'] ?></p>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading">
                                OUR MISSION
                            </div>
                            <div class="panel-body">
                                <p style="text-align: justify;"><?php echo $_SESSION['mission'] ?>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
                <?php
                $conn->close();
                $conn2->close();
                $conn_stu->close();
                ?>
            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
        <?php
        include_once 'small_chat.php';
        ?>

        <!-- Modal HTML -->
        <div id="myModal" class="modal inmodal" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form enctype="multipart/form-data" action="" method="POST" class="form-horizontal">
                        <?php
                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                        if ($conn_stu->connect_error) {
                            die("Connection failed: " . $conn_stu->connect_error);
                        }

                        $sql = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$curtsession'";
                        $result = $conn_stu->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $LAComment = $row["LAComment"];
                                $HODComment = $row["HODComment"];
                            }
                        }
                        $conn_stu->close();
                        ?>
                        <div class="modal-header">
                            <h4 class="modal-title">Important Message on Course Registration</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">

                            <div class="form-group">
                                <?php if ($leveladvcom == true) { ?>
                                <h3>From Level Adviser:- <?php echo $LAComment ?></h3>
                                <?php } ?>
                                <?php if ($hodcom == true) { ?>
                                <h3>From HOD:- <?php echo $HODComment ?></h3>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">

                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- ChartJS-->
    <script src="js/plugins/chartJs/Chart.min.js"></script>

    <script src="js/helpdesk_stu_chat.js"></script>
    <!--
    <script>
        $(document).ready(function() {
            setInterval(function() {
                $("#small_chat_body").load(window.location.href + " #small_chat_body");
            }, 3000);
        });
    </script>
    <script>
        $(document).ready(function() {
            setInterval(function() {
                $("#smallchat_lasttime").load(window.location.href + " #smallchat_lasttime");
            }, 3000);
        });
    </script>
    -->

    <?php if ($leveladvcom == true || $hodcom == true) { ?>
    <script>
    $(window).on('load', function() {
        $('#myModal').modal('show');
    });
    </script>
    <?php } ?>



    <script>
    <?php if ($countses == 1) { ?>
    $(document).ready(function() {

        var lineData = {
            labels: ["0", "<?php echo $session1; ?>"],
            datasets: [{
                label: "CGPA",
                backgroundColor: "rgba(26,179,148,0.5)",
                borderColor: "rgba(26,179,148,0.7)",
                pointBackgroundColor: "rgba(26,179,148,1)",
                pointBorderColor: "#fff",
                data: [0, <?php echo $cgpa1; ?>]
            }]
        };

        var lineOptions = {
            responsive: true
        };


        var ctx = document.getElementById("lineChart").getContext("2d");
        new Chart(ctx, {
            type: 'line',
            data: lineData,
            options: lineOptions
        });

    });
    <?php } elseif ($countses == 2) { ?>
    $(document).ready(function() {

        var lineData = {
            labels: ["0", "<?php echo $session1; ?>", "<?php echo $session2; ?>"],
            datasets: [{
                label: "CGPA",
                backgroundColor: "rgba(26,179,148,0.5)",
                borderColor: "rgba(26,179,148,0.7)",
                pointBackgroundColor: "rgba(26,179,148,1)",
                pointBorderColor: "#fff",
                data: [0, <?php echo $cgpa1; ?>, <?php echo $cgpa2; ?>]
            }]
        };

        var lineOptions = {
            responsive: true
        };


        var ctx = document.getElementById("lineChart").getContext("2d");
        new Chart(ctx, {
            type: 'line',
            data: lineData,
            options: lineOptions
        });

    });
    <?php } elseif ($countses == 3) { ?>
    $(document).ready(function() {

        var lineData = {
            labels: ["0", "<?php echo $session1; ?>", "<?php echo $session2; ?>",
                "<?php echo $session3; ?>"
            ],
            datasets: [{
                label: "CGPA",
                backgroundColor: "rgba(26,179,148,0.5)",
                borderColor: "rgba(26,179,148,0.7)",
                pointBackgroundColor: "rgba(26,179,148,1)",
                pointBorderColor: "#fff",
                data: [0, <?php echo $cgpa1; ?>, <?php echo $cgpa2; ?>, <?php echo $cgpa3; ?>]
            }]
        };

        var lineOptions = {
            responsive: true
        };


        var ctx = document.getElementById("lineChart").getContext("2d");
        new Chart(ctx, {
            type: 'line',
            data: lineData,
            options: lineOptions
        });

    });
    <?php } elseif ($countses == 4) { ?>
    $(document).ready(function() {

        var lineData = {
            labels: ["0", "<?php echo $session1; ?>", "<?php echo $session2; ?>",
                "<?php echo $session3; ?>", "<?php echo $session4; ?>"
            ],
            datasets: [{
                label: "CGPA",
                backgroundColor: "rgba(26,179,148,0.5)",
                borderColor: "rgba(26,179,148,0.7)",
                pointBackgroundColor: "rgba(26,179,148,1)",
                pointBorderColor: "#fff",
                data: [0, <?php echo $cgpa1; ?>, <?php echo $cgpa2; ?>, <?php echo $cgpa3; ?>,
                    <?php echo $cgpa4; ?>
                ]
            }]
        };

        var lineOptions = {
            responsive: true
        };


        var ctx = document.getElementById("lineChart").getContext("2d");
        new Chart(ctx, {
            type: 'line',
            data: lineData,
            options: lineOptions
        });

    });
    <?php } elseif ($countses == 5) { ?>
    $(document).ready(function() {

        var lineData = {
            labels: ["0", "<?php echo $session1; ?>", "<?php echo $session2; ?>",
                "<?php echo $session3; ?>", "<?php echo $session4; ?>", "<?php echo $session5; ?>"
            ],
            datasets: [{
                label: "CGPA",
                backgroundColor: "rgba(26,179,148,0.5)",
                borderColor: "rgba(26,179,148,0.7)",
                pointBackgroundColor: "rgba(26,179,148,1)",
                pointBorderColor: "#fff",
                data: [0, <?php echo $cgpa1; ?>, <?php echo $cgpa2; ?>, <?php echo $cgpa3; ?>,
                    <?php echo $cgpa4; ?>, <?php echo $cgpa5; ?>
                ]
            }]
        };

        var lineOptions = {
            responsive: true
        };


        var ctx = document.getElementById("lineChart").getContext("2d");
        new Chart(ctx, {
            type: 'line',
            data: lineData,
            options: lineOptions
        });

    });
    <?php } ?>
    </script>


</body>

</html>
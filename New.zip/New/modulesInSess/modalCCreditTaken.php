<?php

unset($fr);
unset($fr2);
unset($fr3);

unset($cumunitArray);
unset($cumunitArray2);
unset($cumunitArray3);

$fr[] = 0;
$fr2[] = 0;
$fr3[] = 0;

$cumunitArray[] = 0;
$cumunitArray2[] = 0;
$cumunitArray3[] = 0;
$maxint = 0;
$maxint2 = 0;
$maxint3 = 0;
$getMax = 0;
$getMax2 = 0;
$getMax3 = 0;

$getdept = $_SESSION['deptcode'];
$deptcorreg = $getdept . "_correg";

for ($i = 1; $i <= $repairIteration; $i++) {
    if ($repairEntry_Level[$i] == 200) {
        $cumunitArray2[$i] = $repairCumCP[$i] + $repairToTOuts[$i];

        if (isset($fr2[$cumunitArray2[$i]]) == false) {
            $fr2[$cumunitArray2[$i]] = 1;
        } else {
            $fr2[$cumunitArray2[$i]]++;
        }
    } elseif ($repairEntry_Level[$i] == 300) {
        $cumunitArray3[$i] = $repairCumCP[$i] + $repairToTOuts[$i];

        if (isset($fr3[$cumunitArray3[$i]]) == false) {
            $fr3[$cumunitArray3[$i]] = 1;
        } else {
            $fr3[$cumunitArray3[$i]]++;
        }
    } else {

        $cumunitArray[$i] = $repairCumCP[$i] + $repairToTOuts[$i];

        if (isset($fr[$cumunitArray[$i]]) == false) {
            $fr[$cumunitArray[$i]] = 1;
        } else {
            $fr[$cumunitArray[$i]]++;
        }
    }
}

/*for($i=1; $i <= $repairIteration; $i++) {
        if((int)substr($repairRegno[$i],5,1)==2){
            if(isset($fr2[$cumunitArray2[$i]])==false) {
                $fr2[$cumunitArray2[$i]] = 1;
            } else {
                $fr2[$cumunitArray2[$i]]++;
            }
        }elseif ((int)substr($repairRegno[$i],5,1)==3){
            if(isset($fr3[$cumunitArray3[$i]])==false) {
                $fr3[$cumunitArray3[$i]] = 1;
            } else {
                $fr3[$cumunitArray3[$i]]++;
            }
        }else{
            if(isset($fr[$cumunitArray[$i]])==false) {
                $fr[$cumunitArray[$i]] = 1;
            } else {
                $fr[$cumunitArray[$i]]++;
            }
        }

    }*/
$maxs = array_keys($fr, max($fr));
$maxs2 = array_keys($fr2, max($fr2));
$maxs3 = array_keys($fr3, max($fr3));


$maxint = $maxs[0];
$maxint2 = $maxs2[0];
$maxint3 = $maxs3[0];
$getMax = $fr[$maxs[0]];
$getMax2 = $fr2[$maxs2[0]];
$getMax3 = $fr3[$maxs3[0]];


for ($i = 1; $i <= $repairIteration; $i++) {

    /*$creditCondCourse2 = 0;
        $sql3 = "SELECT * FROM ".$deptcorreg." WHERE Regn1  = '$repairRegno[$i]' AND SemTaken  = '$GetTheSemester' AND coursecondon = 'YES' AND SessionRegis =  '$GetTheSession'";
        $result3 = $conn->query($sql3);
        if ($result3->num_rows > 0) {
            while ($row3 = $result3->fetch_assoc()) {
                $creditCondCourse2 = $creditCondCourse2 + $row3["CUnit"];
            }
        }*/
    /*if ($txtLevelPlus == 500 ){
            if ((int)substr($repairRegno[$i],0,4) == $yearadmtInSess ){
                if ($repairPresCrTaken[$i] + $creditCondCourse2 > 26 || ($repairPresCrTaken[$i] + $creditCondCourse2 < 16 && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0) ){
                    $UnderDeclaration = True;
                }
            }else{
                if ($repairPresCrTaken[$i] + $creditCondCourse2 > 26 && $repairCumCP[$i] + $repairToTOuts[$i] != 0 ){
                    $UnderDeclaration = True;
                }
            }
        }elseif ($txtLevelPlus == 300 ){
            if ((int)substr($repairRegno[$i],0,4) < $yearadmtInSess ){
                if ($repairPresCrTaken[$i] + $creditCondCourse2 > 24 && $repairCumCP[$i] + $repairToTOuts[$i] != 0 ){
                    $UnderDeclaration = True;
                }
            }else{
                if ($repairPresCrTaken[$i] + $creditCondCourse2 > 24 || ($repairPresCrTaken[$i] + $creditCondCourse2 < 16 && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0) ){
                    $UnderDeclaration = True;
                }
            }
        }elseif ($txtLevelPlus == 100 ){
            if ($repairPresCrTaken[$i] + $creditCondCourse2 > 24 || ($repairPresCrTaken[$i] + $creditCondCourse2 < 16 && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0) ){
                $sql = "SELECT * FROM ten88stu WHERE matno  = '$repairRegno[$i]' AND DeptCode  = '$getdept'";
                $result = $conn->query($sql);
                $NoTen88=0;
                if ($result->num_rows > 0) {
                    $NoTen88 = $NoTen88 + 1;
                }
                if ($NoTen88 != 0 && (int)substr($repairRegno[$i],0,4) < $yearadmtInSess ){

                }else{
                   $UnderDeclaration = True;
                }

            }
        }else{
            if ($repairPresCrTaken[$i] + $creditCondCourse2 > 24 || ($repairPresCrTaken[$i] + $creditCondCourse2 < 16 && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0) ){
                $UnderDeclaration = True;
            }
        }*/

    /* if ((int)substr($repairRegno[$i], 5, 1) == 2) {
        $getmaxint = $maxint2;
    } elseif ((int)substr($repairRegno[$i], 5, 1) == 3) {
        $getmaxint = $maxint3;
    } else {
        $getmaxint = $maxint;
    } */

    if ($_SESSION['InstType'] == "University") {
        if ($repairmodeofentry[$i] == "UTME") {
            $getmaxint = $maxint;
        } else {
            if ($repairEntry_Level[$i] == 100) {
                $getmaxint = $maxint;
            } elseif ($repairEntry_Level[$i] == 200) {
                $getmaxint = $maxint2;
            } elseif ($repairEntry_Level[$i] == 300) {
                $getmaxint = $maxint3;
            }
        }
    } elseif ($_SESSION['InstType'] == "Polytechnic") {
        $getmaxint = $maxint;
    } else {
    }

    if (($repairStd_yearAdtd[$i] == $yearadmtInSess && $repairEntry_Level[$i] == 100) or ($repairStd_yearAdtd[$i] > $yearadmtInSess && $repairEntry_Level[$i] > 100)) {
        if ($txtLevelPlus == 100) {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 2 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 5 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        } elseif ($txtLevelPlus == 200) {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 4 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 10 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        } elseif ($txtLevelPlus == 300) {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 5 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 10 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        } elseif ($txtLevelPlus == 400) {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 6 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 10 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        } else {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 8 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 10 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        }
    } else {
        if ($txtLevelPlus == 100) {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 2 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 45 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        } elseif ($txtLevelPlus == 200) {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 4 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 60 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        } elseif ($txtLevelPlus == 300) {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 5 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 75 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        } elseif ($txtLevelPlus == 400) {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 6 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 100 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        } else {
            if (($repairCumCP[$i] + $repairToTOuts[$i] + 8 < $getmaxint) || ($repairCumCP[$i] + $repairToTOuts[$i] - 150 > $getmaxint)) {
                $UnderDeclaration = True;
            }
        }
    }
}

<?php

$n = 0;
$Total_C_F = 0;
$no_of_failure = 0;
$strDefficiency = "";
$Credit_Fail = "";
$YESRelevant = "YES";
$FailedCourses = 0;
$defCount = 0;

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$sql6 = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
$result6 = $conn2->query($sql6);
if ($result6->num_rows > 0) {
    while ($row6 = $result6->fetch_assoc()) {
        $curri = $row6["curriculum"];
    }
}
if ($curri == "OLD") {
    $curri2 = "";
} else {
    $curri2 = "_" . $curri;
}
$deptgencourses = "gencourses" . $curri2;

//$deptcorreg = "correg";
//$getGencourse = "gencourses";
//$deptgencourses = "gencourses";

$deptdb = $_SESSION['deptdb'];
$dept_db = $deptdb . strtolower($getdept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

unset($difFailedCarray);
unset($difFailedCarray2);
$difFailedCarray = array_values(array_diff($FailedCoursearray, $PassedCoursearray));
$difFailedCarray2 = array_values(array_unique($difFailedCarray));
$arraynoFailed = count($difFailedCarray2);
if ($arraynoFailed != 0) {
    for ($x = 0; $x < $arraynoFailed; $x++) {
        $CCode2 = $difFailedCarray2[$x];
        if ($deptoption == "YES") {
            $sql3 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding  = '$CCode2' AND " . $Deptopt2 . " = '$YESRelevant'";
            $result3 = $conn_stu->query($sql3);
            $Add3 = 0;
            if ($result3->num_rows > 0) {
                while ($row3 = $result3->fetch_assoc()) {
                    $Add3++;
                }
            }
        } else {
            $sql3 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding  = '$CCode2' AND Relevant = '$YESRelevant'";
            $result3 = $conn_stu->query($sql3);
            $Add3 = 0;
            if ($result3->num_rows > 0) {
                while ($row3 = $result3->fetch_assoc()) {
                    $Add3++;
                }
            }
        }
        if ($Add3 > 0) {
            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding = '$CCode2'";
            $result6 = $conn_stu->query($sql6);
            if ($result6->num_rows > 0) {
                while ($row6 = $result6->fetch_assoc()) {
                    $GetUnit2 = $row6["credit"];
                }
            }
            $n++;
            $Total_C_F = $Total_C_F + $GetUnit2;
            $Credit_Fail = $Credit_Fail . $CCode2 . "(" . $GetUnit2 . "), ";
            $FailedCourses++;

            $defCount++;
            $defCCode[$defCount] = $CCode2;
            //$defRegn1[$defCount]=$repairRegno[$repairIteration];
        }
    }
}

// Get Outstanding Courses
$YesOption = "YES";
$Outstand = "";
$TotGetUnit2 = 0;

unset($difarray);
unset($difGCodearray);
if ($NON_DE_Senate == true) {
    $difarray = array_values(array_diff($corecoursearray, $regcoursesarray));
    $difGCodearray = array_values(array_diff($groupCodearray, $GCodecoursesarray));
} elseif ($DE200Senate == true) {
    $difarray = array_values(array_diff($DE200corecoursearray, $regcoursesarray));
    $difGCodearray = array_values(array_diff($DE200groupCodearray, $GCodecoursesarray));
} elseif ($DE300Senate == true) {
    $difarray = array_values(array_diff($DE300corecoursearray, $regcoursesarray));
    $difGCodearray = array_values(array_diff($DE300groupCodearray, $GCodecoursesarray));
}
$difGCodearray = array_unique($difGCodearray);


$arrayno = count($difarray);
$arraynoGCode = count($difGCodearray);

if ($arrayno != 0) {
    for ($x = 0; $x < $arrayno; $x++) {
        //echo $repairRegno[$repairIteration] . ", " . $difarray[$x] . "<br>";
        $CCode2 = $difarray[$x];
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding = '$CCode2'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $GetUnit2 = $row6["credit"];
            }
        }
        $TotGetUnit2 = $TotGetUnit2 + $GetUnit2;
        $NoOutstandCourse = $NoOutstandCourse + 1;
        $IsCcondon = 0;

        $Outstand = $Outstand . $CCode2 . "(" . $GetUnit2 . "), ";

        $defCount++;
        $defCCode[$defCount] = $CCode2;
        //$defRegn1[$defCount]=$repairRegno[$repairIteration];
    }
}

if ($arraynoGCode != 0) {
    for ($x = 0; $x < $arraynoGCode; $x++) {
        $GrCode = $difGCodearray[$x];
        if ($deptoption == "YES") {
            $sql6 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$Deptopt2' AND GroupCode = '$GrCode'";
        } else {
            $sql6 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND GroupCode = '$GrCode'";
        }
        $result6 = $conn->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $CCode2 = $row6["outsCourse"];
            }
        }

        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding = '$CCode2'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $GetUnit2 = $row6["credit"];
            }
        }

        $TotGetUnit2 = $TotGetUnit2 + $GetUnit2;
        $NoOutstandCourse = $NoOutstandCourse + 1;
        $IsCcondon = 0;

        $Outstand = $Outstand . $CCode2 . "(" . $GetUnit2 . "), ";

        $defCount++;
        $defCCode[$defCount] = $CCode2;
        //$defRegn1[$defCount]=$repairRegno[$repairIteration];
    }
}
$conn->close();
$conn2->close();
$conn_stu->close();

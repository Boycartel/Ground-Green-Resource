<?php
$dept = $_SESSION['deptcode'];
$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$sql2 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND session1 ='$getsession' AND semester ='2ND'";
$result2 = $conn_stu->query($sql2);
if ($result2->num_rows == 0) {
    $sql3 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND session1 ='$getsession' AND semester ='1ST'";
    $result3 = $conn_stu->query($sql3);
    if ($result3->num_rows > 0) {
        while ($row3 = $result3->fetch_assoc()) {

            $prevcgpa = $row3["CGPA"];
            $stustatus = $row3["RMK"];
            $finalCGPA = $row3["CGPA"];
        }
    }
} else {
    $sql3 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND session1 ='$getsession' AND semester ='2ND'";
    $result3 = $conn_stu->query($sql3);
    if ($result3->num_rows > 0) {
        while ($row3 = $result3->fetch_assoc()) {

            $prevcgpa = $row3["CGPA"];
            $stustatus = $row3["RMK"];
            $finalCGPA = $row3["CGPA"];
        }
    }
}

$conn_stu->close();

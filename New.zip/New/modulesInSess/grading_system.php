 <?php
    //$row['CA'] + $row['Exam'] >= 70
    if ($_SESSION['InstType'] == "University") {
        if ($total >= 70) {
            $grade = "A";
            $gp = $credit * 5;
        } elseif ($total >= 60) {
            $grade = "B";
            $gp = $credit * 4;
        } elseif ($total >= 50) {
            $grade = "C";
            $gp = $credit * 3;
        } elseif ($total >= 45) {
            $grade = "D";
            $gp = $credit * 2;
        } elseif ($total >= 40) {
            $grade = "E";
            $gp = $credit * 1;
        } elseif ($total <= 39.95) {
            $grade = "F";
            $gp = 0;
        }
    } elseif ($_SESSION['InstType'] == "Polytechnic") {



        if ($total >= 75) {
            $grade = "A";
            $gp = $credit * 4;
        } elseif ($total >= 70) {
            $grade = "AB";
            $gp = $credit * 3.5;
        } elseif ($total >= 65) {
            $grade = "B";
            $gp = $credit * 3.25;
        } elseif ($total >= 60) {
            $grade = "BC";
            $gp = $credit * 3;
        } elseif ($total >= 55) {
            $grade = "C";
            $gp = $credit * 2.75;
        } elseif ($total >= 50) {
            $grade = "CD";
            $gp = $credit * 2.5;
        } elseif ($total >= 45) {
            $grade = "D";
            $gp = $credit * 2.25;
        } elseif ($total >= 40) {
            $grade = "E";
            $gp = $credit * 2;
        } else {
            $grade = "F";
            $gp = 0;
        }
    } else {
    }

// Update the following Files

    // 1. raw_results_approval_view.php
    // 2. qap_results.php
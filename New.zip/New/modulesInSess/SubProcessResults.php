<?php

// Non DE UME
if ($GetTheSemester == "1ST") {
    if ($deptoption == "YES") {
        if ($_SESSION['InstType'] == "University") {
            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 < '$txtLevelPlus' AND " . $GroupOption . " = 'NO'";
            $result6 = $conn_stu->query($sql6);
            if ($result6->num_rows > 0) {
                while ($row6 = $result6->fetch_assoc()) {
                    $corecoursecount++;
                    $CCode2 = $row6["C_codding"];
                    $corecoursearray[$corecoursecount] = $CCode2;
                }
            }
        } elseif ($_SESSION['InstType'] == "Polytechnic") {
            if ($getprogram == "HND") {
                if ($txtLevelPlus == "400") {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '300' AND " . $GroupOption . " = 'NO'";
                    $result6 = $conn_stu->query($sql6);
                    if ($result6->num_rows > 0) {
                        while ($row6 = $result6->fetch_assoc()) {
                            $corecoursecount++;
                            $CCode2 = $row6["C_codding"];
                            $corecoursearray[$corecoursecount] = $CCode2;
                        }
                    }
                }
            } else {
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 < '$txtLevelPlus' AND " . $GroupOption . " = 'NO'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    while ($row6 = $result6->fetch_assoc()) {
                        $corecoursecount++;
                        $CCode2 = $row6["C_codding"];
                        $corecoursearray[$corecoursecount] = $CCode2;
                    }
                }
            }
        }
    } else {
        if ($_SESSION['InstType'] == "University") {
            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 < '$txtLevelPlus' AND Grouping2 = 'NO'";
            $result6 = $conn_stu->query($sql6);
            if ($result6->num_rows > 0) {
                while ($row6 = $result6->fetch_assoc()) {
                    $corecoursecount++;
                    $CCode2 = $row6["C_codding"];
                    $corecoursearray[$corecoursecount] = $CCode2;
                }
            }
        } elseif ($_SESSION['InstType'] == "Polytechnic") {
            if ($getprogram == "HND") {
                if ($txtLevelPlus == "400") {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '300' AND Grouping2 = 'NO'";
                    $result6 = $conn_stu->query($sql6);
                    if ($result6->num_rows > 0) {
                        while ($row6 = $result6->fetch_assoc()) {
                            $corecoursecount++;
                            $CCode2 = $row6["C_codding"];
                            $corecoursearray[$corecoursecount] = $CCode2;
                        }
                    }
                }
            } else {
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 < '$txtLevelPlus' AND Grouping2 = 'NO'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    while ($row6 = $result6->fetch_assoc()) {
                        $corecoursecount++;
                        $CCode2 = $row6["C_codding"];
                        $corecoursearray[$corecoursecount] = $CCode2;
                    }
                }
            }
        }
    }

    if ($deptoption == "YES") {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND " . $GroupOption . " = 'NO' AND semester = '1ST'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                $corecoursearray[$corecoursecount] = $CCode2;
            }
        }
    } else {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping2 = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                $corecoursearray[$corecoursecount] = $CCode2;
            }
        }
    }
} else {
    if ($deptoption == "YES") {
        if ($_SESSION['InstType'] == "University") {
            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 <= '$txtLevelPlus' AND " . $GroupOption . " = 'NO'";
            $result6 = $conn_stu->query($sql6);
            if ($result6->num_rows > 0) {
                while ($row6 = $result6->fetch_assoc()) {
                    $corecoursecount++;
                    $CCode2 = $row6["C_codding"];
                    $corecoursearray[$corecoursecount] = $CCode2;
                }
            }
        } elseif ($_SESSION['InstType'] == "Polytechnic") {
            if ($getprogram == "HND") {
                if ($txtLevelPlus == "400") {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '300' AND Level1 = '400' AND " . $GroupOption . " = 'NO'";
                } else {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '300' AND " . $GroupOption . " = 'NO'";
                }
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    while ($row6 = $result6->fetch_assoc()) {
                        $corecoursecount++;
                        $CCode2 = $row6["C_codding"];
                        $corecoursearray[$corecoursecount] = $CCode2;
                    }
                }
            } else {
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 <= '$txtLevelPlus' AND " . $GroupOption . " = 'NO'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    while ($row6 = $result6->fetch_assoc()) {
                        $corecoursecount++;
                        $CCode2 = $row6["C_codding"];
                        $corecoursearray[$corecoursecount] = $CCode2;
                    }
                }
            }
        }
    } else {
        if ($_SESSION['InstType'] == "University") {
            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 <= '$txtLevelPlus' AND Grouping2 = 'NO'";
            $result6 = $conn_stu->query($sql6);
            if ($result6->num_rows > 0) {
                while ($row6 = $result6->fetch_assoc()) {
                    $corecoursecount++;
                    $CCode2 = $row6["C_codding"];
                    $corecoursearray[$corecoursecount] = $CCode2;
                }
            }
        } elseif ($_SESSION['InstType'] == "Polytechnic") {
            if ($getprogram == "HND") {
                if ($txtLevelPlus == "400") {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '300' AND Level1 = '400' AND Grouping2 = 'NO'";
                } else {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '300' AND Grouping2 = 'NO'";
                }
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    while ($row6 = $result6->fetch_assoc()) {
                        $corecoursecount++;
                        $CCode2 = $row6["C_codding"];
                        $corecoursearray[$corecoursecount] = $CCode2;
                    }
                }
            } else {
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 <= '$txtLevelPlus' AND Grouping2 = 'NO'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    while ($row6 = $result6->fetch_assoc()) {
                        $corecoursecount++;
                        $CCode2 = $row6["C_codding"];
                        $corecoursearray[$corecoursecount] = $CCode2;
                    }
                }
            }
        }
    }
}


if ($_SESSION['InstType'] == "University") {
    if ($deptoption == "YES") {
        if ($curricul == "YES") {
            $curri = $_SESSION["curri"];
            $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt' AND curriculum = '$curri'";
        } else {
            $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt'";
        }
        $result5 = $conn->query($sql5);
        if ($result5->num_rows > 0) {
            while ($row5 = $result5->fetch_assoc()) {
                $GetOptCourse = $row5["GroupCode"];
                if ($GetTheSemester == "1ST") {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 < '$txtLevelPlus' AND " . $GroupOption . " = '$GetOptCourse'";
                    $result6 = $conn_stu->query($sql6);
                    if ($result6->num_rows > 0) {
                        $groupCodecount++;
                        $groupCodearray[$groupCodecount] = $GetOptCourse;
                    }

                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND " . $GroupOption . " = '$GetOptCourse'";
                    $result6 = $conn_stu->query($sql6);
                    if ($result6->num_rows > 0) {
                        $groupCodecount++;
                        $groupCodearray[$groupCodecount] = $GetOptCourse;
                    }
                } else {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 <= '$txtLevelPlus' AND " . $GroupOption . " = '$GetOptCourse'";
                    $result6 = $conn_stu->query($sql6);
                    if ($result6->num_rows > 0) {
                        $groupCodecount++;
                        $groupCodearray[$groupCodecount] = $GetOptCourse;
                    }
                }
            }
        }
    } else {
        if ($curricul == "YES") {
            $curri = $_SESSION["curri"];
            $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND curriculum = '$curri'";
        } else {
            $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
        }
        $result5 = $conn->query($sql5);
        if ($result5->num_rows > 0) {
            while ($row5 = $result5->fetch_assoc()) {
                $GetOptCourse = $row5["GroupCode"];
                if ($GetTheSemester == "1ST") {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 < '$txtLevelPlus' AND Grouping2 = '$GetOptCourse'";
                    $result6 = $conn_stu->query($sql6);
                    if ($result6->num_rows > 0) {
                        $groupCodecount++;
                        $groupCodearray[$groupCodecount] = $GetOptCourse;
                    }

                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping2 = '$GetOptCourse'";
                    $result6 = $conn_stu->query($sql6);
                    if ($result6->num_rows > 0) {
                        $groupCodecount++;
                        $groupCodearray[$groupCodecount] = $GetOptCourse;
                    }
                } else {
                    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 <= '$txtLevelPlus' AND Grouping2 = '$GetOptCourse'";
                    $result6 = $conn_stu->query($sql6);
                    if ($result6->num_rows > 0) {
                        $groupCodecount++;
                        $groupCodearray[$groupCodecount] = $GetOptCourse;
                    }
                }
            }
        }
    }
} elseif ($_SESSION['InstType'] == "Polytechnic") {
    if ($getprogram == "HND") {
        if ($txtLevelPlus == "400") {
            if ($deptoption == "YES") {
                if ($curricul == "YES") {
                    $curri = $_SESSION["curri"];
                    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt' AND curriculum = '$curri'";
                } else {
                    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt'";
                }
                $result5 = $conn->query($sql5);
                if ($result5->num_rows > 0) {
                    while ($row5 = $result5->fetch_assoc()) {
                        $GetOptCourse = $row5["GroupCode"];
                        if ($GetTheSemester == "1ST") {
                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '300' AND " . $GroupOption . " = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }

                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND " . $GroupOption . " = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }
                        } else {
                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '300' AND Level1 = '400' AND " . $GroupOption . " = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }
                        }
                    }
                }
            } else {
                if ($curricul == "YES") {
                    $curri = $_SESSION["curri"];
                    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND curriculum = '$curri'";
                } else {
                    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
                }
                $result5 = $conn->query($sql5);
                if ($result5->num_rows > 0) {
                    while ($row5 = $result5->fetch_assoc()) {
                        $GetOptCourse = $row5["GroupCode"];
                        if ($GetTheSemester == "1ST") {
                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '300' AND Grouping2 = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }

                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping2 = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }
                        } else {
                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '300' AND Level1 = '400' AND Grouping2 = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }
                        }
                    }
                }
            }
        } else {
            if ($deptoption == "YES") {
                if ($curricul == "YES") {
                    $curri = $_SESSION["curri"];
                    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt' AND curriculum = '$curri'";
                } else {
                    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt'";
                }
                $result5 = $conn->query($sql5);
                if ($result5->num_rows > 0) {
                    while ($row5 = $result5->fetch_assoc()) {
                        $GetOptCourse = $row5["GroupCode"];
                        if ($GetTheSemester == "1ST") {

                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND " . $GroupOption . " = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }
                        } else {
                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND " . $GroupOption . " = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }
                        }
                    }
                }
            } else {
                if ($curricul == "YES") {
                    $curri = $_SESSION["curri"];
                    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND curriculum = '$curri'";
                } else {
                    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
                }
                $result5 = $conn->query($sql5);
                if ($result5->num_rows > 0) {
                    while ($row5 = $result5->fetch_assoc()) {
                        $GetOptCourse = $row5["GroupCode"];
                        if ($GetTheSemester == "1ST") {

                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping2 = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }
                        } else {
                            $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '$txtLevelPlus' AND Grouping2 = '$GetOptCourse'";
                            $result6 = $conn_stu->query($sql6);
                            if ($result6->num_rows > 0) {
                                $groupCodecount++;
                                $groupCodearray[$groupCodecount] = $GetOptCourse;
                            }
                        }
                    }
                }
            }
        }
    } else {
        if ($deptoption == "YES") {
            if ($curricul == "YES") {
                $curri = $_SESSION["curri"];
                $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt' AND curriculum = '$curri'";
            } else {
                $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt'";
            }
            $result5 = $conn->query($sql5);
            if ($result5->num_rows > 0) {
                while ($row5 = $result5->fetch_assoc()) {
                    $GetOptCourse = $row5["GroupCode"];
                    if ($GetTheSemester == "1ST") {
                        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 < '$txtLevelPlus' AND " . $GroupOption . " = '$GetOptCourse'";
                        $result6 = $conn_stu->query($sql6);
                        if ($result6->num_rows > 0) {
                            $groupCodecount++;
                            $groupCodearray[$groupCodecount] = $GetOptCourse;
                        }

                        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND " . $GroupOption . " = '$GetOptCourse'";
                        $result6 = $conn_stu->query($sql6);
                        if ($result6->num_rows > 0) {
                            $groupCodecount++;
                            $groupCodearray[$groupCodecount] = $GetOptCourse;
                        }
                    } else {
                        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND Level1 <= '$txtLevelPlus' AND " . $GroupOption . " = '$GetOptCourse'";
                        $result6 = $conn_stu->query($sql6);
                        if ($result6->num_rows > 0) {
                            $groupCodecount++;
                            $groupCodearray[$groupCodecount] = $GetOptCourse;
                        }
                    }
                }
            }
        } else {
            if ($curricul == "YES") {
                $curri = $_SESSION["curri"];
                $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND curriculum = '$curri'";
            } else {
                $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
            }
            $result5 = $conn->query($sql5);
            if ($result5->num_rows > 0) {
                while ($row5 = $result5->fetch_assoc()) {
                    $GetOptCourse = $row5["GroupCode"];
                    if ($GetTheSemester == "1ST") {
                        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 < '$txtLevelPlus' AND Grouping2 = '$GetOptCourse'";
                        $result6 = $conn_stu->query($sql6);
                        if ($result6->num_rows > 0) {
                            $groupCodecount++;
                            $groupCodearray[$groupCodecount] = $GetOptCourse;
                        }

                        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping2 = '$GetOptCourse'";
                        $result6 = $conn_stu->query($sql6);
                        if ($result6->num_rows > 0) {
                            $groupCodecount++;
                            $groupCodearray[$groupCodecount] = $GetOptCourse;
                        }
                    } else {
                        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Level1 <= '$txtLevelPlus' AND Grouping2 = '$GetOptCourse'";
                        $result6 = $conn_stu->query($sql6);
                        if ($result6->num_rows > 0) {
                            $groupCodecount++;
                            $groupCodearray[$groupCodecount] = $GetOptCourse;
                        }
                    }
                }
            }
        }
    }
}

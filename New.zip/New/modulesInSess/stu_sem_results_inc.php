<table style="width: 100%">
    <tbody>
    <tr><th style="border-style:solid; border-width:thin; text-align:center">1ST</th><th style="border-style:solid; border-width:thin; text-align:center">2ND</th></tr>
    <tr>
        <td style='border-style:solid; border-width:thin; text-align:center' valign="top">
            <table style="width: 100%">
                <thead>
                <tr style="border-style:solid; border-width:thin; text-align:center"><th style="text-align: center">C Code</th><th style="text-align: center">U</th><th style="text-align: center">GD</th><th style="text-align: center">GP</th></tr>
                </thead>
                <tbody>
                <?php
                if($SemCr1ST[$arrayNumb] != 0) {
                    for ($j = 0; $j < $countSesRes[$arrayNumb]; $j++) {
                        $semester2 = $semester_tot[$arrayNumb][$j];
                        $ccode2 = $ccode_tot[$arrayNumb][$j];
                        $ctitle2 = $ctitle_tot[$arrayNumb][$j];
                        $cunit2 = $cunit_tot[$arrayNumb][$j];
                        $grade2 = $grade_tot[$arrayNumb][$j];
                        $gpoint2 = $gpoint_tot[$arrayNumb][$j];
                        if ($semester2 == "1ST") {
                            echo "<tr><td style='padding-right: 1em'> $ccode2</td><td style='text-align: center'>$cunit2</td><td style='text-align: center'>$grade2</td><td style='text-align: center'>$gpoint2</td></tr>";
                        }
                    }

                ?>
                    <tr><th style='border: 1px solid black; border-collapse: collapse'> S Unit:-</th><th style='border: 1px solid black; border-collapse: collapse; text-align: center'><?php echo $SemCr1ST[$arrayNumb] ?></th><td style='border: 1px solid black; border-collapse: collapse;'></td><td  style='border: 1px solid black; border-collapse: collapse;'></td></tr>
                    <tr><th style='border: 1px solid black; border-collapse: collapse'> CGPA:-</th><th style='border: 1px solid black; border-collapse: collapse; text-align: center'><?php echo $CGPA1ST[$arrayNumb] ?></th><td  style='border: 1px solid black; border-collapse: collapse;'></td><td style='border: 1px solid black; border-collapse: collapse;'></td></tr>
                <?php } ?>
                </tbody>
            </table>

        </td>
        <td style='border-style:solid; border-width:thin; text-align:center' valign="top">
            <table style="width: 100%">
                <thead>
                <tr style="border-style:solid; border-width:thin; text-align:center"><th style="text-align: center">C Code</th><th style="text-align: center">U</th><th style="text-align: center">GD</th><th style="text-align: center">GP</th></tr>
                </thead>
                <tbody>
                <?php
                if($SemCr2ND[$arrayNumb] != 0) {
                    for($j =0; $j < $countSesRes[$arrayNumb]; $j++){
                        $semester2 =$semester_tot[$arrayNumb][$j];
                        $ccode2=$ccode_tot[$arrayNumb][$j];
                        $ctitle2=$ctitle_tot[$arrayNumb][$j];
                        $cunit2=$cunit_tot[$arrayNumb][$j];
                        $grade2=$grade_tot[$arrayNumb][$j];
                        $gpoint2=$gpoint_tot[$arrayNumb][$j];
                        if($semester2 == "2ND") {
                            echo "<tr><td style='padding-right: 1em'> $ccode2</td><td style='text-align: center'>$cunit2</td><td style='text-align: center'>$grade2</td><td style='text-align: center'>$gpoint2</td></tr>";
                        }
                    }
                    ?>
                    <tr><th style='border: 1px solid black; border-collapse: collapse;'> S Unit:-</th><th style='border: 1px solid black; border-collapse: collapse; text-align: center'><?php echo $SemCr2ND[$arrayNumb] ?></th><td  style='border: 1px solid black; border-collapse: collapse;'></td><td  style='border: 1px solid black; border-collapse: collapse;'></td></tr>
                    <tr><th style='border: 1px solid black; border-collapse: collapse'> CGPA:-</th><th style='border: 1px solid black; border-collapse: collapse; text-align: center'><?php echo $CGPA2ND[$arrayNumb] ?></th><td  style='border: 1px solid black; border-collapse: collapse;'></td><td  style='border: 1px solid black; border-collapse: collapse;'></td></tr>
                <?php } ?>
                </tbody>
            </table>

        </td>
    </tr>
    </tbody>
</table>

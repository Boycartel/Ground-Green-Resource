<?php
$FailedCourses = 0;

$CrTake100 = 0;
$CrPass100 = 0;
$GrPoint100 = 0;
$CGPA100 = 0;

$CrTake200 = 0;
$CrPass200 = 0;
$GrPoint200 = 0;
$CGPA200 = 0;

$CrTake300 = 0;
$CrPass300 = 0;
$GrPoint300 = 0;
$CGPA300 = 0;

$CrTake400 = 0;
$CrPass400 = 0;
$GrPoint400 = 0;
$CGPA400 = 0;

$CrTake500 = 0;
$CrPass500 = 0;
$GrPoint500 = 0;
$CGPA500 = 0;

$repairPrvTotalCrTaken = 0;
$repairPrvTotalCrPassed = 0;
$repairPrvTotalGradePoint = 0;
$repairPrvTotalCGPA = 0;

$repairCA = 0;
$repairEXAM = 0;
$repairTOTAL = 0;
$repairGRADE = "";
$repairUNIT = 0;

$repairPresTotalCrTaken = 0;
$repairPresTotalCrPassed = 0;
$presentGPointer = 0;
$repairPresTotalCGPA = 0;

$repairCA_pres = 0;
$repairEXAM_pres = 0;
$repairTOTAL_pres = 0;
$repairGRADE_pres = "";
$repairUNIT_pres = 0;

//cummulative..
$repairCumTotalCrTaken = 0;
$repairCumTotalCrPassed = 0;
$CumGPointer = 0;
$repairCumTotalCGPA = 0;

$repairCumTotalCrTaken_A = 0;
$repairCumTotalCrPassed_A = 0;
$CumGPointer_A = 0;
$repairCumTotalCGPA_A = 0;
$SngReCGP_Cum_A = 0;


$repairCA_Cum = 0;
$repairEXAM_Cum = 0;
$repairTOTAL_Cum = 0;
$repairGRADE_Cum = "";
$repairUNIT_Cum = 0;
$repairUNIT_REMARK = "";
$SSP1_STATE_Cum = 0;

$repairCA_Cum_A = 0;
$repairEXAM_Cum_A = 0;
$repairTOTAL_Cum_A = 0;
$repairUNIT_Cum_A = 0;

//backward Once....
$repairBKTotalCrTaken = 0;
$repairBKTotalCrPassed = 0;
$BKGPointer = 0;
$repairBKTotalCGPA = 0;

$repairCA_BK = 0;
$repairEXAM_BK = 0;
$repairTOTAL_BK = 0;
$repairGRADE_BK = "";
$repairUNIT_BK = 0;

<?php
$userdept = $_SESSION['deptcode'];
$userid = $_SESSION["staffid"];
$usernames = $_SESSION['names'];
$useremail = $_SESSION['email'];
$deptname = $_SESSION['deptname'];
//$cat = $_SESSION['cat'];
$corntsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
                                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                            if ($conn->connect_error) {
                                                                die("Connection failed: " . $conn->connect_error);
                                                            }

                                                            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                                            if ($conn2->connect_error) {
                                                                die("Connection failed: " . $conn2->connect_error);
                                                            }

$getDE = "NO";
$siwesstatus = $_SESSION["siwesstatus"];
$deptoption = $_SESSION['deptoption'];

$Is500L = "NO";

$getdept = $_SESSION['dept_sctny'];
$schcode = $_SESSION['schcode'];

$sql = "SELECT * FROM deptcoding WHERE DeptCode = '$getdept'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $isdeptoption = $row["deptoption"];
        $iscurriculum = $row["curriculum"];
    }
}

$sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $_SESSION["HOD_Sign"] = $row["full_name"];
    }
}

$sql = "SELECT * FROM users WHERE SchCode = '$schcode' AND (cat = 'Dean' OR cat = 'HODDean' OR cat = 'PGExam')";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $_SESSION["Dean_Sign"] = $row["full_name"];
    }
}

$sql = "SELECT * FROM std_data_view WHERE matric_no = '$matno'";
$result = $conn2->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $fulname = $row['first_name'] . " " . $row['other_name'] . " " . $row['surname'];
        $prog = "XXX";
        $permaddres = $row['p_address'];
        $stdid = $row['stdid'];
        if (isset($_POST["view_in_sess"])) {
            $yeargrad = 0;
        } else {
            $yeargrad = $_SESSION['getyeargrad'];
        }

        if ($_SESSION['InstType'] == "Polytechnic") {
            $modeofentry = $row['modeofentry'];
            if ($modeofentry == "ND") {
                $prog = "National Diploma";
            } elseif ($modeofentry == "HND") {
                $prog = "Higher National Diploma";
            }
        }

        $deptname = $_SESSION['deptname'];
        $dept = strtolower($row['dept_code']);
        $entry_session = $row['entry_session'];
        $entry_level = $row['entry_level'];

        $school = $_SESSION['schname'];
        $stateorigin = $row['state'];
        $stu_curriculum = strtolower($row['curriculum']);
        $Stu_Dept_Opt = $row["Dept_Option"];
        $YAddmitted = substr($entry_session, 0, 4);
        if ($entry_level == 200) {
            $getDE = "DE200";
        } elseif ($entry_level == 300) {
            $getDE = "DE300";
        } elseif ($entry_level == 100) {
        }

        //$PlaceBirth = $row['PlaceBirth'];

        $lga = $row['lga'];
        $sex1 = $row['gender'];

        //$withddate = $row['WidDate'];
        $national = $row['nationality'];
        $dob = $row['dob'];

        $name_first = $row['first_name'];
        $name_last = $row['surname'];
        if (empty($row['other_name'])) {
            $name_middle = "";
        } else {
            $name_middle = $row['other_name'];
        }

        $sql2 = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
        $result2 = $conn->query($sql2);

        if ($result2->num_rows > 0) {
            while ($row2 = $result2->fetch_assoc()) {
                $prog_no_years = $row2["prog_no_years"];
            }
        }
    }
}

$sql = "SELECT * FROM std_login WHERE stdid = '$stdid'";
$result = $conn2->query($sql);
if ($result->num_rows > 0) {
    $passportid = $stdid;
} else {
    $passportid = $regid;
}

unset($unitarry);
unset($gparry);
unset($gpaarry);
unset($cgpaarry);
unset($totcpass);
unset($tct);
unset($tcp);
unset($getfivelevel);
unset($getfourlevel);
unset($sessionarry);
unset($LevelArray);

unset($totunit);
unset($totgp);
unset($countSesRes);

unset($ccode_tot);
unset($ctitle_tot);
unset($cunit_tot);
unset($grade_tot);
unset($gpoint_tot);

unset($LevelCGPA);
unset($absent1ST);
unset($absent2ND);

$Lev_totunit = 0;
$Lev_totgp = 0;
$maxSession = "";
$NotRelevant = false;
$SessionCount = 0;

$yearadmt = substr($entry_session, 0, 4);
if ($entry_level == 200) {
    $yearadmt = $yearadmt - 1;
} elseif ($entry_level == 300) {
    $yearadmt = $yearadmt - 2;
}

$deptdb = $_SESSION['deptdb'];
$dept_db = $deptdb . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}
for ($x = 0; $x <= 11; $x++) {
    //$countOneLev=$countTwoLev=$countThreLev=$countFivLev=$countFourLev=0;
    $maxLevel = 0;
    $nextyr = $yearadmt + 1;
    $sessionarry[$x] = $yearadmt . "/" . $nextyr;

    $StuCurSess = str_ireplace("/", "_", $sessionarry[$x]);
    $yearadmt++;


    $gtotgp = 0;
    $stcp = 0;
    $LevelCGPA2 = 0;
    $countSesRes[$x] = 0;
    $absent1ST[$x] = 0;
    $absent2ND[$x] = 0;
    $countOneLev = $countTwoLev = $countThreLev = $countFivLev = $countFourLev = $getlevel = 0;


    if ($stu_curriculum == "old") {
        $stu_curriculum2 = "";
    } else {
        $stu_curriculum2 = "_" . $stu_curriculum;
    }

    if ($sessionarry[$x] < "2014/2015") {
        $deptcorreg = "correg";
    } else {
        $deptcorreg = "correg_" . $StuCurSess;
    }



    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
    $result = $conn_stu->query($sql);
    $totunit = $totgp = $cgpa = $gtotgp = $gtotunit = 0;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            $ccode = $row['CCode'];
            $ctitle = $row['CTitle'];
            $cunit = $row['CUnit'];


            if ($deptoption == "YES") {

                $sql3 = "SELECT * FROM gencourses" . $stu_curriculum2 . " WHERE C_codding  = '$ccode' AND " . $Stu_Dept_Opt . " = 'YES'";
                $result3 = $conn_stu->query($sql3);
                $Add3 = 0;
                if ($result3->num_rows > 0) {
                    while ($row3 = $result3->fetch_assoc()) {
                        $Add3++;
                    }
                }
            } else {

                $sql3 = "SELECT * FROM gencourses" . $stu_curriculum2 . " WHERE C_codding  = '$ccode' AND Relevant = 'YES'";
                $result3 = $conn_stu->query($sql3);
                $Add3 = 0;
                if ($result3->num_rows > 0) {
                    while ($row3 = $result3->fetch_assoc()) {
                        $Add3++;
                    }
                }
            }


            if ($row['SemTaken'] == "1ST") {
                $absent1ST[$x]++;
            } elseif ($row['SemTaken'] == "2ND") {
                $absent2ND[$x]++;
            }
            if ((int)substr($ccode, 3, 1) == 5) {
                $countFivLev++;
            } elseif ((int)substr($ccode, 3, 1) == 4) {
                $countFourLev++;
            } elseif ((int)substr($ccode, 3, 1) == 3) {
                $countThreLev++;
            } elseif ((int)substr($ccode, 3, 1) == 2) {
                $countTwoLev++;
            } elseif ((int)substr($ccode, 3, 1) == 1) {
                $countOneLev++;
            }

            $gpoint = $row["point"];
            $grade = $row["grade"];


            if ($grade == "F") {

                if ($Add3 == 0) {
                    $NotRelevant = true;
                    $ccode = "*" . $ccode;
                }
            } else {
                $stcp = $stcp + $cunit;
            }

            $CA = $row["CA"];
            $Exam = $row["Exam"];

            $total = $CA + $Exam;



            $totunit = $totunit + $cunit;
            $totgp = $totgp + $gpoint;

            $ccode_tot[$x][$countSesRes[$x]] = $ccode;
            $ctitle_tot[$x][$countSesRes[$x]] = $ctitle;
            $cunit_tot[$x][$countSesRes[$x]] = $cunit;
            $grade_tot[$x][$countSesRes[$x]] = $grade;
            $gpoint_tot[$x][$countSesRes[$x]] = $gpoint;

            $countSesRes[$x]++;
        }
    }
    $SessionCount = $x;
    $maxLevel = max($countOneLev, $countTwoLev, $countThreLev, $countFourLev, $countFivLev);
    if ($countOneLev == $maxLevel) {
        $LevelArray[$x] = 100;
    } elseif ($countTwoLev == $maxLevel) {
        $LevelArray[$x] = 200;
    } elseif ($countThreLev == $maxLevel) {
        $LevelArray[$x] = 300;
    } elseif ($countFourLev == $maxLevel) {
        $LevelArray[$x] = 400;
    } elseif ($countFivLev == $maxLevel) {
        $LevelArray[$x] = 500;
        //$Is500L="YES";
    }

    $unitarry[$x] = $totunit;
    $gparry[$x] = $totgp;
    $tgp[$x] = $totgp;
    $tct[$x] = $totunit;
    $tcp[$x] = $stcp;
    $totcpass[$x] = $stcp;

    $Lev_totunit = $Lev_totunit + $totunit;
    $Lev_totgp = $Lev_totgp + $totgp;

    if ($unitarry[$x] == 0) {
        $cgpa = 0;
        $gpaarry[$x] = 0;
        //$cgpaarry[$x]=0;
    } else {
        $cgpa = $gparry[$x] / $unitarry[$x];
        if ($totunit !== 0) {
            $gpaarry[$x] = $totgp / $totunit;
        }
        //$cgpaarry[$x]=$gparry[$x]/$unitarry[$x];
    }

    if ($Lev_totunit == 0) {
        $LevelCGPA[$x] = 0;
    } else {
        $LevelCGPA[$x] = $Lev_totgp / $Lev_totunit;
    }
    if (!isset($_POST["view_in_sess"])) {
        if ($nextyr >= $yeargrad) {
            $maxSession = $sessionarry[$x];
            $getMaxSess = $sessionarry[$x];
            break;
        }
    } else {
        if ($sessionarry[$x] == $getMaxSess) {
            break;
        }
    }
}
$conn_stu->close();

$classdegree = "";
$getdept = $_SESSION['dept_sctny'];

$getyeargrad = $_SESSION['getyeargrad'];
$getsemester = $_SESSION['semesterSel'];
//$dept_scrutiny_senate = $getdept . "_scrutiny_senate";


$dept_db = $_SESSION['deptdb'] . strtolower($getdept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND yearGrad = '$getyeargrad' AND semester = '$getsemester'";
$result = $conn_stu->query($sql);
$totunit1 = $totgp1 = $cgpa1 = $gtotgp1 = $gtotunit1 = $stcp1 = 0;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($getsemester == "1ST") {
            $ccgpa = $row['CGPA_grad_1st'];
        } else {
            $ccgpa = $row['CGPA'];
        }
        $totunit1 = $row['TCT'];
        $stcp1 = $row['TCP'];
        $totgp1 = $row['CGP'];
    }
}

$conn->close();
$conn2->close();
$conn_stu->close();



include 'modulesInSess/classofdegree_inc.php';
?>

<div id="printableArea<?php echo $no ?>" style="width: auto; height: 650px; overflow: auto">
    <?php include 'all_grad_inc.php' ?>
</div>
<div class="row" style="text-align: right">
    <br>
    <input type="button" onclick="printDiv('printableArea<?php echo $no ?>')" value="print to PDF"
        class="btn-success" />
</div>
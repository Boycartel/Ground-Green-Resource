<style>
table,
th,
td {
    /*border: 1px solid black;*/
    border-collapse: collapse;
    font-size: 11px;
}
</style>
<table style="width: 99%">
    <tbody>
        <tr>
            <td>

                <table style="width: 100%">
                    <tbody>
                        <tr>
                            <td style="width: 10%">
                                <img src="img/logo.ico" height="70" alt="FUTMinna" />
                            </td>
                            <td style="width: 80%">
                                <h6 style="text-align: center; font-size: 14px"><strong>
                                        <?php echo $_SESSION['instname'] ?><br>
                                        <?php echo $_SESSION['sch_faculty'] ?> OF
                                        <?php echo strtoupper($school) ?><br>
                                        DEPARTMENT OF <?php echo strtoupper($deptname) ?><br>
                                        <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                        <?php echo strtoupper($prog) ?><br>
                                        <?php } ?>
                                        EXAMINATION RESULTS - OVERALL ASSESSMENT<br>
                                    </strong></h6>
                            </td>
                            <td>
                                <figure class="profile-picture">
                                    <?php

                                    $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                    $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                    echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='70' height='70'>";

                                    ?>
                                </figure>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table style="font-size:12px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                    <tbody style="color: #0a0a0a">
                        <tr>
                            <th style="text-align: left;width: 10%">SURNAME :</th>
                            <td style="width: 30%; text-align: left; padding-left: 1em"><?php echo $name_first ?>
                            </td>
                            <th style="padding-left: 1em;width: 12%; text-align: left">OTHER NAME(S) :</th>
                            <td style="padding-left: 1em;width: 18%"><?php echo $name_middle . " " . $name_last ?>
                            </td>
                            <th style="padding-left: 1em;width: 18%; text-align: left">MATRICULATION NUMBER :</th>
                            <td style="padding-left: 1em"><?php echo $matno ?></td>
                        </tr>
                        <tr>
                            <th style="text-align: left">STATE OF ORIGIN :</th>
                            <td style="padding-left: 1em; text-align: left"><?php echo $stateorigin ?></td>
                            <th style="padding-left: 1em; text-align: left">LOCAL GOVT. AREA :</th>
                            <td style="padding-left: 1em"><?php echo $lga ?></td>
                            <th style="padding-left: 1em; text-align: left">SEX :</th>
                            <td style="padding-left: 1em"><?php echo $sex1 ?></td>
                        </tr>
                        <tr>
                            <th style="vertical-align: top;text-align: left">ADDRESS :</th>
                            <td style="padding-left: 1em; text-align: left"><?php echo $permaddres ?></td>
                            <th style="padding-left: 1em; text-align: left">DATE OF BIRTH :</th>
                            <td style="padding-left: 1em"><?php echo $dob ?></td>
                            <th style="padding-left: 1em; text-align: left">YEAR OF MATRICULATION:</th>
                            <td style="padding-left: 1em"><?php echo $YAddmitted ?></td>
                        </tr>
                        <tr>
                            <th style="vertical-align: top;text-align: left">PROGRAMME:</th>
                            <td style="padding-left: 1em; text-align: left"><?php echo $prog ?></td>
                            <th style="padding-left: 1em; text-align: left">PLACE OF BIRTH :</th>
                            <td style="padding-left: 1em"><?php //echo $PlaceBirth 
                                                            ?></td>
                            <th style="padding-left: 1em; text-align: left">YEAR OF GRADUATION :</th>
                            <td style="padding-left: 1em"><?php echo $yeargrad ?></td>
                        </tr>
                    </tbody>
                </table>

                <table style="color: #0a0a0a; width: 100%; font-size: 9px">
                    <tbody>

                        <tr>
                            <th style="border-style:solid; border-width:thin; text-align:center">
                                <?php echo $sessionarry[0] . " " . $LevelArray[0] . "  Level" ?></th>
                            <th style="border-style:solid; border-width:thin; text-align:center"><?php if ($SessionCount >= 1) {
                                                                                                        echo $sessionarry[1] . " " . $LevelArray[1] . "  Level";
                                                                                                    } ?></th>
                            <th style="border-style:solid; border-width:thin; text-align:center"><?php if ($SessionCount >= 2) {
                                                                                                        echo $sessionarry[2] . " " . $LevelArray[2] . "  Level";
                                                                                                    } ?></th>
                        </tr>
                        <tr>
                            <td style="border-style:solid; border-width:thin; width: 33%" valign="top">

                                <?php

                                echo "<table style='font-size:13px; width: 100%'>";
                                echo "<thead style='text-align:center;'>";
                                echo "<tr>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";

                                $arrayNumb = 0;
                                if ($absent1ST[0] != 0 && $absent2ND[0] != 0) {
                                    include 'modulesInSess/calSemResult_Grad.php';
                                } elseif ($absent1ST[0] == 0 && $absent2ND[0] != 0) {
                                    $indSession = $sessionarry[0];
                                    include 'modulesInSess/missing_ses.php';
                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                    include 'modulesInSess/calSemResult_Grad.php';
                                } elseif ($absent1ST[0] != 0 && $absent2ND[0] == 0) {
                                    include 'modulesInSess/calSemResult_Grad.php';
                                    if ($sessionarry[0] != $getMaxSess) {
                                        $indSession = $sessionarry[0];
                                        include 'modulesInSess/missing_ses.php';
                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                    }
                                } elseif ($absent1ST[0] == 0 && $absent2ND[0] == 0) {
                                    if ($getDE == "DE200" || $getDE == "DE300") {
                                        $response_full = "DE";
                                    } else {
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
                                        $Issess0 = false;
                                        $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[0]'";
                                        $result4 = $conn->query($sql4);
                                        if ($result4->num_rows > 0) {
                                            $response_full = "Cancel Session";
                                            $Issess0 = true;
                                        }
                                        $conn->close();
                                        if ($Issess0 == false) {
                                            $indSession = $sessionarry[0];
                                            include 'modulesInSess/missing_ses.php';
                                        }
                                    }
                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                }



                                if ($tct[0] != 0) {
                                    echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[0]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[0]</th></tr>";
                                }

                                echo "</tbody>";
                                echo "</table>";


                                ?>

                            </td>
                            <td style="border-style:solid; border-width:thin; width: 33%" valign="top">
                                <?php
                                //$session1 = $sessionarry[1];
                                //include 'includes/semresults.php';
                                echo "<table style='font-size:13px; width: 100%'>";
                                echo "<thead style='text-align:center;'>";
                                echo "<tr>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";

                                $arrayNumb = 1;
                                if ($SessionCount >= 1) {
                                    if ($absent1ST[1] != 0 && $absent2ND[1] != 0) {
                                        include 'modulesInSess/calSemResult_Grad.php';
                                    } elseif ($absent1ST[1] == 0 && $absent2ND[1] != 0) {
                                        $indSession = $sessionarry[1];
                                        include 'modulesInSess/missing_ses.php';
                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";

                                        include 'modulesInSess/calSemResult_Grad.php';
                                    } elseif ($absent1ST[1] != 0 && $absent2ND[1] == 0) {
                                        include 'modulesInSess/calSemResult_Grad.php';
                                        if ($sessionarry[1] != $getMaxSess) {
                                            $indSession = $sessionarry[1];
                                            include 'modulesInSess/missing_ses.php';
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }
                                    } elseif ($absent1ST[1] == 0 && $absent2ND[1] == 0) {
                                        if ($getDE == "DE300") {
                                            $response_full = "DE";
                                        } else {
                                           
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }
                                            $Issess1 = false;
                                            $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[1]'";
                                            $result4 = $conn->query($sql4);
                                            if ($result4->num_rows > 0) {
                                                $response_full = "Cancel Session";
                                                $Issess1 = true;
                                            }
                                            $conn->close();
                                            if ($Issess1 == false) {
                                                $indSession = $sessionarry[1];
                                                include 'modulesInSess/missing_ses.php';
                                            }
                                        }
                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                    }


                                    if ($tct[1] != 0) {
                                        echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[1]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[1]</th></tr>";
                                    }
                                }
                                echo "</tbody>";
                                echo "</table>";

                                /*if($getDE=="DE300"){
                                echo "<br><br><br><h1 style='text-align: center'><strong>DE</strong></h1>";
                            }*/
                                ?>

                            </td>
                            <td style="border-style:solid; border-width:thin" valign="top">
                                <?php

                                echo "<table style='font-size:13px; width: 100%'>";
                                echo "<thead style='text-align:center;'>";
                                echo "<tr>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";

                                $arrayNumb = 2;
                                if ($SessionCount >= 2) {
                                    if ($absent1ST[2] != 0 && $absent2ND[2] != 0) {
                                        include 'modulesInSess/calSemResult_Grad.php';
                                    } elseif ($absent1ST[2] == 0 && $absent2ND[2] != 0) {
                                        $indSession = $sessionarry[2];
                                        include 'modulesInSess/missing_ses.php';
                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";

                                        include 'modulesInSess/calSemResult_Grad.php';
                                    } elseif ($absent1ST[2] != 0 && $absent2ND[2] == 0) {
                                        include 'modulesInSess/calSemResult_Grad.php';
                                        if ($sessionarry[2] != $getMaxSess) {
                                            $indSession = $sessionarry[2];
                                            include 'modulesInSess/missing_ses.php';
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }
                                    } elseif ($absent1ST[2] == 0 && $absent2ND[2] == 0) {
                                        
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
                                        $Issess2 = false;
                                        $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[2]'";
                                        $result4 = $conn->query($sql4);
                                        if ($result4->num_rows > 0) {
                                            $response_full = "Cancel Session";
                                            $Issess2 = true;
                                        }
                                        $conn->close();
                                        if ($Issess2 == false) {
                                            $indSession = $sessionarry[2];
                                            include 'modulesInSess/missing_ses.php';
                                        }
                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                    }


                                    if ($tct[2] != 0) {
                                        echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[2]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[2]</th></tr>";
                                    }
                                }
                                echo "</tbody>";
                                echo "</table>";
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($tct[0] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[0] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[0] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[0] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[0] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[0], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[0], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($SessionCount >= 1) { ?>
                                <?php if ($tct[1] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[1] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[1] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[1] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[1] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[1], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[1], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($SessionCount >= 2) { ?>
                                <?php if ($tct[2] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[2] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[2] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[2] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[2] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[2], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[2], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                        </tr>

                    </tbody>
                </table>
                <table style="width: 100%; font-size: 10px">
                    <tbody>
                        <tr>
                            <td style="width: 40%; text-align: left">.</td>
                            <th style="width: 25%; font-size: 12px"><?php if ($NotRelevant == true) {
                                                                        echo "* Courses NOT Relevant to the Department";
                                                                    } ?></th>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="width: 40%; text-align: left"><?php echo $_SESSION["HOD_Sign"] ?></td>
                            <td style="width: 25%"></td>
                            <td style="text-align: left"><?php echo $_SESSION["Dean_Sign"] ?></td>
                        </tr>
                        <tr>
                            <td style="text-align: left">HOD's SIGNATURE AND DATE</td>
                            <td></td>
                            <td style="text-align: left">DEAN's SIGNATURE AND DATE</td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>

<?php if ($SessionCount >= 3) { ?>
<table style="width: 99%">
    <tbody>
        <tr>
            <td>
                <table style="width: 100%">
                    <tbody>
                        <tr>
                            <td style="width: 10%">
                                <img src="img/logo.ico" height="70" alt="Logo" />
                            </td>
                            <td style="width: 80%">
                                <h6 style="text-align: center; font-size: 14px"><strong>
                                        <?php echo $_SESSION['instname'] ?><br>
                                        <?php echo $_SESSION['sch_faculty'] ?> OF
                                        <?php echo strtoupper($school) ?><br>
                                        DEPARTMENT OF <?php echo strtoupper($deptname) ?><br>
                                        <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                        <?php echo strtoupper($prog) ?><br>
                                        <?php } ?>
                                        EXAMINATION RESULTS - OVERALL ASSESSMENT<br>
                                    </strong></h6>
                            </td>
                            <td>
                                <figure class="profile-picture">
                                    <?php
                                        $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                        $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                        echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='70' height='70'>";

                                        ?>
                                </figure>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table style="font-size:9px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                    <tbody style="color: #0a0a0a">
                        <tr>
                            <th style="text-align: left;width: 10%">SURNAME :</th>
                            <td style="width: 30%; text-align: left; padding-left: 1em"><?php echo $name_first ?>
                            </td>
                            <th style="padding-left: 1em;width: 12%; text-align: left">OTHER NAME(S) :</th>
                            <td style="padding-left: 1em;width: 18%"><?php echo $name_middle . " " . $name_last ?>
                            </td>
                            <th style="padding-left: 1em;width: 18%; text-align: left">MATRICULATION NUMBER :</th>
                            <td style="padding-left: 1em"><?php echo $matno ?></td>
                        </tr>
                        <!--<tr><th style="text-align: left">STATE OF ORIGIN :</th><td style="padding-left: 1em; text-align: left"><?php /*echo $stateorigin */ ?></td><th style="padding-left: 1em; text-align: left">LOCAL GOVT. AREA :</th><td style="padding-left: 1em"><?php /*echo $lga */ ?></td><th style="padding-left: 1em; text-align: left">SEX :</th><td style="padding-left: 1em"><?php /*echo $sex1 */ ?></td></tr>
                    <tr><th style="vertical-align: top;text-align: left">ADDRESS :</th><td style="padding-left: 1em; text-align: left"><?php /*echo $permaddres */ ?></td><th style="padding-left: 1em; text-align: left">DATE OF BIRTH :</th><td style="padding-left: 1em"><?php /*echo $dob */ ?></td><th style="padding-left: 1em; text-align: left">YEAR OF MATRICULATION:</th><td style="padding-left: 1em"><?php /*echo $YAddmitted */ ?></td></tr>
                    <tr><th style="vertical-align: top;text-align: left">PROGRAMME:</th><td style="padding-left: 1em; text-align: left"><?php /*echo $prog */ ?></td><th style="padding-left: 1em; text-align: left">PLACE OF BIRTH :</th><td style="padding-left: 1em"><?php /*echo $PlaceBirth */ ?></td><th style="padding-left: 1em; text-align: left">YEAR OF GRADUATION :</th><td style="padding-left: 1em"><?php /*echo $yeargrad */ ?></td></tr>-->
                    </tbody>
                </table>

                <table style="color: #0a0a0a; width: 100%; font-size: 10px">
                    <tbody>

                        <tr>
                            <th style="border-style:solid; border-width:thin; text-align:center">
                                <?php echo $sessionarry[3] . " " . $LevelArray[3] . "  Level" ?></th>
                            <th style="border-style:solid; border-width:thin; text-align:center">
                                <?php echo $sessionarry[4] . " " . $LevelArray[4] . "  Level" ?></th>
                            <th style="border-style:solid; border-width:thin; text-align:center"><?php if ($SessionCount >= 5) {
                                                                                                            echo $sessionarry[5] . " " . $LevelArray[5] . "  Level";
                                                                                                        } ?> </th>
                        </tr>
                        <tr>
                            <td style="border-style:solid; border-width:thin; width: 33%" valign="top">

                                <?php

                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    $arrayNumb = 3;
                                    if ($SessionCount >= 3) {
                                        if ($absent1ST[3] != 0 && $absent2ND[3] != 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[3] == 0 && $absent2ND[3] != 0) {
                                            if ($siwesstatus == "Part") {
                                                if ($LevelArray[3] != 300) {
                                                    $indSession = $sessionarry[3];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                }
                                            }

                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[3] != 0 && $absent2ND[3] == 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                            if ($sessionarry[3] != $getMaxSess) {
                                                if ($LevelArray[3] != 300) {
                                                    $indSession = $sessionarry[3];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                }
                                            }
                                        } elseif ($absent1ST[3] == 0 && $absent2ND[3] == 0) {
                                            
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }
                                            $Issess3 = false;
                                            $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[3]'";
                                            $result4 = $conn->query($sql4);
                                            if ($result4->num_rows > 0) {
                                                $response_full = "Cancel Session";
                                                $Issess3 = true;
                                            }
                                            $conn->close();
                                            if ($Issess3 == false) {
                                                $indSession = $sessionarry[3];
                                                include 'modulesInSess/missing_ses.php';
                                            }
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }


                                        if ($tct[3] != 0) {
                                            echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[3]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[3]</th></tr>";
                                        }
                                    }

                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>

                            </td>
                            <td style="border-style:solid; border-width:thin; width: 33%" valign="top">
                                <?php
                                    //$session1 = $sessionarry[1];
                                    //include 'includes/semresults.php';
                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    $arrayNumb = 4;
                                    if ($SessionCount >= 4) {
                                        if ($absent1ST[4] != 0 && $absent2ND[4] != 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[4] == 0 && $absent2ND[4] != 0) {
                                            if ($LevelArray[4] < 500) {
                                                if ($LevelArray[4] == 400) {
                                                    if ($siwesstatus == "Part") {
                                                        $indSession = $sessionarry[4];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                } elseif ($LevelArray[4] == 300) {
                                                    if ($LevelArray[3] != 300) {
                                                        $indSession = $sessionarry[4];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                }
                                            } else {
                                                $indSession = $sessionarry[4];
                                                include 'modulesInSess/missing_ses.php';
                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                            }
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[4] != 0 && $absent2ND[4] == 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                            if ($sessionarry[4] != $getMaxSess) {
                                                if ($LevelArray[4] < 500) {
                                                    if ($LevelArray[4] == 300) {
                                                        if ($LevelArray[3] != 300) {
                                                            $indSession = $sessionarry[4];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    }
                                                } else {
                                                    $indSession = $sessionarry[4];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                }
                                            }
                                        } elseif ($absent1ST[4] == 0 && $absent2ND[4] == 0) {
                                            
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }
                                            $Issess4 = false;
                                            $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[4]'";
                                            $result4 = $conn->query($sql4);
                                            if ($result4->num_rows > 0) {
                                                $response_full = "Cancel Session";
                                                $Issess4 = true;
                                            }
                                            $conn->close();
                                            if ($Issess4 == false) {
                                                $indSession = $sessionarry[4];
                                                include 'modulesInSess/missing_ses.php';
                                            }
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }


                                        if ($tct[4] != 0) {
                                            echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[4]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[4]</th></tr>";
                                        }
                                    }

                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>


                            </td>
                            <td style="border-style:solid; border-width:thin" valign="top">
                                <?php
                                    //$session1 = $sessionarry[2];
                                    //include 'includes/semresults.php';
                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    $arrayNumb = 5;
                                    if ($SessionCount >= 5) {
                                        if ($absent1ST[5] != 0 && $absent2ND[5] != 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[5] == 0 && $absent2ND[5] != 0) {
                                            if ($LevelArray[4] < 500) {
                                                if ($LevelArray[4] == 400) {
                                                    $indSession = $sessionarry[5];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                } else {
                                                    if ($LevelArray[4] == 300) {
                                                        if ($LevelArray[5] == 400) {
                                                            if ($siwesstatus == "Part") {
                                                                $indSession = $sessionarry[5];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } elseif ($LevelArray[5] != 300) {
                                                            $indSession = $sessionarry[5];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } else {
                                                        $indSession = $sessionarry[5];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                }
                                            }
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[5] != 0 && $absent2ND[5] == 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                            if ($sessionarry[5] != $getMaxSess) {
                                                if ($LevelArray[4] < 500) {
                                                    if ($LevelArray[4] == 400) {
                                                        $indSession = $sessionarry[5];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    } else {
                                                        if ($LevelArray[4] == 300) {
                                                            if ($LevelArray[5] != 400) {
                                                                $indSession = $sessionarry[5];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } else {
                                                            $indSession = $sessionarry[5];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    }
                                                }
                                            }
                                        } elseif ($absent1ST[5] == 0 && $absent2ND[5] == 0) {
                                           
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }
                                            $Issess5 = false;
                                            $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[5]'";
                                            $result4 = $conn->query($sql4);
                                            if ($result4->num_rows > 0) {
                                                $response_full = "Cancel Session";
                                                $Issess5 = true;
                                            }
                                            $conn->close();
                                            if ($Issess5 == false) {
                                                $indSession = $sessionarry[5];
                                                include 'modulesInSess/missing_ses.php';
                                            }
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }


                                        if ($tct[5] != 0) {
                                            echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[5]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[5]</th></tr>";
                                        }
                                    }
                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($SessionCount >= 3) { ?>
                                <?php if ($tct[3] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[3] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[3] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[3] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[3] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[3], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[3], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($SessionCount >= 4) { ?>
                                <?php if ($tct[4] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[4] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[4] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[4] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[4] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[4], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[4], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($SessionCount >= 5) { ?>
                                <?php if ($tct[5] != 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[5] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[5] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[5] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[5] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[5], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[5], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                        </tr>

                        <?php if ($arrayNumb <= 5) { ?>
                        <tr>
                            <td style="border-style:solid; border-width:thin">
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr style="border: 1px solid #ddd">
                                            <th style="text-align: center">SUMMARY</th>
                                        </tr>

                                        <?php
                                                $deptdb = $_SESSION['deptdb'];
                                                $dept_db = $deptdb . $dept;
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }
                                                $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $gettitle = $row['title1'];
                                                        if ($gettitle == "XXXX") {
                                                            echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'> .</td></tr>";
                                                        } else {
                                                            echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'>$gettitle</td></tr>";
                                                        }
                                                    }
                                                }
$conn_stu->close();
                                                ?>
                                        <tr style='border: 1px solid #ddd'>
                                            <td style='padding-left: 1em; text-align: left'>SWEP</td>
                                        </tr>
                                        <tr style='border: 1px solid #ddd'>
                                            <th style='padding-left: 1em; text-align: left'>Total:-</th>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <th style="text-align: center">REQUIRED</th>
                                            <th style="text-align: center">EARNED</th>
                                            <th style="text-align: center">DEF</th>
                                        </tr>

                                        <?php
                                                $totReq = $totearn = $totdif = 0;
                                                $deptdb = $_SESSION['deptdb'];
                                                $dept_db = $deptdb . $dept;
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }
                                                $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $require1 = $row['require1'];
                                                        $earned = $row['earned'];
                                                        $totReq = $totReq + $require1;
                                                        $totearn = $totearn + $earned;
                                                        $dif = $require1 - $earned;
                                                        if ($dif <= 0) {
                                                            $dif = 0;
                                                        }
                                                        $totdif = $totdif + $dif;
                                                        echo "<tr style='border: 1px solid #ddd; text-align: center'><td>$require1</td><td>$earned</td><td>$dif</td></tr>";
                                                    }
                                                }
                                                $conn_stu->close();

                                                $totReq = $totReq + 2;
                                                $totearn = $totearn + 2;

                                                ?>
                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                        </tr>
                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                            <th style="text-align: center"><?php echo $totReq ?></th>
                                            <th style="text-align: center"><?php echo $totearn ?></th>
                                            <th style="text-align: center"><?php echo $totdif ?></th>
                                        </tr>

                                    </tbody>
                                </table>
                            </td>
                            <td style="border-style:solid; border-width:thin">

                                <table style="width: 100%; font-size: 10px">
                                    <tbody>

                                        <tr>
                                            <td>.</td>
                                            <td>.</td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TCT for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $totunit1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TCP for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $stcp1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TGP for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $totgp1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                CGPA:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo number_format((float)$ccgpa, 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                Class of Degree :- </th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $classdegree ?> </td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                Remark :- </th>
                                            <td style="border-bottom-style: solid; border-width:thin">PASSED</td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                * A satisfactory completion of the scheme is all that is required to
                                                qualify the candidate for graduation</th>
                                            <td style="border-bottom-style: solid; border-width:thin"></td>
                                        </tr>


                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <table style="width: 100%; font-size: 10px">
                    <tbody>
                        <tr>
                            <td style="width: 40%; text-align: left">.</td>
                            <th style="width: 25%; font-size: 12px"><?php if ($NotRelevant == true) {
                                                                            echo "* Courses NOT Relevant to the Department";
                                                                        } ?></th>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="width: 40%; text-align: left"><?php echo $_SESSION["HOD_Sign"] ?></td>
                            <td style="width: 25%"></td>
                            <td style="text-align: left"><?php echo $_SESSION["Dean_Sign"] ?></td>
                        </tr>
                        <tr>
                            <td style="text-align: left">HOD's SIGNATURE AND DATE</td>
                            <td></td>
                            <td style="text-align: left">DEAN's SIGNATURE AND DATE</td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>

<?php } ?>


<?php if ($SessionCount >= 6) { ?>
<table style="width: 99%">
    <tbody>
        <tr>
            <td>
                <table style="width: 100%">
                    <tbody>
                        <tr>
                            <td style="width: 10%">
                                <img src="img/logo.ico" height="70" alt="Logo" />
                            </td>
                            <td style="width: 80%">
                                <h6 style="text-align: center; font-size: 14px"><strong>
                                        <?php echo $_SESSION['instname'] ?><br>
                                        <?php echo $_SESSION['sch_faculty'] ?> OF
                                        <?php echo strtoupper($school) ?><br>
                                        DEPARTMENT OF <?php echo strtoupper($deptname) ?><br>
                                        <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                        <?php echo strtoupper($prog) ?><br>
                                        <?php } ?>
                                        EXAMINATION RESULTS - OVERALL ASSESSMENT<br>
                                    </strong></h6>
                            </td>
                            <td>
                                <figure class="profile-picture">
                                    <?php
                                        $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                        $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                        echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='70' height='70'>";

                                        ?>
                                </figure>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table style="font-size:9px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                    <tbody style="color: #0a0a0a">
                        <tr>
                            <th style="text-align: left;width: 10%">SURNAME :</th>
                            <td style="width: 30%; text-align: left; padding-left: 1em"><?php echo $name_first ?>
                            </td>
                            <th style="padding-left: 1em;width: 12%; text-align: left">OTHER NAME(S) :</th>
                            <td style="padding-left: 1em;width: 18%"><?php echo $name_middle . " " . $name_last ?>
                            </td>
                            <th style="padding-left: 1em;width: 18%; text-align: left">MATRICULATION NUMBER :</th>
                            <td style="padding-left: 1em"><?php echo $matno ?></td>
                        </tr>
                    </tbody>
                </table>

                <table style="color: #0a0a0a; width: 100%; font-size: 10px">
                    <tbody>

                        <tr>
                            <th style="border-style:solid; border-width:thin; text-align:center">
                                <?php echo $sessionarry[6] . " " . $LevelArray[6] . "  Level" ?></th>
                            <th style="border-style:solid; border-width:thin; text-align:center"><?php if ($SessionCount >= 7) {
                                                                                                            echo $sessionarry[7] . " " . $LevelArray[7] . "  Level";
                                                                                                        } ?></th>
                            <th style="border-style:solid; border-width:thin; text-align:center"><?php if ($SessionCount >= 8) {
                                                                                                            echo $sessionarry[8] . " " . $LevelArray[8] . "  Level";
                                                                                                        } ?> </th>
                        </tr>
                        <tr>
                            <td style="border-style:solid; border-width:thin; width: 33%" valign="top">

                                <?php

                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    $arrayNumb = 6;
                                    if ($absent1ST[6] != 0 && $absent2ND[6] != 0) {
                                        include 'modulesInSess/calSemResult_Grad.php';
                                    } elseif ($absent1ST[6] == 0 && $absent2ND[6] != 0) {
                                        if ($LevelArray[5] < 500) {
                                            if ($LevelArray[5] == 400) {
                                                $indSession = $sessionarry[6];
                                                include 'modulesInSess/missing_ses.php';
                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                            } else {
                                                if ($LevelArray[5] == 300) {
                                                    if ($LevelArray[6] == 400) {
                                                        if ($siwesstatus == "Part") {
                                                            $indSession = $sessionarry[6];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } elseif ($LevelArray[6] != 300) {
                                                        $indSession = $sessionarry[6];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                } else {
                                                    $indSession = $sessionarry[6];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                }
                                            }
                                        }
                                        include 'modulesInSess/calSemResult_Grad.php';
                                    } elseif ($absent1ST[6] != 0 && $absent2ND[6] == 0) {
                                        include 'modulesInSess/calSemResult_Grad.php';
                                        if ($sessionarry[6] != $getMaxSess) {
                                            if ($LevelArray[5] < 500) {
                                                if ($LevelArray[5] == 400) {
                                                    $indSession = $sessionarry[6];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                } else {
                                                    if ($LevelArray[5] == 300) {
                                                        if ($LevelArray[6] != 400) {
                                                            $indSession = $sessionarry[6];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } else {
                                                        $indSession = $sessionarry[6];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                }
                                            }
                                        }
                                    } elseif ($absent1ST[6] == 0 && $absent2ND[6] == 0) {
                                        
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
                                        $Issess6 = false;
                                        $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[6]'";
                                        $result4 = $conn->query($sql4);
                                        if ($result4->num_rows > 0) {
                                            $response_full = "Cancel Session";
                                            $Issess6 = true;
                                        }
                                        $conn->close();
                                        if ($Issess6 == false) {
                                            $indSession = $sessionarry[6];
                                            include 'modulesInSess/missing_ses.php';
                                        }
                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                    }


                                    if ($tct[6] != 0) {
                                        echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[6]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[6]</th></tr>";
                                    }


                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>

                            </td>
                            <td style="border-style:solid; border-width:thin; width: 33%" valign="top">
                                <?php
                                    //$session1 = $sessionarry[1];
                                    //include 'includes/semresults.php';
                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    if ($SessionCount >= 7) {
                                        $arrayNumb = 7;
                                        if ($absent1ST[7] != 0 && $absent2ND[7] != 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[7] == 0 && $absent2ND[7] != 0) {
                                            if ($LevelArray[6] < 500) {
                                                if ($LevelArray[6] == 400) {
                                                    $indSession = $sessionarry[7];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                } else {
                                                    if ($LevelArray[6] == 300) {
                                                        if ($LevelArray[7] == 400) {
                                                            if ($siwesstatus == "Part") {
                                                                $indSession = $sessionarry[7];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } elseif ($LevelArray[7] != 300) {
                                                            $indSession = $sessionarry[7];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } else {
                                                        $indSession = $sessionarry[7];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                }
                                            }
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[7] != 0 && $absent2ND[7] == 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                            if ($sessionarry[7] != $getMaxSess) {
                                                if ($LevelArray[6] < 500) {
                                                    if ($LevelArray[6] == 400) {
                                                        $indSession = $sessionarry[7];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    } else {
                                                        if ($LevelArray[6] == 300) {
                                                            if ($LevelArray[7] != 400) {
                                                                $indSession = $sessionarry[7];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } else {
                                                            $indSession = $sessionarry[7];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    }
                                                }
                                            }
                                        } elseif ($absent1ST[7] == 0 && $absent2ND[7] == 0) {
                                           
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }
                                            $Issess7 = false;
                                            $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[7]'";
                                            $result4 = $conn->query($sql4);
                                            if ($result4->num_rows > 0) {
                                                $response_full = "Cancel Session";
                                                $Issess7 = true;
                                            }
                                            $conn->close();
                                            if ($Issess7 == false) {
                                                $indSession = $sessionarry[7];
                                                include 'modulesInSess/missing_ses.php';
                                            }
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }


                                        if ($tct[7] != 0) {
                                            echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[7]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[7]</th></tr>";
                                        }
                                    }


                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>


                            </td>
                            <td style="border-style:solid; border-width:thin" valign="top">
                                <?php
                                    //$session1 = $sessionarry[2];
                                    //include 'includes/semresults.php';
                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    if ($SessionCount >= 8) {
                                        $arrayNumb = 8;
                                        if ($absent1ST[8] != 0 && $absent2ND[8] != 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[8] == 0 && $absent2ND[8] != 0) {
                                            if ($LevelArray[7] < 500) {
                                                if ($LevelArray[7] == 400) {
                                                    $indSession = $sessionarry[8];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                } else {
                                                    if ($LevelArray[7] == 300) {
                                                        if ($LevelArray[8] == 400) {
                                                            if ($siwesstatus == "Part") {
                                                                $indSession = $sessionarry[8];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } elseif ($LevelArray[8] != 300) {
                                                            $indSession = $sessionarry[8];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } else {
                                                        $indSession = $sessionarry[8];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                }
                                            }
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[8] != 0 && $absent2ND[8] == 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                            if ($sessionarry[8] != $getMaxSess) {
                                                if ($LevelArray[7] < 500) {
                                                    if ($LevelArray[7] == 400) {
                                                        $indSession = $sessionarry[8];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    } else {
                                                        if ($LevelArray[7] == 300) {
                                                            if ($LevelArray[8] != 400) {
                                                                $indSession = $sessionarry[8];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } else {
                                                            $indSession = $sessionarry[8];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    }
                                                }
                                            }
                                        } elseif ($absent1ST[8] == 0 && $absent2ND[8] == 0) {
                                           
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }
                                            $Issess8 = false;
                                            $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[8]'";
                                            $result4 = $conn->query($sql4);
                                            if ($result4->num_rows > 0) {
                                                $response_full = "Cancel Session";
                                                $Issess8 = true;
                                            }
                                            $conn->close();
                                            if ($Issess8 == false) {
                                                $indSession = $sessionarry[8];
                                                include 'modulesInSess/missing_ses.php';
                                            }
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }


                                        if ($tct[8] != 0) {
                                            echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[8]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[8]</th></tr>";
                                        }
                                    }

                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($SessionCount >= 6) { ?>
                                <?php if ($tct[6] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[6] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[6] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[6] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[6] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[6], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[6], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($SessionCount >= 7) { ?>
                                <?php if ($tct[7] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[7] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[7] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[7] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[7] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[7], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[7], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($arrayNumb >= 8) { ?>
                                <?php if ($tct[8] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[8] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[8] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[8] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[8] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[8], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[8], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                        </tr>

                        <?php if ($arrayNumb <= 8) { ?>
                        <tr>
                            <td style="border-style:solid; border-width:thin">
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr style="border: 1px solid #ddd">
                                            <th style="text-align: center">SUMMARY</th>
                                        </tr>

                                        <?php
                                                $deptdb = $_SESSION['deptdb'];
                                                $dept_db = $deptdb . $dept;
                                                $conn_stu = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $gettitle = $row['title1'];
                                                        if ($gettitle == "XXXX") {
                                                            echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'> .</td></tr>";
                                                        } else {
                                                            echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'>$gettitle</td></tr>";
                                                        }
                                                    }
                                                }
$conn_stu->close();
                                                ?>
                                        <tr style='border: 1px solid #ddd'>
                                            <td style='padding-left: 1em; text-align: left'>SWEP</td>
                                        </tr>
                                        <tr style='border: 1px solid #ddd'>
                                            <th style='padding-left: 1em; text-align: left'>Total:-</th>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <th style="text-align: center">REQUIRED</th>
                                            <th style="text-align: center">EARNED</th>
                                            <th style="text-align: center">DEF</th>
                                        </tr>

                                        <?php
                                                $totReq = $totearn = $totdif = 0;
                                                $deptdb = $_SESSION['deptdb'];
                                                $dept_db = $deptdb . $dept;
                                                $conn_stu = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }
                                                $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $require1 = $row['require1'];
                                                        $earned = $row['earned'];
                                                        $totReq = $totReq + $require1;
                                                        $totearn = $totearn + $earned;
                                                        $dif = $require1 - $earned;
                                                        if ($dif <= 0) {
                                                            $dif = 0;
                                                        }
                                                        $totdif = $totdif + $dif;
                                                        echo "<tr style='border: 1px solid #ddd; text-align: center'><td>$require1</td><td>$earned</td><td>$dif</td></tr>";
                                                    }
                                                }
                                                $conn_stu->close();

                                                $totReq = $totReq + 2;
                                                $totearn = $totearn + 2;

                                                ?>
                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                        </tr>
                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                            <th style="text-align: center"><?php echo $totReq ?></th>
                                            <th style="text-align: center"><?php echo $totearn ?></th>
                                            <th style="text-align: center"><?php echo $totdif ?></th>
                                        </tr>

                                    </tbody>
                                </table>
                            </td>
                            <td style="border-style:solid; border-width:thin">

                                <table style="width: 100%; font-size: 10px">
                                    <tbody>

                                        <tr>
                                            <td>.</td>
                                            <td>.</td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TCT for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $totunit1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TCP for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $stcp1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TGP for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $totgp1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                CGPA:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo number_format((float)$ccgpa, 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                Class of Degree :- </th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $classdegree ?> </td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                Remark :- </th>
                                            <td style="border-bottom-style: solid; border-width:thin">PASSED</td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                * A satisfactory completion of the scheme is all that is required to
                                                qualify the candidate for graduation</th>
                                            <td style="border-bottom-style: solid; border-width:thin"></td>
                                        </tr>


                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <table style="width: 100%; font-size: 10px">
                    <tbody>
                        <tr>
                            <td style="width: 40%; text-align: left">.</td>
                            <th style="width: 25%; font-size: 12px"><?php if ($NotRelevant == true) {
                                                                            echo "* Courses NOT Relevant to the Department";
                                                                        } ?></th>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="width: 40%; text-align: left"><?php echo $_SESSION["HOD_Sign"] ?></td>
                            <td style="width: 25%"></td>
                            <td style="text-align: left"><?php echo $_SESSION["Dean_Sign"] ?></td>
                        </tr>
                        <tr>
                            <td style="text-align: left">HOD's SIGNATURE AND DATE</td>
                            <td></td>
                            <td style="text-align: left">DEAN's SIGNATURE AND DATE</td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
<?php } ?>
<?php if ($SessionCount >= 9) { ?>
<table style="width: 99%">
    <tbody>
        <tr>
            <td>
                <table style="width: 100%">
                    <tbody>
                        <tr>
                            <td style="width: 10%">
                                <img src="img/logo.ico" height="70" alt="Logo" />
                            </td>
                            <td style="width: 80%">
                                <h6 style="text-align: center; font-size: 14px"><strong>
                                        <?php echo $_SESSION['instname'] ?><br>
                                        <?php echo $_SESSION['sch_faculty'] ?> OF
                                        <?php echo strtoupper($school) ?><br>
                                        DEPARTMENT OF <?php echo strtoupper($deptname) ?><br>
                                        <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                        <?php echo strtoupper($prog) ?><br>
                                        <?php } ?>
                                        EXAMINATION RESULTS - OVERALL ASSESSMENT<br>
                                    </strong></h6>
                            </td>
                            <td>
                                <figure class="profile-picture">
                                    <?php
                                        $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                        $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                        echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='70' height='70'>";

                                        ?>
                                </figure>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <table style="font-size:9px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                    <tbody style="color: #0a0a0a">
                        <tr>
                            <th style="text-align: left;width: 10%">SURNAME :</th>
                            <td style="width: 30%; text-align: left; padding-left: 1em"><?php echo $name_first ?>
                            </td>
                            <th style="padding-left: 1em;width: 12%; text-align: left">OTHER NAME(S) :</th>
                            <td style="padding-left: 1em;width: 18%"><?php echo $name_middle . " " . $name_last ?>
                            </td>
                            <th style="padding-left: 1em;width: 18%; text-align: left">MATRICULATION NUMBER :</th>
                            <td style="padding-left: 1em"><?php echo $matno ?></td>
                        </tr>
                    </tbody>
                </table>

                <table style="color: #0a0a0a; width: 100%; font-size: 10px">
                    <tbody>

                        <tr>
                            <th style="border-style:solid; border-width:thin; text-align:center">
                                <?php echo $sessionarry[9] . " " . $LevelArray[9] . "  Level" ?></th>
                            <th style="border-style:solid; border-width:thin; text-align:center"><?php if ($SessionCount >= 10) {
                                                                                                            echo $sessionarry[10] . " " . $LevelArray[10] . "  Level";
                                                                                                        } ?></th>
                            <th style="border-style:solid; border-width:thin; text-align:center"><?php if ($SessionCount >= 11) {
                                                                                                            echo $sessionarry[11] . " " . $LevelArray[11] . "  Level";
                                                                                                        } ?> </th>
                        </tr>
                        <tr>
                            <td style="border-style:solid; border-width:thin; width: 33%" valign="top">

                                <?php

                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    $arrayNumb = 9;
                                    if ($absent1ST[9] != 0 && $absent2ND[9] != 0) {
                                        include 'modulesInSess/calSemResult_Grad.php';
                                    } elseif ($absent1ST[9] == 0 && $absent2ND[9] != 0) {
                                        if ($LevelArray[8] < 500) {
                                            if ($LevelArray[8] == 400) {
                                                $indSession = $sessionarry[9];
                                                include 'modulesInSess/missing_ses.php';
                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                            } else {
                                                if ($LevelArray[8] == 300) {
                                                    if ($LevelArray[9] == 400) {
                                                        if ($siwesstatus == "Part") {
                                                            $indSession = $sessionarry[9];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } elseif ($LevelArray[9] != 300) {
                                                        $indSession = $sessionarry[9];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                } else {
                                                    $indSession = $sessionarry[9];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                }
                                            }
                                        }
                                        include 'modulesInSess/calSemResult_Grad.php';
                                    } elseif ($absent1ST[9] != 0 && $absent2ND[9] == 0) {
                                        include 'modulesInSess/calSemResult_Grad.php';
                                        if ($sessionarry[9] != $getMaxSess) {
                                            if ($LevelArray[8] < 500) {
                                                if ($LevelArray[8] == 400) {
                                                    $indSession = $sessionarry[9];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                } else {
                                                    if ($LevelArray[8] == 300) {
                                                        if ($LevelArray[9] != 400) {
                                                            $indSession = $sessionarry[9];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } else {
                                                        $indSession = $sessionarry[9];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                }
                                            }
                                        }
                                    } elseif ($absent1ST[9] == 0 && $absent2ND[9] == 0) {
                                        
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
                                        $Issess9 = false;
                                        $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[9]'";
                                        $result4 = $conn->query($sql4);
                                        if ($result4->num_rows > 0) {
                                            $response_full = "Cancel Session";
                                            $Issess9 = true;
                                        }
                                        $conn->close();
                                        if ($Issess9 == false) {
                                            $indSession = $sessionarry[9];
                                            include 'modulesInSess/missing_ses.php';
                                        }
                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                    }


                                    if ($tct[9] != 0) {
                                        echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[9]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[9]</th></tr>";
                                    }


                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>

                            </td>
                            <td style="border-style:solid; border-width:thin; width: 33%" valign="top">
                                <?php
                                    //$session1 = $sessionarry[1];
                                    //include 'includes/semresults.php';
                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    if ($SessionCount >= 10) {
                                        $arrayNumb = 10;
                                        if ($absent1ST[10] != 0 && $absent2ND[10] != 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[10] == 0 && $absent2ND[10] != 0) {
                                            if ($LevelArray[9] < 500) {
                                                if ($LevelArray[9] == 400) {
                                                    $indSession = $sessionarry[10];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                } else {
                                                    if ($LevelArray[9] == 300) {
                                                        if ($LevelArray[10] == 400) {
                                                            if ($siwesstatus == "Part") {
                                                                $indSession = $sessionarry[10];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } elseif ($LevelArray[10] != 300) {
                                                            $indSession = $sessionarry[10];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } else {
                                                        $indSession = $sessionarry[10];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                }
                                            }
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[10] != 0 && $absent2ND[10] == 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                            if ($sessionarry[10] != $getMaxSess) {
                                                if ($LevelArray[9] < 500) {
                                                    if ($LevelArray[9] == 400) {
                                                        $indSession = $sessionarry[10];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    } else {
                                                        if ($LevelArray[9] == 300) {
                                                            if ($LevelArray[10] != 400) {
                                                                $indSession = $sessionarry[10];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } else {
                                                            $indSession = $sessionarry[10];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    }
                                                }
                                            }
                                        } elseif ($absent1ST[10] == 0 && $absent2ND[10] == 0) {
                                            
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }
                                            $Issess10 = false;
                                            $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[10]'";
                                            $result4 = $conn->query($sql4);
                                            if ($result4->num_rows > 0) {
                                                $response_full = "Cancel Session";
                                                $Issess10 = true;
                                            }
                                            $conn->close();
                                            if ($Issess10 == false) {
                                                $indSession = $sessionarry[10];
                                                include 'modulesInSess/missing_ses.php';
                                            }
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }


                                        if ($tct[10] != 0) {
                                            echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[10]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[10]</th></tr>";
                                        }
                                    }


                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>


                            </td>
                            <td style="border-style:solid; border-width:thin" valign="top">
                                <?php
                                    //$session1 = $sessionarry[2];
                                    //include 'includes/semresults.php';
                                    echo "<table style='font-size:13px; width: 100%'>";
                                    echo "<thead style='text-align:center;'>";
                                    echo "<tr>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";

                                    if ($SessionCount >= 11) {
                                        $arrayNumb = 11;
                                        if ($absent1ST[11] != 0 && $absent2ND[11] != 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[11] == 0 && $absent2ND[11] != 0) {
                                            if ($LevelArray[10] < 500) {
                                                if ($LevelArray[10] == 400) {
                                                    $indSession = $sessionarry[11];
                                                    include 'modulesInSess/missing_ses.php';
                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                } else {
                                                    if ($LevelArray[10] == 300) {
                                                        if ($LevelArray[11] == 400) {
                                                            if ($siwesstatus == "Part") {
                                                                $indSession = $sessionarry[11];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } elseif ($LevelArray[11] != 300) {
                                                            $indSession = $sessionarry[11];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    } else {
                                                        $indSession = $sessionarry[11];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    }
                                                }
                                            }
                                            include 'modulesInSess/calSemResult_Grad.php';
                                        } elseif ($absent1ST[11] != 0 && $absent2ND[11] == 0) {
                                            include 'modulesInSess/calSemResult_Grad.php';
                                            if ($sessionarry[11] != $getMaxSess) {
                                                if ($LevelArray[10] < 500) {
                                                    if ($LevelArray[10] == 400) {
                                                        $indSession = $sessionarry[11];
                                                        include 'modulesInSess/missing_ses.php';
                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                    } else {
                                                        if ($LevelArray[10] == 300) {
                                                            if ($LevelArray[11] != 400) {
                                                                $indSession = $sessionarry[11];
                                                                include 'modulesInSess/missing_ses.php';
                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                            }
                                                        } else {
                                                            $indSession = $sessionarry[11];
                                                            include 'modulesInSess/missing_ses.php';
                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                        }
                                                    }
                                                }
                                            }
                                        } elseif ($absent1ST[11] == 0 && $absent2ND[11] == 0) {
                                           
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }
                                            $Issess11 = false;
                                            $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[11]'";
                                            $result4 = $conn->query($sql4);
                                            if ($result4->num_rows > 0) {
                                                $response_full = "Cancel Session";
                                                $Issess11 = true;
                                            }
                                            $conn->close();
                                            if ($Issess11 == false) {
                                                $indSession = $sessionarry[11];
                                                include 'modulesInSess/missing_ses.php';
                                            }
                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                        }


                                        if ($tct[11] != 0) {
                                            echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[11]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[11]</th></tr>";
                                        }
                                    }

                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>
                            </td>
                        </tr>
                        <tr>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($tct[9] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[9] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[9] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[9] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[9] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[9], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[9], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($SessionCount >= 10) { ?>
                                <?php if ($tct[10] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[10] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[10] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[10] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[10] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[10], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[10], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <?php if ($arrayNumb >= 11) { ?>
                                <?php if ($tct[11] !== 0) { ?>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 1em"></td>
                                            <th style="text-align: right; padding-right: 1em">
                                                <?php echo $LevelArray[11] . "  L" ?></th>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCT</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tct[11] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TCP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tcp[11] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">TGP</th>
                                            <td style="text-align: right; padding-right: 1em"><?php echo $tgp[11] ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">GPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$gpaarry[11], 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th style="padding-left: 1em; text-align: left">CGPA</th>
                                            <td style="text-align: right; padding-right: 1em">
                                                <?php echo number_format((float)$LevelCGPA[11], 2, '.', '') ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php } ?>
                            </td>
                        </tr>


                        <tr>
                            <td style="border-style:solid; border-width:thin">
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr style="border: 1px solid #ddd">
                                            <th style="text-align: center">SUMMARY</th>
                                        </tr>

                                        <?php
                                            $deptdb = $_SESSION['deptdb'];
                                            $dept_db = $deptdb . $dept;
                                            $conn_stu = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }
                                            $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                            $result = $conn_stu->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $gettitle = $row['title1'];
                                                    if ($gettitle == "XXXX") {
                                                        echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'> .</td></tr>";
                                                    } else {
                                                        echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'>$gettitle</td></tr>";
                                                    }
                                                }
                                            }
$conn_stu->close();
                                            ?>
                                        <tr style='border: 1px solid #ddd'>
                                            <td style='padding-left: 1em; text-align: left'>SWEP</td>
                                        </tr>
                                        <tr style='border: 1px solid #ddd'>
                                            <th style='padding-left: 1em; text-align: left'>Total:-</th>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                            <td style="border-style:solid; border-width:thin">
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <th style="text-align: center">REQUIRED</th>
                                            <th style="text-align: center">EARNED</th>
                                            <th style="text-align: center">DEF</th>
                                        </tr>

                                        <?php
                                            $totReq = $totearn = $totdif = 0;
                                            $deptdb = $_SESSION['deptdb'];
                                            $dept_db = $deptdb . $dept;
                                            $conn_stu = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }
                                            $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                            $result = $conn_stu->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $require1 = $row['require1'];
                                                    $earned = $row['earned'];
                                                    $totReq = $totReq + $require1;
                                                    $totearn = $totearn + $earned;
                                                    $dif = $require1 - $earned;
                                                    if ($dif <= 0) {
                                                        $dif = 0;
                                                    }
                                                    $totdif = $totdif + $dif;
                                                    echo "<tr style='border: 1px solid #ddd; text-align: center'><td>$require1</td><td>$earned</td><td>$dif</td></tr>";
                                                }
                                            }
                                            $conn_stu->close();
                                            
                                            $totReq = $totReq + 2;
                                            $totearn = $totearn + 2;

                                            ?>
                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>0</td>
                                        </tr>
                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                            <th style="text-align: center"><?php echo $totReq ?></th>
                                            <th style="text-align: center"><?php echo $totearn ?></th>
                                            <th style="text-align: center"><?php echo $totdif ?></th>
                                        </tr>

                                    </tbody>
                                </table>
                            </td>
                            <td style="border-style:solid; border-width:thin">

                                <table style="width: 100%; font-size: 10px">
                                    <tbody>

                                        <tr>
                                            <td>.</td>
                                            <td>.</td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TCT for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $totunit1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TCP for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $stcp1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                TGP for graduation:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $totgp1 ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                CGPA:</th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo number_format((float)$ccgpa, 2, '.', '') ?></td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                Class of Degree :- </th>
                                            <td style="border-bottom-style: solid; border-width:thin">
                                                <?php echo $classdegree ?> </td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                Remark :- </th>
                                            <td style="border-bottom-style: solid; border-width:thin">PASSED</td>
                                        </tr>
                                        <tr>
                                            <th
                                                style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                * A satisfactory completion of the scheme is all that is required to
                                                qualify the candidate for graduation</th>
                                            <td style="border-bottom-style: solid; border-width:thin"></td>
                                        </tr>


                                    </tbody>
                                </table>
                            </td>
                        </tr>

                    </tbody>
                </table>
                <table style="width: 100%; font-size: 10px">
                    <tbody>
                        <tr>
                            <td style="width: 40%; text-align: left">.</td>
                            <th style="width: 25%; font-size: 12px"><?php if ($NotRelevant == true) {
                                                                            echo "* Courses NOT Relevant to the Department";
                                                                        } ?></th>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="width: 40%; text-align: left"><?php echo $_SESSION["HOD_Sign"] ?></td>
                            <td style="width: 25%"></td>
                            <td style="text-align: left"><?php echo $_SESSION["Dean_Sign"] ?></td>
                        </tr>
                        <tr>
                            <td style="text-align: left">HOD's SIGNATURE AND DATE</td>
                            <td></td>
                            <td style="text-align: left">DEAN's SIGNATURE AND DATE</td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
<?php } ?>
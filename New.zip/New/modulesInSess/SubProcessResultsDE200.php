<?php

// DE 200
if ($GetTheSemester == "1ST") {
    if ($deptoption == "YES") {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE200GetOption . " = 'YES' AND Level1 < '$txtLevelPlus' AND " . $GroupOption . " = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE200corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE200corecoursearray[$DE200corecoursecount] = $CCode2;
            }
        }
    } else {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Level1 < '$txtLevelPlus' AND Grouping2 = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE200corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE200corecoursearray[$DE200corecoursecount] = $CCode2;
            }
        }
    }

    if ($deptoption == "YES") {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE200GetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND " . $GroupOption . " = 'NO' AND semester = '1ST'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE200corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE200corecoursearray[$DE200corecoursecount] = $CCode2;
            }
        }
    } else {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping2 = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE200corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE200corecoursearray[$DE200corecoursecount] = $CCode2;
            }
        }
    }
} else {
    if ($deptoption == "YES") {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE200GetOption . " = 'YES' AND Level1 <= '$txtLevelPlus' AND " . $GroupOption . " = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE200corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE200corecoursearray[$DE200corecoursecount] = $CCode2;
            }
        }
    } else {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Level1 <= '$txtLevelPlus' AND Grouping2 = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE200corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE200corecoursearray[$DE200corecoursecount] = $CCode2;
            }
        }
    }
}



if ($deptoption == "YES") {
    if ($curricul == "YES") {
        $curri = $_SESSION["curri"];
        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt' AND curriculum = '$curri'";
    } else {
        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt'";
    }
    $result5 = $conn->query($sql5);
    if ($result5->num_rows > 0) {
        while ($row5 = $result5->fetch_assoc()) {
            $GetOptCourse = $row5["GroupCode"];
            if ($GetTheSemester == "1ST") {
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE200GetOption . " = 'YES' AND Level1 < '$txtLevelPlus' AND " . $GroupOption . " = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE200groupCodecount++;
                    $DE200groupCodearray[$DE200groupCodecount] = $GetOptCourse;
                }

                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE200GetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND " . $GroupOption . " = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE200groupCodecount++;
                    $DE200groupCodearray[$DE200groupCodecount] = $GetOptCourse;
                }
            } else {
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE200GetOption . " = 'YES' AND Level1 <= '$txtLevelPlus' AND " . $GroupOption . " = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE200groupCodecount++;
                    $DE200groupCodearray[$DE200groupCodecount] = $GetOptCourse;
                }
            }
        }
    }
} else {
    if ($curricul == "YES") {
        $curri = $_SESSION["curri"];
        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND curriculum = '$curri'";
    } else {
        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
    }
    $result5 = $conn->query($sql5);
    if ($result5->num_rows > 0) {
        while ($row5 = $result5->fetch_assoc()) {
            $GetOptCourse = $row5["GroupCode"];
            if ($GetTheSemester == "1ST") {
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Level1 < '$txtLevelPlus' AND Grouping2 = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE200groupCodecount++;
                    $DE200groupCodearray[$DE200groupCodecount] = $GetOptCourse;
                }

                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping2 = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE200groupCodecount++;
                    $DE200groupCodearray[$DE200groupCodecount] = $GetOptCourse;
                }
            } else {
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Level1 <= '$txtLevelPlus' AND Grouping2 = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE200groupCodecount++;
                    $DE200groupCodearray[$DE200groupCodecount] = $GetOptCourse;
                }
            }
        }
    }
}

/*$txtYearAdmitDE=(int)$txtYearAdmit + 1;
if ($deptoption=="YES" ){
    $sql = "SELECT * FROM stdprofile WHERE YAddmitted = '$txtYearAdmit' AND YAddmittedDir = '$txtYearAdmitDE' AND S_STAUS = '$StuStatus' AND Deptcode = '$getdept' AND Dept_Option = '$GetOpt' ORDER BY regid";
}else{
    $sql = "SELECT * FROM stdprofile WHERE YAddmitted = '$txtYearAdmit' AND YAddmittedDir = '$txtYearAdmitDE' AND S_STAUS = '$StuStatus' AND Deptcode = '$getdept' ORDER BY regid";
}
$result = $conn2->query($sql);
$Add1 = 0;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $repairIteration++;
        $FailedCourses = 0;



        $repairPrvTotalCrTaken = 0;
        $repairPrvTotalCrPassed = 0;
        $repairPrvTotalGradePoint = 0;
        $repairPrvTotalCGPA = 0;

        $repairCA = 0;
        $repairEXAM = 0;
        $repairTOTAL = 0;
        $repairGRADE = "";
        $repairUNIT = 0;

        $repairPresTotalCrTaken = 0;
        $repairPresTotalCrPassed = 0;
        $presentGPointer = 0;
        $repairPresTotalCGPA = 0;

        $repairCA_pres = 0;
        $repairEXAM_pres = 0;
        $repairTOTAL_pres = 0;
        $repairGRADE_pres = "";
        $repairUNIT_pres = 0;

        //cummulative..
        $repairCumTotalCrTaken = 0;
        $repairCumTotalCrPassed = 0;
        $CumGPointer = 0;
        $repairCumTotalCGPA = 0;

        $repairCumTotalCrTaken_A = 0;
        $repairCumTotalCrPassed_A = 0;
        $CumGPointer_A = 0;
        $repairCumTotalCGPA_A = 0;
        $SngReCGP_Cum_A = 0;


        $repairCA_Cum = 0;
        $repairEXAM_Cum = 0;
        $repairTOTAL_Cum = 0;
        $repairGRADE_Cum = "";
        $repairUNIT_Cum = 0;
        $repairUNIT_REMARK = "";
        $SSP1_STATE_Cum = 0;

        $repairCA_Cum_A = 0;
        $repairEXAM_Cum_A = 0;
        $repairTOTAL_Cum_A = 0;
        $repairUNIT_Cum_A = 0;

        //backward Once....
        $repairBKTotalCrTaken = 0;
        $repairBKTotalCrPassed = 0;
        $BKGPointer = 0;
        $repairBKTotalCGPA = 0;

        $repairCA_BK = 0;
        $repairEXAM_BK = 0;
        $repairTOTAL_BK = 0;
        $repairGRADE_BK = "";
        $repairUNIT_BK = 0;




        $Snumber[$repairIteration] = $repairIteration;
        $repairRegno[$repairIteration] = $row["regid"];
        $deptcorreg = $getdept."_correg";

        if(empty($row['names'])) {
            $repairName[$repairIteration] = $row['firstname']." ".$row['othername']." ".$row['surname'];
        }else{
            $repairName[$repairIteration] = $row['names'];
        }

        if($deptoption == "YES"){
            $GetOpt = $row["Dept_Option"];
            $GetOptG = "Group" .$row["Dept_Option"];
            $repairDeptOpt[$repairIteration]=$GetOpt;
        }else{
            $GetOpt = "XX";
            $GetOptG = "XX";
        }
        $NON_DE_Senate = false;
        $DE200Senate = true;
        $DE300Senate = false;

        $InSessionSemester = $GetTheSemester;
        include 'modulesInSess/CalculateResults.php';
        //echo $TotGetUnit2."<br>";
        $repairToTOuts[$repairIteration] = $TotGetUnit2 + $Total_C_F;
        $tstFailedCs[$repairIteration] = $strDefficiency;
        $CachCourse = $repairIteration;

    }
}*/


// DE 300
/*if ($GetTheSemester == "1ST") {
    if($deptoption=="YES"){
        $sql6 = "SELECT * FROM ".$deptgencourses." WHERE " . $CoreDE300GetOption . " = 'YES' AND Level1 < '$txtLevelPlus' AND ".$GroupOption." = 'NO'";
        $result6 = $conn->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $corecoursearray[$corecoursecount]=$CCode2;
            }
        }
    }else{
        $sql6 = "SELECT * FROM ".$deptgencourses." WHERE CoreDE300 = 'YES' AND Level1 < '$txtLevelPlus' AND Grouping = 'NO'";
        $result6 = $conn->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $corecoursearray[$corecoursecount]=$CCode2;
            }
        }
    }

    if($deptoption=="YES"){
        $sql6 = "SELECT * FROM ".$deptgencourses." WHERE " . $CoreDE300GetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND ".$GroupOption." = 'NO' AND semester = '1ST'";
        $result6 = $conn->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $corecoursearray[$corecoursecount]=$CCode2;
            }
        }
    }else{
        $sql6 = "SELECT * FROM ".$deptgencourses." WHERE CoreDE300 = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping = 'NO'";
        $result6 = $conn->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $corecoursearray[$corecoursecount]=$CCode2;
            }
        }
    }

}else{
    if($deptoption=="YES"){
        $sql6 = "SELECT * FROM ".$deptgencourses." WHERE " . $CoreDE300GetOption . " = 'YES' AND Level1 <= '$txtLevelPlus' AND ".$GroupOption." = 'NO'";
        $result6 = $conn->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $corecoursearray[$corecoursecount]=$CCode2;
            }
        }
    }else{
        $sql6 = "SELECT * FROM ".$deptgencourses." WHERE CoreDE300 = 'YES' AND Level1 <= '$txtLevelPlus' AND Grouping = 'NO'";
        $result6 = $conn->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $corecoursearray[$corecoursecount]=$CCode2;
            }
        }
    }

}



if ($deptoption=="YES" ){
    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt'";
    $result5 = $conn->query($sql5);
    if ($result5->num_rows > 0) {
        while ($row5 = $result5->fetch_assoc()) {
            $GetOptCourse=$row5["GroupCode"];
            If ($GetTheSemester == "1ST") {
                $sql6 = "SELECT * FROM ".$deptgencourses." WHERE " . $CoreDE300GetOption . " = 'YES' AND Level1 < '$txtLevelPlus' AND ".$GroupOption." = '$GetOptCourse'";
                $result6 = $conn->query($sql6);
                if ($result6->num_rows > 0) {
                    $groupCodecount++;
                    $groupCodearray[$groupCodecount]=$GetOptCourse;
                }

                $sql6 = "SELECT * FROM ".$deptgencourses." WHERE " . $CoreDE300GetOption . " = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND ".$GroupOption." = '$GetOptCourse'";
                $result6 = $conn->query($sql6);
                if ($result6->num_rows > 0) {
                    $groupCodecount++;
                    $groupCodearray[$groupCodecount]=$GetOptCourse;
                }
            }else{
                $sql6 = "SELECT * FROM ".$deptgencourses." WHERE " . $CoreDE300GetOption . " = 'YES' AND Level1 <= '$txtLevelPlus' AND ".$GroupOption." = '$GetOptCourse'";
                $result6 = $conn->query($sql6);
                if ($result6->num_rows > 0) {
                    $groupCodecount++;
                    $groupCodearray[$groupCodecount]=$GetOptCourse;
                }
            }

        }
    }
}else{
    $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
    $result5 = $conn->query($sql5);
    if ($result5->num_rows > 0) {
        while ($row5 = $result5->fetch_assoc()) {
            $GetOptCourse=$row5["GroupCode"];
            If ($GetTheSemester == "1ST") {
                $sql6 = "SELECT * FROM ".$deptgencourses." WHERE CoreDE300 = 'YES' AND Level1 < '$txtLevelPlus' AND Grouping = '$GetOptCourse'";
                $result6 = $conn->query($sql6);
                if ($result6->num_rows > 0) {
                    $groupCodecount++;
                    $groupCodearray[$groupCodecount]=$GetOptCourse;
                }

                $sql6 = "SELECT * FROM ".$deptgencourses." WHERE CoreDE300 = 'YES' AND Level1 = '$txtLevelPlus' AND semester = '1ST' AND Grouping = '$GetOptCourse'";
                $result6 = $conn->query($sql6);
                if ($result6->num_rows > 0) {
                    $groupCodecount++;
                    $groupCodearray[$groupCodecount]=$GetOptCourse;
                }
            }else{
                $sql6 = "SELECT * FROM ".$deptgencourses." WHERE CoreDE300 = 'YES' AND Level1 <= '$txtLevelPlus' AND Grouping = '$GetOptCourse'";
                $result6 = $conn->query($sql6);
                if ($result6->num_rows > 0) {
                    $groupCodecount++;
                    $groupCodearray[$groupCodecount]=$GetOptCourse;
                }
            }

        }
    }
}

$txtYearAdmitDE=(int)$txtYearAdmit + 3;
if ($deptoption=="YES" ){
    $sql = "SELECT * FROM stdprofile WHERE YAddmitted = '$txtYearAdmit' AND YAddmittedDir = '$txtYearAdmitDE' AND S_STAUS = '$StuStatus' AND Deptcode = '$getdept' AND Dept_Option = '$GetOpt' ORDER BY regid";
}else{
    $sql = "SELECT * FROM stdprofile WHERE YAddmitted = '$txtYearAdmit' AND YAddmittedDir = '$txtYearAdmitDE' AND S_STAUS = '$StuStatus' AND Deptcode = '$getdept' ORDER BY regid";
}
$result = $conn2->query($sql);
$Add1 = 0;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $repairIteration++;
        $FailedCourses = 0;

        $repairPrvTotalCrTaken = 0;
        $repairPrvTotalCrPassed = 0;
        $repairPrvTotalGradePoint = 0;
        $repairPrvTotalCGPA = 0;

        $repairCA = 0;
        $repairEXAM = 0;
        $repairTOTAL = 0;
        $repairGRADE = "";
        $repairUNIT = 0;

        $repairPresTotalCrTaken = 0;
        $repairPresTotalCrPassed = 0;
        $presentGPointer = 0;
        $repairPresTotalCGPA = 0;

        $repairCA_pres = 0;
        $repairEXAM_pres = 0;
        $repairTOTAL_pres = 0;
        $repairGRADE_pres = "";
        $repairUNIT_pres = 0;

        //cummulative..
        $repairCumTotalCrTaken = 0;
        $repairCumTotalCrPassed = 0;
        $CumGPointer = 0;
        $repairCumTotalCGPA = 0;

        $repairCumTotalCrTaken_A = 0;
        $repairCumTotalCrPassed_A = 0;
        $CumGPointer_A = 0;
        $repairCumTotalCGPA_A = 0;
        $SngReCGP_Cum_A = 0;


        $repairCA_Cum = 0;
        $repairEXAM_Cum = 0;
        $repairTOTAL_Cum = 0;
        $repairGRADE_Cum = "";
        $repairUNIT_Cum = 0;
        $repairUNIT_REMARK = "";
        $SSP1_STATE_Cum = 0;

        $repairCA_Cum_A = 0;
        $repairEXAM_Cum_A = 0;
        $repairTOTAL_Cum_A = 0;
        $repairUNIT_Cum_A = 0;

        //backward Once....
        $repairBKTotalCrTaken = 0;
        $repairBKTotalCrPassed = 0;
        $BKGPointer = 0;
        $repairBKTotalCGPA = 0;

        $repairCA_BK = 0;
        $repairEXAM_BK = 0;
        $repairTOTAL_BK = 0;
        $repairGRADE_BK = "";
        $repairUNIT_BK = 0;




        $Snumber[$repairIteration] = $repairIteration;
        $repairRegno[$repairIteration] = $row["regid"];
        $deptcorreg = $getdept."_correg";

        if(empty($row['names'])) {
            $repairName[$repairIteration] = $row['firstname']." ".$row['othername']." ".$row['surname'];
        }else{
            $repairName[$repairIteration] = $row['names'];
        }

        if($deptoption == "YES"){
            $GetOpt = $row["Dept_Option"];
            $GetOptG = "Group" .$row["Dept_Option"];
            $repairDeptOpt[$repairIteration]=$GetOpt;
        }else{
            $GetOpt = "XX";
            $GetOptG = "XX";
        }
        $NON_DE_Senate = false;
        $DE200Senate = false;
        $DE300Senate = true;

        $InSessionSemester = $GetTheSemester;
        include 'modulesInSess/CalculateResults.php';
        //echo $TotGetUnit2."<br>";
        $repairToTOuts[$repairIteration] = $TotGetUnit2 + $Total_C_F;
        $tstFailedCs[$repairIteration] = $strDefficiency;
        $CachCourse = $repairIteration;

    }
}*/
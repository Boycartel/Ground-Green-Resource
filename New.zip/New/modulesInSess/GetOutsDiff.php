<?php

$Total_C_F = 0;
$no_of_failure = 0;
$strDefficiency = "";
$Credit_Fail = "";
$TotGetUnit2 = 0;
$YesOption = "YES";
$Outstand = "";

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$deptdb = $_SESSION['deptdb'];
$dept_db = $deptdb . strtolower($getdept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

unset($difFailedCarray);
unset($difFailedCarray2);
$difFailedCarray = array_values(array_diff($FailedCoursearray, $PassedCoursearray));
$difFailedCarray2 = array_values(array_unique($difFailedCarray));
//$arraynoFailed=count($difFailedCarray2);
$difFailedCRelev = array_values(array_intersect($relevantCourse, $difFailedCarray2));

foreach ($difFailedCRelev as $CCode2) {
    //echo "$value <br>";
    $defTitle = "";
    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding = '$CCode2'";
    $result6 = $conn_stu->query($sql6);
    if ($result6->num_rows > 0) {
        while ($row6 = $result6->fetch_assoc()) {
            $GetUnit2 = $row6["credit"];
            $defTitle = str_replace("'", "''", $row6["C_title"]);
        }
    }
    //$n++;
    $countdefCCode++;
    $StudefCCode[$countdefCCode] = $CCode2;
    $RegdefCCode[$countdefCCode] = $repairRegno[$i];
    $TitledefCCode[$countdefCCode] = $defTitle;
    $UnitdefCCode[$countdefCCode] = $GetUnit2;
    $Total_C_F = $Total_C_F + $GetUnit2;
    $Credit_Fail = $Credit_Fail . $CCode2 . "(" . $GetUnit2 . "), ";
    $numb_Course_failed++;
}




unset($difarray);
unset($difGCodearray);
if ($NON_DE_Senate == true) {
    $difarray = array_values(array_diff($corecoursearray, $regcoursesarray));
    $difGCodearray = array_values(array_diff($groupCodearray, $GCodecoursesarray));
} elseif ($DE200Senate == true) {
    $difarray = array_values(array_diff($DE200corecoursearray, $regcoursesarray));
    $difGCodearray = array_values(array_diff($DE200groupCodearray, $GCodecoursesarray));
} elseif ($DE300Senate == true) {
    $difarray = array_values(array_diff($DE300corecoursearray, $regcoursesarray));
    $difGCodearray = array_values(array_diff($DE300groupCodearray, $GCodecoursesarray));
}
$difGCodearray = array_unique($difGCodearray);

//$arrayno=count($difarray);
//$arraynoGCode=count($difGCodearray);

foreach ($difarray as $CCode2) {
    $defTitle = "";
    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding = '$CCode2'";
    $result6 = $conn_stu->query($sql6);
    if ($result6->num_rows > 0) {
        while ($row6 = $result6->fetch_assoc()) {
            $GetUnit2 = $row6["credit"];
            $defTitle = str_replace("'", "''", $row6["C_title"]);
        }
    }

    $TotGetUnit2 = $TotGetUnit2 + $GetUnit2;
    $numb_Course_failed++;
    //$NoOutstandCourse = $NoOutstandCourse + 1;
    $IsCcondon = 0;
    //for($j = 1; $j <= $StuSessCount; $j++) {

    $StuCurSess = str_ireplace("/", "_", $GetTheSession);
    $deptcorreg = "correg_" . $StuCurSess;

    $sql3 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]' AND CCode  = '$CCode2' AND coursecondon = 'YES' AND SessionRegis =  '$GetTheSession'";
    $result3 = $conn_stu->query($sql3);
    if ($result3->num_rows > 0) {
        $IsCcondon = $IsCcondon + 1;
    }
    //}


    $countdefCCode++;
    $StudefCCode[$countdefCCode] = $CCode2;
    $RegdefCCode[$countdefCCode] = $repairRegno[$i];
    $TitledefCCode[$countdefCCode] = $defTitle;
    $UnitdefCCode[$countdefCCode] = $GetUnit2;

    if ($IsCcondon == 0) {
        $Outstand = $Outstand . $CCode2 . "(" . $GetUnit2 . "), ";
    } else {
        $Outstand = $Outstand . $CCode2 . "(c)" . "(" . $GetUnit2 . "), ";
    }
}

foreach ($difGCodearray as $GroupCode) {
    if ($_SESSION['curricul'] == "YES") {
        $curri = $_SESSION["curri"];
        if ($deptoption == "YES") {
            $sql6 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt' AND GroupCode = '$GroupCode' AND curriculum = '$curri'";
        } else {
            $sql6 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND GroupCode = '$GroupCode' AND curriculum = '$curri'";
        }
    } else {
        if ($deptoption == "YES") {
            $sql6 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$GetOpt' AND GroupCode = '$GroupCode'";
        } else {
            $sql6 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND GroupCode = '$GroupCode'";
        }
    }
    $result6 = $conn->query($sql6);
    if ($result6->num_rows > 0) {
        while ($row6 = $result6->fetch_assoc()) {
            $CCode2 = $row6["outsCourse"];
        }
    }


    //$sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Grouping = '$CCode2'";
    $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding = '$CCode2'";
    $result6 = $conn_stu->query($sql6);
    if ($result6->num_rows > 0) {
        while ($row6 = $result6->fetch_assoc()) {
            $GetUnit2 = $row6["credit"];
            $defTitle = str_replace("'", "''", $row6["C_title"]);
        }
    }
    $TotGetUnit2 = $TotGetUnit2 + $GetUnit2;
    $numb_Course_failed++;
    //$NoOutstandCourse = $NoOutstandCourse + 1;
    $IsCcondon = 0;



    $StuCurSess = str_ireplace("/", "_", $GetTheSession);
    $deptcorreg = "correg_" . $StuCurSess;
    $sql3 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]' AND CCode  = '$CCode2' AND coursecondon = 'YES' AND SessionRegis =  '$GetTheSession'";
    $result3 = $conn_stu->query($sql3);
    if ($result3->num_rows > 0) {
        while ($row3 = $result3->fetch_assoc()) {
            $IsCcondon = $IsCcondon + 1;
        }
    }
    //}


    $countdefCCode++;
    $StudefCCode[$countdefCCode] = $CCode2;
    $RegdefCCode[$countdefCCode] = $repairRegno[$i];
    $TitledefCCode[$countdefCCode] = $defTitle;
    $UnitdefCCode[$countdefCCode] = $GetUnit2;
    if ($IsCcondon == 0) {
        $Outstand = $Outstand . $CCode2 . "(" . $GetUnit2 . "), ";
    } else {
        $Outstand = $Outstand . $CCode2 . "(c)" . "(" . $GetUnit2 . "), ";
    }
}
$conn->close();
$conn2->close();
$conn_stu->close();

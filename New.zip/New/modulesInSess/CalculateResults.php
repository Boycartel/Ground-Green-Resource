<?php
$InSessionSemester = $_SESSION['resultsemester'];
if ($_SESSION['deptoption'] == "YES") {
    $getdeptOpt = $_SESSION["getdeptOpt"];
}

if ($SessCount == 1) {

    if ($InSessionSemester == "1ST") {

        include 'modulesInSess/Level100.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);

        $CrTake100 = $CrTakePresent;
        $CrPass100 = $CrPassPresent;
        $GrPoint100 = $GrPointPresent;
        if ($CrTake100 == 0) {
            $CGPA100 = 0;
        } else {
            $CGPA100 = $GrPoint100 / $CrTake100;
        }
        $repairCumCrTaken[$i] = $CrTakePrev + $CrTakePresent;
        $repairCumCP[$i] = $CrPassPrev + $CrPassPresent;
        $repairCumGP[$i] = $GrPointPrev + $GrPointPresent;
        if (($CrTakePrev + $CrTakePresent) == 0) {
            $repairCumCGPA[$i] = 0;
        } else {
            $repairCumCGPA[$i] = number_format(($GrPointPrev + $GrPointPresent) / ($CrTakePrev + $CrTakePresent), 2);
        }
    } else {

        include 'modulesInSess/Level100.php';

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);

        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairCumCrTaken[$i] = $CrTake100;
        $repairCumCP[$i] = $CrPass100;
        $repairCumGP[$i] = $GrPoint100;
        $repairCumCGPA[$i] = number_format($CGPA100, 2);
    }
    $repairCGPA100[$i] = 0;
    $repairCGPA200[$i] = 0;
    $repairCGPA300[$i] = 0;
    $repairCGPA400[$i] = 0;
} elseif ($SessCount == 2) {

    if ($InSessionSemester == "1ST") {
        include 'modulesInSess/Level200.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);


        $repairCumCrTaken[$i] = $CrTakePrev + $CrTakePresent;
        $repairCumCP[$i] = $CrPassPrev + $CrPassPresent;
        $repairCumGP[$i] = $GrPointPrev + $GrPointPresent;
        $repairCumCGPA[$i] = number_format($CGPA200, 2);
    } else {

        include 'modulesInSess/Level200.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);


        $repairCumCrTaken[$i] = $CrTake200;
        $repairCumCP[$i] = $CrPass200;
        $repairCumGP[$i] = $GrPoint200;
        $repairCumCGPA[$i] = number_format($CGPA200, 2);
    }
    $repairCGPA100[$i] = number_format($CGPA100, 2);
    $repairCGPA200[$i] = 0;
    $repairCGPA300[$i] = 0;
    $repairCGPA400[$i] = 0;
} elseif ($SessCount == 3) {
    if ($InSessionSemester == "1ST") {
        include 'modulesInSess/Level300.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);


        $repairCumCrTaken[$i] = $CrTakePrev + $CrTakePresent;
        $repairCumCP[$i] = $CrPassPrev + $CrPassPresent;
        $repairCumGP[$i] = $GrPointPrev + $GrPointPresent;
        $repairCumCGPA[$i] = number_format($CGPA300, 2);
    } else {

        include 'modulesInSess/Level300.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);


        $repairCumCrTaken[$i] = $CrTake300;
        $repairCumCP[$i] = $CrPass300;
        $repairCumGP[$i] = $GrPoint300;
        $repairCumCGPA[$i] = number_format($CGPA300, 2);
    }
    $repairCGPA100[$i] = number_format($CGPA100, 2);
    $repairCGPA200[$i] = number_format($CGPA200, 2);
    $repairCGPA300[$i] = 0;
    $repairCGPA400[$i] = 0;
} elseif ($SessCount == 4) {
    if ($InSessionSemester == "1ST") {
        include 'modulesInSess/Level400.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);


        $repairCumCrTaken[$i] = $CrTakePrev + $CrTakePresent;
        $repairCumCP[$i] = $CrPassPrev + $CrPassPresent;
        $repairCumGP[$i] = $GrPointPrev + $GrPointPresent;
        $repairCumCGPA[$i] = number_format($CGPA400, 2);
    } else {

        include 'modulesInSess/Level400.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);


        $repairCumCrTaken[$i] = $CrTake400;
        $repairCumCP[$i] = $CrPass400;
        $repairCumGP[$i] = $GrPoint400;
        $repairCumCGPA[$i] = number_format($CGPA400, 2);
    }
    $repairCGPA100[$i] = number_format($CGPA100, 2);
    $repairCGPA200[$i] = number_format($CGPA200, 2);
    $repairCGPA300[$i] = number_format($CGPA300, 2);
    $repairCGPA400[$i] = 0;
} elseif ($SessCount == 5) {
    if ($InSessionSemester == "1ST") {
        include 'modulesInSess/Level500.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);


        $repairCumCrTaken[$i] = $CrTakePrev + $CrTakePresent;
        $repairCumCP[$i] = $CrPassPrev + $CrPassPresent;
        $repairCumGP[$i] = $GrPointPrev + $GrPointPresent;
        $repairCumCGPA[$i] = number_format($CGPA500, 2);
    } else {

        include 'modulesInSess/Level500.php';
        $repairPrvCrTaken[$i] = $CrTakePrev;
        $repairPrvCP[$i] = $CrPassPrev;
        $repairPrvGP[$i] = $GrPointPrev;
        $repairPrvCGPA[$i] = number_format($CGPAPrev, 2);

        $repairPresCrTaken[$i] = $CrTakePresent;
        $repairPresCP[$i] = $CrPassPresent;
        $repairPresGP[$i] = $GrPointPresent;
        $repairPresCGPA[$i] = number_format($CGPAPresent, 2);


        $repairCumCrTaken[$i] = $CrTake500;
        $repairCumCP[$i] = $CrPass500;
        $repairCumGP[$i] = $GrPoint500;
        $repairCumCGPA[$i] = number_format($CGPA500, 2);
    }
    $repairCGPA100[$i] = number_format($CGPA100, 2);
    $repairCGPA200[$i] = number_format($CGPA200, 2);
    $repairCGPA300[$i] = number_format($CGPA300, 2);
    $repairCGPA400[$i] = number_format($CGPA400, 2);
}

$repairsem_C_F[$i] = $sem_C_F;
$repairprev_C_F[$i] = $prev_C_F;
$repaircum_C_F[$i] = $cum_C_F;
$repairnumb_Course_failed[$i] = $numb_Course_failed;

$ProbPoint = 1;
if (Trim($InSessionSemester) == "1ST") {
    if ($SessCount == 1) {
        $THE_REMARK[$i] = "DEF";
        if ($CGPA100 < $ProbPoint) {
            $THE_REMARK[$i] = "P";
        } else {
            if (($Total_C_F + $TotGetUnit2) == 0) {
                $THE_REMARK[$i] = "IGS";
            } else {
                $THE_REMARK[$i] = "DEF";
            }
        }

        if ($repairPrvCrTaken[$i] > 0) {
            if ($CGPAPrev < $ProbPoint) {
                $THE_REMARK[$i] = "SP1";
            }
        }
        if ($CrTakePresent == 0) {
            $THE_REMARK[$i] = "DEF";
        }
    }
    if ($SessCount == 2) {
        if ($CGPA200 < $ProbPoint) {
            if ($CGPA100 < $ProbPoint) {
                $THE_REMARK[$i] = "SP1";
            } else {
                $THE_REMARK[$i] = "P";
            }
        } else {
            if ($repairPresCGPA[$i] < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            } else {
                if ($Total_C_F + $TotGetUnit2 == 0) {
                    $THE_REMARK[$i] = "IGS";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }

            if ($NON_DE_Senate == True) {
                if ($CGPA100 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                }
            }
        }


        if ($CrTakePresent == 0) {
            if ($CGPA100 < $ProbPoint) {
                if ($NON_DE_Senate == True) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } else {
                $THE_REMARK[$i] = "DEF";
            }
        }
    }

    if ($SessCount == 3) {
        if ($CGPA300 < $ProbPoint) {

            if ($CGPA200 < $ProbPoint) {
                $THE_REMARK[$i] = "SP1";
            } else {
                $THE_REMARK[$i] = "P";
            }
            if ($DE200Senate == true) {
                if ($CGPA200 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "P";
                }
            } elseif ($NON_DE_Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA100 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    } else {
                        $THE_REMARK[$i] = "SP1";
                    }
                } else {
                    $THE_REMARK[$i] = "P";
                }
            }
        } else {
            if ($repairPresCGPA[$i] < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            } else {
                if ($Total_C_F + $TotGetUnit2 == 0) {
                    $THE_REMARK[$i] = "IGS";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }

            if ($DE200Senate == true) {
                if ($CGPA200 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                }
            } elseif ($NON_DE_Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA100 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    } else {
                        $THE_REMARK[$i] = "SP1";
                    }
                }
            }
        }
        if ($CrTakePresent == 0) {

            if ($DE300Senate == True) {
                $THE_REMARK[$i] = "DEF";
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }
        }
    }
    if ($SessCount == 4) {
        if ($CGPA400 < $ProbPoint) {

            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "P";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "P";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "P";
                }
            }
        } else {
            if ($repairPresCGPA[$i] < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            } else {
                if ($Total_C_F + $TotGetUnit2 == 0) {
                    $THE_REMARK[$i] = "IGS";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }

            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                }
            }
        }

        if ($CrTakePresent == 0) {
            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }
        }
    }
    if ($SessCount == 5) {
        if ($CGPA500 < $ProbPoint) {
            if ($CGPA400 < $ProbPoint) {
                $THE_REMARK[$i] = "SP1";
            } else {
                $THE_REMARK[$i] = "P";
            }

            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "P";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "P";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "P";
                }
            }
        } else {
            if ($repairPresCGPA[$i] < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            } else {
                if ($Total_C_F + $TotGetUnit2 == 0) {
                    $THE_REMARK[$i] = "IGS";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }

            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                }
            }
        }
        if ($CrTakePresent == 0) {
            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }
        }
    }
} else {

    if ($SessCount == 1) {
        if ($CGPA100 < $ProbPoint) {

            if ($CrTakePrevOnly > 0) {
                $CGPAPrevOnly = $GrPointPrevOnly / $CrTakePrevOnly;
                if ($CGPAPrevOnly < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            } else {
                $THE_REMARK[$i] = "SP1";
            }
        } else {

            if ($Total_C_F + $TotGetUnit2 == 0) {
                $THE_REMARK[$i] = "IGS";
                if ($CGPA100 >= 4.5) {
                    $THE_REMARK[$i] = "VL";
                } elseif ($CGPA100 >= 4) {
                    $THE_REMARK[$i] = "DL";
                }
            } else {
                $THE_REMARK[$i] = "DEF";
            }

            if ($CGPAPresent < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            }
        }

        if ($DegType == "BEng") {
            if ($CGPA100 >= 2) {
                if ($Ten88Math < 8 || $Ten88PHY < 7 || $Ten88CHM < 6) {
                    $THE_REMARK[$i] = "8-7-6";
                }
            } else {
                $THE_REMARK[$i] = "BL2";
            }
        }
    }
    if ($SessCount == 2) {
        if ($CGPA200 < $ProbPoint) {
            if ($DE200Senate == True) {
                $THE_REMARK[$i] = "SP1";
            } else {
                if ($CGPA100 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            }
        } else {
            if (($Total_C_F + $TotGetUnit2) == 0) {
                $THE_REMARK[$i] = "IGS";
                if ($CGPA200 >= 4.5) {
                    $THE_REMARK[$i] = "VL";
                } elseif ($CGPA200 >= 4) {
                    $THE_REMARK[$i] = "DL";
                }
            } else {
                $THE_REMARK[$i] = "DEF";
            }

            if ($CGPAPresent < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            }
        }

        if ($CrTakePresent == 0) {
            if ($CGPA100 < $ProbPoint) {
                if ($NON_DE_Senate == True) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } else {
                $THE_REMARK[$i] = "DEF";
            }
        }
    }

    if ($SessCount == 3) {
        if ($CGPA300 < $ProbPoint) {
            if ($DE300Senate == True) {
                $THE_REMARK[$i] = "SP1";
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            }
        } else {
            if ($Total_C_F + $TotGetUnit2 == 0) {
                $THE_REMARK[$i] = "IGS";
                if ($CGPA300 >= 4.5) {
                    $THE_REMARK[$i] = "VL";
                } elseif ($CGPA300 >= 4) {
                    $THE_REMARK[$i] = "DL";
                }
            } else {
                $THE_REMARK[$i] = "DEF";
            }

            if ($CGPAPresent < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            }

            if ($NON_DE_Senate == True) {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                }
            }
        }

        if ($CrTakePresent == 0) {
            if ($DE300Senate == True) {
                $THE_REMARK[$i] = "DEF";
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }
        }
    }
    if ($SessCount == 4) {
        if ($CGPA400 < $ProbPoint) {
            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            }
        } else {
            if ($Total_C_F + $TotGetUnit2 == 0) {
                $THE_REMARK[$i] = "IGS";
                if ($CGPA400 >= 4.5) {
                    $THE_REMARK[$i] = "VL";
                } elseif ($CGPA400 >= 4) {
                    $THE_REMARK[$i] = "DL";
                }
            } else {
                $THE_REMARK[$i] = "DEF";
            }

            if ($CGPAPresent < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            }

            if ($DE300Senate == True) {
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                }
            }
        }
        if ($CrTakePresent == 0) {
            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }
        }
    }
    if ($SessCount == 5) {
        if ($CGPA500 < $ProbPoint) {
            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP2";
                } else {
                    $THE_REMARK[$i] = "SP1";
                }
            }
        } else {
            if ($Total_C_F + $TotGetUnit2 == 0) {
                $THE_REMARK[$i] = "IGS";
                if ($CGPA400 >= 4.5) {
                    $THE_REMARK[$i] = "VL";
                } elseif ($CGPA400 >= 4) {
                    $THE_REMARK[$i] = "DL";
                }
            } else {
                $THE_REMARK[$i] = "DEF";
            }

            if ($CGPAPresent < $ProbPoint) {
                $THE_REMARK[$i] = "P";
            }

            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                }
            }
        }
        if ($CrTakePresent == 0) {
            if ($DE300Senate == True) {
                if ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } elseif ($DE200Senate == True) {
                if ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            } else {
                if ($CGPA100 < $ProbPoint) {
                    if ($CGPA200 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA200 < $ProbPoint) {
                    if ($CGPA300 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA300 < $ProbPoint) {
                    if ($CGPA400 < $ProbPoint) {
                        $THE_REMARK[$i] = "SP2";
                    }
                } elseif ($CGPA400 < $ProbPoint) {
                    $THE_REMARK[$i] = "SP1";
                } else {
                    $THE_REMARK[$i] = "DEF";
                }
            }
        }
    }
}

$cursemcourses[$i] = $getcursemcourses;

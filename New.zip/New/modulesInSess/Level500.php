<?php
$CrTake100 = 0;
$CrPass100 = 0;
$GrPoint100 = 0;
$CGPA100 = 0;

$CrTake200 = 0;
$CrPass200 = 0;
$GrPoint200 = 0;
$CGPA200 = 0;

$CrTake300 = 0;
$CrPass300 = 0;
$GrPoint300 = 0;
$CGPA300 = 0;

$CrTake400 = 0;
$CrPass400 = 0;
$GrPoint400 = 0;
$CGPA400 = 0;

$CrTake500 = 0;
$CrPass500 = 0;
$GrPoint500 = 0;
$CGPA500 = 0;

$CrTakePrev = 0;
$CrPassPrev = 0;
$GrPointPrev = 0;
$CGPAPrev = 0;

$CrTakePrev1ST = 0;
$CrPassPrev1ST = 0;
$GrPointPrev1ST = 0;
$CGPAPrev1ST = 0;

$CrTakePrevOnly = 0;
$CrPassPrevOnly = 0;
$GrPointPrevOnly = 0;
$CGPAPrevOnly = 0;

$CrTakePresent = 0;
$CrPassPresent = 0;
$GrPointPresent = 0;
$CGPAPresent = 0;
$getcursemcourses = "";
$semgrade = "";

$sem_C_F = 0;
$prev_C_F = 0;
$cum_C_F = 0;
$numb_Course_failed = 0;

//Grad Requirement
//unset($stuRequiremt);
//$stuRequiremt[]="";
//unset($stuRequiremtUnit);
//$stuRequiremtUnit[]=0;
//$CountstuRequiremt=0;
// Requirement
/*unset($getstuRequiremt);
$getstuRequiremt[]="";
unset($getstuRequiremtUnit);
$getstuRequiremtUnit[]=0;
$countgetstuRequiremt=0;*/

//Get Outstanding Courses
unset($regcoursesarray);
$regcoursesarray[] = "";
$countcoursesarray = 0;
unset($GCodecoursesarray);
$GCodecoursesarray[] = "";
$countGCodesarray = 0;

$NoOutstandCourse = 0;
$TotGetUnit2 = 0;

//Difficiency Courses
unset($PassedCoursearray);
$PassedCoursearray[] = "";
$countPassedCoursearray = 0;
unset($FailedCoursearray);
$FailedCoursearray[] = "";
$countFailedCoursearray = 0;

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$deptdb = $_SESSION['deptdb'];
$dept_db = $deptdb . strtolower($getdept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

if ($_SESSION['deptoption'] == "YES") {
    $getdeptOpt2 = $_SESSION["getdeptOpt"];
} else {
    $getdeptOpt2 = "NOP";
}


if ($_SESSION['curricul'] == "YES") {
    $curri = $_SESSION["curri"];
    if ($curri == "OLD") {
        $curri2 = "";
    } else {
        $curri2 = "_" . $curri;
    }
    $getGencourse = "gencourses" . $curri2;
} else {
    $getGencourse = "gencourses";
    $curri = "OLD";
}


for ($j = 1; $j <= $StuSessCount; $j++) {

    $StuCurSess = str_ireplace("/", "_", $getstuSession[$j]);
    $deptcorreg = "correg_" . $StuCurSess;
    if ($GetTheSemester == "1ST") {
        if ($getstuSession[$j] == $GetTheSession) {
            $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]' AND SessionRegis  = '$getstuSession[$j]' AND SemTaken  = '1ST' AND coursecondon = 'NO'";
        } else {
            $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]' AND SessionRegis  = '$getstuSession[$j]' AND coursecondon = 'NO'";
        }
    } else {
        $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]' AND SessionRegis  = '$getstuSession[$j]' AND coursecondon = 'NO'";
    }

    $result2 = $conn_stu->query($sql2);
    if ($result2->num_rows > 0) {
        while ($row2 = $result2->fetch_assoc()) {
            $CCode1 = $row2["CCode"];

            $countcoursesarray++;
            $regcoursesarray[$countcoursesarray] = $CCode1;
            if ($row2["Grouping2"] != "NO") {
                $countGCodesarray++;
                $GCodecoursesarray[$countGCodesarray] = $row2["Grouping2"];
            }
            //$SemTake100 = strtoupper($row2["SemTaken"]);
            if (empty($row2['CA'])) {
                $repairCA = 0;
            } else {
                $repairCA = (float)$row2['CA'];
            }

            if (empty($row2['Exam'])) {
                $repairEXAM = 0;
            } else {
                $repairEXAM = (float)$row2['Exam'];
            }


            $getCCode = $row2["CCode"];
            $sql3 = "SELECT Level1 FROM " . $getGencourse . " WHERE C_codding  = '$getCCode'";
            $result3 = $conn_stu->query($sql3);
            if ($result3->num_rows > 0) {
                while ($row3 = $result3->fetch_assoc()) {
                    $course_level = $row3["Level1"];
                }
            } else {
                $course_level = 100;
            }

            $repairUNIT = (int)$row2["CUnit"];
            if ($row2["noexam"] == "YES") {
                $repairTOTAL = 0;
            } else {
                $repairTOTAL = $repairCA + $repairEXAM;
            }

            $store_cs_code = $row2["CCode"];


            $semgrade = $row2["grade"];
            $sngReCGP = $row2["point"];


            if ($row2["SessionRegis"] < $GetTheSession) {
                $CrTake400 = $CrTake400 + $repairUNIT;
                $GrPoint400 = $GrPoint400 + $sngReCGP;
            }

            if ($row2["SessionRegis"] <= $StuSession[3]) {
                $CrTake300 = $CrTake300 + $repairUNIT;
                $GrPoint300 = $GrPoint300 + $sngReCGP;
            }

            if ($row2["SessionRegis"] <= $StuSession[2]) {
                $CrTake200 = $CrTake200 + $repairUNIT;
                $GrPoint200 = $GrPoint200 + $sngReCGP;
            }

            if ($row2["SessionRegis"] <= $StuSession[1]) {
                $CrTake100 = $CrTake100 + $repairUNIT;
                $GrPoint100 = $GrPoint100 + $sngReCGP;
            }

            if ($row2["SessionRegis"] == $GetTheSession && $row2["SemTaken"] == $GetTheSemester) {
                $CrTakePresent = $CrTakePresent + $repairUNIT;
                if ($repairTOTAL >= 40) {
                    $CrPassPresent = $CrPassPresent + $repairUNIT;
                } else {
                    $sem_C_F += $repairUNIT;
                }
                $GrPointPresent = $GrPointPresent + $sngReCGP;
                $getcursemcourses = $getcursemcourses . $row2["CCode"] . "(" . $semgrade . ")" . "(" . $repairUNIT . "), ";

                $sql4 = "SELECT * FROM grade_cursem WHERE CCode  = '$CCode1' AND session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND deptOption =  '$getdeptOpt2' AND curriculum =  '$curri'";
                $result4 = $conn->query($sql4);
                if ($result4->num_rows == 0) {
                    $sql5 = "INSERT INTO grade_cursem (CCode, session1, SemTaken, Level1, DeptCode, deptOption, curriculum, course_level)VALUES('$CCode1', '$GetTheSession', '$GetTheSemester', '$txtLevelPlus', '$getdept', '$getdeptOpt2', '$curri', '$course_level')";
                    $result5 = $conn->query($sql5);
                }
            }

            if ($row2["SessionRegis"] < $GetTheSession) {
                $CrTakePrev = $CrTakePrev + $repairUNIT;
                if ($repairTOTAL >= 40) {
                    $CrPassPrev = $CrPassPrev + $repairUNIT;
                }
                $GrPointPrev = $GrPointPrev + $sngReCGP;
            }
            $CrTake500 = $CrTake500 + $repairUNIT;
            if ($repairTOTAL >= 40) {
                $CrPass500 = $CrPass500 + $repairUNIT;
                $countPassedCoursearray++;
                $PassedCoursearray[$countPassedCoursearray] = $CCode1;
            } else {
                $countFailedCoursearray++;
                $FailedCoursearray[$countFailedCoursearray] = $CCode1;
            }
            $GrPoint500 = $GrPoint500 + $sngReCGP;


            if ($row2["SessionRegis"] == $GetTheSession && $row2["SemTaken"] == '1ST' && $GetTheSemester == '2ND') {
                $CrTakePrev1ST = $CrTakePrev1ST + $repairUNIT;
                if ($repairTOTAL >= 40) {
                    $CrPassPrev1ST = $CrPassPrev1ST + $repairUNIT;
                } else {
                    $prev_C_F += $repairUNIT;
                }
                $GrPointPrev1ST = $GrPointPrev1ST + $sngReCGP;
            }
        }
    }
}
$conn->close();
$conn2->close();
$conn_stu->close();



include 'modulesInSess/GetOutsDiff.php';

$cum_C_F = $Total_C_F + $TotGetUnit2;

if (($Total_C_F + $TotGetUnit2) == 0) {
    $strDefficiency = "";
} else {
    //$strDefficiency = $Credit_Fail . "/" . $Outstand . " = " . ($Total_C_F + $TotGetUnit2);
    $strDefficiency = $Credit_Fail . "/" . $Outstand;
}

if ($CrTakePresent == 0) {
    $CGPAPresent = 0;
} else {
    $CGPAPresent = $GrPointPresent / $CrTakePresent;
}

if ($GetTheSemester == '2ND') {
    $CrTakePrev = $CrTakePrev1ST + $CrTakePrev;
    $CrPassPrev = $CrPassPrev1ST + $CrPassPrev;
    $GrPointPrev = $GrPointPrev1ST + $GrPointPrev;
}
if ($CrTakePrev == 0) {
    $CGPAPrev = 0;
} else {
    $CGPAPrev = $GrPointPrev / $CrTakePrev;
}
if ($CrTake500 == 0) {
    $CGPA500 = 0;
} else {
    $CGPA500 = $GrPoint500 / $CrTake500;
}
if ($CrTake400 == 0) {
    $CGPA400 = 0;
} else {
    $CGPA400 = $GrPoint400 / $CrTake400;
}
if ($CrTake300 == 0) {
    $CGPA300 = 0;
} else {
    $CGPA300 = $GrPoint300 / $CrTake300;
}
if ($CrTake200 == 0) {
    $CGPA200 = 0;
} else {
    $CGPA200 = $GrPoint200 / $CrTake200;
}
if ($CrTake100 == 0) {
    $CGPA100 = 0;
} else {
    $CGPA100 = $GrPoint100 / $CrTake100;
}

    //$no_of_failure = $n;
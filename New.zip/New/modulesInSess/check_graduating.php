<?php

unset($corecoursearray);
$corecoursearray[] = "";
$corecoursecount = 0;
unset($groupCodearray);
$groupCodearray[] = "";
$groupCodecount = 0;


//DE 200
unset($DE200corecoursearray);
$DE200corecoursearray[] = "";
$DE200corecoursecount = 0;
unset($DE200groupCodearray);
$DE200groupCodearray[] = "";
$DE200groupCodecount = 0;

//DE 300
unset($DE300corecoursearray);
$DE300corecoursearray[] = "";
$DE300corecoursecount = 0;
unset($DE300groupCodearray);
$DE300groupCodearray[] = "";
$DE300groupCodecount = 0;

//Grad Requirement
unset($stuRequiremt);
$stuRequiremt[] = "";
$CountstuRequiremt = 0;

//Get Outstanding Courses
unset($regcoursesarray);
$regcoursesarray[] = "";
$countcoursesarray = 0;
unset($GCodecoursesarray);
$GCodecoursesarray[] = "";
$countGCodesarray = 0;

$NoOutstandCourse = 0;
$TotGetUnit2 = 0;

//Difficiency Courses
unset($PassedCoursearray);
$PassedCoursearray[] = "";
$countPassedCoursearray = 0;
unset($FailedCoursearray);
$FailedCoursearray[] = "";
$countFailedCoursearray = 0;

$CrTake500 = 0;
$CrPass500 = 0;
$GrPoint500 = 0;
$CGPA500 = 0;

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$deptdb = $_SESSION['deptdb'];
$dept_db = $deptdb . strtolower($getdept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

$sql2 = "SELECT entry_session, matric_no, entry_level FROM std_data_view WHERE matric_no = '$regid'";
$result2 = $conn2->query($sql2);
if ($result2->num_rows > 0) {
    while ($row2 = $result2->fetch_assoc()) {
        $StartYear = substr($row2['entry_session'], 0, 4);
        $EntryLevel = $row2['entry_level'];
    }
}

$FinalYear = $getyeargrad;
//$StartYear = substr($regid, 0, 4);
for ($x = $StartYear; $x <= $FinalYear; $x++) {
    $getstuSession2 = $x . "/" . ($x + 1);

    $StuCurSess = str_ireplace("/", "_", $getstuSession2);
    $deptcorreg = "correg_" . $StuCurSess;

    $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid'";
    $result2 = $conn_stu->query($sql2);
    if ($result2->num_rows > 0) {
        while ($row2 = $result2->fetch_assoc()) {
            $CCode1 = $row2["CCode"];

            $countcoursesarray++;
            $regcoursesarray[$countcoursesarray] = $CCode1;

            if ($row2["Grouping"] != "NO") {
                $countGCodesarray++;
                $GCodecoursesarray[$countGCodesarray] = $row2["Grouping"];
            }

            if (empty($row2['CA'])) {
                $repairCA = 0;
            } else {
                $repairCA = (float)$row2['CA'];
            }

            if (empty($row2['Exam'])) {
                $repairEXAM = 0;
            } else {
                $repairEXAM = (float)$row2['Exam'];
            }

            if ($row2["noexam"] == "YES") {
                $repairTOTAL = 0;
            } else {
                $repairTOTAL = $repairCA + $repairEXAM;
            }
            $repairUNIT = (int)$row2["CUnit"];

            $sngReCGP = $row["point"];


            $CrTake500 = $CrTake500 + $repairUNIT;
            $GrPoint500 = $GrPoint500 + $sngReCGP;
            if ($repairTOTAL >= 40) {
                $CrPass500 = $CrPass500 + $repairUNIT;
                $countPassedCoursearray++;
                $PassedCoursearray[$countPassedCoursearray] = $CCode1;
            } else {
                $countFailedCoursearray++;
                $FailedCoursearray[$countFailedCoursearray] = $CCode1;
            }
        }
    }
}

if ($CrTake500 == 0) {
    $CGPA500 = 0;
} else {
    $CGPA500 = $GrPoint500 / $CrTake500;
}

$sql6 = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
$result6 = $conn2->query($sql6);
if ($result6->num_rows > 0) {
    while ($row6 = $result6->fetch_assoc()) {
        $curri = $row6["curriculum"];
    }
}
if ($curri == "OLD") {
    $curri2 = "";
} else {
    $curri2 = "_" . $curri;
}
$deptgencourses = "gencourses" . $curri2;


if ($EntryLevel == 200) {
    $NON_DE_Senate = false;
    $DE200Senate = true;
    $DE300Senate = false;



    if ($deptoption == "YES") {
        $CoreGetOption = "Core_" . $Deptopt2;
        $CoreDE200GetOption = "CoreDE200_" . $Deptopt2;
        $CoreDE300GetOption = "CoreDE300_" . $Deptopt2;
        $GroupOption = "Group" . $Deptopt2;

        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE200GetOption . " = 'YES' AND " . $GroupOption . " = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE200corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE200corecoursearray[$DE200corecoursecount] = $CCode2;
            }
        }
    } else {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Grouping = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE200corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE200corecoursearray[$DE200corecoursecount] = $CCode2;
            }
        }
    }

    if ($deptoption == "YES") {
        $CoreGetOption = "Core_" . $Deptopt2;
        $CoreDE200GetOption = "CoreDE200_" . $Deptopt2;
        $CoreDE300GetOption = "CoreDE300_" . $Deptopt2;
        $GroupOption = "Group" . $Deptopt2;

        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$Deptopt2'";
        $result5 = $conn->query($sql5);
        if ($result5->num_rows > 0) {
            while ($row5 = $result5->fetch_assoc()) {
                $GetOptCourse = $row5["GroupCode"];
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE200GetOption . " = 'YES' AND " . $GroupOption . " = '$GetOptCourse'";
                $result6 = $conn->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE200groupCodecount++;
                    $DE200groupCodearray[$DE200groupCodecount] = $GetOptCourse;
                }
            }
        }
    } else {
        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
        $result5 = $conn->query($sql5);
        if ($result5->num_rows > 0) {
            while ($row5 = $result5->fetch_assoc()) {
                $GetOptCourse = $row5["GroupCode"];
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Grouping = '$GetOptCourse'";
                $result6 = $conn->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE200groupCodecount++;
                    $DE200groupCodearray[$DE200groupCodecount] = $GetOptCourse;
                }
            }
        }
    }
} elseif ($EntryLevel == 300) {
    $NON_DE_Senate = false;
    $DE200Senate = false;
    $DE300Senate = true;
    //include 'modulesInSess/SubProcessResultsDE300.php';

    if ($deptoption == "YES") {
        $CoreGetOption = "Core_" . $Deptopt2;
        $CoreDE200GetOption = "CoreDE200_" . $Deptopt2;
        $CoreDE300GetOption = "CoreDE300_" . $Deptopt2;
        $GroupOption = "Group" . $Deptopt2;

        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE300GetOption . " = 'YES' AND " . $GroupOption . " = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE300corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE300corecoursearray[$DE300corecoursecount] = $CCode2;
            }
        }
    } else {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Grouping = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $DE300corecoursecount++;
                $CCode2 = $row6["C_codding"];
                //$GetUnit2 = $row6["credit"];
                $DE300corecoursearray[$DE300corecoursecount] = $CCode2;
            }
        }
    }

    if ($deptoption == "YES") {
        $CoreGetOption = "Core_" . $Deptopt2;
        $CoreDE200GetOption = "CoreDE200_" . $Deptopt2;
        $CoreDE300GetOption = "CoreDE300_" . $Deptopt2;
        $GroupOption = "Group" . $Deptopt2;

        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$Deptopt2'";
        $result5 = $conn->query($sql5);
        if ($result5->num_rows > 0) {
            while ($row5 = $result5->fetch_assoc()) {
                $GetOptCourse = $row5["GroupCode"];
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreDE300GetOption . " = 'YES' AND " . $GroupOption . " = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE300groupCodecount++;
                    $DE300groupCodearray[$DE300groupCodecount] = $GetOptCourse;
                }
            }
        }
    } else {
        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
        $result5 = $conn->query($sql5);
        if ($result5->num_rows > 0) {
            while ($row5 = $result5->fetch_assoc()) {
                $GetOptCourse = $row5["GroupCode"];
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE CoreDE200 = 'YES' AND Grouping = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $DE300groupCodecount++;
                    $DE300groupCodearray[$DE300groupCodecount] = $GetOptCourse;
                }
            }
        }
    }
} else {
    $NON_DE_Senate = true;
    $DE200Senate = false;
    $DE300Senate = false;

    if ($deptoption == "YES") {
        //$GetOpt = $getdeptOpt;
        $CoreGetOption = "Core_" . $Deptopt2;
        $CoreDE200GetOption = "CoreDE200_" . $Deptopt2;
        $CoreDE300GetOption = "CoreDE300_" . $Deptopt2;
        $GroupOption = "Group" . $Deptopt2;

        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND " . $GroupOption . " = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                $corecoursearray[$corecoursecount] = $CCode2;
            }
        }
    } else {
        $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Grouping = 'NO'";
        $result6 = $conn_stu->query($sql6);
        if ($result6->num_rows > 0) {
            while ($row6 = $result6->fetch_assoc()) {
                $corecoursecount++;
                $CCode2 = $row6["C_codding"];
                $corecoursearray[$corecoursecount] = $CCode2;
            }
        }
    }

    if ($deptoption == "YES") {

        //$GetOpt = $getdeptOpt;
        $CoreGetOption = "Core_" . $Deptopt2;
        $CoreDE200GetOption = "CoreDE200_" . $Deptopt2;
        $CoreDE300GetOption = "CoreDE300_" . $Deptopt2;
        $GroupOption = "Group" . $Deptopt2;

        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept' AND OptCode = '$Deptopt2'";
        $result5 = $conn->query($sql5);
        if ($result5->num_rows > 0) {
            while ($row5 = $result5->fetch_assoc()) {
                $GetOptCourse = $row5["GroupCode"];
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE " . $CoreGetOption . " = 'YES' AND " . $GroupOption . " = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $groupCodecount++;
                    $groupCodearray[$groupCodecount] = $GetOptCourse;
                }
            }
        }
    } else {
        $sql5 = "SELECT * FROM grouping_couses WHERE DeptCode = '$getdept'";
        $result5 = $conn->query($sql5);
        if ($result5->num_rows > 0) {
            while ($row5 = $result5->fetch_assoc()) {
                $GetOptCourse = $row5["GroupCode"];
                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE Core = 'YES' AND Grouping = '$GetOptCourse'";
                $result6 = $conn_stu->query($sql6);
                if ($result6->num_rows > 0) {
                    $groupCodecount++;
                    $groupCodearray[$groupCodecount] = $GetOptCourse;
                }
            }
        }
    }
}
$conn->close();
$conn2->close();
$conn_stu->close();

include 'modulesInSess/GetOutsDiff_grad.php';

if (($Total_C_F + $TotGetUnit2) == 0) {
    $strDefficiency = "";
} else {
    $strDefficiency = $Credit_Fail . "/" . $Outstand . " = " . ($Total_C_F + $TotGetUnit2);
}

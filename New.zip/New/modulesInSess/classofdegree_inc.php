<?php
//$Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;
if ($_SESSION['InstType'] == "University") {
    if ($cgpa >= 4.495) {
        $classdegree = "First Class";
        $Countfirst++;
        $classdegree_code = 1;
    } elseif ($cgpa >= 3.495) {
        $classdegree = "Second Class Upper";
        $Count2Upper++;
        $classdegree_code = 2;
    } elseif ($cgpa >= 2.395) {
        $classdegree = "Second Class Lower";
        $Count2Lower++;
        $classdegree_code = 3;
    } elseif ($cgpa >= 1.495) {
        $classdegree = "Third Class";
        $Count3Class++;
        $classdegree_code = 4;
    } else {
        $classdegree = "Pass";
        $CountPass++;
        $classdegree_code = 5;
    }
} elseif ($_SESSION['InstType'] == "Polytechnic") {
    if ($cgpa >= 3.5) {
        $classdegree = "Distinction";
        $classdegree_code = "D";
        $Countfirst++;
    } elseif ($cgpa >= 3) {
        $classdegree = "Upper Credit";
        $classdegree_code = "U/C";
        $Count2Upper++;
    } elseif ($cgpa >= 2.5) {
        $classdegree = "Lower Credit";
        $classdegree_code = "L/C";
        $CountPass++;
    } elseif ($cgpa >= 2) {
        $classdegree = "Pass";
        $classdegree_code = "PAS";
        $CountPass++;
    } else {
        $classdegree = "Fail";
        $classdegree_code = "F";
        $CountFail++;
    }
} else {
}

// Check 
//1. stu_perfom_graph.php
//2. graduation_summary.php
//3. graduation_summarysex.php
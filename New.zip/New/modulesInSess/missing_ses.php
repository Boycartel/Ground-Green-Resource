<?php
$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql5 = "SELECT * FROM missing_session WHERE matno = '$matno' AND session = '$indSession' AND semester = '$semtake'";
$result5 = $conn->query($sql5);
if ($result5->num_rows > 0) {
    while ($row5 = $result5->fetch_assoc()) {
        $response = $row5['response'] . ".png";
    }
} else {
    $response = "Abscond.png";
}
$conn->close();

echo "<img src='img/$response' alt='logo' style='width: 250px; height: 200px;' />";

<?php

for ($j = 0; $j < $countSesRes[$arrayNumb]; $j++) {
    $ccode2 = $ccode_tot[$arrayNumb][$j];
    $ctitle2 = $ctitle_tot[$arrayNumb][$j];
    $cunit2 = $cunit_tot[$arrayNumb][$j];
    $grade2 = $grade_tot[$arrayNumb][$j];
    $gpoint2 = $gpoint_tot[$arrayNumb][$j];

    echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode2</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle2</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit2</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade2</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$gpoint2</td></tr>";
}

<?php
require_once '../includes/db_connect2.php';

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: ../home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title>FUTMinna Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword" content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="../assets/images/favicon.png">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="../assets/vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="../assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="../assets/vendor/select2/select2.css" />
    <link rel="stylesheet" href="../assets/vendor/jquery-datatables-bs3/assets/css/datatables.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="../assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="../assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="../assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="../assets/vendor/modernizr/modernizr.js"></script>

    <script src="../inline_edit/jquery.min.js"></script>

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <!--To Prevent Backward-->
    <!--<script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>-->
    <style>
        th {
            font-size: 12px;
        }
    </style>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        //include_once '../includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            //include_once '../includes/aside_menu_staff.php';
            $success = "";
            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header">
                    <h2>Set Session</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-file"></i>
                                </a>
                            </li>
                            <li><span>Settings</span></li>
                            <li><span>Set Session</span></li>
                        </ol>


                    </div>
                </header>

                <!-- start: page -->
                <?php
                set_time_limit(1000);
                $GetTheSession = $_SESSION['resultsession'];
                /*$sql = "SELECT * FROM gencoursesupload WHERE Department = 'MAT'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $ccode = $row["C_codding"];
                    $GetTheSession2 = str_replace("/", "_", $GetTheSession);
                    $sql2 = "SELECT * FROM courses_register_".$GetTheSession2." WHERE CCode = '$ccode'";
                    $result2 = $conn->query($sql2);
                    $countstu=mysqli_num_rows($result2);

                    $sql3 = "UPDATE gencoursesupload SET totStu = '$countstu' WHERE C_codding = '$ccode'";
                    $result3 = $conn->query($sql3);
                }
            }*/

                if (isset($_POST["submit_reg"])) {
                    // For 3 Years 2014/2015, 2015/2016, 2016/2017
                    // For 3 Years 2017/2018, 2018/2019, 2019/2020
                    // For 3 Years 2020/2021, 2021/2022, 2022/2022

                    $deptsessgroup = "correg_2020_2022";

                    $dbsession = "2021_2022";
                    //$dbsession = "2020_2022";
                    //$sessDept = "cpe";
                    $sql = "select 1 from correg_" . $dbsession;
                    $exists = $conn_dept->query($sql);

                    if ($exists == false) {
                        $TabCreate = "correg_" . $dbsession;
                        $sql = "CREATE TABLE " . $TabCreate . " SELECT * FROM correg_empty";
                        $result = $conn_dept->query($sql);

                        $sql = "ALTER TABLE " . $TabCreate . " ADD column id int NOT NULL auto_increment Primary Key";
                        $result = $conn_dept->query($sql);

                        /* $FYear = substr($dbsession, 0, 4);
                        for ($i = 1; $i <= 3; $i++) {
                            $getSession = $FYear . "/" . ($FYear + 1);
                            $FYear = $FYear + 1;

                            $sql = "SELECT * FROM session_interval WHERE sess_interval = '$dbsession' AND sessions = '$getSession'";
                            $result = $conn->query($sql);
                            if ($result->num_rows == 0) {
                                $sql6 = "INSERT INTO session_interval(sess_interval, sessions)VALUES('$dbsession', '$getSession')";
                                $result6 = $conn->query($sql6);
                            }
                        } */
                    }

                    set_time_limit(1000);

                    $sessmigr = str_replace("_", "/", $dbsession);

                    $sql = "SELECT * FROM " . $deptsessgroup . " WHERE SessionRegis = '$sessmigr'";

                    $result = $conn_dept->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $id = $row["id"];
                            $CCode = $row["CCode"];
                            $CTitle = $row["CTitle"];
                            $CNature = $row["CNature"];
                            $CUnit = $row["CUnit"];
                            $SemTaken = $row["SemTaken"];
                            $SessionRegis = $row["SessionRegis"];
                            $CA = $row["CA"];
                            $Exam = $row["Exam"];
                            $grade = $row["grade"];
                            $Grouping = $row["Grouping"];
                            $Regn1 = $row["Regn1"];
                            $coursecondon = $row["coursecondon"];
                            $noexam = $row["noexam"];
                            $deptOption = $row["deptOption"];
                            $curriculum = $row["curriculum"];
                            $point = $row["point"];

                            $sql6 = "INSERT INTO correg_" . $dbsession . "(CCode, CTitle, CNature, CUnit, SemTaken, SessionRegis, CA, Exam, grade, Grouping, Regn1, coursecondon, noexam, deptOption, point, curriculum) VALUES ('$CCode', '$CTitle', '$CNature', '$CUnit', '$SemTaken', '$SessionRegis', '$CA', '$Exam', '$grade', '$Grouping', '$Regn1', '$coursecondon', '$noexam', '$deptOption', '$point', '$curriculum')";
                            $result6 = $conn_dept->query($sql6);

                            $sql2 = "DELETE FROM " . $deptsessgroup . " WHERE id = '$id'";
                            $result2 = $conn_dept->query($sql2);
                        }
                    }
                }

                if (isset($_POST["submit_grade"])) {
                    set_time_limit(1000);
                    $sql = "SELECT * FROM cpe_correg";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $id = $row["id"];

                            $CA = $row["CA"];
                            $Exam = $row["Exam"];
                            $CUnit = $row["CUnit"];
                            $total = $CA + $Exam;


                            if ($total >= 75) {
                                $grade = "A";
                                $point = 4 * $CUnit;
                            } elseif ($total >= 70) {
                                $grade = "AB";
                                $point = 3.5 * $CUnit;
                            } elseif ($total >= 65) {
                                $grade = "B";
                                $point = 3.25 * $CUnit;
                            } elseif ($total >= 60) {
                                $grade = "BC";
                                $point = 3 * $CUnit;
                            } elseif ($total >= 55) {
                                $grade = "C";
                                $point = 2.75 * $CUnit;
                            } elseif ($total >= 50) {
                                $grade = "CD";
                                $point = 2.5 * $CUnit;
                            } elseif ($total >= 45) {
                                $grade = "D";
                                $point = 2.25 * $CUnit;
                            } elseif ($total >= 40) {
                                $grade = "E";
                                $point = 2 * $CUnit;
                            } else {
                                $grade = "F";
                                $point = 0;
                            }


                            $sql2 = "UPDATE cpe_correg SET grade ='$grade', point ='$point' WHERE id  = '$id'";
                            $result2 = $conn->query($sql2);
                        }
                    }
                }


                if (isset($_POST["submit_core"])) {
                    $sql = "SELECT * FROM core";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $ccode = $row["CCourse"];

                            $sql2 = "UPDATE cpe_gencourses SET Core ='YES' WHERE C_codding  = '$ccode'";
                            $result2 = $conn->query($sql2);
                        }
                    }

                    $sql = "SELECT * FROM core_de200";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $ccode = $row["CCourse"];

                            $sql2 = "UPDATE cpe_gencourses SET CoreDE200 ='YES' WHERE C_codding  = '$ccode'";
                            $result2 = $conn->query($sql2);
                        }
                    }

                    $sql = "SELECT * FROM core_de300";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $ccode = $row["CCourse"];

                            $sql2 = "UPDATE cpe_gencourses SET CoreDE300 ='YES' WHERE C_codding  = '$ccode'";
                            $result2 = $conn->query($sql2);
                        }
                    }
                }

                if (isset($_POST["submit_Course_reg"])) {
                    set_time_limit(1000);
                    $sql = "SELECT * FROM courses_register WHERE session = '2021/2022'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $id = $row["sn"];
                            $Regn1 = $row["Regn1"];
                            $name1 = $row["name1"];
                            $CCode = $row["CCode"];
                            $CUnit = $row["CUnit"];
                            $CTitle = $row["CTitle"];
                            $SemTaken = $row["SemTaken"];
                            $Nature = $row["Nature"];
                            $session = $row["session"];
                            $departments = $row["departments"];
                            $date = $row["date"];

                            $sql6 = "INSERT INTO courses_register_2021_2022(Regn1, name1, CCode, CUnit, CTitle, SemTaken, Nature, session, departments, date) VALUES ('$Regn1', '$name1', '$CCode', '$CUnit', '$CTitle', '$SemTaken', '$Nature', '$session', '$departments', '$date')";
                            $result6 = $conn->query($sql6);

                            $sql2 = "DELETE FROM courses_register WHERE sn = '$id'";
                            $result2 = $conn->query($sql2);
                        }
                    }
                }

                if (isset($_POST["submit_Update_StuProfil"])) {
                    set_time_limit(1000);
                    //$sql = "SELECT * FROM stdprofile WHERE Deptcode = 'MAT'";
                    $sql = "SELECT * FROM stdprofile";
                    $result = $conn2->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $id = $row["id"];
                            $Regn1 = $row["regid"];
                            $yearadmtDE = "XXXX";
                            $yearadmt = substr($Regn1, 0, 4);
                            $admtmode = substr($Regn1, 5, 1);
                            if ($yearadmt == "2021") {
                                if ($admtmode == 2) {
                                    $yearadmtDE = $yearadmt;
                                    $yearadmt = $yearadmt - 2;
                                } elseif ($admtmode == 3) {
                                    $yearadmtDE = $yearadmt;
                                    $yearadmt = $yearadmt - 3;
                                }
                            } else {
                                if ($admtmode == 2) {
                                    $yearadmtDE = $yearadmt;
                                    $yearadmt = $yearadmt - 1;
                                } elseif ($admtmode == 3) {
                                    $yearadmtDE = $yearadmt;
                                    $yearadmt = $yearadmt - 2;
                                }
                            }


                            $names = $row["firstname"] . " " . $row["othername"] . " " . $row["surname"];
                            $sql2 = "UPDATE stdprofile SET YAddmitted ='$yearadmt', YAddmittedDir ='$yearadmtDE', curriculum = 'OLD', names ='$names' WHERE id  = '$id'";
                            $result2 = $conn2->query($sql2);
                        }
                    }
                }


                ?>
                <div class="row">

                    <section class="panel panel-success">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>

                        </header>
                        <div class="panel-body">
                            <div class="row">
                                <h2 style="color: blue; text-align: center"><?php echo $success ?></h2>
                                <div class="col-lg-6">
                                    <form class="form-horizontal form-bordered" method="post">

                                        <div class="row" style="text-align: right">
                                            <button type="submit" name="submit_reg" class="btn btn-primary btn-xs">Break
                                                CorReg</button>
                                        </div>
                                        <br><br><br>
                                        <div class="row" style="text-align: right">
                                            <button type="submit" name="submit_grade" class="btn btn-primary btn-xs">Add
                                                Grade</button>
                                        </div>
                                        <br><br><br>
                                        <div class="row" style="text-align: right">
                                            <button type="submit" name="submit_core" class="btn btn-primary btn-xs">Core
                                                Courses
                                            </button>
                                        </div>

                                        <br><br><br>
                                        <div class="row" style="text-align: right">
                                            <button type="submit" name="submit_Course_reg" class="btn btn-primary btn-xs">Course Reg Split
                                            </button>
                                        </div>

                                        <br><br><br>
                                        <div class="row" style="text-align: right">
                                            <button type="submit" name="submit_Update_StuProfil" class="btn btn-primary btn-xs">Update Stu Profile
                                            </button>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-6">

                                </div>
                            </div>

                        </div>
                        <br><br>

                    </section>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>



    <!-- Vendor -->
    <script src="../assets/vendor/jquery/jquery.js"></script>
    <script src="../assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="../assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="../assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="../assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="../assets/vendor/select2/select2.js"></script>
    <script src="../assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
    <script src="../assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
    <script src="../assets/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="../assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="../assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="../assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="../assets/javascripts/tables/examples.datatables.default.js"></script>
    <script src="../assets/javascripts/tables/examples.datatables.row.with.details.js"></script>
    <script src="../assets/javascripts/tables/examples.datatables.tabletools.js"></script>

    <!-- Specific Page Vendor -->
    <script src="../assets/vendor/pnotify/pnotify.custom.js"></script>


    <!-- Examples -->
    <script src="../assets/javascripts/ui-elements/examples.modals.js"></script>


</body>

</html>
<?php
require_once 'includes/db_connect.php';
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>School Portal</title>
    <link rel="shortcut icon" href="img/logo.ico">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">


    <div class="middle-box text-center animated fadeInDown">
        <h2>Reset Password</h2>

        <div class="error-desc">
            Enter your Matric number
            <form class="form-inline m-t" role="form" method="post">
                <div class="form-group">
                    <input type="text" name="regid" class="form-control" placeholder="File Number">
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>


    </div>
    <div>
        <?php
        if (isset($_POST['submitemail'])) {

            $to = $_POST['sendemail'];
            $subject = "New Password";
            $message = "This is an OTP number for you to reset your password:    ";
            $message .= $_POST['sendtoken'];
            $headers = "From: eresults@futminna.edu.ng";
            // Sending email
            if (mail($to, $subject, $message, $headers)) {
                $sno = $_POST['sno'];
                $sendtoken = $_POST['sendtoken'];
                $sql = "UPDATE std_login SET pwd_reset_token = '$sendtoken' WHERE id='$sno'";
                $result = $conn2->query($sql);

                echo "<h2  class='alert alert-success' style='text-align: center;'>";
                echo 'An OTP number has been sent to the email for you to reset your password<br>';
                echo $_POST['sendemail'];
                echo "<br>";
                echo "Check your inbox or spam folder";
                echo "<br>";
                echo "<a href= 'password_reset_stu.php' class='btn btn-primary'>Reset</a>";
                echo "</h2>";
            } else {
                /* $sno = $_POST['sno'];
                $sendtoken = $_POST['sendtoken'];
                $sql = "UPDATE std_login SET pwd_reset_token = '$sendtoken' WHERE id='$sno'";
                $result = $conn2->query($sql); */
                echo "<h2 class='alert alert-danger' style='text-align: center;'>";
                echo 'Unable to send email. Please try again.';
                echo "</h2>";

                /* echo "<h2  class='alert alert-success' style='text-align: center;'>";
                echo 'An OTP number has been sent to the email for you to reset your password<br>';
                echo $_POST['sendemail'];
                echo "<br>";
                echo "Check your inbox or spam folder";
                echo "<br>";
                echo "<a href= 'password_reset_stu.php' class='btn btn-primary'>Reset</a>";
                echo "</h2>"; */
            }
        }
        ?>
    </div>
    <?php if (isset($_POST['submit'])) { ?>
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="col-lg-2">

            </div>
            <div class="col-lg-8">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 style="text-align: center;">Click Send button to send OTP to your email</h3>
                    </div>
                    <div class="panel-body">
                        <?php
                        $regid = $_POST['regid'];
                        $regid = stripslashes($regid);
                        $regid = mysqli_real_escape_string($conn2, $regid);

                        $sql = "SELECT * FROM std_login WHERE stdid = '$regid'";
                        $result = $conn2->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $sn = $row["id"];
                                $active_status = $row['active_status'];
                            }
                            //$token = md5(rand() . time());
                            $token = rand(10000, 100000);
                        }

                        $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                        $result = $conn2->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                $email = $row["sch_email"];
                            }
                        }

                        $conn2->close();
                        ?>

                        <form role="form" enctype="multipart/form-data" method="post" action="">
                            <div class="form-group">
                                <label class="col-lg-5 control-label">PF Number</label>
                                <div class="col-lg-7">
                                    <?php echo strtoupper($regid) ?>
                                </div>
                                <br />
                            </div>
                            <br>
                            <div class="form-group">
                                <label class="col-lg-5 control-label">Staff Name:</label>
                                <div class="col-lg-7">
                                    <?php echo  $names ?>
                                </div>
                                <br />
                            </div>
                            <br>
                            <div class="form-group">
                                <label class="col-lg-5 control-label">Staff email:</label>
                                <div class="col-lg-7">
                                    <?php echo  $email ?>
                                    <input type="hidden" class="form-control" style="color:#000000" name="sendemail" value="<?php echo  $email ?>">
                                    <input type="hidden" class="form-control" style="color:#000000" name="sno" value="<?php echo  strtoupper($sn) ?>">
                                    <input type="hidden" class="form-control" style="color:#000000" name="sendtoken" value="<?php echo  $token ?>">
                                </div>
                                <br />
                            </div>
                            <br /><br>
                            <?php if ($active_status == 0) { ?>
                                <h2 class='alert alert-danger' style='text-align: center;'>You are NOT an Active Member</h2>
                            <?php } else { ?>
                                <div class="form-group">
                                    <label class="col-lg-5 control-label"></label>
                                    <div class="col-lg-offset-2 col-lg-7" style="text-align: right;">
                                        <button type="submit" name="submitemail" class="btn btn-primary">Send <i class="fa fa-send"></i></button>

                                    </div>
                                </div>
                            <?php } ?>
                        </form>



                    </div>
                </div>

            </div>
            <div class="col-lg-2">

            </div>

        </div>
    <?php } ?>
    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
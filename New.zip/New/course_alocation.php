<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

if ($_SESSION['course_alocation'] == false) {
    header('Location: Home_Staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Allocation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Allocation</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Allocation
                        </div>
                        <div class="panel-body">
                            <div>
                                <?php
                                //$cat = $_SESSION['cat'];
                                $curtsession = $_SESSION['corntsession'];
                                $dept = $_SESSION['deptcode'];
                                $schcode = $_SESSION['schcode'];

                                $inserted = "";
                                if (isset($_POST["submit"])) {
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $staffid = $_POST["getstaffid"];


                                    if (!empty($_POST["chosen"])) {
                                        foreach ($_POST["chosen"] as $key => $value) {

                                            //echo $_POST["chosen"][$key];


                                            $ccode = $_POST["ccode"][$key];
                                            $CTitle = str_replace("'", "''", $_POST["CTitle"][$key]);
                                            $CUnit = $_POST["CUnit"][$key];
                                            $SemTaken = $_POST["SemTaken"][$key];
                                            $teamleader = $_POST["teamleader"][$key];
                                            $Ctype = $_POST["Ctype"][$key];


                                            $sql = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND CCode = '$ccode' AND SessionReg = '$curtsession' AND curri = '$Ctype'";
                                            $result = $conn->query($sql);

                                            if ($result->num_rows == 0) {
                                                $sql2 = "INSERT INTO coursealocation (PFNo, CCode, CTitle, CUnit, Semester, SessionReg, Department, teamleader, ugpg, curri) VALUES ('$staffid', '$ccode', '$CTitle', '$CUnit', '$SemTaken', '$curtsession', '$dept', '$teamleader', 'ug', '$Ctype')";
                                                $result2 = $conn->query($sql2);
                                                if ($teamleader == "YES") {
                                                    $sql2 = "UPDATE coursealocation SET teamleader = 'NO' WHERE PFNo <> '$staffid' AND CCode = '$ccode' AND SessionReg = '$curtsession' AND curri = '$Ctype'";
                                                    $result2 = $conn->query($sql2);
                                                }
                                            } else {
                                                if ($teamleader == "YES") {
                                                    $sql2 = "UPDATE coursealocation SET teamleader = 'YES' WHERE PFNo = '$staffid' AND CCode = '$ccode' AND SessionReg = '$curtsession' AND curri = '$Ctype'";
                                                    $result2 = $conn->query($sql2);

                                                    $sql2 = "UPDATE coursealocation SET teamleader = 'NO' WHERE PFNo <> '$staffid' AND CCode = '$ccode' AND SessionReg = '$curtsession' AND curri = '$Ctype'";
                                                    $result2 = $conn->query($sql2);
                                                }
                                            }
                                        }

                                        $countC = 0;
                                        $sql2 = "SELECT * FROM coursealocation WHERE CCode = '$ccode'";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $countC++;
                                            }
                                        }
                                        if ($countC == 1) {
                                            $sql2 = "UPDATE coursealocation SET teamleader = 'YES' WHERE CCode = '$ccode'";
                                            $result2 = $conn->query($sql2);
                                        }

                                        $inserted = "Record Inserted";
                                    }
                                    $conn->close();
                                }
                                ?>




                                <div class="row" style="color:#000">

                                    <div class="col-lg-6 col-md-6">
                                        <h4>
                                            <center>Current Session: <?php echo $curtsession ?></center>
                                        </h4>
                                        <form class="form-horizontal" method="post">
                                            <div class="form-group">
                                                <label class="control-label col-lg-4" for="regid">Select
                                                    Status:</label>
                                                <div class="col-lg-6">
                                                    <select name="staffcat" class="country form-control" style="color:#000000" id="staffcat">
                                                        <option value=SelectItem>Select Item</option>
                                                        <?php if ($cat_Dean == "YES") { ?>
                                                            <option value=deptstaff>Faculty Staff</option>
                                                            <option value=outstaff>Outside Faculty</option>
                                                        <?php } else { ?>
                                                            <option value=deptstaff>Departmental Staff</option>
                                                            <option value=outstaff>Outside Department</option>
                                                        <?php } ?>

                                                    </select>

                                                </div>
                                                <div class="col-lg-2">
                                                    <button type="submit" name="liststatus" class="btn btn-primary btn-sm">OK</button>
                                                </div>
                                            </div>

                                            <?php
                                            if (isset($_POST["liststatus"])) {
                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }
                                                // Capture selected country
                                                $catstaff = $_POST["staffcat"];
                                                $dept = $_SESSION['deptcode'];

                                            ?>

                                                <div class="col-lg-8">
                                                    <div class="form-group">
                                                        <label class="control-label col-lg-6" for="regid">Select Course
                                                            Lecturer:</label>
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <select name="getstaffid" class="form-control" style="color:#000000" id="getstaffid" required>
                                                                    <?php
                                                                    if ($catstaff == "deptstaff") {
                                                                        if ($cat_Dean == "YES") {
                                                                            $sql = "SELECT * FROM users WHERE SchCode = '$schcode' ORDER BY staffid";
                                                                        } else {
                                                                            $sql = "SELECT * FROM users WHERE staffacddept = '$dept' ORDER BY staffid";
                                                                        }
                                                                    } elseif ($catstaff == "outstaff") {
                                                                        $sql = "SELECT * FROM users ORDER BY staffid";
                                                                    }
                                                                    $result = $conn->query($sql);

                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $staffid = $row["staffid"];
                                                                            $staffname = $row["full_name"];
                                                                    ?>
                                                                            <option value='<?php echo $staffid ?>'>
                                                                                <?php echo $staffid . " " . $staffname ?>
                                                                            </option>
                                                                    <?php

                                                                        }
                                                                    }

                                                                    ?>
                                                                </select>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>

                                            <?php
                                                $conn->close();
                                            }
                                            ?>

                                            <br />
                                            <?php
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            $numbschCurri = $_SESSION['numbschCurri'];
                                            echo "<center><h4 style='color:#009'>$inserted</h4></center>";
                                            if ($cat_Dean == "YES" && $cat_HOD == "YES") {
                                                $sql = "SELECT * FROM gencoursesupload WHERE Department = '$schcode' OR Department = '$dept' ORDER BY C_codding";
                                            } elseif ($cat_Dean == "NO" && $cat_HOD == "YES") {
                                                $sql = "SELECT * FROM gencoursesupload WHERE Department = '$dept' ORDER BY C_codding";
                                            } elseif ($cat_Dean == "YES" && $cat_HOD == "NO") {
                                                $sql = "SELECT * FROM gencoursesupload WHERE Department = '$schcode' ORDER BY C_codding";
                                            }

                                            $result = $conn->query($sql);

                                            if ($result->num_rows > 0) {

                                            ?>

                                                <table class="table table-hover margin bottom">
                                                    <thead>
                                                        <tr>
                                                            <th></th>
                                                            <th>Course Code</th>
                                                            <th>Course Title</th>
                                                            <th>Unit</th>
                                                            <th>Semester</th>
                                                            <?php if ($numbschCurri > 1) { ?>
                                                                <th>Curriculum</th>
                                                            <?php } ?>
                                                            <th>Team Leader</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["id"];
                                                            $ccode = $row["C_codding"];
                                                            $CTitle = $row["C_title"];
                                                            $CUnit = $row["credit"];
                                                            $SemTaken = $row["semester"];
                                                            $type1 = $row["type1"];
                                                            $sql2 = "SELECT * FROM sch_curriculum WHERE curri_Code = '$type1'";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $type2 = $row2["curri_Title"];
                                                                }
                                                            }

                                                            echo "<tr>
														<td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccode' name='ccode[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccode' name='ccode[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitle' name='CTitle[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitle' name='CTitle[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnit' name='CUnit[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnit' name='CUnit[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTaken' name='SemTaken[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTaken' name='SemTaken[" . $id . "]' value='" . $SemTaken . "'/>
														</td>";
                                                            if ($numbschCurri > 1) {
                                                                echo "<td>
                                                        
                                                                <label id='Ctype' name='Ctype[" . $id . "]'>$type2</label>
                                                                <input type='hidden' id='Ctype' name='Ctype[" . $id . "]' value='" . $type1 . "'/>
                                                            
                                                                </td>";
                                                            }
                                                            echo "<td>
														<select name = 'teamleader[" . $id . "]' class='form-control' style='color:#000000' id='teamleader' required>
                                                            <option value = 'NO'>NO</option>
                                                            <option value = 'YES'>YES</option>
                                                        </select>
														
														</td>
														
														</tr>\n";
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>

                                            <?php

                                            }
                                            $conn->close();
                                            ?>
                                            <br /><br />
                                            <div class="row" style="text-align:right">
                                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                            <br /><br />
                                        </form>
                                    </div>
                                    <div class="col-lg-1 col-md-1">

                                    </div>
                                    <div class="col-lg-5 col-md-5">
                                        <center>
                                            <h4>Edit Course Allocation</h4>
                                        </center>
                                        <center>
                                            <h4> <?php echo $curtsession . " " ?>Session</h4>
                                        </center>
                                        <br>
                                        <?php
                                        $deleted = "";
                                        //if(isset($_POST["remove"])){

                                        //}
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
                                        echo "<center><h3 style='color:#009'>$deleted</h3></center>";
                                        if ($cat_Dean == "YES") {
                                            $sql = "SELECT * FROM coursealocation WHERE SessionReg = '$curtsession' AND Department = '$schcode' ORDER BY ccode";
                                        } else {
                                            $sql = "SELECT * FROM coursealocation WHERE SessionReg = '$curtsession' AND Department = '$dept' ORDER BY ccode";
                                        }

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {

                                        ?>
                                            <table class="table table-hover margin bottom">
                                                <thead>
                                                    <tr>
                                                        <th>PF No.</th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Team Leader</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php
                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["sn"];

                                                        echo "<tr id='$id'><td>{$row['PFNo']}</td><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['teamleader']}</td>
														<td>
														 
															<button class='btn btn-danger btn-xs remove-record'>Delete</button>
														</td></tr>\n";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>

                                        <?php

                                        }
                                        $conn->close();
                                        ?>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script type="text/javascript">
        $(".remove-record").click(function() {
            var id = $(this).parents("tr").attr("id");
            if (confirm('Are you sure to delete this record ?')) {
                $.ajax({
                    url: 'delete_res/delete_coures_alocat.php',
                    type: 'GET',
                    data: {
                        id: id
                    },
                    error: function() {
                        alert('Something is wrong, couldn\'t delete record');
                    },
                    success: function(data) {
                        $("#" + id).remove();
                        alert("Record delete successfully.");
                    }
                });
            }
        });
    </script>
</body>

</html>
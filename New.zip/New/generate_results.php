<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['senate_format'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="inline_edit/jquery.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>
        <?php
        if (isset($_POST["submit_dept"])) {
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $getdept = $_POST["getdept"];

            $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$getdept'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {

                    $_SESSION['deptoption'] = $row["deptoption"];
                    $_SESSION['curricul'] = $row["curriculum"];
                    $_SESSION['deptcode'] = $row["DeptCode"];
                    $_SESSION['deptname'] = $row["DeptName"];
                    $_SESSION['prog_no_years'] = $row["prog_no_years"];
                }
            }
            $conn->close();

            $deptoption = $_SESSION['deptoption'];
            $curricul = $_SESSION['curricul'];
            $getdept = $_SESSION['deptcode'];
            $dept = $_SESSION['deptcode'];
            $deptname = $_SESSION['deptname'];
        } else {
            $deptoption = $_SESSION['deptoption'];
            $curricul = $_SESSION['curricul'];
            $getdept = $_SESSION['deptcode'];
            $dept = $_SESSION['deptcode'];
            $deptname = $_SESSION['deptname'];
        }


        set_time_limit(1000);
        ?>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Generate Results</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Generate Results</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Generate Results
                        </div>
                        <div class="panel-body">
                            <?php
                            $cursession = $_SESSION['resultsession'];
                            $resultsemester = $_SESSION['resultsemester'];

                            $staffid = $_SESSION['staffid'];


                            if (isset($_POST["deleteResGen"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $deptdb = $_SESSION['deptdb'];
                                $dept_db = $deptdb . strtolower($getdept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                $levelappr = $_POST["levelappr"];
                                $id = $_POST["id"];

                                $sql = "SELECT * FROM hod_semester_res_approval WHERE sn = '$id'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $getdeptoption = $row["deptoption"];
                                        $curricul = $row["curriculum"];
                                    }
                                }

                                if ($_SESSION['curricul'] !== "YES") {
                                    $curricul = "OLD";
                                }

                                if ($deptoption !== "YES") {
                                    $getdeptoption = "NOP";
                                }

                                $sql = "DELETE FROM scrutiny_senate WHERE session1  = '$cursession' AND semester = '$resultsemester' AND Level1 =  '$levelappr' AND DeptOpt = '$getdeptoption' AND curriculum = '$curricul'";
                                $result = $conn_stu->query($sql);

                                $sql = "DELETE FROM grade_cursem WHERE session1  = '$cursession' AND SemTaken = '$resultsemester' AND Level1 =  '$levelappr' AND DeptCode =  '$dept' AND deptOption = '$getdeptoption' AND curriculum = '$curricul'";
                                $result = $conn->query($sql);

                                $sql = "DELETE FROM grad_summary WHERE curri  = '$curricul' AND deptopt = '$getdeptoption' AND yeargrad =  '$levelappr'";
                                $result = $conn_stu->query($sql);

                                /* if ($_SESSION['curricul'] == "YES") {
                                    if ($deptoption == "YES") {
                                        $sql = "DELETE FROM scrutiny_senate WHERE session1  = '$cursession' AND semester = '$resultsemester' AND Level1 =  '$levelappr' AND DeptOpt = '$getdeptoption' AND curriculum = '$curricul'";
                                        $result = $conn_stu->query($sql);

                                        $sql = "DELETE FROM grade_cursem WHERE session1  = '$cursession' AND SemTaken = '$resultsemester' AND Level1 =  '$levelappr' AND DeptCode =  '$dept' AND deptOption = '$getdeptoption' AND curriculum = '$curricul'";
                                        $result = $conn->query($sql);
                                    } else {
                                        $sql = "DELETE FROM scrutiny_senate WHERE session1  = '$cursession' AND semester = '$resultsemester' AND Level1 =  '$levelappr' AND curriculum = '$curricul'";
                                        $result = $conn_stu->query($sql);

                                        $sql = "DELETE FROM grade_cursem WHERE session1  = '$cursession' AND SemTaken = '$resultsemester' AND Level1 =  '$levelappr' AND DeptCode =  '$dept' AND curriculum = '$curricul'";
                                        $result = $conn->query($sql);
                                    }
                                } else {
                                    if ($deptoption == "YES") {
                                        $sql = "DELETE FROM scrutiny_senate WHERE session1  = '$cursession' AND semester = '$resultsemester' AND Level1 =  '$levelappr' AND DeptOpt = '$getdeptoption'";
                                        $result = $conn_stu->query($sql);

                                        $sql = "DELETE FROM grade_cursem WHERE session1  = '$cursession' AND SemTaken = '$resultsemester' AND Level1 =  '$levelappr' AND DeptCode =  '$dept' AND deptOption = '$getdeptoption'";
                                        $result = $conn->query($sql);
                                    } else {
                                        $sql = "DELETE FROM scrutiny_senate WHERE session1  = '$cursession' AND semester = '$resultsemester' AND Level1 =  '$levelappr'";
                                        $result = $conn_stu->query($sql);

                                        $sql = "DELETE FROM grade_cursem WHERE session1  = '$cursession' AND SemTaken = '$resultsemester' AND Level1 =  '$levelappr' AND DeptCode =  '$dept'";
                                        $result = $conn->query($sql);
                                    }
                                } */

                                $sql = "DELETE FROM hod_semester_res_approval WHERE sn  = '$id'";
                                $result = $conn->query($sql);

                                $conn->close();
                                $conn_stu->close();
                            }
                            ?>

                            <?php if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES") { ?>
                            <form class="form-horizontal form-bordered" method="post">
                                <div class="row">
                                    <h2><?php echo $_SESSION['deptname'] ?></h2>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="getdept">Department:</label>
                                            <div class="col-lg-7">
                                                <select name="getdept" class="form-control" style="color:#000000"
                                                    id="getdept" required="required">
                                                    <option value=''>Select Option</option>

                                                    <?php
                                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                        if ($conn->connect_error) {
                                                            die("Connection failed: " . $conn->connect_error);
                                                        }

                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $DeptCode = $row["DeptCode"];
                                                                $DeptName = $row["DeptName"];
                                                                echo "<option value = '$DeptCode'>$DeptName</option>";
                                                            }
                                                        }
                                                        $conn->close();
                                                        ?>

                                                </select>
                                            </div>
                                        </div>

                                    </div>



                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-6"></label>
                                            <div class="col-lg-6">
                                                <button type="submit" name="submit_dept"
                                                    class="btn btn-primary btn-sm">Submit</button>
                                            </div>
                                        </div>
                                    </div>

                                </div>



                            </form>
                            <?php } ?>

                            <!-- start: page -->
                            <?php if (!isset($_POST["submit"]) && !isset($_POST["submitNext1"])) { ?>
                            <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                ?>
                            <br>
                            <form class="form-horizontal form-bordered" method="post">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="getyearAdt">Year
                                                Admitted:</label>
                                            <div class="col-lg-7">
                                                <?php
                                                    $iniyear = (int)substr($_SESSION['resultsession'], 5) - 9;
                                                    $finalyear = (int)substr($_SESSION['resultsession'], 5) + 1;

                                                    ?>
                                                <select name="getyearAdt" id="YGradSel" class="form-control"
                                                    style="color:#000000" id="getyearAdt" required="required">
                                                    <option value=''>Select Year</option>
                                                    <?php
                                                        while ($iniyear <= $finalyear) {
                                                            $addyear = $iniyear + 1;

                                                            echo "<option value = '$addyear'>$addyear</option>";
                                                            $iniyear++;
                                                        }

                                                        ?>

                                                </select>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-lg-4">
                                        <?php if ($deptoption == "YES") { ?>
                                        <div class="form-group">
                                            <label class="control-label col-lg-6" for="getdeptOpt">Departmental
                                                Option:</label>
                                            <div class="col-lg-6">
                                                <select name="getdeptOpt" class="form-control" style="color:#000000"
                                                    id="getdeptOpt" required="required">
                                                    <option value=''>Select Option</option>

                                                    <?php


                                                            $sql = "SELECT * FROM dept_option WHERE deptcode =  '$getdept'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $OptCode = $row["Opt_Code"];
                                                                    $OptTitle = $row["Opt_Title"];
                                                                    echo "<option value = '$OptCode'>$OptTitle</option>";
                                                                }
                                                            }

                                                            ?>

                                                </select>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>


                                    <div class="col-lg-4">
                                        <?php if ($_SESSION['curricul'] == "YES") { ?>
                                        <div class="form-group">
                                            <label class="control-label col-lg-6" for="getdeptCurri">Select
                                                Curriculum:</label>
                                            <div class="col-lg-6">
                                                <select name="getdeptCurri" class="form-control" style="color:#000000"
                                                    id="getdeptCurri" required="required">
                                                    <option value=''>Select Curriculum</option>

                                                    <?php
                                                            $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$getdept'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $curri_Code = $row["curri_Code"];
                                                                    $curri_Title = $row["curri_Title"];
                                                                    echo "<option value = '$curri_Code'>$curri_Title</option>";
                                                                }
                                                            }
                                                            ?>

                                                </select>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>

                                </div>


                                <!-- State dropdown -->
                                <div class="row">
                                    <div class="col-lg-4" id="YGrad">

                                    </div>
                                    <div class="col-lg-4">
                                        <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                        <div class="form-group">
                                            <label class="control-label col-lg-6" for="getprogram">Programme:</label>
                                            <div class="col-lg-6">
                                                <select name="getprogram" class="form-control" style="color:#000000"
                                                    id="getprogram" required="required">
                                                    <option value=''>Select Option</option>
                                                    <option value='ND'>ND</option>
                                                    <option value='HND'>HND</option>

                                                </select>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-4">

                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-6">Session:</label>
                                            <label class="control-label col-lg-6"
                                                style="text-align: left"><?php echo $_SESSION['resultsession'] ?></label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-6">Semester:</label>
                                            <label class="control-label col-lg-6"
                                                style="text-align: left;"><?php echo $_SESSION['resultsemester'] ?></label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-6"></label>
                                            <div class="col-lg-6">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <?php
                                $conn->close();
                                ?>
                            <?php } ?>
                            <?php if (isset($_POST["submit"]) || isset($_POST["submitNext1"])) { ?>
                            <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                ?>
                            <?php
                                if (isset($_POST["submit"])) {
                                    $deptoption = $_SESSION['deptoption'];
                                    $getdept = $_SESSION['deptcode'];
                                    //$defCount=0;

                                    $CountShortUnit = 0;
                                    $SessCount = 0;
                                    unset($StuSession);
                                    $StuSession[] = "";
                                    $_SESSION["StuSession"] = $StuSession;

                                    $OptTitle = $deptname;
                                    if ($deptoption == "YES") {
                                        $getdeptOpt = $_POST["getdeptOpt"];
                                        $_SESSION["getdeptOpt"] = $getdeptOpt;

                                        $sql = "SELECT * FROM dept_option WHERE deptcode =  '$getdept' AND Opt_Code = '$getdeptOpt'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $OptTitle = $row["Opt_Title"];
                                            }
                                        }
                                    }



                                    $IntYearAdmit = (int)$_POST["getyearAdt"];
                                    $txtYearAdmit = $_POST["getyearAdt"];
                                    if ($_SESSION['InstType'] == "Polytechnic") {
                                        $getprogram = $_POST["getprogram"];
                                    } else {
                                        $getprogram = "";
                                    }
                                    $_SESSION["IntYearAdmit"] = $IntYearAdmit;
                                    $_SESSION["txtYearAdmit"] = $txtYearAdmit;
                                    $GetTheSession = $_SESSION['resultsession'];
                                    $GetTheSemester = $_SESSION['resultsemester'];
                                    $_SESSION["getyearGrad"] = "XXXX";

                                    $DE200Senate = False;
                                    $DE300Senate = False;
                                    $NON_DE_Senate = False;
                                    $_SESSION["DE200Senate"] = $DE200Senate;
                                    $_SESSION["DE300Senate"] = $DE300Senate;
                                    $_SESSION["NON_DE_Senate"] = $NON_DE_Senate;


                                    do {

                                        $sessionpres = $IntYearAdmit . "/" . ($IntYearAdmit + 1);
                                        $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionpres'";
                                        $result = $conn->query($sql);
                                        $Add1 = 0;
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $Add1++;
                                            }
                                        }
                                        if ($Add1 == 0) {
                                            $SessCount = $SessCount + 1;
                                            $StuSession[$SessCount] = $sessionpres;
                                        }

                                        if ($StuSession[$SessCount] == $GetTheSession) {
                                            break;
                                        }

                                        $IntYearAdmit = $IntYearAdmit + 1;
                                    } while ($SessCount < 10);

                                    /*if ($SessCount == 4 and $GetTheSemester == "2ND") {
                        for ($x = 1; $x <= $SessCount; $x++) {
                            $StuSession[$x] = "";
                        }
                        echo "On SIWES, No Record";

                    }*/

                                    if ($GetTheSemester == "1ST") {
                                        $MySemester = "Semester: First";
                                    } else {
                                        $MySemester = "Semester: Second";
                                    }


                                    $MySession = "Session : " . $GetTheSession;
                                    if ($_SESSION['InstType'] == "University") {
                                        if ($SessCount == 1) {
                                            $_SESSION["SessCount"] = 1;
                                            $txtLevelPlus = 100;
                                        } elseif ($SessCount == 2) {
                                            $_SESSION["SessCount"] = 2;
                                            $txtLevelPlus = 200;
                                        } elseif ($SessCount == 3) {
                                            $_SESSION["SessCount"] = 3;
                                            $txtLevelPlus = 300;
                                        } elseif ($SessCount == 4) {
                                            $_SESSION["SessCount"] = 4;
                                            $txtLevelPlus = 400;
                                        } elseif ($SessCount == 5) {
                                            $_SESSION["SessCount"] = 5;
                                            $txtLevelPlus = 500;
                                        }

                                        $_SESSION['lblYearAdmit'] = $txtLevelPlus;
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {

                                        if ($_POST["getprogram"] == "ND") {
                                            if ($SessCount == 1) {
                                                $_SESSION["SessCount"] = 1;
                                                $txtLevelPlus = 100;
                                            } elseif ($SessCount == 2) {
                                                $_SESSION["SessCount"] = 2;
                                                $txtLevelPlus = 200;
                                                //$_SESSION["getyearGrad"] = $_POST["getyearGrad"];
                                            }
                                        } else {
                                            if ($SessCount == 1) {
                                                $_SESSION["SessCount"] = 1;
                                                $txtLevelPlus = 300;
                                            } elseif ($SessCount == 2) {
                                                $_SESSION["SessCount"] = 2;
                                                $txtLevelPlus = 400;
                                                //$_SESSION["getyearGrad"] = $_POST["getyearGrad"];
                                            }
                                        }

                                        if ($txtLevelPlus == 100) {
                                            $_SESSION['lblYearAdmit'] = "ND I";
                                        } elseif ($txtLevelPlus == 200) {
                                            $_SESSION['lblYearAdmit'] = "ND II";
                                        } elseif ($txtLevelPlus == 300) {
                                            $_SESSION['lblYearAdmit'] = "HND I";
                                        } elseif ($txtLevelPlus == 400) {
                                            $_SESSION['lblYearAdmit'] = "HND II";
                                        }
                                    } else {
                                    }

                                    if ($SessCount >= $_SESSION['prog_no_years']) {
                                        $_SESSION["getyearGrad"] = $_POST["getyearGrad"];
                                    }
                                    $_SESSION['LevelPlus'] = $txtLevelPlus;

                                    $enterYAmitted = $txtYearAdmit;
                                    $enterSession = $GetTheSession;
                                    $enterSemester = $GetTheSemester;

                                    $preEnterYAmitted = $txtYearAdmit;
                                    $preEnterSession = $GetTheSession;
                                    $preEnterSemester = $GetTheSemester;

                                    unset($corecoursearray);
                                    $corecoursearray[] = "";
                                    $corecoursecount = 0;
                                    unset($groupCodearray);
                                    $groupCodearray[] = "";
                                    $groupCodecount = 0;


                                    //DE 200
                                    unset($DE200corecoursearray);
                                    $DE200corecoursearray[] = "";
                                    $DE200corecoursecount = 0;
                                    unset($DE200groupCodearray);
                                    $DE200groupCodearray[] = "";
                                    $DE200groupCodecount = 0;

                                    //DE 300
                                    unset($DE300corecoursearray);
                                    $DE300corecoursearray[] = "";
                                    $DE300corecoursecount = 0;
                                    unset($DE300groupCodearray);
                                    $DE300groupCodearray[] = "";
                                    $DE300groupCodecount = 0;

                                    $deptdb = $_SESSION['deptdb'];
                                    $dept_db = $deptdb . strtolower($getdept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                    $deptcorreg = "correg";
                                    if ($curricul == "YES") {
                                        $curri = $_POST["getdeptCurri"];
                                        $_SESSION["curri"] = $curri;
                                        if ($curri == "OLD") {
                                            $curri2 = "";
                                        } else {
                                            $curri2 = "_" . $curri;
                                        }
                                        $deptgencourses = "gencourses" . $curri2;
                                    } else {
                                        $deptgencourses = "gencourses";
                                    }

                                    $yearadmtInSess = $txtYearAdmit;

                                    if ($deptoption == "YES") {
                                        $GetOpt = $getdeptOpt;
                                        $CoreGetOption = "Core_" . $GetOpt;
                                        $CoreDE200GetOption = "CoreDE200_" . $GetOpt;
                                        $CoreDE300GetOption = "CoreDE300_" . $GetOpt;
                                        $GroupOption = "Group" . $GetOpt;

                                        $_SESSION["CoreGetOption"] = $CoreGetOption;
                                        $_SESSION["CoreDE200GetOption"] = $CoreDE200GetOption;
                                        $_SESSION["CoreDE300GetOption"] = $CoreDE300GetOption;
                                        $_SESSION["GroupOption"] = $GroupOption;
                                    }
                                    include 'modulesInSess/SubProcessResults.php';
                                    $_SESSION['corecoursearray'] = $corecoursearray;
                                    $_SESSION['corecoursecount'] = $corecoursecount;
                                    $_SESSION['groupCodearray'] = $groupCodearray;
                                    $_SESSION['groupCodecount'] = $groupCodecount;

                                    include 'modulesInSess/SubProcessResultsDE200.php';
                                    $_SESSION['DE200corecoursearray'] = $DE200corecoursearray;
                                    $_SESSION['DE200corecoursecount'] = $DE200corecoursecount;
                                    $_SESSION['DE200groupCodearray'] = $DE200groupCodearray;
                                    $_SESSION['DE200groupCodecount'] = $DE200groupCodecount;

                                    include 'modulesInSess/SubProcessResultsDE300.php';
                                    $_SESSION['DE300corecoursearray'] = $DE300corecoursearray;
                                    $_SESSION['DE300corecoursecount'] = $DE300corecoursecount;
                                    $_SESSION['DE300groupCodearray'] = $DE300groupCodearray;
                                    $_SESSION['DE300groupCodecount'] = $DE300groupCodecount;

                                    unset($repairRegno);
                                    unset($repairDeptOpt);
                                    unset($repairName);
                                    unset($repairFname);
                                    unset($repairSname);
                                    unset($repairOname);
                                    unset($repairSex);
                                    unset($repairmodeofentry);
                                    unset($repairPrvCrTaken);
                                    unset($repairPrvCP);
                                    unset($repairPrvGP);
                                    unset($repairPrvCGPA);
                                    unset($repairPresCrTaken);
                                    unset($repairPresCP);
                                    unset($repairPresGP);
                                    unset($repairPresCGPA);
                                    unset($repairCumCrTaken);
                                    unset($repairCumCP);
                                    unset($repairCumGP);
                                    unset($repairCumCGPA);
                                    unset($THE_REMARK);
                                    unset($tstFailedCs);
                                    unset($repairToTOuts);
                                    unset($repairCGPA100);
                                    unset($repairCGPA200);
                                    unset($repairCGPA300);
                                    unset($repairCGPA400);
                                    unset($repairCGPA500);
                                    unset($cursemcourses);
                                    unset($spillover);

                                    unset($repairdob);
                                    unset($repairp_address);
                                    unset($repairdeptfull);
                                    unset($repairprogfull);
                                    unset($repaireyearadmt);

                                    unset($repairIteration);

                                    unset($repairemail);
                                    unset($repairphone);
                                    unset($repairm_status);
                                    unset($repairJANB_no);

                                    unset($repairStdid);
                                    unset($repairState);
                                    unset($repairLGA);
                                    unset($repairstu_group);
                                    unset($repairduration_time);

                                    unset($repairsem_C_F);
                                    unset($repairprev_C_F);
                                    unset($repaircum_C_F);
                                    unset($repairnumb_Course_failed);

                                    $repairRegno[] = "";
                                    $repairDeptOpt[] = "";
                                    $repairName[] = "";
                                    $repairFname[] = "";
                                    $repairSname[] = "";
                                    $repairOname[] = "";
                                    $repairSex[] = "";
                                    $repairEntry_Level[] = "";
                                    $repairStd_yearAdtd[] = "";
                                    $repairmodeofentry[] = "";
                                    $repairPrvCrTaken[] = 0;
                                    $repairPrvCP[] = 0;
                                    $repairPrvGP[] = 0;
                                    $repairPrvCGPA[] = 0;
                                    $repairPresCrTaken[] = 0;
                                    $repairPresCP[] = 0;
                                    $repairPresGP[] = 0;
                                    $repairPresCGPA[] = 0;
                                    $repairCumCrTaken[] = 0;
                                    $repairCumCP[] = 0;
                                    $repairCumGP[] = 0;
                                    $repairCumCGPA[] = 0;
                                    $THE_REMARK[] = "";
                                    $tstFailedCs[] = "";
                                    $repairToTOuts[] = 0;
                                    $repairCGPA100[] = 0;
                                    $repairCGPA200[] = 0;
                                    $repairCGPA300[] = 0;
                                    $repairCGPA400[] = 0;
                                    $repairCGPA500[] = 0;
                                    $cursemcourses[] = "";
                                    $spillover[] = "NO";

                                    $repairdob[] = "";
                                    $repairp_address[] = "";
                                    $repairdeptfull[] = "";
                                    $repairprogfull[] = "";
                                    $repaireyearadmt[] = "";

                                    $repairemail[] = "";
                                    $repairphone[] = "";
                                    $repairm_status[] = "";
                                    $repairJANB_no[] = "";


                                    $repairStdid[] = "";
                                    $repairState[] = "";
                                    $repairLGA[] = "";
                                    $repairstu_group[] = "";
                                    $$repairduration_time = "";

                                    $repairsem_C_F[] = 0;
                                    $repairprev_C_F[] = 0;
                                    $repaircum_C_F[] = 0;
                                    $repairnumb_Course_failed[] = 0;

                                    unset($ArraystuRequiremtCode);
                                    unset($ArraystuRequiremtFreq);
                                    unset($ArraystuRequiremtRegNo);
                                    unset($ArraystuRequiremtModeEntry);
                                    $ArraystuRequiremtCode[] = "";
                                    $ArraystuRequiremtFreq[] = 0;
                                    $ArraystuRequiremtRegNo[] = "";
                                    $ArraystuRequiremtCount = 0;
                                    $ArraystuRequiremtModeEntry[] = "";

                                    //Deficiency/Outstanding
                                    $countdefCCode = 0;
                                    unset($RegdefCCode);
                                    $RegdefCCode[] = "";
                                    unset($StudefCCode);
                                    $StudefCCode[] = "";
                                    unset($TitledefCCode);
                                    $TitledefCCode[] = "";
                                    unset($UnitdefCCode);
                                    $UnitdefCCode[] = 0;

                                    //unset($defRegn1);
                                    unset($relevantCourse);
                                    $relevantCourse[] = "";
                                    $countrelevantCourse = 0;


                                    $repairIteration = 0;
                                    $_SESSION["repairIteration"] = $repairIteration;
                                    $_SESSION['repairRegno'] = $repairRegno;
                                    $_SESSION['repairDeptOpt'] = $repairDeptOpt;
                                    $_SESSION['repairName'] = $repairName;
                                    $_SESSION['repairFname'] = $repairFname;
                                    $_SESSION['repairSname'] = $repairSname;
                                    $_SESSION['repairOname'] = $repairOname;
                                    $_SESSION['repairSex'] = $repairSex;
                                    $_SESSION['repairEntry_Level'] = $repairEntry_Level;
                                    $_SESSION['repairStd_yearAdtd'] = $repairStd_yearAdtd;
                                    $_SESSION['repairPrvCrTaken'] = $repairPrvCrTaken;
                                    $_SESSION['repairPrvCP'] = $repairPrvCP;
                                    $_SESSION['repairPrvGP'] = $repairPrvGP;
                                    $_SESSION['repairPrvCGPA'] = $repairPrvCGPA;
                                    $_SESSION['repairPresCrTaken'] = $repairPresCrTaken;
                                    $_SESSION['repairPresCP'] = $repairPresCP;
                                    $_SESSION['repairPresGP'] = $repairPresGP;
                                    $_SESSION['repairPresCGPA'] = $repairPresCGPA;
                                    $_SESSION['repairCumCrTaken'] = $repairCumCrTaken;
                                    $_SESSION['repairCumCP'] = $repairCumCP;
                                    $_SESSION['repairCumGP'] = $repairCumGP;
                                    $_SESSION['repairCumCGPA'] = $repairCumCGPA;
                                    $_SESSION['THE_REMARK'] = $THE_REMARK;
                                    $_SESSION['tstFailedCs'] = $tstFailedCs;
                                    $_SESSION['repairToTOuts'] = $repairToTOuts;
                                    $_SESSION['repairCGPA100'] = $repairCGPA100;
                                    $_SESSION['repairCGPA200'] = $repairCGPA200;
                                    $_SESSION['repairCGPA300'] = $repairCGPA300;
                                    $_SESSION['repairCGPA400'] = $repairCGPA400;
                                    $_SESSION['repairCGPA500'] = $repairCGPA500;
                                    $_SESSION["cursemcourses"] = $cursemcourses;
                                    $_SESSION["spillover"] = $spillover;

                                    $_SESSION["repairdob"] = $repairdob;
                                    $_SESSION["repairp_address"] = $repairp_address;
                                    $_SESSION["repairdeptfull"] = $repairdeptfull;
                                    $_SESSION["repairprogfull"] = $repairprogfull;
                                    $_SESSION["repaireyearadmt"] = $repaireyearadmt;

                                    $_SESSION["repairemail"] = $repairemail;
                                    $_SESSION["repairphone"] = $repairphone;
                                    $_SESSION["repairm_status"] = $repairm_status;
                                    $_SESSION["repairJANB_no"] = $repairJANB_no;


                                    $_SESSION["repairStdid"] = $repairStdid;
                                    $_SESSION["repairState"] = $repairState;
                                    $_SESSION["repairLGA"] = $repairLGA;
                                    $_SESSION["repairstu_group"] = $repairstu_group;
                                    $_SESSION["repairduration_time"] = $repairduration_time;
                                    $_SESSION["repairmodeofentry"] = $repairmodeofentry;

                                    $_SESSION["repairsem_C_F"] = $repairsem_C_F;
                                    $_SESSION["repairprev_C_F"] = $repairprev_C_F;
                                    $_SESSION["repaircum_C_F"] = $repaircum_C_F;
                                    $_SESSION["repairnumb_Course_failed"] = $repairnumb_Course_failed;

                                    $_SESSION["ArraystuRequiremtCode"] = $ArraystuRequiremtCode;
                                    $_SESSION["ArraystuRequiremtFreq"] = $ArraystuRequiremtFreq;
                                    $_SESSION["ArraystuRequiremtRegNo"] = $ArraystuRequiremtRegNo;
                                    $_SESSION["ArraystuRequiremtCount"] = $ArraystuRequiremtCount;
                                    $_SESSION["ArraystuRequiremtModeEntry"] = $ArraystuRequiremtModeEntry;

                                    $_SESSION["countdefCCode"] = $countdefCCode;
                                    $_SESSION["RegdefCCode"] = $RegdefCCode;
                                    $_SESSION["StudefCCode"] = $StudefCCode;
                                    $_SESSION["TitledefCCode"] = $TitledefCCode;
                                    $_SESSION["UnitdefCCode"] = $UnitdefCCode;

                                    $_SESSION["StuSession"] = $StuSession;

                                    //$_SESSION["relevantCourse"] = $relevantCourse;
                                    //$_SESSION["countrelevantCourse"] = $countrelevantCourse;

                                    if ($deptoption == "YES") {

                                        $sql3 = "SELECT * FROM " . $deptgencourses . " WHERE " . $getdeptOpt . " = 'YES'";
                                    } else {
                                        $sql3 = "SELECT * FROM " . $deptgencourses . " WHERE Relevant = 'YES'";
                                    }
                                    $result3 = $conn_stu->query($sql3);
                                    if ($result3->num_rows > 0) {
                                        while ($row3 = $result3->fetch_assoc()) {
                                            $relevantCourse[$countrelevantCourse] = $row3["C_codding"];
                                            $countrelevantCourse++;
                                        }
                                    }
                                    $_SESSION["relevantCourse"] = $relevantCourse;
                                    $_SESSION["countrelevantCourse"] = $countrelevantCourse;
                                    //$dept_id = $_SESSION['dept_id'];

                                    $StuStatus = 6;
                                    if ($_SESSION['InstType'] == "University") {
                                        if ($curricul == "YES") {
                                            if ($deptoption == "YES") {
                                                $sql = "SELECT YAddmitted, status, dept_code, Dept_Option, curriculum, matric_no, gender, state, lga, first_name, other_name, surname, modeofentry, entry_level, entry_session, dob, p_address, sch_email, phone_number, marital_status, jamb_appl_no FROM std_data_view WHERE YAddmitted = '$txtYearAdmit' AND (status = 1 OR status = 2 OR status = 3 OR status = 4 OR status = 5 OR status = 6) AND dept_code = '$getdept' AND Dept_Option = '$getdeptOpt' AND curriculum = '$curri' ORDER BY matric_no";
                                            } else {
                                                $sql = "SELECT YAddmitted, status, dept_code, Dept_Option, curriculum, matric_no, gender, state, lga, first_name, other_name, surname, modeofentry, entry_level, entry_session, dob, p_address, sch_email, phone_number, marital_status, jamb_appl_no FROM std_data_view WHERE YAddmitted = '$txtYearAdmit' AND (status = 1 OR status = 2 OR status = 3 OR status = 4 OR status = 5 OR status = 6) AND dept_code = '$getdept' AND curriculum = '$curri' ORDER BY matric_no";
                                            }
                                        } else {
                                            if ($deptoption == "YES") {
                                                $sql = "SELECT YAddmitted, status, dept_code, Dept_Option, curriculum, matric_no, gender, state, lga, first_name, other_name, surname, modeofentry, entry_level, entry_session, dob, p_address, sch_email, phone_number, marital_status, jamb_appl_no FROM std_data_view WHERE YAddmitted = '$txtYearAdmit' AND (status = 1 OR status = 2 OR status = 3 OR status = 4 OR status = 5 OR status = 6) AND dept_code = '$getdept' AND Dept_Option = '$getdeptOpt' ORDER BY matric_no";
                                            } else {
                                                $sql = "SELECT YAddmitted, status, dept_code, Dept_Option, curriculum, matric_no, gender, state, lga, first_name, other_name, surname, modeofentry, entry_level, entry_session, dob, p_address, sch_email, phone_number, marital_status, jamb_appl_no FROM std_data_view WHERE YAddmitted = '$txtYearAdmit' AND (status = 1 OR status = 2 OR status = 3 OR status = 4 OR status = 5 OR status = 6) AND dept_code = '$getdept' ORDER BY matric_no";
                                            }
                                        }
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        if ($curricul == "YES") {
                                            if ($deptoption == "YES") {
                                                $sql = "SELECT YAddmitted, status, dept_code, Dept_Option, curriculum, matric_no, gender, state, lga, stu_group, first_name, other_name, surname, modeofentry, entry_level, entry_session, dob, p_address, sch_email, phone_number, marital_status, jamb_appl_no FROM std_data_view WHERE YAddmitted = '$txtYearAdmit' AND modeofentry = '$getprogram' AND (status = 1 OR status = 2 OR status = 3 OR status = 4 OR status = 5 OR status = 6) AND dept_code = '$getdept' AND Dept_Option = '$getdeptOpt' AND curriculum = '$curri' ORDER BY matric_no";
                                            } else {
                                                $sql = "SELECT YAddmitted, status, dept_code, Dept_Option, curriculum, matric_no, gender, state, lga, stu_group, first_name, other_name, surname, modeofentry, entry_level, entry_session, dob, p_address, sch_email, phone_number, marital_status, jamb_appl_no FROM std_data_view WHERE YAddmitted = '$txtYearAdmit' AND modeofentry = '$getprogram' AND (status = 1 OR status = 2 OR status = 3 OR status = 4 OR status = 5 OR status = 6) AND dept_code = '$getdept' AND curriculum = '$curri' ORDER BY matric_no";
                                            }
                                        } else {
                                            if ($deptoption == "YES") {
                                                $sql = "SELECT YAddmitted, status, dept_code, Dept_Option, curriculum, matric_no, gender, state, lga, stu_group, first_name, other_name, surname, modeofentry, entry_level, entry_session, dob, p_address, sch_email, phone_number, marital_status, jamb_appl_no FROM std_data_view WHERE YAddmitted = '$txtYearAdmit' AND modeofentry = '$getprogram' AND (status = 1 OR status = 2 OR status = 3 OR status = 4 OR status = 5 OR status = 6) AND dept_code = '$getdept' AND Dept_Option = '$getdeptOpt' ORDER BY matric_no";
                                            } else {
                                                $sql = "SELECT YAddmitted, status, dept_code, Dept_Option, curriculum, matric_no, gender, state, lga, stu_group, first_name, other_name, surname, modeofentry, entry_level, entry_session, dob, p_address, sch_email, phone_number, marital_status, jamb_appl_no FROM std_data_view WHERE YAddmitted = '$txtYearAdmit' AND modeofentry = '$getprogram' AND (status = 1 OR status = 2 OR status = 3 OR status = 4 OR status = 5 OR status = 6) AND dept_code = '$getdept' ORDER BY matric_no";
                                            }
                                        }
                                    }
                                    $result = $conn2->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $repairIteration++;
                                            $repairRegno[$repairIteration] = $row["matric_no"];
                                            $repairSex[$repairIteration] = ucwords(strtolower($row["gender"]));
                                            $repairState[$repairIteration] = ucwords(strtolower($row["state"]));
                                            $repairLGA[$repairIteration] = ucwords(strtolower($row["lga"]));
                                            if ($_SESSION['InstType'] == "University") {
                                                $repairstu_group[$repairIteration] = "NG";
                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                $repairstu_group[$repairIteration] = $row["stu_group"];
                                            }
                                            $$repairduration_time[$repairIteration] = $row["duration_time"];
                                            //$repairmodeofentry[$repairIteration] = $row["modeofentry"];
                                            $repairmodeofentry[$repairIteration] = $getprogram;
                                            $repairFname[$repairIteration] = ucwords(strtolower($row['first_name']));
                                            $repairSname[$repairIteration] = ucwords(strtolower($row['surname']));
                                            $repairOname[$repairIteration] = ucwords(strtolower($row['other_name']));
                                            $repairEntry_Level[$repairIteration] = $row['entry_level'];
                                            $repairStd_yearAdtd[$repairIteration] = substr($row['entry_session'], 0, 4);
                                            $repairName[$repairIteration] = $repairFname[$repairIteration] . " " . $repairOname[$repairIteration] . " " . $repairSname[$repairIteration];

                                            $repairdob[$repairIteration] = $row['dob'];
                                            $repairp_address[$repairIteration] = $row['p_address'];
                                            $repairdeptfull[$repairIteration] = $deptname;
                                            $repairprogfull[$repairIteration] = $OptTitle;

                                            $repairemail[$repairIteration] = $row['sch_email'];
                                            $repairphone[$repairIteration] = $row['phone_number'];
                                            $repairm_status[$repairIteration] = $row['marital_status'];
                                            $repairJANB_no[$repairIteration] = $row['jamb_appl_no'];

                                            $repaireyearadmt[$repairIteration] = substr($row['entry_session'], 0, 4);

                                            if ($deptoption == "YES") {
                                                $GetOpt = $row["Dept_Option"];
                                                //$GetOptG = "Group" .$row["Dept_Option"];

                                            } else {
                                                $GetOpt = "NOP";
                                                //$GetOptG = "XX";
                                            }
                                            $repairDeptOpt[$repairIteration] = $GetOpt;
                                        }
                                    }

                                    $conn->close();
                                    $conn2->close();
                                    $conn_stu->close();

                                    $_SESSION["repairIteration"] = $repairIteration;
                                    $_SESSION['repairRegno'] = $repairRegno;
                                    $_SESSION['repairDeptOpt'] = $repairDeptOpt;
                                    $_SESSION['repairName'] = $repairName;
                                    $_SESSION['repairFname'] = $repairFname;
                                    $_SESSION['repairSname'] = $repairSname;
                                    $_SESSION['repairOname'] = $repairOname;
                                    $_SESSION['repairSex'] = $repairSex;
                                    $_SESSION['repairEntry_Level'] = $repairEntry_Level;
                                    $_SESSION['repairStd_yearAdtd'] = $repairStd_yearAdtd;
                                    //$_SESSION["repairStdid"] = $repairStdid;
                                    $_SESSION["repairState"] = $repairState;
                                    $_SESSION["repairLGA"] = $repairLGA;
                                    $_SESSION["repairstu_group"] = $repairstu_group;
                                    $_SESSION["repairduration_time"] = $repairduration_time;
                                    $_SESSION["repairmodeofentry"] = $repairmodeofentry;

                                    $_SESSION["repairdob"] = $repairdob;
                                    $_SESSION["repairp_address"] = $repairp_address;
                                    $_SESSION["repairdeptfull"] = $repairdeptfull;
                                    $_SESSION["repairprogfull"] = $repairprogfull;
                                    $_SESSION["repaireyearadmt"] = $repaireyearadmt;

                                    $_SESSION["repairemail"] = $repairemail;
                                    $_SESSION["repairphone"] = $repairphone;
                                    $_SESSION["repairm_status"] = $repairm_status;
                                    $_SESSION["repairJANB_no"] = $repairJANB_no;

                                    $_SESSION["getNext"] = 1;
                                    //$_SESSION["EndRec"]=false;
                                    //include 'modulesInSess/SubProcessResults.php';
                                } else {
                                    $repairIteration = $_SESSION["repairIteration"];
                                    $repairRegno = $_SESSION['repairRegno'];
                                }
                                /* */
                                ?>
                            <div class="row">
                                <div class="col-xs-12">
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>
                                            <div class="row" style="font-size: large">
                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <label class="control-label col-lg-5"
                                                            style="text-align: right">Year
                                                            Admitted:</label>
                                                        <label class="control-label col-lg-5"
                                                            style="text-align: left"><?php echo $_SESSION["txtYearAdmit"] ?></label>

                                                    </div>
                                                </div>
                                                <div class="col-lg-2">
                                                    <div class="form-group">
                                                        <label class="control-label col-lg-5"
                                                            style="text-align: right">Level:</label>
                                                        <label class="control-label col-lg-5"
                                                            style="text-align: left"><?php echo $_SESSION['lblYearAdmit'] ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="form-group">
                                                        <label class="control-label col-lg-5"
                                                            style="text-align: right">Session:</label>
                                                        <label class="control-label col-lg-5"
                                                            style="text-align: left"><?php echo $_SESSION['resultsession'] ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="form-group">
                                                        <label class="control-label col-lg-5"
                                                            style="text-align: right">Semester:</label>
                                                        <label class="control-label col-lg-5"
                                                            style="text-align: left"><?php echo $_SESSION['resultsemester'] ?></label>
                                                    </div>
                                                </div>

                                            </div>

                                        </header>
                                        <div class="panel-body">
                                            <div class="col-md-3">

                                            </div>
                                            <div class="col-md-6">
                                                <section class="panel">
                                                    <div class="panel-body">
                                                        <?php if (isset($_POST["submit"]) || isset($_POST["submitNext1"])) {
                                                                /*  $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                if ($conn->connect_error) {
                                                                    die("Connection failed: " . $conn->connect_error);
                                                                }

                                                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                                                if ($conn2->connect_error) {
                                                                    die("Connection failed: " . $conn2->connect_error);
                                                                }

                                                                $deptdb = $_SESSION['deptdb'];
                                                                $dept_db = $deptdb . strtolower($getdept);
                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                if ($conn_stu->connect_error) {
                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                } */
                                                                if (isset($_POST["submit"])) {
                                                            ?>
                                                        <div class="progress light m-md">
                                                            <div class="progress-bar progress-bar-primary"
                                                                role="progressbar" aria-valuenow="0" aria-valuemin="0"
                                                                aria-valuemax="100" style="width: 0%;">
                                                                0% Complete
                                                            </div>

                                                        </div>

                                                        <?php
                                                                    $repairIteration = $_SESSION["repairIteration"];
                                                                    if ($repairIteration >= 75) {
                                                                        echo "<h3>Click Next to process the first 75 of $repairIteration records ...</h3>";
                                                                    } else {
                                                                        echo "<h3>Click Next to process the $repairIteration records ...</h3>";
                                                                    }
                                                                } else {
                                                                    $txtLevelPlus = $_SESSION['LevelPlus'];
                                                                    $repairIteration = $_SESSION["repairIteration"];
                                                                    $deptcorreg = "correg";

                                                                    if ($_SESSION['curricul'] == "YES") {
                                                                        $curri = $_SESSION["curri"];
                                                                        if ($curri == "OLD") {
                                                                            $curri2 = "";
                                                                        } else {
                                                                            $curri2 = "_" . $curri;
                                                                        }
                                                                        $deptgencourses = "gencourses" . $curri2;
                                                                    } else {
                                                                        $deptgencourses = "gencourses";
                                                                    }


                                                                    $iniNext = $_SESSION["getNext"];
                                                                    //echo "Initial: ". $iniNext;
                                                                    if ($_SESSION["getNext"] + 75 < $_SESSION["repairIteration"]) {
                                                                        $_SESSION["getNext"] = $_SESSION["getNext"] + 75;
                                                                    } else {
                                                                        $_SESSION["getNext"] = $_SESSION["repairIteration"];
                                                                    }

                                                                    $GetTheSession = $_SESSION['resultsession'];
                                                                    $GetTheSemester = $_SESSION['resultsemester'];
                                                                    $txtYearAdmit = $_SESSION["txtYearAdmit"];
                                                                    $StuSession = $_SESSION["StuSession"];

                                                                    $repairDeptOpt = $_SESSION['repairDeptOpt'];
                                                                    $repairName = $_SESSION['repairName'];
                                                                    $repairFname = $_SESSION['repairFname'];
                                                                    $repairSname = $_SESSION['repairSname'];
                                                                    $repairOname = $_SESSION['repairOname'];
                                                                    $repairSex = $_SESSION['repairSex'];
                                                                    $repairEntry_Level = $_SESSION['repairEntry_Level'];
                                                                    $repairStd_yearAdtd = $_SESSION['repairStd_yearAdtd'];
                                                                    $repairmodeofentry = $_SESSION["repairmodeofentry"];
                                                                    $repairPrvCrTaken = $_SESSION['repairPrvCrTaken'];
                                                                    $repairPrvCP = $_SESSION['repairPrvCP'];
                                                                    $repairPrvGP = $_SESSION['repairPrvGP'];
                                                                    $repairPrvCGPA = $_SESSION['repairPrvCGPA'];
                                                                    $repairPresCrTaken = $_SESSION['repairPresCrTaken'];
                                                                    $repairPresCP = $_SESSION['repairPresCP'];
                                                                    $repairPresGP = $_SESSION['repairPresGP'];
                                                                    $repairPresCGPA = $_SESSION['repairPresCGPA'];
                                                                    $repairCumCrTaken = $_SESSION['repairCumCrTaken'];
                                                                    $repairCumCP = $_SESSION['repairCumCP'];
                                                                    $repairCumGP = $_SESSION['repairCumGP'];
                                                                    $repairCumCGPA = $_SESSION['repairCumCGPA'];
                                                                    $THE_REMARK = $_SESSION['THE_REMARK'];
                                                                    $tstFailedCs = $_SESSION['tstFailedCs'];
                                                                    $repairToTOuts = $_SESSION['repairToTOuts'];
                                                                    $repairCGPA100 = $_SESSION['repairCGPA100'];
                                                                    $repairCGPA200 = $_SESSION['repairCGPA200'];
                                                                    $repairCGPA300 = $_SESSION['repairCGPA300'];
                                                                    $repairCGPA400 = $_SESSION['repairCGPA400'];
                                                                    $repairCGPA500 = $_SESSION['repairCGPA500'];
                                                                    $cursemcourses = $_SESSION["cursemcourses"];
                                                                    $spillover = $_SESSION["spillover"];

                                                                    $repairdob = $_SESSION["repairdob"];
                                                                    $repairp_address = $_SESSION["repairp_address"];
                                                                    $repairdeptfull = $_SESSION["repairdeptfull"];
                                                                    $repairprogfull = $_SESSION["repairprogfull"];
                                                                    $repaireyearadmt = $_SESSION["repaireyearadmt"];

                                                                    $repairemail =  $_SESSION["repairemail"];
                                                                    $repairphone = $_SESSION["repairphone"];
                                                                    $repairm_status = $_SESSION["repairm_status"];
                                                                    $repairJANB_no = $_SESSION["repairJANB_no"];


                                                                    $repairsem_C_F = $_SESSION["repairsem_C_F"];
                                                                    $repairprev_C_F = $_SESSION["repairprev_C_F"];
                                                                    $repaircum_C_F = $_SESSION["repaircum_C_F"];
                                                                    $repairnumb_Course_failed = $_SESSION["repairnumb_Course_failed"];

                                                                    $deptoption = $_SESSION['deptoption'];
                                                                    $SessCount = $_SESSION["SessCount"];

                                                                    $ArraystuRequiremtCode = $_SESSION["ArraystuRequiremtCode"];
                                                                    $ArraystuRequiremtFreq = $_SESSION["ArraystuRequiremtFreq"];
                                                                    $ArraystuRequiremtRegNo = $_SESSION["ArraystuRequiremtRegNo"];
                                                                    $ArraystuRequiremtCount = $_SESSION["ArraystuRequiremtCount"];
                                                                    $ArraystuRequiremtModeEntry = $_SESSION["ArraystuRequiremtModeEntry"];

                                                                    $countdefCCode = $_SESSION["countdefCCode"];
                                                                    $RegdefCCode = $_SESSION["RegdefCCode"];
                                                                    $StudefCCode = $_SESSION["StudefCCode"];
                                                                    $TitledefCCode = $_SESSION["TitledefCCode"];
                                                                    $UnitdefCCode = $_SESSION["UnitdefCCode"];

                                                                    $corecoursearray = $_SESSION['corecoursearray'];
                                                                    $corecoursecount = $_SESSION['corecoursecount'];
                                                                    $groupCodearray = $_SESSION['groupCodearray'];
                                                                    $groupCodecount = $_SESSION['groupCodecount'];

                                                                    $DE200corecoursearray = $_SESSION['DE200corecoursearray'];
                                                                    $DE200corecoursecount = $_SESSION['DE200corecoursecount'];
                                                                    $DE200groupCodearray = $_SESSION['DE200groupCodearray'];
                                                                    $DE200groupCodecount = $_SESSION['DE200groupCodecount'];

                                                                    $DE300corecoursearray = $_SESSION['DE300corecoursearray'];
                                                                    $DE300corecoursecount = $_SESSION['DE300corecoursecount'];
                                                                    $DE300groupCodearray = $_SESSION['DE300groupCodearray'];
                                                                    $DE300groupCodecount = $_SESSION['DE300groupCodecount'];

                                                                    $relevantCourse = $_SESSION["relevantCourse"];
                                                                    $countrelevantCourse = $_SESSION["countrelevantCourse"];
                                                                    if ($deptoption == "YES") {
                                                                        $getdeptOpt = $_SESSION["getdeptOpt"];
                                                                    }

                                                                    if ($_SESSION['curricul'] !== "YES") {
                                                                        $curri = "OLD";
                                                                    }

                                                                    if ($deptoption !== "YES") {
                                                                        $getdeptOpt = "NOP";
                                                                    }



                                                                    $FinalYear = substr($GetTheSession, 0, 4);
                                                                    for ($i = $iniNext; $i <= $_SESSION["getNext"]; $i++) {

                                                                        include 'modulesInSess/initialise_all.php';

                                                                        if ($i == 1) {
                                                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                            if ($conn->connect_error) {
                                                                                die("Connection failed: " . $conn->connect_error);
                                                                            }

                                                                            $sql = "DELETE FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND deptOption =  '$getdeptOpt' AND curriculum =  '$curri'";
                                                                            $result = $conn->query($sql);
                                                                            /* if ($_SESSION['curricul'] == "YES") {
                                                                                $curri = $_SESSION["curri"];
                                                                                if ($deptoption == "YES") {
                                                                                    $sql = "DELETE FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND deptOption =  '$getdeptOpt' AND curriculum =  '$curri'";
                                                                                    $result = $conn->query($sql);
                                                                                } else {
                                                                                    $sql = "DELETE FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND curriculum =  '$curri'";
                                                                                    $result = $conn->query($sql);
                                                                                }
                                                                            } else {
                                                                                if ($deptoption == "YES") {
                                                                                    $sql = "DELETE FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND deptOption =  '$getdeptOpt'";
                                                                                    $result = $conn->query($sql);
                                                                                } else {
                                                                                    $sql = "DELETE FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept'";
                                                                                    $result = $conn->query($sql);
                                                                                }
                                                                            } */
                                                                            $conn->close();
                                                                        }


                                                                        $NON_DE_Senate = false;
                                                                        $DE200Senate = false;
                                                                        $DE300Senate = false;
                                                                        unset($getstuSession);
                                                                        $getstuSession[] = "";
                                                                        $StuSessCount = 0;
                                                                        $StartYear = $repairStd_yearAdtd[$i];
                                                                        //$StartYear = 2018;
                                                                        if ($SessCount == 5) {
                                                                            if ($StartYear < $txtYearAdmit) {
                                                                                $spillover[$i] = "YES";
                                                                            } else {
                                                                                $spillover[$i] = "NO";
                                                                            }
                                                                        } else {
                                                                            $spillover[$i] = "NO";
                                                                        }
                                                                        for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                                            $StuSessCount++;
                                                                            $getstuSession[$StuSessCount] = $x . "/" . ($x + 1);
                                                                            //echo $repairRegno[$i].", ".$getstuSession[$x];
                                                                            //echo "<br>";
                                                                        }

                                                                        if ($_SESSION['InstType'] == "University") {
                                                                            if ($repairmodeofentry[$i] == "UTME") {
                                                                                $NON_DE_Senate = true;
                                                                                $DE200Senate = false;
                                                                                $DE300Senate = false;
                                                                            } else {
                                                                                if ($repairEntry_Level[$i] == 100) {
                                                                                    $NON_DE_Senate = true;
                                                                                    $DE200Senate = false;
                                                                                    $DE300Senate = false;
                                                                                } elseif ($repairEntry_Level[$i] == 200) {
                                                                                    $NON_DE_Senate = false;
                                                                                    $DE200Senate = true;
                                                                                    $DE300Senate = false;
                                                                                } elseif ($repairEntry_Level[$i] == 300) {
                                                                                    $NON_DE_Senate = false;
                                                                                    $DE200Senate = false;
                                                                                    $DE300Senate = true;
                                                                                }
                                                                            }
                                                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                                            $NON_DE_Senate = true;
                                                                            $DE200Senate = false;
                                                                            $DE300Senate = false;
                                                                        } else {
                                                                        }

                                                                        $InSessionSemester = $GetTheSemester;
                                                                        include 'modulesInSess/CalculateResults.php';

                                                                        $repairToTOuts[$i] = $TotGetUnit2 + $Total_C_F;
                                                                        $tstFailedCs[$i] = $strDefficiency;
                                                                        //$CachCourse = $repairIteration;


                                                                    }

                                                                    $_SESSION["repairIteration"] = $repairIteration;
                                                                    $_SESSION['repairRegno'] = $repairRegno;
                                                                    $_SESSION['repairDeptOpt'] = $repairDeptOpt;
                                                                    $_SESSION['repairName'] = $repairName;
                                                                    $_SESSION['repairFname'] = $repairFname;
                                                                    $_SESSION['repairSname'] = $repairSname;
                                                                    $_SESSION['repairOname'] = $repairOname;
                                                                    $_SESSION['repairSex'] = $repairSex;
                                                                    $_SESSION['repairEntry_Level'] = $repairEntry_Level;
                                                                    $_SESSION['repairStd_yearAdtd'] = $repairStd_yearAdtd;
                                                                    $_SESSION["repairmodeofentry"] = $repairmodeofentry;
                                                                    $_SESSION['repairPrvCrTaken'] = $repairPrvCrTaken;
                                                                    $_SESSION['repairPrvCP'] = $repairPrvCP;
                                                                    $_SESSION['repairPrvGP'] = $repairPrvGP;
                                                                    $_SESSION['repairPrvCGPA'] = $repairPrvCGPA;
                                                                    $_SESSION['repairPresCrTaken'] = $repairPresCrTaken;
                                                                    $_SESSION['repairPresCP'] = $repairPresCP;
                                                                    $_SESSION['repairPresGP'] = $repairPresGP;
                                                                    $_SESSION['repairPresCGPA'] = $repairPresCGPA;
                                                                    $_SESSION['repairCumCrTaken'] = $repairCumCrTaken;
                                                                    $_SESSION['repairCumCP'] = $repairCumCP;
                                                                    $_SESSION['repairCumGP'] = $repairCumGP;
                                                                    $_SESSION['repairCumCGPA'] = $repairCumCGPA;
                                                                    $_SESSION['THE_REMARK'] = $THE_REMARK;
                                                                    $_SESSION['tstFailedCs'] = $tstFailedCs;
                                                                    $_SESSION['repairToTOuts'] = $repairToTOuts;
                                                                    $_SESSION['repairCGPA100'] = $repairCGPA100;
                                                                    $_SESSION['repairCGPA200'] = $repairCGPA200;
                                                                    $_SESSION['repairCGPA300'] = $repairCGPA300;
                                                                    $_SESSION['repairCGPA400'] = $repairCGPA400;
                                                                    $_SESSION['repairCGPA500'] = $repairCGPA500;
                                                                    $_SESSION["cursemcourses"] = $cursemcourses;
                                                                    $_SESSION["spillover"] = $spillover;

                                                                    $_SESSION["repairdob"] = $repairdob;
                                                                    $_SESSION["repairp_address"] = $repairp_address;
                                                                    $_SESSION["repairdeptfull"] = $repairdeptfull;
                                                                    $_SESSION["repairprogfull"] = $repairprogfull;
                                                                    $_SESSION["repaireyearadmt"] = $repaireyearadmt;

                                                                    $_SESSION["repairemail"] = $repairemail;
                                                                    $_SESSION["repairphone"] = $repairphone;
                                                                    $_SESSION["repairm_status"] = $repairm_status;
                                                                    $_SESSION["repairJANB_no"] = $repairJANB_no;


                                                                    $_SESSION["repairsem_C_F"] = $repairsem_C_F;
                                                                    $_SESSION["repairprev_C_F"] = $repairprev_C_F;
                                                                    $_SESSION["repaircum_C_F"] = $repaircum_C_F;
                                                                    $_SESSION["repairnumb_Course_failed"] = $repairnumb_Course_failed;

                                                                    $_SESSION["ArraystuRequiremtCode"] = $ArraystuRequiremtCode;
                                                                    $_SESSION["ArraystuRequiremtFreq"] = $ArraystuRequiremtFreq;
                                                                    $_SESSION["ArraystuRequiremtRegNo"] = $ArraystuRequiremtRegNo;
                                                                    $_SESSION["ArraystuRequiremtCount"] = $ArraystuRequiremtCount;
                                                                    $_SESSION["ArraystuRequiremtModeEntry"] = $ArraystuRequiremtModeEntry;

                                                                    $_SESSION["countdefCCode"] = $countdefCCode;
                                                                    $_SESSION["RegdefCCode"] = $RegdefCCode;
                                                                    $_SESSION["StudefCCode"] = $StudefCCode;
                                                                    $_SESSION["TitledefCCode"] = $TitledefCCode;
                                                                    $_SESSION["UnitdefCCode"] = $UnitdefCCode;

                                                                    //$_SESSION["relevantCourse"] = $relevantCourse;
                                                                    //$_SESSION["countrelevantCourse"] = $countrelevantCourse;
                                                                    //$_SESSION["getNext"]=$i+1;

                                                                    $RecComplete = ($_SESSION["getNext"] / $_SESSION["repairIteration"]) * 100;
                                                                    $PercComplt = round($RecComplete);
                                                                    //echo "Last Next: ".$_SESSION["getNext"];
                                                                    $prevRec = $_SESSION["getNext"];
                                                                    $nextRec = $_SESSION["getNext"] + 75;
                                                                    ?>
                                                        <div class="progress light m-md">
                                                            <div class="progress-bar progress-bar-primary"
                                                                role="progressbar"
                                                                aria-valuenow="<?php echo $PercComplt ?>"
                                                                aria-valuemin="0" aria-valuemax="100"
                                                                style="width: <?php echo $PercComplt ?>%;">
                                                                <?php echo $PercComplt ?>% Complete
                                                            </div>

                                                        </div>
                                                        <?php
                                                                    if ($_SESSION["getNext"] + 75 < $_SESSION["repairIteration"]) {
                                                                        echo "<h3>Click Next to process  $prevRec to $nextRec of $repairIteration Records ...</h3>";
                                                                    } else {
                                                                        if ($_SESSION["getNext"] < $repairIteration) {
                                                                            echo "<h3>Click Next to process  $prevRec to $repairIteration of $repairIteration Records ...</h3>";
                                                                        } else {
                                                                            echo "<h3>Click Finish ...</h3>";
                                                                        }
                                                                    }
                                                                    ?>
                                                        <?php

                                                                    //include 'modulesInSess/SubProcessResultsDE200.php';

                                                                }
                                                            }
                                                            ?>
                                                        <div style="text-align: right">
                                                            <form class="form-horizontal form-bordered" method="post">
                                                                <?php if ($_SESSION["getNext"] < $repairIteration) { ?>
                                                                <button type="submit" name="submitNext1"
                                                                    class="btn btn-success btn-sm"
                                                                    style="border-radius:40px;">Next ></button>
                                                                <?php } else { ?>
                                                                <button type="submit" name="submitfinish"
                                                                    class="btn btn-primary btn-sm"
                                                                    style="border-radius:40px;">Finish</button>
                                                                <?php } ?>
                                                            </form>
                                                        </div>

                                                    </div>
                                                </section>
                                            </div>
                                            <div class="col-md-3">

                                            </div>

                                        </div>

                                    </section>
                                </div>
                            </div>
                            <?php } ?>
                            <hr class="separator" />


                            <div class="row">
                                <?php if (isset($_POST["submitres"]) || isset($_POST["submitfinal"]) || isset($_POST["submitfinalfinal"])) {
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                    if ($conn2->connect_error) {
                                        die("Connection failed: " . $conn2->connect_error);
                                    }

                                    $repairIteration = $_SESSION["repairIteration"];
                                    $txtLevelPlus = $_SESSION['LevelPlus'];
                                    $GetTheSemester = $_SESSION['resultsemester'];
                                    $getdept = $_SESSION['deptcode'];
                                    $GetTheSession = $_SESSION['resultsession'];
                                    $repairRegno = $_SESSION['repairRegno'];
                                    $getyearGrad = $_SESSION["getyearGrad"];

                                    $repairDeptOpt = $_SESSION['repairDeptOpt'];
                                    $repairName = $_SESSION['repairName'];
                                    $repairFname = $_SESSION['repairFname'];
                                    $repairSname = $_SESSION['repairSname'];
                                    $repairOname = $_SESSION['repairOname'];
                                    $repairSex = $_SESSION['repairSex'];
                                    $repairEntry_Level = $_SESSION['repairEntry_Level'];
                                    $repairStd_yearAdtd = $_SESSION['repairStd_yearAdtd'];
                                    $repairmodeofentry = $_SESSION["repairmodeofentry"];
                                    $repairPrvCrTaken = $_SESSION['repairPrvCrTaken'];
                                    $repairPrvCP = $_SESSION['repairPrvCP'];
                                    $repairPrvGP = $_SESSION['repairPrvGP'];
                                    $repairPrvCGPA = $_SESSION['repairPrvCGPA'];
                                    $repairPresCrTaken = $_SESSION['repairPresCrTaken'];
                                    $repairPresCP = $_SESSION['repairPresCP'];
                                    $repairPresGP = $_SESSION['repairPresGP'];
                                    $repairPresCGPA = $_SESSION['repairPresCGPA'];
                                    $repairCumCrTaken = $_SESSION['repairCumCrTaken'];
                                    $repairCumCP = $_SESSION['repairCumCP'];
                                    $repairCumGP = $_SESSION['repairCumGP'];
                                    $repairCumCGPA = $_SESSION['repairCumCGPA'];
                                    $THE_REMARK = $_SESSION['THE_REMARK'];
                                    $tstFailedCs = $_SESSION['tstFailedCs'];
                                    $repairToTOuts = $_SESSION['repairToTOuts'];
                                    $repairCGPA100 = $_SESSION['repairCGPA100'];
                                    $repairCGPA200 = $_SESSION['repairCGPA200'];
                                    $repairCGPA300 = $_SESSION['repairCGPA300'];
                                    $repairCGPA400 = $_SESSION['repairCGPA400'];
                                    $repairCGPA500 = $_SESSION['repairCGPA500'];
                                    $spillover = $_SESSION["spillover"];

                                    $repairdob = $_SESSION["repairdob"];
                                    $repairp_address = $_SESSION["repairp_address"];
                                    $repairdeptfull =  $_SESSION["repairdeptfull"];
                                    $repairprogfull = $_SESSION["repairprogfull"];
                                    $repaireyearadmt = $_SESSION["repaireyearadmt"];

                                    $repairemail = $_SESSION["repairemail"];
                                    $repairphone = $_SESSION["repairphone"];
                                    $repairm_status = $_SESSION["repairm_status"];
                                    $repairJANB_no = $_SESSION["repairJANB_no"];

                                    $repairStdid = $_SESSION["repairStdid"];
                                    $repairState = $_SESSION["repairState"];
                                    $repairLGA = $_SESSION["repairLGA"];
                                    $repairstu_group = $_SESSION["repairstu_group"];
                                    $repairduration_time = $_SESSION["repairduration_time"];

                                    $repairsem_C_F = $_SESSION["repairsem_C_F"];
                                    $repairprev_C_F = $_SESSION["repairprev_C_F"];
                                    $repaircum_C_F = $_SESSION["repaircum_C_F"];
                                    $repairnumb_Course_failed = $_SESSION["repairnumb_Course_failed"];

                                    $deptoption = $_SESSION['deptoption'];
                                    $SessCount = $_SESSION["SessCount"];

                                    $ArraystuRequiremtCode = $_SESSION["ArraystuRequiremtCode"];
                                    $ArraystuRequiremtFreq = $_SESSION["ArraystuRequiremtFreq"];
                                    $ArraystuRequiremtRegNo = $_SESSION["ArraystuRequiremtRegNo"];
                                    $ArraystuRequiremtCount = $_SESSION["ArraystuRequiremtCount"];
                                    $ArraystuRequiremtModeEntry = $_SESSION["ArraystuRequiremtModeEntry"];

                                    $countdefCCode = $_SESSION["countdefCCode"];
                                    $RegdefCCode = $_SESSION["RegdefCCode"];
                                    $StudefCCode = $_SESSION["StudefCCode"];
                                    $TitledefCCode = $_SESSION["TitledefCCode"];
                                    $UnitdefCCode = $_SESSION["UnitdefCCode"];

                                    $deptdb = $_SESSION['deptdb'];
                                    $dept_db = $deptdb . strtolower($getdept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }

                                    if (isset($_POST["submitres"])) {

                                        $dept_scrutiny_senate = "scrutiny_senate";

                                        if ($_SESSION['curricul'] == "YES") {
                                            $curri = $_SESSION["curri"];
                                            if ($deptoption == "YES") {
                                                $getdeptOpt = $_SESSION["getdeptOpt"];
                                                $sql = "DELETE FROM " . $dept_scrutiny_senate . " WHERE session1  = '$GetTheSession' AND semester = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptOpt = '$getdeptOpt' AND curriculum = '$curri'";
                                            } else {
                                                $sql = "DELETE FROM " . $dept_scrutiny_senate . " WHERE session1  = '$GetTheSession' AND semester = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND curriculum = '$curri'";
                                            }
                                        } else {
                                            $curri = "OLD";
                                            if ($deptoption == "YES") {
                                                $getdeptOpt = $_SESSION["getdeptOpt"];
                                                $sql = "DELETE FROM " . $dept_scrutiny_senate . " WHERE session1  = '$GetTheSession' AND semester = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptOpt = '$getdeptOpt'";
                                            } else {
                                                $sql = "DELETE FROM " . $dept_scrutiny_senate . " WHERE session1  = '$GetTheSession' AND semester = '$GetTheSemester' AND Level1 =  '$txtLevelPlus'";
                                            }
                                        }
                                        $result = $conn_stu->query($sql);

                                        for ($i = 1; $i <= $repairIteration; $i++) {
                                            $newName1 = str_replace("'", "''", $repairName[$i]);
                                            $newfname = str_replace("'", "''", $repairFname[$i]);
                                            $newsname = str_replace("'", "''", $repairSname[$i]);
                                            $newoname = str_replace("'", "''", $repairOname[$i]);
                                            $stateOfOrigin = str_replace("'", "''", $repairState[$i]);
                                            $lga = str_replace("'", "''", $repairLGA[$i]);
                                            $p_address = str_replace("'", "''", $repairp_address[$i]);
                                            $sql = "INSERT INTO " . $dept_scrutiny_senate . "(Regn, Name1, fname, sname, oname, sex, stateOfOrigin, lga, stu_group, duration_time, DeptOpt, curriculum, CGPA100, CGPA200, CGPA300, CGPA400, PCT, PCP, PGP, PCGPA, SCT, SCP, SGP, SGPA, TCT, TCP, CGP, CGPA, RMK, def_out, semester, session1, Level1, yearGrad, spillover, mode_entry, prev_C_F, sem_C_F, cum_C_F, numb_Course_failed, dob, p_address, deptfull, progfull, yearadmt, email, phone, m_status, JAMB_no)VALUES('$repairRegno[$i]', '$newName1', '$newfname', '$newsname', '$newoname', '$repairSex[$i]', '$stateOfOrigin', '$lga', '$repairstu_group[$i]', '$repairduration_time[$i]', '$repairDeptOpt[$i]', '$curri', '$repairCGPA100[$i]', '$repairCGPA200[$i]', '$repairCGPA300[$i]', '$repairCGPA400[$i]', '$repairPrvCrTaken[$i]', '$repairPrvCP[$i]', '$repairPrvGP[$i]', '$repairPrvCGPA[$i]', '$repairPresCrTaken[$i]', '$repairPresCP[$i]', '$repairPresGP[$i]', '$repairPresCGPA[$i]', '$repairCumCrTaken[$i]', '$repairCumCP[$i]', '$repairCumGP[$i]', '$repairCumCGPA[$i]', '$THE_REMARK[$i]', '$tstFailedCs[$i]', '$GetTheSemester', '$GetTheSession', '$txtLevelPlus', '$getyearGrad', '$spillover[$i]', '$repairmodeofentry[$i]', '$repairprev_C_F[$i]', '$repairsem_C_F[$i]', '$repaircum_C_F[$i]', '$repairnumb_Course_failed[$i]', '$repairdob[$i]', '$p_address', '$repairdeptfull[$i]', '$repairprogfull[$i]', '$repaireyearadmt[$i]', '$repairemail[$i]', '$repairphone[$i]', '$repairm_status[$i]', '$repairJANB_no[$i]')";
                                            $result = $conn_stu->query($sql);
                                        }


                                        /* if ($SessCount == 1) {
                                            for ($i = 1; $i <= $repairIteration; $i++) {
                                                $sql = "INSERT INTO " . $dept_scrutiny_senate . "(Regn, Name1, fname, sname, oname, sex, stateOfOrigin, lga, DeptOpt, curriculum, CGPA100, CGPA200, CGPA300, CGPA400, PCT, PCP, PGP, PCGPA, SCT, SCP, SGP, SGPA, TCT, TCP, CGP, CGPA, RMK, def_out, semester, session1, Level1, yearGrad, spillover, mode_entry, prev_C_F, sem_C_F, cum_C_F, numb_Course_failed)VALUES('$repairRegno[$i]', '$repairName[$i]', '$repairFname[$i]', '$repairSname[$i]', '$repairOname[$i]', '$repairSex[$i]', '$repairState[$i]', '$repairLGA[$i]', '$repairDeptOpt[$i]', '$curri', '0', '0', '0', '0', '$repairPrvCrTaken[$i]', '$repairPrvCP[$i]', '$repairPrvGP[$i]', '$repairPrvCGPA[$i]', '$repairPresCrTaken[$i]', '$repairPresCP[$i]', '$repairPresGP[$i]', '$repairPresCGPA[$i]', '$repairCumCrTaken[$i]', '$repairCumCP[$i]', '$repairCumGP[$i]', '$repairCumCGPA[$i]', '$THE_REMARK[$i]', '$tstFailedCs[$i]', '$GetTheSemester', '$GetTheSession', '$txtLevelPlus', '$getyearGrad', '$spillover[$i]', '$repairmodeofentry[$i]', '$repairprev_C_F[$i]', '$repairsem_C_F[$i]', '$repaircum_C_F[$i]', '$repairnumb_Course_failed[$i]')";
                                                $result = $conn_stu->query($sql);
                                            }
                                        } elseif ($SessCount == 2) {
                                            for ($i = 1; $i <= $repairIteration; $i++) {
                                                $sql = "INSERT INTO " . $dept_scrutiny_senate . "(Regn, Name1, fname, sname, oname, sex, stateOfOrigin, lga, DeptOpt, curriculum, CGPA100, CGPA200, CGPA300, CGPA400, PCT, PCP, PGP, PCGPA, SCT, SCP, SGP, SGPA, TCT, TCP, CGP, CGPA, RMK, def_out, semester, session1, Level1, yearGrad, spillover, mode_entry, prev_C_F, sem_C_F, cum_C_F, numb_Course_failed)VALUES('$repairRegno[$i]', '$repairName[$i]', '$repairFname[$i]', '$repairSname[$i]', '$repairOname[$i]', '$repairSex[$i]', '$repairState[$i]', '$repairLGA[$i]', '$repairDeptOpt[$i]', '$curri', '$repairCGPA100[$i]', '0', '0', '0', '$repairPrvCrTaken[$i]', '$repairPrvCP[$i]', '$repairPrvGP[$i]', '$repairPrvCGPA[$i]', '$repairPresCrTaken[$i]', '$repairPresCP[$i]', '$repairPresGP[$i]', '$repairPresCGPA[$i]', '$repairCumCrTaken[$i]', '$repairCumCP[$i]', '$repairCumGP[$i]', '$repairCumCGPA[$i]', '$THE_REMARK[$i]', '$tstFailedCs[$i]', '$GetTheSemester', '$GetTheSession', '$txtLevelPlus', '$getyearGrad', '$spillover[$i]', '$repairmodeofentry[$i]', '$repairprev_C_F[$i]', '$repairsem_C_F[$i]', '$repaircum_C_F[$i]', '$repairnumb_Course_failed[$i]')";
                                                $result = $conn_stu->query($sql);
                                            }
                                        } elseif ($SessCount == 3) {
                                            for ($i = 1; $i <= $repairIteration; $i++) {
                                                $sql = "INSERT INTO " . $dept_scrutiny_senate . "(Regn, Name1, fname, sname, oname, sex, stateOfOrigin, lga, DeptOpt, curriculum, CGPA100, CGPA200, CGPA300, CGPA400, PCT, PCP, PGP, PCGPA, SCT, SCP, SGP, SGPA, TCT, TCP, CGP, CGPA, RMK, def_out, semester, session1, Level1, yearGrad, spillover, mode_entry, prev_C_F, sem_C_F, cum_C_F, numb_Course_failed)VALUES('$repairRegno[$i]', '$repairName[$i]', '$repairFname[$i]', '$repairSname[$i]', '$repairOname[$i]', '$repairSex[$i]', '$repairState[$i]', '$repairLGA[$i]', '$repairDeptOpt[$i]', '$curri', '$repairCGPA100[$i]', '$repairCGPA200[$i]', '0', '0', '$repairPrvCrTaken[$i]', '$repairPrvCP[$i]', '$repairPrvGP[$i]', '$repairPrvCGPA[$i]', '$repairPresCrTaken[$i]', '$repairPresCP[$i]', '$repairPresGP[$i]', '$repairPresCGPA[$i]', '$repairCumCrTaken[$i]', '$repairCumCP[$i]', '$repairCumGP[$i]', '$repairCumCGPA[$i]', '$THE_REMARK[$i]', '$tstFailedCs[$i]', '$GetTheSemester', '$GetTheSession', '$txtLevelPlus', '$getyearGrad', '$spillover[$i]', '$repairmodeofentry[$i]', '$repairprev_C_F[$i]', '$repairsem_C_F[$i]', '$repaircum_C_F[$i]', '$repairnumb_Course_failed[$i]')";
                                                $result = $conn_stu->query($sql);
                                            }
                                        } elseif ($SessCount == 4) {
                                            for ($i = 1; $i <= $repairIteration; $i++) {
                                                $sql = "INSERT INTO " . $dept_scrutiny_senate . "(Regn, Name1, fname, sname, oname, sex, stateOfOrigin, lga, DeptOpt, curriculum, CGPA100, CGPA200, CGPA300, CGPA400, PCT, PCP, PGP, PCGPA, SCT, SCP, SGP, SGPA, TCT, TCP, CGP, CGPA, RMK, def_out, semester, session1, Level1, yearGrad, spillover, mode_entry, prev_C_F, sem_C_F, cum_C_F, numb_Course_failed)VALUES('$repairRegno[$i]', '$repairName[$i]', '$repairFname[$i]', '$repairSname[$i]', '$repairOname[$i]', '$repairSex[$i]', '$repairState[$i]', '$repairLGA[$i]', '$repairDeptOpt[$i]', '$curri', '$repairCGPA100[$i]', '$repairCGPA200[$i]', '$repairCGPA300[$i]', '0', '$repairPrvCrTaken[$i]', '$repairPrvCP[$i]', '$repairPrvGP[$i]', '$repairPrvCGPA[$i]', '$repairPresCrTaken[$i]', '$repairPresCP[$i]', '$repairPresGP[$i]', '$repairPresCGPA[$i]', '$repairCumCrTaken[$i]', '$repairCumCP[$i]', '$repairCumGP[$i]', '$repairCumCGPA[$i]', '$THE_REMARK[$i]', '$tstFailedCs[$i]', '$GetTheSemester', '$GetTheSession', '$txtLevelPlus', '$getyearGrad', '$spillover[$i]', '$repairmodeofentry[$i]', '$repairprev_C_F[$i]', '$repairsem_C_F[$i]', '$repaircum_C_F[$i]', '$repairnumb_Course_failed[$i]')";
                                                $result = $conn_stu->query($sql);
                                            }
                                        } elseif ($SessCount == 5) {
                                            for ($i = 1; $i <= $repairIteration; $i++) {

                                                $sql = "INSERT INTO " . $dept_scrutiny_senate . "(Regn, Name1, fname, sname, oname, sex, stateOfOrigin, lga, DeptOpt, curriculum, CGPA100, CGPA200, CGPA300, CGPA400, PCT, PCP, PGP, PCGPA, SCT, SCP, SGP, SGPA, TCT, TCP, CGP, CGPA, RMK, def_out, semester, session1, Level1, yearGrad, spillover, mode_entry, prev_C_F, sem_C_F, cum_C_F, numb_Course_failed)VALUES('$repairRegno[$i]', '$repairName[$i]', '$repairFname[$i]', '$repairSname[$i]', '$repairOname[$i]', '$repairSex[$i]', '$repairState[$i]', '$repairLGA[$i]', '$repairDeptOpt[$i]', '$curri', '$repairCGPA100[$i]', '$repairCGPA200[$i]', '$repairCGPA300[$i]', '$repairCGPA400[$i]', '$repairPrvCrTaken[$i]', '$repairPrvCP[$i]', '$repairPrvGP[$i]', '$repairPrvCGPA[$i]', '$repairPresCrTaken[$i]', '$repairPresCP[$i]', '$repairPresGP[$i]', '$repairPresCGPA[$i]', '$repairCumCrTaken[$i]', '$repairCumCP[$i]', '$repairCumGP[$i]', '$repairCumCGPA[$i]', '$THE_REMARK[$i]', '$tstFailedCs[$i]', '$GetTheSemester', '$GetTheSession', '$txtLevelPlus', '$getyearGrad', '$spillover[$i]', '$repairmodeofentry[$i]', '$repairprev_C_F[$i]', '$repairsem_C_F[$i]', '$repaircum_C_F[$i]', '$repairnumb_Course_failed[$i]')";
                                                $result = $conn_stu->query($sql);
                                            }
                                        } */

                                        $dept_diff_outs_courses = "diff_outs_courses";
                                        if ($_SESSION['curricul'] == "YES") {
                                            $curri = $_SESSION["curri"];
                                            if ($curri == "OLD") {
                                                $curri2 = "";
                                            } else {
                                                $curri2 = "_" . $curri;
                                            }
                                            $deptgencourses = "gencourses" . $curri2;
                                        } else {
                                            $deptgencourses = "gencourses";
                                        }

                                        for ($i = 0; $i <= $countdefCCode; $i++) {

                                            $sql = "DELETE FROM " . $dept_diff_outs_courses . " WHERE Regn1  = '$RegdefCCode[$i]'";
                                            $result = $conn_stu->query($sql);


                                            $sql = "INSERT INTO " . $dept_diff_outs_courses . "(CCode, CTitle, CUnit, SemTaken, Regn1)VALUES('$StudefCCode[$i]', '$TitledefCCode[$i]', '$UnitdefCCode[$i]', '$GetTheSemester', '$RegdefCCode[$i]')";
                                            $result = $conn_stu->query($sql);
                                        }


                                        if ($_SESSION['curricul'] !== "YES") {
                                            $curri = "OLD";
                                        } else {
                                            $curri = $_SESSION["curri"];
                                        }

                                        if ($deptoption !== "YES") {
                                            $getdeptOpt = "NOP";
                                        } else {
                                            $getdeptOpt = $_SESSION["getdeptOpt"];
                                        }

                                        /* if ($_SESSION['curricul'] == "YES") {
                                            $curri = $_SESSION["curri"];
                                            if ($deptoption == "YES") {
                                                $getdeptOpt = $_SESSION["getdeptOpt"];
                                                $sql = "SELECT * FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND deptOption =  '$getdeptOpt' AND curriculum =  '$curri'";
                                            } else {
                                                $sql = "SELECT * FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND curriculum =  '$curri'";
                                            }
                                        } else {
                                            if ($deptoption == "YES") {
                                                $getdeptOpt = $_SESSION["getdeptOpt"];
                                                $sql = "SELECT * FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND deptOption =  '$getdeptOpt'";
                                            } else {
                                                $sql = "SELECT * FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept'";
                                            }
                                        } */

                                        $sql = "SELECT * FROM grade_cursem WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND deptOption =  '$getdeptOpt' AND curriculum =  '$curri'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $CCode = $row["CCode"];
                                                $GetUnit = 0;
                                                $GetSepCode = "";
                                                $GetSepCode2 = "";
                                                unset($CodeArray);
                                                unset($CodeArray2);
                                                $levelCode = (int)substr($row["CCode"], 3, 1);
                                                $sql6 = "SELECT * FROM " . $deptgencourses . " WHERE C_codding = '$CCode'";
                                                $result6 = $conn_stu->query($sql6);
                                                if ($result6->num_rows > 0) {
                                                    while ($row6 = $result6->fetch_assoc()) {
                                                        $GetUnit = $row6["credit"];
                                                        $GetTitle = $row6["C_title"];
                                                        if ($deptoption == "YES") {
                                                            $getdeptOpt = $_SESSION["getdeptOpt"];
                                                            $CStatus = $row6["Core_" . $getdeptOpt];
                                                        } else {
                                                            $CStatus = $row6["Core"];
                                                        }
                                                    }
                                                }

                                                if ($CStatus == "YES") {
                                                    $CStatus = "Core";
                                                } else {
                                                    $CStatus = "Elective";
                                                }
                                                $CodeArray = str_split($CCode);
                                                $CodeArray2 = str_split($CCode, 3);
                                                for ($i = 0; $i < 6; $i++) {
                                                    $GetSepCode = $GetSepCode . $CodeArray[$i] . " ";
                                                }
                                                for ($i = 0; $i < 2; $i++) {
                                                    $GetSepCode2 = $GetSepCode2 . $CodeArray2[$i] . " ";
                                                }

                                                if ($_SESSION['curricul'] !== "YES") {
                                                    $curri = "OLD";
                                                } else {
                                                    $curri = $_SESSION["curri"];
                                                }

                                                if ($deptoption !== "YES") {
                                                    $getdeptOpt = "NOP";
                                                } else {
                                                    $getdeptOpt = $_SESSION["getdeptOpt"];
                                                }
                                                $sql2 = "UPDATE grade_cursem SET levelCode ='$levelCode', CUnit ='$GetUnit', CTitle ='$GetTitle', CStatus ='$CStatus', CCodeSepr ='$GetSepCode', split_two ='$GetSepCode2' WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND CCode='$CCode' AND deptOption =  '$getdeptOpt' AND curriculum =  '$curri'";
                                                $result2 = $conn->query($sql2);

                                                /* if ($_SESSION['curricul'] == "YES") {
                                                    $curri = $_SESSION["curri"];
                                                    if ($deptoption == "YES") {
                                                        $getdeptOpt = $_SESSION["getdeptOpt"];
                                                        $sql2 = "UPDATE grade_cursem SET levelCode ='$levelCode', CUnit ='$GetUnit', CTitle ='$GetTitle', CStatus ='$CStatus', CCodeSepr ='$GetSepCode', split_two ='$GetSepCode2' WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND CCode='$CCode' AND deptOption =  '$getdeptOpt' AND curriculum =  '$curri'";
                                                        $result2 = $conn->query($sql2);
                                                    } else {
                                                        $sql2 = "UPDATE grade_cursem SET levelCode ='$levelCode', CUnit ='$GetUnit', CTitle ='$GetTitle', CStatus ='$CStatus', CCodeSepr ='$GetSepCode', split_two ='$GetSepCode2' WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND CCode='$CCode' AND curriculum =  '$curri'";
                                                        $result2 = $conn->query($sql2);
                                                    }
                                                } else {
                                                    if ($deptoption == "YES") {
                                                        $getdeptOpt = $_SESSION["getdeptOpt"];
                                                        $sql2 = "UPDATE grade_cursem SET levelCode ='$levelCode', CUnit ='$GetUnit', CTitle ='$GetTitle', CStatus ='$CStatus', CCodeSepr ='$GetSepCode', split_two ='$GetSepCode2' WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND CCode='$CCode' AND deptOption =  '$getdeptOpt'";
                                                        $result2 = $conn->query($sql2);
                                                    } else {
                                                        $sql2 = "UPDATE grade_cursem SET levelCode ='$levelCode', CUnit ='$GetUnit', CTitle ='$GetTitle', CStatus ='$CStatus', CCodeSepr ='$GetSepCode', split_two ='$GetSepCode2' WHERE session1  = '$GetTheSession' AND SemTaken = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND DeptCode =  '$getdept' AND CCode='$CCode'";
                                                        $result2 = $conn->query($sql2);
                                                    }
                                                } */
                                            }
                                        }

                                        for ($i = 1; $i <= $repairIteration; $i++) {
                                            $contsemester = 0;
                                            $FinalYear = substr($GetTheSession, 0, 4);
                                            // Get Start year from Matric Number
                                            $StartYear = $repairStd_yearAdtd[$i];
                                            for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                $getstuSession2 = $x . "/" . ($x + 1);
                                                $fsemexist = 0;
                                                $ssemexist = 0;
                                                $StuCurSess = str_ireplace("/", "_", $getstuSession2);
                                                $deptcorreg = "correg_" . $StuCurSess;

                                                $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]'";
                                                $result2 = $conn_stu->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {

                                                        if ($row2["SemTaken"] == "1ST") {
                                                            $fsemexist++;
                                                        } else {
                                                            $ssemexist++;
                                                        }
                                                    }
                                                }



                                                if ($getstuSession2 == $GetTheSession) {
                                                    if ($GetTheSemester == "1ST") {
                                                        if ($fsemexist > 0) {
                                                            $contsemester++;
                                                        }
                                                    } else {
                                                        if ($fsemexist > 0) {
                                                            $contsemester++;
                                                        }

                                                        if ($ssemexist > 0) {
                                                            $contsemester++;
                                                        }
                                                    }

                                                    break;
                                                } else {
                                                    if ($fsemexist > 0) {
                                                        $contsemester++;
                                                    }

                                                    if ($ssemexist > 0) {
                                                        $contsemester++;
                                                    }
                                                }
                                            }
                                            $sql6 = "UPDATE scrutiny_senate SET no_semester = '$contsemester' WHERE session1  = '$GetTheSession' AND semester = '$GetTheSemester' AND Level1 =  '$txtLevelPlus' AND Regn = '$repairRegno[$i]'";
                                            $result6 = $conn_stu->query($sql6);
                                        }
                                    }


                                    $repairIteration_2 = round($repairIteration / 2);
                                    if (isset($_POST["submitfinal"])) {

                                        $countgetstuRequiremt = 0;
                                        $ReqCode = "";
                                        $ReqName = "";
                                        for ($i = 1; $i <= $repairIteration_2; $i++) {

                                            $sql6 = "DELETE FROM grad_require WHERE Regn = '$repairRegno[$i]'";
                                            $result6 = $conn_stu->query($sql6);

                                            $getdept2 = strtoupper($getdept);
                                            if ($_SESSION['InstType'] == "University") {
                                                if ($_SESSION['curricul'] == "YES") {
                                                    $curri = $_SESSION["curri"];
                                                    $sql7 = "SELECT * FROM requirement_tab WHERE DeptCode  = '$getdept2' AND curri_Code = '$curri'";
                                                } else {
                                                    $sql7 = "SELECT * FROM requirement_tab WHERE DeptCode  = '$getdept2'";
                                                }
                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                if ($_SESSION['curricul'] == "YES") {
                                                    $curri = $_SESSION["curri"];
                                                    $sql7 = "SELECT * FROM requirement_tab_poly WHERE DeptCode  = '$getdept2' AND curri_Code = '$curri' AND prog = '$repairmodeofentry[$i]'";
                                                } else {
                                                    $sql7 = "SELECT * FROM requirement_tab_poly WHERE DeptCode  = '$getdept2' AND prog = '$repairmodeofentry[$i]'";
                                                }
                                            }


                                            $result7 = $conn->query($sql7);
                                            if ($result7->num_rows > 0) {
                                                while ($row7 = $result7->fetch_assoc()) {

                                                    $ReqCode = $row7["Requirement_Code"];
                                                    $ReqName = $row7["Requirement_Name"];
                                                    $countgetstuRequiremt = 0;

                                                    if ($_SESSION['InstType'] == "University") {
                                                        if ($repairmodeofentry[$i] == "UTME") {
                                                            $RequiredCr = $row7["Requirement_100"];
                                                        } else {
                                                            if ($repairEntry_Level[$i] == 100) {
                                                                $RequiredCr = $row7["Requirement_100"];
                                                            } elseif ($repairEntry_Level[$i] == 200) {
                                                                $RequiredCr = $row7["Requirement_DE200"];
                                                            } elseif ($repairEntry_Level[$i] == 300) {
                                                                $RequiredCr = $row7["Requirement_DE300"];
                                                            }
                                                        }
                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                        $RequiredCr = $row7["Requirement_100"];
                                                    } else {
                                                    }


                                                    $FinalYear = substr($GetTheSession, 0, 4);
                                                    $StartYear = $repairStd_yearAdtd[$i];
                                                    for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                        $getstuSession2 = $x . "/" . ($x + 1);

                                                        $StuCurSess = str_ireplace("/", "_", $getstuSession2);
                                                        $deptcorreg = "correg_" . $StuCurSess;

                                                        $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]' AND CNature = '$ReqCode' AND SessionRegis = '$getstuSession2'";
                                                        $result2 = $conn_stu->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $CCode1 = $row2["CCode"];
                                                                if (empty($row2['CA'])) {
                                                                    $repairCA = 0;
                                                                } else {
                                                                    $repairCA = (float)$row2['CA'];
                                                                }

                                                                if (empty($row2['Exam'])) {
                                                                    $repairEXAM = 0;
                                                                } else {
                                                                    $repairEXAM = (float)$row2['Exam'];
                                                                }
                                                                if ($row2["noexam"] == "YES") {
                                                                    $repairTOTAL = 0;
                                                                } else {
                                                                    $repairTOTAL = $repairCA + $repairEXAM;
                                                                }
                                                                if ($repairTOTAL >= 40) {
                                                                    $countgetstuRequiremt = $countgetstuRequiremt + (int)$row2["CUnit"];
                                                                }
                                                            }
                                                        }
                                                    }

                                                    $sql6 = "INSERT INTO grad_require(Regn, title1, require1, earned, reqCode)VALUES('$repairRegno[$i]', '$ReqName', '$RequiredCr', '$countgetstuRequiremt', '$ReqCode')";
                                                    $result6 = $conn_stu->query($sql6);
                                                }
                                            }
                                        }
                                    }
                                    if (isset($_POST["submitfinalfinal"])) {


                                        $DEFCount = 0;
                                        $IGSCount = 0;
                                        $SP1Count = 0;
                                        $SP2Count = 0;
                                        $PCount = 0;
                                        $DLCount = 0;
                                        $VCLCount = 0;
                                        $Ten88Count = 0;
                                        $BL2Count = 0;

                                        $countgetstuRequiremt = 0;
                                        $ReqCode = "";
                                        $ReqName = "";

                                        $deptdb = $_SESSION['deptdb'];
                                        $dept_db = $deptdb . strtolower($getdept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        for ($i = $repairIteration_2 + 1; $i <= $repairIteration; $i++) {

                                            $sql6 = "DELETE FROM grad_require WHERE Regn = '$repairRegno[$i]'";
                                            $result6 = $conn_stu->query($sql6);

                                            $getdept2 = strtoupper($getdept);
                                            if ($_SESSION['InstType'] == "University") {
                                                if ($_SESSION['curricul'] == "YES") {
                                                    $curri = $_SESSION["curri"];
                                                    $sql7 = "SELECT * FROM requirement_tab WHERE DeptCode  = '$getdept2' AND curri_Code = '$curri'";
                                                } else {
                                                    $sql7 = "SELECT * FROM requirement_tab WHERE DeptCode  = '$getdept2'";
                                                }
                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                if ($_SESSION['curricul'] == "YES") {
                                                    $curri = $_SESSION["curri"];
                                                    $sql7 = "SELECT * FROM requirement_tab_poly WHERE DeptCode  = '$getdept2' AND curri_Code = '$curri' AND prog = '$repairmodeofentry[$i]'";
                                                } else {
                                                    $sql7 = "SELECT * FROM requirement_tab_poly WHERE DeptCode  = '$getdept2' AND prog = '$repairmodeofentry[$i]'";
                                                }
                                            }


                                            $result7 = $conn->query($sql7);
                                            if ($result7->num_rows > 0) {
                                                while ($row7 = $result7->fetch_assoc()) {

                                                    $ReqCode = $row7["Requirement_Code"];
                                                    $ReqName = $row7["Requirement_Name"];
                                                    $countgetstuRequiremt = 0;

                                                    if ($_SESSION['InstType'] == "University") {
                                                        if ($repairmodeofentry[$i] == "UTME") {
                                                            $RequiredCr = $row7["Requirement_100"];
                                                        } else {
                                                            if ($repairEntry_Level[$i] == 100) {
                                                                $RequiredCr = $row7["Requirement_100"];
                                                            } elseif ($repairEntry_Level[$i] == 200) {
                                                                $RequiredCr = $row7["Requirement_DE200"];
                                                            } elseif ($repairEntry_Level[$i] == 300) {
                                                                $RequiredCr = $row7["Requirement_DE300"];
                                                            }
                                                        }
                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                        $RequiredCr = $row7["Requirement_100"];
                                                    } else {
                                                    }

                                                    /* if ((int)substr($repairRegno[$i], 5, 1) == 2) {
                                                        $RequiredCr = $row7["Requirement_DE200"];
                                                    } elseif ((int)substr($repairRegno[$i], 5, 1) == 3) {
                                                        $RequiredCr = $row7["Requirement_DE300"];
                                                    } else {
                                                        $RequiredCr = $row7["Requirement_100"];
                                                    } */


                                                    $FinalYear = substr($GetTheSession, 0, 4);
                                                    $StartYear = $repairStd_yearAdtd[$i];
                                                    for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                        $getstuSession2 = $x . "/" . ($x + 1);

                                                        $StuCurSess = str_ireplace("/", "_", $getstuSession2);
                                                        $deptcorreg = "correg_" . $StuCurSess;

                                                        $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]' AND CNature = '$ReqCode' AND SessionRegis = '$getstuSession2'";
                                                        $result2 = $conn_stu->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $CCode1 = $row2["CCode"];
                                                                if (empty($row2['CA'])) {
                                                                    $repairCA = 0;
                                                                } else {
                                                                    $repairCA = (float)$row2['CA'];
                                                                }

                                                                if (empty($row2['Exam'])) {
                                                                    $repairEXAM = 0;
                                                                } else {
                                                                    $repairEXAM = (float)$row2['Exam'];
                                                                }
                                                                if ($row2["noexam"] == "YES") {
                                                                    $repairTOTAL = 0;
                                                                } else {
                                                                    $repairTOTAL = $repairCA + $repairEXAM;
                                                                }
                                                                if ($repairTOTAL >= 40) {
                                                                    $countgetstuRequiremt = $countgetstuRequiremt + (int)$row2["CUnit"];
                                                                }
                                                            }
                                                        }
                                                    }

                                                    $sql6 = "INSERT INTO grad_require(Regn, title1, require1, earned, reqCode)VALUES('$repairRegno[$i]', '$ReqName', '$RequiredCr', '$countgetstuRequiremt', '$ReqCode')";
                                                    $result6 = $conn_stu->query($sql6);
                                                }
                                            }
                                        }
                                        for ($i = 1; $i <= $repairIteration; $i++) {
                                            if ($THE_REMARK[$i] == "P") {
                                                $PCount++;
                                            } elseif ($THE_REMARK[$i] == "IGS") {
                                                $IGSCount++;
                                            } elseif ($THE_REMARK[$i] == "DEF") {
                                                $DEFCount++;
                                            } elseif ($THE_REMARK[$i] == "SP1") {
                                                $SP1Count++;
                                            } elseif ($THE_REMARK[$i] == "SP2") {
                                                $SP2Count++;
                                            } elseif ($THE_REMARK[$i] == "DL") {
                                                $DLCount++;
                                            } elseif ($THE_REMARK[$i] == "VL") {
                                                $VCLCount++;
                                            } elseif ($THE_REMARK[$i] == "8-7-6") {
                                                $Ten88Count++;
                                            } elseif ($THE_REMARK[$i] == "BL2") {
                                                $BL2Count++;
                                            }
                                        }

                                        if ($_SESSION['deptoption'] == "YES") {
                                            $getdeptOpt =  $_SESSION["getdeptOpt"];
                                            if ($_SESSION['curricul'] == "YES") {
                                                $curri = $_SESSION["curri"];
                                            } else {
                                                $curri = "OLD";
                                            }
                                        } else {
                                            $getdeptOpt =  "NOP";
                                            if ($_SESSION['curricul'] == "YES") {
                                                $curri = $_SESSION["curri"];
                                            } else {
                                                $curri = "OLD";
                                            }
                                        }
                                        $getyearGrad = $_SESSION["getyearGrad"];
                                        $sql = "DELETE FROM hod_semester_res_approval WHERE session_apprv  = '$GetTheSession' AND semester_apprv  = '$GetTheSemester' AND Level_Apprv  = '$txtLevelPlus' AND deptCode  = '$getdept' AND deptoption  = '$getdeptOpt' AND curriculum  = '$curri' AND yeargrad = '$getyearGrad'";
                                        $result = $conn->query($sql);

                                        $sql = "INSERT INTO hod_semester_res_approval(session_apprv, semester_apprv, Level_Apprv, deptCode, Approval, VL, DL, IGS, DEF, P, SP1, SP2, eight76, BL2, total1, deptoption, curriculum, yeargrad)VALUES( '$GetTheSession', '$GetTheSemester',  '$txtLevelPlus', '$getdept', 'NO', '$VCLCount', '$DLCount', '$IGSCount', '$DEFCount', '$PCount', '$SP1Count', '$SP2Count', '$Ten88Count', '$BL2Count', '$repairIteration', '$getdeptOpt', '$curri', '$getyearGrad')";
                                        $result = $conn->query($sql);
                                    }
                                    $conn->close();
                                    $conn2->close();
                                    $conn_stu->close();
                                ?>
                                <section class="panel">
                                    <header class="panel-heading">
                                        <div class="panel-actions">
                                            <a href="#" class="fa fa-caret-down"></a>
                                            <a href="#" class="fa fa-times"></a>
                                        </div>
                                        <div class="row" style="font-size: large">
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <label class="control-label col-lg-5" style="text-align: right">Year
                                                        Admitted:</label>
                                                    <label class="control-label col-lg-5"
                                                        style="text-align: left"><?php echo $_SESSION["txtYearAdmit"] ?></label>

                                                </div>
                                            </div>
                                            <div class="col-lg-2">
                                                <div class="form-group">
                                                    <label class="control-label col-lg-5"
                                                        style="text-align: right">Level:</label>
                                                    <label class="control-label col-lg-5"
                                                        style="text-align: left"><?php echo $_SESSION['lblYearAdmit'] ?></label>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label class="control-label col-lg-5"
                                                        style="text-align: right">Session:</label>
                                                    <label class="control-label col-lg-5"
                                                        style="text-align: left"><?php echo $_SESSION['resultsession'] ?></label>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label class="control-label col-lg-5"
                                                        style="text-align: right">Semester:</label>
                                                    <label class="control-label col-lg-5"
                                                        style="text-align: left"><?php echo $_SESSION['resultsemester'] ?></label>
                                                </div>
                                            </div>

                                        </div>

                                    </header>
                                    <div class="panel-body">
                                        <div class="col-md-3">

                                        </div>
                                        <div class="col-md-6">
                                            <section class="panel">
                                                <div class="panel-body">

                                                    <?php if (isset($_POST["submitres"])) { ?>
                                                    <div class="progress light m-md">
                                                        <div class="progress-bar progress-bar-success"
                                                            role="progressbar" aria-valuenow="30" aria-valuemin="0"
                                                            aria-valuemax="100" style="width: 30%;">
                                                            30% Complete
                                                        </div>

                                                    </div>
                                                    <h3>Click Next to Proceed ...</h3>
                                                    <?php } ?>
                                                    <?php if (isset($_POST["submitfinal"])) { ?>
                                                    <div class="progress light m-md">
                                                        <div class="progress-bar progress-bar-success"
                                                            role="progressbar" aria-valuenow="60" aria-valuemin="0"
                                                            aria-valuemax="100" style="width: 60%;">
                                                            60% Complete
                                                        </div>

                                                    </div>
                                                    <h3>Click Finish to Complete the Process ...</h3>
                                                    <?php } ?>
                                                    <?php if (isset($_POST["submitfinalfinal"])) { ?>
                                                    <div class="progress light m-md">
                                                        <div class="progress-bar progress-bar-primary"
                                                            role="progressbar" aria-valuenow="100" aria-valuemin="0"
                                                            aria-valuemax="100" style="width: 100%;">
                                                            100% Complete
                                                        </div>

                                                    </div>
                                                    <h3>Record Saved Successfully...</h3>
                                                    <?php } ?>
                                                    <div style="text-align: right">
                                                        <form class="form-horizontal form-bordered" method="post">
                                                            <?php if (isset($_POST["submitres"])) { ?>
                                                            <button type="submit" name="submitfinal"
                                                                class="btn btn-success btn-sm"
                                                                style="border-radius:40px;">Next ></button>
                                                            <?php } ?>
                                                            <?php if (isset($_POST["submitfinal"])) { ?>
                                                            <button type="submit" name="submitfinalfinal"
                                                                class="btn btn-primary btn-sm"
                                                                style="border-radius:40px;">Finish</button>
                                                            <?php } ?>
                                                        </form>
                                                    </div>
                                                </div>

                                            </section>
                                        </div>
                                        <div class="col-md-3">

                                        </div>
                                    </div>
                                    <hr>

                                </section>

                                <?php } ?>

                                <div class="row">
                                    <div class="col-lg-3">

                                    </div>
                                    <div class="col-lg-3">
                                        <h3>Session :- <?php echo $cursession ?></h3>
                                    </div>
                                    <div class="col-lg-3">
                                        <h3>Semester :- <?php echo $resultsemester ?></h3>
                                    </div>
                                    <div class="col-lg-3">

                                    </div>
                                </div>
                                <div class="row">
                                    <diV class="col-lg-3">

                                    </diV>
                                    <diV class="col-lg-6">
                                        <table class="table table-bordered table-striped mb-none">
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>Level </th>
                                                    <th>Approval</th>
                                                    <th>No of Students</th>
                                                    <?php if ($_SESSION['deptoption'] == "YES") { ?>
                                                    <th>Dept Option</th>
                                                    <?php } ?>
                                                    <?php if ($_SESSION['curricul'] == "YES") { ?>
                                                    <th>Curriculum</th>
                                                    <?php } ?>
                                                    <th>Action</th>
                                                    <th>Action</th>
                                                </tr>

                                            </thead>
                                            <tbody>

                                                <?php
                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }



                                                $dbsession = str_replace("/", "_", $cursession);
                                                $sql = "SELECT * FROM hod_semester_res_approval WHERE deptCode = '$dept' AND  session_apprv = '$cursession' AND  semester_apprv = '$resultsemester' ORDER BY Level_Apprv";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["sn"];
                                                        $Level_Apprv = $row["Level_Apprv"];
                                                        $Level_Apprv2 = $row["Level_Apprv"];
                                                        if ($_SESSION['InstType'] == "Polytechnic") {
                                                            if ($Level_Apprv == 100) {
                                                                $Level_Apprv2 = "ND I";
                                                            } elseif ($Level_Apprv == 200) {
                                                                $Level_Apprv2 = "ND II";
                                                            } elseif ($Level_Apprv == 300) {
                                                                $Level_Apprv2 = "HND I";
                                                            } elseif ($Level_Apprv == 400) {
                                                                $Level_Apprv2 = "HND II";
                                                            }
                                                        }
                                                        $approval = $row["Approval"];
                                                        $total1 = $row["total1"];


                                                        if ($_SESSION['deptoption'] == "YES") {
                                                            $deptoption = $row["deptoption"];
                                                            $sql2 = "SELECT * FROM dept_option WHERE deptcode =  '$getdept' AND Opt_Code = '$deptoption' ";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $OptTitle = $row2["Opt_Title"];
                                                                }
                                                            }
                                                        }

                                                        if ($_SESSION['curricul'] == "YES") {
                                                            $curriculum = $row["curriculum"];
                                                            $sql2 = "SELECT * FROM dept_curriculum WHERE deptcode = '$getdept' AND curri_Code = '$curriculum'";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $curri_Title = $row2["curri_Title"];
                                                                }
                                                            }
                                                        }

                                                        echo "<tr>";
                                                        echo "<td>$Level_Apprv2 </td><td>$approval</td>";
                                                        echo "<td>$total1</td>";
                                                        if ($_SESSION['deptoption'] == "YES") {
                                                            echo "<td>$OptTitle</td>";
                                                        }
                                                        if ($_SESSION['curricul'] == "YES") {
                                                            echo "<td>$curri_Title</td>";
                                                        }
                                                        echo "<td>";
                                                        echo "<form class='form-horizontal form-bordered' method='post' action='semester_res_approval_view.php'>";
                                                        echo "<input type='hidden' value='$id' name='id'>";
                                                        echo "<input type='submit' name='view' class='btn btn-success btn-xs' value='View'>";
                                                        echo "</form>";
                                                        echo "</td>";
                                                        echo "<td>";
                                                        if ($approval != "YES") {
                                                            echo "<form class='form-horizontal form-bordered' method='post' action=''>";
                                                            echo "<input type='hidden' value='$id' name='id'>";
                                                            echo "<input type='hidden' value='$Level_Apprv' name='levelappr'>";
                                                            echo "<input type='submit' name='deleteResGen' class='btn btn-danger btn-xs' value='Delete'>";
                                                            echo "</form>";
                                                        }

                                                        echo "</td>";
                                                        echo "</tr>";
                                                    }
                                                }
                                                $conn->close();

                                                ?>
                                            </tbody>
                                        </table>
                                    </diV>
                                    <diV class="col-lg-3">

                                    </diV>
                                </div>
                                <hr class="separator" />
                                <?php



                                $UnderDeclaration = false;

                                if (isset($_POST["submitfinish"])) {


                                    $txtLevelPlus = $_SESSION['LevelPlus'];
                                    $repairIteration = $_SESSION["repairIteration"];
                                    $deptcorreg = $getdept . "_correg";

                                    if ($_SESSION['InstType'] == "University") {

                                        $_SESSION['lblYearAdmit'] = $txtLevelPlus;
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        if ($txtLevelPlus == 100) {
                                            $_SESSION['lblYearAdmit'] = "ND I";
                                        } elseif ($txtLevelPlus == 200) {
                                            $_SESSION['lblYearAdmit'] = "ND II";
                                        } elseif ($txtLevelPlus == 300) {
                                            $_SESSION['lblYearAdmit'] = "HND I";
                                        } elseif ($txtLevelPlus == 400) {
                                            $_SESSION['lblYearAdmit'] = "HND II";
                                        }
                                    }


                                    if ($_SESSION['curricul'] == "YES") {
                                        $curri = $_SESSION["curri"];
                                        if ($curri == "OLD") {
                                            $curri2 = "";
                                        } else {
                                            $curri2 = "_" . $curri;
                                        }
                                        $deptgencourses = $getdept . "_gencourses" . $curri2;
                                    } else {
                                        $deptgencourses = $getdept . "_gencourses";
                                    }

                                    $GetTheSession = $_SESSION['resultsession'];
                                    $GetTheSemester = $_SESSION['resultsemester'];
                                    $txtYearAdmit = $_SESSION["txtYearAdmit"];
                                    $yearadmtInSess = $_SESSION["txtYearAdmit"];
                                    $repairRegno = $_SESSION['repairRegno'];
                                    $repairDeptOpt = $_SESSION['repairDeptOpt'];
                                    $repairName = $_SESSION['repairName'];
                                    $repairFname = $_SESSION['repairFname'];
                                    $repairSname = $_SESSION['repairSname'];
                                    $repairOname = $_SESSION['repairOname'];
                                    $repairSex = $_SESSION['repairSex'];
                                    $repairEntry_Level = $_SESSION['repairEntry_Level'];
                                    $repairStd_yearAdtd = $_SESSION['repairStd_yearAdtd'];
                                    $repairmodeofentry = $_SESSION["repairmodeofentry"];
                                    $repairPrvCrTaken = $_SESSION['repairPrvCrTaken'];
                                    $repairPrvCP = $_SESSION['repairPrvCP'];
                                    $repairPrvGP = $_SESSION['repairPrvGP'];
                                    $repairPrvCGPA = $_SESSION['repairPrvCGPA'];
                                    $repairPresCrTaken = $_SESSION['repairPresCrTaken'];
                                    $repairPresCP = $_SESSION['repairPresCP'];
                                    $repairPresGP = $_SESSION['repairPresGP'];
                                    $repairPresCGPA = $_SESSION['repairPresCGPA'];
                                    $repairCumCrTaken = $_SESSION['repairCumCrTaken'];
                                    $repairCumCP = $_SESSION['repairCumCP'];
                                    $repairCumGP = $_SESSION['repairCumGP'];
                                    $repairCumCGPA = $_SESSION['repairCumCGPA'];
                                    $THE_REMARK = $_SESSION['THE_REMARK'];
                                    $tstFailedCs = $_SESSION['tstFailedCs'];
                                    $repairToTOuts = $_SESSION['repairToTOuts'];
                                    $repairCGPA100 = $_SESSION['repairCGPA100'];
                                    $repairCGPA200 = $_SESSION['repairCGPA200'];
                                    $repairCGPA300 = $_SESSION['repairCGPA300'];
                                    $repairCGPA400 = $_SESSION['repairCGPA400'];
                                    $repairCGPA500 = $_SESSION['repairCGPA500'];
                                    $cursemcourses = $_SESSION["cursemcourses"];

                                    $repairStdid = $_SESSION["repairStdid"];
                                    $repairState = $_SESSION["repairState"];
                                    $repairLGA = $_SESSION["repairLGA"];
                                    $repairstu_group = $_SESSION["repairstu_group"];
                                    $repairduration_time = $_SESSION["repairduration_time"];

                                    $repairdob = $_SESSION["repairdob"];
                                    $repairp_address = $_SESSION["repairp_address"];
                                    $repairdeptfull =  $_SESSION["repairdeptfull"];
                                    $repairprogfull = $_SESSION["repairprogfull"];
                                    $repaireyearadmt = $_SESSION["repaireyearadmt"];

                                    $repairemail = $_SESSION["repairemail"];
                                    $repairphone = $_SESSION["repairphone"];
                                    $repairm_status = $_SESSION["repairm_status"];
                                    $repairJANB_no = $_SESSION["repairJANB_no"];

                                    $repairsem_C_F = $_SESSION["repairsem_C_F"];
                                    $repairprev_C_F = $_SESSION["repairprev_C_F"];
                                    $repaircum_C_F = $_SESSION["repaircum_C_F"];
                                    $repairnumb_Course_failed = $_SESSION["repairnumb_Course_failed"];

                                    $deptoption = $_SESSION['deptoption'];
                                    $SessCount = $_SESSION["SessCount"];

                                    $ArraystuRequiremtCode = $_SESSION["ArraystuRequiremtCode"];
                                    $ArraystuRequiremtFreq = $_SESSION["ArraystuRequiremtFreq"];
                                    $ArraystuRequiremtRegNo = $_SESSION["ArraystuRequiremtRegNo"];
                                    $ArraystuRequiremtCount = $_SESSION["ArraystuRequiremtCount"];
                                    $ArraystuRequiremtModeEntry = $_SESSION["ArraystuRequiremtModeEntry"];

                                    $countdefCCode = $_SESSION["countdefCCode"];
                                    $RegdefCCode = $_SESSION["RegdefCCode"];
                                    $StudefCCode = $_SESSION["StudefCCode"];
                                    $TitledefCCode = $_SESSION["TitledefCCode"];
                                    $UnitdefCCode = $_SESSION["UnitdefCCode"];


                                    include 'modulesInSess/modalCCreditTaken.php';

                                ?>
                                <div class="row" style="font-size: large">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" style="text-align: right">Year
                                                Admitted:</label>
                                            <label class="control-label col-lg-5"
                                                style="text-align: left"><?php echo $txtYearAdmit ?></label>

                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5"
                                                style="text-align: right">Level:</label>
                                            <label class="control-label col-lg-5"
                                                style="text-align: left"><?php echo $_SESSION['lblYearAdmit'] ?></label>

                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5"
                                                style="text-align: right">Session:</label>
                                            <label class="control-label col-lg-5"
                                                style="text-align: left"><?php echo $GetTheSession ?></label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5"
                                                style="text-align: right">Semester:</label>
                                            <label class="control-label col-lg-5"
                                                style="text-align: left"><?php echo $GetTheSemester ?></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <br>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped mb-none" id="datatable-default">
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Matric No</th>
                                                <th>Name</th>

                                                <?php if ($deptoption == "YES") { ?>
                                                <th>Option Code</th>
                                                <?php } ?>
                                                <th>Grades</th>
                                                <?php if ($SessCount == 2) { ?>
                                                <th style="font-size: 10px">100L CGPA</th>
                                                <?php } ?>
                                                <?php if ($SessCount == 3) { ?>
                                                <th style="font-size: 10px">100L CGPA</th>
                                                <th style="font-size: 10px">200L CGPA</th>
                                                <?php } ?>
                                                <?php if ($SessCount == 4) { ?>
                                                <th style="font-size: 10px">100L CGPA</th>
                                                <th style="font-size: 10px">200L CGPA</th>
                                                <th style="font-size: 10px">300L CGPA</th>
                                                <?php } ?>
                                                <?php if ($SessCount == 5) { ?>
                                                <th style="font-size: 10px">100L CGPA</th>
                                                <th style="font-size: 10px">200L CGPA</th>
                                                <th style="font-size: 10px">300L CGPA</th>
                                                <th style="font-size: 10px">400L CGPA</th>
                                                <?php } ?>
                                                <th style="font-size: 10px">PCT</th>
                                                <th style="font-size: 10px">PCP</th>
                                                <th style="font-size: 10px">PGP</th>
                                                <th style="font-size: 10px">PCGPA</th>
                                                <th style="font-size: 10px">SCT</th>
                                                <th style="font-size: 10px">SCP</th>
                                                <th style="font-size: 10px">SGP</th>
                                                <th style="font-size: 10px">SGPA</th>
                                                <th style="font-size: 10px">TCT</th>
                                                <th style="font-size: 10px">TCP</th>
                                                <th style="font-size: 10px">TGP</th>
                                                <th style="font-size: 10px">CGPA</th>
                                                <th>RMK</th>
                                                <th>Deficiency/Outstanding</th>
                                                <?php if ($UnderDeclaration == true) { ?>
                                                <th>Comment to Note</th>
                                                <?php } ?>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }

                                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                                if ($conn2->connect_error) {
                                                    die("Connection failed: " . $conn2->connect_error);
                                                }

                                                $deptdb = $_SESSION['deptdb'];
                                                $dept_db = $deptdb . strtolower($getdept);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                $sno = 0;
                                                for ($i = 1; $i <= $repairIteration; $i++) {
                                                    $sno++;
                                                    $getCommentNote = "";
                                                    $creditCondCourse2 = 0;

                                                    $FinalYear = substr($GetTheSession, 0, 4);
                                                    $StartYear = $repairStd_yearAdtd[$i];
                                                    for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                        $getstuSession2 = $x . "/" . ($x + 1);

                                                        $StuCurSess = str_ireplace("/", "_", $getstuSession2);
                                                        $deptcorreg = "correg_" . $StuCurSess;

                                                        $sql3 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$repairRegno[$i]' AND SemTaken  = '$GetTheSemester' AND coursecondon = 'YES' AND SessionRegis =  '$GetTheSession'";
                                                        $result3 = $conn_stu->query($sql3);
                                                        if ($result3->num_rows > 0) {
                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                $creditCondCourse2 = $creditCondCourse2 + $row3["CUnit"];
                                                            }
                                                        }
                                                    }


                                                    if ($txtLevelPlus == 500) {
                                                        if ($repairPresCrTaken[$i] + $creditCondCourse2 > $_SESSION['MaxCredit']) {
                                                            $getCommentNote = "Over Registration";
                                                            $UnderDeclaration = True;
                                                        }
                                                        if ($repairStd_yearAdtd[$i] == $yearadmtInSess) {
                                                            if (($repairPresCrTaken[$i] + $creditCondCourse2 < $_SESSION['minCredit'] && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0)) {
                                                                $getCommentNote = "Under Registration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        }
                                                    } elseif ($txtLevelPlus == 300) {
                                                        if ($repairPresCrTaken[$i] + $creditCondCourse2 > $_SESSION['MaxCredit']) {
                                                            $getCommentNote = "Over Registration";
                                                            $UnderDeclaration = True;
                                                        }
                                                        if ($repairStd_yearAdtd[$i] >= $yearadmtInSess) {
                                                            if (($repairPresCrTaken[$i] + $creditCondCourse2 < $_SESSION['minCredit'] && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0)) {
                                                                $getCommentNote = "Under Registration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        }
                                                    } elseif ($txtLevelPlus == 400) {
                                                        if ($repairPresCrTaken[$i] + $creditCondCourse2 > $_SESSION['MaxCredit']) {
                                                            $getCommentNote = "Over Registration";
                                                            $UnderDeclaration = True;
                                                        }
                                                        if ($repairStd_yearAdtd[$i] >= $yearadmtInSess) {
                                                            if (($repairPresCrTaken[$i] + $creditCondCourse2 < 2 && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0)) {
                                                                $getCommentNote = "Under Registration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        }
                                                    } elseif ($txtLevelPlus == 100) {
                                                        if ($repairPresCrTaken[$i] + $creditCondCourse2 > $_SESSION['MaxCreditNew']) {
                                                            $getCommentNote = "Over Registration";
                                                            $UnderDeclaration = True;
                                                        }
                                                        if (($repairPresCrTaken[$i] + $creditCondCourse2 < $_SESSION['minCreditNew'] && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0)) {
                                                            $sql = "SELECT * FROM ten88stu WHERE matno  = '$repairRegno[$i]' AND DeptCode  = '$getdept'";
                                                            $result = $conn->query($sql);
                                                            $NoTen88 = 0;
                                                            if ($result->num_rows > 0) {
                                                                $NoTen88++;
                                                            }
                                                            if ($NoTen88 != 0 && $repairStd_yearAdtd[$i] < $yearadmtInSess) {
                                                                $getCommentNote = "";
                                                            } else {
                                                                $getCommentNote = "Under Registration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        }
                                                    } else {
                                                        if ($repairPresCrTaken[$i] + $creditCondCourse2 > $_SESSION['MaxCredit']) {
                                                            $getCommentNote = "Over Registration";
                                                            $UnderDeclaration = True;
                                                        }
                                                        if (($repairPresCrTaken[$i] + $creditCondCourse2 < $_SESSION['minCredit'] && $repairCumCP[$i] + $repairToTOuts[$i] != 0 && $repairPresCrTaken[$i] + $creditCondCourse2 != 0)) {
                                                            $getCommentNote = "Under Registration";
                                                            $UnderDeclaration = True;
                                                        }
                                                    }

                                                    if ($_SESSION['InstType'] == "University") {
                                                        if ($repairmodeofentry[$i] == "UTME") {
                                                            $getmaxint = $maxint;
                                                        } else {
                                                            if ($repairEntry_Level[$i] == 100) {
                                                                $getmaxint = $maxint;
                                                            } elseif ($repairEntry_Level[$i] == 200) {
                                                                $getmaxint = $maxint2;
                                                            } elseif ($repairEntry_Level[$i] == 300) {
                                                                $getmaxint = $maxint3;
                                                            }
                                                        }
                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                        $getmaxint = $maxint;
                                                    } else {
                                                    }


                                                    /*  if ((int)substr($repairRegno[$i], 5, 1) == 2) {
                                                    $getmaxint = $maxint2;
                                                } elseif ((int)substr($repairRegno[$i], 5, 1) == 3) {
                                                    $getmaxint = $maxint3;
                                                } else {
                                                    $getmaxint = $maxint;
                                                } */
                                                    if (($repairStd_yearAdtd[$i] == $yearadmtInSess && $repairEntry_Level[$i] == 100) or ($repairStd_yearAdtd[$i] > $yearadmtInSess && $repairEntry_Level[$i] > 100)) {
                                                        if ($txtLevelPlus == 100) {
                                                            if (($repairCumCP[$i] + $repairToTOuts[$i] + 2) < $getmaxint && ($repairCumCP[$i] + $repairToTOuts[$i]) != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif (($repairCumCP[$i] + $repairToTOuts[$i] - 5) > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        } elseif ($txtLevelPlus == 200) {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 4 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 10 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        } elseif ($txtLevelPlus == 300) {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 5 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 10 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        } elseif ($txtLevelPlus == 400) {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 6 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 10 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        } else {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 8 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 10 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        }
                                                    } else {
                                                        if ($txtLevelPlus == 100) {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 2 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 45 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        } elseif ($txtLevelPlus == 200) {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 4 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 60 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        } elseif ($txtLevelPlus == 300) {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 5 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 75 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        } elseif ($txtLevelPlus == 400) {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 6 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 100 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        } else {
                                                            if ($repairCumCP[$i] + $repairToTOuts[$i] + 8 < $getmaxint && $repairCumCP[$i] + $repairToTOuts[$i] != 0) {
                                                                $getCommentNote = "Under Declaration";
                                                                $UnderDeclaration = True;
                                                            } elseif ($repairCumCP[$i] + $repairToTOuts[$i] - 150 > $getmaxint) {
                                                                $getCommentNote = "Over Declaration";
                                                                $UnderDeclaration = True;
                                                            }
                                                        }
                                                    }
                                                    if ($repairPrvCrTaken[$i] == 0) {
                                                        $PrvCrTaken = "";
                                                        $PrvCP = "";
                                                        $PrvGP = "";
                                                        $PrvCGPA = "";
                                                    } else {
                                                        $PrvCrTaken = $repairPrvCrTaken[$i];
                                                        $PrvCP = $repairPrvCP[$i];
                                                        $PrvGP = $repairPrvGP[$i];
                                                        $PrvCGPA = $repairPrvCGPA[$i];
                                                    }

                                                    if ($repairPresCrTaken[$i] == 0) {
                                                        $PresCrTaken = "";
                                                        $PresCP = "";
                                                        $PresGP = "";
                                                        $PresCGPA = "";
                                                    } else {
                                                        $PresCrTaken = $repairPresCrTaken[$i];
                                                        $PresCP = $repairPresCP[$i];
                                                        $PresGP = $repairPresGP[$i];
                                                        $PresCGPA = $repairPresCGPA[$i];
                                                    }

                                                    if ($repairCumCrTaken[$i] == 0) {
                                                        $CumCrTaken = "";
                                                        $CumCP = "";
                                                        $CumGP = "";
                                                        $CumCGPA = "";
                                                    } else {
                                                        $CumCrTaken = $repairCumCrTaken[$i];
                                                        $CumCP = $repairCumCP[$i];
                                                        $CumGP = $repairCumGP[$i];
                                                        $CumCGPA = $repairCumCGPA[$i];
                                                    }
                                                    //$PrvCrTaken = 15;
                                                    if ($SessCount == 1) {
                                                        if ($deptoption == "YES") {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        } else {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        }
                                                    } elseif ($SessCount == 2) {
                                                        if ($repairCGPA100[$i] == 0) {
                                                            $CGPA100 = "";
                                                        } else {
                                                            $CGPA100 = $repairCGPA100[$i];
                                                        }
                                                        if ($deptoption == "YES") {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        } else {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        }
                                                    } elseif ($SessCount == 3) {
                                                        if ($repairCGPA100[$i] == 0) {
                                                            $CGPA100 = "";
                                                        } else {
                                                            $CGPA100 = $repairCGPA100[$i];
                                                        }
                                                        if ($repairCGPA200[$i] == 0) {
                                                            $CGPA200 = "";
                                                        } else {
                                                            $CGPA200 = $repairCGPA200[$i];
                                                        }

                                                        if ($deptoption == "YES") {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        } else {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        }
                                                    } elseif ($SessCount == 4) {
                                                        if ($repairCGPA100[$i] == 0) {
                                                            $CGPA100 = "";
                                                        } else {
                                                            $CGPA100 = $repairCGPA100[$i];
                                                        }
                                                        if ($repairCGPA200[$i] == 0) {
                                                            $CGPA200 = "";
                                                        } else {
                                                            $CGPA200 = $repairCGPA200[$i];
                                                        }
                                                        if ($repairCGPA300[$i] == 0) {
                                                            $CGPA300 = "";
                                                        } else {
                                                            $CGPA300 = $repairCGPA300[$i];
                                                        }

                                                        if ($deptoption == "YES") {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$CGPA300</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$CGPA300</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        } else {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$CGPA300</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$CGPA300</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        }
                                                    } elseif ($SessCount == 5) {
                                                        if ($repairCGPA100[$i] == 0) {
                                                            $CGPA100 = "";
                                                        } else {
                                                            $CGPA100 = $repairCGPA100[$i];
                                                        }
                                                        if ($repairCGPA200[$i] == 0) {
                                                            $CGPA200 = "";
                                                        } else {
                                                            $CGPA200 = $repairCGPA200[$i];
                                                        }
                                                        if ($repairCGPA300[$i] == 0) {
                                                            $CGPA300 = "";
                                                        } else {
                                                            $CGPA300 = $repairCGPA300[$i];
                                                        }
                                                        if ($repairCGPA400[$i] == 0) {
                                                            $CGPA400 = "";
                                                        } else {
                                                            $CGPA400 = $repairCGPA400[$i];
                                                        }

                                                        if ($deptoption == "YES") {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$CGPA300</td><td>$CGPA400</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$repairDeptOpt[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$CGPA300</td><td>$CGPA400</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        } else {
                                                            if ($UnderDeclaration == true) {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$CGPA300</td><td>$CGPA400</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td><td>$getCommentNote</td></tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$repairRegno[$i]</td><td>$repairName[$i]</td><td>$cursemcourses[$i]</td><td>$CGPA100</td><td>$CGPA200</td><td>$CGPA300</td><td>$CGPA400</td><td>$PrvCrTaken</td><td>$PrvCP</td><td>$PrvGP</td><td>$PrvCGPA</td><td>$PresCrTaken</td><td>$PresCP</td><td>$PresGP</td><td>$PresCGPA</td><td>$CumCrTaken</td><td>$CumCP</td><td>$CumGP</td><td>$CumCGPA</td><td>$THE_REMARK[$i]</td><td>$tstFailedCs[$i]</td></tr>\n";
                                                            }
                                                        }
                                                    }
                                                }
                                                $conn->close();
                                                $conn2->close();
                                                $conn_stu->close();
                                                ?>
                                        </tbody>
                                    </table>
                                </div>

                                <br><br>
                                <div class="row" style="padding: 3em;">

                                    <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }


                                        $approval = "NO";
                                        if ($_SESSION['curricul'] == "YES") {
                                            $curri = $_SESSION["curri"];
                                            if ($deptoption == "YES") {
                                                $getdeptOpt = $_SESSION["getdeptOpt"];
                                                $sql2 = "SELECT * FROM hod_semester_res_approval WHERE session_apprv  = '$GetTheSession' AND semester_apprv  = '$GetTheSemester' AND Level_Apprv  = '$txtLevelPlus' AND deptCode  = '$getdept' AND deptoption = '$getdeptOpt' AND curriculum  = '$curri'";
                                            } else {
                                                $sql2 = "SELECT * FROM hod_semester_res_approval WHERE session_apprv  = '$GetTheSession' AND semester_apprv  = '$GetTheSemester' AND Level_Apprv  = '$txtLevelPlus' AND deptCode  = '$getdept' AND curriculum  = '$curri'";
                                            }
                                        } else {
                                            if ($deptoption == "YES") {
                                                $getdeptOpt = $_SESSION["getdeptOpt"];
                                                $sql2 = "SELECT * FROM hod_semester_res_approval WHERE session_apprv  = '$GetTheSession' AND semester_apprv  = '$GetTheSemester' AND Level_Apprv  = '$txtLevelPlus' AND deptCode  = '$getdept' AND deptoption = '$getdeptOpt'";
                                            } else {
                                                $sql2 = "SELECT * FROM hod_semester_res_approval WHERE session_apprv  = '$GetTheSession' AND semester_apprv  = '$GetTheSemester' AND Level_Apprv  = '$txtLevelPlus' AND deptCode  = '$getdept'";
                                            }
                                        }
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $approval = $row2["Approval"];
                                            }
                                        }
                                        $conn->close();
                                        ?>
                                    <?php //if($UnderDeclaration==false){ 
                                        ?>
                                    <?php if ($approval == "YES") { ?>
                                    <h3 style="color: red">Can't Submit, Result already approved by HOD</h3>
                                    <?php } else { ?>
                                    <form class="form-horizontal form-bordered" method="post" style="text-align: right">
                                        <button type="submit" name="submitres"
                                            class="btn btn-primary btn-sm">Submit</button>
                                    </form>
                                    <?php } ?>

                                    <?php //}else{ 
                                        ?>
                                    <h2 style="color: red">NOTE: You need to work on "Comment to Note" before submitting
                                        generated
                                        results</h2>
                                    <?php //} 
                                        ?>

                                </div>
                                <?php
                                    /*for ($i = 1; $i <= $defCount; $i++) {

                        echo $defRegn1[$i].", ".$defCCode[$i]."<br>";
                    }*/

                                    $_SESSION["repairIteration"] = $repairIteration;
                                    $_SESSION['repairRegno'] = $repairRegno;
                                    $_SESSION['repairDeptOpt'] = $repairDeptOpt;
                                    $_SESSION['repairName'] = $repairName;
                                    $_SESSION['repairFname'] = $repairFname;
                                    $_SESSION['repairSname'] = $repairSname;
                                    $_SESSION['repairOname'] = $repairOname;
                                    $_SESSION['repairSex'] = $repairSex;
                                    $_SESSION['repairEntry_Level'] = $repairEntry_Level;
                                    $_SESSION['repairStd_yearAdtd'] = $repairStd_yearAdtd;
                                    $_SESSION["repairmodeofentry"] = $repairmodeofentry;
                                    $_SESSION['repairPrvCrTaken'] = $repairPrvCrTaken;
                                    $_SESSION['repairPrvCP'] = $repairPrvCP;
                                    $_SESSION['repairPrvGP'] = $repairPrvGP;
                                    $_SESSION['repairPrvCGPA'] = $repairPrvCGPA;
                                    $_SESSION['repairPresCrTaken'] = $repairPresCrTaken;
                                    $_SESSION['repairPresCP'] = $repairPresCP;
                                    $_SESSION['repairPresGP'] = $repairPresGP;
                                    $_SESSION['repairPresCGPA'] = $repairPresCGPA;
                                    $_SESSION['repairCumCrTaken'] = $repairCumCrTaken;
                                    $_SESSION['repairCumCP'] = $repairCumCP;
                                    $_SESSION['repairCumGP'] = $repairCumGP;
                                    $_SESSION['repairCumCGPA'] = $repairCumCGPA;
                                    $_SESSION['THE_REMARK'] = $THE_REMARK;
                                    $_SESSION['tstFailedCs'] = $tstFailedCs;
                                    $_SESSION['repairToTOuts'] = $repairToTOuts;
                                    $_SESSION['repairCGPA100'] = $repairCGPA100;
                                    $_SESSION['repairCGPA200'] = $repairCGPA200;
                                    $_SESSION['repairCGPA300'] = $repairCGPA300;
                                    $_SESSION['repairCGPA400'] = $repairCGPA400;
                                    $_SESSION['repairCGPA500'] = $repairCGPA500;

                                    $_SESSION["repairsem_C_F"] = $repairsem_C_F;
                                    $_SESSION["repairprev_C_F"] = $repairprev_C_F;
                                    $_SESSION["repaircum_C_F"] = $repaircum_C_F;
                                    $_SESSION["repairnumb_Course_failed"] = $repairnumb_Course_failed;

                                    $_SESSION["repairdob"] = $repairdob;
                                    $_SESSION["repairp_address"] = $repairp_address;
                                    $_SESSION["repairdeptfull"] = $repairdeptfull;
                                    $_SESSION["repairprogfull"] = $repairprogfull;
                                    $_SESSION["repaireyearadmt"] = $repaireyearadmt;

                                    $_SESSION["repairemail"] = $repairemail;
                                    $_SESSION["repairphone"] = $repairphone;
                                    $_SESSION["repairm_status"] = $repairm_status;
                                    $_SESSION["repairJANB_no"] = $repairJANB_no;

                                    $_SESSION["ArraystuRequiremtCode"] = $ArraystuRequiremtCode;
                                    $_SESSION["ArraystuRequiremtFreq"] = $ArraystuRequiremtFreq;
                                    $_SESSION["ArraystuRequiremtRegNo"] = $ArraystuRequiremtRegNo;
                                    $_SESSION["ArraystuRequiremtCount"] = $ArraystuRequiremtCount;
                                    $_SESSION["ArraystuRequiremtModeEntry"] = $ArraystuRequiremtModeEntry;

                                    $_SESSION["countdefCCode"] = $countdefCCode;
                                    $_SESSION["RegdefCCode"] = $RegdefCCode;
                                    $_SESSION["StudefCCode"] = $StudefCCode;
                                    $_SESSION["TitledefCCode"] = $TitledefCCode;
                                    $_SESSION["UnitdefCCode"] = $UnitdefCCode;



                                    ?>
                                <?php } ?>


                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
    $(document).ready(function() {
        $('#YGradSel').on('change', function() {
            var SelID = $(this).val();
            if (SelID) {
                $.ajax({
                    type: 'POST',
                    url: 'ajax_save_rec/ajaxData.php',
                    data: 'sel_id=' + SelID,
                    success: function(html) {
                        $('#YGrad').html(html);

                    }
                });
            } else {

            }
        });


    });
    </script>
</body>

</html>
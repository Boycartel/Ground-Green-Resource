<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['qap_request'] == false) {
    header('Location: home_staff.php');
}
?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_qap.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Students' CGPA</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                QAP
                            </li>

                            <li class="active">
                                <strong>Students' CGPA</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Student Results
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <div class="row">
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="control-label col-lg-4" for="content">Select
                                                    Course:</label>
                                                <div class="col-lg-8">
                                                    <select class="form-control" style="color:#000000" name="course">
                                                        <option value="SelectItem">Select Item</option>
                                                        <?php
                                                        //$cat = $_SESSION['cat'];
                                                        $dept = $_SESSION['deptcode'];
                                                        if ($cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                            $sql = "SELECT * FROM gencoursesupload WHERE Department = '$dept' ORDER BY C_codding";
                                                        } else {
                                                            $sql = "SELECT * FROM gencoursesupload ORDER BY C_codding";
                                                        }

                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {
                                                            // output data of each row
                                                            while ($row = $result->fetch_assoc()) {
                                                                $C_codding = $row["C_codding"];
                                                                $C_title = $row["C_title"];
                                                                echo "<option value='$C_codding'>$C_codding  $C_title</option>";
                                                            }
                                                        }

                                                        ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">

                                                <label class="control-label col-lg-3">Session:</label>
                                                <div class="col-lg-5">
                                                    <?php
                                                    $iniyear = 2015;

                                                    $finalyear = substr($_SESSION['corntsession'], 5);

                                                    ?>
                                                    <select name="getsession" class="form-control" style="color:#000000"
                                                        id="getsession">
                                                        <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                            <?php echo $_SESSION['corntsession'] ?></option>
                                                        <?php
                                                        while ($iniyear <= $finalyear) {
                                                            $addyear = $iniyear + 1;

                                                            echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                            $iniyear++;
                                                        }

                                                        ?>

                                                    </select>
                                                </div>
                                                <div class="col-lg-2">
                                                    <button type="submit" name="submit"
                                                        class="btn btn-primary btn-sm">Submit</button>
                                                </div>
                                            </div>
                                        </div>


                                    </form>
                                </div>
                                <hr class="separator" />
                                <?php if (isset($_POST["submit"])) {

                                ?>
                                <div class="row">

                                    <?php
                                        $ccode = $_POST["course"];
                                        $session1 = $_POST["getsession"];

                                        set_time_limit(500);
                                        error_reporting(0);
                                        $sql = "SELECT * FROM gencoursesupload WHERE C_codding='$ccode'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $C_title = $row["C_title"];
                                            }
                                        }
                                        $GetTitle = $ccode . "  " . $C_title . " (" . $session1 . " Session)";
                                        ?>

                                    <table id="myTable" class="table mb-none" style="font-size:12px" summary=""
                                        rules="groups" frame="hsides" border="2">
                                        <caption><?php echo $GetTitle ?></caption>
                                        <colgroup align="center"></colgroup>
                                        <colgroup align="left"></colgroup>
                                        <colgroup span="2"></colgroup>
                                        <colgroup span="3" align="center"></colgroup>
                                        <thead>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Mat No</th>
                                                <th>Name</th>
                                                <th>CA</th>
                                                <th>Exam</th>
                                                <th>Grade</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                                //$staffid = $_SESSION['staffid'];
                                                $sno = $A = $B = $C = $D = $E = $F = $tot = 0;

                                                $session2 = str_replace("/", "_", $session1);
                                                $sql = "SELECT * FROM raw_results_" . $session2 . " WHERE CCode = '$ccode'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        //$state = $sex = $name1 = "";
                                                        $regid = $row["Regn1"];
                                                        $sno++;
                                                        $name1 = $row["name1"];

                                                        $point = 0;
                                                        $grade = "";
                                                        $ca = $row['CA'];
                                                        $exam = $row['Exam'];


                                                        if ($_SESSION['InstType'] == "University") {
                                                            if ($row['CA'] + $row['Exam'] >= 70) {
                                                                $point = 5;
                                                                $grade = "A";
                                                                $A++;
                                                            } elseif ($row['CA'] + $row['Exam'] >= 60) {
                                                                $point = 4;
                                                                $grade = "B";
                                                                $B++;
                                                            } elseif ($row['CA'] + $row['Exam'] >= 50) {
                                                                $point = 3;
                                                                $grade = "C";
                                                                $C++;
                                                            } elseif ($row['CA'] + $row['Exam'] >= 45) {
                                                                $point = 2;
                                                                $grade = "D";
                                                                $D++;
                                                            } elseif ($row['CA'] + $row['Exam'] >= 40) {
                                                                $point = 1;
                                                                $grade = "E";
                                                                $E++;
                                                            } elseif ($row['CA'] + $row['Exam'] <= 39.95) {
                                                                $point = 0;
                                                                $grade = "F";
                                                                $F++;
                                                            }
                                                        } elseif (
                                                            $_SESSION['InstType'] == "Polytechnic"
                                                        ) {

                                                            if ($row['CA'] + $row['Exam'] >= 75) {
                                                                $point = 4;
                                                                $grade = "A";
                                                                $A++;
                                                            } elseif (
                                                                $row['CA'] + $row['Exam'] >= 70
                                                            ) {
                                                                $point = 3.5;
                                                                $grade = "AB";
                                                                $AB++;
                                                            } elseif (
                                                                $row['CA'] + $row['Exam'] >= 65
                                                            ) {
                                                                $point = 3.25;
                                                                $grade = "B";
                                                                $B++;
                                                            } elseif (
                                                                $row['CA'] + $row['Exam'] >= 60
                                                            ) {
                                                                $point = 3;
                                                                $grade = "BC";
                                                                $BC++;
                                                            } elseif (
                                                                $row['CA'] + $row['Exam'] >= 55
                                                            ) {
                                                                $point = 2.75;
                                                                $grade = "C";
                                                                $C++;
                                                            } elseif (
                                                                $row['CA'] + $row['Exam'] >= 50
                                                            ) {
                                                                $point = 2.5;
                                                                $grade = "CD";
                                                                $CD++;
                                                            } elseif (
                                                                $row['CA'] + $row['Exam'] >= 45
                                                            ) {
                                                                $point = 2.25;
                                                                $grade = "D";
                                                                $D++;
                                                            } elseif (
                                                                $row['CA'] + $row['Exam'] >= 40
                                                            ) {
                                                                $point = 2;
                                                                $grade = "E";
                                                                $E++;
                                                            } else {
                                                                $point = 0;
                                                                $grade = "F";
                                                                $F++;
                                                            }
                                                        } else {
                                                        }





                                                        $tot++;
                                                        //$sumunits += $row['CUnit'];

                                                        //$sumgp += $row['CUnit'] * $point;




                                                        echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$regid</td><td>$name1</td><td style='text-align:center'>$ca</td><td style='text-align:center'>$exam</td><td style='text-align:center'>$grade</td></tr>\n";
                                                    }
                                                }


                                                /*}
										}*/


                                                ?>
                                        </tbody>
                                    </table>
                                    <br>
                                    <center>
                                        <h2>SUMMARY</h2>
                                        <table style="width: 60%; border:thin; border-color:#000">

                                            <tbody>
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <tr>
                                                    <td style="text-align:center">A</td>
                                                    <td style="text-align:center"><?php echo number_format($A, 0) ?>
                                                    </td>

                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">B</td>
                                                    <td style="text-align:center"><?php echo number_format($B, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">C</td>
                                                    <td style="text-align:center"><?php echo number_format($C, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">D</td>
                                                    <td style="text-align:center"><?php echo number_format($D, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">E</td>
                                                    <td style="text-align:center"><?php echo number_format($E, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">F</td>
                                                    <td style="text-align:center"><?php echo number_format($F, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">Total</td>
                                                    <td style="text-align:center"><?php echo number_format($tot, 0) ?>
                                                    </td>
                                                </tr>
                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                <?php } else { ?>
                                                <tr>
                                                    <td style="text-align:center">A</td>
                                                    <td style="text-align:center"><?php echo number_format($A, 0) ?>
                                                    </td>

                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">A</td>
                                                    <td style="text-align:center"><?php echo number_format($AB, 0) ?>
                                                    </td>

                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">B</td>
                                                    <td style="text-align:center"><?php echo number_format($B, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">BC</td>
                                                    <td style="text-align:center"><?php echo number_format($B, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">C</td>
                                                    <td style="text-align:center"><?php echo number_format($C, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">CD</td>
                                                    <td style="text-align:center"><?php echo number_format($C, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">D</td>
                                                    <td style="text-align:center"><?php echo number_format($D, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">E</td>
                                                    <td style="text-align:center"><?php echo number_format($E, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">F</td>
                                                    <td style="text-align:center"><?php echo number_format($F, 0) ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="text-align:center">Total</td>
                                                    <td style="text-align:center"><?php echo number_format($tot, 0) ?>
                                                    </td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </center>
                                    <br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                            class="btn btn-primary">Download</a>
                                    </div>

                                </div>
                                <?php } ?>

                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
//session_start();
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

include_once 'includes/get_stu_level.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <!--
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    -->
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Registration</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li><span>Course Registration</span></li>
                            <li class="active">
                                <strong>Course Registration(Current)</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Registration(Current)
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal" role="form" method="post" action="stu_registered_course.php">
                                <div class="col-lg-6 col-md-6" style="text-align:right; text-align:center">

                                    <?php
                                    $regid = $_SESSION["regid"];
                                    $dept = $_SESSION['deptcode'];
                                    $curtsession = $_SESSION['corntsession'];
                                    //$curtsession = "2024/2025";
                                    $stucurriculum = strtoupper($_SESSION['stucurriculum']);
                                    $stateorigin = $_SESSION['stateorigin'];
                                    $lga = $_SESSION['lga'];

                                    if ($stucurriculum == "OLD") {
                                        $curri2 = "";
                                    } else {
                                        $curri2 = "_" . $stucurriculum;
                                    }

                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                    if ($conn2->connect_error) {
                                        die("Connection failed: " . $conn2->connect_error);
                                    }

                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }

                                    $names = $_SESSION['names'];
                                    $names = str_replace("'", "''", $names);
                                    $IsYearAdmt = strlen($_SESSION['YAddmitted']);
                                    if ($_SESSION['modeofentry'] == "DE") {
                                        $YearAdmt = substr($_SESSION['entry_session'], 0, 4);
                                        $YearAdmtDE = intval($YearAdmt) - 1;
                                    } else {
                                        $YearAdmt = substr($_SESSION['entry_session'], 0, 4);
                                        $YearAdmtDE = "XXXX";
                                    }





                                    $Stu_Dept_Option = strtoupper($_SESSION['Dept_Option']);
                                    $deptoption = $_SESSION['deptoption'];
                                    $date1 = date("Y-m-d");
                                    $dbsession = str_replace("/", "_", $curtsession);
                                    $sql = "DELETE FROM courses_register_" . $dbsession . " WHERE Regn1 ='$regid'";
                                    $result = $conn->query($sql);

                                    $conn->close();

                                    $StuCurSess = str_ireplace("/", "_", $curtsession);
                                    $deptcorreg = "correg_" . $StuCurSess;

                                    //$sql = "DELETE FROM " . $deptcorreg . " WHERE Regn1 ='$regid'";
                                    //$result = $conn_stu->query($sql);

                                    $CCodeArry = $_SESSION["CCodeArry"];
                                    $CUnitArry = $_SESSION["CUnitArry"];
                                    $CTitleArry = $_SESSION["CTitleArry"];
                                    $SemTakenArry = $_SESSION["SemTakenArry"];
                                    $NatureArry = $_SESSION["NatureArry"];
                                    $countCC = $_SESSION["countCC"];

                                    for ($i = 1; $i <= $countCC; $i++) {
                                        $ccode = $CCodeArry[$i];
                                        $CTitle = str_replace("'", "''", $CTitleArry[$i]);
                                        $CUnit = $CUnitArry[$i];
                                        $SemTaken = $SemTakenArry[$i];
                                        $Nature = $NatureArry[$i];
                                        //$CGroup = "NO";

                                        $sql2 = "INSERT INTO courses_register_" . $dbsession . " (Regn1, name1, CCode, CUnit, CTitle, SemTaken, Nature, session, departments, date) VALUES ('$regid', '$names', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature', '$curtsession', '$dept', '$date1')";
                                        $result2 = $conn->query($sql2);

                                        $sql3 = "SELECT COUNT(*) AS total FROM courses_register_" . $dbsession . "  WHERE CCode = '$ccode'";
                                        $result3 = $conn->query($sql3);
                                        $row3 = $result3->fetch_assoc();
                                        $totalRows = $row3["total"];

                                        $sql2 = "UPDATE gencoursesupload SET totStu = '$totalRows' WHERE C_codding = '$ccode'";
                                        $result2 = $conn->query($sql2);
                                        $conn->close();
                                    }
                                    /* $sql = "SELECT * FROM coursesregis WHERE Regn1 = '$regid'";
                                    $result = $conn_stu->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $ccode = $row["CCode"];
                                            $CTitle = str_replace("'", "''", $row["CTitle"]);
                                            $CUnit = $row["CUnit"];
                                            $SemTaken = $row["SemTaken"];
                                            $Nature = $row["Nature"];
                                            $CGroup = "NO";

                                            $sql2 = "INSERT INTO courses_register_" . $dbsession . " (Regn1, name1, CCode, CUnit, CTitle, SemTaken, Nature, session, departments, date) VALUES ('$regid', '$names', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature', '$curtsession', '$dept', '$date1')";
                                            $result2 = $conn->query($sql2);

                                            $sql3 = "SELECT COUNT(*) AS total FROM courses_register_" . $dbsession . "  WHERE CCode = '$ccode'";
                                            $result3 = $conn->query($sql3);
                                            $row3 = $result3->fetch_assoc();
                                            $totalRows = $row3["total"];

                                            $sql2 = "UPDATE gencoursesupload SET totStu = '$totalRows' WHERE C_codding = '$ccode'";
                                            $result2 = $conn->query($sql2);
                                        }
                                    } */

                                    if ($IsYearAdmt < 4) {
                                        $sql2 = "UPDATE std_data_view SET getme = 'NO', session_reg_status = 'YES', YAddmitted = '$YearAdmt', YAddmittedDir = '$YearAdmtDE' WHERE matric_no = '$regid'";
                                        $result2 = $conn2->query($sql2);
                                    } else {
                                        $sql2 = "UPDATE std_data_view SET getme = 'NO', session_reg_status = 'YES' WHERE matric_no = '$regid'";
                                        $result2 = $conn2->query($sql2);
                                    }
                                    $conn2->close();

                                    $sql = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 ='$curtsession'";
                                    $result = $conn_stu->query($sql);
                                    if ($result->num_rows == 0) {
                                        $sql2 = "INSERT INTO hod_list (matricno, LevelAdvice, HOD, Dean, Registrar, session1, StuLevel, LAComment, HODComment, DeanComment, RegisComment, stateorigin, name1, lga) VALUES ('$regid', 'Yet', 'Yet', 'Yet', 'Yet', '$curtsession', '$level', '_', '_', '_', '_', '$stateorigin', '$names', '$lga')";
                                        $result2 = $conn_stu->query($sql2);
                                    }
                                    $conn_stu->close();
                                    //$sql = "DELETE FROM coursesregis WHERE Regn1 ='$regid'";
                                    //$result = $conn_stu->query($sql);

                                    $conn->close();
                                    $conn2->close();
                                    $conn_stu->close();
                                    ?>

                                    <button type="submit" name="submit3" class="btn btn-primary">Back to Registered
                                        Courses</button>
                                </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    //include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Department's Library</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Department's Library</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Department's Library
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <?php
                                $dept = $_SESSION['deptcode'];
                                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                    $id = $_POST["id"];
                                    $_SESSION['id'] = $id;

                                    $dept = $_SESSION['deptcode'];

                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }

                                    $sql = "SELECT * FROM library WHERE id = '$id'";
                                    $result = $conn_stu->query($sql);

                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $boobtitle = $row['booktitle'];
                                            $bookauthor = $row['author'];
                                            $bookabstract = $row['abstract'];
                                        }
                                    }
                                    $conn_stu->close();
                                    
                                    $filename = 'content/Library/' . $dept . '/' . $id . '.pdf';
                                    $booksize = filesize($filename) / 1024 . ' KB';
                                    $booksize2 = number_format((float)filesize($filename) / 1024, 2, '.', ',') . ' KB';
                                ?>
                                <table class="table bootstrap-datatable">
                                    <tbody>
                                        <tr>
                                            <td>Book Title</td>
                                            <td><?php echo $boobtitle ?></td>
                                        </tr>
                                        <tr>
                                            <td>Author</td>
                                            <td><?php echo $bookauthor ?></td>
                                        </tr>
                                        <tr>
                                            <td>Book Size</td>
                                            <td><?php echo $booksize2 ?></td>
                                        </tr>
                                        <tr>
                                            <td>Abstract/Introduction</td>
                                            <td><?php echo $bookabstract ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <?php

                                }
                                ?>
                                <form action="stu_library_download.php" method="post">
                                    <div style="text-align: right;">
                                        <input type="submit" class="btn btn-success btn-sm" value="Download">
                                    </div>

                                </form>
                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_view'] == false) {
    header('Location: home_staff.php');
}
?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">
    <script src="inline_edit/jquery.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php

    $schcode = $_SESSION['schcode2'];
    //$cat = $_SESSION['cat'];
    $dept = $_SESSION['deptcode'];
    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Missing Session/Semester</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Missing Session
                            </li>

                            <li class="active">
                                <strong>Missing Session/Semester</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Missing Session/Semester
                        </div>
                        <div class="panel-body">
                            <table class="table table-striped table-bordered table-hover dataTables-example">
                                <thead>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Matric No.</th>
                                        <th>Name</th>
                                        <th>Response</th>
                                        <th>Session</th>
                                        <th>Semester</th>
                                        <th>Comment</th>
                                        <th>Approval</th>
                                        <th>Senate Number</th>
                                        <th>Action</th>
                                        <th>Action</th>

                                    </tr>
                                </thead>


                                <tbody>

                                    <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }


                                    if ($cat_Administrator == "YES" || $cat_POs == "YES" || $cat_AcadSec == "YES") {
                                        $sql = "SELECT id, matno, name1, response, response_full, session, semester, coment, approval, senateno FROM missing_session ORDER BY id DESC";
                                    } else if ($cat_Acad_Ofice == "YES" || $cat_Dean == "YES") {
                                        $sql = "SELECT id, matno, name1, response, response_full, session, semester, coment, approval, senateno FROM missing_session WHERE schcode = '$schcode' ORDER BY id DESC";
                                    } else if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                        $sql = "SELECT id, matno, name1, response, response_full, session, semester, coment, approval, senateno FROM missing_session WHERE schcode = '$schcode' AND deptcode = '$dept' ORDER BY id DESC";
                                    }

                                    $sno = 0;
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $sno++;
                                            $id = $row['id'];
                                            $response = $row['response'];
                                            if ($response == "Deferment") {
                                                $response_full = "Deferment";
                                            } else if ($response == "Abscond") {
                                                $response_full = "Abscond";
                                            } else if ($response == "Condonation") {
                                                $response_full = "Condonation";
                                            } else if ($response == "Suspension") {
                                                $response_full = "Suspension";
                                            } else if ($response == "Expulsion") {
                                                $response_full = "Expulsion";
                                            } else if ($response == "VolWithdrawal") {
                                                $response_full = "Voluntary Withdrawal";
                                            } else if ($response == "PoorWithdrawal") {
                                                $response_full = "Withdrawal(Poor Acad Performance)";
                                            } else if ($response == "Notification_illhealth") {
                                                $response_full = "Notification of ill-health";
                                            } else if ($response == "recall_susp") {
                                                $response_full = "Recall from Suspension";
                                            } else if ($response == "recall_expul") {
                                                $response_full = "Recall from Expulsion";
                                            }
                                            echo "<tr><td>$sno</td><td>{$row['matno']}</td><td>{$row['name1']}</td><td>$response_full</td><td>{$row['session']}</td><td>{$row['semester']}</td><td>{$row['coment']}</td><td>{$row['approval']}</td><td>{$row['senateno']}</td>
			                                        												
			                                            <form action='staf_condone_defer_result.php' method='post'>
			                                                  <input type='hidden' value=$id name='id'>
			                                                  <td><input type='submit' name = 'view' class='btn btn-primary btn-xs' value='Result'></td>
			                                                  
			                                                  <td><a href='miss_session_print.php?id2=$id' class='btn btn-info btn-xs'>Print</a></td>
			                                             </form>
			                                        </tr>\n";
                                        }
                                    }
                                    $conn->close();
                                    ?>
                                </tbody>
                            </table>



                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Page-Level Scripts -->
    <script>
    $(document).ready(function() {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: []

        });

    });
    </script>



</body>

</html>
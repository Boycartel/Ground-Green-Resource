<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Open/Close Course Registration</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Settings
                            </li>

                            <li class="active">
                                <strong>Open/Close Course Registration</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Open/Close Course Registration
                        </div>
                        <div class="panel-body">
                            <!-- start: page -->
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $success = "";
                            $sql = "SELECT * FROM sessions WHERE getkey = 'key1'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $reg_session = $row["session_title"];
                                    $reg_semester = $row["semester"];
                                    $results_session = $row["result_session"];
                                    $results_semester = $row["result_semester"];
                                }
                            }



                            if (isset($_POST["submit"])) {

                                $sql = "SELECT * FROM setting";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $CourseREg = $row["CourseREg"];
                                    }
                                }

                                if ($CourseREg == "Open") {
                                    $getStatus = "Closed";
                                } else {
                                    $getStatus = "Open";
                                }

                                $sql = "UPDATE setting SET CourseREg = '$getStatus'";
                                $result = $conn->query($sql);
                            }

                            $sql = "SELECT * FROM setting";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $CourseREg = $row["CourseREg"];
                                }
                            }

                            if ($CourseREg == "Open") {
                                $getStatus = "Close";
                            } else {
                                $getStatus = "Open";
                            }
                            ?>
                            <div class="row">

                                <h2 style="color: blue; text-align: center"><?php echo $success ?></h2>
                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="row">
                                        <div class="col-lg-2">

                                        </div>
                                        <div class="col-lg-8">
                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Item</th>
                                                        <th>Session</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>Course Registration</td>
                                                        <td><?php echo $reg_session ?> </td>

                                                        <?php if ($getStatus == "Open") { ?>
                                                            <td class="client-status"><span class="label label-danger"><?php echo $CourseREg ?></span>
                                                            </td>
                                                            <td>
                                                                <input type='submit' name="submit" class='btn btn-info btn-sm' value='<?php echo $getStatus ?>'>
                                                            </td>
                                                        <?php } else { ?>
                                                            <td class="client-status"><span class="label label-info"><?php echo $CourseREg ?></span>
                                                            </td>
                                                            <td>
                                                                <input type='submit' name="submit" class='btn btn-danger btn-sm' value='<?php echo $getStatus ?>'>
                                                            </td>
                                                        <?php } ?>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-lg-2">

                                        </div>

                                    </div>

                                </form>
                            </div>
                            <?php
                            $conn->close();
                            ?>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
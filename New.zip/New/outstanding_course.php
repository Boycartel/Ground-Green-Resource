<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity_stu.php';

$paystatus = "NO";
$regid = $_SESSION['regid'];
$corntsession = $_SESSION['corntsession'];
$modeofentry = $_SESSION['modeofentry'];
if ($modeofentry == "ND") {
    $prog = "National Diploma";
} elseif ($modeofentry == "HND") {
    $prog = "Higher National Diploma";
}
$sql = "SELECT * FROM std_data_payment WHERE Matriculation_no = '$regid' AND session = '$corntsession' AND payment_cat = 'registration' AND (pay_or_skip = 'pay' || pay_or_skip = 'skip')";
$result = $conn2->query($sql);

if ($result->num_rows == 0) {
    header('Location: home_stu.php');
}

//include_once 'includes/check_stu_status.php';

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <?php

    $regid = $_SESSION["regid"];
    $studept = $_SESSION['deptcode'];
    $curtsession = $_SESSION['corntsession'];
    $names = $_SESSION['names'];
    $resultsession = $_SESSION['resultsession'];
    $resultsemester = $_SESSION['resultsemester'];
    $entry_session = $_SESSION['entry_session'];

    $cgpa = $totsumunits = $totsumgp = 0;
    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Outstanding Courses</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Outstanding Courses</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Outstanding Courses
                        </div>
                        <div class="panel-body">
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <form class="form-horizontal" role="form" method="post" action="">
                                    <?php

                                    $regid = $_SESSION["regid"];
                                    $dept = $_SESSION['deptcode'];
                                    if ($stutype == "UG") {
                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        $sql = "SELECT * FROM diff_outs_courses WHERE Regn1 = '$regid' ORDER BY CCode";
                                        $result = $conn_stu->query($sql);
                                    } else {
                                        $sql = "SELECT * FROM " . $dept . "_diff_outs_courses_pg WHERE Regn1 = '$regid' ORDER BY CCode";
                                        $result = $conn->query($sql);
                                    }



                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                    ?>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>

                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                while ($row = $result->fetch_assoc()) {

                                                    echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td></tr>\n";
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    <?php } ?>
                                </form>
                            </div>
                            <div class="col-md-1">
                            </div>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
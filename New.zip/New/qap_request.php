<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['qap_request'] == false) {
    header('Location: home_staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_qap.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Students' CGPA</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                QAP
                            </li>

                            <li class="active">
                                <strong>Students' CGPA</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students' CGPA
                        </div>
                        <div class="panel-body">

                            <div class="row">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-4" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-8">
                                                <select class="form-control" style="color:#000000" name="dept" required>
                                                    <option value="">Select Item</option>
                                                    <?php
                                                    //$cat = $_SESSION['cat'];
                                                    $dept = $_SESSION['deptcode'];

                                                    if ($cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                    } else {
                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    }

                                                    //$sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = $row["DeptCode"];
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }

                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">

                                            <label class="control-label col-lg-4" for="regid">Session:</label>
                                            <div class="col-lg-8">
                                                <?php
                                                $iniyear = 2015;

                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="getsession" class="form-control" style="color:#000000"
                                                    id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <label class="control-label col-lg-3" for="regid">Level:</label>
                                            <div class="col-lg-7">
                                                <select name="level" class="form-control" style="color:#000000"
                                                    id="level" required>
                                                    <option value="">Select Item</option>
                                                    <?php if ($_SESSION['InstType'] == "University") { ?>
                                                    <option value="100">100</option>
                                                    <option value="200">200</option>
                                                    <option value="300">300</option>
                                                    <option value="400">400</option>
                                                    <option value="500">500</option>
                                                    <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                    <option value="100">ND I</option>
                                                    <option value="200">ND II</option>
                                                    <option value="300">HND I</option>
                                                    <option value="400">HND II</option>
                                                    <?php } ?>
                                                </select>
                                            </div>


                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-3">Semester:</label>
                                            <div class="col-lg-7">
                                                <select name="semester" class="form-control" style="color:#000000"
                                                    id="semester" required>
                                                    <option value="">Select Item</option>
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>

                                                </select>
                                            </div>
                                            <div class="col-lg-2">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <hr class="separator" />
                            <?php if (isset($_POST["submit"])) {
                                $session = $_POST['getsession'];
                                $dept = $_POST['dept'];
                                $level = $_POST['level'];
                                $semester = $_POST['semester'];
                                $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $deptname = $row['DeptName'];
                                    }
                                }
                            ?>
                            <div class="row">

                                <?php
                                    set_time_limit(1000);
                                    $GetTitle = "Department:-  " . $deptname . ", Level:- " . $level . ", Session:- " . $session;
                                    ?>
                                <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                    rules="groups" frame="hsides" border="2">
                                    <caption><?php echo $GetTitle ?></caption>
                                    <colgroup align="center"></colgroup>
                                    <colgroup align="left"></colgroup>
                                    <colgroup span="2"></colgroup>
                                    <colgroup span="3" align="center"></colgroup>
                                    <thead>
                                        <tr>
                                            <th>S/No</th>
                                            <th>Mat No</th>
                                            <th>Name</th>
                                            <th>Sex</th>
                                            <th>State</th>
                                            <th>CGPA</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                            $staffid = $_SESSION['staffid'];
                                            $sql = "DELETE FROM qap_request WHERE pfno ='$staffid'";
                                            $result = $conn->query($sql);
                                            $sno = 0;

                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }

                                            $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$level' AND session1 = '$session' AND semester = '$semester'";
                                            $result = $conn_stu->query($sql);

                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $state = $sex = $name1 = "";
                                                    $regid = $row["Regn"];
                                                    $name1 = $row["Name1"];
                                                    $cgpa = 0;
                                                    $sno++;

                                                    $sex = $row["sex"];
                                                    $state = $row["stateOfOrigin"];

                                                    $cgpa = $row["CGPA"];



                                                    $sql3 = "INSERT INTO qap_request (matno, name1, sex, state1, cgpa, pfno) VALUES ('$regid', '$name1', '$sex', '$state', '$cgpa', '$staffid')";
                                                    $result3 = $conn->query($sql3);

                                                    echo "<tr><td>$sno</td><td>$regid</td><td>$name1</td><td>$sex</td><td>$state</td><td>$cgpa</td></tr>\n";
                                                }
                                            }
                                            ?>
                                    </tbody>
                                </table>


                                <br>
                                <div style="text-align: right">
                                    <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                        class="btn btn-primary btn-sm">Download</a>
                                </div>


                            </div>
                            <?php } ?>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
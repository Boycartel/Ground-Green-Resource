<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>
    <script src="js/getexcel/tableToExcel_Staff.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li><span>APU</span></li>
                            <li><span>Staff Record</span></li>
                            <li class="active">
                                <strong>By State</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            By State
                        </div>
                        <div class="panel-body">
                            <div class="row">

                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="form-group">
                                        <label class="control-label col-lg-3" for="regid">Scale</label>
                                        <div class="col-lg-4">
                                            <select name="scale" class="form-control" style="color:#000000" id="scale">
                                                <option value='CONUASS'>CONUASS</option>
                                                <option value='CONTISS'>CONTISS</option>
                                                <option value='CONMESS'>CONMESS</option>
                                                <option value='CONHESS'>CONHESS</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-5">
                                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                        </div>
                                    </div>

                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"])) { ?>
                                    <?php
                                    $scale = $_POST["scale"];
                                    $GetTitle = "Staff Count by State(" . $scale . ")";
                                    ?>
                                    <h2 class="panel-title"><?php echo $GetTitle ?></h2>
                                    <?php
                                    $totmale = $totfemale = $totphdmale = $totphdfemale = $tottotal = 0;
                                    for ($x = 1; $x <= 15; $x++) {
                                        $totmaleG[$x] = 0;
                                        $totfemaleG[$x] = 0;
                                    }
                                    ?>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>State</th>
                                                    <th>Male</th>
                                                    <th>Female</th>
                                                    <?php if ($scale == "CONUASS") { ?>
                                                        <th>Ph.D(M)</th>
                                                        <th>Ph.D(F)</th>
                                                        <th>GA(M)</th>
                                                        <th>GA(F)</th>
                                                        <th>AL(M)</th>
                                                        <th>AL(F)</th>
                                                        <th>LII(M)</th>
                                                        <th>LII(F)</th>
                                                        <th>LI(M)</th>
                                                        <th>LI(F)</th>
                                                        <th>SL(M)</th>
                                                        <th>SL(F)</th>
                                                        <th>AP(M)</th>
                                                        <th>AP(F)</th>
                                                        <th>Prof(M)</th>
                                                        <th>Prof(F)</th>
                                                    <?php
                                                    } elseif ($scale == "CONTISS") {
                                                        for ($x = 1; $x <= 15; $x++) {
                                                            if ($x < 10) {
                                                                echo "<th>N0$x(M)</th>";
                                                                echo "<th>N0$x(F)</th>";
                                                            } else {
                                                                echo "<th>N$x(M)</th>";
                                                                echo "<th>N$x(F)</th>";
                                                            }
                                                        }
                                                    } elseif ($scale == "CONHESS") {
                                                        for ($x = 1; $x <= 15; $x++) {
                                                            if ($x < 10) {
                                                                echo "<th>H0$x(M)</th>";
                                                                echo "<th>H0$x(F)</th>";
                                                            } else {
                                                                echo "<th>H$x(M)</th>";
                                                                echo "<th>H$x(F)</th>";
                                                            }
                                                        }
                                                    } elseif ($scale == "CONMESS") {
                                                        for ($x = 1; $x <= 7; $x++) {
                                                            if ($x < 10) {
                                                                echo "<th>M0$x(M)</th>";
                                                                echo "<th>M0$x(F)</th>";
                                                            } else {
                                                                echo "<th>M$x(M)</th>";
                                                                echo "<th>M$x(F)</th>";
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                    <th>Total</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $sql = "SELECT * FROM states ORDER BY state";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {

                                                        $state = $row["state"];
                                                        $state2 = strtoupper($state);
                                                        $male = $female = $phdmale = $phdfemale = $total = 0;
                                                        for ($x = 1; $x <= 15; $x++) {
                                                            $maleG[$x] = 0;
                                                            $femaleG[$x] = 0;
                                                        }
                                                        if ($scale == "CONUASS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE stateOfOrigin = '$state2' AND Scale = 'CONUASS' AND nationality = 'Nigerian'";
                                                        } elseif ($scale == "CONTISS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE stateOfOrigin = '$state2' AND Scale = 'CONTISS' AND nationality = 'Nigerian'";
                                                        } elseif ($scale == "CONHESS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE stateOfOrigin = '$state2' AND Scale = 'CONHESS' AND nationality = 'Nigerian'";
                                                        } elseif ($scale == "CONMESS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE stateOfOrigin = '$state2' AND Scale = 'CONMESS' AND nationality = 'Nigerian'";
                                                        }

                                                        $result2 = $conn7->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $gradeL = $row2["GradeL"];
                                                                if ($row2["Sex"] == "M") {
                                                                    $male++;
                                                                    $totmale++;
                                                                    if ($scale == "CONUASS") {
                                                                        if ($row2["HQualificatn"] == "Ph.D") {
                                                                            $phdmale++;
                                                                            $totphdmale++;
                                                                        }
                                                                        for ($x = 1; $x <= 7; $x++) {
                                                                            if ($gradeL == "A0" . $x) {
                                                                                $maleG[$x]++;
                                                                                $totmaleG[$x]++;
                                                                            }
                                                                        }
                                                                    } elseif ($scale == "CONTISS") {
                                                                        for ($x = 1; $x <= 15; $x++) {
                                                                            if ($x < 10) {
                                                                                $getgradeL = "N0" . $x;
                                                                            } else {
                                                                                $getgradeL = "N" . $x;
                                                                            }
                                                                            if ($gradeL == $getgradeL) {
                                                                                $maleG[$x]++;
                                                                                $totmaleG[$x]++;
                                                                            }
                                                                        }
                                                                    } elseif ($scale == "CONHESS") {
                                                                        for ($x = 1; $x <= 15; $x++) {
                                                                            if ($x < 10) {
                                                                                $getgradeL = "H0" . $x;
                                                                            } else {
                                                                                $getgradeL = "H" . $x;
                                                                            }
                                                                            if ($gradeL == $getgradeL) {
                                                                                $maleG[$x]++;
                                                                                $totmaleG[$x]++;
                                                                            }
                                                                        }
                                                                    } elseif ($scale == "CONMESS") {
                                                                        for ($x = 1; $x <= 7; $x++) {
                                                                            if ($gradeL == "M0" . $x) {
                                                                                $maleG[$x]++;
                                                                                $totmaleG[$x]++;
                                                                            }
                                                                        }
                                                                    }
                                                                } elseif ($row2["Sex"] == "F") {
                                                                    $female++;
                                                                    $totfemale++;
                                                                    if ($scale == "CONUASS") {
                                                                        if ($row2["HQualificatn"] == "Ph.D") {
                                                                            $phdfemale++;
                                                                            $totphdfemale++;
                                                                        }
                                                                        for ($x = 1; $x <= 7; $x++) {
                                                                            if ($gradeL == "A0" . $x) {
                                                                                $femaleG[$x]++;
                                                                                $totfemaleG[$x]++;
                                                                            }
                                                                        }
                                                                    } elseif ($scale == "CONTISS") {
                                                                        for ($x = 1; $x <= 15; $x++) {
                                                                            if ($x < 10) {
                                                                                $getgradeL = "N0" . $x;
                                                                            } else {
                                                                                $getgradeL = "N" . $x;
                                                                            }
                                                                            if ($gradeL == $getgradeL) {
                                                                                $femaleG[$x]++;
                                                                                $totfemaleG[$x]++;
                                                                            }
                                                                        }
                                                                    } elseif ($scale == "CONHESS") {
                                                                        for ($x = 1; $x <= 15; $x++) {
                                                                            if ($x < 10) {
                                                                                $getgradeL = "H0" . $x;
                                                                            } else {
                                                                                $getgradeL = "H" . $x;
                                                                            }
                                                                            if ($gradeL == $getgradeL) {
                                                                                $femaleG[$x]++;
                                                                                $totfemaleG[$x]++;
                                                                            }
                                                                        }
                                                                    } elseif ($scale == "CONMESS") {
                                                                        for ($x = 1; $x <= 7; $x++) {
                                                                            if ($gradeL == "M0" . $x) {
                                                                                $femaleG[$x]++;
                                                                                $totfemaleG[$x]++;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        $total = $male + $female;
                                                        if ($total > 0) {
                                                            $sno++;
                                                            if ($scale == "CONUASS" || $scale == "CONMESS") {
                                                                if ($scale == "CONUASS") {
                                                                    echo "<tr><td>$sno</td><td>$state</td><td>$male</td><td>$female</td><td>$phdmale</td><td>$phdfemale</td>";
                                                                } else {
                                                                    echo "<tr><td>$sno</td><td>$state</td><td>$male</td><td>$female</td>";
                                                                }

                                                                for ($x = 1; $x <= 7; $x++) {
                                                                    echo "<td>$maleG[$x]</td>";
                                                                    echo "<td>$femaleG[$x]</td>";
                                                                }
                                                            } elseif ($scale == "CONTISS" || $scale == "CONHESS") {
                                                                echo "<tr><td>$sno</td><td>$state</td><td>$male</td><td>$female</td>";
                                                                for ($x = 1; $x <= 15; $x++) {
                                                                    echo "<td>$maleG[$x]</td>";
                                                                    echo "<td>$femaleG[$x]</td>";
                                                                }
                                                            }
                                                            echo "<td>$total</td><td>
                                                    <form action='dap_staff_list.php' method='post'>
                                                        <input type='hidden' value='$state2' name='id'>
                                                        <input type='hidden' value='yesstate' name='deptstate'>
                                                        <input type='hidden' value='$scale' name='myscale'>
                                                        <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                                    </form>
                                                    </td>
                                                        
                                                    </tr>\n";
                                                        }
                                                    }
                                                }

                                                //Non Nigerian

                                                $male = $female = $phdmale = $phdfemale = $total = 0;
                                                for ($x = 1; $x <= 15; $x++) {
                                                    $maleG[$x] = 0;
                                                    $femaleG[$x] = 0;
                                                }
                                                if ($scale == "CONUASS") {
                                                    $sql2 = "SELECT * FROM staff_profile WHERE Scale = 'CONUASS' AND nationality = 'Non Nigerian'";
                                                } elseif ($scale == "CONTISS") {
                                                    $sql2 = "SELECT * FROM staff_profile WHERE Scale = 'CONTISS' AND nationality = 'Non Nigerian'";
                                                } elseif ($scale == "CONHESS") {
                                                    $sql2 = "SELECT * FROM staff_profile WHERE Scale = 'CONHESS' AND nationality = 'Non Nigerian'";
                                                } elseif ($scale == "CONMESS") {
                                                    $sql2 = "SELECT * FROM staff_profile WHERE Scale = 'CONMESS' AND nationality = 'Non Nigerian'";
                                                }

                                                $result2 = $conn7->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $gradeL = $row2["GradeL"];
                                                        if ($row2["Sex"] == "M") {
                                                            $male++;
                                                            $totmale++;
                                                            if ($scale == "CONUASS") {
                                                                if ($row2["HQualificatn"] == "Ph.D") {
                                                                    $phdmale++;
                                                                    $totphdmale++;
                                                                }
                                                                for ($x = 1; $x <= 7; $x++) {
                                                                    if ($gradeL == "A0" . $x) {
                                                                        $maleG[$x]++;
                                                                        $totmaleG[$x]++;
                                                                    }
                                                                }
                                                            } elseif ($scale == "CONTISS") {
                                                                for ($x = 1; $x <= 15; $x++) {
                                                                    if ($x < 10) {
                                                                        $getgradeL = "N0" . $x;
                                                                    } else {
                                                                        $getgradeL = "N" . $x;
                                                                    }
                                                                    if ($gradeL == $getgradeL) {
                                                                        $maleG[$x]++;
                                                                        $totmaleG[$x]++;
                                                                    }
                                                                }
                                                            } elseif ($scale == "CONHESS") {
                                                                for ($x = 1; $x <= 15; $x++) {
                                                                    if ($x < 10) {
                                                                        $getgradeL = "H0" . $x;
                                                                    } else {
                                                                        $getgradeL = "H" . $x;
                                                                    }
                                                                    if ($gradeL == $getgradeL) {
                                                                        $maleG[$x]++;
                                                                        $totmaleG[$x]++;
                                                                    }
                                                                }
                                                            } elseif ($scale == "CONMESS") {
                                                                for ($x = 1; $x <= 7; $x++) {
                                                                    if ($gradeL == "M0" . $x) {
                                                                        $maleG[$x]++;
                                                                        $totmaleG[$x]++;
                                                                    }
                                                                }
                                                            }
                                                        } elseif ($row2["Sex"] == "F") {
                                                            $female++;
                                                            $totfemale++;
                                                            if ($scale == "CONUASS") {
                                                                if ($row2["HQualificatn"] == "Ph.D") {
                                                                    $phdfemale++;
                                                                    $totphdfemale++;
                                                                }
                                                                for ($x = 1; $x <= 7; $x++) {
                                                                    if ($gradeL == "A0" . $x) {
                                                                        $femaleG[$x]++;
                                                                        $totfemaleG[$x]++;
                                                                    }
                                                                }
                                                            } elseif ($scale == "CONTISS") {
                                                                for ($x = 1; $x <= 15; $x++) {
                                                                    if ($x < 10) {
                                                                        $getgradeL = "N0" . $x;
                                                                    } else {
                                                                        $getgradeL = "N" . $x;
                                                                    }
                                                                    if ($gradeL == $getgradeL) {
                                                                        $femaleG[$x]++;
                                                                        $totfemaleG[$x]++;
                                                                    }
                                                                }
                                                            } elseif ($scale == "CONHESS") {
                                                                for ($x = 1; $x <= 15; $x++) {
                                                                    if ($x < 10) {
                                                                        $getgradeL = "H0" . $x;
                                                                    } else {
                                                                        $getgradeL = "H" . $x;
                                                                    }
                                                                    if ($gradeL == $getgradeL) {
                                                                        $femaleG[$x]++;
                                                                        $totfemaleG[$x]++;
                                                                    }
                                                                }
                                                            } elseif ($scale == "CONMESS") {
                                                                for ($x = 1; $x <= 7; $x++) {
                                                                    if ($gradeL == "M0" . $x) {
                                                                        $femaleG[$x]++;
                                                                        $totfemaleG[$x]++;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                $total = $male + $female;
                                                if ($total > 0) {
                                                    $sno++;
                                                    if ($scale == "CONUASS" || $scale == "CONMESS") {
                                                        if ($scale == "CONUASS") {
                                                            echo "<tr><td>$sno</td><td>Non Nigerian</td><td>$male</td><td>$female</td><td>$phdmale</td><td>$phdfemale</td>";
                                                        } else {
                                                            echo "<tr><td>$sno</td><td>Non Nigerian</td><td>$male</td><td>$female</td>";
                                                        }

                                                        for ($x = 1; $x <= 7; $x++) {
                                                            echo "<td>$maleG[$x]</td>";
                                                            echo "<td>$femaleG[$x]</td>";
                                                        }
                                                    } elseif ($scale == "CONTISS" || $scale == "CONHESS") {
                                                        echo "<tr><td>$sno</td><td>Non Nigerian</td><td>$male</td><td>$female</td>";
                                                        for ($x = 1; $x <= 15; $x++) {
                                                            echo "<td>$maleG[$x]</td>";
                                                            echo "<td>$femaleG[$x]</td>";
                                                        }
                                                    }
                                                    echo "<td>$total</td><td>
                                            <form action='dap_staff_list.php' method='post'>
                                                <input type='hidden' value='Non Nigerian' name='id'>
                                                <input type='hidden' value='yesstate' name='deptstate'>
                                                <input type='hidden' value='$scale' name='myscale'>
                                                <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                            </form>
                                            </td>
                                                
                                            </tr>\n";
                                                }

                                                $tottotal = $totmale + $totfemale;
                                                if ($scale == "CONUASS" || $scale == "CONMESS") {
                                                    if ($scale == "CONUASS") {
                                                        echo "<tr><td></td><td>Total</td><td>$totmale</td><td>$totfemale</td><td>$totphdmale</td><td>$totphdfemale</td>";
                                                    } else {
                                                        echo "<tr><td></td><td>Total</td><td>$totmale</td><td>$totfemale</td>";
                                                    }

                                                    for ($x = 1; $x <= 7; $x++) {
                                                        echo "<td>$totmaleG[$x]</td>";
                                                        echo "<td>$totfemaleG[$x]</td>";
                                                    }
                                                } elseif ($scale == "CONTISS" || $scale == "CONHESS") {
                                                    echo "<tr><td></td><td>Total</td><td>$totmale</td><td>$totfemale</td>";
                                                    for ($x = 1; $x <= 15; $x++) {
                                                        echo "<td>$totmaleG[$x]</td>";
                                                        echo "<td>$totfemaleG[$x]</td>";
                                                    }
                                                }

                                                echo "<td>$tottotal</td><td></td>
                                                            
                                                        </tr>\n";
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <br><br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                    </div>

                                <?php } ?>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
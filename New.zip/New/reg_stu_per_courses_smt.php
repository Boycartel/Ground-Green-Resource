<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['reg_stu_per_courses'] == false) {
    header('Location: Home_Staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_CR.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Registered Students Per Course</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Registered Students Per Course</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <div class="col-lg-2">

                    </div>
                    <div class="col-lg-8">
                        <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                            <div class="panel-heading">
                                Registered Students Per
                                Course<?php echo " " . $_POST["getsession"] . " " ?>
                            </div>
                            <div class="panel-body">

                                <?php
                                set_time_limit(500);
                                $GetTitle = "Registered Students Per Course  " . $_POST["getsession"] . " Session";
                                ?>
                                <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                    rules="groups" frame="hsides" border="2">
                                    <caption><?php echo $GetTitle ?></caption>
                                    <colgroup align="center"></colgroup>
                                    <colgroup align="left"></colgroup>
                                    <colgroup span="2"></colgroup>
                                    <colgroup span="3" align="center"></colgroup>
                                    <thead>
                                        <tr>
                                            <th>Course Code</th>
                                            <th>Course Title</th>
                                            <th>No of Students</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
                                        $session1 = $_POST["getsession"];
                                        $courseRegSplitSess = $_SESSION['courseRegSplitSess'];
                                        if (!empty($_POST["chosen"])) {
                                            foreach ($_POST["chosen"] as $key => $value) {

                                                $ccode1 = $_POST["ccode1"][$key];
                                                $ctitle = $_POST["CTitle1"][$key];
                                                $nostu = 0;

                                                if ($session1 < $courseRegSplitSess) {
                                                    $sql = "SELECT * FROM courses_register WHERE CCode = '$ccode1' AND session = '$session1'";
                                                } else {
                                                    $dbsession = str_replace("/", "_", $session1);
                                                    $sql = "SELECT * FROM courses_register_" . $dbsession . " WHERE CCode = '$ccode1'";
                                                }
                                                $result = $conn->query($sql);
                                                $nostu = mysqli_num_rows($result);

                                                echo "<tr><td>$ccode1</td><td>$ctitle</td><td>$nostu</td></tr>\n";
                                            }
                                        }
                                        $conn->close();

                                        ?>
                                    </tbody>
                                </table>
                                <br>
                                <div style="text-align: right">
                                    <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                        class="btn btn-primary">Download</a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-2">

                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
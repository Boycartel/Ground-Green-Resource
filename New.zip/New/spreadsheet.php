<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>
        <?php

        $deptoption = $_SESSION['deptoption'];
        $deptname = $_SESSION["deptname"];
        $schcode = $_SESSION['schcode'];
        ?>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Returning Students Spreadsheet</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li>
                                Students Spreadsheet
                            </li>
                            <li class="active">
                                <strong>Returning Students</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Returning Students Spreadsheet
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal form-bordered" method="post">
                                <div class="row">

                                    <div class="col-lg-4">
                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-7">
                                                <select class="country form-control" style="color:#000000" name="dept">
                                                    <option value="SelectItem">Select Item</option>
                                                    <?php
                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                    if ($conn->connect_error) {
                                                        die("Connection failed: " . $conn->connect_error);
                                                    }

                                                    $dept = $_SESSION['deptcode'];

                                                    if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                    } else {
                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    }
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = strtolower($row["DeptCode"]);
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }
                                                    $conn->close();
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="row">
                                            <label class="control-label col-lg-6" for="regid">Year of
                                                Admitted:</label>
                                            <div class="col-lg-6">
                                                <?php

                                                $finalyear = substr($_SESSION['corntsession'], 5) + 1;
                                                $iniyear = "2010";
                                                ?>
                                                <select name="getyearadmt" class="form-control" style="color:#000000" id="getyearadmt" required="required">
                                                    <option value="">Select Item</option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear'>$iniyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>


                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                        <div class="col-lg-3">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="getprogram">Program:</label>
                                                <div class="col-lg-7">

                                                    <select name="getprogram" class="form-control" style="color:#000000" id="getprogram" required="required">
                                                        <option value="">Select Item</option>
                                                        <option value="ND">ND</option>
                                                        <option value="HND">HND</option>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <div class="col-lg-2">
                                        <div class="row">

                                            <div class="col-lg-4">
                                                <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </form>
                            <hr class="separator" />
                            <?php if (isset($_POST["submit"])) { ?>
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                $_SESSION['dept_sctny'] = $_POST["dept"];
                                $_SESSION['getyearadmt'] = $_POST["getyearadmt"];
                                if ($_SESSION['InstType'] == "Polytechnic") {
                                    $_SESSION['getprogram'] = $_POST["getprogram"];
                                    $getprogram = $_SESSION['getprogram'];
                                    if ($getprogram == "ND") {
                                        $prog = "National Diploma";
                                    } elseif ($getprogram == "HND") {
                                        $prog = "Higher National Diploma";
                                    }
                                }

                                $getdept = $_SESSION['dept_sctny'];
                                $getyearadmt = $_SESSION['getyearadmt'];



                                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $_SESSION["HOD_Sign"] = $row["full_name"];
                                    }
                                }

                                $sql = "SELECT * FROM users WHERE SchCode = '$schcode' AND (cat = 'Dean' OR cat = 'HODDean' OR cat = 'PGExam')";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $_SESSION["Dean_Sign"] = $row["full_name"];
                                    }
                                }

                                ?>
                                <div class="col-lg-12">
                                    <div class="col-lg-4">
                                        <h5><b>Department: <?php echo $deptname; ?></b></h5>
                                    </div>
                                    <div class="col-lg-4">
                                        <h5><b>Year of Admitted: <?php echo $_SESSION['getyearadmt']; ?></b></h5>
                                    </div>
                                    <div class="col-lg-4">
                                        <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                            <h5><b>Programme: <?php echo $prog; ?></b></h5>
                                        <?php } else { ?>
                                            <h5><b>Programme: Undergraduate</b></h5>
                                        <?php } ?>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <table class="table table-striped table-bordered table-hover dataTables-example">
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Matric No</th>
                                                <th>Name</th>
                                                <th>Status</th>

                                                <?php if ($deptoption == "YES") { ?>
                                                    <th>Department Option</th>
                                                <?php } ?>
                                                <th>Action</th>


                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            $sno = 0;
                                            if ($_SESSION['InstType'] == "Polytechnic") {
                                                $sql = "SELECT * FROM std_data_view WHERE dept_code = '$getdept' AND YAddmitted = '$getyearadmt' AND modeofentry = '$getprogram' ORDER BY matric_no";
                                            } else {
                                                $sql = "SELECT * FROM std_data_view WHERE dept_code = '$getdept' AND YAddmitted = '$getyearadmt' ORDER BY matric_no";
                                            }

                                            $result = $conn2->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $sno++;
                                                    $id = $row["id"];
                                                    $regid = $row['matric_no'];
                                                    $Dept_Option = $row['Dept_Option'];
                                                    $S_STAUS = $row['status'];
                                                    if ($S_STAUS == 6) {
                                                        $S_STAUS = "In Session";
                                                    } elseif ($S_STAUS == 12) {
                                                        $S_STAUS = "Graduated";
                                                    } elseif ($S_STAUS == 14) {
                                                        $S_STAUS = "Withdrawn";
                                                    } elseif ($S_STAUS == 15) {
                                                        $S_STAUS = "Dead";
                                                    }
                                                    $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                    if (empty($names)) {
                                                        $names = $row["names"];
                                                    }

                                                    echo "<tr><td>$sno</td><td>$regid</td><td>$names</td><td>$S_STAUS</td>";
                                                    if ($deptoption == "YES") {
                                                        echo "<td>$Dept_Option</td>";
                                                    }

                                                    echo "<td>
                                                        <form action='spreadsheet_grad_view.php' method='post' target='_blank'>
                                                            <input type='hidden' value='$regid' name='id'>
                                                            
                                                            <input type='submit' name='view_in_sess' class='btn btn-info btn-xs' value='View'>
                                                        </form>
                                                        </td>";

                                                    echo "</tr>\n";
                                                }
                                            }


                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php
                                $conn->close();
                                $conn2->close();
                                ?>
                            <?php } ?>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {
            $('.dataTables-example').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [{
                        extend: 'excel',
                        title: 'ExampleFile'
                    }

                ]

            });

        });
    </script>
</body>

</html>
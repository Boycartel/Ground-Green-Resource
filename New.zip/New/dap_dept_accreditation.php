<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Delete
    <link href='delete_res/bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>-->
    <script src='delete_res/jquery-3.3.1.js' type='text/javascript'> </script>
    <script src='delete_res/bootstrap/js/bootstrap.min.js'> </script>
    <script src='delete_res/bootbox.min.js'> </script>

    <!-- End To Delete -->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $("select.state").change(function() {
                var selecteddept = $(".state option:selected").val();
                $.ajax({
                    type: "POST",
                    url: "dap_dept_prog.php",
                    data: {
                        state: selecteddept
                    }
                }).done(function(data) {
                    $("#getprog").html(data);
                });
            });
        });
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                APU
                            </li>

                            <li class="active">
                                <strong>Department Accreditation</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $GetTitle = "Accreditation Status";
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Department Accreditation
                        </div>
                        <div class="panel-body">
                            <?php
                            if (isset($_POST["delete"])) {
                            }
                            if (isset($_POST["submit"])) {
                                $depart = $_POST["depart"];
                                $prog = $_POST["prog"];
                                $accrtype = $_POST["accrtype"];
                                $dateaccr = $_POST["dateaccr"];
                                $dateaccr = date('d F, Y', strtotime($dateaccr));

                                $sql = "SELECT * FROM deptcoding WHERE DeptCode='$depart'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $DeptName = $row["DeptName"];
                                    }
                                }

                                $sql = "INSERT INTO dept_accreditation (deptcode, program, accr_type, date_accr) VALUES ('$DeptName', '$prog', '$accrtype', '$dateaccr')";
                                $result = $conn->query($sql);
                            }
                            ?>
                            <!-- start: page -->
                            <div class="row">
                                <?php if (isset($_POST["addnew"])) { ?>
                                    <form class="form-horizontal form-bordered" method="post">

                                        <div class="form-group">
                                            <div class="col-sm-1">
                                            </div>
                                            <label class="col-sm-2 control-label">Department</label>
                                            <div class="col-sm-8">
                                                <select class="state form-control m-bot15" name="depart" required="required">
                                                    <option></option>
                                                    <?php
                                                    $sql = "SELECT * FROM deptcoding WHERE students='yes' ORDER BY DeptName";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $DeptCode = $row["DeptCode"];
                                                            $DeptName = $row["DeptName"];
                                                            echo "<option value=$DeptCode>$DeptName</option>";
                                                        }
                                                    }

                                                    ?>

                                                </select>
                                            </div>
                                            <div class="col-sm-1">
                                            </div>
                                        </div>

                                        <div class='form-group'>
                                            <div class="col-sm-1">
                                            </div>
                                            <label class='col-sm-2 control-label'>Program:</label>
                                            <div class='col-sm-8' id='getprog'>

                                            </div>

                                            <div class="col-sm-1">
                                            </div>
                                        </div>
                                        <div class='form-group'>
                                            <div class="col-sm-1">
                                            </div>
                                            <label class='col-sm-2 control-label'>Accreditation Type:</label>
                                            <div class='col-sm-2'>
                                                <select class="form-control m-bot15" name="accrtype" required="required">
                                                    <option>Full</option>
                                                    <option>Interim</option>
                                                    <option>Approved</option>
                                                </select>
                                            </div>
                                            <label class='col-sm-1 control-label'>Date:</label>
                                            <div class='col-sm-4'>
                                                <div class="input-group">
                                                    <span class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </span>
                                                    <input type="text" style="color:#000000" data-plugin-datepicker class="form-control" name="dateaccr">
                                                </div>
                                            </div>
                                            <div class="col-sm-1">
                                                <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                            </div>
                                            <div class="col-sm-1">
                                            </div>
                                        </div>

                                    </form>
                                <?php } ?>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class='form-group'>
                                        <div class="col-sm-1">
                                        </div>
                                        <div class="col-sm-8">

                                        </div>
                                        <div class="col-sm-2">
                                            <?php if (!isset($_POST["addnew"])) { ?>
                                                <button type="submit" name="addnew" class="btn btn-primary btn-sm">Add
                                                    New</button>
                                            <?php } ?>
                                        </div>
                                        <div class="col-sm-1">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                    <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                        <caption><?php echo $GetTitle ?></caption>
                                        <colgroup align="center"></colgroup>
                                        <colgroup align="left"></colgroup>
                                        <colgroup span="2"></colgroup>
                                        <colgroup span="3" align="center"></colgroup>
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Department</th>
                                                <th>Program</th>
                                                <th>Type</th>
                                                <th>Date</th>

                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sno = 0;
                                            $sql = "SELECT * FROM dept_accreditation ORDER BY deptcode";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $sno++;
                                                    $sn = $row["sn"];
                                                    $deptcode = $row["deptcode"];
                                                    $program = $row["program"];
                                                    $accr_type = $row["accr_type"];
                                                    $date_accr = $row["date_accr"];
                                                    echo "<tr><td>$sno</td><td>$deptcode</td><td>$program</td><td>$accr_type</td><td>$date_accr</td>
                                                <td>
                                                <div class='row'>
                                                    <div class='col-sm-6'>
                                                        <form action='' method='post'>
                                                        <input type='hidden' value='$program' name='id'>
                                                        <input type='hidden' value='$sn' name='sn'>
                                                        <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                                        
                                                    </form>
                                                    </div>
                                                    <div class='col-sm-6'>
                                                        <button class='delete_accreditation btn btn-danger btn-xs' id='del_.$sn' data-id='$sn'>Delete</button>
                                                    </div>
                                                </div>
                                                
                                                </td>
                                                                    
                                           </tr>\n";
                                                }
                                            }


                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                                <br><br>
                                <div style="text-align: right">
                                    <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                </div>


                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
        $(document).ready(function() {

            // Delete
            $('.delete_accreditation').click(function() {
                var el = this;

                // Delete id
                var deleteid = $(this).data('id');

                // Confirm box
                bootbox.confirm("Do you really want to delete record?", function(result) {

                    if (result) {
                        // AJAX Request
                        $.ajax({
                            url: 'delete_res/delete_accreditation.php',
                            type: 'POST',
                            data: {
                                id: deleteid
                            },
                            success: function(response) {

                                // Removing row from HTML Table
                                if (response == 1) {
                                    $(el).closest('tr').css('background', 'tomato');
                                    $(el).closest('tr').fadeOut(800, function() {
                                        $(this).remove();
                                    });
                                } else {
                                    bootbox.alert('Record not deleted.');
                                }

                            }
                        });
                    }

                });

            });

        });
    </script>
</body>

</html>
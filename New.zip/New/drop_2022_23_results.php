<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>
<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">


    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Missing</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Missing</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
            if ($conn2->connect_error) {
                die("Connection failed: " . $conn2->connect_error);
            }
?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Missing
                        </div>
                        <div class="panel-body">
                            <?php
                            set_time_limit(500);
                            error_reporting(E_ERROR);


                            if (isset($_POST["submitdrop"])) {
                                $dupDept = strtolower($_POST["deptdrop"]);
                                $dept_db = $_SESSION['deptdb'] . $dupDept;

                                try {
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                } catch (Exception $e) {
                                }

                                $sql = "DELETE FROM scrutiny_senate";
                                $result = $conn_stu->query($sql);

                                $sql = "DELETE FROM correg_2022_2023";
                                $result = $conn_stu->query($sql);

                                $sql = "DELETE FROM absent_students";
                                $result = $conn_stu->query($sql);

                                $dupDept2 = strtoupper($dupDept);
                                $sql = "DELETE FROM hod_semester_res_approval WHERE deptCode = '$dupDept'";
                                $result = $conn->query($sql);

                                $dupDept2 = strtoupper($dupDept);
                                $sql = "DELETE FROM raw_results_2022_2023 WHERE stu_dept = '$dupDept2'";
                                $result = $conn->query($sql);

                                echo "<h2 style='text-align: center; color:red;'>Record deleted successfully...";
                            }

                            ?>



                            <div class="row">
                                <form class="form-horizontal form-bordered" method="post">
                                    <h2 class="panel-title" style="text-align: center">Faculty Board Format</h2>
                                    <br><br><br>
                                    <div class="col-lg-5">
                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-7">
                                                <select class="country form-control" style="color:#000000" name="dept">
                                                    <option value="SelectItem">Select Item</option>
                                                    <?php
                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = strtolower($row["DeptCode"]);
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-lg-3">
                                        <button type="submit" name="submitdept"
                                            class="btn btn-primary btn-sm">Submit</button>
                                    </div>
                                </form>
                            </div>
                            <?php if (isset($_POST["submitdept"])) { ?>
                            <div class="row">
                                <form class="form-horizontal form-bordered" method="post">
                                    <?php
                                        $detpdrop = $_POST["dept"];
                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$detpdrop'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $deptname2 = $row["DeptName"];
                                            }
                                        }
                                        ?>
                                    <h2 style="text-align: center; color:red;">Drop Record of <?php echo $deptname2 ?>?
                                    </h2>
                                    <div class="row">
                                        <div class="col-lg-2">

                                        </div>
                                        <div class="col-lg-8">
                                            <table class="table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>S/No</th>
                                                        <th>Matric No</th>
                                                        <th>Course Code</th>
                                                        <th>Total</th>
                                                        <th>Session</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php

                                                        $sno = 0;
                                                        $sql = "SELECT * FROM raw_results_2022_2023 WHERE stu_dept = '$detpdrop'";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $CCode = $row["CCode"];
                                                                $total = $row["total"];
                                                                $SessionRegis = $row["SessionRegis"];
                                                                $Regn1 = $row["Regn1"];
                                                                echo "<tr><td>$sno</td><td>$Regn1</td><td>$CCode</td><td>$total</td><td>$SessionRegis</td></tr>";
                                                            }
                                                        }
                                                        ?>
                                                </tbody>
                                            </table>
                                            <div class="row" style="text-align: right;">
                                                <input type="hidden" name="deptdrop" value="<?php echo $detpdrop ?>">
                                                <button type="submit" name="submitdrop"
                                                    class="btn btn-primary btn-sm">Drop</button>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">

                                        </div>

                                    </div>



                                </form>
                            </div>
                            <?php } ?>


                        </div>
                    </div>

                    <?php
$conn->close();
$conn2->close();
$conn_stu->close();
?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Table -->
    <script src="js/plugins/dataTables/datatables.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>


</body>

</html>
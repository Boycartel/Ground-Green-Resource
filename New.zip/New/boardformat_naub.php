<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['board_format'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?> Students' Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword" content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>


    <style>
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }
    </style>

    <style>
        .btn-xs,
        .btn-group-xs>.btn {
            padding: 1px 5px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px;
        }
    </style>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
        <form class="form-horizontal form-bordered" method="post">

            <div class="row">
                <h2 class="panel-title" style="text-align: center">Faculty Board Format</h2>
                <br><br><br>
                <div class="col-lg-5">
                    <div class="row">
                        <label class="control-label col-lg-5" for="content">Select Department:</label>
                        <div class="col-lg-7">
                            <select class="country form-control" style="color:#000000" name="dept">
                                <option value="SelectItem">Select Item</option>
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }


                                $dept = $_SESSION['deptcode'];


                                if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                } else {
                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                }


                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    // output data of each row
                                    while ($row = $result->fetch_assoc()) {
                                        $deptcode2 = strtolower($row["DeptCode"]);
                                        $deptname2 = $row["DeptName"];
                                        echo "<option value=$deptcode2>$deptname2</option>";
                                    }
                                }
                                $conn->close();
                                ?>

                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="row">
                        <label class="control-label col-lg-5" for="regid">Level:</label>
                        <div class="col-lg-7">
                            <select name="getlevel" class="form-control" style="color:#000000" id="getlevel">
                                <option value="100">100</option>
                                <option value="200">200</option>
                                <option value="300">300</option>
                                <option value="400">400</option>
                                <option value="500">500</option>

                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="row">
                        <label class="control-label col-lg-5" for="regid">Session:</label>
                        <div class="col-lg-7">
                            <?php
                            $iniyear = 2015;
                            $finalyear = substr($_SESSION['corntsession'], 5);

                            ?>
                            <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                    <?php echo $_SESSION['corntsession'] ?></option>
                                <?php
                                while ($iniyear <= $finalyear) {
                                    $addyear = $iniyear + 1;

                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                    $iniyear++;
                                }

                                ?>


                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="row">
                        <label class="control-label col-lg-4" for="regid">Semester:</label>
                        <div class="col-lg-4">
                            <select name="getsemester" class="form-control" style="color:#000000" id="getsemester">
                                <option value="1ST">1ST</option>
                                <option value="2ND">2ND</option>

                            </select>
                        </div>
                        <div class="col-lg-4">
                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                        </div>
                    </div>
                </div>

            </div>
        </form>
        <hr class="separator" />
    </div>

    <hr class="separator" />
    <div style="padding-left:3em; padding-right: 3em">
        <?php
        if (isset($_POST["submitAll"])) {
            $getstatus = $_POST["getstatus"];
            $getdept = $_SESSION['dept_sctny'];
            $getsession = $_SESSION['getsession_sctny'];
            $getsemester = $_SESSION['getsemester_sctny'];
            $getlevel = $_SESSION['getlevel_sctny'];

            $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
            if ($conn_stu->connect_error) {
                die("Connection failed: " . $conn_stu->connect_error);
            }

            $sql2 = "UPDATE scrutiny_senate SET board_aproval = '$getstatus' WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval <> 'Approve'";
            $result2 = $conn_stu->query($sql2);
            $conn_stu->close();
        }

        ?>
        <?php if (isset($_POST["submit"]) || isset($_POST["submitAll"])) { ?>
            <?php
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }


            set_time_limit(1000);
            $DegType = $_SESSION['DegType'];

            if (isset($_POST["submit"])) {
                $_SESSION['dept_sctny'] = $_POST["dept"];
                $_SESSION['getsession_sctny'] = $_POST["getsession"];
                $_SESSION['getsemester_sctny'] = $_POST["getsemester"];
                $_SESSION['getlevel_sctny'] = $_POST["getlevel"];
            }

            $_SESSION['sn'] = 0;

            $deptname = "";

            $getdept = $_SESSION['dept_sctny'];
            $getsession = $_SESSION['getsession_sctny'];
            $getsemester = $_SESSION['getsemester_sctny'];
            $getlevel = $_SESSION['getlevel_sctny'];

            $sql = "SELECT DeptName, DeptCode FROM deptcoding WHERE DeptCode = '$getdept'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $deptname = $row["DeptName"];
                }
            }
            $conn->close();
            ?>
            <section class="panel panel-success">
                <!--<div style="text-align: center"><h2 class="panel-title"><?php /*echo $deptname */ ?> Department</h2></div>
                <br><br>-->
                <div class="panel-body">
                    <form class="form-horizontal form-bordered" method="post">
                        <div class="row">
                            <div class="col-lg-6">

                            </div>
                            <label class="control-label col-lg-2" for="regid">Select Status:</label>
                            <div class="col-lg-3">
                                <select name="getstatus" class="form-control" style="color:#000000" id="getstatus" required>
                                    <option value='Yet'>Yet</option>
                                    <option value='Approve'>Approve</option>
                                    <option value='Not Approve'>Not Approve</option>

                                </select>

                            </div>
                            <div class="col-lg-1" style="text-align: right">
                                <button type="submit" name="submitAll" class="btn btn-primary btn-xs">Submit All
                                </button>
                            </div>
                        </div>
                    </form>
                    <br>
                    <div class="row">
                        <div class="col-lg-4">
                            Department: <?php echo $deptname; ?>
                        </div>
                        <div class="col-lg-2">
                            Level: <?php echo $_SESSION['getlevel_sctny']; ?>
                        </div>
                        <div class="col-lg-3">
                            Session: <?php echo $_SESSION['getsession_sctny']; ?>
                        </div>
                        <div class="col-lg-3">
                            Semester: <?php echo $_SESSION['getsemester_sctny']; ?>
                        </div>

                    </div>
                    <hr class="separator" />
                    <br>
                    <div class="col-lg-12">
                        <?php
                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                        if ($conn2->connect_error) {
                            die("Connection failed: " . $conn2->connect_error);
                        }
                        unset($LblCodeArray);
                        $LblCodeArray[] = "";
                        unset($CourseCodeArray);
                        $CourseCodeArray[] = "";
                        $countCCode = 0;

                        unset($LblCodeArray2);
                        $LblCodeArray2[] = "";
                        unset($CourseCodeArray2);
                        $CourseCodeArray2[] = "";
                        $countCCode2 = 0;

                        $deptgencourses = "gencourses";

                        $sql = "SELECT DISTINCT CCode, session1, Level1, DeptCode, SemTaken, levelCode, split_two, CUnit, course_level FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                if ($row["course_level"] == $getlevel) {
                                    $countCCode++;
                                    $CourseCodeArray[$countCCode] = $row["CCode"];
                                    $CCode = $row["split_two"];
                                    $LblCodeArray[$countCCode] = $CCode . " (" . $row["CUnit"] . ")";
                                } else {
                                    $countCCode2++;
                                    $CourseCodeArray2[$countCCode2] = $row["CCode"];
                                    $CCode = $row["split_two"];
                                    $LblCodeArray2[$countCCode2] = $CCode . " (" . $row["CUnit"] . ")";
                                }
                            }
                        }

                        ?>
                        <table id="customers">
                            <thead style='text-align:center'>
                                <tr>

                                    <?php if ($getlevel == 100) { ?>
                                        <th colspan="<?php echo $countCCode + 3 ?>"></th>
                                    <?php } ?>
                                    <?php if ($getlevel == 200) { ?>
                                        <th colspan="<?php echo $countCCode + 4 ?>"></th>
                                    <?php } ?>
                                    <?php if ($getlevel == 300) { ?>
                                        <th colspan="<?php echo $countCCode + 5 ?>"></th>
                                    <?php } ?>
                                    <?php if ($getlevel == 400) { ?>
                                        <th colspan="<?php echo $countCCode + 6 ?>"></th>
                                    <?php } ?>
                                    <?php if ($getlevel == 500) { ?>
                                        <th colspan="<?php echo $countCCode + 7 ?>"></th>
                                    <?php } ?>
                                    <th colspan="4" style="text-align: center;">PREVIOUS</th>
                                    <th colspan="4" style="text-align: center;">CURRENT</th>
                                    <th colspan="4" style="text-align: center;">CUMULATIVE</th>
                                    <th colspan="4"></th>
                                </tr>
                                <tr>
                                    <th>S/ No</th>
                                    <th>Matric_No/ Name</th>

                                    <?php for ($i = 1; $i <= $countCCode; $i++) { ?>
                                        <th style="font-size: 10px"><?php echo $LblCodeArray[$i] ?></th>
                                    <?php } ?>
                                    <th style="font-size: 10px">OTHER COURSES</th>
                                    <?php if ($getlevel == 200) { ?>
                                        <th style="font-size: 10px">100L CGPA</th>
                                    <?php } ?>
                                    <?php if ($getlevel == 300) { ?>
                                        <th style="font-size: 10px">100L CGPA</th>
                                        <th style="font-size: 10px">200L CGPA</th>
                                    <?php } ?>
                                    <?php if ($getlevel == 400) { ?>
                                        <th style="font-size: 10px">100L CGPA</th>
                                        <th style="font-size: 10px">200L CGPA</th>
                                        <th style="font-size: 10px">300L CGPA</th>
                                    <?php } ?>
                                    <?php if ($getlevel == 500) { ?>
                                        <th style="font-size: 10px">100L CGPA</th>
                                        <th style="font-size: 10px">200L CGPA</th>
                                        <th style="font-size: 10px">300L CGPA</th>
                                        <th style="font-size: 10px">400L CGPA</th>
                                    <?php } ?>
                                    <th style="font-size: 10px">TCUR</th>
                                    <th style="font-size: 10px">PCP</th>
                                    <th style="font-size: 10px">TWGP</th>
                                    <th style="font-size: 10px">CGPA</th>
                                    <th style="font-size: 10px">TCUR</th>
                                    <th style="font-size: 10px">SCP</th>
                                    <th style="font-size: 10px">TWGP</th>
                                    <th style="font-size: 10px">CGPA</th>
                                    <th style="font-size: 10px">TCUR</th>
                                    <th style="font-size: 10px">TCP</th>
                                    <th style="font-size: 10px">TWGP</th>
                                    <th style="font-size: 10px">CGPA</th>
                                    <th>REMARKS</th>
                                    <!--<th>Deff. & Outstanding</th>-->
                                    <th>Approval</th>
                                    <th>Comment</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sno = 0;
                                $DEFCount = 0;
                                $IGSCount = 0;
                                $SP1Count = 0;
                                $SP2Count = 0;
                                $PCount = 0;
                                $DLCount = 0;
                                $VCLCount = 0;
                                $Ten88Count = 0;
                                $BL2Count = 0;

                                $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $sno++;
                                        $regid = $row["Regn"];
                                        $names = $row["Name1"];
                                        $id = $row["sn"];
                                        $aproval = $row['board_aproval'];
                                        $coment = $row["board_comment"];

                                        $defout = $def = $out = $rmk = $grade = "";


                                        $unit = $ptct = $ptcp = $pgp = $pcgpa = $stct = $stcp = $sgp = $scgpa = $tct = $tcp = $tgp = $cgpa = 0;
                                        $cgpa100 = $row['CGPA100'];
                                        $cgpa200 = $row['CGPA200'];
                                        $cgpa300 = $row['CGPA300'];
                                        $cgpa400 = $row['CGPA400'];

                                        $ptct = $row['PCT'];
                                        $ptcp = $row['PCP'];
                                        $pgp = $row['PGP'];
                                        $pcgpa = $row['PCGPA'];

                                        $stct = $row['SCT'];
                                        $stcp = $row['SCP'];
                                        $sgp = $row['SGP'];
                                        $scgpa = $row['SGPA'];
                                        $tct = $row['TCT'];
                                        $tcp = $row['TCP'];
                                        $tgp = $row['CGP'];
                                        $cgpa = $row['CGPA'];
                                        $rmk = $row['RMK'];
                                        $defout = $row['def_out'];

                                        if ($rmk == "P") {
                                            $PCount++;
                                            $full_rmk = "Sem Prob " . $defout;
                                        } elseif ($rmk == "IGS") {
                                            $IGSCount++;
                                            $full_rmk = "PASS";
                                        } elseif ($rmk == "DEF") {
                                            $DEFCount++;
                                            $full_rmk = "CO " . $defout;
                                        } elseif ($rmk == "SP1") {
                                            $SP1Count++;
                                            $full_rmk = "Sess Prob I " . $defout;
                                        } elseif ($rmk == "SP2") {
                                            $SP2Count++;
                                            $full_rmk = "Sess Prob II(WD) " . $defout;
                                        } elseif ($rmk == "DL") {
                                            $DLCount++;
                                            $full_rmk = "PASS Dean List";
                                        } elseif ($rmk == "VL") {
                                            $VCLCount++;
                                            $full_rmk = "VC List";
                                        } elseif ($rmk == "8-7-6") {
                                            $Ten88Count++;
                                            $full_rmk = "8-7-6 " . $defout;
                                        } elseif ($rmk == "BL2") {
                                            $BL2Count++;
                                            $full_rmk = "BL2 " . $defout;
                                        }

                                        if ($ptct == 0) {
                                            $ptct = "";
                                            $ptcp = "";
                                            $pgp = "";
                                            $pcgpa = "";
                                        } else {
                                            $ptct = $row['PCT'];
                                            $ptcp = $row['PCP'];
                                            $pgp = $row['PGP'];
                                            $pcgpa = $row['PCGPA'];
                                        }

                                        if ($stct == 0) {
                                            $stct2 = "";
                                            $stcp = "";

                                            $Response = "";

                                            $sql2 = "SELECT * FROM missing_session WHERE matno = '$regid' AND session = '$getsession' AND semester = '$getsemester'";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $Response = $row2["response"];
                                                }
                                            }
                                            if ($Response == "Deferment") {
                                                $sgp = "Defe";
                                                $scgpa = "rred";
                                            } elseif ($Response == "Condonation") {
                                                $sgp = "Con";
                                                $scgpa = "done";
                                            } elseif ($Response == "VolWithdrawal") {
                                                $sgp = "With";
                                                $scgpa = "drawn";
                                            } elseif ($Response == "PoorWithdrawal") {
                                                $sgp = "With";
                                                $scgpa = "drawn";
                                            } elseif ($Response == "Notification_illhealth") {
                                                $sgp = "Ill";
                                                $scgpa = "Health";
                                            } else {
                                                $sgp = "Abs";
                                                $scgpa = "cond";
                                            }
                                        } else {
                                            $stct2 = $row['SCT'];
                                            $stcp = $row['SCP'];
                                            $sgp = $row['SGP'];
                                            $scgpa = $row['SGPA'];
                                        }
                                        $other_courses = "";
                                        for ($j = 1; $j <= $countCCode2; $j++) {
                                            $grade = "-";
                                            $total = "";
                                            $StuCurSess = str_ireplace("/", "_", $getsession);
                                            $deptcorreg = "correg_" . $StuCurSess;
                                            $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND CCode  = '$CourseCodeArray2[$j]' AND SemTaken = '$getsemester' AND SessionRegis =  '$getsession'";
                                            $result2 = $conn_stu->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    //$grade = $row2["grade"];
                                                    $total = $row2["CA"] + $row2["Exam"];
                                                    $other_courses = $other_courses . ", " . $row2["CUnit"] . $CourseCodeArray2[$j] . "(" . $total . $row2["grade"] . ")";
                                                }
                                            }
                                        }

                                        echo "<tr><td>$sno</td><td>$regid <br> $names</td>";
                                        for ($i = 1; $i <= $countCCode; $i++) {
                                            $grade = "-";
                                            $total = "";
                                            $StuCurSess = str_ireplace("/", "_", $getsession);
                                            $deptcorreg = "correg_" . $StuCurSess;
                                            $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND CCode  = '$CourseCodeArray[$i]' AND SemTaken = '$getsemester' AND SessionRegis =  '$getsession'";
                                            $result2 = $conn_stu->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $grade = $row2["grade"];
                                                    $total = $row2["CA"] + $row2["Exam"];
                                                }
                                            }
                                            echo "<td>$total $grade</td>";
                                        }
                                        echo "<td>$other_courses</td>";
                                        if ($getlevel == 200) {
                                            echo "<td>$cgpa100</td>";
                                        } elseif ($getlevel == 300) {
                                            echo "<td>$cgpa100</td><td>$cgpa200</td>";
                                        } elseif ($getlevel == 400) {
                                            echo "<td>$cgpa100</td><td>$cgpa200</td><td>$cgpa300</td>";
                                        } elseif ($getlevel == 500) {
                                            echo "<td>$cgpa100</td><td>$cgpa200</td><td>$cgpa300</td><td>$cgpa400</td>";
                                        }

                                        if ($stct == 0) {
                                            if ($Response == "Deferment" || $Response == "Condonation" || $Response == "Notification_illhealth") {
                                                echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td style='background-color: purple; color: white'>$sgp</td><td style='background-color: purple; color: white'>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$full_rmk</td>";
                                            } else {
                                                echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td style='background-color: #9d1e15; color: white'>$sgp</td><td style='background-color: #9d1e15; color: white'>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$full_rmk</td>";
                                            }
                                        } else {
                                            echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td>$sgp</td><td>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$full_rmk</td>";
                                        }


                                        echo '<td><a href="#" class="board_aproval" id="board_aproval_' . $row["sn"] . '" data-type="select" data-pk="' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="board_aproval">' . $row["board_aproval"] . '</a></td>
                                           <td><a href="#" class="board_comment" id="board_comment_' . $row["sn"] . '" data-type="text" data-pk = "' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="board_comment">' . $row["board_comment"] . '</a></td>
                                          ';

                                        echo "</tr>\n";
                                    }
                                }
                                $SubTotal = $PCount + $IGSCount + $DEFCount + $SP1Count + $SP2Count + $DLCount + $VCLCount + $Ten88Count + $BL2Count;

                                ?>
                            </tbody>
                        </table>
                        <?php
                        $conn->close();
                        $conn2->close();
                        $conn_stu->close();
                        ?>
                    </div>
                    <div>
                        <p style="font-size: 14px">
                            <?php
                            if ($DegType == "BEng") {
                                echo "SUMMARY<br>  VC's' List = " . $VCLCount . ",  Dean's' List = " . $DLCount . ",  PASS = " . $IGSCount . ",   Reapeat Course = " . $DEFCount . ",  Sem Prob = " . $PCount . ",   Sess Prob I = " . $SP1Count . ",   Sess Prob II = " . $SP2Count . ",  8-7-6 = " . $Ten88Count . ",  BL2 = " . $BL2Count . ",  Total = " . $SubTotal;
                            } else {
                                echo "SUMMARY<br>   VC's' List = " . $VCLCount . ",  Dean's' List = " . $DLCount . ",  PASS = " . $IGSCount . ",   Reapeat Course = " . $DEFCount . ",  Sem Prob = " . $PCount . ",   Sess Prob I = " . $SP1Count . ",  Sess Prob II = " . $SP2Count . ",  Total = " . $SubTotal;
                            }

                            ?>
                        </p>
                    </div>


                </div>
                <br><br>
                <div class="row" style="text-align: right">
                    <form action='Print_rec/print_schboard_naub.php' method='post' target='_blank'>
                        <input type='submit' name='print' class='btn btn-outline-success btn-sm' value='Print Preview'>
                    </form>
                </div>
                <br><br>
            </section>
        <?php } ?>

    </div>



    <script>
        //For Last Name Table Column Data

        const board_comment = document.getElementsByClassName('board_comment');

        for (var count = 0; count < board_comment.length; count++) {
            const board_comment_data = document.getElementById(board_comment[count].getAttribute('id'));

            const board_comment_popover = new DarkEditable(board_comment_data);
        }


        //For Gender Table column Data

        const board_aproval = document.getElementsByClassName('board_aproval');

        for (var count = 0; count < board_aproval.length; count++) {
            const board_aproval_data = document.getElementById(board_aproval[count].getAttribute("id"));

            const board_aproval_popover = new DarkEditable(board_aproval_data, {
                source: [{
                        value: 'Yet',
                        text: 'Yet'
                    },
                    {
                        value: 'Approve',
                        text: 'Approve'
                    },
                    {
                        value: 'Not Approve',
                        text: 'Not Approve'
                    }
                ]
            });
        }
    </script>

</body>

</html>
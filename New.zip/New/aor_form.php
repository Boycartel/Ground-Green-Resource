<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script type="text/javascript">
        function printDiv(div_id) {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var content_vlue = document.getElementById(div_id).innerHTML;

            var docprint = window.open("", "", disp_setting);

            ///// Enable Bootstrap CSS
            //// Can also add customise CSS
            docprint.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
            );
            docprint.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php
    $staffid = $_SESSION['staffid'];
    $corntsession = $_SESSION['corntsession'];
    $cursemester = $_SESSION['cursemester'];
    $schname = $_SESSION['schname'];
    $deptname = $_SESSION['deptname'];

    if (isset($_POST["submit"])) {
        $getsession = $_POST["getsession"];
        $getsemester = $_POST["getsemester"];

        $sql2 = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$getsession' AND Semester = '$getsemester'";
        $result2 = $conn->query($sql2);
        $teachunit = 0;
        if ($result2->num_rows > 0) {
            while ($row2 = $result2->fetch_assoc()) {
                $teachunit = $teachunit + $row2["CUnit"];
            }
        }
    }

    $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $emailAdd = $row['emailAdd'];
            $phone = $row['phone'];
        }
    }

    $sql = "SELECT * FROM staff_profile WHERE PSN = '$staffid'";
    $result = $conn7->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $fname = $row['fname'];
            $surname = $row['sname'];
            $othernames = $row['oname'];
            $mytitle = $row['title'];
            $apptype = $row['Status'];
            $leaveabsent_study = $row['leaveabsent_study'];
            $postn_rank = $row['Rank1'];
            $GradeL = $row['GradeL'];

            $area_special = $row['area_special'];
        }
    }


    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Assignment of Responsibility (AOR) Form</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>AOR Form</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Assignment of Responsibility (AOR) Form
                        </div>
                        <div class="panel-body">
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <div>
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">Session: </label>
                                            <div class="col-lg-3">
                                                <?php
                                                $iniyear = 2015;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>
                                            </div>
                                            <label class="control-label col-lg-2" for="regid">Semester:</label>
                                            <div class="col-lg-2">
                                                <select name="getsemester" class="form-control" style="color:#000000" id="getsemester">
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>

                                                </select>
                                            </div>
                                            <div class="col-lg-2">
                                                <button type="submit" name="submit" class="btn btn-sm btn-primary">Submit</button>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <br>
                                <hr class="separator" />
                                <br>
                                <?php if (isset($_POST["submit"])) { ?>
                                    <div class="col-md-12">
                                        <div id="printableArea">
                                            <h3 style="text-align: center"><?php echo $_SESSION['instname'] ?><br><b style="font-size:large">ASSIGNMENT OF RESPONSIBILITY (AOR)
                                                    FORM</b></h3>
                                            <?php
                                            if ($apptype == "fulltime") {
                                                $apptypefull = "Full Time";
                                            } elseif ($apptype == "parttime") {
                                                $apptypefull = "Part Time";
                                            } elseif ($apptype == "Contract") {
                                                $apptypefull = "Contract";
                                            }
                                            ?>
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label"><b>Session:
                                                        <?php echo $getsession ?></b></label>
                                                <label class="col-lg-4 control-label"><b><?php echo $getsemester ?>
                                                        Semester</b> </label>
                                                <label class="col-lg-4 control-label" style="text-align: right"><b>Appointment:
                                                        <?php echo $apptypefull ?></b>
                                                </label>

                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-3 control-label"><b>Last Name:</b>
                                                    <?php echo $surname ?></label>
                                                <label class="col-lg-3 control-label"><b>First Name:</b>
                                                    <?php echo $fname ?> </label>
                                                <label class="col-lg-3 control-label"><b>Middle Name: </b>
                                                    <?php echo $othernames ?></label>
                                                <label class="col-lg-3 control-label" style="text-align: right"><b>PF No:
                                                    </b> <?php echo $staffid ?></label>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-12 control-label"><b>Name of School:</b>
                                                    <?php echo $schname ?></label>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-8 control-label"><b>Name of Department:</b>
                                                    <?php echo $deptname ?></label>
                                                <label class="col-lg-4 control-label" style="text-align: right"><b>Staff
                                                        Phone No:</b> <?php echo $phone ?></label>
                                            </div>

                                            <?php
                                            if ($postn_rank == "Prof") {
                                                $postn_rank_full = "Professor";
                                            } elseif ($postn_rank == "assprof") {
                                                $postn_rank_full = "Associate Professor";
                                            } elseif ($postn_rank == "SL") {
                                                $postn_rank_full = "Senior Lecturer";
                                            } elseif ($postn_rank == "LI") {
                                                $postn_rank_full = "Lecturer I";
                                            } elseif ($postn_rank == "LII") {
                                                $postn_rank_full = "Lecturer II";
                                            } elseif ($postn_rank == "AL") {
                                                $postn_rank_full = "Assistant Lecturer";
                                            } else {
                                                $postn_rank_full = "Graduate Assistant";
                                            }
                                            ?>
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label"><b>Position/Rank:</b>
                                                    <?php echo $postn_rank_full ?></label>
                                                <label class="col-lg-4 control-label"><b>Salary Grade Level:</b>
                                                    CONUASS
                                                    <?php echo $GradeL ?></label>
                                                <label class="col-lg-4 control-label" style="text-align: right"><b>Teaching
                                                        Credit Units:</b> <?php echo $teachunit ?></label>
                                            </div>


                                            <hr class="separator" />
                                            <h4><strong>1. TEACHING</strong></h4>
                                            <table class="table table-striped mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Course Code</th>
                                                        <th>Course Name/Title</th>
                                                        <th>Venue</th>
                                                        <th>Lecture Days & Time</th>
                                                        <th>Credit Hours</th>
                                                        <th>Lab/ Studio (Y/N)</th>
                                                        <th>No. of Lecturers</th>
                                                        <th>Total Student Enroll</th>
                                                        <th>% Input (QAP Use)</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $getsemester = $_POST["getsemester"];
                                                    $sql = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$getsession' AND Semester = '$getsemester' ORDER BY CCode";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["sn"];
                                                            $CCode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $getsession2 = str_replace("/", "_", $getsession);
                                                            $sql2 = "SELECT * FROM courses_register_" . $getsession2 . " WHERE CCode = '$CCode'";
                                                            $result2 = $conn->query($sql2);
                                                            $countstu = 0;
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $countstu++;
                                                                }
                                                            }
                                                            $countstu = number_format($countstu, 0);

                                                            $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode'";
                                                            $result2 = $conn->query($sql2);
                                                            $lectureDays = "";
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $venue = $row2["venue"];
                                                                    if (strlen($row2["M"]) > 1) {
                                                                        $lectureDays = $lectureDays . "Monday " . $row2["M"] . " (" . $row2["MHr"] . " hr(s))<br>";
                                                                    }

                                                                    if (strlen($row2["T"]) > 1) {
                                                                        $lectureDays = $lectureDays . "Tuesday " . $row2["T"] . " (" . $row2["THr"] . " hr(s))<br>";
                                                                    }

                                                                    if (strlen($row2["W"]) > 1) {
                                                                        $lectureDays = $lectureDays . "Wednesday " . $row2["W"] . " (" . $row2["WHr"] . " hr(s))<br>";
                                                                    }

                                                                    if (strlen($row2["Th"]) > 1) {
                                                                        $lectureDays = $lectureDays . "Thursday " . $row2["Th"] . " (" . $row2["ThHr"] . " hr(s))<br>";
                                                                    }

                                                                    if (strlen($row2["F"]) > 1) {
                                                                        $lectureDays = $lectureDays . "Friday " . $row2["F"] . " (" . $row2["FHr"] . " hr(s))<br>";
                                                                    }

                                                                    if (strlen($row2["S"]) > 1) {
                                                                        $lectureDays = $lectureDays . "Saturday " . $row2["S"] . " (" . $row2["SHr"] . " hr(s))<br>";
                                                                    }
                                                                }
                                                            }

                                                            $sql2 = "SELECT * FROM coursealocation WHERE CCode = '$CCode' AND SessionReg = '$getsession'";
                                                            $result2 = $conn->query($sql2);
                                                            $countstaff = 0;
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $countstaff++;
                                                                }
                                                            }
                                                            echo "<tr><td>$CCode</td><td>$CTitle</td><td>$venue</td><td>$lectureDays</td><td>$CUnit</td><td></td><td>$countstaff</td><td>$countstu</td><td></td></tr>";
                                                        }
                                                    }
                                                    ?>

                                                </tbody>
                                            </table>
                                            <h5 style="text-align: right"><strong>Sub total:______________</strong>
                                            </h5>
                                            <hr class="separator" />
                                            <h4><strong>2. ADMINISTRATIVE DUTIES(<i>Complete the Activity Form with
                                                        Documentation Attached</i>)</strong></h4>
                                            <table class="table table-striped mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Type of Activity</th>
                                                        <th>Details</th>
                                                        <th>Year</th>
                                                        <th>% Input (QAP Use)</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sql = "SELECT * FROM admin_duties WHERE staffid = '$staffid' AND session1 = '$getsession' AND approval = 'YES' ";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $activit_code = $row['activit_code'];
                                                            $activity_type = $row['activity_type'];
                                                            $year1 = $row['year1'];
                                                            $session1 = $row['session1'];
                                                            $id = $row['id'];
                                                            if ($activit_code == "15" || $activit_code == "18" || $activit_code == "19") {
                                                                $specify = $row['specify'];
                                                                echo "<tr><td>$activity_type</td><td>$specify</td><td>$year1</td><td></td>";
                                                            } else {
                                                                echo "<tr><td>$activity_type</td><td></td><td>$year1</td><td></td>";
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <h5 style="text-align: right"><strong>Sub total:______________</strong>
                                            </h5>

                                            <hr class="separator" />
                                            <h4><strong>3. FUNDED RESEARCH & CUNSULTANCY(<i>Complete the Research
                                                        Activity
                                                        Report Form with Documentation Attached</i>)</strong></h4>
                                            <table class="table table-striped mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Project No</th>
                                                        <th>Title of Award</th>
                                                        <th>In-Kind Required by Grant</th>
                                                        <th>Release Time</th>
                                                        <th>Total (Amount)</th>
                                                        <th>Remark</th>
                                                        <th>% Input (QAP Use)</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sql = "SELECT * FROM funded_research WHERE staffid = '$staffid' AND session1 = '$getsession' AND approval = 'YES'";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $projt_no = $row['projt_no'];
                                                            $projt_title = $row['projt_title'];
                                                            $reguire_grant = $row['reguire_grant'];
                                                            $release_time = $row['release_time'];
                                                            $totamount = number_format($row['totamount'], 2);
                                                            //$totamount = $row['totamount'];
                                                            $remark1 = $row['remark1'];
                                                            echo "<tr><td>$projt_no</td><td>$projt_title</td><td>$reguire_grant</td><td>$release_time</td><td>$totamount</td><td>$remark1</td><td></td><td>";
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <h5 style="text-align: right"><strong>Sub total:______________</strong>
                                            </h5>
                                            <h5 style="text-align: right"><strong>TOTAL DESIGNATED INPUT (QAP
                                                    Use):______________</strong></h5>

                                            <hr class="separator" />
                                            <h4><strong>4. COMMUNITY SERVICE (<i>Services Rendered Without Demand
                                                        for
                                                        Payment)</i></strong></h4>
                                            <table class="table table-striped mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Type</th>
                                                        <th>Beneficiary</th>
                                                        <th>Effect</th>
                                                        <th>Date</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sql = "SELECT * FROM comm_service WHERE staffid = '$staffid' AND session1 = '$getsession' AND approval = 'YES'";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $type_comm = $row['type_comm'];
                                                            $beneficiary = $row['beneficiary'];
                                                            $effect = $row['effect'];
                                                            $date_comm = $row['date_comm'];

                                                            echo "<tr><td>$type_comm</td><td>$beneficiary</td><td>$effect</td><td>$date_comm</td><td>";
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <h4><strong>I CERTIFY THAT ABOVE INPUT HAS BEEN ASSIGNED:</strong></h4>
                                            <hr class="separator" />

                                            <div class="form-group">
                                                <label class="col-lg-4 control-label" style="text-align: center">-----------------------------------------<br>Lecturer's
                                                    Signature</label>
                                                <label class="col-lg-2 control-label" style="text-align: center">---------------------<br>Date</label>
                                                <label class="col-lg-4 control-label" style="text-align: center">-----------------------------------------<br>HOD's
                                                    Signature</label>
                                                <label class="col-lg-2 control-label" style="text-align: center">---------------------<br>Date</label>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label" style="text-align: center">-----------------------------------------<br>Dean's
                                                    Signature</label>
                                                <label class="col-lg-2 control-label" style="text-align: center">---------------------<br>Date</label>
                                                <label class="col-lg-4 control-label" style="text-align: center"><br></label>
                                                <label class="col-lg-2 control-label" style="text-align: center"><br></label>
                                            </div>
                                        </div>
                                        <div class="row" style="text-align: right">
                                            <br>
                                            <input type="button" onclick="printDiv('printableArea')" value="print" class="btn-success" />
                                        </div>
                                    </div>

                                <?php } ?>
                            </div>
                            <div class="col-md-1">
                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

</body>

</html>
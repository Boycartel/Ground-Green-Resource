<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';


?>




<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_R.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>

</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Record View</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Record View</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                if ($conn2->connect_error) {
                    die("Connection failed: " . $conn2->connect_error);
                }

                $dept = $_SESSION['deptcode'];
                $deptname = $_SESSION['deptname'];
                $corntsession = $_SESSION['corntsession'];
                $resultsession = $_SESSION['resultsession'];
                $resultsemester = $_SESSION['resultsemester'];
                if (isset($_POST["viewCourse"])) {
                    $course = $_POST['id'];
                    $session = $corntsession;

                    $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$course'";
                    $result2 = $conn->query($sql2);
                    if ($result2->num_rows > 0) {
                        while ($row = $result2->fetch_assoc()) {
                            $cursedept = strtolower($row["Department"]);
                            $coursetitle = $row["C_title"];
                        }
                    }
                }

                if (isset($_POST["viewStu"])) {
                    $state = $_POST['id'];
                    $statefull = strtolower($_POST['id2']);
                    /* $sql2 = "SELECT * FROM states WHERE StateCode = '$state'";
                    $result2 = $conn->query($sql2);
                    if ($result2->num_rows > 0) {
                        while ($row = $result2->fetch_assoc()) {
                            $GetTitle = $row["state"] . " State";
                        }
                    } */
                }

                if (isset($_POST["viewStuLevel"])) {
                    $level = $_POST['id'];
                    $GetTitle = $level . " Level";
                }


                ?>
                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            <?php if (isset($_POST["viewCourse"])) { ?>
                            Students' Registered Courses
                            <?php } ?>
                            <?php if (isset($_POST["viewStu"])) { ?>
                            Registered Students from <?php echo $statefull ?> State
                            <?php } elseif (isset($_POST["viewStuLevel"])) {  ?>
                            Registered <?php echo $GetTitle ?> Students
                            <?php } ?>
                        </div>
                        <div class="panel-body">
                            <div class="row">



                                <div class="col-lg-12  col-md-12">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <?php
                                        set_time_limit(500);
                                        $sno = 0;
                                        if (isset($_POST["viewCourse"])) {
                                            $GetTitle = $coursetitle;

                                        ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                            rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>

                                                    <th>SNo</th>
                                                    <th>Matric No</th>
                                                    <th>Name</th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Session</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $courseRegSplitSess = $_SESSION['courseRegSplitSess'];
                                                    if ($session < $courseRegSplitSess) {
                                                        $sql = "SELECT Regn1, name1, CCode, CTitle, CUnit, SemTaken, session FROM courses_register WHERE CCode= '$course' AND session= '$session' ORDER BY Regn1";
                                                        //$sql = "SELECT * FROM courses_register WHERE CCode = '$ccode1' AND session = '$session1'";
                                                    } else {
                                                        $dbsession = str_replace("/", "_", $session);
                                                        $sql = "SELECT Regn1, name1, CCode, CTitle, CUnit, SemTaken, session FROM courses_register_" . $dbsession . " WHERE CCode= '$course' AND session= '$session' ORDER BY Regn1";
                                                        //$sql = "SELECT * FROM courses_register_".$dbsession." WHERE CCode = '$ccode1'";
                                                    }

                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;

                                                            echo "<tr><td>$sno</td><td>{$row['Regn1']}</td><td>{$row['name1']}</td><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['session']}</td></tr>\n";
                                                        }
                                                    }
                                                    ?>
                                            </tbody>
                                        </table>
                                        <?php } ?>

                                        <?php
                                        if (isset($_POST["viewStu"]) || isset($_POST["viewStuLevel"])) {

                                        ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                            rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>

                                                    <th>SNo</th>
                                                    <th>Matric No</th>
                                                    <th>Name</th>
                                                    <th>Level</th>
                                                    <th>State of Origin</th>
                                                    <th>LGA</th>
                                                    <th>Department</th>
                                                    <th>Validation(Level Adviser)</th>
                                                    <th>Validation(HOD)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $statefull2 = strtoupper($statefull);
                                                    //if ($cat_Sub_Admin == "YES" || $cat_Administrator == "YES") {
                                                        $sql3 = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptCode";
                                                        $result3 = $conn->query($sql3);
                                                        if ($result3->num_rows > 0) {
                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                $deptName = $row3["DeptName"];
                                                                $dept_db = $_SESSION['deptdb'] . strtolower($row3["DeptCode"]);
                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                if ($conn_stu->connect_error) {
                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                }


                                                                if (isset($_POST["viewStu"])) {
                                                                    $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND (stateorigin = '$state' OR stateorigin = '$statefull2') ORDER BY matricno";
                                                                } elseif (isset($_POST["viewStuLevel"])) {
                                                                    $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND StuLevel = '$level' ORDER BY matricno";
                                                                }
                                                                $result = $conn_stu->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $sno++;
                                                                        if ($_SESSION['InstType'] == "University") {
                                                                            echo "<tr><td>$sno</td><td>{$row['matricno']}</td><td>{$row['name1']}</td><td>{$row['StuLevel']}</td><td>{$row['stateorigin']}</td><td>{$row['lga']}</td><td>$deptName</td><td>{$row['LevelAdvice']}</td><td>{$row['HOD']}</td></tr>\n";
                                                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                                            if ($row["StuLevel"] == 100) {
                                                                                $stulevel2 = "ND I";
                                                                            } elseif ($row["StuLevel"] == 200) {
                                                                                $stulevel2 = "ND II";
                                                                            } elseif ($row["StuLevel"] == 300) {
                                                                                $stulevel2 = "HND I";
                                                                            } elseif ($row["StuLevel"] == 400) {
                                                                                $stulevel2 = "HND II";
                                                                            }
                                                                            echo "<tr><td>$sno</td><td>{$row['matricno']}</td><td>{$row['name1']}</td><td>$stulevel2</td><td>{$row['stateorigin']}</td><td>{$row['lga']}</td><td>$deptName</td><td>{$row['LevelAdvice']}</td><td>{$row['HOD']}</td></tr>\n";
                                                                        } else {
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    /* } else {
                                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                        if ($conn_stu->connect_error) {
                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                        }
                                                        if (isset($_POST["viewStu"])) {
                                                            $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND (stateorigin = '$state' OR stateorigin = '$statefull2') ORDER BY matricno";
                                                        } elseif (isset($_POST["viewStuLevel"])) {
                                                            $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND StuLevel = '$level' ORDER BY matricno";
                                                        }
                                                        $result = $conn_stu->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                if ($_SESSION['InstType'] == "University") {
                                                                    echo "<tr><td>$sno</td><td>{$row['matricno']}</td><td>{$row['name1']}</td><td>{$row['StuLevel']}</td><td>{$row['stateorigin']}</td><td>{$row['lga']}</td><td>$deptname</td></tr>\n";
                                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                                    if ($row["StuLevel"] == 100) {
                                                                        $stulevel2 = "ND I";
                                                                    } elseif ($row["StuLevel"] == 200) {
                                                                        $stulevel2 = "ND II";
                                                                    } elseif ($row["StuLevel"] == 300) {
                                                                        $stulevel2 = "HND I";
                                                                    } elseif ($row["StuLevel"] == 400) {
                                                                        $stulevel2 = "HND II";
                                                                    }
                                                                    echo "<tr><td>$sno</td><td>{$row['matricno']}</td><td>{$row['name1']}</td><td>$stulevel2</td><td>{$row['stateorigin']}</td><td>{$row['lga']}</td><td>$deptname</td></tr>\n";
                                                                } else {
                                                                }
                                                            }
                                                        }
                                                    } */



                                                    ?>
                                            </tbody>
                                        </table>
                                        <?php } ?>
                                        <br>
                                        <div style="text-align: right">
                                            <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                                class="btn btn-primary">Download</a>
                                        </div>


                                    </div>
                                    <div class="col-lg-1">

                                    </div>


                                </div>

                            </div>

                        </div>
                    </div>



                </div>
                <?php
                $conn->close();
                $conn2->close();
                ?>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>



</body>

</html>
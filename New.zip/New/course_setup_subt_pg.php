<?php
require_once 'includes/db_connect.php';

require_once 'includes/check_validity.php';

if ($_SESSION['pg_course_setup'] == false) {
    header('Location: Home_Staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Setup</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>
                            <li>
                                Courses Setup
                            </li>
                            <li class="active">
                                <strong>Submit</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php $_SESSION['loadformval'] = "YES"; ?>
                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Setup
                        </div>
                        <div class="panel-body">
                            <div>
                                <h2 style="color:#00C"><strong>
                                        <center>Record Saved</center>
                                    </strong></h2>
                                <?php

                                //$curtsession = $_SESSION['corntsession'];
                                $dept = $_SESSION['deptcode'];

                                if (!empty($_POST["chosen"])) {
                                    foreach ($_POST["chosen"] as $key => $value) {

                                        //echo $_POST["chosen"][$key];


                                        $ccode = $_POST["ccode"][$key];
                                        $CTitle = str_replace("'", "''", $_POST["CTitle"][$key]);
                                        $CUnit = $_POST["CUnit"][$key];
                                        $SemTaken = $_POST["SemTaken"][$key];
                                        $nature = $_POST["Nature"][$key];


                                        $sql = "SELECT * FROM deptcourses WHERE CCode = '$ccode' AND dept = '$dept'";
                                        $result = $conn5->query($sql);

                                        if ($result->num_rows == 0) {

                                            $sql2 = "INSERT INTO deptcourses (CCode, CTitle, CUnit, SemTaken, Nature, dept) VALUES ('$ccode', '$CTitle', '$CUnit', '$SemTaken', '$nature', '$dept')";
                                            $result = $conn5->query($sql2);
                                        }
                                    }
                                }

                                $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' ORDER BY CCode";
                                $result = $conn5->query($sql);

                                if ($result->num_rows > 0) {
                                ?>
                                    <table class="table mb-none">
                                        <thead>
                                            <tr>
                                                <th>Course Code</th>
                                                <th>Course Title</th>
                                                <th>Unit</th>
                                                <th>Semester</th>
                                                <th>Nature</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // output data of each row
                                            while ($row = $result->fetch_assoc()) {
                                                $id = $row["id"];
                                                $ccode = $row["CCode"];
                                                $CTitle = $row["CTitle"];
                                                $CUnit = $row["CUnit"];
                                                $SemTaken = $row["SemTaken"];
                                                $Nature = $row["Nature"];

                                                echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td></tr>\n";
                                            }
                                            ?>
                                        </tbody>
                                    </table>

                                <?php
                                }
                                //$conn->close();		
                                ?>

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>


</body>

</html>
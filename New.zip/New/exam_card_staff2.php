<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';


if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: Home_Staff.php');
}
?>



<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Print Div-->
    <script type="text/javascript">
        function printDiv(div_id) {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var content_vlue = document.getElementById(div_id).innerHTML;

            var docprint = window.open("", "", disp_setting);

            ///// Enable Bootstrap CSS
            //// Can also add customise CSS
            docprint.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
            );
            docprint.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Exam Card</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_stu.php">Home</a>
                        </li>

                        <li class="active">
                            <strong>Exam Card</strong>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper wrapper-content animated fadeInUp">

                        <div class="ibox">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10 panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                                <div class="panel-heading">
                                    Exam Card

                                </div>
                                <div class="panel-body">
                                    <div>
                                        <form class="form-horizontal form-bordered" method="post">
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label">Matric Number: </label>
                                                <div class="col-lg-5">
                                                    <input type="text" class="form-control" style="color:#000000" name="regid">
                                                </div>
                                                <div class="col-lg-3">
                                                    <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <br><br>
                                    <?php if (isset($_POST["submit"])) { ?>
                                        <div id="printableArea">
                                            <?php

                                            $corntsession = $_SESSION['corntsession'];
                                            $cursemester = $_SESSION['cursemester'];
                                            $tot1stoutunit = $tot2ndoutunit = 0;

                                            $regid = $_POST["regid"];
                                            $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                            $result = $conn2->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $dept = $row["dept_code"];
                                                    $programme = $row["programme"];
                                                    $cat_class_degree = $row["cat_class_degree"];
                                                    $stdid = $row["stdid"];
                                                }
                                            }


                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }

                                            $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession'  AND matricno = '$regid'";
                                            $result = $conn_stu->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $stuname = $row["name1"];
                                                    $stulevel = $row["StuLevel"];
                                                    $leveladv = $row["LevelAdvice"];
                                                    $HOD = $row["HOD"];
                                                    $Dean = $row["Dean"];
                                                    $Registrar = $row["Registrar"];
                                                    $LAName = $row["LAName"];
                                                    $HODName = $row["HODName"];
                                                }
                                            }

                                            $sql = "SELECT * FROM std_login WHERE stdid = '$stdid'";
                                            $result = $conn2->query($sql);
                                            if ($result->num_rows > 0) {
                                                $passportid = $stdid;
                                            } else {
                                                $passportid = $regid;
                                            }

                                            ?>
                                            <div style="text-align: center;"><img src="img/logo.ico" height="100" alt="logo" /></div>
                                            <?php
                                            if ($cursemester == "1ST") {
                                                $getSem = "1<sup>st</sup>";
                                            } else {
                                                $getSem = "2<sup>nd</sup>";
                                            }
                                            ?>
                                            <h1 style="text-align: center; color:black"><?php echo $_SESSION['instname'] ?>
                                            </h1>
                                            <h1 style="text-align: center; color:black">EXAMINATION CARD</h1>
                                            <h2 style='text-align:center; color:black'><?php echo $getSem ?> Semester
                                                <?php echo $corntsession ?> Session</h2>


                                            <table style="width: 97%">
                                                <tr>
                                                    <td><?php echo "Matric No: " . $regid; ?><br><?php echo "Name:  " . $stuname; ?><br><?php echo "Programme:  " . $cat_class_degree . " " . $programme; ?><br><?php echo "Level:  " . $stulevel; ?>
                                                    </td>
                                                    <td style="text-align:right">
                                                        <?php

                                                        $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                        $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                                        echo "<img alt=''  class='' src='$stu_pic_folder/$passptfile' width='100' height='100'>";
                                                        ?>
                                                    </td>
                                                </tr>
                                            </table>

                                            <?php
                                            $curtsession2 = str_replace("/", "_", $corntsession);
                                            $sql = "SELECT * FROM courses_register_" . $curtsession2 . " WHERE Regn1 = '$regid' AND SemTaken = '$cursemester'";
                                            $result = $conn->query($sql);

                                            if ($result->num_rows > 0) {

                                            ?>

                                                <table class="table table-bordered" cellspacing="0" rules="all" border="1" style="width: 97%">
                                                    <thead>
                                                        <tr>
                                                            <th style="padding-left: 1em;">Course Code</th>
                                                            <th>Course Title</th>
                                                            <th>Unit</th>
                                                            <th>Sign & Date by Invigilator</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["sn"];
                                                            $ccode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $Nature = $row["Nature"];

                                                            $tot1stoutunit += $row['CUnit'];


                                                            echo "<tr><td style='padding-left: 1em;'>{$row['CCode']}</td><td style='padding-left: 1em;'>{$row['CTitle']}</td><td style='padding-left: 1em;'>{$row['CUnit']}</td><td></td></tr>\n";
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>

                                            <?php

                                            }

                                            ?>

                                            <br><br>

                                            <div style="text-align: center;">
                                                _____________________________________<br>HOD's Sign and
                                                Stamp
                                            </div>



                                        </div>
                                        <br><br>
                                        <div style="text-align: right">
                                            <?php if ($leveladv == "Validate") { ?>
                                                <input type="button" onclick="printDiv('printableArea')" value="print" class="btn-success" />
                                            <?php } ?>
                                        </div>
                                    <?php } ?>
                                    <br /><br />
                                </div>
                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
<?php
require_once 'includes/db_connect.php';
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>School Portal</title>
    <link rel="shortcut icon" href="img/logo.ico">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">



    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 style="text-align: center;">Password Reset</h3>
                </div>
                <div class="panel-body">
                    <?php
                    if (isset($_POST["submit"])) {
                        $regid = $_POST["regid"];
                        $otp = $_POST["otp"];
                        $password = $_POST["password"];
                        $confirmpassword = $_POST["confirmpwd"];
                        $success = false;
                        $otp = stripslashes($otp);
                        $otp = mysqli_real_escape_string($conn2, $otp);
                        $regid = stripslashes($regid);
                        $regid = mysqli_real_escape_string($conn2, $regid);

                        $sql = "SELECT * FROM std_login WHERE stdid = '$regid'";
                        $result = $conn2->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $otp_db = $row["pwd_reset_token"];
                            }

                            $password = stripslashes($password);
                            $password = mysqli_real_escape_string($conn, $password);

                            $confirmpassword = stripslashes($confirmpassword);
                            $confirmpassword = mysqli_real_escape_string($conn, $confirmpassword);
                            if ($otp == $otp_db && $otp > 0) {
                                if (strlen($password) >= 6) {
                                    if ($password == $confirmpassword) {
                                        $password = md5($password);
                                        $sql = "UPDATE std_login SET password='$password', pwd_reset_token = 0 WHERE stdid = '$regid'";
                                        $result = $conn2->query($sql);

                                        echo "<h3 class='alert alert-danger' style='color:blue; text-align: center'>Password saved successfully<br>
                                        <a href= 'index.php' class='btn btn-primary'>Back to Login</a></h3>";
                                        $success = true;
                                    } else {
                                        echo "<h3 class='alert alert-danger' style='color: red; text-align: center'>Error: Password and confirmation must match exactly</h3>";
                                    }
                                } else {
                                    echo "<h3 class='alert alert-danger' style='color: red; text-align: center'>Error: Passwords must be at least 6 characters long</h3>";
                                }
                            } else {
                                echo "<h3 class='alert alert-danger' style='color: red; text-align: center'>Error: Wrong OTP Number</h3>";
                            }
                        } else {
                            echo "<h3 class='alert alert-danger' style='color: red; text-align: center'>Error: Wrong Matric Number</h3>";
                        }
                    }
                    ?>
                    <?php if ($success == false) { ?>
                        <form class="form-horizontal" role="form" method="post" action="">

                            <div class="form-group">
                                <label class="col-lg-4 control-label">Matric Number</label>
                                <div class="col-lg-8">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-file-text-o"></i></span>

                                        <input type="text" name="regid" id="regid" class="form-control" placeholder="File Number">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">OTP Number</label>
                                <div class="col-lg-8">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-key"></i></span>

                                        <input type="number" name="otp" id="otp" class="form-control" placeholder="OTP Number">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">New Password</label>
                                <div class="col-lg-8">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>

                                        <input type="password" name="password" id="password" class="form-control" placeholder="New Password">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Confirm Password</label>
                                <div class="col-lg-8">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock"></i></i></span>
                                        <input type="password" name="confirmpwd" id="confirmpwd" class="form-control" placeholder="Confirm Password">
                                    </div>

                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label"></label>
                                <div class="col-lg-8">
                                    <div class="input-group" style="text-align: right;">
                                        <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                    </div>

                                </div>
                            </div>


                        </form>
                    <?php } ?>
                </div>
            </div>

        </div>
        <div class="col-lg-2">

        </div>

    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
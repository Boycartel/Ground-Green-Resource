<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?> Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword"
        content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
        <form class="form-horizontal form-bordered" method="post">

            <div class="row">
                <h2 class="panel-title" style="text-align: center">Set Students' Status</h2>
                <br><br><br>

                <div class="col-lg-3">
                    <div class="row">
                        <label class="control-label col-lg-5" for="getyearadmt">Year Admitted:</label>
                        <div class="col-lg-7">
                            <?php
                            $iniyear = 2015;
                            $finalyear = substr($_SESSION['corntsession'], 5);

                            ?>
                            <select name="getyearadmt" class="form-control" style="color:#000000" id="getyearadmt">
                                <option value="<?php echo $finalyear ?>"><?php echo $finalyear ?></option>
                                <?php
                                while ($iniyear <= $finalyear) {
                                    $addyear = $iniyear + 1;

                                    echo "<option value = '$iniyear'>$iniyear</option>";
                                    $iniyear++;
                                }

                                ?>


                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                    <div class="row">
                        <label class="control-label col-lg-5" for="getprogram">Programme:</label>
                        <div class="col-lg-7">

                            <select name="getprogram" class="form-control" style="color:#000000" id="getprogram"
                                required>
                                <option value="">Select Item</option>
                                <option value="ND">ND</option>
                                <option value="HND">HND</option>
                            </select>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                <div class="col-lg-4">
                    <?php if ($_SESSION['deptoption'] == "YES") { ?>
                    <div class="row">
                        <label class="control-label col-lg-5" for="getopt">Departmental Option:</label>
                        <div class="col-lg-7">

                            <select name="getopt" class="form-control" style="color:#000000" id="getopt" required>
                                <option value="">Select Item</option>
                                <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }
                                    $dept = strtolower($_SESSION['deptcode']);
                                    $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept' ORDER BY Opt_Title";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $Opt_Code = $row["Opt_Code"];
                                            $Opt_Title = $row["Opt_Title"];
                                            echo "<option value='$Opt_Code'>$Opt_Title</option>";
                                        }
                                    }
                                    $conn->close();
                                    ?>

                            </select>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                <div class="col-lg-2">
                    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                </div>

            </div>
        </form>
        <hr class="separator" />
    </div>

    <div style="padding-left:3em; padding-right: 3em">

        <?php if (isset($_POST["submit"])) { ?>
        <?php
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
            if ($conn2->connect_error) {
                die("Connection failed: " . $conn2->connect_error);
            }

            $yearadmtd = $_POST["getyearadmt"];
            if ($_SESSION['InstType'] == "Polytechnic") {
                $getprogram = $_POST["getprogram"];
                $_SESSION['getprogram'] = $getprogram;
            }
            $cursession = $_SESSION['resultsession'];
            $resultsemester = $_SESSION['resultsemester'];
            $dept = $_SESSION['deptcode'];
            $_SESSION['yearadmtd'] = $yearadmtd;
            $getopt = $_POST["getopt"];
            $_SESSION['getopt'] = $getopt;
            ?>

        <div class="panel-body">

            <br>
            <div class="col-lg-12 table-responsive">

                <table class="table table-striped table-bordered">
                    <thead style='text-align:center'>
                        <tr>
                            <th>S/No</th>
                            <th>Matric_No</th>
                            <th>Name</th>
                            <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                            <th>Programme</th>
                            <?php } ?>
                            <?php if ($_SESSION['deptoption'] == "YES") { ?>
                            <th>Departmental Option</th>
                            <?php } ?>
                            <th>Year Admitted</th>
                            <th>Student Status</th>
                            <th>Student Group</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $sno = 0;
                            if ($_SESSION['deptoption'] == "YES") {
                                if ($_SESSION['InstType'] == "University") {
                                    $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND YAddmitted = '$yearadmtd' AND Dept_Option = '$getopt' ORDER BY matric_no";
                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                    $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND YAddmitted = '$yearadmtd' AND modeofentry = '$getprogram' AND Dept_Option = '$getopt' ORDER BY matric_no";
                                }
                            } else {
                                if ($_SESSION['InstType'] == "University") {
                                    $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND YAddmitted = '$yearadmtd' ORDER BY matric_no";
                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                    $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND YAddmitted = '$yearadmtd' AND modeofentry = '$getprogram' ORDER BY matric_no";
                                }
                            }


                            $result = $conn2->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $sno++;
                                    $regid = $row["matric_no"];
                                    $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                    if ($_SESSION['deptoption'] == "YES") {
                                        $Dept_Option = $row['Dept_Option'];
                                        $sql2 = "SELECT * FROM dept_option WHERE deptcode = '$dept' AND Opt_Code = '$Dept_Option'";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $Opt_Title = $row2["Opt_Title"];
                                            }
                                        }
                                    }
                                    /* if ($row["status"] == 6) {
                                        $status = "In Session";
                                    } elseif ($row["status"] == 8) {
                                        $status = "Suspended";
                                    } elseif ($row["status"] == 9) {
                                        $status = "Deferment";
                                    } elseif ($row["status"] == 10) {
                                        $status = "Overstayed";
                                    } elseif ($row["status"] == 11) {
                                        $status = "Expulsion";
                                    } elseif ($row["status"] == 12) {
                                        $status = "Graduated";
                                    } elseif ($row["status"] == 14) {
                                        $status = "Withdrawn";
                                    } elseif ($row["status"] == 15) {
                                        $status = "Dead";
                                    } */

                                    echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$regid </td><td> $names</td>";
                                    if ($_SESSION['InstType'] == "Polytechnic") {
                                        $modeofentry = $row['modeofentry'];
                                        echo "<td>$modeofentry</td>";
                                    }
                                    if ($_SESSION['deptoption'] == "YES") {
                                        echo "<td>$Opt_Title</td>";
                                    }
                                    echo '<td><a href="#" class="YAddmitted" id="YAddmitted_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_stu_status.php" data-name="YAddmitted">' . $row["YAddmitted"] . '</a></td>';
                                    echo '<td><a href="#" class="status" id="status_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_stu_status.php" data-name="status">' . $row["status"] . '</a></td>';
                                    echo '<td><a href="#" class="stu_group" id="stu_group_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_stu_status.php" data-name="stu_group">' . $row["stu_group"] . '</a></td>';
                                    /* if ($_SESSION['deptoption'] == "YES") {
                                        echo '<td><a href="#" class="Dept_Option" id="Dept_Option_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_stu_status.php" data-name="Dept_Option">' . $row["Dept_Option"] . '</a></td>';
                                    } */

                                    echo "</tr>\n";
                                }
                            }

                            ?>
                    </tbody>
                </table>
            </div>

        </div>
        <?php
            $conn->close();
            $conn2->close();
            ?>
        <?php } ?>

    </div>



    <script>
    //For Year Admitted Table column Data

    const YAddmitted = document.getElementsByClassName('YAddmitted');

    for (var count1 = 0; count1 < YAddmitted.length; count1++) {
        const YAddmitted_data = document.getElementById(YAddmitted[count1].getAttribute("id"));

        const YAddmitted_popover = new DarkEditable(YAddmitted_data, {
            source: [
                <?php $yearadmtd = $_SESSION['yearadmtd']; ?>

                <?php
                    for ($x = -2; $x <= 2; $x++) {
                        $addyear = $yearadmtd + $x;
                    ?> {
                    value: '<?php echo $addyear ?>',
                    text: '<?php echo $addyear ?>'
                },
                <?php

                    }

                    ?>
            ]
        });
    }

    //For Students Status Table column Data

    const status = document.getElementsByClassName('status');

    for (var count2 = 0; count2 < status.length; count2++) {
        const status_data = document.getElementById(status[count2].getAttribute("id"));

        const status_popover = new DarkEditable(status_data, {
            source: [

                {
                    value: '5',
                    text: 'Admission Clearance(Cleared)'
                },
                {
                    value: '6',
                    text: 'In Session'
                }, {
                    value: '8',
                    text: 'Suspended'
                }, {
                    value: '9',
                    text: 'Deferment'
                }, {
                    value: '10',
                    text: 'Overstayed'
                }, {
                    value: '11',
                    text: 'Expulsion'
                }, {
                    value: '12',
                    text: 'Graduated'
                }, {
                    value: '14',
                    text: 'Withdrawn'
                }, {
                    value: '15',
                    text: 'Dead'
                }
            ]
        });
    }

    //For Student Group Table column Data

    const stu_group = document.getElementsByClassName('stu_group');

    for (var count3 = 0; count3 < stu_group.length; count3++) {
        const stu_group_data = document.getElementById(stu_group[count3].getAttribute("id"));

        const stu_group_popover = new DarkEditable(stu_group_data, {
            source: [
                <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $getprogram = $_SESSION['getprogram'];
                    $sql = "SELECT * FROM dept_stu_group WHERE deptcode = '$dept' AND prog = '$getprogram'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $group_Code = $row["group_Code"];
                            $group_Title = $row["group_Title"];
                    ?> {
                    value: '<?php echo $group_Code ?>',
                    text: '<?php echo $group_Title ?>'
                },
                <?php
                        }
                    }
                    $conn->close();

                    ?>

            ]
        });
    }
    </script>
</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

$dept = $_SESSION['deptcode'];

/* $sql = "SELECT * FROM " . $dept . "_library";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    header('Location: home_stu.php');
} */
?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Department's Library</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Department's Library</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Department's Library
                        </div>
                        <div class="panel-body">
                            <?php
                            //if (strtoupper($dept) == "STA") {
                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                            if ($conn_stu->connect_error) {
                                die("Connection failed: " . $conn_stu->connect_error);
                            }

                            $sql = "SELECT * FROM library";
                            $result = $conn_stu->query($sql);

                            if ($result->num_rows > 0) {
                                // output data of each row
                            ?>
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th>id</th>
                                            <th>Book Title</th>
                                            <th>Author</th>
                                            <th>Publisher</th>
                                            <th></th>

                                        </tr>
                                    </thead>
                                    <tbody>


                                    <?php
                                    while ($row = $result->fetch_assoc()) {
                                        $id = $row["id"];
                                        echo "<tr><td>$id</td><td>{$row['booktitle']}</td><td>{$row['author']}</td><td>{$row['publisher']}</td>
												<td>
												<form action='stu_library_view.php' method='post'>
													  <input type='hidden' value=$id name='id'>
													  <input type='submit' class='btn btn-success btn-xs' value='View Detail'>
												 </form>
												</td>
												</tr>\n";
                                    }
                                }
                                //}
                                $conn_stu->close();
                                    ?>
                                    </tbody>
                                </table>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect.php';
//require_once 'includes/check_validity.php';


?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Print Div-->
    <script type="text/javascript">
    function printme() {
        var print_div = document.getElementById("printablediv");
        var print_area = window.open();
        print_area.document.write(print_div.innerHTML);
        print_area.document.close();
        print_area.focus();
        print_area.print();
        print_area.close();
    }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php
            if ($_SESSION['usertype'] == "Student") {
                $stutype = $_SESSION['stutype'];
                if ($stutype == "UG") {
                    include_once 'includes/aside_menu.php';
                } else {
                    include_once 'includes/pg_aside_menu.php';
                }
            } else {

                include_once 'includes/aside_menu_staff.php';
            }

            ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php

                    if ($_SESSION['usertype'] == "Student") {
                        $stutype = $_SESSION['stutype'];
                        if ($stutype == "UG") {
                            include_once 'includes/header2.php';
                        } else {
                            include_once 'includes/header2_pg.php';
                        }
                    } else {

                        include_once 'includes/header2_staff.php';
                    }

                    ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Missing Session</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Missing Session
                            </li>

                            <li class="active">
                                <strong>Letter</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Missing Session Letter
                        </div>
                        <div class="panel-body">
                            <strong>
                                <h3 style="text-align: center"><?php echo $_SESSION['instname'] ?><br>(Registry
                                    Department
                                    - Academic Office)</h3>
                            </strong>

                            <center><img alt='' src='img/logo.ico' width='100' height='100'></center>
                            <br />

                            <?php
                            if (isset($_GET['id2']) && $_GET['id2'] !== '') {
                                $id = $_GET['id2'];
                            }
                            $_SESSION['id'] =  $id;


                            //$dept = $_SESSION["deptname"];
                            //$school = $_SESSION['schname'];
                            $sql = "SELECT * FROM missing_session WHERE id = '$id'";
                            $result = $conn->query($sql);
                            $countmis = 0;
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $matno = strtoupper($row["matno"]);
                                    $name1 = $row["name1"];
                                    $officername = $row["officername"];
                                    $officersch = $row["schcode"];
                                    $response = $row["response"];
                                    $semester = $row["semester"];
                                    $session = $row["session"];
                                    $getdate = $row["date1"];
                                    $deptcode =  $row["deptcode"];
                                    $coments =  $row["coment"];
                                    $senateno =  $row["senateno"];
                                    $approval =  $row["approval"];
                                    $officerno =  $row["officerno"];
                                    $stulevel = $row["stulevel"];
                                }
                            }

                            $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$deptcode'";
                            $result = $conn->query($sql);
                            $countmis = 0;
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $dept = $row["DeptName"];
                                }
                            }
                            $sql = "SELECT * FROM schoolname WHERE SchCode = '$officersch'";
                            $result = $conn->query($sql);
                            $countmis = 0;
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $school = $row["SchName"];
                                }
                            }

                            $senatedate = date("Y/m/d");
                            $sql = "SELECT * FROM miss_session_senateno WHERE senateno = '$senateno'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $senatedate = $row["senatedate"];
                                }
                            }

                            $day1 = date_format(date_create($senatedate), "j");
                            //$day1ldig =substr($day1,-1);
                            //$day1ldig = (int)$day1ldig;
                            if ($day1 == 1 || $day1 == 21 || $day1 == 31) {
                                $dayordinal = "st";
                            } else if ($day1 == 2 || $day1 == 22) {
                                $dayordinal = "nd";
                            } else if ($day1 == 3 || $day1 == 23) {
                                $dayordinal = "rd";
                            } else {
                                $dayordinal = "th";
                            }

                            $fulsenatedate = date_format(date_create($senatedate), "l") . ", " . date_format(date_create($senatedate), "j") . "<sup>" . $dayordinal . "</sup> " . date_format(date_create($senatedate), "F") . ", " . date_format(date_create($senatedate), "Y");

                            $senatenoldig = substr($senateno, -1);
                            $senatenoldig = (int)$senatenoldig;
                            if ($senatenoldig == 1) {
                                $senateordinal = "st";
                            } else if ($senatenoldig == 2) {
                                $senateordinal = "nd";
                            } else if ($senatenoldig == 3) {
                                $senateordinal = "rd";
                            } else {
                                $senateordinal = "th";
                            }



                            if ($response == "Deferment") {
                                $response_full = "DEFERMENT";
                            } else if ($response == "Condonation") {
                                $response_full = "CONDONATION";
                            } else if ($response == "Suspension") {
                                $response_full = "Suspension";
                            } else if ($response == "Expulsion") {
                                $response_full = "Expulsion";
                            } else if ($response == "VolWithdrawal") {
                                $response_full = "Voluntary Withdrawal";
                            } else if ($response == "PoorWithdrawal") {
                                $response_full = "Withdrawal(Poor Acad Performance)";
                            } else if ($response == "Notification_illhealth") {
                                $response_full = "Notification of ill-health";
                            } else if ($response == "recall_susp") {
                                $response_full = "Recall from Suspension";
                            } else if ($response == "recall_expul") {
                                $response_full = "Recall from Expulsion";
                            }

                            if ($approval == "Approve") {
                                $approval_ful = "and approved";
                            } else {
                                $approval_ful = "but did not approve";
                            }
                            $sessionnext = substr($session, 5, 4);
                            $sessionnext2 = $sessionnext + 1;
                            $nextsession = $sessionnext . "/" . $sessionnext2;

                            if ($semester == "1ST") {
                                $semester = "FIRST";
                                $nextsem = "Second";
                                $nextses = $session;
                                $notapprovsem = "1ST";
                            } else if ($semester == "2ND") {
                                $semester = "SECOND";
                                $nextsem = "First";
                                $nextses = $nextsession;
                                $notapprovsem = "2ND";
                            } else {
                                $semester = "FIRST AND SECOND";
                                $nextsem = "First";
                                $nextses = $nextsession;
                                $notapprovsem = "1ST";
                            }
                            ?>
                            <p style="text-align:right"><?php echo date_format(date_create($getdate), "d F, Y") ?>
                            </p>
                            <br />
                            <p style="text-align:left">
                                <strong><?php echo $name1 . " (" . $matno . ") " . $stulevel . "L" ?></strong><br /><?php echo "Department of " . $dept . "," ?><br /><?php echo "School of " . $school . "," ?><br />Nigerian
                                Army University,<br />Minna
                            </p>
                            <?php if ($response == "Deferment" || $response == "Condonation") { ?>
                            <h3><strong>RE: APPLICATION FOR <?php echo $response_full ?> OF <?php echo $semester ?>
                                    SEMESTER <?php echo $session ?> ACADEMIC SESSION</strong></h3>
                            <?php if ($approval == "Approve") { ?>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting
                                held on <?php echo $fulsenatedate ?> considered <?php echo $approval_ful ?> your
                                <?php echo strtolower($response_full) ?> of <?php echo strtolower($semester) ?>
                                semester <?php echo $session ?> academic session.</p>
                            <?php } else { ?>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting
                                held on <?php echo $fulsenatedate ?> considered but did not approve your
                                <?php echo strtolower($response_full) ?> of <?php echo strtolower($semester) ?>
                                semester <?php echo $session ?> academic session.</p>
                            <?php } ?>

                            <?php } else if ($response == "Suspension") { ?>
                            <h3><strong>SUSPENSION OF <?php echo $semester ?> SEMESTER <?php echo $session ?>
                                    ACADEMIC SESSION</strong></h3>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting
                                held on <?php echo $fulsenatedate ?> considered and approved your
                                <?php echo strtolower($response_full) ?> of <?php echo strtolower($semester) ?>
                                semester <?php echo $session ?> academic session.</p>
                            <?php } else if ($response == "Expulsion") { ?>
                            <h3><strong>EXPULSION FROM UNIVERSITY</strong></h3>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting
                                held on <?php echo $fulsenatedate ?> considered and approved your expulsion from the
                                University.</p>
                            <?php } else if ($response == "VolWithdrawal") { ?>
                            <h3><strong>VOLUNTARY WITHDRAWAL FROM UNIVERSITY</strong></h3>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting
                                held on <?php echo $fulsenatedate ?> observed that you were absent from the
                                University for two consecutive sessions without official permission and you did not
                                registered for those sessions.</p>
                            <p>By the University policy, you have voluntarily withdrawn yourself fron the University
                                by this action.</p>
                            <p>Senate therefore, approved your voluntary withdrawal from the University.</p>
                            <p>Please, handover immediatly any University property in your posession including the
                                student's identification(ID) card to the Dean of Students.</p>
                            <p>Wishing you goodluck in your future endeavour.</p>
                            <?php } else if ($response == "PoorWithdrawal") { ?>
                            <h3><strong>WITHDRAWAL FROM THE UNIVERSITY</strong></h3>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting
                                held on <?php echo $fulsenatedate ?> consider among others, your examination results
                                for the <?php echo $session ?> session from the School of <?php echo $school ?>.</p>
                            <p>Senate observed your poor academic performance which resulted into your placement on
                                probation for two consecutive sessions.</p>
                            <p>Consequently, senate approved your withdrawal from the University with immediate
                                effect.</p>
                            <p>Please, handover immediatly any University property in your posession including the
                                student's identification(ID) card to the Dean of Students.</p>
                            <p>Wishing you goodluck in your future endeavour.</p>
                            <?php } else if ($response == "Notification_illhealth") { ?>
                            <h3><strong>RE: NOTIFICATION OF ILL-HEALTH</strong></h3>
                            <?php
                                if ($approval == "Approve") {
                                    $approval_ful = "and aknowledged";
                                }
                                ?>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting
                                held on <?php echo $fulsenatedate ?> considered <?php echo $approval_ful ?> your
                                notification of ill-health.</p>
                            <?php } else if ($response == "recall_susp") { ?>
                            <h3><strong>RECALL FROM SUSPENSION</strong></h3>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting
                                held on <?php echo $fulsenatedate ?> considered and approved your recall from
                                suspension.</p>
                            <?php } else if ($response == "recall_expul") { ?>
                            <h3><strong>RECALL FROM EXPULSION</strong></h3>
                            <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?> meeting held
                                    on <?php echo $fulsenatedate ?> considered and approved your recall from
                                    expulsion.</p>
                            <?php } ?>


                            <p><?php echo $coments ?></p>


                            <?php if ($response == "Deferment" || $response == "Condonation") { ?>

                            <?php if ($approval == "Approve") { ?>
                            <p>You are expected to resume your normal academic activities during the
                                <?php echo $nextsem ?> semester <?php echo $nextses ?> academic session.</p>
                            <?php } else { ?>
                            <p>You are expected to resume your normal academic activities during the
                                <?php echo $notapprovsem ?> semester <?php echo $session ?> academic session.</p>
                            <?php } ?>

                            <?php } else if ($response == "Notification_illhealth") { ?>
                            <p>Note that as soon as you are fit to resume normal academic activities, you are to
                                present a certificate of medical fitness and an application for condonation of the
                                period of illness.</p>
                            <p>Wishing you quick recovery.</p>
                            <?php } else if ($response == "recall_susp" || $response == "recall_expul") { ?>
                            <p>You are expected to resume your normal academic activities immediately.</p>
                            <?php } ?>

                            <?php if ($response == "Deferment") { ?>
                            <p>Note that deferment counts towards your graduation.</p>
                            <?php } ?>
                            <p></p>
                            <br />
                            <p>Thank you.</p>
                            <p></p>
                            <img alt='' src='img/signature/<?php echo $officerno ?>.PNG' width='80' height='60'>
                            <p><strong><?php echo $officername ?></strong><br />Admin. Officer(Desk Officer,
                                <?php echo $officersch ?>)<br />For: Registrar</p>
                            <br>
                            <div style="text-align: right">
                                <input type="button" class='btn btn-info btn-sm' value="Print" onclick="printme()">
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <!--Print Start-->
    <div id="printablediv" style="width: 100%; height: 200px;" hidden="hidden">
        <strong>
            <h3 style="text-align: center"><?php echo $_SESSION['instname'] ?><br>(Registry Department - Academic
                Office)</h3>
        </strong>
        <center><img alt='' src='img/logo.ico' width='70' height='70'></center>
        <br />

        <?php
        $id = $_SESSION['id'];


        //$dept = $_SESSION["deptname"];
        //$school = $_SESSION['schname'];
        $sql = "SELECT * FROM missing_session WHERE id = '$id'";
        $result = $conn->query($sql);
        $countmis = 0;
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $matno = strtoupper($row["matno"]);
                $name1 = $row["name1"];
                $officername = $row["officername"];
                $officersch = $row["schcode"];
                $response = $row["response"];
                $semester = $row["semester"];
                $session = $row["session"];
                $getdate = $row["date1"];
                $deptcode =  $row["deptcode"];
                $coments =  $row["coment"];
                $senateno =  $row["senateno"];
                $approval =  $row["approval"];
                $officerno =  $row["officerno"];
                $stulevel = $row["stulevel"];
            }
        }

        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$deptcode'";
        $result = $conn->query($sql);
        $countmis = 0;
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $dept = $row["DeptName"];
            }
        }
        $sql = "SELECT * FROM schoolname WHERE SchCode = '$officersch'";
        $result = $conn->query($sql);
        $countmis = 0;
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $school = $row["SchName"];
            }
        }

        $sql = "SELECT * FROM miss_session_senateno WHERE senateno = '$senateno'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $senatedate = $row["senatedate"];
            }
        }

        $day1 = date_format(date_create($senatedate), "j");
        //$day1ldig =substr($day1,-1);
        //$day1ldig = (int)$day1ldig;
        if ($day1 == 1 || $day1 == 21 || $day1 == 31) {
            $dayordinal = "st";
        } else if ($day1 == 2 || $day1 == 22) {
            $dayordinal = "nd";
        } else if ($day1 == 3 || $day1 == 23) {
            $dayordinal = "rd";
        } else {
            $dayordinal = "th";
        }

        $fulsenatedate = date_format(date_create($senatedate), "l") . ", " . date_format(date_create($senatedate), "j") . "<sup>" . $dayordinal . "</sup> " . date_format(date_create($senatedate), "F") . ", " . date_format(date_create($senatedate), "Y");

        $senatenoldig = substr($senateno, -1);
        $senatenoldig = (int)$senatenoldig;
        if ($senatenoldig == 1) {
            $senateordinal = "st";
        } else if ($senatenoldig == 2) {
            $senateordinal = "nd";
        } else if ($senatenoldig == 3) {
            $senateordinal = "rd";
        } else {
            $senateordinal = "th";
        }



        if ($response == "Deferment") {
            $response_full = "DEFERMENT";
        } else if ($response == "Condonation") {
            $response_full = "CONDONATION";
        } else if ($response == "Suspension") {
            $response_full = "Suspension";
        } else if ($response == "Expulsion") {
            $response_full = "Expulsion";
        } else if ($response == "VolWithdrawal") {
            $response_full = "Voluntary Withdrawal";
        } else if ($response == "PoorWithdrawal") {
            $response_full = "Withdrawal(Poor Acad Performance)";
        } else if ($response == "Notification_illhealth") {
            $response_full = "Notification of ill-health";
        } else if ($response == "recall_susp") {
            $response_full = "Recall from Suspension";
        } else if ($response == "recall_expul") {
            $response_full = "Recall from Expulsion";
        }

        if ($approval == "Approve") {
            $approval_ful = "and approved";
        } else {
            $approval_ful = "but did not approve";
        }
        $sessionnext = substr($session, 5, 4);
        $sessionnext2 = $sessionnext + 1;
        $nextsession = $sessionnext . "/" . $sessionnext2;

        if ($semester == "1ST") {
            $semester = "FIRST";
            $nextsem = "Second";
            $nextses = $session;
            $notapprovsem = "1ST";
        } else if ($semester == "2ND") {
            $semester = "SECOND";
            $nextsem = "First";
            $nextses = $nextsession;
            $notapprovsem = "2ND";
        } else {
            $semester = "FIRST AND SECOND";
            $nextsem = "First";
            $nextses = $nextsession;
            $notapprovsem = "1ST";
        }
        ?>
        <p style="text-align:right"><?php echo date_format(date_create($getdate), "d F, Y") ?></p>
        <br />
        <p style="text-align:left">
            <strong><?php echo $name1 . " (" . $matno . ") " . $stulevel . "L" ?></strong><br /><?php echo "Department of " . $dept . "," ?><br /><?php echo "School of " . $school . "," ?><br />Federal
            University of Technology,<br />Minna
        </p>
        <?php if ($response == "Deferment" || $response == "Condonation") { ?>
        <h3><strong>RE: APPLICATION FOR <?php echo $response_full ?> OF <?php echo $semester ?> SEMESTER
                <?php echo $session ?> ACADEMIC SESSION</strong></h3>
        <?php if ($approval == "Approve") { ?>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting held on
            <?php echo $fulsenatedate ?> considered <?php echo $approval_ful ?> your
            <?php echo strtolower($response_full) ?> of <?php echo strtolower($semester) ?> semester
            <?php echo $session ?> academic session.</p>
        <?php } else { ?>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting held on
            <?php echo $fulsenatedate ?> considered but did not approve your <?php echo strtolower($response_full) ?> of
            <?php echo strtolower($semester) ?> semester <?php echo $session ?> academic session.</p>
        <?php } ?>

        <?php } else if ($response == "Suspension") { ?>
        <h3><strong>SUSPENSION OF <?php echo $semester ?> SEMESTER <?php echo $session ?> ACADEMIC SESSION</strong></h3>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting held on
            <?php echo $fulsenatedate ?> considered and approved your <?php echo strtolower($response_full) ?> of
            <?php echo strtolower($semester) ?> semester <?php echo $session ?> academic session.</p>
        <?php } else if ($response == "Expulsion") { ?>
        <h3><strong>EXPULSION FROM UNIVERSITY</strong></h3>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting held on
            <?php echo $fulsenatedate ?> considered and approved your expulsion from the University.</p>
        <?php } else if ($response == "VolWithdrawal") { ?>
        <h3><strong>VOLUNTARY WITHDRAWAL FROM UNIVERSITY</strong></h3>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting held on
            <?php echo $fulsenatedate ?> observed that you were absent from the University for two consecutive sessions
            without official permission and you did not registered for those sessions.</p>
        <p>By the University policy, you have voluntarily withdrawn yourself fron the University by this action.</p>
        <p>Senate therefore, approved your voluntary withdrawal from the University.</p>
        <p>Please, handover immediatly any University property in your posession including the student's
            identification(ID) card to the Dean of Students.</p>
        <p>Wishing you goodluck in your future endeavour.</p>
        <?php } else if ($response == "PoorWithdrawal") { ?>
        <h3><strong>WITHDRAWAL FROM THE UNIVERSITY</strong></h3>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting held on
            <?php echo $fulsenatedate ?> consider among others, your examination results for the <?php echo $session ?>
            session from the School of <?php echo $school ?>.</p>
        <p>Senate observed your poor academic performance which resulted into your placement on probation for two
            consecutive sessions.</p>
        <p>Consequently, senate approved your withdrawal from the University with immediate effect.</p>
        <p>Please, handover immediatly any University property in your posession including the student's
            identification(ID) card to the Dean of Students.</p>
        <p>Wishing you goodluck in your future endeavour.</p>
        <?php } else if ($response == "Notification_illhealth") { ?>
        <h3><strong>RE: NOTIFICATION OF ILL-HEALTH</strong></h3>
        <?php
            if ($approval == "Approve") {
                $approval_ful = "and aknowledged";
            }
            ?>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting held on
            <?php echo $fulsenatedate ?> considered <?php echo $approval_ful ?> your notification of ill-health.</p>
        <?php } else if ($response == "recall_susp") { ?>
        <h3><strong>RECALL FROM SUSPENSION</strong></h3>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?></sup> meeting held on
            <?php echo $fulsenatedate ?> considered and approved your recall from suspension.</p>
        <?php } else if ($response == "recall_expul") { ?>
        <h3><strong>RECALL FROM EXPULSION</strong></h3>
        <p>Senate at its <?php echo $senateno ?><sup><?php echo $senateordinal ?> meeting held on
                <?php echo $fulsenatedate ?> considered and approved your recall from expulsion.</p>
        <?php } ?>


        <p><?php echo $coments ?></p>


        <?php if ($response == "Deferment" || $response == "Condonation") { ?>

        <?php if ($approval == "Approve") { ?>
        <p>You are expected to resume your normal academic activities during the <?php echo $nextsem ?> semester
            <?php echo $nextses ?> academic session.</p>
        <?php } else { ?>
        <p>You are expected to resume your normal academic activities during the <?php echo $notapprovsem ?> semester
            <?php echo $session ?> academic session.</p>
        <?php } ?>

        <?php } else if ($response == "Notification_illhealth") { ?>
        <p>Note that as soon as you are fit to resume normal academic activities, you are to present a certificate of
            medical fitness and an application for condonation of the period of illness.</p>
        <p>Wishing you quick recovery.</p>
        <?php } else if ($response == "recall_susp" || $response == "recall_expul") { ?>
        <p>You are expected to resume your normal academic activities immediately.</p>
        <?php } ?>

        <?php if ($response == "Deferment") { ?>
        <p>Note that deferment counts towards your graduation.</p>
        <?php } ?>
        <p></p>
        <br />
        <p>Thank you.</p>
        <p></p>
        <img alt='' src='img/signature/<?php echo $officerno ?>.PNG' width='80' height='60'>
        <p><strong><?php echo $officername ?></strong><br />Admin. Officer(Desk Officer,
            <?php echo $officersch ?>)<br />For: Registrar</p>

    </div>


    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
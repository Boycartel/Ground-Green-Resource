<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['transcript_email'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <style type="text/css">
        table {
            page-break-inside: avoid;
        }

        p {
            page-break-before: always;
        }

        @page {
            size: A4 landscape;
            font-size: small;
        }

        @page :left {
            margin-left: 1cm;
        }

        @page :right {
            margin-left: 1cm;
        }
    </style>

    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript">
        $("#btnPrint").live("click", function() {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var divContents = $("#dvContainer").html();
            var printWindow = window.open('', '', disp_setting);
            printWindow.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
            );
            printWindow.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>


    <script type="text/javascript">
        $("#btnPrint2").live("click", function() {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var divContents = $("#dvContainer2").html();
            var printWindow = window.open('', '', disp_setting);
            printWindow.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
            );
            printWindow.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>

    <script type="text/javascript">
        $("#btnPrint3").live("click", function() {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var divContents = $("#dvContainer3").html();
            var printWindow = window.open('', '', disp_setting);
            printWindow.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
            );
            printWindow.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>


    <script type="text/javascript">
        $("#btnPrint4").live("click", function() {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var divContents = $("#dvContainer4").html();
            var printWindow = window.open('', '', disp_setting);
            printWindow.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
            );
            printWindow.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>
    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php
    $userdept = $_SESSION['deptcode'];
    $userid = $_SESSION["staffid"];
    $usernames = $_SESSION['names'];
    $useremail = $_SESSION['email'];
    $deptname = $_SESSION['deptname'];
    //$cat = $_SESSION['cat'];
    $corntsession = $_SESSION['corntsession'];
    $cursemester = $_SESSION['cursemester'];

    $schcode = $_SESSION['schcode'];

    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Students' Academic Transcript</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Students' Academic Transcript</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students' Academic Transcript
                        </div>
                        <div class="panel-body">
                            <div>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Matric Number: </label>
                                        <div class="col-lg-5">
                                            <input type="text" class="form-control" style="color:#000000" name="regid" value="MTH/18U/0854">
                                        </div>
                                        <div class="col-lg-3">
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                        </div>
                                    </div>
                                </form>
                            </div>
                            <br>
                            <hr class="separator" />
                            <br>
                            <div class="row">
                                <?php if (isset($_POST["submit"])) { ?>
                                    <section class="panel">



                                        <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        $yeargrad = "";
                                        $getDE = "NO";
                                        $siwesstatus = $_SESSION["siwesstatus"];
                                        $deptoption = $_SESSION['deptoption'];
                                        $matno = str_replace("'", "", $_POST['regid']);
                                        $matno = filter_var(strtoupper($matno), FILTER_SANITIZE_STRING);


                                        $Is500L = "NO";
                                        $sql = "SELECT * FROM std_data_view WHERE matric_no = '$matno'";
                                        $result = $conn2->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $nationality = $row['nationality'];
                                                $jamb_appl_no = $row['jamb_appl_no'];
                                                $entry_session = $row['entry_session'];
                                                $entry_level = $row['entry_level'];
                                                $fulname = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                $modeofentry = $row["modeofentry"];
                                                $prog = "XXXX";

                                                $permaddres = $row['p_address'];


                                                $deptname = $_SESSION['deptname'];
                                                $dept = strtolower($row['dept_code']);


                                                $school = $row['school'];
                                                $stateorigin = $row['state'];
                                                $stu_curriculum = strtolower($row['curriculum']);
                                                $Stu_Dept_Opt = $row["Dept_Option"];
                                                $YAddmitted = substr($entry_session, 0, 4);
                                                if ($entry_level == 200) {
                                                    $getDE = "DE200";
                                                } elseif ($entry_level == 300) {
                                                    $getDE = "DE300";
                                                } elseif ($entry_level == 100) {
                                                }

                                                $PlaceBirth = "XXXX";

                                                $lga = $row['lga'];
                                                $sex1 = $row['gender'];

                                                $national = $row['nationality'];
                                                $dob = $row['dob'];


                                                $name_first = $row['first_name'];
                                                $name_last = $row['surname'];
                                                if (empty($row['other_name'])) {
                                                    $name_middle = "";
                                                } else {
                                                    $name_middle = $row['other_name'];
                                                }
                                            }
                                        }

                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $DegreeAward = $row["DegreeAward"];
                                            }
                                        }

                                        $sql = "SELECT * FROM users WHERE staffacddept = '$dept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $_SESSION["HOD_Sign"] = $row["full_name"];
                                            }
                                        }

                                        $sql = "SELECT * FROM users WHERE staffacddept = '$dept' AND (cat = 'Examiner' OR cat = 'ExamLAdvice' OR cat = 'PGExam')";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $_SESSION["Exam_Sign"] = $row["full_name"];
                                            }
                                        } else {
                                            $_SESSION["Exam_Sign"] = "XXXX";
                                        }


                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }
                                        $sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND graduated = 'YES'";
                                        $result = $conn_stu->query($sql);
                                        $totunit1 = $totgp1 = $cgpa1 = $gtotgp1 = $gtotunit1 = $stcp1 = 0;
                                        $conn->close();
                                        $conn2->close();
                                        $conn_stu->close();

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $yeargrad = $row["yearGrad"];
                                            }
                                        } else {
                                        ?>
                                            <script type="text/javascript">
                                                window.location.href = "transcript_comp_naub.php"
                                            </script>
                                        <?php
                                        }

                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $isdeptoption = $row["deptoption"];
                                                $iscurriculum = $row["curriculum"];
                                            }
                                        }
                                        //$conn->close();
                                        unset($unitarry);
                                        unset($gparry);
                                        unset($gpaarry);
                                        unset($cgpaarry);
                                        unset($totcpass);
                                        unset($tct);
                                        unset($tcp);
                                        unset($getfivelevel);
                                        unset($getfourlevel);
                                        unset($sessionarry);
                                        unset($LevelArray);

                                        unset($totunit);
                                        unset($totgp);
                                        unset($countSesRes);

                                        unset($ccode_tot);
                                        unset($ctitle_tot);
                                        unset($cunit_tot);
                                        unset($grade_tot);
                                        unset($gpoint_tot);
                                        unset($marks_tot);
                                        unset($sem_tot);

                                        unset($LevelCGPA);
                                        unset($absent1ST);
                                        unset($absent2ND);

                                        $Lev_totunit = 0;
                                        $Lev_totgp = 0;
                                        $maxSession = "";
                                        $NotRelevant = false;
                                        $SessionCount = 0;

                                        $yearadmt = substr($entry_session, 0, 4);
                                        if ($entry_level == 200) {
                                            $yearadmt = $yearadmt - 1;
                                        } elseif ($entry_level == 300) {
                                            $yearadmt = $yearadmt - 2;
                                        }

                                        $resultsession = $_SESSION['resultsession'];
                                        $resultsemester = $_SESSION['resultsemester'];
                                        $FinalYear = substr($resultsession, 0, 4);
                                        $StartYear = substr($entry_session, 0, 4);
                                        if (isset($_POST["view_in_sess"])) {
                                            unset($getSessionUnGrad);
                                            $countses = 0;

                                            for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                $getstuSession2 = $x . "/" . ($x + 1);
                                                $StuCurSess = str_ireplace("/", "_", $getstuSession2);

                                                if ($getstuSession2 < "2014/2015") {
                                                    $deptcorreg = "correg";
                                                } else {
                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                }

                                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$matno' AND SessionRegis = '$getstuSession2'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $countses++;
                                                        $getSessionUnGrad[$countses] = $row['SessionRegis'];
                                                    }
                                                }
                                                $getSessionUnGrad2 = array_unique($getSessionUnGrad);
                                                $getMaxSess = max($getSessionUnGrad2);
                                            }
                                        }
                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        for ($x = 0; $x <= 11; $x++) {
                                            //$countOneLev=$countTwoLev=$countThreLev=$countFivLev=$countFourLev=0;
                                            $maxLevel = 0;
                                            $nextyr = $yearadmt + 1;
                                            $sessionarry[$x] = $yearadmt . "/" . $nextyr;
                                            $yearadmt++;


                                            $gtotgp = 0;
                                            $stcp = 0;
                                            $LevelCGPA2 = 0;
                                            $countSesRes[$x] = 0;
                                            $absent1ST[$x] = 0;
                                            $absent2ND[$x] = 0;
                                            $countOneLev = $countTwoLev = $countThreLev = $countFivLev = $countFourLev = $getlevel = 0;


                                            $StuCurSess = str_ireplace("/", "_", $sessionarry[$x]);

                                            if (isset($_POST["view_in_sess"])) {

                                                $deptcorreg = "correg_" . $StuCurSess;
                                                if ($sessionarry[$x] == $getMaxSess) {
                                                    if ($getMaxSess == $resultsession && $resultsemester == "1ST") {
                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' AND SemTaken = '1ST' ORDER BY SemTaken, CCode";
                                                    } else {
                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
                                                    }
                                                } else {
                                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
                                                }
                                            } else {
                                                $deptcorreg = "correg_" . $StuCurSess;
                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
                                            }

                                            $result = $conn_stu->query($sql);
                                            $totunit = $totgp = $cgpa = $gtotgp = $gtotunit = 0;
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {

                                                    $ccode = $row['CCode'];
                                                    $ctitle = $row['CTitle'];
                                                    $cunit = $row['CUnit'];


                                                    if ($isdeptoption == "YES") {
                                                        if ($iscurriculum == "YES") {
                                                            if ($stu_curriculum == "old") {
                                                                $stu_curriculum2 = "";
                                                            } else {
                                                                $stu_curriculum2 = "_" . $stu_curriculum;
                                                            }
                                                            $sql3 = "SELECT * FROM gencourses" . $stu_curriculum2 . " WHERE C_codding  = '$ccode' AND " . $Stu_Dept_Opt . " = 'YES'";
                                                        } else {
                                                            $sql3 = "SELECT * FROM gencourses WHERE C_codding  = '$ccode' AND " . $Stu_Dept_Opt . " = 'YES'";
                                                        }

                                                        $result3 = $conn_stu->query($sql3);
                                                        $Add3 = 0;
                                                        if ($result3->num_rows > 0) {
                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                $Add3++;
                                                            }
                                                        }
                                                    } else {

                                                        if ($iscurriculum == "YES") {
                                                            if ($stu_curriculum == "old") {
                                                                $stu_curriculum2 = "";
                                                            } else {
                                                                $stu_curriculum2 = "_" . $stu_curriculum;
                                                            }
                                                            $sql3 = "SELECT * FROM gencourses" . $stu_curriculum2 . " WHERE C_codding  = '$ccode' AND Relevant = 'YES'";
                                                        } else {
                                                            $sql3 = "SELECT * FROM gencourses WHERE C_codding  = '$ccode' AND Relevant = 'YES'";
                                                        }

                                                        $result3 = $conn_stu->query($sql3);
                                                        $Add3 = 0;
                                                        if ($result3->num_rows > 0) {
                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                $Add3++;
                                                            }
                                                        }
                                                    }


                                                    if ($row['SemTaken'] == "1ST") {
                                                        $absent1ST[$x]++;
                                                    } elseif ($row['SemTaken'] == "2ND") {
                                                        $absent2ND[$x]++;
                                                    }
                                                    if ((int)substr($ccode, 3, 1) == 5) {
                                                        $countFivLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 4) {
                                                        $countFourLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 3) {
                                                        $countThreLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 2) {
                                                        $countTwoLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 1) {
                                                        $countOneLev++;
                                                    }

                                                    $gpoint = $row['point'];
                                                    $marks = $row['CA'] + $row['Exam'];
                                                    $grade = $row['grade'];
                                                    $sem = $row['SemTaken'];
                                                    $stcp = $stcp + $cunit;

                                                    if ($grade == "F") {

                                                        if ($Add3 == 0) {
                                                            $NotRelevant = true;
                                                            $ccode = "*" . $ccode;
                                                        }
                                                    }


                                                    $totunit = $totunit + $cunit;
                                                    $totgp = $totgp + $gpoint;

                                                    $ccode_tot[$x][$countSesRes[$x]] = $ccode;
                                                    $ctitle_tot[$x][$countSesRes[$x]] = $ctitle;
                                                    $cunit_tot[$x][$countSesRes[$x]] = $cunit;
                                                    $grade_tot[$x][$countSesRes[$x]] = $grade;
                                                    $marks_tot[$x][$countSesRes[$x]] = $marks;
                                                    $gpoint_tot[$x][$countSesRes[$x]] = $gpoint;
                                                    $sem_tot[$x][$countSesRes[$x]] = $sem;

                                                    $countSesRes[$x]++;
                                                }
                                            }
                                            $SessionCount = $x;
                                            $maxLevel = max($countOneLev, $countTwoLev, $countThreLev, $countFourLev, $countFivLev);
                                            if ($countOneLev == $maxLevel) {
                                                $LevelArray[$x] = 100;
                                            } elseif ($countTwoLev == $maxLevel) {
                                                $LevelArray[$x] = 200;
                                            } elseif ($countThreLev == $maxLevel) {
                                                $LevelArray[$x] = 300;
                                            } elseif ($countFourLev == $maxLevel) {
                                                $LevelArray[$x] = 400;
                                            } elseif ($countFivLev == $maxLevel) {
                                                $LevelArray[$x] = 500;
                                                //$Is500L="YES";
                                            }

                                            $unitarry[$x] = $totunit;
                                            $gparry[$x] = $totgp;
                                            $tgp[$x] = $totgp;
                                            $tct[$x] = $totunit;
                                            $tcp[$x] = $stcp;
                                            $totcpass[$x] = $stcp;

                                            $Lev_totunit = $Lev_totunit + $totunit;
                                            $Lev_totgp = $Lev_totgp + $totgp;

                                            if ($unitarry[$x] == 0) {
                                                $cgpa = 0;
                                                $gpaarry[$x] = 0;
                                                //$cgpaarry[$x]=0;
                                            } else {
                                                $cgpa = $gparry[$x] / $unitarry[$x];
                                                if ($totunit !== 0) {
                                                    $gpaarry[$x] = $totgp / $totunit;
                                                }
                                            }

                                            if ($Lev_totunit == 0) {
                                                $LevelCGPA[$x] = 0;
                                            } else {
                                                $LevelCGPA[$x] = $Lev_totgp / $Lev_totunit;
                                            }
                                            if (!isset($_POST["view_in_sess"])) {
                                                if ($nextyr >= $yeargrad) {
                                                    $maxSession = $sessionarry[$x];
                                                    $getMaxSess = $sessionarry[$x];
                                                    break;
                                                }
                                            } else {
                                                if ($sessionarry[$x] == $getMaxSess) {
                                                    break;
                                                }
                                            }
                                        }

                                        if ($SessionCount + 1 <= 4) {
                                            $totpages = 2;
                                        } elseif ($SessionCount + 1 <= 6) {
                                            $totpages = 3;
                                        } elseif ($SessionCount + 1 <= 8) {
                                            $totpages = 4;
                                        }
                                        $classdegree = "";
                                        $getdept = $dept;

                                        // To Change

                                        //$getyeargrad = "2021";
                                        //$getsemester = "2ND";
                                        $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;
                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        //$sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND yearGrad = '$getyeargrad' AND semester = '$getsemester'";
                                        $sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND graduated = 'YES'";
                                        $result = $conn_stu->query($sql);
                                        $totunit1 = $totgp1 = $cgpa1 = $gtotgp1 = $gtotunit1 = $stcp1 = 0;
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {

                                                $ccgpa = $row['CGPA'];
                                                $totunit1 = $row['TCT'];
                                                $stcp1 = $row['TCP'];
                                                $totgp1 = $row['CGP'];
                                                $classdegree = $row['classdegree'];
                                            }
                                        }
                                        $conn->close();
                                        $conn2->close();
                                        $conn_stu->close();
                                        include 'modulesInSess/classofdegree_inc.php';


                                        ?>

                                        <header class="panel-heading tab-bg-info">
                                            <ul class="nav nav-tabs">
                                                <li class="active">
                                                    <a data-toggle="tab" href="#page1">
                                                        Page 1
                                                    </a>
                                                </li>
                                                <?php if ($SessionCount >= 2) { ?>
                                                    <li>
                                                        <a data-toggle="tab" href="#page2">
                                                            Page 2
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                                <?php if ($SessionCount >= 4) { ?>
                                                    <li class="">
                                                        <a data-toggle="tab" href="#page3">
                                                            Page 3
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                                <?php if ($SessionCount >= 6) { ?>
                                                    <li class="">
                                                        <a data-toggle="tab" href="#page4">
                                                            Page 4
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                            </ul>
                                        </header>

                                        <div class="panel-body">
                                            <div class="tab-content">

                                                <div id="page1" class="tab-pane active">
                                                    <div id="dvContainer" style="width: auto; float: none">

                                                        <style>
                                                            table,
                                                            th,
                                                            td {
                                                                /*border: 1px solid black;*/
                                                                border-collapse: collapse;
                                                                font-size: 11px;
                                                            }
                                                        </style>

                                                        <table style="width: 99%">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="width: 10%">
                                                                        <img src="img/logo.ico" height="70" alt="logo" />
                                                                    </td>
                                                                    <th style="width: 80%">

                                                                        <p style="text-align: center; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                            <?php echo $_SESSION['instname'] ?><br>

                                                                            FACULTY OF
                                                                            <?php echo strtoupper($_SESSION['schname']) ?><br>

                                                                            DEPARTMENT OF
                                                                            <?php echo strtoupper($_SESSION['deptname']) ?><br>

                                                                            Official Transcript of Student's
                                                                            Academic Record
                                                                        </p>


                                                                    </th>
                                                                    <td>

                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <table style="width: 100%; color: #0a0a0a; padding-bottom: 1em; padding-top: 1em">
                                                            <tbody style="color: #0a0a0a">
                                                                <tr>
                                                                    <th style="text-align: left;width: 15%">
                                                                        REG NO :</th>
                                                                    <td style="width: 15%; text-align: left">
                                                                        <?php echo $matno ?></td>
                                                                    <th style="width: 15%; text-align: left">
                                                                        JAMB NO :</th>
                                                                    <td style="width: 15%">
                                                                        <?php echo $jamb_appl_no ?>
                                                                    </td>
                                                                    <th></th>

                                                                    <td></td>
                                                                </tr>

                                                                <tr>
                                                                    <th style="width: 15%; text-align: left">
                                                                        FIRST NAME :</th>
                                                                    <td style="width: 15%">
                                                                        <?php echo $name_first ?>

                                                                    </td>
                                                                    <th style="text-align: left; width: 15%">
                                                                        SURNAME :</th>
                                                                    <td style="width: 15%; text-align: left">
                                                                        <?php echo $name_last ?>
                                                                    </td>

                                                                    <th style="width: 15%; text-align: left">
                                                                        OTHER NAMES :</th>
                                                                    <td>
                                                                        <?php echo $name_middle ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th style="width: 15%; text-align: left">
                                                                        SEX :</th>
                                                                    <td style="width: 15%">
                                                                        <?php echo $sex1 ?></td>
                                                                    <th style="width: 15%; text-align: left">
                                                                        NATIONALITY :</th>
                                                                    <td style="width: 15%">
                                                                        <?php echo $nationality ?></td>
                                                                    <th style="text-align: left; width: 15%">STATE OF
                                                                        ORIGIN :</th>
                                                                    <td style="text-align: left">
                                                                        <?php echo $stateorigin ?></td>


                                                                </tr>


                                                                <tr>
                                                                    <th style="text-align: left; width: 15%">
                                                                        FACULTY :</th>
                                                                    <td style="width: 35%; text-align: left" colspan="2">
                                                                        <?php echo $_SESSION['schname'] ?>
                                                                    </td>
                                                                    <th style="width: 15%; text-align: left">
                                                                        DEPARTMENT :</th>
                                                                    <td style="width: 35%" colspan="2">
                                                                        <?php echo $_SESSION['deptname'] ?>
                                                                    </td>

                                                                </tr>

                                                            </tbody>
                                                        </table>

                                                        <table style="color: #0a0a0a; width: 98%; font-size: 9px">
                                                            <thead>
                                                                <tr>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        Session</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        Sem</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        Courses</th>

                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        TCUR</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        TWGP</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        GPA</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        CGPA</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <!-- Year One -->

                                                                <?php
                                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                if ($conn->connect_error) {
                                                                    die("Connection failed: " . $conn->connect_error);
                                                                }


                                                                $cancelsess1 = false;
                                                                $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[0]'";
                                                                $result = $conn->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    $cancelsess1 = true;
                                                                }
                                                                $conn->close();
                                                                ?>
                                                                <?php if ($cancelsess1 == true) { ?>
                                                                    <tr>
                                                                        <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                            <?php
                                                                            echo $sessionarry[0] . "<br> Canceled Session";
                                                                            ?>

                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>

                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                            <img src="img/cancel.png" alt="logo" style="width: 300px; height: 250px;" />
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>

                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                        </td>
                                                                    </tr>

                                                                <?php } else { ?>
                                                                    <tr>
                                                                        <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                            <?php echo $sessionarry[0] . "<br>" . $LevelArray[0] . "  Level" ?>

                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                            1
                                                                        </td>
                                                                        <td>
                                                                            <?php
                                                                            $totunit = $totgp = $cgpa = $gtotgp = $gtotunit = 0;
                                                                            echo "<table style='border: 1px solid; width: 100%'>";
                                                                            echo "<thead style='text-align:center;'>";
                                                                            echo "<tr>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                            echo "</tr>";
                                                                            echo "</thead>";
                                                                            echo "<tbody>";
                                                                            if ($absent1ST[0] != 0) {
                                                                                $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                if ($conn_stu->connect_error) {
                                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                                }
                                                                                $StuCurSess = str_ireplace("/", "_", $sessionarry[0]);
                                                                                $deptcorreg = "correg_" . $StuCurSess;
                                                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '1ST' ORDER BY CCode";
                                                                                $result = $conn_stu->query($sql);
                                                                                $ct = $gp = $gpa = 0;
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {

                                                                                        $ccode = $row['CCode'];
                                                                                        $ctitle = $row['CTitle'];
                                                                                        $cunit = $row['CUnit'];
                                                                                        $grade = $row['grade'];
                                                                                        $total = $row['CA'] + $row['Exam'];
                                                                                        $ct = $ct + $cunit;
                                                                                        $gp = $gp + $row["point"];
                                                                                        $totunit = $totunit + $cunit;
                                                                                        $totgp = $totgp + $row["point"];

                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                    }
                                                                                    if ($ct > 0) {
                                                                                        $gpa = $gp / $ct;
                                                                                    } else {
                                                                                        $gpa = 0;
                                                                                    }

                                                                                    if ($totunit > 0) {
                                                                                        $cgpa = $totgp / $totunit;
                                                                                    } else {
                                                                                        $cgpa = 0;
                                                                                    }
                                                                                }
                                                                                $conn_stu->close();
                                                                            } else {
                                                                                $indSession = $sessionarry[0];
                                                                                if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                    //$response_full = "DE";
                                                                                    echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                } else {
                                                                                    $indSession = $sessionarry[0];
                                                                                    $semtake = "1ST";
                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                }
                                                                            }
                                                                            echo "</tbody>";
                                                                            echo "</table>";

                                                                            ?>
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                        </td>
                                                                    </tr>

                                                                    <tr>
                                                                        <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                            <?php echo $sessionarry[0] . "<br>" . $LevelArray[0] . "  Level" ?>

                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                            2
                                                                        </td>
                                                                        <td>
                                                                            <?php

                                                                            echo "<table style='border: 1px solid; width: 100%'>";
                                                                            echo "<thead style='text-align:center;'>";
                                                                            echo "<tr>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                            echo "</tr>";
                                                                            echo "</thead>";
                                                                            echo "<tbody>";
                                                                            if ($absent2ND[0] != 0) {
                                                                                $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                if ($conn_stu->connect_error) {
                                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                                }

                                                                                $StuCurSess = str_ireplace("/", "_", $sessionarry[0]);
                                                                                $deptcorreg = "correg_" . $StuCurSess;
                                                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '2ND' ORDER BY CCode";
                                                                                $result = $conn_stu->query($sql);
                                                                                $ct = $gp = $gpa = 0;
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {

                                                                                        $ccode = $row['CCode'];
                                                                                        $ctitle = $row['CTitle'];
                                                                                        $cunit = $row['CUnit'];
                                                                                        $grade = $row['grade'];
                                                                                        $total = $row['CA'] + $row['Exam'];
                                                                                        $ct = $ct + $cunit;
                                                                                        $gp = $gp + $row["point"];
                                                                                        $totunit = $totunit + $cunit;
                                                                                        $totgp = $totgp + $row["point"];

                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                    }
                                                                                    if ($ct > 0) {
                                                                                        $gpa = $gp / $ct;
                                                                                    } else {
                                                                                        $gpa = 0;
                                                                                    }

                                                                                    if ($totunit > 0) {
                                                                                        $cgpa = $totgp / $totunit;
                                                                                    } else {
                                                                                        $cgpa = 0;
                                                                                    }
                                                                                }
                                                                                $conn_stu->close();
                                                                            } else {
                                                                                $indSession = $sessionarry[0];
                                                                                if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                    //$response_full = "DE";
                                                                                    echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                } else {
                                                                                    $indSession = $sessionarry[0];
                                                                                    $semtake = "2ND";
                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                }
                                                                            }
                                                                            echo "</tbody>";
                                                                            echo "</table>";

                                                                            ?>
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                        </td>
                                                                    </tr>

                                                                <?php } ?>


                                                                <!-- Year Two -->
                                                                <?php
                                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                if ($conn->connect_error) {
                                                                    die("Connection failed: " . $conn->connect_error);
                                                                }
                                                                $cancelsess2 = false;
                                                                $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[1]'";
                                                                $result = $conn->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    $cancelsess2 = true;
                                                                }
                                                                $conn->close();
                                                                ?>
                                                                <?php if ($cancelsess2 == true) { ?>
                                                                    <tr>
                                                                        <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                            <?php
                                                                            echo $sessionarry[1] . "<br> Canceled Session";
                                                                            ?>

                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>

                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                            <img src="img/cancel.png" alt="logo" style="width: 300px; height: 250px;" />
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>

                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                        </td>
                                                                    </tr>

                                                                <?php } else { ?>
                                                                    <tr>
                                                                        <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                            <?php echo $sessionarry[1] . "<br>" . $LevelArray[1] . "  Level" ?>

                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                            1
                                                                        </td>
                                                                        <td>
                                                                            <?php

                                                                            echo "<table style='border: 1px solid; width: 100%'>";
                                                                            echo "<thead style='text-align:center;'>";
                                                                            echo "<tr>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                            echo "</tr>";
                                                                            echo "</thead>";
                                                                            echo "<tbody>";
                                                                            if ($absent1ST[1] != 0) {
                                                                                $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                if ($conn_stu->connect_error) {
                                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                                }
                                                                                $StuCurSess = str_ireplace("/", "_", $sessionarry[1]);
                                                                                $deptcorreg = "correg_" . $StuCurSess;
                                                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '1ST' ORDER BY CCode";
                                                                                $result = $conn_stu->query($sql);
                                                                                $ct = $gp = $gpa = 0;
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {

                                                                                        $ccode = $row['CCode'];
                                                                                        $ctitle = $row['CTitle'];
                                                                                        $cunit = $row['CUnit'];
                                                                                        $grade = $row['grade'];
                                                                                        $total = $row['CA'] + $row['Exam'];
                                                                                        $ct = $ct + $cunit;
                                                                                        $gp = $gp + $row["point"];
                                                                                        $totunit = $totunit + $cunit;
                                                                                        $totgp = $totgp + $row["point"];

                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                    }
                                                                                    if ($ct > 0) {
                                                                                        $gpa = $gp / $ct;
                                                                                    } else {
                                                                                        $gpa = 0;
                                                                                    }

                                                                                    if ($totunit > 0) {
                                                                                        $cgpa = $totgp / $totunit;
                                                                                    } else {
                                                                                        $cgpa = 0;
                                                                                    }
                                                                                }
                                                                                $conn_stu->close();
                                                                            } else {
                                                                                $indSession = $sessionarry[1];
                                                                                if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                    //$response_full = "DE";
                                                                                    echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                } else {
                                                                                    $indSession = $sessionarry[1];
                                                                                    $semtake = "1ST";
                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                }
                                                                            }
                                                                            echo "</tbody>";
                                                                            echo "</table>";

                                                                            ?>
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                        </td>
                                                                    </tr>

                                                                    <tr>
                                                                        <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                            <?php echo $sessionarry[1] . "<br>" . $LevelArray[1] . "  Level" ?>

                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                            2
                                                                        </td>
                                                                        <td>
                                                                            <?php

                                                                            echo "<table style='width: 100%; border: 1px solid;'>";
                                                                            echo "<thead style='text-align:center;'>";
                                                                            echo "<tr>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                            echo "</tr>";
                                                                            echo "</thead>";
                                                                            echo "<tbody>";
                                                                            if ($absent2ND[1] != 0) {
                                                                                $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                if ($conn_stu->connect_error) {
                                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                                }
                                                                                $StuCurSess = str_ireplace("/", "_", $sessionarry[1]);
                                                                                $deptcorreg = "correg_" . $StuCurSess;
                                                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '2ND' ORDER BY CCode";
                                                                                $result = $conn_stu->query($sql);
                                                                                $ct = $gp = $gpa = 0;
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {

                                                                                        $ccode = $row['CCode'];
                                                                                        $ctitle = $row['CTitle'];
                                                                                        $cunit = $row['CUnit'];
                                                                                        $grade = $row['grade'];
                                                                                        $total = $row['CA'] + $row['Exam'];
                                                                                        $ct = $ct + $cunit;
                                                                                        $gp = $gp + $row["point"];
                                                                                        $totunit = $totunit + $cunit;
                                                                                        $totgp = $totgp + $row["point"];

                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                    }
                                                                                    if ($ct > 0) {
                                                                                        $gpa = $gp / $ct;
                                                                                    } else {
                                                                                        $gpa = 0;
                                                                                    }

                                                                                    if ($totunit > 0) {
                                                                                        $cgpa = $totgp / $totunit;
                                                                                    } else {
                                                                                        $cgpa = 0;
                                                                                    }
                                                                                }
                                                                                $conn_stu->close();
                                                                            } else {
                                                                                $indSession = $sessionarry[1];
                                                                                if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                    //$response_full = "DE";
                                                                                    echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                } else {
                                                                                    $indSession = $sessionarry[1];
                                                                                    $semtake = "2ND";
                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                }
                                                                            }
                                                                            echo "</tbody>";
                                                                            echo "</table>";

                                                                            ?>
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                        </td>
                                                                        <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                        </td>
                                                                    </tr>

                                                                <?php } ?>




                                                            </tbody>
                                                        </table>
                                                        <br><br>
                                                        <table style="width: 99%;">

                                                            <body>
                                                                <tr>
                                                                    <th style="font-size: 14px; width:50%; text-align:center">
                                                                        ----------------------------------------<br><?php echo $_SESSION["Exam_Sign"] ?><br>
                                                                        Examination Officer</th>
                                                                    <th style="font-size: 14px; width:50%; text-align:center">
                                                                        ----------------------------------------<br><?php echo $_SESSION["HOD_Sign"] ?><br>
                                                                        Head of Department and Chief Examiner</th>
                                                                </tr>

                                                            </body>
                                                        </table>
                                                        <h3 style="text-align: center;">Page 1 of <?php echo $totpages ?>
                                                        </h3>
                                                    </div>
                                                    <div class="row" style="text-align: right">
                                                        <br>

                                                        <input type="button" value="print to PDF" id="btnPrint" class="btn-success" />
                                                    </div>
                                                </div>
                                                <!-- profile -->
                                                <div id="page2" class="tab-pane">
                                                    <div id="dvContainer2" style="width: auto; float: none">
                                                        <style>
                                                            table,
                                                            th,
                                                            td {
                                                                /*border: 1px solid black;*/
                                                                border-collapse: collapse;
                                                                font-size: 11px;
                                                            }
                                                        </style>
                                                        <table style="width: 99%">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="width: 10%">
                                                                        <img src="img/logo.ico" height="70" alt="logo" />
                                                                    </td>
                                                                    <th style="width: 80%">

                                                                        <p style="text-align: center; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                            <?php echo $_SESSION['instname'] ?><br>

                                                                            FACULTY OF
                                                                            <?php echo strtoupper($_SESSION['schname']) ?><br>

                                                                            DEPARTMENT OF
                                                                            <?php echo strtoupper($_SESSION['deptname']) ?><br>

                                                                            Official Transcript of Student's
                                                                            Academic Record
                                                                        </p>


                                                                    </th>
                                                                    <td>

                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <table style="width: 100%; color: #0a0a0a; padding-bottom: 1em; padding-top: 1em">
                                                            <tbody style="color: #0a0a0a">
                                                                <tr>
                                                                    <th style="text-align: left;width: 15%">
                                                                        REG NO :</th>
                                                                    <td style="width: 15%; text-align: left">
                                                                        <?php echo $matno ?></td>
                                                                    <th style="width: 15%; text-align: left">
                                                                        JAMB NO :</th>
                                                                    <td style="width: 15%">
                                                                        <?php echo $jamb_appl_no ?>
                                                                    </td>
                                                                    <th></th>

                                                                    <td></td>
                                                                </tr>

                                                                <tr>
                                                                    <th style="width: 15%; text-align: left">
                                                                        FIRST NAME :</th>
                                                                    <td style="width: 15%">
                                                                        <?php echo $name_first ?>

                                                                    </td>
                                                                    <th style="text-align: left; width: 15%">
                                                                        SURNAME :</th>
                                                                    <td style="width: 15%; text-align: left">
                                                                        <?php echo $name_last ?>
                                                                    </td>

                                                                    <th style="width: 15%; text-align: left">
                                                                        OTHER NAMES :</th>
                                                                    <td>
                                                                        <?php echo $name_middle ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <th style="width: 15%; text-align: left">
                                                                        SEX :</th>
                                                                    <td style="width: 15%">
                                                                        <?php echo $sex1 ?></td>
                                                                    <th style="width: 15%; text-align: left">
                                                                        NATIONALITY :</th>
                                                                    <td style="width: 15%">
                                                                        <?php echo $nationality ?></td>
                                                                    <th style="text-align: left; width: 15%">STATE OF
                                                                        ORIGIN :</th>
                                                                    <td style="text-align: left">
                                                                        <?php echo $stateorigin ?></td>


                                                                </tr>


                                                                <tr>
                                                                    <th style="text-align: left; width: 15%">
                                                                        FACULTY :</th>
                                                                    <td style="width: 35%; text-align: left" colspan="2">
                                                                        <?php echo $_SESSION['schname'] ?>
                                                                    </td>
                                                                    <th style="width: 15%; text-align: left">
                                                                        DEPARTMENT :</th>
                                                                    <td style="width: 35%" colspan="2">
                                                                        <?php echo $_SESSION['deptname'] ?>
                                                                    </td>

                                                                </tr>

                                                            </tbody>
                                                        </table>

                                                        <table style="color: #0a0a0a; width: 98%; font-size: 9px">
                                                            <thead>
                                                                <tr>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        Session</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        Sem</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        Courses</th>

                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        TCUR</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        TWGP</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        GPA</th>
                                                                    <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                        CGPA</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>



                                                                <?php if ($SessionCount >= 2) { ?>
                                                                    <!-- Year Three -->
                                                                    <?php
                                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                    if ($conn->connect_error) {
                                                                        die("Connection failed: " . $conn->connect_error);
                                                                    }
                                                                    $cancelsess3 = false;
                                                                    $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[2]'";
                                                                    $result = $conn->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        $cancelsess3 = true;
                                                                    }
                                                                    $conn->close();
                                                                    ?>
                                                                    <?php if ($cancelsess3 == true) { ?>
                                                                        <tr>
                                                                            <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                <?php
                                                                                echo $sessionarry[2] . "<br> Canceled Session";
                                                                                ?>

                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>

                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                <img src="img/cancel.png" alt="logo" style="width: 300px; height: 250px;" />
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>

                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                            </td>
                                                                        </tr>

                                                                    <?php } else { ?>
                                                                        <tr>
                                                                            <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                <?php
                                                                                echo $sessionarry[2] . "<br>" . $LevelArray[2] . "  Level";
                                                                                ?>

                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                1
                                                                            </td>
                                                                            <td>
                                                                                <?php

                                                                                echo "<table style='border: 1px solid; width: 100%'>";
                                                                                echo "<thead style='text-align:center;'>";
                                                                                echo "<tr>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                echo "</tr>";
                                                                                echo "</thead>";
                                                                                echo "<tbody>";
                                                                                if ($absent1ST[2] != 0) {
                                                                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                    if ($conn_stu->connect_error) {
                                                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                                                    }
                                                                                    $StuCurSess = str_ireplace("/", "_", $sessionarry[2]);
                                                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '1ST' ORDER BY CCode";
                                                                                    $result = $conn_stu->query($sql);
                                                                                    $ct = $gp = $gpa = 0;
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {

                                                                                            $ccode = $row['CCode'];
                                                                                            $ctitle = $row['CTitle'];
                                                                                            $cunit = $row['CUnit'];
                                                                                            $grade = $row['grade'];
                                                                                            $total = $row['CA'] + $row['Exam'];
                                                                                            $ct = $ct + $cunit;
                                                                                            $gp = $gp + $row["point"];
                                                                                            $totunit = $totunit + $cunit;
                                                                                            $totgp = $totgp + $row["point"];

                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                        }
                                                                                        if ($ct > 0) {
                                                                                            $gpa = $gp / $ct;
                                                                                        } else {
                                                                                            $gpa = 0;
                                                                                        }

                                                                                        if ($totunit > 0) {
                                                                                            $cgpa = $totgp / $totunit;
                                                                                        } else {
                                                                                            $cgpa = 0;
                                                                                        }
                                                                                    }
                                                                                    $conn_stu->close();
                                                                                } else {
                                                                                    $indSession = $sessionarry[2];
                                                                                    if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                        //$response_full = "DE";
                                                                                        echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                    } else {
                                                                                        $indSession = $sessionarry[2];
                                                                                        $semtake = "1ST";
                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                    }
                                                                                }
                                                                                echo "</tbody>";
                                                                                echo "</table>";

                                                                                ?>
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                            </td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                <?php
                                                                                echo $sessionarry[2] . "<br>" . $LevelArray[2] . "  Level";
                                                                                ?>

                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                2
                                                                            </td>
                                                                            <td>
                                                                                <?php

                                                                                echo "<table style='border: 1px solid; width: 100%'>";
                                                                                echo "<thead style='text-align:center;'>";
                                                                                echo "<tr>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                echo "</tr>";
                                                                                echo "</thead>";
                                                                                echo "<tbody>";
                                                                                if ($absent2ND[2] != 0) {
                                                                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                    if ($conn_stu->connect_error) {
                                                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                                                    }
                                                                                    $StuCurSess = str_ireplace("/", "_", $sessionarry[2]);
                                                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '2ND' ORDER BY CCode";
                                                                                    $result = $conn_stu->query($sql);
                                                                                    $ct = $gp = $gpa = 0;
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {

                                                                                            $ccode = $row['CCode'];
                                                                                            $ctitle = $row['CTitle'];
                                                                                            $cunit = $row['CUnit'];
                                                                                            $grade = $row['grade'];
                                                                                            $total = $row['CA'] + $row['Exam'];
                                                                                            $ct = $ct + $cunit;
                                                                                            $gp = $gp + $row["point"];
                                                                                            $totunit = $totunit + $cunit;
                                                                                            $totgp = $totgp + $row["point"];

                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                        }
                                                                                        if ($ct > 0) {
                                                                                            $gpa = $gp / $ct;
                                                                                        } else {
                                                                                            $gpa = 0;
                                                                                        }

                                                                                        if ($totunit > 0) {
                                                                                            $cgpa = $totgp / $totunit;
                                                                                        } else {
                                                                                            $cgpa = 0;
                                                                                        }
                                                                                    }
                                                                                    $conn_stu->close();
                                                                                } else {
                                                                                    $indSession = $sessionarry[2];
                                                                                    if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                        //$response_full = "DE";
                                                                                        echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                    } else {
                                                                                        $indSession = $sessionarry[2];
                                                                                        $semtake = "2ND";
                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                    }
                                                                                }
                                                                                echo "</tbody>";
                                                                                echo "</table>";

                                                                                ?>
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                            </td>
                                                                        </tr>
                                                                    <?php } ?>

                                                                <?php } ?>


                                                                <?php if ($SessionCount >= 3) { ?>
                                                                    <!-- Year Three -->
                                                                    <?php
                                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                    if ($conn->connect_error) {
                                                                        die("Connection failed: " . $conn->connect_error);
                                                                    }
                                                                    $cancelsess4 = false;
                                                                    $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[3]'";
                                                                    $result = $conn->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        $cancelsess4 = true;
                                                                    }
                                                                    $conn->close();
                                                                    ?>
                                                                    <?php if ($cancelsess4 == true) { ?>
                                                                        <tr>
                                                                            <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                <?php
                                                                                echo $sessionarry[3] . "<br> Canceled Session";
                                                                                ?>

                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>

                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                <img src="img/cancel.png" alt="logo" style="width: 300px; height: 250px;" />
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>

                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                            </td>
                                                                        </tr>

                                                                    <?php } else { ?>
                                                                        <tr>
                                                                            <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                <?php
                                                                                echo $sessionarry[3] . "<br>" . $LevelArray[3] . "  Level";
                                                                                ?>

                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                1
                                                                            </td>
                                                                            <td>
                                                                                <?php

                                                                                echo "<table style='border: 1px solid; width: 100%'>";
                                                                                echo "<thead style='text-align:center;'>";
                                                                                echo "<tr>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                echo "</tr>";
                                                                                echo "</thead>";
                                                                                echo "<tbody>";
                                                                                if ($absent1ST[3] != 0) {
                                                                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                    if ($conn_stu->connect_error) {
                                                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                                                    }
                                                                                    $StuCurSess = str_ireplace("/", "_", $sessionarry[3]);
                                                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '1ST' ORDER BY CCode";
                                                                                    $result = $conn_stu->query($sql);
                                                                                    $ct = $gp = $gpa = 0;
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {

                                                                                            $ccode = $row['CCode'];
                                                                                            $ctitle = $row['CTitle'];
                                                                                            $cunit = $row['CUnit'];
                                                                                            $grade = $row['grade'];
                                                                                            $total = $row['CA'] + $row['Exam'];
                                                                                            $ct = $ct + $cunit;
                                                                                            $gp = $gp + $row["point"];
                                                                                            $totunit = $totunit + $cunit;
                                                                                            $totgp = $totgp + $row["point"];

                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                        }
                                                                                        if ($ct > 0) {
                                                                                            $gpa = $gp / $ct;
                                                                                        } else {
                                                                                            $gpa = 0;
                                                                                        }

                                                                                        if ($totunit > 0) {
                                                                                            $cgpa = $totgp / $totunit;
                                                                                        } else {
                                                                                            $cgpa = 0;
                                                                                        }
                                                                                    }
                                                                                    $conn_stu->close();
                                                                                } else {
                                                                                    $indSession = $sessionarry[3];
                                                                                    if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                        //$response_full = "DE";
                                                                                        echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                    } else {
                                                                                        $indSession = $sessionarry[3];
                                                                                        $semtake = "1ST";
                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                    }
                                                                                }
                                                                                echo "</tbody>";
                                                                                echo "</table>";

                                                                                ?>
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                            </td>
                                                                        </tr>

                                                                        <tr>
                                                                            <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                <?php
                                                                                echo $sessionarry[3] . "<br>" . $LevelArray[3] . "  Level";
                                                                                ?>

                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                2
                                                                            </td>
                                                                            <td>
                                                                                <?php

                                                                                echo "<table style='border: 1px solid; width: 100%'>";
                                                                                echo "<thead style='text-align:center;'>";
                                                                                echo "<tr>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                echo "</tr>";
                                                                                echo "</thead>";
                                                                                echo "<tbody>";
                                                                                if ($absent2ND[3] != 0) {
                                                                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                    if ($conn_stu->connect_error) {
                                                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                                                    }
                                                                                    $StuCurSess = str_ireplace("/", "_", $sessionarry[3]);
                                                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '2ND' ORDER BY CCode";
                                                                                    $result = $conn_stu->query($sql);
                                                                                    $ct = $gp = $gpa = 0;
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {

                                                                                            $ccode = $row['CCode'];
                                                                                            $ctitle = $row['CTitle'];
                                                                                            $cunit = $row['CUnit'];
                                                                                            $grade = $row['grade'];
                                                                                            $total = $row['CA'] + $row['Exam'];
                                                                                            $ct = $ct + $cunit;
                                                                                            $gp = $gp + $row["point"];
                                                                                            $totunit = $totunit + $cunit;
                                                                                            $totgp = $totgp + $row["point"];

                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                        }
                                                                                        if ($ct > 0) {
                                                                                            $gpa = $gp / $ct;
                                                                                        } else {
                                                                                            $gpa = 0;
                                                                                        }

                                                                                        if ($totunit > 0) {
                                                                                            $cgpa = $totgp / $totunit;
                                                                                        } else {
                                                                                            $cgpa = 0;
                                                                                        }
                                                                                    }
                                                                                    $conn_stu->close();
                                                                                } else {
                                                                                    $indSession = $sessionarry[3];
                                                                                    if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                        //$response_full = "DE";
                                                                                        echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                    } else {
                                                                                        $indSession = $sessionarry[3];
                                                                                        $semtake = "2ND";
                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                    }
                                                                                }
                                                                                echo "</tbody>";
                                                                                echo "</table>";

                                                                                ?>
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                            </td>
                                                                            <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                            </td>
                                                                        </tr>
                                                                    <?php } ?>

                                                                <?php } ?>
                                                            </tbody>
                                                        </table>
                                                        <?php if ($SessionCount <= 3) { ?>
                                                            <table>

                                                                <body>
                                                                    <tr>
                                                                        <td style="font-size: 14px;"><strong>FINAL
                                                                                CGPA:</strong>
                                                                            <?php echo number_format($cgpa, 2) ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="font-size: 14px;"><strong>Degree
                                                                                Aarded:</strong>
                                                                            <?php echo $DegreeAward . " " . $deptname ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="font-size: 14px;"><strong>Class of
                                                                                Degree:</strong>
                                                                            <?php echo $classdegree ?></td>
                                                                    </tr>
                                                                </body>
                                                            </table>
                                                        <?php } ?>
                                                        <br><br>
                                                        <table style="width: 99%;">

                                                            <body>
                                                                <tr>
                                                                    <th style="font-size: 14px; width:50%; text-align:center">
                                                                        ----------------------------------------<br><?php echo $_SESSION["Exam_Sign"] ?><br>
                                                                        Examination Officer</th>
                                                                    <th style="font-size: 14px; width:50%; text-align:center">
                                                                        ----------------------------------------<br><?php echo $_SESSION["HOD_Sign"] ?><br>
                                                                        Head of Department and Chief Examiner</th>
                                                                </tr>

                                                            </body>
                                                        </table>
                                                        <h3 style="text-align: center;">Page 2 of <?php echo $totpages ?>
                                                        </h3>
                                                    </div>
                                                    <div class="row" style="text-align: right">
                                                        <br>
                                                        <input type="button" value="print to PDF" id="btnPrint2" class="btn-success" />
                                                    </div>
                                                </div>
                                                <?php if ($SessionCount >= 4) { ?>
                                                    <div id="page3" class="tab-pane">
                                                        <div id="dvContainer3" style="width: auto; float: none">
                                                            <style>
                                                                table,
                                                                th,
                                                                td {
                                                                    /*border: 1px solid black;*/
                                                                    border-collapse: collapse;
                                                                    font-size: 11px;
                                                                }
                                                            </style>
                                                            <table style="width: 99%">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="width: 10%">
                                                                            <img src="img/logo.ico" height="70" alt="logo" />
                                                                        </td>
                                                                        <th style="width: 80%">

                                                                            <p style="text-align: center; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                <?php echo $_SESSION['instname'] ?><br>

                                                                                FACULTY OF
                                                                                <?php echo strtoupper($_SESSION['schname']) ?><br>


                                                                                DEPARTMENT OF
                                                                                <?php echo strtoupper($_SESSION['deptname']) ?><br>

                                                                                Official Transcript of Student's
                                                                                Academic Record
                                                                            </p>


                                                                        </th>
                                                                        <td>

                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <table style="width: 100%; color: #0a0a0a; padding-bottom: 1em; padding-top: 1em">
                                                                <tbody style="color: #0a0a0a">
                                                                    <tr>
                                                                        <th style="text-align: left;width: 15%">
                                                                            REG NO :</th>
                                                                        <td style="width: 15%; text-align: left">
                                                                            <?php echo $matno ?></td>
                                                                        <th style="width: 15%; text-align: left">
                                                                            JAMB NO :</th>
                                                                        <td style="width: 15%">
                                                                            <?php echo $jamb_appl_no ?>
                                                                        </td>
                                                                        <th></th>

                                                                        <td></td>
                                                                    </tr>

                                                                    <tr>
                                                                        <th style="width: 15%; text-align: left">
                                                                            FIRST NAME :</th>
                                                                        <td style="width: 15%">
                                                                            <?php echo $name_first ?>

                                                                        </td>
                                                                        <th style="text-align: left; width: 15%">
                                                                            SURNAME :</th>
                                                                        <td style="width: 15%; text-align: left">
                                                                            <?php echo $name_last ?>
                                                                        </td>

                                                                        <th style="width: 15%; text-align: left">
                                                                            OTHER NAMES :</th>
                                                                        <td>
                                                                            <?php echo $name_middle ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th style="width: 15%; text-align: left">
                                                                            SEX :</th>
                                                                        <td style="width: 15%">
                                                                            <?php echo $sex1 ?></td>
                                                                        <th style="width: 15%; text-align: left">
                                                                            NATIONALITY :</th>
                                                                        <td style="width: 15%">
                                                                            <?php echo $nationality ?></td>
                                                                        <th style="text-align: left; width: 15%">STATE OF
                                                                            ORIGIN :</th>
                                                                        <td style="text-align: left">
                                                                            <?php echo $stateorigin ?></td>


                                                                    </tr>


                                                                    <tr>
                                                                        <th style="text-align: left; width: 15%">
                                                                            FACULTY :</th>
                                                                        <td style="width: 35%; text-align: left" colspan="2">
                                                                            <?php echo $_SESSION['schname'] ?>
                                                                        </td>
                                                                        <th style="width: 15%; text-align: left">
                                                                            DEPARTMENT :</th>
                                                                        <td style="width: 35%" colspan="2">
                                                                            <?php echo $_SESSION['deptname'] ?>
                                                                        </td>

                                                                    </tr>

                                                                </tbody>
                                                            </table>

                                                            <table style="color: #0a0a0a; width: 98%; font-size: 9px">
                                                                <thead>
                                                                    <tr>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            Session</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            Sem</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            Courses</th>

                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            TCUR</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            TWGP</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            GPA</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            CGPA</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>



                                                                    <?php if ($SessionCount >= 4) { ?>
                                                                        <!-- Year Three -->
                                                                        <?php
                                                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                        if ($conn->connect_error) {
                                                                            die("Connection failed: " . $conn->connect_error);
                                                                        }
                                                                        $cancelsess5 = false;
                                                                        $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[4]'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            $cancelsess5 = true;
                                                                        }
                                                                        $conn->close();
                                                                        ?>
                                                                        <?php if ($cancelsess5 == true) { ?>
                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[4] . "<br> Canceled Session";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    <img src="img/cancel.png" alt="logo" style="width: 300px; height: 250px;" />
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>

                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>

                                                                        <?php } else { ?>
                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[4] . "<br>" . $LevelArray[4] . "  Level";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    1
                                                                                </td>
                                                                                <td>
                                                                                    <?php

                                                                                    echo "<table style='border: 1px solid; width: 100%'>";
                                                                                    echo "<thead style='text-align:center;'>";
                                                                                    echo "<tr>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                    echo "</tr>";
                                                                                    echo "</thead>";
                                                                                    echo "<tbody>";
                                                                                    if ($absent1ST[4] != 0) {
                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                        if ($conn_stu->connect_error) {
                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                        }
                                                                                        $StuCurSess = str_ireplace("/", "_", $sessionarry[4]);
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '1ST' ORDER BY CCode";
                                                                                        $result = $conn_stu->query($sql);
                                                                                        $ct = $gp = $gpa = 0;
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {

                                                                                                $ccode = $row['CCode'];
                                                                                                $ctitle = $row['CTitle'];
                                                                                                $cunit = $row['CUnit'];
                                                                                                $grade = $row['grade'];
                                                                                                $total = $row['CA'] + $row['Exam'];
                                                                                                $ct = $ct + $cunit;
                                                                                                $gp = $gp + $row["point"];
                                                                                                $totunit = $totunit + $cunit;
                                                                                                $totgp = $totgp + $row["point"];

                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                            }
                                                                                            if ($ct > 0) {
                                                                                                $gpa = $gp / $ct;
                                                                                            } else {
                                                                                                $gpa = 0;
                                                                                            }

                                                                                            if ($totunit > 0) {
                                                                                                $cgpa = $totgp / $totunit;
                                                                                            } else {
                                                                                                $cgpa = 0;
                                                                                            }
                                                                                        }
                                                                                        $conn_stu->close();
                                                                                    } else {
                                                                                        $indSession = $sessionarry[4];
                                                                                        if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                            //$response_full = "DE";
                                                                                            echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                        } else {
                                                                                            $indSession = $sessionarry[4];
                                                                                            $semtake = "1ST";
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                        }
                                                                                    }
                                                                                    echo "</tbody>";
                                                                                    echo "</table>";

                                                                                    ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>

                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[4] . "<br>" . $LevelArray[4] . "  Level";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    2
                                                                                </td>
                                                                                <td>
                                                                                    <?php

                                                                                    echo "<table style='border: 1px solid; width: 100%'>";
                                                                                    echo "<thead style='text-align:center;'>";
                                                                                    echo "<tr>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                    echo "</tr>";
                                                                                    echo "</thead>";
                                                                                    echo "<tbody>";
                                                                                    if ($absent2ND[4] != 0) {
                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                        if ($conn_stu->connect_error) {
                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                        }
                                                                                        $StuCurSess = str_ireplace("/", "_", $sessionarry[4]);
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '2ND' ORDER BY CCode";
                                                                                        $result = $conn_stu->query($sql);
                                                                                        $ct = $gp = $gpa = 0;
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {

                                                                                                $ccode = $row['CCode'];
                                                                                                $ctitle = $row['CTitle'];
                                                                                                $cunit = $row['CUnit'];
                                                                                                $grade = $row['grade'];
                                                                                                $total = $row['CA'] + $row['Exam'];
                                                                                                $ct = $ct + $cunit;
                                                                                                $gp = $gp + $row["point"];
                                                                                                $totunit = $totunit + $cunit;
                                                                                                $totgp = $totgp + $row["point"];

                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                            }
                                                                                            if ($ct > 0) {
                                                                                                $gpa = $gp / $ct;
                                                                                            } else {
                                                                                                $gpa = 0;
                                                                                            }

                                                                                            if ($totunit > 0) {
                                                                                                $cgpa = $totgp / $totunit;
                                                                                            } else {
                                                                                                $cgpa = 0;
                                                                                            }
                                                                                        }
                                                                                        $conn_stu->close();
                                                                                    } else {
                                                                                        $indSession = $sessionarry[4];
                                                                                        if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                            //$response_full = "DE";
                                                                                            echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                        } else {
                                                                                            $indSession = $sessionarry[4];
                                                                                            $semtake = "2ND";
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                        }
                                                                                    }
                                                                                    echo "</tbody>";
                                                                                    echo "</table>";

                                                                                    ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>
                                                                        <?php } ?>

                                                                    <?php } ?>


                                                                    <?php if ($SessionCount >= 5) { ?>
                                                                        <!-- Year Three -->
                                                                        <?php
                                                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                        if ($conn->connect_error) {
                                                                            die("Connection failed: " . $conn->connect_error);
                                                                        }
                                                                        $cancelsess6 = false;
                                                                        $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[5]'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            $cancelsess6 = true;
                                                                        }
                                                                        $conn->close();
                                                                        ?>
                                                                        <?php if ($cancelsess6 == true) { ?>
                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[5] . "<br> Canceled Session";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    <img src="img/cancel.png" alt="logo" style="width: 300px; height: 250px;" />
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>

                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>

                                                                        <?php } else { ?>
                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[5] . "<br>" . $LevelArray[5] . "  Level";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    1
                                                                                </td>
                                                                                <td>
                                                                                    <?php

                                                                                    echo "<table style='border: 1px solid; width: 100%'>";
                                                                                    echo "<thead style='text-align:center;'>";
                                                                                    echo "<tr>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                    echo "</tr>";
                                                                                    echo "</thead>";
                                                                                    echo "<tbody>";
                                                                                    if ($absent1ST[5] != 0) {
                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                        if ($conn_stu->connect_error) {
                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                        }
                                                                                        $StuCurSess = str_ireplace("/", "_", $sessionarry[5]);
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '1ST' ORDER BY CCode";
                                                                                        $result = $conn_stu->query($sql);
                                                                                        $ct = $gp = $gpa = 0;
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {

                                                                                                $ccode = $row['CCode'];
                                                                                                $ctitle = $row['CTitle'];
                                                                                                $cunit = $row['CUnit'];
                                                                                                $grade = $row['grade'];
                                                                                                $total = $row['CA'] + $row['Exam'];
                                                                                                $ct = $ct + $cunit;
                                                                                                $gp = $gp + $row["point"];
                                                                                                $totunit = $totunit + $cunit;
                                                                                                $totgp = $totgp + $row["point"];

                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                            }
                                                                                            if ($ct > 0) {
                                                                                                $gpa = $gp / $ct;
                                                                                            } else {
                                                                                                $gpa = 0;
                                                                                            }

                                                                                            if ($totunit > 0) {
                                                                                                $cgpa = $totgp / $totunit;
                                                                                            } else {
                                                                                                $cgpa = 0;
                                                                                            }
                                                                                        }
                                                                                        $conn_stu->close();
                                                                                    } else {
                                                                                        $indSession = $sessionarry[5];
                                                                                        if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                            //$response_full = "DE";
                                                                                            echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                        } else {
                                                                                            $indSession = $sessionarry[5];
                                                                                            $semtake = "1ST";
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                        }
                                                                                    }
                                                                                    echo "</tbody>";
                                                                                    echo "</table>";

                                                                                    ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>

                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[5] . "<br>" . $LevelArray[5] . "  Level";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    2
                                                                                </td>
                                                                                <td>
                                                                                    <?php

                                                                                    echo "<table style='border: 1px solid; width: 100%'>";
                                                                                    echo "<thead style='text-align:center;'>";
                                                                                    echo "<tr>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                    echo "</tr>";
                                                                                    echo "</thead>";
                                                                                    echo "<tbody>";
                                                                                    if ($absent2ND[5] != 0) {
                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                        if ($conn_stu->connect_error) {
                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                        }
                                                                                        $StuCurSess = str_ireplace("/", "_", $sessionarry[5]);
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '2ND' ORDER BY CCode";
                                                                                        $result = $conn_stu->query($sql);
                                                                                        $ct = $gp = $gpa = 0;
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {

                                                                                                $ccode = $row['CCode'];
                                                                                                $ctitle = $row['CTitle'];
                                                                                                $cunit = $row['CUnit'];
                                                                                                $grade = $row['grade'];
                                                                                                $total = $row['CA'] + $row['Exam'];
                                                                                                $ct = $ct + $cunit;
                                                                                                $gp = $gp + $row["point"];
                                                                                                $totunit = $totunit + $cunit;
                                                                                                $totgp = $totgp + $row["point"];

                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                            }
                                                                                            if ($ct > 0) {
                                                                                                $gpa = $gp / $ct;
                                                                                            } else {
                                                                                                $gpa = 0;
                                                                                            }

                                                                                            if ($totunit > 0) {
                                                                                                $cgpa = $totgp / $totunit;
                                                                                            } else {
                                                                                                $cgpa = 0;
                                                                                            }
                                                                                        }
                                                                                        $conn_stu->close();
                                                                                    } else {
                                                                                        $indSession = $sessionarry[5];
                                                                                        if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                            //$response_full = "DE";
                                                                                            echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                        } else {
                                                                                            $indSession = $sessionarry[5];
                                                                                            $semtake = "2ND";
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                        }
                                                                                    }
                                                                                    echo "</tbody>";
                                                                                    echo "</table>";

                                                                                    ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>
                                                                        <?php } ?>

                                                                    <?php } ?>
                                                                </tbody>
                                                            </table>
                                                            <?php if ($SessionCount <= 5) { ?>
                                                                <table>

                                                                    <body>
                                                                        <tr>
                                                                            <td style="font-size: 14px;"><strong>FINAL
                                                                                    CGPA:</strong>
                                                                                <?php echo number_format($cgpa, 2) ?>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="font-size: 14px;"><strong>Degree
                                                                                    Aarded:</strong>
                                                                                <?php echo $DegreeAward . " " . $deptname ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="font-size: 14px;"><strong>Class of
                                                                                    Degree:</strong>
                                                                                <?php echo $classdegree ?></td>
                                                                        </tr>
                                                                    </body>
                                                                </table>
                                                            <?php } ?>
                                                            <br><br>
                                                            <table style="width: 99%;">

                                                                <body>
                                                                    <tr>
                                                                        <th style="font-size: 14px; width:50%; text-align:center">
                                                                            ----------------------------------------<br><?php echo $_SESSION["Exam_Sign"] ?><br>
                                                                            Examination Officer</th>
                                                                        <th style="font-size: 14px; width:50%; text-align:center">
                                                                            ----------------------------------------<br><?php echo $_SESSION["HOD_Sign"] ?><br>
                                                                            Head of Department and Chief Examiner</th>
                                                                    </tr>

                                                                </body>
                                                            </table>
                                                            <h3 style="text-align: center;">Page 3 of <?php echo $totpages ?>
                                                            </h3>
                                                        </div>
                                                        <div class="row" style="text-align: right">
                                                            <br>
                                                            <input type="button" value="print to PDF" id="btnPrint3" class="btn-success" />
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php if ($SessionCount >= 6) { ?>
                                                    <div id="page4" class="tab-pane">
                                                        <div id="dvContainer4" style="width: auto; float: none">
                                                            <style>
                                                                table,
                                                                th,
                                                                td {
                                                                    /*border: 1px solid black;*/
                                                                    border-collapse: collapse;
                                                                    font-size: 11px;
                                                                }
                                                            </style>
                                                            <table style="width: 99%">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="width: 10%">
                                                                            <img src="img/logo.ico" height="70" alt="logo" />
                                                                        </td>
                                                                        <th style="width: 80%">

                                                                            <p style="text-align: center; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                <?php echo $_SESSION['instname'] ?><br>

                                                                                FACULTY OF
                                                                                <?php echo strtoupper($_SESSION['schname']) ?><br>


                                                                                DEPARTMENT OF
                                                                                <?php echo strtoupper($_SESSION['deptname']) ?><br>

                                                                                Official Transcript of Student's
                                                                                Academic Record
                                                                            </p>


                                                                        </th>
                                                                        <td>

                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <table style="width: 100%; color: #0a0a0a; padding-bottom: 1em; padding-top: 1em">
                                                                <tbody style="color: #0a0a0a">
                                                                    <tr>
                                                                        <th style="text-align: left;width: 15%">
                                                                            REG NO :</th>
                                                                        <td style="width: 15%; text-align: left">
                                                                            <?php echo $matno ?></td>
                                                                        <th style="width: 15%; text-align: left">
                                                                            JAMB NO :</th>
                                                                        <td style="width: 15%">
                                                                            <?php echo $jamb_appl_no ?>
                                                                        </td>
                                                                        <th></th>

                                                                        <td></td>
                                                                    </tr>

                                                                    <tr>
                                                                        <th style="width: 15%; text-align: left">
                                                                            FIRST NAME :</th>
                                                                        <td style="width: 15%">
                                                                            <?php echo $name_first ?>

                                                                        </td>
                                                                        <th style="text-align: left; width: 15%">
                                                                            SURNAME :</th>
                                                                        <td style="width: 15%; text-align: left">
                                                                            <?php echo $name_last ?>
                                                                        </td>

                                                                        <th style="width: 15%; text-align: left">
                                                                            OTHER NAMES :</th>
                                                                        <td>
                                                                            <?php echo $name_middle ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th style="width: 15%; text-align: left">
                                                                            SEX :</th>
                                                                        <td style="width: 15%">
                                                                            <?php echo $sex1 ?></td>
                                                                        <th style="width: 15%; text-align: left">
                                                                            NATIONALITY :</th>
                                                                        <td style="width: 15%">
                                                                            <?php echo $nationality ?></td>
                                                                        <th style="text-align: left; width: 15%">STATE OF
                                                                            ORIGIN :</th>
                                                                        <td style="text-align: left">
                                                                            <?php echo $stateorigin ?></td>


                                                                    </tr>


                                                                    <tr>
                                                                        <th style="text-align: left; width: 15%">
                                                                            FACULTY :</th>
                                                                        <td style="width: 35%; text-align: left" colspan="2">
                                                                            <?php echo $_SESSION['schname'] ?>
                                                                        </td>
                                                                        <th style="width: 15%; text-align: left">
                                                                            DEPARTMENT :</th>
                                                                        <td style="width: 35%" colspan="2">
                                                                            <?php echo $_SESSION['deptname'] ?>
                                                                        </td>

                                                                    </tr>

                                                                </tbody>
                                                            </table>

                                                            <table style="color: #0a0a0a; width: 98%; font-size: 9px">
                                                                <thead>
                                                                    <tr>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            Session</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            Sem</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            Courses</th>

                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            TCUR</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            TWGP</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            GPA</th>
                                                                        <th style='border-style:solid; border-width:thin; text-align:center'>
                                                                            CGPA</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>



                                                                    <?php if ($SessionCount >= 6) { ?>
                                                                        <!-- Year Three -->
                                                                        <?php
                                                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                        if ($conn->connect_error) {
                                                                            die("Connection failed: " . $conn->connect_error);
                                                                        }
                                                                        $cancelsess7 = false;
                                                                        $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[6]'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            $cancelsess7 = true;
                                                                        }
                                                                        $conn->close();
                                                                        ?>
                                                                        <?php if ($cancelsess7 == true) { ?>
                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[6] . "<br> Canceled Session";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    <img src="img/cancel.png" alt="logo" style="width: 300px; height: 250px;" />
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>

                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>

                                                                        <?php } else { ?>
                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[6] . "<br>" . $LevelArray[6] . "  Level";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    1
                                                                                </td>
                                                                                <td>
                                                                                    <?php

                                                                                    echo "<table style='border: 1px solid; width: 100%'>";
                                                                                    echo "<thead style='text-align:center;'>";
                                                                                    echo "<tr>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                    echo "</tr>";
                                                                                    echo "</thead>";
                                                                                    echo "<tbody>";
                                                                                    if ($absent1ST[6] != 0) {
                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                        if ($conn_stu->connect_error) {
                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                        }
                                                                                        $StuCurSess = str_ireplace("/", "_", $sessionarry[6]);
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '1ST' ORDER BY CCode";
                                                                                        $result = $conn_stu->query($sql);
                                                                                        $ct = $gp = $gpa = 0;
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {

                                                                                                $ccode = $row['CCode'];
                                                                                                $ctitle = $row['CTitle'];
                                                                                                $cunit = $row['CUnit'];
                                                                                                $grade = $row['grade'];
                                                                                                $total = $row['CA'] + $row['Exam'];
                                                                                                $ct = $ct + $cunit;
                                                                                                $gp = $gp + $row["point"];
                                                                                                $totunit = $totunit + $cunit;
                                                                                                $totgp = $totgp + $row["point"];

                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                            }
                                                                                            if ($ct > 0) {
                                                                                                $gpa = $gp / $ct;
                                                                                            } else {
                                                                                                $gpa = 0;
                                                                                            }

                                                                                            if ($totunit > 0) {
                                                                                                $cgpa = $totgp / $totunit;
                                                                                            } else {
                                                                                                $cgpa = 0;
                                                                                            }
                                                                                        }
                                                                                        $conn_stu->close();
                                                                                    } else {
                                                                                        $indSession = $sessionarry[6];
                                                                                        if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                            //$response_full = "DE";
                                                                                            echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                        } else {
                                                                                            $indSession = $sessionarry[6];
                                                                                            $semtake = "1ST";
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                        }
                                                                                    }
                                                                                    echo "</tbody>";
                                                                                    echo "</table>";

                                                                                    ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>

                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[6] . "<br>" . $LevelArray[6] . "  Level";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    2
                                                                                </td>
                                                                                <td>
                                                                                    <?php

                                                                                    echo "<table style='border: 1px solid; width: 100%'>";
                                                                                    echo "<thead style='text-align:center;'>";
                                                                                    echo "<tr>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                    echo "</tr>";
                                                                                    echo "</thead>";
                                                                                    echo "<tbody>";
                                                                                    if ($absent2ND[6] != 0) {
                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                        if ($conn_stu->connect_error) {
                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                        }
                                                                                        $StuCurSess = str_ireplace("/", "_", $sessionarry[6]);
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '2ND' ORDER BY CCode";
                                                                                        $result = $conn_stu->query($sql);
                                                                                        $ct = $gp = $gpa = 0;
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {

                                                                                                $ccode = $row['CCode'];
                                                                                                $ctitle = $row['CTitle'];
                                                                                                $cunit = $row['CUnit'];
                                                                                                $grade = $row['grade'];
                                                                                                $total = $row['CA'] + $row['Exam'];
                                                                                                $ct = $ct + $cunit;
                                                                                                $gp = $gp + $row["point"];
                                                                                                $totunit = $totunit + $cunit;
                                                                                                $totgp = $totgp + $row["point"];

                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                            }
                                                                                            if ($ct > 0) {
                                                                                                $gpa = $gp / $ct;
                                                                                            } else {
                                                                                                $gpa = 0;
                                                                                            }

                                                                                            if ($totunit > 0) {
                                                                                                $cgpa = $totgp / $totunit;
                                                                                            } else {
                                                                                                $cgpa = 0;
                                                                                            }
                                                                                        }
                                                                                        $conn_stu->close();
                                                                                    } else {
                                                                                        $indSession = $sessionarry[6];
                                                                                        if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                            //$response_full = "DE";
                                                                                            echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                        } else {
                                                                                            $indSession = $sessionarry[6];
                                                                                            $semtake = "2ND";
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                        }
                                                                                    }
                                                                                    echo "</tbody>";
                                                                                    echo "</table>";

                                                                                    ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>
                                                                        <?php } ?>

                                                                    <?php } ?>


                                                                    <?php if ($SessionCount >= 7) { ?>
                                                                        <!-- Year Three -->
                                                                        <?php
                                                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                        if ($conn->connect_error) {
                                                                            die("Connection failed: " . $conn->connect_error);
                                                                        }
                                                                        $cancelsess8 = false;
                                                                        $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[7]'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            $cancelsess8 = true;
                                                                        }
                                                                        $conn->close();
                                                                        ?>
                                                                        <?php if ($cancelsess8 == true) { ?>
                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[7] . "<br> Canceled Session";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    <img src="img/cancel.png" alt="logo" style="width: 300px; height: 250px;" />
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'></td>

                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>

                                                                        <?php } else { ?>
                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[7] . "<br>" . $LevelArray[7] . "  Level";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    1
                                                                                </td>
                                                                                <td>
                                                                                    <?php

                                                                                    echo "<table style='border: 1px solid; width: 100%'>";
                                                                                    echo "<thead style='text-align:center;'>";
                                                                                    echo "<tr>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                    echo "</tr>";
                                                                                    echo "</thead>";
                                                                                    echo "<tbody>";
                                                                                    if ($absent1ST[7] != 0) {
                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                        if ($conn_stu->connect_error) {
                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                        }
                                                                                        $StuCurSess = str_ireplace("/", "_", $sessionarry[7]);
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '1ST' ORDER BY CCode";
                                                                                        $result = $conn_stu->query($sql);
                                                                                        $ct = $gp = $gpa = 0;
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {

                                                                                                $ccode = $row['CCode'];
                                                                                                $ctitle = $row['CTitle'];
                                                                                                $cunit = $row['CUnit'];
                                                                                                $grade = $row['grade'];
                                                                                                $total = $row['CA'] + $row['Exam'];
                                                                                                $ct = $ct + $cunit;
                                                                                                $gp = $gp + $row["point"];
                                                                                                $totunit = $totunit + $cunit;
                                                                                                $totgp = $totgp + $row["point"];

                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                            }
                                                                                            if ($ct > 0) {
                                                                                                $gpa = $gp / $ct;
                                                                                            } else {
                                                                                                $gpa = 0;
                                                                                            }

                                                                                            if ($totunit > 0) {
                                                                                                $cgpa = $totgp / $totunit;
                                                                                            } else {
                                                                                                $cgpa = 0;
                                                                                            }
                                                                                        }
                                                                                        $conn_stu->close();
                                                                                    } else {
                                                                                        $indSession = $sessionarry[7];
                                                                                        if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                            //$response_full = "DE";
                                                                                            echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                        } else {
                                                                                            $indSession = $sessionarry[7];
                                                                                            $semtake = "1ST";
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                        }
                                                                                    }
                                                                                    echo "</tbody>";
                                                                                    echo "</table>";

                                                                                    ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>

                                                                            <tr>
                                                                                <td style=' border-style:solid; border-width:thin; padding-left: 1em' valign='top'>
                                                                                    <?php
                                                                                    echo $sessionarry[7] . "<br>" . $LevelArray[7] . "  Level";
                                                                                    ?>

                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'>
                                                                                    2
                                                                                </td>
                                                                                <td>
                                                                                    <?php

                                                                                    echo "<table style='border: 1px solid; width: 100%'>";
                                                                                    echo "<thead style='text-align:center;'>";
                                                                                    echo "<tr>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px; width:10%'>C Code</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Units</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Marks</th>";
                                                                                    echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; text-align:center; font-size: 10px; width:7%'>Grade</th>";

                                                                                    echo "</tr>";
                                                                                    echo "</thead>";
                                                                                    echo "<tbody>";
                                                                                    if ($absent2ND[7] != 0) {
                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                        if ($conn_stu->connect_error) {
                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                        }
                                                                                        $StuCurSess = str_ireplace("/", "_", $sessionarry[7]);
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SemTaken = '2ND' ORDER BY CCode";
                                                                                        $result = $conn_stu->query($sql);
                                                                                        $ct = $gp = $gpa = 0;
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {

                                                                                                $ccode = $row['CCode'];
                                                                                                $ctitle = $row['CTitle'];
                                                                                                $cunit = $row['CUnit'];
                                                                                                $grade = $row['grade'];
                                                                                                $total = $row['CA'] + $row['Exam'];
                                                                                                $ct = $ct + $cunit;
                                                                                                $gp = $gp + $row["point"];
                                                                                                $totunit = $totunit + $cunit;
                                                                                                $totgp = $totgp + $row["point"];

                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'> $ccode</td><td style='border-right-style:solid; border-right-width:thin; padding-left: 1em' valign='top'>$ctitle</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'>$cunit</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$total</td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'>$grade</td></tr>";
                                                                                            }
                                                                                            if ($ct > 0) {
                                                                                                $gpa = $gp / $ct;
                                                                                            } else {
                                                                                                $gpa = 0;
                                                                                            }

                                                                                            if ($totunit > 0) {
                                                                                                $cgpa = $totgp / $totunit;
                                                                                            } else {
                                                                                                $cgpa = 0;
                                                                                            }
                                                                                        }
                                                                                        $conn_stu->close();
                                                                                    } else {
                                                                                        $indSession = $sessionarry[7];
                                                                                        if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                            //$response_full = "DE";
                                                                                            echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                        } else {
                                                                                            $indSession = $sessionarry[7];
                                                                                            $semtake = "2ND";
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                        }
                                                                                    }
                                                                                    echo "</tbody>";
                                                                                    echo "</table>";

                                                                                    ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totunit ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo $totgp ?></td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($gpa, 2) ?>
                                                                                </td>
                                                                                <td style='border-style:solid; border-width:thin; text-align:center' valign='top'><?php echo number_format($cgpa, 2) ?>
                                                                                </td>
                                                                            </tr>
                                                                        <?php } ?>

                                                                    <?php } ?>
                                                                </tbody>
                                                            </table>
                                                            <?php if ($SessionCount <= 7) { ?>
                                                                <table>

                                                                    <body>
                                                                        <tr>
                                                                            <td style="font-size: 14px;"><strong>FINAL
                                                                                    CGPA:</strong>
                                                                                <?php echo number_format($cgpa, 2) ?>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="font-size: 14px;"><strong>Degree
                                                                                    Aarded:</strong>
                                                                                <?php echo $DegreeAward . " " . $deptname ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="font-size: 14px;"><strong>Class of
                                                                                    Degree:</strong>
                                                                                <?php echo $classdegree ?></td>
                                                                        </tr>
                                                                    </body>
                                                                </table>
                                                            <?php } ?>
                                                            <br><br>
                                                            <table style="width: 99%;">

                                                                <body>
                                                                    <tr>
                                                                        <th style="font-size: 14px; width:50%; text-align:center">
                                                                            ----------------------------------------<br><?php echo $_SESSION["Exam_Sign"] ?><br>
                                                                            Examination Officer</th>
                                                                        <th style="font-size: 14px; width:50%; text-align:center">
                                                                            ----------------------------------------<br><?php echo $_SESSION["HOD_Sign"] ?><br>
                                                                            Head of Department and Chief Examiner</th>
                                                                    </tr>

                                                                </body>
                                                            </table>
                                                            <h3 style="text-align: center;">Page 4 of <?php echo $totpages ?>
                                                            </h3>
                                                        </div>
                                                        <div class="row" style="text-align: right">
                                                            <br>
                                                            <input type="button" value="print to PDF" id="btnPrint4" class="btn-success" />
                                                        </div>

                                                    </div>
                                                <?php } ?>


                                            </div>
                                        </div>

                                    </section>

                                <?php } ?>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['Administrator'] !== "YES") {
    header('Location:home_staff.php');
}
?>



<?php

$staffid = $_SESSION['staffid'];
$dept = $_SESSION['deptcode'];
$user_names = $_SESSION['names'];
$schcode = $_SESSION['schcode'];

$corntsession = $_SESSION['corntsession'];
?>
<!DOCTYPE html>
<html>

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <link href="css/plugins/datapicker/datepicker3.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_SBD.js"></script>
</head>

<body>

    <div id="wrapper">


        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <?php
                    include_once 'includes/header2_staff.php';
                    ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-9">
                    <h2>Students Profile</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_staff.php">Home</a>
                        </li>
                        <li>
                            Profile
                        </li>
                        <li class="active">
                            <strong>Students Profile</strong>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="wrapper wrapper-content animated fadeInRight">

                <?php
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                if ($conn2->connect_error) {
                    die("Connection failed: " . $conn2->connect_error);
                }
                ?>


                <div class="row">

                    <form role="form" method="post" action="">
                        <div class="row">
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Department: </label>
                                    <div class="col-sm-8">
                                        <select class="form-control m-b" name="dept" required>
                                            <option value="">Select Item</option>
                                            <?php
                                            $sql = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptName";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $Code = $row["DeptCode"];
                                                    $Depart = $row["DeptName"];
                                                    echo " <option value='$Code'>$Depart</option>";
                                                }
                                            }

                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">State: </label>
                                    <div class="col-sm-8">
                                        <select class="form-control m-b" name="stateorigin">
                                            <option value="All">All</option>
                                            <?php
                                            $sql = "SELECT * FROM states ORDER BY state";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $state = $row["state"];
                                                    //$Depart = $row["Depart"];
                                                    echo " <option value='$state'>$state</option>";
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Level: </label>
                                    <div class="col-sm-8">
                                        <select class="form-control m-b" name="level1">
                                            <option value="All">All</option>
                                            <option value="100">100</option>
                                            <option value="200">200</option>
                                            <option value="300">300</option>
                                            <option value="400">400</option>
                                            <option value="500">500</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Gender: </label>
                                    <div class="col-sm-8">
                                        <select class="form-control m-b" name="sex">
                                            <option value="All">All</option>
                                            <option value="M">Male</option>
                                            <option value="F">Female</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="col-sm-4 control-label"></label>
                                    <div class="col-sm-8">
                                        <button class="btn btn-sm btn-primary pull-right m-t-n-xs" name="submit" type="submit"><strong>Submit</strong></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>

                    </form>
                </div>
                <div class="row">
                    <form role="form" method="post" action="">
                        <div class="col-md-2 text-left">

                        </div>
                        <div class="col-md-5 text-right">
                            <label class="control-label">Search with keyword in Matric No/Name/Department/State/LGA:
                            </label>
                        </div>
                        <div class="col-md-5">
                            <div class="input-group text-right">
                                <input type="text" placeholder="Search" name="Search" class="input-sm form-control">
                                <span class="input-group-btn">
                                    <button type="submit" name="submitsearch" class="btn btn-sm btn-primary">
                                        Go!</button> </span>
                            </div>
                        </div>
                    </form>
                </div>

                <hr>
                <?php if (isset($_POST["submit"])) { ?>
                    <?php
                    $_SESSION["IsSearch"] = false;
                    $dept = $_POST["dept"];
                    $stateorigin = $_POST["stateorigin"];
                    $sex = $_POST["sex"];
                    $level1 = $_POST["level1"];

                    $_SESSION["deptSess"] = $dept;
                    $_SESSION["stateoriginSess"] = $stateorigin;
                    $_SESSION["sexSess"] = $sex;
                    $_SESSION["level1Sess"] = $level1;

                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $Depart = ucwords(strtolower($row["DeptName"]));
                        }
                    }
                    if ($sex == "M") {
                        $gender = "Male";
                    } else if ($sex == "F") {
                        $gender = "Female";
                    } else {
                        $gender = "All";
                    }
                    ?>
                    <div class="row">

                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class="control-label">Department: <?php echo $Depart ?></label>

                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label class="control-label">State: <?php echo ucwords(strtolower($stateorigin)) ?></label>

                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label class="control-label">Level: <?php echo $level1 ?></label>

                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label class="control-label">Gender: <?php echo $gender ?></label>

                            </div>
                        </div>
                        <div class="col-sm-1">
                            <div class="form-group">
                                <form role="form" method="post" action="">
                                    <button class="btn btn-success btn-sm" name="viewlist" type="submit"><strong><i class="fa fa-list"></i> View in List</strong></button>
                                </form>
                            </div>
                        </div>

                    </div>


                    <div class="row">
                        <?php


                        if ($stateorigin == "All" && $sex == "All") {
                            $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND (status = 5 OR status = 6)";
                        } elseif ($stateorigin !== "All" && $sex == "All") {
                            $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND state = '$stateorigin' AND (status = 5 OR status = 6)";
                        } elseif ($stateorigin == "All" && $sex !== "All") {
                            $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND (gender = '$sex' OR gender = '$gender') AND (status = 5 OR status = 6)";
                        } elseif ($stateorigin !== "All" && $sex !== "All") {
                            $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND (gender = '$sex' OR gender = '$gender') AND state = '$stateorigin' AND (status = 5 OR status = 6)";
                        }

                        $result = $conn2->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $id = $row["id"];
                                $regid = $row["matric_no"];
                                $stuDept = $row["dept_code"];
                                $dept_db = $_SESSION['deptdb'] . strtolower($stuDept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }
                                if ($level1 == "All") {
                                    $sql3 = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$corntsession'";
                                } else {
                                    $sql3 = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$corntsession' AND StuLevel = '$level1'";
                                }
                                $result3 = $conn_stu->query($sql3);
                                if ($result3->num_rows > 0) {
                                    while ($row3 = $result3->fetch_assoc()) {
                                        $stuLevel = $row3["StuLevel"];
                                        if ($stuLevel == "600") {
                                            $stuLevel = "Spill Over";
                                        }
                                        $stdid = $row["stdid"];
                                        $Name1 = ucwords(strtolower($row["first_name"] . " " . $row["other_name"] . " " . $row["surname"]));
                                        $stateOfOrigin = ucwords(strtolower($row["state"]));
                                        $LGA = ucwords(strtolower($row["lga"]));
                                        $ContAdd = $row["c_address"];
                                        $phonenumber = $row["phone_number"];
                                        $DeptCode = $row["dept_code"];
                                        $Department = $row["department"];
                                        $email = $row["email"];

                                        $matpassport = str_replace("/", "_", $regid);

                        ?>
                                        <div class="col-lg-4">
                                            <div class="contact-box" style="display:block; height:250px;">


                                                <div class="col-sm-4">

                                                    <div class="text-center">


                                                        <?php echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='130'>";
                                                        ?>
                                                        <div class="m-t-xs font-bold"><strong><?php echo $Name1 ?></strong>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-8">
                                                    <b>Matric No:</b> <?php echo $regid ?><br>
                                                    <b>Department:</b> <?php echo $Department ?><br>
                                                    <b>Level:</b> <?php echo $stuLevel ?>; <b>Gender:</b> <?php echo $sex ?><br>
                                                    <b>State/LGA:</b> <?php echo $stateOfOrigin ?>/<?php echo $LGA ?><br>
                                                    <br>
                                                    <address>
                                                        <strong>Address</strong><br>
                                                        <abbr title="Contact Address"><i class="fa fa-envelope-o"></i></abbr> :
                                                        <?php echo ucwords(strtolower(substr($ContAdd, 0, 25))) ?>...<br>

                                                        <abbr title="Phone"><i class="fa fa-phone"></i></abbr> :
                                                        <?php echo $phonenumber ?><br>
                                                        <abbr title="email"><i class="fa fa-envelope"></i></abbr> :
                                                        <?php echo $email ?>

                                                    </address>
                                                    <div class="text-right">
                                                        <form role="form" method="post" action="ind_stu_biodata.php" class="form-horizontal">

                                                            <input type="hidden" name="id" value="<?php echo $id ?>">
                                                            <button class="btn btn-white btn-xs" name="view" type="submit" data-toggle="tooltip" title="View Record"><strong><i class="fa fa-folder"></i> View</strong></button>

                                                        </form>

                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>


                                            </div>
                                        </div>
                        <?php
                                    }
                                }
                                $conn_stu->close();
                            }
                        }

                        ?>
                    </div>
                <?php } ?>

                <?php if (isset($_POST["submitsearch"])) { ?>
                    <?php
                    $search = $_POST["Search"];
                    $_SESSION["searchSess"] = $search;
                    $_SESSION["IsSearch"] = true;
                    ?>
                    <div class="row">

                        <div class="col-sm-9">
                            <div class="form-group">
                                <label class="control-label">Searched with the keyword: <?php echo $search ?></label>

                            </div>
                        </div>

                        <div class="col-sm-3 text-right">
                            <form role="form" method="post" action="">
                                <button class="btn btn-success btn-sm" name="viewlist" type="submit"><strong><i class="fa fa-list"></i> View in List</strong></button>
                            </form>
                        </div>
                    </div>

                    <div class="row">
                        <?php


                        $sql = "SELECT * FROM std_data_view WHERE matric_no LIKE '%$search%' OR first_name LIKE '%$search%' OR other_name LIKE '%$search%' OR surname LIKE '%$search%' OR department LIKE '%$search%' OR state LIKE '%$search%' OR lga LIKE '%$search%' AND (status = 5 OR status = 6)";
                        //$sql = "SELECT * FROM std_data_view WHERE matric_no LIKE '%$search%'";
                        $result = $conn2->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $id = $row["id"];
                                $regid = $row["matric_no"];
                                $stuDept = $row["dept_code"];
                                $dept_db = $_SESSION['deptdb'] . strtolower($stuDept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }
                                $sql3 = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$corntsession'";
                                $result3 = $conn_stu->query($sql3);
                                if ($result3->num_rows > 0) {
                                    while ($row3 = $result3->fetch_assoc()) {
                                        $stuLevel = $row3["StuLevel"];
                                        if ($stuLevel == "600") {
                                            $stuLevel = "Spill Over";
                                        }
                                        $stdid = $row["stdid"];
                                        $Name1 = ucwords(strtolower($row["first_name"] . " " . $row["other_name"] . " " . $row["surname"]));
                                        $stateOfOrigin = ucwords(strtolower($row["state"]));
                                        $LGA = ucwords(strtolower($row["lga"]));
                                        $ContAdd = $row["c_address"];
                                        $phonenumber = $row["phone_number"];
                                        $DeptCode = $row["dept_code"];
                                        $Department = $row["department"];
                                        $email = $row["email"];


                                        $matpassport = str_replace("/", "_", $regid);

                        ?>
                                        <div class="col-lg-4">
                                            <div class="contact-box" style="display:block; height:250px;">


                                                <div class="col-sm-4">

                                                    <div class="text-center">


                                                        <?php echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='130'>"; ?>
                                                        <div class="m-t-xs font-bold"><strong><?php echo $Name1 ?></strong>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-8">
                                                    <b>Matric No:</b> <?php echo $regid ?><br>
                                                    <b>Department:</b> <?php echo $Department ?><br>
                                                    <b>Level:</b> <?php echo $stuLevel ?>; <b>Gender:</b> <?php echo $sex ?><br>
                                                    <b>State/LGA:</b> <?php echo $stateOfOrigin ?>/<?php echo $LGA ?><br>
                                                    <br>
                                                    <address>
                                                        <strong>Address</strong><br>
                                                        <abbr title="Contact Address"><i class="fa fa-envelope-o"></i></abbr> :
                                                        <?php echo ucwords(strtolower(substr($ContAdd, 0, 25))) ?>...<br>

                                                        <abbr title="Phone"><i class="fa fa-phone"></i></abbr> :
                                                        <?php echo $phonenumber ?><br>
                                                        <abbr title="email"><i class="fa fa-envelope"></i></abbr> :
                                                        <?php echo $email ?>

                                                    </address>
                                                    <div class="text-right">
                                                        <form role="form" method="post" action="ind_stu_biodata.php" class="form-horizontal">

                                                            <input type="hidden" name="id" value="<?php echo $id ?>">
                                                            <button class="btn btn-white btn-xs" name="view" type="submit" data-toggle="tooltip" title="View Record"><strong><i class="fa fa-folder"></i> View</strong></button>

                                                        </form>

                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>


                                            </div>
                                        </div>
                        <?php
                                    }
                                }
                                $conn_stu->close();
                            }
                        }

                        ?>
                    </div>

                <?php } ?>


                <?php if (isset($_POST["viewlist"])) { ?>
                    <?php
                    set_time_limit(500);
                    if ($_SESSION["IsSearch"] == true) {
                        $search = $_SESSION["searchSess"];
                        $GetTitle = "Searched with the keyword: " . $search;
                    } else {
                        $dept = $_SESSION["deptSess"];
                        $stateorigin = $_SESSION["stateoriginSess"];
                        $sex = $_SESSION["sexSess"];
                        $level1 = $_SESSION["level1Sess"];

                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $Depart = ucwords(strtolower($row["DeptName"]));
                            }
                        }
                        if ($sex == "M") {
                            $gender = "Male";
                        } else if ($sex == "F") {
                            $gender = "Female";
                        } else {
                            $gender = "All";
                        }
                        $GetTitle = "Department: " . $Depart . ", State: " . ucwords(strtolower($stateorigin)) . ", Level: " . $level1 . ", Gender: " . $gender;
                    }


                    $sno = 0;
                    ?>
                    <div class="row">
                        <?php if ($_SESSION["IsSearch"] == true) { ?>
                            <div class="col-sm-9">
                                <div class="form-group">
                                    <label class="control-label">Searched with the keyword: <?php echo $search ?></label>

                                </div>
                            </div>

                            <div class="col-sm-3 text-right">

                            </div>
                        <?php } else { ?>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class="control-label">Department: <?php echo $Depart ?></label>

                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class="control-label">State: <?php echo ucwords(strtolower($stateorigin)) ?></label>

                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="control-label">Level: <?php echo $level1 ?></label>

                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <label class="control-label">Gender: <?php echo $gender ?></label>

                                </div>
                            </div>
                            <div class="col-sm-1">

                            </div>
                        <?php } ?>
                    </div>
                    <div class="table-responsive">

                        <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups" frame="hsides" border="2">
                            <caption><?php echo $GetTitle ?></caption>
                            <colgroup align="center"></colgroup>
                            <colgroup align="left"></colgroup>
                            <colgroup span="2"></colgroup>
                            <colgroup span="3" align="center"></colgroup>
                            <thead>
                                <tr>

                                    <th>SNo</th>
                                    <th>Matric No</th>
                                    <th>Surname</th>
                                    <th>First Name</th>
                                    <th>Other Name</th>
                                    <th>Level</th>
                                    <th>JAMB No</th>
                                    <th>Sex</th>
                                    <th>Nationality</th>
                                    <th>State of Origin</th>
                                    <th>LGA</th>
                                    <th>Date of Birth</th>
                                    <th>Permanant Home Address</th>
                                    <th>Contact Address</th>
                                    <th>Phone No</th>
                                    <th>Marital Status</th>
                                    <th>Place of Birth</th>
                                    <th>email</th>

                                    <th>Blood Group</th>
                                    <th>Department</th>
                                    <th>Faculty/School</th>
                                    <th>Next of Kin Name</th>
                                    <th>Relationship to Next of Kin</th>
                                    <th>Next of Kin Address</th>
                                    <th>Next of Kin Phone Number</th>
                                    <th>Next of Kin email</th>

                                    <th>1<sup>st</sup> Exam Type:</th>
                                    <th>1<sup>st</sup> Exam Date:</th>
                                    <th>1<sup>st</sup> Exam Number:</th>
                                    <th>2<sup>nd</sup> Exam Type:</th>
                                    <th>2<sup>nd</sup> Exam Date:</th>
                                    <th>2<sup>nd</sup> Exam Number:</th>

                                    <th>Subject 1</th>
                                    <th>Subject 2</th>
                                    <th>Subject 3</th>
                                    <th>Subject 4</th>
                                    <th>Subject 5</th>
                                    <th>Subject 6</th>
                                    <th>Subject 7</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($_SESSION["IsSearch"] == true) {
                                    $sql = "SELECT * FROM std_data_view WHERE matric_no LIKE '%$search%' OR first_name LIKE '%$search%' OR other_name LIKE '%$search%' OR surname LIKE '%$search%' OR department LIKE '%$search%' OR state LIKE '%$search%' OR lga LIKE '%$search%' AND (status = 5 OR status = 6)";
                                } else {
                                    if ($stateorigin == "All" && $sex == "All") {
                                        $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND (status = 5 OR status = 6)";
                                    } elseif ($stateorigin !== "All" && $sex == "All") {
                                        $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND state = '$stateorigin' AND (status = 5 OR status = 6)";
                                    } elseif ($stateorigin == "All" && $sex !== "All") {
                                        $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND (gender = '$sex' OR gender = '$gender') AND (status = 5 OR status = 6)";
                                    } elseif ($stateorigin !== "All" && $sex !== "All") {
                                        $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND (gender = '$sex' OR gender = '$gender') AND state = '$stateorigin' AND (status = 5 OR status = 6)";
                                    }
                                }
                                $result = $conn2->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $id = $row["id"];
                                        $regid = $row["matric_no"];
                                        $stuDept = $row["dept_code"];
                                        $dept_db = $_SESSION['deptdb'] . strtolower($stuDept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }
                                        if ($level1 == "All") {
                                            $sql3 = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$corntsession'";
                                        } else {
                                            $sql3 = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$corntsession' AND StuLevel = '$level1'";
                                        }
                                        $result3 = $conn_stu->query($sql3);
                                        if ($result3->num_rows > 0) {
                                            while ($row3 = $result3->fetch_assoc()) {
                                                $stuLevel = $row3["StuLevel"];
                                                if ($stuLevel == "600") {
                                                    $stuLevel = "Spill Over";
                                                }
                                            }


                                            $sno++;
                                            $regid = $row["matric_no"];
                                            $surname = $row["surname"];
                                            $firstname = $row["first_name"];
                                            $othername = $row["other_name"];
                                            $jambno = $row["jamb_appl_no"];
                                            $stateorigin = $row["state"];
                                            $lga = $row["lga"];

                                            $sex = $row["gender"];
                                            $permaddres = $row["p_address"];
                                            $contaddres = $row["c_address"];
                                            $nationality = $row["nationality"];
                                            $dob = $row["dob"];
                                            $pob = "XX";
                                            $phone1 = $row["phone_number"];
                                            $maried = $row["marital_status"];
                                            $email = $row["email"];

                                            $blood_group = $row["blood_group"];
                                            $deptname = $row["department"];
                                            $schname = $row["school"];
                                            $next_name = $row["next_name"];
                                            $next_rel = $row["next_rel"];
                                            $next_addr = $row["next_addr"];
                                            $next_phone = $row["next_phone"];
                                            $next_email = $row["next_email"];

                                            $f_examtype = $row['f_examtype'];
                                            $f_examdate = $row['f_examdate'];
                                            $f_examno = $row['f_examno'];
                                            $s_examtype = $row['s_examtype'];
                                            $s_examdate = $row['s_examdate'];
                                            $s_examno = $row['s_examno'];

                                            $s_rslt1 = $row['s_rslt1'];
                                            $s_rslt2 = $row['s_rslt2'];
                                            $s_rslt3 = $row['s_rslt3'];
                                            $s_rslt4 = $row['s_rslt4'];
                                            $s_rslt5 = $row['s_rslt5'];
                                            $s_rslt6 = $row['s_rslt6'];
                                            $s_rslt7 = $row['s_rslt7'];

                                            echo "<tr><td>$sno</td><td>$regid</td><td>$surname</td><td>$firstname</td><td>$othername</td><td>$stuLevel</td><td>$jambno</td><td>$sex</td><td>$nationality</td><td>$stateorigin</td><td>$lga</td><td>$dob</td><td>$permaddres</td><td>$contaddres</td><td>$phone1</td><td>$maried</td><td>$pob</td><td>$email</td>";
                                            echo "<td>$blood_group</td><td>$deptname</td><td>$schname</td><td>$next_name</td><td>$next_rel</td><td>$next_addr</td><td>$next_phone</td><td>$next_email</td>";
                                            echo "<td>$f_examtype</td><td>$f_examdate</td><td>$f_examno</td><td>$s_examtype</td><td>$s_examdate</td><td>$s_examno</td>";
                                            echo "<td>$s_rslt1</td><td>$s_rslt2</td><td>$s_rslt3</td><td>$s_rslt4</td><td>$s_rslt5</td><td>$s_rslt6</td><td>$s_rslt7</td></tr>";
                                        }
                                    }
                                }


                                ?>
                            </tbody>
                        </table>

                    </div>
                    <br>
                    <div style="text-align: right">
                        <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                    </div>
                <?php } ?>
                <?php
                $conn->close();
                $conn2->close();

                ?>
            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">
            <?php
            include_once 'includes/aside_right.php';
            ?>
        </div>

    </div>




    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>

    <!-- Data picker -->
    <script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>

    <script src="js/getexcel/tableToExcel_R.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
            $("select.state").change(function() {
                var selectedState = $(".state option:selected").val();
                $.ajax({
                    type: "POST",
                    url: "ajax_save_rec/lga_ddown.php",
                    data: {
                        state: selectedState
                    }
                }).done(function(data) {
                    $("#getlga").html(data);
                });
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("select.state").change(function() {
                var selectedState = $(".state option:selected").val();
                $.ajax({
                    type: "POST",
                    url: "ajax_save_rec/lga_ddown2.php",
                    data: {
                        state: selectedState
                    }
                }).done(function(data) {
                    $("#getlga2").html(data);
                });
            });
        });
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $("select.scale").change(function() {
                var selectedState = $(".scale option:selected").val();
                $.ajax({
                    type: "POST",
                    url: "ajax_save_rec/grade_level.php",
                    data: {
                        scale: selectedState
                    }
                }).done(function(data) {
                    $("#getgrade").html(data);
                });
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("select.scale").change(function() {
                var selectedState = $(".scale option:selected").val();
                $.ajax({
                    type: "POST",
                    url: "ajax_save_rec/grade_level2.php",
                    data: {
                        scale: selectedState
                    }
                }).done(function(data) {
                    $("#getgrade2").html(data);
                });
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("select.hqualification").change(function() {
                var selectedState = $(".hqualification option:selected").val();
                $.ajax({
                    type: "POST",
                    url: "ajax_save_rec/otherquali.php",
                    data: {
                        hqualification: selectedState
                    }
                }).done(function(data) {
                    $("#getotherquali").html(data);
                });
            });
        });
    </script>


    <script>
        $('#data_1 .input-group.date').datepicker({
            todayBtn: "linked",
            keyboardNavigation: false,
            forceParse: false,
            calendarWeeks: true,
            autoclose: true
        });
    </script>
</body>

</html>
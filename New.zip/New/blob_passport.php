<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>


</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Upload Courses</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-upload"></i>
                                </a>
                            </li>
                            <li><span>Upload Courses</span></li>

                        </ol>


                    </div>
                </header>

                <!-- start: page -->

                <div class="row">

                    <div class="col-lg-12  col-md-12">

                        <div class="col-lg-12">
                            <section class="panel panel-success">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>

                                    <h2 class="panel-title">Upload Courses</h2>
                                </header>
                                <div class="panel-body">
                                    <?php

                                    if (count($_FILES) > 0) {
                                        if (is_uploaded_file($_FILES['userImage']['tmp_name'])) {

                                            $imgData = addslashes(file_get_contents($_FILES['userImage']['tmp_name']));
                                            $imageProperties = getimageSize($_FILES['userImage']['tmp_name']);

                                            $sql = "INSERT INTO mat (imageType, imageData) VALUES('{$imageProperties['mime']}', '{$imgData}')";
                                            //$current_id = mysqli_query($conn10, $sql) or die("<b>Error:</b> Problem on Image Insert<br/>" . mysqli_error($conn));
                                            $current_id = $conn10->query($sql);
                                        }
                                    }
                                    ?>
                                    <form name="frmImage" enctype="multipart/form-data" action="" method="post" class="frmImageUpload">
                                        <label>Upload Image File:</label><br /> <input name="userImage" type="file" class="inputFile" />
                                        <input type="submit" value="Submit" class="btnSubmit" />
                                    </form>

                                </div>
                                <?php
                                $sql = "SELECT imageType, imageData FROM mat WHERE id=10";
                                $sth = $conn10->query($sql);
                                $result = mysqli_fetch_array($sth);

                                echo '<img src="data:image/jpeg;base64,' . base64_encode($result['imageData']) . '"/>';
                                ?>


                            </section>


                        </div>

                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-autosize/jquery.autosize.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

</body>

</html>
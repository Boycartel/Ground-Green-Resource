<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_List.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Download Courses</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Download
                            </li>

                            <li class="active">
                                <strong>Download Courses</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }
?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Download Courses
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form class="form-horizontal" method="post">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-7">
                                                <select class="form-control" style="color:#000000" name="SelDept">
                                                    <option value="All">All</option>
                                                    <?php
                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $DeptCode = $row["DeptCode"];
                                                            $DeptName = $row["DeptName"];
                                                            echo "<option value='$DeptCode'>$DeptName</option>";
                                                        }
                                                    }
                                                    $sql = "SELECT * FROM schoolname ORDER BY SchName";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $SchCode = $row["SchCode"];
                                                            $SchName = $row["SchName"];
                                                            echo "<option value='$SchCode'>$SchName</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>


                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">

                                            <label class="control-label col-lg-5" for="regid">Select Curriculum:</label>
                                            <div class="col-lg-7">
                                                <select name="SelCurri" class="form-control" style="color:#000000"
                                                    id="SelCurri">
                                                    <option value="All">All</option>
                                                    <?php
                                                    $sql = "SELECT * FROM sch_curriculum ORDER BY curri_Title";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $curri_Code = $row["curri_Code"];
                                                            $curri_Title = $row["curri_Title"];
                                                            echo "<option value='$curri_Code'>$curri_Title</option>";
                                                        }
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-9">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1">

                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"])) { ?>
                                <?php
                                    $SelDept = $_POST['SelDept'];
                                    $SelCurri = $_POST['SelCurri'];

                                    ?>
                                <div class="col-lg-12  col-md-12">

                                    <div class="table-responsive">

                                        <?php
                                            set_time_limit(500);
                                            $GetTitle = "Department: " . $SelDept . ", Curriculum: " . $SelCurri;
                                            //$GetTitle = "";
                                            $sno = 0;
                                            ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                            rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>

                                                    <th>SNo</th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Credit Unit</th>
                                                    <th>Semester</th>
                                                    <th>Department/Faculty</th>
                                                    <th>Curriculum</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    if ($SelDept == "All") {
                                                        if ($SelCurri == "All") {
                                                            $sql = "SELECT * FROM gencoursesupload ORDER BY Department, C_codding";
                                                        } else {
                                                            $sql = "SELECT * FROM gencoursesupload WHERE type1 = '$SelCurri' ORDER BY Department, C_codding";
                                                        }
                                                    } else {
                                                        if ($SelCurri == "All") {
                                                            $sql = "SELECT * FROM gencoursesupload WHERE Department = '$SelDept' ORDER BY Department, C_codding";
                                                        } else {
                                                            $sql = "SELECT * FROM gencoursesupload WHERE Department = '$SelDept' AND type1 = '$SelCurri' ORDER BY Department, C_codding";
                                                        }
                                                    }


                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {

                                                            $C_codding = $row["C_codding"];
                                                            $C_title = $row["C_title"];
                                                            $credit = $row["credit"];
                                                            $semester = $row["semester"];
                                                            $Department = $row["Department"];
                                                            $type1 = $row["type1"];

                                                            $sql2 = "SELECT * FROM deptcoding WHERE DeptCode = '$Department'";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $DeptName = $row2["DeptName"];
                                                                }
                                                            } else {
                                                                $sql2 = "SELECT * FROM schoolname WHERE SchCode = '$Department'";
                                                                $result2 = $conn->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $DeptName = $row2["SchName"];
                                                                    }
                                                                }
                                                            }

                                                            $sql2 = "SELECT * FROM sch_curriculum WHERE curri_Code = '$type1'";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $curri_Title = $row2["curri_Title"];
                                                                }
                                                            }

                                                            $sno++;
                                                            echo "<tr><td>$sno</td><td>$C_codding</td><td>$C_title</td><td>$credit</td><td>$semester</td><td>$DeptName</td><td>$curri_Title</td></tr>\n";
                                                        }
                                                    }
                                                    ?>
                                            </tbody>
                                        </table>


                                    </div>
                                    <br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                            class="btn btn-primary">Download</a>
                                    </div>
                                </div>



                                <?php } ?>
                            </div>


                        </div>
                    </div>

                    <?php
$conn->close();
$conn2->close();
?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
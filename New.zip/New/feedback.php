<?php
require_once 'includes/db_connect2.php';
//require_once 'includes/check_validity.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php
            if ($_SESSION['usertype'] == "Student") {
                $stutype = $_SESSION['stutype'];
                if ($stutype == "UG") {
                    include_once 'includes/aside_menu.php';
                } else {
                    include_once 'includes/pg_aside_menu.php';
                }
            } else {

                include_once 'includes/aside_menu_staff.php';
            }

            ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php

                    if ($_SESSION['usertype'] == "Student") {
                        $stutype = $_SESSION['stutype'];
                        if ($stutype == "UG") {
                            include_once 'includes/header2.php';
                        } else {
                            include_once 'includes/header2_pg.php';
                        }
                    } else {

                        include_once 'includes/header2_staff.php';
                    }

                    ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Portal Feedback</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Portal Feedback</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Portal Feedback
                        </div>
                        <div class="panel-body">

                            <?php

                            //$regid = $_SESSION["regid"];
                            $names = $_SESSION["names"];
                            $email = $_SESSION['email'];
                            $subject = "XX";
                            $usertype = "";
                            $info = "";

                            $D = exec('date /T');
                            $T = exec('time /T');
                            $DT = strtotime(str_replace("/", "-", $D . " " . $T));
                            $prestimefull = date("d/m/Y h:ia", $DT);

                            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                $message = $_POST["content"];
                                

                                if ($_SESSION['usertype'] == "Student") {
                                    $usertype = $_SESSION["regid"];
                                } else {

                                    $usertype = $_SESSION['staffid'];
                                }
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                if (!empty($message)) {
                                    $sql = "INSERT INTO feedback (regid, fname, email, subject, message, date1) VALUES ('$usertype', '$names', '$email', '$subject', '$message', '$prestimefull')";
                                    $result = $conn->query($sql);

                                    $info = "Message Saved";
                                }
                                //header('Location: ../Home_Stu.php');
                                $conn->close();
                            }
                            ?>
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="form-group">
                                        <label class="control-label col-lg-2" for="content"></label>
                                        <div class="col-lg-10">
                                            <strong style="color:#00C"><?php echo $info ?></strong>
                                        </div>
                                    </div>
                                    <!-- Content -->
                                    <div class="form-group">
                                        <label class="control-label col-lg-2" for="content">Message</label>
                                        <div class="col-lg-10">
                                            <textarea class="form-control" name="content" id="content"></textarea>
                                        </div>
                                    </div>

                                    <!-- Buttons -->
                                    <div class="form-group">
                                        <!-- Buttons -->
                                        <div class="col-lg-offset-2 col-lg-9">
                                            <button type="submit" class="btn btn-primary">Submit</button>

                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-md-1">
                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
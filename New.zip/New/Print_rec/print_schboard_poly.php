<?php
require_once '../includes/db_connect2.php';
?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?> Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword"
        content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="../img/logo.ico">



    <style type="text/css">
    table {
        page-break-inside: avoid;
    }

    h1,
    h2,
    h3,
    h4,
    h5 {
        page-break-after: avoid;
    }

    @page {
        size: A4 landscape;
        font-size: small;
    }

    @page :left {
        margin-left: 1cm;
    }

    @page :right {
        margin-left: 2cm;
    }
    </style>


    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>

</head>

<body>
    <section class="body">


        <div class="inner-wrapper">
            <div class="row" id="printableArea" style="width: auto; float: none">


                <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                            if ($conn2->connect_error) {
                                die("Connection failed: " . $conn2->connect_error);
                            }
                            
                $_SESSION['sn'] = 0;

                $deptname = "";
                set_time_limit(1000);
                $DegType = $_SESSION['DegType'];

                if (isset($_POST["print_appr"])) {
                    $getdept = $_SESSION['deptcode'];
                    $getsession = $_SESSION['getsession_sctny'];
                    $getsemester = $_SESSION['getsemester_sctny'];
                    $getlevel = $_SESSION['getlevel_sctny'];
                    $getdeptoption = $_SESSION['getdeptoption'];
                    $curriculum = $_SESSION['curriculum'];
                    $getgroup = $_SESSION['getgroup'];
                } else {
                    $getdept = $_SESSION['dept_sctny'];
                    $getsession = $_SESSION['getsession_sctny'];
                    $getsemester = $_SESSION['getsemester_sctny'];
                    $getlevel = $_SESSION['getlevel_sctny'];
                    $getgroup = $_SESSION['getgroup'];
                    $dept_option = $_SESSION['dept_option'];
                }

                if ($_SESSION['getlevel_sctny'] == "100" || $_SESSION['getlevel_sctny'] == "200") {
                    $prog = "ND";
                } else {
                    $prog = "HND";
                }

                $schcode = $_SESSION['schcode'];
                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["HOD_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'Examiner' OR cat = 'ExamLAdvice' OR cat = 'PGExam')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["Exam_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE SchCode = '$schcode' AND (cat = 'Dean' OR cat = 'HODDean' OR cat = 'PGExam')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["Dean_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT DeptName, DeptCode, School FROM deptcoding WHERE DeptCode = '$getdept'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $deptname = $row["DeptName"];
                        $schcode = $row["School"];
                    }
                }

                $sql = "SELECT * FROM schoolname WHERE SchCode = '$schcode'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $schname = $row["SchName"];
                    }
                }

                if ($_SESSION['getlevel_sctny'] == 100 || $_SESSION['getlevel_sctny'] == 300) {
                    if ($getsemester == "1ST") {
                        $contactSem = "1<sup>st</sup>";
                    } else {
                        $contactSem = "2<sup>nd</sup>";
                    }
                } elseif ($_SESSION['getlevel_sctny'] == 200 || $_SESSION['getlevel_sctny'] == 400) {
                    if ($getsemester == "1ST") {
                        $contactSem = "3<sup>rd</sup>";
                    } else {
                        $contactSem = "4<sup>th</sup>";
                    }
                }

                ?>
                <section class="panel panel-success">

                    <div class="panel-body">
                        <br>
                        <div class="col-lg-12" id="printableArea" style="width: auto; float: none">
                            <?php
                            unset($LblCodeArray);
                            $LblCodeArray[] = "";
                            unset($CourseCodeArray);
                            $CourseCodeArray[] = "";
                            unset($CourseUnitArray);
                            $CourseUnitArray[] = "";

                            unset($CourseCodeArray2);
                            $CourseCodeArray2[] = "";

                            $countCCode = 0;
                            $countCCode2 = 0;
                            $deptgencourses = $getdept . "_gencourses";

                            $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                            if ($conn_stu->connect_error) {
                                die("Connection failed: " . $conn_stu->connect_error);
                            }

                            $sql = "SELECT DISTINCT CCode, session1, Level1, DeptCode, SemTaken, levelCode, split_two, CUnit FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {

                                    $C_codding = $row["CCode"];

                                    $sql2 = "SELECT Core, semester FROM gencourses WHERE C_codding = '$C_codding'";
                                    $result2 = $conn_stu->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $Core = $row2["Core"];
                                            $semester = $row2["semester"];
                                        }
                                    }
                                    if ($semester == $getsemester) {
                                        $countCCode++;
                                        $CourseCodeArray[$countCCode] = $row["CCode"];
                                        $CCode = $row["split_two"];
                                        $LblCodeArray[$countCCode] = $CCode;
                                        if ($Core == "YES") {
                                            $CourseUnitArray[$countCCode] = $row["CUnit"] . '  C';
                                        } else {
                                            $CourseUnitArray[$countCCode] = $row["CUnit"] . '  E';
                                        }
                                    }
                                }
                            }


                            $sql = "SELECT DISTINCT CCode, session1, Level1, DeptCode, SemTaken, levelCode, split_two, CUnit FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {

                                    $C_codding = $row["CCode"];

                                    $sql2 = "SELECT Core, semester FROM gencourses WHERE C_codding = '$C_codding'";
                                    $result2 = $conn_stu->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $Core = $row2["Core"];
                                            $semester = $row2["semester"];
                                        }
                                    }
                                    if ($semester !== $getsemester) {
                                        $countCCode++;
                                        $CourseCodeArray[$countCCode] = $row["CCode"];
                                        $CCode = $row["split_two"];
                                        $LblCodeArray[$countCCode] = $CCode;
                                        if ($Core == "YES") {
                                            $CourseUnitArray[$countCCode] = $row["CUnit"] . '  C';
                                        } else {
                                            $CourseUnitArray[$countCCode] = $row["CUnit"] . '  E';
                                        }
                                    }
                                }
                            }

                            if ($_SESSION['getlevel_sctny'] == 100) {
                                $gLevel = "ND I";
                            } elseif ($_SESSION['getlevel_sctny'] == 200) {
                                $gLevel = "ND II";
                            } elseif ($_SESSION['getlevel_sctny'] == 300) {
                                $gLevel = "HND I";
                            } elseif ($_SESSION['getlevel_sctny'] == 400) {
                                $gLevel = "HND II";
                            }

                            $numbofStu = 0;
                            $Arrayregid[] = "";
                            $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND stu_group = '$getgroup' AND DeptOpt = '$dept_option' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";
                            $result = $conn_stu->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $numbofStu++;
                                    $Arrayregid[$numbofStu] = $row["Regn"];
                                    $codeyearadmt = substr($row["yearadmt"], 2, 2);
                                }
                            }
                            //$numPage = $numbofStu / 8;

                            if ($numbofStu <= 8) {
                                $inino = 1;
                                $finalno = $numbofStu;
                                $nopg = 1;
                            } else {
                                $inino = 1;
                                $finalno = 8;
                                $nopg = intdiv($numbofStu, 8);
                                if (($numbofStu % 8) > 0) {
                                    $nopg = $nopg + 1;
                                }
                            }

                            if ($getlevel == 100 || $getlevel == 200) {
                                $progtype = "ND";
                            } else {
                                $progtype = "HD";
                            }

                            if ($getgroup == "G10" || $getgroup == "G20") {
                                $Gcode = $getgroup;
                            } else {
                                $Gcode = str_replace("0", "", $getgroup);
                            }

                            if ($getgroup == "NG") {
                                $Gcode = "G1";
                            }
                            $stugroupcode = strtoupper($getdept) . $progtype . $codeyearadmt . $Gcode;
                            //echo $numbofStu;
                            ?>
                            <style>
                            table,
                            th,
                            td {

                                border-collapse: collapse;
                                text-align: center;

                            }

                            table,
                            td {
                                font-size: 10px;
                            }
                            </style>

                            <?php for ($pg = 1; $pg <= $nopg; $pg++) { ?>

                            <?php $pagediff = $finalno - $inino; ?>
                            <table style="width: 99%; border:2em" style="border-collapse: collapse">
                                <thead>
                                    <tr>
                                        <th colspan="2">
                                            <img src="../img/logo.ico" height="70" width="70" alt="Logo" />
                                        </th>
                                        <th colspan="<?php echo $countCCode + 7 ?>" style="text-align:left">
                                            <strong
                                                style="font-size: x-large;"><?php echo $_SESSION['instname'] ?></strong><br>SCHOOL
                                            OF
                                            <?php echo strtoupper($schname) ?>, DEPARTMENT OF
                                            <?php echo strtoupper($deptname) ?><br>

                                            <?php if ($_SESSION['getlevel_sctny'] == 100 || $_SESSION['getlevel_sctny'] == 200) { ?>
                                            NATIONAL DIPLOMA PROGRAMME, *
                                            <?php } else { ?>
                                            HIGHER NATIONAL DIPLOMA PROGRAMME, *
                                            <?php } ?>
                                            (<?php echo $gLevel ?> [FT-*/REGULAR]),
                                            <?php echo $contactSem ?>
                                            SEMESTER, <?php echo $_SESSION['getsession_sctny']; ?> SESSION<br><strong
                                                style="font-size: small;">EXAMINATION RESULTS
                                                BROADSHEET REPORT - MONTH/YEAR OF GRADUATION</strong>


                                        </th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="border: 1px solid;">Date: <?php echo date("d F, Y") ?>
                                        </th>
                                        <th colspan="<?php echo $countCCode ?>"
                                            style="border: 1px solid; font-size:small">Courses
                                            Examined
                                            (Core and Electives)</th>
                                        <th colspan="5" style="border: 1px solid;">Summaries</th>
                                        <th colspan="2" style="border: 2px solid;"><?php echo $stugroupcode ?></th>
                                    </tr>
                                    <tr>
                                        <th colspan="2" style="border: 1px solid; text-align:right">Course<br> Code<br>
                                            Units/Status</th>
                                        <?php for ($i = 1; $i <= $countCCode; $i++) { ?>
                                        <th style="border: 1px solid;">
                                            <?php echo $LblCodeArray[$i] . "<br>" . $CourseUnitArray[$i] ?></th>
                                        <?php } ?>
                                        <th colspan="5" style="border: 1px solid;">Previous Semesters<br>
                                            Current Semester<br>
                                            Cumulative</th>
                                        <th colspan="2" style="border: 1px solid;">Academic
                                            Standing</th>

                                    </tr>
                                    <tr>
                                        <th style="border: 1px solid;">S/ No</th>
                                        <th style="border: 1px solid;">Matric_No/ Name</th>
                                        <th colspan="<?php echo $countCCode ?>"
                                            style="border: 1px solid; font-size:small">Scores (%),
                                            Letter
                                            Grades and Weighted Grade
                                            Points</th>


                                        <th style="border: 1px solid;">TUA</th>
                                        <th style="border: 1px solid;">TUP</th>
                                        <th style="border: 1px solid;">TGP</th>
                                        <th style="border: 1px solid;">GPA</th>
                                        <th style="border: 1px solid;">TUO</th>
                                        <th style="border: 1px solid;">Past</th>

                                        <th style="border: 1px solid;">Curr</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $sno = 0;
                                        /* $DEFCount = 0;
                                        $IGSCount = 0;
                                        $SP1Count = 0;
                                        $SP2Count = 0;
                                        $PCount = 0;
                                        $DLCount = 0;
                                        $VCLCount = 0;
                                        $Ten88Count = 0;
                                        $BL2Count = 0; */


                                        for ($x = $inino; $x <= $finalno; $x++) {
                                            $matno = $Arrayregid[$x];

                                            $sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND stu_group = '$getgroup' AND DeptOpt = '$dept_option' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";
                                            $result = $conn_stu->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $sno++;
                                                    $regid = $row["Regn"];
                                                    $names = $row["Name1"];
                                                    $fname = strtoupper($row["fname"]);
                                                    $sname = strtoupper($row["sname"]);
                                                    $oname = strtoupper($row["oname"]);
                                                    if ($row["sex"] == "Male") {
                                                        $sex = "M";
                                                    } elseif ($row["sex"] == "Female") {
                                                        $sex = "F";
                                                    } else {
                                                        $sex = $row["sex"];
                                                    }
                                                    $id = $row["sn"];
                                                    $aproval = $row['board_aproval'];
                                                    $coment = $row["board_comment"];

                                                    $defout = $def = $out = $rmk = $grade = "";


                                                    $unit = $ptct = $ptcp = $pgp = $pcgpa = $stct = $stcp = $sgp = $scgpa = $tct = $tcp = $tgp = $cgpa = 0;

                                                    $ptct = $row['PCT'];
                                                    $ptcp = $row['PCP'];
                                                    $pgp = $row['PGP'];
                                                    $pcgpa = $row['PCGPA'];

                                                    $stct = $row['SCT'];
                                                    $stcp = $row['SCP'];
                                                    $sgp = $row['SGP'];
                                                    $scgpa = $row['SGPA'];
                                                    $tct = $row['TCT'];
                                                    $tcp = $row['TCP'];
                                                    $tgp = $row['CGP'];
                                                    $cgpa = $row['CGPA'];

                                                    $sem_C_F = $row['sem_C_F'];
                                                    $prev_C_F = $row['prev_C_F'];
                                                    $cum_C_F = $row['cum_C_F'];
                                                    $numb_Course_failed = $row['numb_Course_failed'];

                                                    $rmk = $row['RMK'];
                                                    $defout = $row['def_out'];

                                                    $defout1ST = "";
                                                    if ($getsemester == "2ND") {
                                                        $sql2 = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '1ST' AND Regn = '$regid'";
                                                        $result2 = $conn_stu->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $defout1ST = $row2['def_out'];
                                                            }
                                                        }
                                                    }

                                                    if ($scgpa >= 3.495) {
                                                        if (empty($defout)) {
                                                            $dclasscode = "RHL";
                                                            $COcourses = "PASSED";
                                                        } else {
                                                            $COcourses = $defout;
                                                            $dclasscode = "COV";
                                                        }
                                                    } elseif ($scgpa >= 3.245) {
                                                        if (empty($defout)) {
                                                            $dclasscode = "DHL";
                                                            $COcourses = "PASSED";
                                                        } else {
                                                            $COcourses = $defout;
                                                            $dclasscode = "COV";
                                                        }
                                                    } elseif ($scgpa >= 2) {
                                                        if ($cgpa >= 2) {
                                                            if ($defout == "") {
                                                                $dclasscode = "PAS";
                                                                $COcourses = "PASSED";
                                                            } else {
                                                                $COcourses = $defout;
                                                                $dclasscode = "COV";
                                                            }
                                                        } else {
                                                            if ($defout == "") {
                                                                $COcourses = "PASSED";
                                                            } else {
                                                                $COcourses = $defout;
                                                            }
                                                            $dclasscode = "WAR";
                                                        }
                                                    } else {
                                                        if ($cgpa >= 2) {
                                                            if ($defout == "") {
                                                                $COcourses = "PASSED";
                                                            } else {
                                                                $COcourses = $defout;
                                                            }
                                                            $dclasscode = "WAR";
                                                        } else {
                                                            if ($defout == "") {
                                                                $COcourses = "PASSED";
                                                            } else {
                                                                $COcourses = $defout;
                                                            }
                                                            $dclasscode = "PRO";
                                                        }
                                                    }


                                                    if ($row["no_semester"] > 3) {
                                                        if ($defout == "") {
                                                            include 'modulesInSess/classofdegree_inc.php';
                                                            $dclass = $classdegree;
                                                            $dclasscode = $classdegree_code;
                                                        }
                                                    }


                                                    if ($row["no_semester"] > 3) {
                                                        if ($pcgpa >= 3.5) {

                                                            $prevdclasscode = "D";
                                                        } elseif ($pcgpa >= 3) {

                                                            $prevdclasscode = "U/C";
                                                        } elseif ($pcgpa >= 2.5) {

                                                            $prevdclasscode = "L/C";
                                                        } elseif ($pcgpa >= 2) {

                                                            $prevdclasscode = "PAS";
                                                        } else {

                                                            $prevdclasscode = "F";
                                                        }
                                                    } else {
                                                        $prevdclasscode = "PAS";
                                                    }

                                                    if ($defout1ST == "") {
                                                        if ($pcgpa >= 3.495) {
                                                            $prevdclasscode = "RHL";
                                                        } elseif ($pcgpa >= 3.245) {
                                                            $prevdclasscode = "DHL";
                                                        } else {
                                                            $prevdclasscode = "PAS";
                                                        }
                                                    } else {
                                                        $prevdclasscode = "COV";
                                                    }
                                                    if ($pcgpa < 1.5) {
                                                        $prevdclasscode = "PRO";
                                                    } elseif ($pcgpa < 2) {
                                                        $prevdclasscode = "WAR";
                                                    }

                                                    if ($row["no_semester"] == 1) {
                                                        $prevdclasscode = "-";
                                                    }

                                                    if ($row2["no_semester"] > 1) {
                                                        if ($scgpa < 1.5 && $cgpa < 1) {
                                                            $dclasscode++;
                                                        }
                                                    }




                                                    $totalArray[] = "";
                                                    $gradeArray[] = "";
                                                    $pointArray[] = "";

                                                    for ($i = 1; $i <= $countCCode; $i++) {
                                                        $grade = "-";

                                                        $StuCurSess = str_ireplace("/", "_", $getsession);
                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                        $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND CCode  = '$CourseCodeArray[$i]' AND SemTaken = '$getsemester' AND SessionRegis =  '$getsession'";
                                                        $result2 = $conn_stu->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $grade = $row2["grade"];
                                                                $CA = $row2["CA"];
                                                                $Exam = $row2["Exam"];
                                                                $gpoint = $row2["point"];
                                                                $total = $CA + $Exam;

                                                                $totalArray[$i] = $total;
                                                                $gradeArray[$i] = $grade;
                                                                $pointArray[$i] = $gpoint;
                                                            }
                                                        } else {
                                                            $sql3 = "SELECT * FROM absent_students WHERE matric_no  = '$regid' AND CCode  = '$CourseCodeArray[$i]' AND semtaken = '$getsemester' AND session1 =  '$getsession'";
                                                            $result3 = $conn_stu->query($sql3);
                                                            if ($result3->num_rows > 0) {
                                                                while ($row3 = $result3->fetch_assoc()) {

                                                                    if ($row3["status1"] == "R") {
                                                                        $UploadUnit = $row3["CUnit"];
                                                                        $getTotal = $row3["CA"] + $row3["Exam"];
                                                                        $totalArray[$i] = $getTotal;
                                                                        if ($getTotal >= 75) {
                                                                            $gp = $UploadUnit * 4;
                                                                            $grade = "A";
                                                                        } elseif ($getTotal >= 70) {
                                                                            $gp = $UploadUnit * 3.5;
                                                                            $grade = "AB";
                                                                        } elseif ($getTotal >= 65) {
                                                                            $gp = $UploadUnit * 3.25;
                                                                            $grade = "B";
                                                                        } elseif ($getTotal >= 60) {
                                                                            $gp = $UploadUnit * 3;
                                                                            $grade = "BC";
                                                                        } elseif ($getTotal >= 55) {
                                                                            $gp = $UploadUnit * 2.75;
                                                                            $grade = "C";
                                                                        } elseif ($getTotal >= 50) {
                                                                            $gp = $UploadUnit * 2.5;
                                                                            $grade = "CD";
                                                                        } elseif ($getTotal >= 45) {
                                                                            $gp = $UploadUnit * 2.25;
                                                                            $grade = "D";
                                                                        } elseif ($getTotal >= 40) {
                                                                            $gp = $UploadUnit * 2;
                                                                            $grade = "E";
                                                                        } else {
                                                                            $gp = $UploadUnit * 0;
                                                                            $grade = "F";
                                                                        }
                                                                        $gradeArray[$i] = $grade;
                                                                        $pointArray[$i] = $gp;
                                                                    } else {
                                                                        if ($row3["status1"] == "X") {
                                                                            $totalArray[$i] = "ABS";
                                                                        } elseif ($row3["status1"] == "D") {
                                                                            $totalArray[$i] = "DEF";
                                                                        } elseif ($row3["status1"] == "I") {
                                                                            $totalArray[$i] = "INC";
                                                                        } elseif ($row3["status1"] == "S") {
                                                                            $totalArray[$i] = "SIC";
                                                                        } elseif ($row3["status1"] == "N") {
                                                                            $totalArray[$i] = "NA";
                                                                        }
                                                                        $gradeArray[$i] = "";
                                                                        $pointArray[$i] = "";
                                                                    }
                                                                }
                                                            } else {
                                                                $totalArray[$i] = "";
                                                                $gradeArray[$i] = "";
                                                                $pointArray[$i] = "";
                                                            }
                                                        }
                                                    }

                                                    $pcgpa = number_format($row['PCGPA'], 2, '.', ',');
                                                    $scgpa = number_format($row['SGPA'], 2, '.', ',');
                                                    $cgpa = number_format($row['CGPA'], 2, '.', ',');

                                                    $colaprows = $countCCode + 7;
                                                    if ($defout == "") {
                                                        $COcourses = "PASSED: " . strtoupper($dclass);
                                                    }

                                                    echo "<tr><td style='border-left: 1px solid;'>$x</td><td style='border-left: 1px solid; text-align:left;'>$regid</td>";
                                                    for ($j = 1; $j <= $countCCode; $j++) {

                                                        echo "<td style='border-left: 1px solid;'>$totalArray[$j]</td>";
                                                    }
                                                    echo "<td style='border-left: 1px solid;'>$ptct</td><td style='border-left: 1px solid;'>$ptcp</td><td style='border-left: 1px solid;'>$pgp</td><td style='border-left: 1px solid;'>$pcgpa</td><td style='border-left: 1px solid;'>$prev_C_F</td><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; border-right: 1px solid;'></td>";


                                                    echo "</tr>";
                                                    echo "<tr><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; text-align: right'>$sex</td>";
                                                    for ($j = 1; $j <= $countCCode; $j++) {
                                                        echo "<td style='border-left: 1px solid;'>$gradeArray[$j]</td>";
                                                    }
                                                    echo "<td style='border-left: 1px solid;'>$stct</td><td style='border-left: 1px solid;'>$stcp</td><td style='border-left: 1px solid;'>$sgp</td><td style='border-left: 1px solid;'>$scgpa</td><td style='border-left: 1px solid;'>$sem_C_F</td><td style='border-left: 1px solid;'>$prevdclasscode</td><td style='border-left: 1px solid; border-right: 1px solid;'>$dclasscode</td>";


                                                    echo "</tr>";
                                                    echo "<tr><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; text-align:left;'>$sname</td>";
                                                    for ($j = 1; $j <= $countCCode; $j++) {
                                                        echo "<td style='border-left: 1px solid;'>$pointArray[$j]</td>";
                                                    }
                                                    echo "<td style='border-left: 1px solid;'>$tct</td><td style='border-left: 1px solid;'>$tcp</td><td style='border-left: 1px solid;'>$tgp</td><td style='border-left: 1px solid;'>$cgpa</td><td style='border-left: 1px solid;'>$cum_C_F</td>";
                                                    echo "<td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; border-right: 1px solid;'></td>";
                                                    echo "</tr>";
                                                    if ($defout == "") {
                                                        echo "<tr style='border-bottom: 1px solid;'><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; text-align:left;'>$fname $oname</td><td colspan= '$colaprows' style=' border-right: 1px solid; text-align:left;'>$COcourses</td></tr>\n";
                                                    } else {
                                                        echo "<tr style='border-bottom: 1px solid;'><td style='border-left: 1px solid;'></td><td style='border-left: 1px solid; text-align:left;'>$fname $oname</td><td colspan= '$colaprows' style=' border-right: 1px solid; text-align:left;'>CO: $numb_Course_failed - $COcourses</td></tr>\n";
                                                    }
                                                }
                                            }
                                        }

                                        ?>
                                </tbody>

                                <tfoot>

                                    <?php if ($pg == $nopg) { ?>
                                    <tr>
                                        <th>
                                            TOTAL: <?php echo $x - 1 ?>
                                        </th>
                                        <th style="border-style: none; text-align:center; font-size:small; padding-top: 3em"
                                            colspan="<?php echo $countCCode + 9 ?>"><?php echo $pg . ' of ' . $nopg ?>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th style="padding-top: 1em; text-align:center; font-size:40px;" colspan="2">
                                            __________
                                        </th>
                                        <th style="padding-top: 1em; text-align:center; font-size:40px;"
                                            colspan="<?php echo $countCCode ?>">
                                            __________
                                        </th>
                                        <th style="padding-top: 1em; text-align:center; font-size:40px;" colspan="7">
                                            __________
                                        </th>
                                    </tr>
                                    <tr>
                                        <th style="border-style: none; text-align:center; font-size:small" colspan="2">
                                            HEAD OF DEPARTMENT
                                        </th>
                                        <th style="border-style: none; text-align:center; font-size:small"
                                            colspan="<?php echo $countCCode ?>">
                                            DEAN OF SCHOOL
                                        </th>
                                        <th style="border-style: none; text-align:center; font-size:small" colspan="7">
                                            RECTOR
                                        </th>
                                    </tr>
                                    <?php } else { ?>
                                    <tr>
                                        <th></th>
                                        <th style="border-style: none; text-align:center; font-size:small; padding-top: 3em"
                                            colspan="<?php echo $countCCode + 9 ?>"><?php echo $pg . ' of ' . $nopg ?>
                                        </th>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php } ?>
                                </tfoot>
                            </table>

                            <?php


                                if ($numbofStu > 8) {
                                    $inino = $inino + 8;

                                    if ($finalno + 8 >= $numbofStu) {
                                        $finalno = $numbofStu;
                                    } else {
                                        $finalno = $finalno + 8;
                                    }
                                }

                                ?>

                            <?php } ?>
                        </div>



                    </div>

                </section>
                <?php
$conn->close();
$conn2->close();
$conn_stu->close();
?>
            </div>
            <br><br>
            <div class="row" style="text-align: right; padding-right: 3em">
                <input type="button" onclick="printDiv('printableArea')" value="print" />
            </div>
            <br><br>
        </div>


    </section>




</body>

</html>
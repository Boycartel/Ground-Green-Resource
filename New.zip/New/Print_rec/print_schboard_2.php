<?php
require_once '../includes/db_connect2.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?> Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword" content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="../img/logo.ico">


    <style type="text/css">
        table {
            page-break-inside: avoid;
        }

        h1,
        h2,
        h3,
        h4,
        h5 {
            page-break-before: always;
        }

        @page {
            size: A4 landscape;
            font-size: small;
        }

        @page :left {
            margin-left: 1cm;
        }

        @page :right {
            margin-left: 1cm;
        }
    </style>

    <script type="text/javascript">
        function printDiv(div_id) {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var content_vlue = document.getElementById(div_id).innerHTML;

            var docprint = window.open("", "", disp_setting);

            ///// Enable Bootstrap CSS
            //// Can also add customise CSS
            docprint.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
            );
            docprint.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    </script>

</head>

<body>
    <section class="body">


        <div class="inner-wrapper">
            <div class="row" id="printableArea" style="width: auto; float: none">


                <?php
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                if ($conn2->connect_error) {
                    die("Connection failed: " . $conn2->connect_error);
                }

                $_SESSION['sn'] = 0;

                $deptname = "";
                set_time_limit(1000);
                $DegType = $_SESSION['DegType'];
                if ($_SESSION['getsemester_sctny'] == "1ST") {
                    $semester = "FIRST";
                } else {
                    $semester = "SECOND";
                }

                if (isset($_POST["print_appr"])) {
                    $getdept = $_SESSION['deptcode'];
                    $getsession = $_SESSION['getsession_sctny'];
                    $getsemester = $_SESSION['getsemester_sctny'];
                    $getlevel = $_SESSION['getlevel_sctny'];
                    $getdeptoption = $_SESSION['getdeptoption'];
                    $curriculum = $_SESSION['curriculum'];
                } else {
                    $getdept = $_SESSION['dept_sctny'];
                    $getsession = $_SESSION['getsession_sctny'];
                    $getsemester = $_SESSION['getsemester_sctny'];
                    $getlevel = $_SESSION['getlevel_sctny'];
                }

                //$getdept = $_SESSION['dept_sctny'];
                //$getsession = $_SESSION['getsession_sctny'];
                //$getsemester = $_SESSION['getsemester_sctny'];
                //$getlevel = $_SESSION['getlevel_sctny'];

                $sql = "SELECT DeptName, DeptCode FROM deptcoding WHERE DeptCode = '$getdept'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        $deptname = $row["DeptName"];
                    }
                }

                $schcode = $_SESSION['schcode'];
                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["HOD_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'Examiner' OR cat = 'ExamLAdvice' OR cat = 'PGExam')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["Exam_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE SchCode = '$schcode' AND (cat = 'Dean' OR cat = 'HODDean' OR cat = 'PGExam')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["Dean_Sign"] = $row["full_name"];
                    }
                }

                $pageno = 0;
                if ($getlevel == 100) {
                    $pagecode = "A";
                } elseif ($getlevel == 200) {
                    $pagecode = "B";
                } elseif ($getlevel == 300) {
                    $pagecode = "C";
                } elseif ($getlevel == 400) {
                    $pagecode = "D";
                } elseif ($getlevel == 500) {
                    $pagecode = "E";
                }
                ?>
                <section class="panel panel-success">

                    <div class="panel-body">
                        <br>
                        <div class="col-lg-12" id="printableArea" style="width: auto; float: none">
                            <?php
                            unset($LblCodeArray);
                            $LblCodeArray[] = "";
                            unset($CourseCodeArray);
                            $CourseCodeArray[] = "";
                            unset($CourseTitleArray);
                            $CourseTitleArray[] = "";
                            unset($CourseUnitArray);
                            $CourseUnitArray[] = "";
                            unset($CourseStatusArray);
                            $CourseStatusArray[] = "";
                            $countCCode = 0;
                            $deptgencourses = $getdept . "_gencourses";


                            $sql = "SELECT DISTINCT CCode, CTitle, session1, Level1, DeptCode, SemTaken, levelCode, split_two, CUnit, CStatus FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";

                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $countCCode++;
                                    $CourseCodeArray[$countCCode] = $row["CCode"];
                                    $CourseTitleArray[$countCCode] = $row["CTitle"];
                                    $CourseUnitArray[$countCCode] = $row["CUnit"];
                                    $CourseStatusArray[$countCCode] = $row["CStatus"];
                                    $CCode = $row["split_two"];
                                    $LblCodeArray[$countCCode] = $CCode . " (" . $row["CUnit"] . ")";
                                }
                            }

                            $DEFCount = 0;
                            $IGSCount = 0;
                            $SP1Count = 0;
                            $SP2Count = 0;
                            $PCount = 0;
                            $DLCount = 0;
                            $VCLCount = 0;
                            $Ten88Count = 0;
                            $BL2Count = 0;

                            $sno = 0;
                            $regidArray[] = "";
                            $namesArray[] = "";
                            $mode_entryArray[] = "";
                            $no_semesterArray[] = 0;
                            $ptctArray[] = 0;
                            $ptcpArray[] = 0;
                            $pgpArray[] = 0;
                            $pcgpaArray[] = 0;

                            $stctArray[] = 0;
                            $stct2Array[] = 0;
                            $stcpArray[] = 0;
                            $sgpArray[] = 0;
                            $scgpaArray[] = 0;
                            $tctArray[] = 0;
                            $tcpArray[] = 0;
                            $tgpArray[] = 0;
                            $cgpaArray[] = 0;
                            $rmk2Array[] = "";
                            $defoutArray[] = "";

                            $countdefer = $countcondon = $countvolwithd = $countpoorwithd = $countilhealth = $countabscond = 0;

                            $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                            if ($conn_stu->connect_error) {
                                die("Connection failed: " . $conn_stu->connect_error);
                            }
                            $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";

                            $result = $conn_stu->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $sno++;
                                    $regidArray[$sno] = $row["Regn"];
                                    $namesArray[$sno] = $row["Name1"];

                                    $mode_entryArray[$sno] = $row['mode_entry'];
                                    $no_semesterArray[$sno] = $row['no_semester'];

                                    $ptctArray[$sno] = $row['PCT'];
                                    $ptcpArray[$sno] = $row['PCP'];
                                    $pgpArray[$sno] = $row['PGP'];
                                    $pcgpaArray[$sno] = $row['PCGPA'];

                                    $stctArray[$sno] = $row['SCT'];
                                    $stcpArray[$sno] = $row['SCP'];
                                    $sgpArray[$sno] = $row['SGP'];
                                    $scgpaArray[$sno] = $row['SGPA'];
                                    $tctArray[$sno] = $row['TCT'];
                                    $tcpArray[$sno] = $row['TCP'];
                                    $tgpArray[$sno] = $row['CGP'];
                                    $cgpaArray[$sno] = $row['CGPA'];
                                    $rmk = $row['RMK'];
                                    $defoutArray[$sno] = $row['def_out'];

                                    if ($rmk == "P") {
                                        $PCount++;
                                        $rmk2Array[$sno] = "Probation";
                                    } elseif ($rmk == "IGS") {
                                        $IGSCount++;
                                        $rmk2Array[$sno] = "In Good Standing";
                                    } elseif ($rmk == "DEF") {
                                        $DEFCount++;
                                        $rmk2Array[$sno] = "Defcient";
                                    } elseif ($rmk == "SP1") {
                                        $SP1Count++;
                                        $rmk2Array[$sno] = "Probation";
                                    } elseif ($rmk == "SP2") {
                                        $SP2Count++;
                                        $rmk2Array[$sno] = "Probation";
                                    } elseif ($rmk == "DL") {
                                        $DLCount++;
                                        $rmk2Array[$sno] = "In Good Standing";
                                    } elseif ($rmk == "VL") {
                                        $VCLCount++;
                                        $rmk2Array[$sno] = "In Good Standing";
                                    } elseif ($rmk == "8-7-6") {
                                        $Ten88Count++;
                                        $rmk2Array[$sno] = "Defcient";
                                    } elseif ($rmk == "BL2") {
                                        $BL2Count++;
                                        $rmk2Array[$sno] = "Defcient";
                                    }


                                    if ($stctArray[$sno] == 0) {
                                        $stct2Array[$sno] = "";
                                        $stcpArray[$sno] = "";
                                        $regid = $regidArray[$sno];
                                        $Response = "";

                                        $sql2 = "SELECT * FROM missing_session WHERE matno = '$regid' AND session = '$getsession' AND semester = '$getsemester'";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $Response = $row2["response"];
                                            }
                                        }

                                        if ($Response == "Deferment") {
                                            $sgpArray[$sno] = "Defe";
                                            $scgpaArray[$sno] = "rred";
                                            $rmk2Array[$sno] = "Deferment";
                                            $countdefer++;
                                        } elseif ($Response == "Condonation") {
                                            $sgpArray[$sno] = "Con";
                                            $scgpaArray[$sno] = "done";
                                            $rmk2Array[$sno] = "Condoned";
                                            $countcondon++;
                                        } elseif ($Response == "VolWithdrawal") {
                                            $sgpArray[$sno] = "With";
                                            $scgpaArray[$sno] = "drawn";
                                            $rmk2Array[$sno] = "Voluntary Withdrawal";
                                            $countvolwithd++;
                                        } elseif ($Response == "PoorWithdrawal") {
                                            $sgpArray[$sno] = "With";
                                            $scgpaArray[$sno] = "drawn";
                                            $rmk2Array[$sno] = "Withdrawal on Poor Academic";
                                            $countpoorwithd++;
                                        } elseif ($Response == "Notification_illhealth") {
                                            $sgpArray[$sno] = "Ill";
                                            $scgpaArray[$sno] = "Health";
                                            $rmk2Array[$sno] = "Notification of Ill Health";
                                            $countilhealth++;
                                        } else {
                                            $sgpArray[$sno] = "Abs";
                                            $scgpaArray[$sno] = "cond";
                                            $rmk2Array[$sno] = "Abscond";
                                            $countabscond++;
                                        }
                                        if ($rmk == "DEF") {
                                            $DEFCount = $DEFCount - 1;
                                        } elseif ($rmk == "SP1") {
                                            $DEFCount = $DEFCount - 1;
                                        } elseif ($rmk == "SP2") {
                                            $DEFCount = $DEFCount - 1;
                                        }
                                    } else {
                                        $stct2Array[$sno] = $row['SCT'];
                                        $stcpArray[$sno] = $row['SCP'];
                                        $sgpArray[$sno] = $row['SGP'];
                                        $scgpaArray[$sno] = $row['SGPA'];
                                    }

                                    $totDeff = $DEFCount + $Ten88Count + $BL2Count;
                                    $totIGS = $IGSCount + $DLCount + $VCLCount;
                                    $totProbation = $PCount + $SP1Count + $SP2Count;
                                }
                            }
                            if ($sno <= 20) {
                                $inino = 1;
                                $finalno = $sno;
                                $nopg = 1;
                            } else {
                                $inino = 1;
                                $finalno = 20;
                                $nopg = intdiv($sno, 20);
                                if (($sno % 20) > 0) {
                                    $nopg = $nopg + 1;
                                }
                            }


                            ?>
                            <style>
                                table,
                                th,
                                td {
                                    border: 1px solid black;
                                    border-collapse: collapse;

                                }

                                table,
                                td {
                                    font-size: 10px;
                                }
                            </style>
                            <?php for ($pg = 1; $pg <= $nopg; $pg++) { ?>

                                <?php $pagediff = $finalno - $inino; ?>
                                <h2>

                                </h2>

                                <table style="width: 99%; border:2em">
                                    <thead>

                                        <tr>
                                            <td style="border-style: none; text-align:center; font-size:large" colspan="40">
                                                <?php echo $_SESSION['instname'] ?><br>
                                                FACULTY OF <?php echo strtoupper($_SESSION['schname']); ?>
                                        </tr>
                                        <tr>
                                            <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                                DEPARTMENT OF
                                                <?php echo strtoupper($_SESSION['deptname']); ?></td>
                                        </tr>
                                        <tr>
                                            <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                                <?php echo $_SESSION['getsession_sctny']; ?>
                                                <?php echo $semester; ?> SEMESTER EXAMINATION RESULTS
                                                </th>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                                <?php echo $DegType; ?>
                                                <?php echo strtoupper($_SESSION['deptname']); ?>
                                                <?php echo $_SESSION['getlevel_sctny']; ?> LEVEL - FACULTY BOARD FORMAT</th>
                                            </td>
                                        </tr>

                                        <tr>
                                            <th style='text-align:center'>S/ No</th>
                                            <th style='text-align:center'>Matric No</th>
                                            <th style='text-align:center'>Name</th>

                                            <?php for ($i = 1; $i <= $countCCode; $i++) { ?>
                                                <th style='text-align:center; font-size: 8px'><?php echo $LblCodeArray[$i] ?>
                                                </th>
                                            <?php } ?>


                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        for ($j = $inino; $j <= $finalno; $j++) {
                                            //for ($j = 1; $j <= 4; $j++) {
                                            $regid = $regidArray[$j];
                                            $names = $namesArray[$j];
                                            echo "<tr><td style='text-align:center'>$j</td><td style='text-align:center'>$regid </td><td> $names</td>";
                                            for ($i = 1; $i <= $countCCode; $i++) {
                                                $grade = "-";

                                                $StuCurSess = str_ireplace("/", "_", $getsession);
                                                $deptcorreg = "correg_" . $StuCurSess;



                                                $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND CCode  = '$CourseCodeArray[$i]' AND SemTaken = '$getsemester' AND SessionRegis =  '$getsession'";
                                                $result2 = $conn_stu->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $totalscor = $row2["CA"] + $row2["Exam"];
                                                        $grade = $totalscor . " " . $row2["grade"];
                                                        //$unit=$row2["CUnit"];

                                                    }
                                                }
                                                echo "<td style='text-align:center'>$grade</td>";
                                            }

                                            echo "</tr>\n";
                                        }
                                        $conn->close();
                                        $conn2->close();
                                        $conn_stu->close();
                                        $pageno++;
                                        ?>


                                    </tbody>
                                    <tfoot>
                                        <?php if ($pagediff < 5) { ?>
                                            <tr>
                                                <td style="border-style: none; text-align:center; font-size:small; padding-top: 30em">
                                                </td>
                                            </tr>
                                        <?php } elseif ($pagediff < 10) { ?>
                                            <tr>
                                                <td style="border-style: none; text-align:center; font-size:small; padding-top: 20em">
                                                </td>
                                            </tr>
                                        <?php } elseif ($pagediff < 15) { ?>
                                            <tr>
                                                <td style="border-style: none; text-align:center; font-size:small; padding-top: 10em">
                                                </td>
                                            </tr>
                                        <?php } ?>
                                        <tr>

                                            <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="3">
                                                <?php echo $_SESSION["HOD_Sign"] ?></td>

                                            <th style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="6">
                                                <?php echo $pagecode . $pageno ?></th>


                                            <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="12">
                                                <?php echo $_SESSION["Dean_Sign"] ?></td>
                                        </tr>
                                        <tr>

                                            <th style="border-style: none; text-align:center; font-size:small" colspan="3">
                                                HOD
                                            </th>
                                            <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="6">
                                            </td>
                                            <th style="border-style: none; text-align:center; font-size:small" colspan="12">
                                                DEAN
                                            </th>
                                        </tr>
                                    </tfoot>
                                    <h2>

                                    </h2>
                                </table>





                                <h3>

                                </h3>

                                <table style="width: 99%; border:2em">
                                    <thead>

                                        <tr>
                                            <td style="border-style: none; text-align:center; font-size:large" colspan="40">
                                                <?php echo $_SESSION['instname'] ?><br>
                                                FACULTY OF <?php echo strtoupper($_SESSION['schname']); ?>
                                        </tr>
                                        <tr>
                                            <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                                DEPARTMENT OF
                                                <?php echo strtoupper($_SESSION['deptname']); ?></td>
                                        </tr>
                                        <tr>
                                            <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                                <?php echo $_SESSION['getsession_sctny']; ?>
                                                <?php echo $semester; ?> SEMESTER EXAMINATION RESULTS
                                                </th>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                                <?php echo $DegType; ?>
                                                <?php echo strtoupper($_SESSION['deptname']); ?>
                                                <?php echo $_SESSION['getlevel_sctny']; ?> LEVEL - SENATE FORMAT</th>
                                            </td>
                                        </tr>

                                        <tr>
                                            <th style='text-align:center'>S/ No</th>
                                            <th style='text-align:center'>Matric No</th>
                                            <th style='text-align:center'>Name</th>

                                            <th style="font-size: 10px">ME</th>
                                            <th style="font-size: 10px">NSS</th>
                                            <th style="font-size: 10px">RCU</th>
                                            <th style="font-size: 10px">ECU</th>
                                            <th style="font-size: 10px">CP</th>
                                            <th style="font-size: 10px">GPA</th>
                                            <th style="font-size: 10px">TRCU</th>
                                            <th style="font-size: 10px">TECU</th>
                                            <th style="font-size: 10px">TCP</th>
                                            <th style="font-size: 10px">PCGPA</th>
                                            <th style="font-size: 10px">CGPA</th>
                                            <th style="font-size: 10px">Courses Outstanding</th>
                                            <th>Remarks</th>


                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        for ($j = $inino; $j <= $finalno; $j++) {
                                            $regid = $regidArray[$j];
                                            $names = $namesArray[$j];
                                            $mode_entry = $mode_entryArray[$j];
                                            $no_semester = $no_semesterArray[$j];
                                            $stct = $stctArray[$j];
                                            $stct2 = $stct2Array[$j];
                                            $stcp = $stcpArray[$j];
                                            $sgp = $sgpArray[$j];
                                            $scgpa = $scgpaArray[$j];
                                            $tct = $tctArray[$j];
                                            $tcp = $tcpArray[$j];
                                            $tgp = $tgpArray[$j];
                                            $pcgpa = $pcgpaArray[$j];
                                            $cgpa = $cgpaArray[$j];
                                            $defout = $defoutArray[$j];
                                            $rmk2 = $rmk2Array[$j];

                                            echo "<tr><td style='text-align:center'>$j</td><td style='text-align:center'>$regid </td><td> $names</td>";
                                            echo "<td>$mode_entry</td><td>$no_semester</td>";
                                            /*  if ($stct == 0) {
                                                if ($Response == "Deferment" || $Response == "Condonation" || $Response == "Notification_illhealth") {
                                                    echo "<td>$stct2</td><td>$stcp</td><td style='background-color: purple; color: white'>$sgp</td><td style='background-color: purple; color: white'>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$pcgpa</td><td>$cgpa</td><td>$defout</td><td>$rmk2</td>";
                                                } else {
                                                    echo "<td>$stct2</td><td>$stcp</td><td style='background-color: #9d1e15; color: white'>$sgp</td><td style='background-color: #9d1e15; color: white'>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$pcgpa</td><td>$cgpa</td><td>$defout</td><td>$rmk2</td>";
                                                }
                                            } else {
                                                echo "<td>$stct2</td><td>$stcp</td><td>$sgp</td><td>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$pcgpa</td><td>$cgpa</td><td>$defout</td><td>$rmk2</td>";
                                            } */
                                            echo "<td>$stct2</td><td>$stcp</td><td>$sgp</td><td>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$pcgpa</td><td>$cgpa</td><td>$defout</td><td>$rmk2</td>";

                                            echo "</tr>\n";
                                        }

                                        $pageno++;
                                        ?>


                                    </tbody>
                                    <tfoot>
                                        <?php if ($pagediff < 5) { ?>
                                            <tr>
                                                <td style="border-style: none; text-align:center; font-size:small; padding-top: 30em">
                                                </td>
                                            </tr>
                                        <?php } elseif ($pagediff < 10) { ?>
                                            <tr>
                                                <td style="border-style: none; text-align:center; font-size:small; padding-top: 20em">
                                                </td>
                                            </tr>
                                        <?php } elseif ($pagediff < 15) { ?>
                                            <tr>
                                                <td style="border-style: none; text-align:center; font-size:small; padding-top: 10em">
                                                </td>
                                            </tr>
                                        <?php } ?>
                                        <tr>

                                            <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="3">
                                                <?php echo $_SESSION["HOD_Sign"] ?></td>

                                            <th style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="11">
                                                <?php echo $pagecode . $pageno ?></th>

                                            <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="1">
                                                <?php echo $_SESSION["Dean_Sign"] ?></td>
                                        </tr>
                                        <tr>

                                            <th style="border-style: none; text-align:center; font-size:small" colspan="3">
                                                HOD
                                            </th>
                                            <td style="border-style: none; text-align:center; font-size:small" colspan="11">
                                            </td>
                                            <th style="border-style: none; text-align:center; font-size:small" colspan="1">
                                                DEAN
                                            </th>
                                        </tr>
                                    </tfoot>
                                    <h2>

                                    </h2>
                                </table>
                                <?php
                                if ($sno > 20) {
                                    $inino = $inino + 20;

                                    if ($finalno + 20 >= $sno) {
                                        $finalno = $sno;
                                    } else {
                                        $finalno = $finalno + 20;
                                    }
                                }


                                ?>

                            <?php } ?>


                            <!--Summary Page -->
                            <h2 style="text-align: center">

                            </h2>

                            <table style="width: 99%; border:2em">
                                <thead>

                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:large" colspan="40">
                                            <?php echo $_SESSION['instname'] ?><br>
                                            FACULTY OF <?php echo strtoupper($_SESSION['schname']); ?>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                            DEPARTMENT OF
                                            <?php echo strtoupper($_SESSION['deptname']); ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                            <?php echo $_SESSION['getsession_sctny']; ?>
                                            <?php echo $semester; ?> SEMESTER EXAMINATION RESULTS
                                            </th>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                            <?php echo $DegType; ?>
                                            <?php echo strtoupper($_SESSION['deptname']); ?>
                                            <?php echo $_SESSION['getlevel_sctny']; ?> LEVEL - SUMMARY PAGE</th>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th style="border-style: none">NOTE</th>

                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em"><b>ME:</b> Mode of Entry</td>
                                        <td style="border-style: none"><b>NSS:</b> Number of Semesters Spent</td>
                                        <td style="border-style: none"><b>RCU:</b> Registered Credit Units</td>

                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em"><b>ECU: Earned Credit Units
                                        </td>
                                        <td style="border-style: none"><b>CP:</b> Credit Points</td>
                                        <td style="border-style: none"><b>GPA:</b> Grade Point Average</td>

                                    </tr>

                                    <tr>
                                        <td style="border-style: none; padding-top: 1em"><b>TRCU:</b> Total Registered
                                            Credit
                                            Units</td>
                                        <td style="border-style: none"><b>TECU:</b> Total Earned Credit Units</td>
                                        <td style="border-style: none"><b>TCP:</b> Total Credit Points</td>

                                    </tr>

                                    <tr>

                                        <td style="border-style: none; padding-top: 1em"><b>PCGPA:</b> Previous
                                            Cummulative
                                            Grade Point Average
                                        </td>
                                        <td style="border-style: none"><b>CGPA:</b> Cummulative Grade Point Average</td>
                                        <td style="border-style: none"><b>UTME:</b> Unified Tertiary Matriculation
                                            Examination
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em"><b>DE:</b> Direct Entry</td>
                                    </tr>
                                    <tr>
                                        <th style="border-style: none; padding-top: 2em"> SUMMARY</th>


                                    </tr>

                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number in Good Standing</td>
                                        <td style="border-style: none"><?php echo $totIGS ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number with Deficiency</td>
                                        <td style="border-style: none"><?php echo $totDeff ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number on Probation</td>
                                        <td style="border-style: none"><?php echo $totProbation ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number of Voluntary Withdraw
                                        </td>
                                        <td style="border-style: none"><?php echo $countvolwithd ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number to Withdraw on Poor
                                            Academic Performance</td>
                                        <td style="border-style: none"><?php echo $countpoorwithd ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number of Deferment</td>
                                        <td style="border-style: none"><?php echo $countdefer ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number of Condonation</td>
                                        <td style="border-style: none"><?php echo $countcondon ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number of Notification of Ill
                                            Health</td>
                                        <td style="border-style: none"><?php echo $countilhealth ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number Absent</td>
                                        <td style="border-style: none"><?php echo $countabscond ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; padding-top: 1em">Number Deceased</td>
                                        <td style="border-style: none">0</td>
                                    </tr>
                                    <tr>
                                        <th style="border-style: none; padding-top: 1em; text-align:left">Total Number
                                            of Students</th>
                                        <th style="border-style: none; text-align:left"><?php echo $sno ?></th>
                                    </tr>

                                </thead>
                                <tbody>
                                    <?php


                                    $pageno++;
                                    ?>


                                </tbody>
                                <tfoot>
                                    <tr>

                                        <td style=" border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="2">
                                            <?php echo $_SESSION["HOD_Sign"] ?></td>

                                        <th style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="1">
                                            <?php echo $pagecode . $pageno ?></th>

                                        <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="2">
                                            <?php echo $_SESSION["Dean_Sign"] ?></td>
                                    </tr>
                                    <tr>

                                        <th style="border-style: none; text-align:center; font-size:small" colspan="2">
                                            HOD
                                        </th>
                                        <td style="border-style: none; text-align:center; font-size:small" colspan="1">
                                        </td>
                                        <th style="border-style: none; text-align:center; font-size:small" colspan="2">
                                            DEAN
                                        </th>
                                    </tr>
                                </tfoot>
                            </table>

                            <!--Course Listing -->
                            <h2>

                            </h2>

                            <table style="width: 99%; border:2em; font-size:medium">
                                <thead>

                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:large" colspan="40">
                                            <?php echo $_SESSION['instname'] ?><br>
                                            FACULTY OF <?php echo strtoupper($_SESSION['schname']); ?>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                            DEPARTMENT OF
                                            <?php echo strtoupper($_SESSION['deptname']); ?></td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                            <?php echo $_SESSION['getsession_sctny']; ?>
                                            <?php echo $semester; ?> SEMESTER EXAMINATION RESULTS
                                            </th>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:small" colspan="40">
                                            <?php echo $DegType; ?>
                                            <?php echo strtoupper($_SESSION['deptname']); ?>
                                            <?php echo $_SESSION['getlevel_sctny']; ?> LEVEL - COURSE LISTING</th>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th style='text-align:center'>S/ No</th>
                                        <th style='text-align:center'>Course Code</th>
                                        <th style='text-align:center'>Course Title</th>

                                        <th style="font-size: 10px; text-align:center">Unit</th>
                                        <th style="font-size: 10px">Status</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                    for ($i = 1; $i <= $countCCode; $i++) {


                                        $C_codding = $CourseCodeArray[$i];
                                        $C_title = $CourseTitleArray[$i];
                                        $credit = $CourseUnitArray[$i];
                                        $Status = $CourseStatusArray[$i];



                                        echo "<tr><td style='text-align:center'>$i</td><td style='text-align:center'>$C_codding </td><td> $C_title</td><td style='text-align:center'> $credit</td><td> $Status</td>";
                                    }

                                    $pageno++;
                                    ?>


                                </tbody>
                                <tfoot>
                                    <tr>

                                        <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="2">
                                            <?php echo $_SESSION["HOD_Sign"] ?></td>

                                        <th style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="1">
                                            <?php echo $pagecode . $pageno ?></th>

                                        <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="2">
                                            <?php echo $_SESSION["Dean_Sign"] ?></td>
                                    </tr>
                                    <tr>

                                        <th style="border-style: none; text-align:center; font-size:small" colspan="2">
                                            HOD
                                        </th>
                                        <td style="border-style: none; text-align:center; font-size:small" colspan="1">
                                        </td>
                                        <th style="border-style: none; text-align:center; font-size:small" colspan="2">
                                            DEAN
                                        </th>
                                    </tr>
                                </tfoot>
                            </table>




                        </div>



                    </div>

                </section>

            </div>
            <br><br>
            <div class="row" style="text-align: right; padding-right: 3em">
                <input type="button" onclick="printDiv('printableArea')" value="print" />
            </div>
            <br><br>
        </div>


    </section>




</body>

</html>
<?php
require_once '../includes/db_connect2.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?> Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword"
        content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="../img/logo.ico">


    <style type="text/css">
    table {
        page-break-inside: avoid;
    }

    h1,
    h2,
    h3,
    h4,
    h5 {
        page-break-after: avoid;
    }

    @page {
        size: A4 landscape;
        font-size: small;
    }

    @page :left {
        margin-left: 1cm;
    }

    @page :right {
        margin-left: 2cm;
    }
    </style>


    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>

</head>

<body>
    <section class="body">


        <div class="inner-wrapper">
            <div class="row" id="printableArea" style="width: auto; float: none">


                <?php
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                            if ($conn2->connect_error) {
                                                die("Connection failed: " . $conn2->connect_error);
                                            }

                $_SESSION['sn'] = 0;

                $deptname = "";
                set_time_limit(1000);
                //$DegType = $_SESSION['DegType'];

                if (isset($_POST["print_appr"])) {
                    $getdept = $_SESSION['deptcode'];
                    $getsession = $_SESSION['getsession_sctny'];
                    $getsemester = $_SESSION['getsemester_sctny'];
                    $getlevel = $_SESSION['getlevel_sctny'];
                    $getdeptoption = $_SESSION['getdeptoption'];
                    $curriculum = $_SESSION['curriculum'];
                } else {
                    $getdept = $_SESSION['dept_sctny'];
                    $getsession = $_SESSION['getsession_sctny'];
                    $getsemester = $_SESSION['getsemester_sctny'];
                    $getlevel = $_SESSION['getlevel_sctny'];
                }

                //$getdept = $_SESSION['dept_sctny'];
                //$getsession = $_SESSION['getsession_sctny'];
                //$getsemester = $_SESSION['getsemester_sctny'];
                //$getlevel = $_SESSION['getlevel_sctny'];

                $sql = "SELECT DeptName, DeptCode, DegreeAward FROM deptcoding WHERE DeptCode = '$getdept'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while ($row = $result->fetch_assoc()) {
                        $deptname = $row["DeptName"];
                        $DegType = $row["DegreeAward"];
                    }
                }

                $schcode = $_SESSION['schcode'];
                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["HOD_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'Examiner' OR cat = 'ExamLAdvice' OR cat = 'PGExam')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["Exam_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE SchCode = '$schcode' AND (cat = 'Dean' OR cat = 'HODDean' OR cat = 'PGExam')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["Dean_Sign"] = $row["full_name"];
                    }
                } else {
                    $_SESSION["Dean_Sign"] = "XXXX";
                }
                ?>
                <section class="panel panel-success">

                    <div class="panel-body">
                        <br>
                        <div class="col-lg-12" id="printableArea" style="width: auto; float: none">
                            <?php
                            unset($LblCodeArray);
                            $LblCodeArray[] = "";
                            unset($CourseCodeArray);
                            $CourseCodeArray[] = "";
                            $countCCode = 0;

                            unset($LblCodeArray2);
                            $LblCodeArray2[] = "";
                            unset($CourseCodeArray2);
                            $CourseCodeArray2[] = "";
                            $countCCode2 = 0;

                            $deptgencourses = "gencourses";

                            $sql = "SELECT DISTINCT CCode, session1, Level1, DeptCode, SemTaken, levelCode, split_two, CUnit, course_level FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    if ($row["course_level"] == $getlevel) {
                                        $countCCode++;
                                        $CourseCodeArray[$countCCode] = $row["CCode"];
                                        $CCode = $row["split_two"];
                                        $LblCodeArray[$countCCode] = $CCode . " (" . $row["CUnit"] . ")";
                                    } else {
                                        $countCCode2++;
                                        $CourseCodeArray2[$countCCode2] = $row["CCode"];
                                        $CCode = $row["split_two"];
                                        $LblCodeArray2[$countCCode2] = $CCode . " (" . $row["CUnit"] . ")";
                                    }
                                }
                            }

                            ?>
                            <style>
                            table,
                            th,
                            td {
                                border: 1px solid black;
                                border-collapse: collapse;

                            }

                            table,
                            td {
                                font-size: 10px;
                            }
                            </style>
                            <?php
                            if ($_SESSION['getsemester_sctny'] == "1ST") {
                                $sem_full = "FIRST";
                            } else {
                                $sem_full = "SECOND";
                            }
                            ?>
                            <table style="width: 99%; border:2em">
                                <tbody>
                                    <tr>
                                        <td style="border-style: none; width:33%">
                                            <img alt='' src='../img/logo.ico' width='70' height='70'>
                                        </td>
                                        <td style="border-style: none; width:33%">
                                            <p style="text-align: center; font-size:small">
                                                <?php echo $_SESSION['instname'] ?><br>
                                                <?php echo $_SESSION['sch_faculty'] ?> OF
                                                <?php echo strtoupper($_SESSION['schname']); ?><br>
                                                DEPARTMENT OF <?php echo strtoupper($_SESSION['deptname']); ?><br>
                                                <?php echo $sem_full ?> SEMESTER RESULT
                                                <?php echo $_SESSION['getsession_sctny'] ?> SESSION

                                            </p>
                                        </td>
                                        <td style="vertical-align: top; border-style: none; text-align: center">
                                            <h2>Senate Paper No.: 05/19/23</h2>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <table style="width: 99%; border:2em">
                                <thead>


                                    <tr>
                                        <th style="border-style: none; padding-bottom: 1em" colspan="3">
                                            DEPARTMENT OF
                                            <?php echo strtoupper($_SESSION['deptname']); ?></th>
                                        <th style="border-style: none; padding-bottom: 1em"
                                            colspan="<?php echo $countCCode ?>">
                                            <?php echo $DegType ?>
                                            <?php echo strtoupper($_SESSION['deptname']); ?></th>
                                        <th style="border-style: none; padding-bottom: 1em" colspan="4">
                                            <?php echo $_SESSION['getlevel_sctny']; ?> LEVEL</th>
                                        <th style="border-style: none; padding-bottom: 1em" colspan="6">
                                            <?php echo $_SESSION['getsession_sctny']; ?> SESSION</th>

                                        <th style="border-style: none; padding-bottom: 1em" colspan="5">
                                            <?php echo $_SESSION['getsemester_sctny']; ?> SEMESTER</th>



                                    </tr>
                                    <tr>

                                        <?php if ($getlevel == 100) { ?>
                                        <th colspan="<?php echo $countCCode + 4 ?>"></th>
                                        <?php } ?>
                                        <?php if ($getlevel == 200) { ?>
                                        <th colspan="<?php echo $countCCode + 5 ?>"></th>
                                        <?php } ?>
                                        <?php if ($getlevel == 300) { ?>
                                        <th colspan="<?php echo $countCCode + 6 ?>"></th>
                                        <?php } ?>
                                        <?php if ($getlevel == 400) { ?>
                                        <th colspan="<?php echo $countCCode + 7 ?>"></th>
                                        <?php } ?>
                                        <?php if ($getlevel == 500) { ?>
                                        <th colspan="<?php echo $countCCode + 8 ?>"></th>
                                        <?php } ?>
                                        <th colspan="4" style="text-align: center;">PREVIOUS
                                        </th>
                                        <th colspan="4" style="text-align: center;">CURRENT</th>
                                        <th colspan="4" style="text-align: center;">CUMULATIVE</th>
                                        <th colspan="4"></th>
                                    </tr>
                                    <tr>
                                        <th style='text-align:center'>S/ No</th>
                                        <th style='text-align:center'>Matric_No</th>
                                        <th style='text-align:center'>Name</th>

                                        <?php for ($i = 1; $i <= $countCCode; $i++) { ?>
                                        <th style='text-align:center; font-size: 8px'><?php echo $LblCodeArray[$i] ?>
                                        </th>
                                        <?php } ?>
                                        <th style="font-size: 10px">OTHER COURSES</th>
                                        <?php if ($getlevel == 200) { ?>
                                        <th style="font-size: 10px">100L CGPA</th>
                                        <?php } ?>
                                        <?php if ($getlevel == 300) { ?>
                                        <th style="font-size: 10px">100L CGPA</th>
                                        <th style="font-size: 10px">200L CGPA</th>
                                        <?php } ?>
                                        <?php if ($getlevel == 400) { ?>
                                        <th style="font-size: 10px">100L CGPA</th>
                                        <th style="font-size: 10px">200L CGPA</th>
                                        <th style="font-size: 10px">300L CGPA</th>
                                        <?php } ?>
                                        <?php if ($getlevel == 500) { ?>
                                        <th style="font-size: 10px">100L CGPA</th>
                                        <th style="font-size: 10px">200L CGPA</th>
                                        <th style="font-size: 10px">300L CGPA</th>
                                        <th style="font-size: 10px">400L CGPA</th>
                                        <?php } ?>
                                        <th style='text-align:center'>TCUR</th>
                                        <th style='text-align:center'>PCP</th>
                                        <th style='text-align:center'>TWGP</th>
                                        <th style='text-align:center'>CGPA</th>
                                        <th style=' text-align:center'>TCUR</th>
                                        <th style='text-align:center'>SCP</th>
                                        <th style='text-align:center'>TWGP</th>
                                        <th style='text-align:center'>CGPA</th>
                                        <th style='text-align:center'>TCUR</th>
                                        <th style='text-align:center'>TCP</th>
                                        <th style=' text-align:center'>TWGP</th>
                                        <th style='text-align:center'>CGPA</th>
                                        <th style='text-align:center'>REMARKS</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sno = 0;
                                    $DEFCount = 0;
                                    $IGSCount = 0;
                                    $SP1Count = 0;
                                    $SP2Count = 0;
                                    $PCount = 0;
                                    $DLCount = 0;
                                    $VCLCount = 0;
                                    $Ten88Count = 0;
                                    $BL2Count = 0;
                                    //if (isset($_POST["print_appr"]) || isset($_POST["print"])) {
                                    //$sql = "SELECT * FROM " . $getdept . "_scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND DeptOpt = '$getdeptoption' AND curriculum = '$curriculum' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";
                                    //} else {
                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                    $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval <> 'Approve' ORDER BY Regn";
                                    //}

                                    $result = $conn_stu->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $sno++;
                                            $regid = $row["Regn"];
                                            $names = $row["Name1"];
                                            $id = $row["sn"];
                                            $aproval = $row['board_aproval'];
                                            $coment = $row["board_comment"];

                                            $defout = $def = $out = $rmk = $grade = "";


                                            $unit = $ptct = $ptcp = $pgp = $pcgpa = $stct = $stcp = $sgp = $scgpa = $tct = $tcp = $tgp = $cgpa = 0;
                                            $cgpa100 = $row['CGPA100'];
                                            $cgpa200 = $row['CGPA200'];
                                            $cgpa300 = $row['CGPA300'];
                                            $cgpa400 = $row['CGPA400'];

                                            $ptct = $row['PCT'];
                                            $ptcp = $row['PCP'];
                                            $pgp = $row['PGP'];
                                            $pcgpa = $row['PCGPA'];

                                            $stct = $row['SCT'];
                                            $stcp = $row['SCP'];
                                            $sgp = $row['SGP'];
                                            $scgpa = $row['SGPA'];
                                            $tct = $row['TCT'];
                                            $tcp = $row['TCP'];
                                            $tgp = $row['CGP'];
                                            $cgpa = $row['CGPA'];
                                            $rmk = $row['RMK'];
                                            $defout = $row['def_out'];

                                            if ($rmk == "P") {
                                                $PCount++;
                                                $full_rmk = "Sem Prob " . $defout;
                                            } elseif ($rmk == "IGS") {
                                                $IGSCount++;
                                                $full_rmk = "PASS";
                                            } elseif ($rmk == "DEF") {
                                                $DEFCount++;
                                                $full_rmk = "CO: " . $defout;
                                            } elseif ($rmk == "SP1") {
                                                $SP1Count++;
                                                $full_rmk = "Sess Prob I " . $defout;
                                            } elseif ($rmk == "SP2") {
                                                $SP2Count++;
                                                $full_rmk = "Sess Prob II(WD) " . $defout;
                                            } elseif ($rmk == "DL") {
                                                $DLCount++;
                                                $full_rmk = "PASS Dean List";
                                            } elseif ($rmk == "VL") {
                                                $VCLCount++;
                                                $full_rmk = "VC List";
                                            } elseif ($rmk == "8-7-6") {
                                                $Ten88Count++;
                                                $full_rmk = "8-7-6 " . $defout;
                                            } elseif ($rmk == "BL2") {
                                                $BL2Count++;
                                                $full_rmk = "BL2 " . $defout;
                                            }

                                            if ($ptct == 0) {
                                                $ptct = "";
                                                $ptcp = "";
                                                $pgp = "";
                                                $pcgpa = "";
                                            } else {
                                                $ptct = $row['PCT'];
                                                $ptcp = $row['PCP'];
                                                $pgp = $row['PGP'];
                                                $pcgpa = $row['PCGPA'];
                                            }
                                            if ($stct == 0) {
                                                $stct2 = "";
                                                $stcp = "";

                                                $Response = "";

                                                $sql2 = "SELECT * FROM missing_session WHERE matno = '$regid' AND session = '$getsession' AND semester = '$getsemester'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $Response = $row2["response"];
                                                    }
                                                }
                                                if ($Response == "Deferment") {
                                                    $sgp = "Defe";
                                                    $scgpa = "rred";
                                                } elseif ($Response == "Condonation") {
                                                    $sgp = "Con";
                                                    $scgpa = "done";
                                                } elseif ($Response == "VolWithdrawal") {
                                                    $sgp = "With";
                                                    $scgpa = "drawn";
                                                } elseif ($Response == "PoorWithdrawal") {
                                                    $sgp = "With";
                                                    $scgpa = "drawn";
                                                } else {
                                                    $sgp = "Abs";
                                                    $scgpa = "cond";
                                                }
                                            } else {
                                                $stct2 = $row['SCT'];
                                                $stcp = $row['SCP'];
                                                $sgp = $row['SGP'];
                                                $scgpa = $row['SGPA'];
                                            }
                                            $other_courses = "";
                                            for ($j = 1; $j <= $countCCode2; $j++) {
                                                $grade = "-";
                                                $total = "";
                                                $StuCurSess = str_ireplace("/", "_", $getsession);
                                                $deptcorreg = "correg_" . $StuCurSess;
                                                $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND CCode  = '$CourseCodeArray2[$j]' AND SemTaken = '$getsemester' AND SessionRegis =  '$getsession'";
                                                $result2 = $conn_stu->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        //$grade = $row2["grade"];
                                                        $total = $row2["CA"] + $row2["Exam"];
                                                        $other_courses = $other_courses . ", " . $row2["CUnit"] . $CourseCodeArray2[$j] . "(" . $total . $row2["grade"] . ")";
                                                    }
                                                }
                                            }


                                            echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$regid </td><td> $names</td>";
                                            for ($i = 1; $i <= $countCCode; $i++) {
                                                $grade = "-";
                                                $total = "";
                                                $StuCurSess = str_ireplace("/", "_", $getsession);
                                                $deptcorreg = "correg_" . $StuCurSess;
                                                $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND CCode  = '$CourseCodeArray[$i]' AND SemTaken = '$getsemester' AND SessionRegis =  '$getsession'";
                                                $result2 = $conn_stu->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $grade = $row2["grade"];
                                                        $total = $row2["CA"] + $row2["Exam"];
                                                    }
                                                }
                                                echo "<td style='text-align:center'>$total $grade</td>";
                                            }
                                            echo "<td>$other_courses</td>";
                                            if ($getlevel == 200) {
                                                echo "<td style='text-align:center'>$cgpa100</td>";
                                            } elseif ($getlevel == 300) {
                                                echo "<td style='text-align:center'>$cgpa100</td><td style='text-align:center'>$cgpa200</td>";
                                            } elseif ($getlevel == 400) {
                                                echo "<td style='text-align:center'>$cgpa100</td><td style='text-align:center'>$cgpa200</td><td style='text-align:center'>$cgpa300</td>";
                                            } elseif ($getlevel == 500) {
                                                echo "<td style='text-align:center'>$cgpa100</td><td style='text-align:center'>$cgpa200</td><td style='text-align:center'>$cgpa300</td><td style='text-align:center'>$cgpa400</td>";
                                            }
                                            if ($stct == 0) {
                                                if ($Response == "Deferment" || $Response == "Condonation") {
                                                    echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td style='background-color: purple; color: white'>$sgp</td><td style='background-color: purple; color: white'>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$full_rmk</td>";
                                                } else {
                                                    echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td style='background-color: #9d1e15; color: white'>$sgp</td><td style='background-color: #9d1e15; color: white'>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$full_rmk</td>";
                                                }
                                            } else {
                                                echo "<td style='text-align:center'>$ptct</td><td style='text-align:center'>$ptcp</td><td style='text-align:center'>$pgp</td><td style='text-align:center'>$pcgpa</td><td style='text-align:center'>$stct2</td><td style='text-align:center'>$stcp</td><td style='text-align:center'>$sgp</td><td style='text-align:center'>$scgpa</td><td style='text-align:center'>$tct</td><td style='text-align:center'>$tcp</td><td style='text-align:center'>$tgp</td><td style='text-align:center'>$cgpa</td><td style='text-align:center'>$full_rmk</td>";
                                            }


                                            echo "</tr>\n";
                                        }
                                    }
                                    $SubTotal = $PCount + $IGSCount + $DEFCount + $SP1Count + $SP2Count + $DLCount + $VCLCount + $Ten88Count + $BL2Count;
                                    ?>
                                    <tr>
                                        <th style="border-style: none; text-align:center; padding-top: 2em; padding-bottom: 1em"
                                            colspan="12">
                                            SUMMARY</th>
                                    </tr>
                                    <tr>
                                        <th style="border-style: none; padding: 0.5em" colspan="2">VC's' List:
                                            <?php echo $VCLCount ?></th>
                                        <th style="border-style: none; padding: 0.5em" colspan="2">Dean's' List:
                                            <?php echo $DLCount ?></th>
                                        <th style="border-style: none; padding: 0.5em" colspan="3">PASS:
                                            <?php echo $IGSCount ?></th>
                                        <th style="border-style: none; padding: 0.5em" colspan="4">Reapeat Course:
                                            <?php echo $DEFCount ?></th>
                                        <th style="border-style: none; padding: 0.5em" colspan="3">Sem Prob:
                                            <?php echo $PCount ?></th>

                                    </tr>
                                    <tr>

                                        <th style="border-style: none; padding: 0.5em" colspan="2">Sess Prob I:
                                            <?php echo $SP1Count ?></th>
                                        <th style="border-style: none; padding: 0.5em" colspan="2">Sess Prob II:
                                            <?php echo $SP2Count ?></th>
                                        <?php if ($DegType == "BEng") { ?>
                                        <th style="border-style: none; padding: 0.5em" colspan="3">8-7-6:
                                            <?php echo $Ten88Count ?></th>
                                        <th style="border-style: none; padding: 0.5em" colspan="4">BL2:
                                            <?php echo $BL2Count ?></th>
                                        <?php } ?>
                                        <th style="border-style: none; padding: 0.5em" colspan="3">Total:
                                            <?php echo $SubTotal ?></th>
                                    </tr>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em"
                                            colspan="12">
                                            <?php echo $_SESSION["HOD_Sign"] ?></td>
                                        <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em"
                                            colspan="8">
                                            <?php echo $_SESSION["Dean_Sign"] ?></td>
                                    </tr>
                                    <tr>
                                        <th style="border-style: none; text-align:center; font-size:small" colspan="12">
                                            Head of Department and Chief Examiner
                                        </th>
                                        <th style="border-style: none; text-align:center; font-size:small" colspan="8">
                                            Dean of Faculty
                                        </th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <?php
$conn->close();
$conn2->close();
$conn_stu->close();
?>

                    </div>

                </section>

            </div>
            <br><br>
            <div class="row" style="text-align: right; padding-right: 3em">
                <input type="button" onclick="printDiv('printableArea')" value="print" />
            </div>
            <br><br>
        </div>


    </section>




</body>

</html>
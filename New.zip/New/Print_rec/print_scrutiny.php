<?php
require_once '../includes/db_connect2.php';
?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?> Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword" content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="../img/logo.ico">



    <style type="text/css">
        table {
            page-break-inside: avoid;
        }

        h1,
        h2,
        h3,
        h4,
        h5 {
            page-break-after: avoid;
        }

        @page {
            size: A4 landscape;
            font-size: small;
        }

        @page :left {
            margin-left: 1cm;
        }

        @page :right {
            margin-left: 2cm;
        }
    </style>


    <script type="text/javascript">
        function printDiv(div_id) {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var content_vlue = document.getElementById(div_id).innerHTML;

            var docprint = window.open("", "", disp_setting);

            ///// Enable Bootstrap CSS
            //// Can also add customise CSS
            docprint.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
            );
            docprint.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    </script>

</head>

<body>
    <section class="body">


        <div class="inner-wrapper">
            <div class="row">


                <?php
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                if ($conn2->connect_error) {
                    die("Connection failed: " . $conn2->connect_error);
                }
                $DegType = $_SESSION['DegType'];
                $_SESSION['sn'] = 0;

                $deptname = "";

                $getdept = $_SESSION['dept_sctny'];
                $getsession = $_SESSION['getsession_sctny'];
                $getsemester = $_SESSION['getsemester_sctny'];
                $getlevel = $_SESSION['getlevel_sctny'];

                $schcode = $_SESSION['schcode'];
                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["HOD_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE SchCode = '$schcode' AND (cat = 'Dean' OR cat = 'HODDean' OR cat = 'PGExam')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["Dean_Sign"] = $row["full_name"];
                    }
                }
                ?>
                <section class="panel panel-success">

                    <div class="panel-body">

                        <!--<div class="row">
                        <div class="col-lg-4">
                            Department: <?php /*echo $deptname; */ ?>
                        </div>
                        <div class="col-lg-2">
                            Level:  <?php /*echo $_SESSION['getlevel_sctny']; */ ?>
                        </div>
                        <div class="col-lg-3">
                            Session:  <?php /*echo $_SESSION['getsession_sctny']; */ ?>
                        </div>
                        <div class="col-lg-3">
                            Semester:  <?php /*echo $_SESSION['getsemester_sctny']; */ ?>
                        </div>

                    </div>
-->
                        <br>
                        <div class="col-lg-12" id="printableArea" style="width: auto; float: none">
                            <?php
                            /*unset($LblCodeArray);
                        $LblCodeArray[]="";
                        unset($CourseCodeArray);
                        $CourseCodeArray[]="";
                        $countCCode=0;
                        $deptgencourses = $getdept."_gencourses";

                        $sql = "SELECT * FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $countCCode++;
                                $CourseCodeArray[$countCCode] = $row["CCode"];
                                $CCode=$row["CCodeSepr"];
                                $LblCodeArray[$countCCode]=$CCode." (".$row["CUnit"].")";
                            }
                        }*/

                            ?>
                            <style>
                                table,
                                th,
                                td {
                                    border: 1px solid black;
                                    border-collapse: collapse;
                                    text-align: center;
                                }

                                table,
                                td {
                                    font-size: 13px;
                                }
                            </style>
                            <h2 style="text-align: center">
                                <?php echo $_SESSION['instname'] ?><br>
                                <?php echo $_SESSION['sch_faculty'] ?> OF
                                <?php echo strtoupper($_SESSION['schname']); ?>
                            </h2>

                            <table style="width: 99%; border:2em">
                                <thead>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:x-large; padding-bottom: 1em" colspan="30">
                                            DEPARTMENT OF
                                            <?php echo strtoupper($_SESSION['deptname']); ?></td>
                                    </tr>

                                    <tr>

                                        <th style="border-style: none; text-align:center; font-size:small" colspan="6">
                                            SESSION :
                                            <?php echo $_SESSION['getsession_sctny']; ?></th>

                                        <th style="border-style: none; text-align:center; font-size:small" colspan="6">
                                            SEMESTER:
                                            <?php echo $_SESSION['getsemester_sctny']; ?></th>

                                        <th style="border-style: none; text-align:center; font-size:small" colspan="6">
                                            LEVEL :
                                            <?php echo $_SESSION['getlevel_sctny']; ?></th>

                                    </tr>
                                    <tr>
                                        <th style='text-align:center'>S/ No</th>
                                        <th style='text-align:center'>Matric_No</th>
                                        <th style='text-align:center'>Name</th>
                                        <?php if ($getlevel == 200) { ?>
                                            <th style="font-size: 10px">100L CGPA</th>
                                        <?php } ?>
                                        <?php if ($getlevel == 300) { ?>
                                            <th style="font-size: 10px">100L CGPA</th>
                                            <th style="font-size: 10px">200L CGPA</th>
                                        <?php } ?>
                                        <?php if ($getlevel == 400) { ?>
                                            <th style="font-size: 10px">100L CGPA</th>
                                            <th style="font-size: 10px">200L CGPA</th>
                                            <th style="font-size: 10px">300L CGPA</th>
                                        <?php } ?>
                                        <?php if ($getlevel == 500) { ?>
                                            <th style="font-size: 10px">100L CGPA</th>
                                            <th style="font-size: 10px">200L CGPA</th>
                                            <th style="font-size: 10px">300L CGPA</th>
                                            <th style="font-size: 10px">400L CGPA</th>
                                        <?php } ?>
                                        <th style='text-align:center'>PCT</th>
                                        <th style='text-align:center'>PCP</th>
                                        <th style='text-align:center'>PGP</th>
                                        <th style='text-align:center'>PCGPA</th>
                                        <th style=' text-align:center'>SCT</th>
                                        <th style='text-align:center'>SCP</th>
                                        <th style='text-align:center'>SGP</th>
                                        <th style='text-align:center'>SGPA</th>
                                        <th style='text-align:center'>TCT</th>
                                        <th style='text-align:center'>TCP</th>
                                        <th style=' text-align:center'>TGP</th>
                                        <th style='text-align:center'>CGPA</th>
                                        <th style='text-align:center'>RMK</th>
                                        <th>Deff. & Outstanding</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sno = 0;
                                    $DEFCount = 0;
                                    $IGSCount = 0;
                                    $SP1Count = 0;
                                    $SP2Count = 0;
                                    $PCount = 0;
                                    $DLCount = 0;
                                    $VCLCount = 0;
                                    $Ten88Count = 0;
                                    $BL2Count = 0;
                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }

                                    $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND board_aproval = 'Approve' AND senate_aproval <> 'Approve' ORDER BY Regn";
                                    $result = $conn_stu->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $sno++;
                                            $regid = $row["Regn"];
                                            $names = $row["Name1"];
                                            $id = $row["sn"];
                                            $aproval = $row['board_aproval'];
                                            $coment = $row["board_comment"];

                                            $defout = $def = $out = $rmk = $grade = "";


                                            $unit = $ptct = $ptcp = $pgp = $pcgpa = $stct = $stcp = $sgp = $scgpa = $tct = $tcp = $tgp = $cgpa = 0;
                                            $cgpa100 = $row['CGPA100'];
                                            $cgpa200 = $row['CGPA200'];
                                            $cgpa300 = $row['CGPA300'];
                                            $cgpa400 = $row['CGPA400'];

                                            $ptct = $row['PCT'];
                                            $ptcp = $row['PCP'];
                                            $pgp = $row['PGP'];
                                            $pcgpa = $row['PCGPA'];

                                            $stct = $row['SCT'];
                                            $stcp = $row['SCP'];
                                            $sgp = $row['SGP'];
                                            $scgpa = $row['SGPA'];
                                            $tct = $row['TCT'];
                                            $tcp = $row['TCP'];
                                            $tgp = $row['CGP'];
                                            $cgpa = $row['CGPA'];
                                            $rmk = $row['RMK'];
                                            $defout = $row['def_out'];

                                            if ($rmk == "P") {
                                                $PCount++;
                                                //$PtotCount++;
                                            } elseif ($rmk == "IGS") {
                                                $IGSCount++;
                                                //IGStotCount = IGStotCount + 1
                                            } elseif ($rmk == "DEF") {
                                                $DEFCount++;
                                                //DEFtotCount = DEFtotCount + 1
                                            } elseif ($rmk == "SP1") {
                                                $SP1Count++;
                                                //SP1totCount = SP1totCount + 1
                                            } elseif ($rmk == "SP2") {
                                                $SP2Count++;
                                                //SP2totCount = SP2totCount + 1
                                            } elseif ($rmk == "DL") {
                                                $DLCount++;
                                                //DLtotCount = DLtotCount + 1
                                            } elseif ($rmk == "VL") {
                                                $VCLCount++;
                                                //VCtotCount = VCtotCount + 1
                                            }

                                            if ($ptct == 0) {
                                                $ptct = "";
                                                $ptcp = "";
                                                $pgp = "";
                                                $pcgpa = "";
                                            } else {
                                                $ptct = $row['PCT'];
                                                $ptcp = $row['PCP'];
                                                $pgp = $row['PGP'];
                                                $pcgpa = $row['PCGPA'];
                                            }
                                            if ($stct == 0) {
                                                $stct2 = "";
                                                $stcp = "";

                                                $Response = "";

                                                $sql2 = "SELECT * FROM missing_session WHERE matno = '$regid' AND session = '$getsession' AND semester = '$getsemester'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $Response = $row2["response"];
                                                    }
                                                }
                                                if ($Response == "Deferment") {
                                                    $sgp = "Defe";
                                                    $scgpa = "rred";
                                                } elseif ($Response == "Condonation") {
                                                    $sgp = "Con";
                                                    $scgpa = "done";
                                                } elseif ($Response == "VolWithdrawal") {
                                                    $sgp = "With";
                                                    $scgpa = "drawn";
                                                } elseif ($Response == "PoorWithdrawal") {
                                                    $sgp = "With";
                                                    $scgpa = "drawn";
                                                } else {
                                                    $sgp = "Abs";
                                                    $scgpa = "cond";
                                                }
                                            } else {
                                                $stct2 = $row['SCT'];
                                                $stcp = $row['SCP'];
                                                $sgp = $row['SGP'];
                                                $scgpa = $row['SGPA'];
                                            }



                                            echo "<tr><td>$sno</td><td>$regid </td><td style='text-align: left'> $names</td>";
                                            if ($getlevel == 200) {
                                                echo "<td>$cgpa100</td>";
                                            } elseif ($getlevel == 300) {
                                                echo "<td>$cgpa100</td><td>$cgpa200</td>";
                                            } elseif ($getlevel == 400) {
                                                echo "<td>$cgpa100</td><td>$cgpa200</td><td>$cgpa300</td>";
                                            } elseif ($getlevel == 500) {
                                                echo "<td>$cgpa100</td><td>$cgpa200</td><td>$cgpa300</td><td>$cgpa400</td>";
                                            }
                                            if ($stct == 0) {
                                                if ($Response == "Deferment" || $Response == "Condonation") {
                                                    echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td>$sgp</td><td>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$rmk</td><td style='text-align: left'>$defout</td>";
                                                } else {
                                                    echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td>$sgp</td><td>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$rmk</td><td style='text-align: left'>$defout</td>";
                                                }
                                            } else {
                                                echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td>$sgp</td><td>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$rmk</td><td style='text-align: left'>$defout</td>";
                                            }


                                            echo "</tr>\n";
                                        }
                                        $SubTotal = $PCount + $IGSCount + $DEFCount + $SP1Count + $SP2Count + $DLCount + $VCLCount + $Ten88Count + $BL2Count;
                                    ?>
                                        <tr>
                                            <th style="border-style: none; text-align:center; padding-top: 2em; padding-bottom: 1em" colspan="15">SUMMARY</th>
                                        </tr>
                                        <tr>
                                            <th style="border-style: none; padding: 0.5em" colspan="2">VCL:
                                                <?php echo $VCLCount ?></th>
                                            <th style="border-style: none; padding: 0.5em" colspan="1">DL:
                                                <?php echo $DLCount ?></th>
                                            <th style="border-style: none; padding: 0.5em" colspan="3">IGS:
                                                <?php echo $IGSCount ?></th>
                                            <th style="border-style: none; padding: 0.5em" colspan="3">DEF:
                                                <?php echo $DEFCount ?></th>
                                            <th style="border-style: none; padding: 0.5em" colspan="3">P:
                                                <?php echo $PCount ?></th>

                                        </tr>
                                        <tr>

                                            <th style="border-style: none; padding: 0.5em" colspan="2">SP1:
                                                <?php echo $SP1Count ?></th>
                                            <th style="border-style: none; padding: 0.5em" colspan="1">SP2:
                                                <?php echo $SP2Count ?></th>
                                            <?php if ($DegType == "BEng") { ?>
                                                <th style="border-style: none; padding: 0.5em" colspan="3">8-7-6:
                                                    <?php echo $Ten88Count ?></th>
                                                <th style="border-style: none; padding: 0.5em" colspan="3">BL2:
                                                    <?php echo $BL2Count ?></th>
                                            <?php } ?>
                                            <th style="border-style: none; padding: 0.5em" colspan="3">Total:
                                                <?php echo $SubTotal ?></th>
                                        </tr>
                                    <?php
                                    }



                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="8">
                                            <?php echo $_SESSION["HOD_Sign"] ?></td>
                                        <td style="border-style: none; text-align:center; font-size:small; padding-top: 3em" colspan="8">
                                            <?php echo $_SESSION["Dean_Sign"] ?></td>
                                    </tr>
                                    <tr>
                                        <th style="border-style: none; text-align:center; font-size:small" colspan="8">
                                            HOD's SIGNATURE AND DATE
                                        </th>
                                        <th style="border-style: none; text-align:center; font-size:small" colspan="8">
                                            DEAN's SIGNATURE AND DATE
                                        </th>
                                    </tr>
                                </tfoot>
                            </table>

                        </div>

                        <br><br>
                        <div class="row" style="text-align: right; padding-right: 3em">
                            <input type="button" onclick="printDiv('printableArea')" value="print" />
                        </div>

                    </div>
                </section>
                <br><br><br>
                <?php
                $conn->close();
                $conn2->close();
                $conn_stu->close();
                ?>
            </div>
        </div>


    </section>




</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_validation'] == false) {
    header('Location: Home_Staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>

</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Validation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Course
                            </li>
                            <li class="active">
                                <strong>Course Validation</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php
                

                $staffnames = $_SESSION['names'];
                $staffid = $_SESSION['staffid'];
                $ValStatus = "";

                if (isset($_POST["submit_selval"])) {
                    $seloption = $_POST["seloption"];
                    if ($seloption == "LevelAdviser") {
                        $_SESSION["seloption"] = "LevelAdviceVal";
                        $ValStatus = "As Level Adviser";
                    } elseif ($seloption == "HOD") {
                        $_SESSION["seloption"] = "HODVal";
                        $ValStatus = "As HOD";
                    }
                }
                ?>
                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Validation <?php echo $ValStatus ?>
                        </div>
                        <?php $_SESSION['loadformval'] = "YES"; ?>
                        <div class="panel-body">
                            <div>
                                <form class="form-horizontal" method="post">
                                    <div class="row">
                                        <div class="form-group">
                                            <div class="col-lg-1">
                                            </div>
                                            <div class="col-lg-3">
                                                <input type="radio" name="validation" value="validated"> Validated
                                            </div>
                                            <div class="col-lg-3">
                                                <input type="radio" name="validation" value="yetvalidate"> Yet to
                                                Validate
                                            </div>
                                            <div class="col-lg-2">
                                                <input type="radio" name="validation" value="all" checked> All
                                            </div>
                                            <div class="col-lg-3">
                                                <?php
                                                if ($cat_HOD == "YES" || $cat_L100 == "YES" || $cat_L200 == "YES" || $cat_L300 == "YES" || $cat_L400 == "YES" || $cat_L500 == "YES") {
                                                    echo "<a class='' href='validation_list.php'>Get Validated List</a>";
                                                }
                                                ?>

                                            </div>
                                        </div>
                                    </div>
                                    <hr class="separator" />
                                    <div class="row">

                                        <div class="form-group">
                                            <label class="control-label col-lg-3" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-6">
                                                <select class="country form-control" style="color:#000000" name="dept">

                                                    <?php
                                                    $_SESSION['valdept'] = "";
        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        
                                                    $schcode = $_SESSION['schcode'];
                                                    $dept = $_SESSION['deptcode'];

                                                    if ($cat_L100 == "YES" || $cat_L200 == "YES" || $cat_L300 == "YES" || $cat_L400 == "YES" || $cat_L500 == "YES" || $cat_spill_over == "YES" || $cat_HOD == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept' AND students = 'yes'";
                                                    } else {
                                                        $sql = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptName";
                                                    }

                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = $row["DeptCode"];
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }
$conn->close();
                                                    ?>

                                                </select>

                                            </div>
                                            <div class="col-lg-3">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>


                                    </div>


                                </form>
                            </div>



                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"]) || isset($_POST["validate"]) || isset($_POST["sumcomment"])) { ?>
                                <div class="col-lg-12  col-md-12">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                                Course Validation
                                                <?php echo " " . $_SESSION['corntsession'] . " " ?>Session
                                            </div>
                                            <div class="panel-body">
                                                <div class="col-lg-3">
                                                    <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                    if ($conn2->connect_error) {
                                        die("Connection failed: " . $conn2->connect_error);
                                    }
                                    
                                                        $valregid = $valname = $valname2 = $valcoment = $valcat = "";

                                                        //$cat = $_SESSION['cat'];
                                                        $corntsession = $_SESSION['corntsession'];
                                                        $staffid = $_SESSION['staffid'];

                                                        $staflevel = $_SESSION['staflevel'];
                                                        if (isset($_POST["submit"])) {
                                                            $dept = strtolower($_POST["dept"]);
                                                            $valoption = $_POST["validation"];

                                                            $_SESSION['loadformval'] = "NO";
                                                            $_SESSION['valoption'] = $valoption;
                                                            $_SESSION['valcoment'] = "";
                                                        }

                                                        if (isset($_POST["validate"])) {
                                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                            if ($conn_stu->connect_error) {
                                                                die("Connection failed: " . $conn_stu->connect_error);
                                                            }

                                                            $valregid = $_POST["valregid"];
                                                            $valcat = $_POST["valcat"];
                                                            $getvalcat = $_POST["getvalcat"];
                                                            $getfieldcomt = $_POST["getfieldcomt"];
                                                            $getfieldName = $_POST["getfieldName"];
                                                            if ($_POST["comment"] == "") {
                                                                $comment = "_";
                                                            } else {
                                                                $comment = str_replace("'", "", $_POST["comment"]);
                                                                $comment = validate_input($comment);
                                                            }


                                                            $sql = "SELECT * FROM std_data_view WHERE matric_no = '$valregid'";
                                                            $result = $conn2->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    //$valname = $row['names'];
                                                                    $valname = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                                    $valname = strtolower($valname);
                                                                    $valname = ucwords($valname);
                                                                    $Stu_Dept_Option = strtoupper($row['Dept_Option']);
                                                                    $stucurriculum = $row["curriculum"];
                                                                }
                                                            }

                                                            if ($stucurriculum == "OLD") {
                                                                $curri2 = "";
                                                            } else {
                                                                $curri2 = "_" . $stucurriculum;
                                                            }

                                                            $curtsession = $_SESSION['corntsession'];
                                                            $dbsession = str_replace("/", "_", $curtsession);

                                                            $deptoption = $_SESSION['deptoption'];
                                                            $StuCurSess = str_replace("/", "_", $curtsession);
                                                            $deptcorreg = "correg_" . $StuCurSess;

                                                            // SQL to check if table exists
                                                            $sql = "SHOW TABLES LIKE '$deptcorreg'";
                                                            $result = $conn_stu->query($sql);
                                                            if ($result && $result->num_rows == 0) {
                                                                $sql2 = "CREATE TABLE " . $deptcorreg . " SELECT * FROM correg_empty";
                                                                $result2 = $conn_stu->query($sql2);
                                                            }




                                                            $sql = "DELETE FROM " . $deptcorreg . " WHERE Regn1 ='$valregid'";
                                                            $result = $conn_stu->query($sql);

                                                            $date1 = date("Y-m-d");
                                                            $valgetval = $_POST["valcoment"];
                                                            if ($_POST["valcoment"] == "Yet") {
                                                                $valStaff = "XX";
                                                                $_SESSION['valcoment'] = "Validation Cancel, Select next Matric No.";
                                                            } else {
                                                                $valStaff = $staffid . ' ' . $staffnames;
                                                                $valStaff = str_replace("'", "''", $valStaff);
                                                                $_SESSION['valcoment'] = "Validated, Select next Matric No.";

                                                                $sql = "SELECT * FROM courses_register_" . $dbsession . " WHERE Regn1 = '$valregid'";
                                                                $result = $conn->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $ccode = $row["CCode"];
                                                                        $CTitle = str_replace("'", "''", $row["CTitle"]);
                                                                        $CUnit = $row["CUnit"];
                                                                        $SemTaken = $row["SemTaken"];
                                                                        $CGroup = "NO";
                                                                        $Nature = $row["Nature"];
                                                                        $sql3 = "SELECT * FROM gencourses" . $curri2 . " WHERE C_codding = '$ccode'";
                                                                        $result3 = $conn_stu->query($sql3);
                                                                        if ($result3->num_rows > 0) {
                                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                                $Nature = $row3["Nature1"];
                                                                                $CUnit = $row3["credit"];
                                                                                if ($deptoption == "YES") {
                                                                                    $CGroup = $row3["Group" . $Stu_Dept_Option];
                                                                                } else {
                                                                                    $CGroup = $row3["Grouping2"];
                                                                                }
                                                                            }
                                                                        }

                                                                        $sql2 = "INSERT INTO " . $deptcorreg . " (Regn1, deptOption, CCode, CUnit, CTitle, SemTaken, CNature, SessionRegis, CA, Exam, grade, point, Grouping2, coursecondon, noexam, date, curriculum) VALUES ('$valregid', '$Stu_Dept_Option', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature', '$curtsession', '0', '0', 'F', '0', '$CGroup', 'NO', 'NO', '$date1', '$stucurriculum')";
                                                                        $result2 = $conn_stu->query($sql2);
                                                                    }
                                                                }
                                                            }


                                                            $sql = "UPDATE hod_list SET $getvalcat = '$valgetval', $getfieldcomt = '$comment', $getfieldName = '$valStaff' WHERE matricno = '$valregid' AND Session1 = '$corntsession'";
                                                            $result = $conn_stu->query($sql);
                                                            //}

                                                        }



                                                        if (isset($_POST["sumcomment"])) {
                                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                            if ($conn_stu->connect_error) {
                                                                die("Connection failed: " . $conn_stu->connect_error);
                                                            }

                                                            $valregid = $_POST["valregid"];
                                                            $valcat = $_POST["valcat"];
                                                            $getvalcat = $_POST["getvalcat"];
                                                            $getfieldcomt = $_POST["getfieldcomt"];
                                                            if ($_POST["comment"] == "") {
                                                                $comment = "_";
                                                            } else {
                                                                $comment = str_replace("'", "", $_POST["comment"]);
                                                                $comment = filter_var($comment, FILTER_SANITIZE_STRING);
                                                            }



                                                            $valgetval = $_POST["valcoment"];
                                                            $_SESSION['valcoment'] = "Comment Saved, Select next Matric No.";



                                                            $sql = "UPDATE hod_list SET $getfieldcomt = '$comment' WHERE matricno = '$valregid' AND Session1 = '$corntsession'";
                                                            $result = $conn_stu->query($sql);
                                                            //}

                                                        }
                                                        //echo $dept;
                                                        $_SESSION['valdept'] = $dept;

                                                        ?>

                                                    <select name="courses" class="form-control" style="color:#000000"
                                                        id="courses" size="20" onChange="showUser(this.value)">
                                                        <?php
                                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                            if ($conn_stu->connect_error) {
                                                                die("Connection failed: " . $conn_stu->connect_error);
                                                            }

                                                            if ($_SESSION["seloption"] == "LevelAdviceVal") {
                                                                if ($cat_L100 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '100' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '100' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '100' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_L200 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '200' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '200' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '200' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_L300 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '300' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '300' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '300' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_L400 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '400' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '400' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '400' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_L500 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '500' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '500' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '500' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_spill_over == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '600' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '600' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '600' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            } elseif ($_SESSION["seloption"] == "HODVal") {
                                                                if ($_SESSION['valoption'] == "validated") {
                                                                    $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND HOD = 'Validate' ORDER BY matricno";
                                                                } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                    $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '')  AND LevelAdvice = 'Validate' ORDER BY matricno";
                                                                } elseif ($_SESSION['valoption'] == "all") {
                                                                    $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND LevelAdvice = 'Validate' ORDER BY matricno";
                                                                }
                                                                $result = $conn_stu->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $matricno = $row["matricno"];
                                                                        $valname2 = $row["name1"];
                                                                        if ($matricno == $valregid) {
                                                                            echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                        } else {
                                                                            echo "<option value=$matricno>$matricno $valname2</option>";
                                                                        }
                                                                    }
                                                                }
                                                            } elseif ($cat_HOD == "YES") {
                                                                if ($_SESSION['valoption'] == "validated") {
                                                                    $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND HOD = 'Validate' ORDER BY matricno";
                                                                } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                    $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '')  AND LevelAdvice = 'Validate' ORDER BY matricno";
                                                                } elseif ($_SESSION['valoption'] == "all") {
                                                                    $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession' AND LevelAdvice = 'Validate' ORDER BY matricno";
                                                                }
                                                                $result = $conn_stu->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $matricno = $row["matricno"];
                                                                        $valname2 = $row["name1"];
                                                                        if ($matricno == $valregid) {
                                                                            echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                        } else {
                                                                            echo "<option value=$matricno>$matricno $valname2</option>";
                                                                        }
                                                                    }
                                                                }
                                                            } elseif ($cat_L100 == "YES" || $cat_L200 == "YES" || $cat_L300 == "YES" || $cat_L400 == "YES" || $cat_L500 == "YES" || $cat_spill_over == "YES") {
                                                                if ($cat_L100 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '100' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '100' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '100' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_L200 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '200' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '200' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '200' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_L300 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '300' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '300' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '300' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_L400 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '400' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '400' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '400' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_L500 == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '500' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '500' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '500' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                if ($cat_spill_over == "YES") {
                                                                    if ($_SESSION['valoption'] == "validated") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '600' AND Session1 = '$corntsession' AND LevelAdvice = 'Validate' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "yetvalidate") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '600' AND Session1 = '$corntsession' AND (LevelAdvice IS NULL OR LevelAdvice = 'Yet' OR LevelAdvice = '') ORDER BY matricno";
                                                                    } elseif ($_SESSION['valoption'] == "all") {
                                                                        $sql = "SELECT * FROM hod_list WHERE StuLevel = '600' AND Session1 = '$corntsession' AND (HOD IS NULL OR HOD = 'Yet' OR HOD = '') ORDER BY matricno";
                                                                    }
                                                                    $result = $conn_stu->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $matricno = $row["matricno"];
                                                                            $valname2 = $row["name1"];
                                                                            if ($matricno == $valregid) {
                                                                                echo "<option value=$matricno selected>$matricno $valname2</option>";
                                                                            } else {
                                                                                echo "<option value=$matricno>$matricno $valname2</option>";
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            ?>


                                                    </select>
                                                    <?php
                                                        $conn->close();
                                                        $conn2->close();
                                                        $conn_stu->close();
                                                        ?>

                                                </div>
                                                <div class="col-lg-9" style="color:#000">

                                                    <center><strong> <?php echo $valregid ?></strong></center>
                                                    <center><strong> <?php echo $valname ?></strong></center>
                                                    <center><strong> <?php echo $_SESSION['valcoment'] ?></strong>
                                                    </center>

                                                    <div id="txtHint"></div>
                                                    <br>

                                                </div>

                                            </div>
                                        </div>



                                    </div>
                                    <div class="col-lg-1">

                                    </div>


                                </div>



                                <?php } ?>

                            </div>


                        </div>
                    </div>



                </div>

            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>

        <script>
        function showUser(str) {
            if (str == "") {
                document.getElementById("txtHint").innerHTML = "";
                return;
            } else {
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else {
                    // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        document.getElementById("txtHint").innerHTML = this.responseText;
                    }
                };
                xmlhttp.open("GET", "course_validation_inc.php?q=" + str, true);
                xmlhttp.send();
            }
        }
        </script>
</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pg_staff_results'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_R.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Download Students Profile(PG)</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Download
                            </li>

                            <li class="active">
                                <strong>Download Students Profile(PG)</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Download Students Profile(PG)
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form class="form-horizontal" method="post">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-7">
                                                <select class="form-control" style="color:#000000" name="downloaddept">
                                                    <option value="SelectItem">Select Item</option>
                                                    <?php
                                                    //$cat = $_SESSION['cat'];
                                                    $dept = $_SESSION['deptcode'];

                                                    if ($cat_PG_Coord == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                    } else {
                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    }


                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = strtolower($row["DeptCode"]);
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <?php
                                            $finalyear = substr($_SESSION['corntsession'], 5);
                                            ?>
                                            <label class="control-label col-lg-5" for="regid">Year Admitted:</label>
                                            <div class="col-lg-7">
                                                <select name="getyearaddmt" class="form-control" style="color:#000000" id="getyearaddmt">
                                                    <option value="<?php echo $finalyear ?>"><?php echo $finalyear ?>
                                                    </option>
                                                    <?php
                                                    $iniyear = 2015;
                                                    //$finalyear = substr($_SESSION['corntsession'],5);

                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear'>$iniyear</option>";
                                                        $iniyear++;
                                                    }

                                                    //$conn->close();
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-9">
                                                <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1">

                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"])) { ?>
                                    <?php
                                    $downloaddept = $_POST['downloaddept'];
                                    $getyearaddmt = $_POST['getyearaddmt'];

                                    $sql2 = "SELECT * FROM deptcoding WHERE DeptCode = '$downloaddept'";
                                    $result2 = $conn->query($sql2);

                                    if ($result2->num_rows > 0) {
                                        while ($row = $result2->fetch_assoc()) {
                                            $downdeptname = $row["DeptName"];
                                        }
                                    }
                                    ?>
                                    <div class="col-lg-12  col-md-12">

                                        <div class="table-responsive">
                                            <?php
                                            set_time_limit(500);
                                            $GetTitle = $downdeptname . " Department";
                                            $sno = 0;
                                            ?>
                                            <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups" frame="hsides" border="2">
                                                <caption><?php echo $GetTitle ?></caption>
                                                <colgroup align="center"></colgroup>
                                                <colgroup align="left"></colgroup>
                                                <colgroup span="2"></colgroup>
                                                <colgroup span="3" align="center"></colgroup>
                                                <thead>
                                                    <tr>

                                                        <th>SNo</th>
                                                        <th>Registration No</th>
                                                        <th>Surname</th>
                                                        <th>First Name</th>
                                                        <th>Other Name</th>
                                                        <th>Programme Title</th>
                                                        <th>Programme</th>
                                                        <th>State of Origin</th>
                                                        <th>LGA</th>
                                                        <th>Date of Birth</th>
                                                        <th>Permanant Home Address</th>
                                                        <th>Nationality</th>
                                                        <th>Phone No</th>
                                                        <th>email</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sql = "SELECT * FROM pgapplication WHERE regid<>'' AND deptcode = '$downloaddept' ORDER BY regid";
                                                    $result = $conn4->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {

                                                            $regid = $row["regid"];
                                                            $sessionadmt = $row["session"];
                                                            if ($getyearaddmt == substr($sessionadmt, 0, 4)) {
                                                                $sno++;
                                                                $surname = $row["surname"];
                                                                $firstname = $row["firstname"];
                                                                $othername = $row["middlename"];
                                                                $programme_title = $row["programme_title"];
                                                                $stateorigin = $row["stateoforigin"];
                                                                $lga = $row["lga"];
                                                                $sex = $row["sex"];
                                                                $permaddres = $row["p_address"];
                                                                $programme = $row["course1"];
                                                                $nationality = $row["nationality"];
                                                                $dob = $row["date_of_birth"];
                                                                //$pob = $row["PlaceBirth"];
                                                                $phone1 = $row["phone"];
                                                                $email = $row["email"];

                                                                echo "<tr><td>$sno</td><td>$regid</td><td>$surname</td><td>$firstname</td><td>$othername</td><td>$programme_title</td><td>$programme</td><td>$stateorigin</td><td>$lga</td><td>$dob</td><td>$permaddres</td><td>$nationality</td><td>$phone1</td><td>$email</td></tr>\n";
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>



                                        </div>
                                        <br>
                                        <div style="text-align: right">
                                            <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                        </div>
                                    </div>



                                <?php } ?>
                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pg_staff_results'] == false) {
    header('Location: home_staff.php');
}

//$defer1st=$studeptcode="";

$cat = $_SESSION['cat'];
$staflevel = $_SESSION['staflevel'];
//$regid = $_POST["regid"];
$dept = $_SESSION['deptcode'];
$schcode = $_SESSION['schcode'];




?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--Print Div-->
    <script type="text/javascript">
        function printme() {
            var print_div = document.getElementById("printablediv");
            var print_area = window.open();
            print_area.document.write(print_div.innerHTML);
            print_area.document.close();
            print_area.focus();
            print_area.print();
            print_area.close();
        }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Students' Result</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-file"></i>
                                </a>
                            </li>
                            <li><span>Results</span></li>
                            <li><span>Students' Result</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">

                    <div class="col-md-1">
                    </div>
                    <div class="col-md-10">
                        <div>
                            <form class="form-horizontal form-bordered" method="post">
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Registration Number: </label>
                                    <div class="col-lg-5">
                                        <input type="text" class="form-control" style="color:#000000" name="regid">
                                    </div>
                                    <div class="col-lg-3">
                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                    </div>
                                </div>
                            </form>
                        </div>
                        <br>
                        <hr class="separator" />
                        <br>
                        <?php if (isset($_POST["submit"])) { ?>
                            <?php

                            $regid = $_POST["regid"];

                            //$_SESSION['regid']=$regid;
                            $sumunits = $sumgp = $point = $cgpa = 0;
                            $grade = "";
                            $no_rec = "NO";
                            $sql = "SELECT * FROM pgapplication WHERE regid = '$regid'";
                            $result = $conn4->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $studept = strtolower($row['deptcode']);
                                }
                            }

                            if ($cat == "HOD" || $cat == "PGHOD" || $cat == "HODLAdvice" || $cat == "Examiner" || $cat == "ExamLAdvice" || $cat == "PG" || $cat == "PGExam") {
                                if ($studept !== $dept) {
                                    $no_rec = "YES";
                                }
                            }

                            if ($no_rec == "NO") {

                                $sql = "SELECT * FROM e_data_profile WHERE regid = '$regid'";
                                $result = $conn4->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $stdid = $row['stdid'];
                                    }
                                }

                                $sql = "SELECT * FROM pgapplication WHERE applicant_id = '$stdid'";
                                $result = $conn4->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $studept = strtolower($row['deptcode']);
                                    }
                                }

                                $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$studept'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $deptname = $row["DeptName"];
                                    }
                                }

                                $sql2 = "SELECT * FROM reg_password WHERE stdid = '$stdid'";
                                $result2 = $conn4->query($sql2);
                                if ($result2->num_rows > 0) {
                                    while ($row2 = $result2->fetch_assoc()) {
                                        $names = $row2["CandName"];
                                    }
                                }

                            ?>
                                <section class="panel panel-success">
                                    <header class="panel-heading">
                                        <div class="panel-actions">
                                            <a href="#" class="fa fa-caret-down"></a>
                                            <a href="#" class="fa fa-times"></a>
                                        </div>

                                        <h2 class="panel-title"><?php echo $names ?></h2>
                                    </header>
                                    <div class="panel-body">

                                        <div class="col-md-1">
                                        </div>
                                        <div class="col-md-10">
                                            <?php
                                            $_SESSION["regid"] = $regid;
                                            $_SESSION['deptcode'] = $studept;
                                            $_SESSION['stdid'] = $stdid;
                                            $_SESSION['names'] = $names;
                                            $_SESSION['deptname'] = $deptname;

                                            echo "<div class='row'>";
                                            echo "<div class='col-lg-9'>";
                                            echo "Registration No :  " . $regid;
                                            echo "<br>";
                                            echo "Name:  " . $names;
                                            echo "</div>";
                                            echo "<div class='col-lg-3' style='text-align:right'>";
                                            echo "<img alt='' src='https://eportal.futminna.edu.ng/pg/uploads/" . $stdid . "_passport.jpg' width='100' height='100'>";

                                            echo "</div>";
                                            echo "</div>";
                                            //$studeptcode="aet";
                                            //echo "Yes";
                                            $norec = "YES";
                                            $sql = "SELECT * FROM " . $studept . "_correg WHERE regn1 = '$regid' ORDER BY SessionRegis, SemTaken";
                                            $result = $conn5->query($sql);

                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                                $norec = "NO";
                                            ?>
                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th>Course Code</th>
                                                            <th>Course Title</th>
                                                            <th>Unit</th>
                                                            <th>Semester</th>
                                                            <th>Session</th>
                                                            <th>Grade</th>
                                                            <th>GP</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>


                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            if ($row['CA'] + $row['Exam'] >= 70) {
                                                                $grade = "A";
                                                                $gp = $row['CUnit'] * 5;
                                                            } elseif ($row['CA'] + $row['Exam'] >= 60) {
                                                                $grade = "B";
                                                                $gp = $row['CUnit'] * 4;
                                                            } elseif ($row['CA'] + $row['Exam'] >= 50) {
                                                                $grade = "C";
                                                                $gp = $row['CUnit'] * 3;
                                                            } elseif ($row['CA'] + $row['Exam'] >= 45) {
                                                                $grade = "D";
                                                                $gp = $row['CUnit'] * 2;
                                                            } elseif ($row['CA'] + $row['Exam'] >= 40) {
                                                                $grade = "E";
                                                                $gp = $row['CUnit'] * 1;
                                                            } elseif ($row['CA'] + $row['Exam'] <= 39.95) {
                                                                $grade = "F";
                                                                $gp = 0;
                                                            }

                                                            echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['SessionRegis']}</td><td>$grade</td><td>$gp</td></tr>\n";
                                                            $sumunits += $row['CUnit'];

                                                            $sumgp +=  $gp;
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>

                                            <?php

                                            }

                                            echo "<center>";
                                            echo "<br>";
                                            echo "Total Credit Units =   " . $sumunits . "<br>";
                                            echo "Total Grade Points =  " . $sumgp . "<br>";
                                            if ($norec == "YES") {
                                                echo "CGPA =   "  . number_format(0, 2, '.', '');
                                            } else {
                                                echo "CGPA =   "  . number_format((float)$sumgp / $sumunits, 2, '.', '');
                                            }

                                            echo "<br><br>";
                                            ?>
                                            <div style="text-align: right">
                                                <input type="button" class='btn btn-info btn-sm' value="Print" onclick="printme()">
                                            </div>
                                            <?php

                                            echo "<br><br>";

                                            echo "</center>";

                                            ?>
                                        </div>
                                        <div class="col-md-1">
                                        </div>

                                    </div>
                                </section>
                            <?php } ?>
                        <?php } ?>
                    </div>
                    <div class="col-md-1">
                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>
    <!--Print Start-->
    <div id="printablediv" style="width: 100%; height: 200px;" hidden="hidden">
        <center><strong>
                <h3>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</h3>
            </strong></center>
        <center><strong>
                <h4>STUDENT'S ACADEMIC RECORD</h4>
            </strong></center>

        <?php


        $regid = $_SESSION["regid"];
        $dept = $_SESSION['deptcode'];
        $stdid = $_SESSION['stdid'];
        $names = $_SESSION['names'];
        $deptname = $_SESSION['deptname'];



        ?>
        <table width="100%">
            <tbody>
                <tr>
                    <td width="70%">
                        Registration Number: <?php echo $regid ?><br>
                        Student ID: <?php echo $stdid ?><br>
                        Name : <?php echo $names ?><br>
                        Department: <?php echo $deptname ?>
                    </td>
                    <td>
                        <figure class="profile-picture">
                            <?php echo "<img alt='' src='https://eportal.futminna.edu.ng/pg/uploads/" . $stdid . "_passport.jpg' width='100' height='100'>"; ?>
                        </figure>
                    </td>
                </tr>
            </tbody>
        </table>


        <?php
        $sql = "SELECT * FROM " . $dept . "_correg WHERE regn1 = '$regid' ORDER BY SessionRegis, SemTaken, CCode";
        $result = $conn5->query($sql);

        if ($result->num_rows > 0) {
        ?>
            <br>
            <table style="border-collapse: collapse; width: 100%;">
                <thead>
                    <tr>
                        <th style="text-align: left; border: 1px solid #ccc;">Course Code</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Course Title</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Unit</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Semester</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Session</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Grade</th>
                        <th style="text-align: left; border: 1px solid #ccc;">GP</th>
                    </tr>
                </thead>
                <tbody>


                    <?php
                    while ($row = $result->fetch_assoc()) {
                        if ($row['CA'] + $row['Exam'] >= 70) {
                            $grade = "A";
                            $gp = $row['CUnit'] * 5;
                        } elseif ($row['CA'] + $row['Exam'] >= 60) {
                            $grade = "B";
                            $gp = $row['CUnit'] * 4;
                        } elseif ($row['CA'] + $row['Exam'] >= 50) {
                            $grade = "C";
                            $gp = $row['CUnit'] * 3;
                        } elseif ($row['CA'] + $row['Exam'] >= 45) {
                            $grade = "D";
                            $gp = $row['CUnit'] * 2;
                        } elseif ($row['CA'] + $row['Exam'] >= 40) {
                            $grade = "E";
                            $gp = $row['CUnit'] * 1;
                        } elseif ($row['CA'] + $row['Exam'] <= 39.95) {
                            $grade = "F";
                            $gp = 0;
                        }

                        echo "<tr><td style='text-align: left; border: 1px solid #ccc;'>{$row['CCode']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['CTitle']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['CUnit']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['SemTaken']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['SessionRegis']}</td><td style='text-align: left; border: 1px solid #ccc;'>$grade</td><td style='text-align: left; border: 1px solid #ccc;'>$gp</td></tr>\n";
                        $sumunits += $row['CUnit'];

                        $sumgp += $gp;
                    }


                    ?>
                </tbody>
            </table>


        <?php } ?>

        <br>
        <center>
            <?php
            echo "<br>";
            echo "Total Credit Units =   " . $sumunits . "<br>";
            echo "Total Grade Points =  " . $sumgp . "<br>";
            if ($norec == "YES") {
                echo "CGPA =   "  . number_format(0, 2, '.', '');
            } else {
                echo "CGPA =   "  . number_format((float)$sumgp / $sumunits, 2, '.', '');
            }
            ?>
        </center>


    </div>

    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
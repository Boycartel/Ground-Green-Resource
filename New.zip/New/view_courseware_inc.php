<table class="table mb-none">
	<thead>
		<tr>

			<th>Course Code</th>
			<th>Material Title</th>
			<th>Click to Download</th>
			<th>Action</th>
		</tr>
	</thead>
	<tbody>
		<?php
		require_once 'includes/db_connect.php';
		require_once 'includes/check_validity.php';

		$curtsession = $_SESSION['corntsession'];
		$savesession = substr($curtsession, 0, 4) . "_" . substr($curtsession, -4);
		$staffid = $_SESSION['staffid'];

		//if(isset($_POST["submit"])){
		$thelist = "";
		$fname = "";
		$course = $_GET['q'];

		$_SESSION['getcoursedel'] = $course;
		$ckfolder = "Content/$savesession/$course";
		if (is_dir($ckfolder)) {

			if ($handle = opendir($ckfolder)) {
				while (false !== ($file = readdir($handle))) {
					if ($file != "." && $file != "..") {
						//$thelist .= '<li><a href="'.$file.'">'.$file.'</a></li>';
						$sql = "SELECT * FROM courseware WHERE savepath = '$file'";
						$result = $conn->query($sql);

						if ($result->num_rows > 0) {
							while ($row = $result->fetch_assoc()) {
								$fname = $row["bookname"];
								$filenam = $row["savepath"];
								$id = $row["id"];
							}
							$thelist .= "<a href='download_courseware.php?filename1=" . $file . "'>$file</a>";
							echo "<tr><td>$course</td><td>$fname</td><td>$thelist</td>
						<td>
							 <form action='courseware_delete.php' method='post'>
								  <input type='hidden' value=$id name='id'>
								  <input type='hidden' value=$filenam name='filenam'>
								  <input type='submit' class='btn btn-info btn-xs' value='Remove'>
							 </form>
						
						</td>
					</tr>\n";
							$thelist = "";
						}
					}
				}
				closedir($handle);
				//$_SESSION['downlcurse']=$course;
				//$_SESSION['downlsession']=$savesession;
			}
		}
		echo "</tbody>";
		echo "</table>";

		//$conn->close();
		?>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php

    $deptoption = $_SESSION['deptoption'];
    $deptname = $_SESSION["deptname"];
    $schcode = $_SESSION['schcode'];

    $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = 0;
    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Graduating Students Spreadsheet</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Graduating Students Spreadsheet</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Graduating Students Spreadsheet 1<sup>st</sup> Semester
                        </div>
                        <div class="panel-body">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <?php echo $deptname ?> Department
                                </div>
                                <div class="panel-body">
                                    <form class="form-horizontal form-bordered" action="" method="post">
                                        <div class="row">

                                            <div class="col-lg-4">
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="regid">Year of
                                                        Graduation:</label>
                                                    <div class="col-lg-7">
                                                        <?php
                                                        $iniyear = 2015;
                                                        $finalyear = substr($_SESSION['corntsession'], 5) + 1;

                                                        ?>
                                                        <select name="getyeargrad" class="form-control"
                                                            style="color:#000000" id="getyeargrad">
                                                            <option value="<?php echo $finalyear ?>">
                                                                <?php echo $finalyear ?></option>
                                                            <?php
                                                            while ($iniyear <= $finalyear) {
                                                                $addyear = $iniyear + 1;

                                                                echo "<option value = '$iniyear'>$iniyear</option>";
                                                                $iniyear++;
                                                            }

                                                            ?>


                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="row">
                                                    <label class="control-label col-lg-12" for="content">Semester:
                                                        1ST</label>

                                                </div>
                                            </div>
                                            <div class="col-lg-4">

                                            </div>
                                            <div class="col-lg-4">
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <button type="submit" name="submit"
                                                            class="btn btn-primary btn-sm">Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </form>

                                    <hr class="separator" />
                                    <?php
                                    if (isset($_POST["Submit_grad_1st"])) {
                                        $pick1stRegNo = $_SESSION["pick1stRegNo"];
                                        $getdept = $_SESSION['deptcode'];

                                        $deptoption = $_SESSION['deptoption'];
                                        $getyeargrad = $_SESSION['getyeargrad'];

                                        //$dept_scrutiny_senate = $getdept . "_scrutiny_senate";
                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        $sql = "UPDATE scrutiny_senate SET grad_1st_sel = 'NO' WHERE yearGrad = '$getyeargrad' AND semester = '1ST' AND graduated = 'NO'";
                                        $result = $conn_stu->query($sql);

                                        foreach ($pick1stRegNo as $RegNo) {
                                            $sql = "UPDATE scrutiny_senate SET grad_1st_sel = 'YES' WHERE yearGrad = '$getyeargrad' AND semester = '1ST' AND Regn = '$RegNo'";
                                            $result = $conn_stu->query($sql);
                                        }
                                        $conn_stu->close();
                                        echo "<h2>Record Saved...</h2>";
                                    }
                                    ?>

                                    <?php if (isset($_POST["submit"])) { ?>
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="row">
                                            <div class="col-lg-2">

                                            </div>
                                            <div class="col-lg-8">
                                                <table class="table table-bordered table-striped mb-none">
                                                    <thead style='text-align:center'>
                                                        <tr>
                                                            <th>S/No</th>
                                                            <th>Check to Select</th>
                                                            <th>Matric No</th>
                                                            <th>Name</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            $getdept = $_SESSION['deptcode'];

                                                            $_SESSION['getyeargrad'] = $_POST['getyeargrad'];
                                                            //$getsemester = $_SESSION['semesterSel'];
                                                            $deptoption = $_SESSION['deptoption'];
                                                            //$deptname = $_SESSION["deptname"];
                                                            //$schcode=$_SESSION['schcode'];
                                                            //$dept_scrutiny_senate = $getdept . "_scrutiny_senate";
                                                            $getyeargrad = $_SESSION['getyeargrad'];

                                                            $sno = 0;
                                                            $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                            if ($conn_stu->connect_error) {
                                                                die("Connection failed: " . $conn_stu->connect_error);
                                                            }

                                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '1ST' AND def_out = '' AND graduated = 'NO' ORDER BY Regn";
                                                            //$sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '1ST' AND graduated = 'NO' ORDER BY Regn";
                                                            $result = $conn_stu->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $sno++;
                                                                    $regid = $row["Regn"];
                                                                    $names = $row["Name1"];
                                                                    $ccgpa = $row['CGPA'];
                                                                    $id = $row["sn"];

                                                                    echo "<tr><td style='text-align:center'>$sno</td>";
                                                                    echo "<td><input type='checkbox' name='chosen1[" . $id . "]' value='" . $id . "'/></td>";
                                                                    echo "<td style='text-align:center'>
                                                        <label id='ccode' name='ccode[" . $id . "]'>$regid</label>
                                                        <input type='hidden' id='ccode' name='ccode[" . $id . "]' value='" . $regid . "'/>
                                                        </td>";
                                                                    echo "<td> $names</td>";

                                                                    echo "</tr>\n";
                                                                }
                                                            }
                                                            $conn_stu->close();
                                                            ?>
                                                    </tbody>
                                                </table>

                                            </div>
                                            <div class="col-lg-2">

                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-lg-2">

                                            </div>
                                            <div class="col-lg-8" style="text-align: right">
                                                <br><br>
                                                <button type="submit" name="submit_1ST"
                                                    class="btn btn-primary btn-sm">Submit</button>
                                                <br><br>
                                            </div>
                                            <div class="col-lg-2">

                                            </div>

                                        </div>
                                    </form>
                                    <?php } ?>

                                    <?php if (isset($_POST["submit_1ST"])) { ?>
                                    <div class="col-lg-12">
                                        <table class="table table-bordered table-striped mb-none"
                                            id="datatable-default">
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Matric No</th>
                                                    <th>Name</th>
                                                    <th>CGPA</th>
                                                    <th>Class of Degree</th>
                                                    <?php if ($deptoption == "YES") { ?>
                                                    <th>Department Option</th>
                                                    <?php } ?>
                                                    <th>Deficiency/Outstanding</th>
                                                    <th>Action</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $ccgpa = 0;
                                                    $classdegree = "";
                                                    $sno = 0;
                                                    $classdegree_code = 0;
                                                    $NON_DE_Senate = false;
                                                    $DE200Senate = false;
                                                    $DE300Senate = false;

                                                    $getdept = $_SESSION['deptcode'];

                                                    $deptoption = $_SESSION['deptoption'];
                                                    $getyeargrad = $_SESSION['getyeargrad'];

                                                    unset($corecoursearray);
                                                    $corecoursearray[] = "";

                                                    unset($groupCodearray);
                                                    $groupCodearray[] = "";
                                                    $groupCodecount = 0;

                                                    $optCount = 0;
                                                    $deptgencourses = $getdept . "_gencourses";

                                                    unset($regcoursesarray);
                                                    $regcoursesarray[] = "";
                                                    $countcoursesarray = 0;

                                                    unset($pick1stRegNo);
                                                    $pick1stRegNo[] = "";
                                                    $pick1stRegNoCount = 0;

                                                    $YesDeficient = false;
                                                    $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;

                                                    //$dept_scrutiny_senate = $getdept . "_scrutiny_senate";
                                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    $sql = "UPDATE scrutiny_senate SET classdegree = 'XX', classdegree_code = '0', CGPA_grad_1st = '0' WHERE yearGrad = '$getyeargrad' AND semester = '1ST' AND graduated = 'NO'";
                                                    $result = $conn_stu->query($sql);
$conn_stu->close();

                                                    if (!empty($_POST["chosen1"])) {
                                                        foreach ($_POST["chosen1"] as $key => $value) {
                                                            $regid = $_POST["ccode"][$key];
                                                            $pick1stRegNoCount++;
                                                            $pick1stRegNo[$pick1stRegNoCount] = $regid;
                                                            $sno++;
                                                            $deptcorreg = $getdept . "_correg";
                                                            $deptgencourses = $getdept . "_gencourses";

                                                            $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                            if ($conn_stu->connect_error) {
                                                                die("Connection failed: " . $conn_stu->connect_error);
                                                            }

                                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '1ST' AND Regn = '$regid'";
                                                            $result = $conn_stu->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $id = $row["sn"];
                                                                    $regid = $row["Regn"];
                                                                    $names = $row["Name1"];
                                                                    $ccgpa = $row["CGPA"];

                                                                    $NON_DE_Senate = false;
                                                                    $DE200Senate = false;
                                                                    $DE300Senate = false;

                                                                    if (empty($row["DeptOpt"])) {
                                                                        $Deptopt2 = "";
                                                                    } else {
                                                                        $Deptopt2 = $row["DeptOpt"];
                                                                    }
                                                                }
                                                            }
                                                            $conn_stu->close();
                                                            $cgpa = $ccgpa;
                                                            include 'modulesInSess/check_graduating.php';
                                                            //$ccgpa = $CGPA500;

                                                            include 'modulesInSess/classofdegree_inc.php';



                                                            //$sql2 = "UPDATE scrutiny_senate SET CGPA_grad_1st = '$ccgpa' WHERE sn = '$id'";
                                                            //$result2 = $conn_stu->query($sql2);

                                                            if ($strDefficiency != "") {
                                                                $YesDeficient = true;
                                                            }
                                                            $ccgpa = number_format($ccgpa, 2);
                                                            echo "<tr><td>$sno</td><td>$regid</td><td>$names</td><td>$ccgpa</td><td>$classdegree</td>";
                                                            if ($deptoption == "YES") {
                                                                echo "<td>$Deptopt2</td>";
                                                            }

                                                            echo "<td>$strDefficiency</td><td>
                                                <form action='spreadsheet_grad_view.php' method='post' target='_blank'>
                                                    <input type='hidden' value='$regid' name='id'>
                                                    <input type='submit' name='view1stsem' class='btn btn-info btn-xs' value='View'>
                                                </form>
                                                </td>";

                                                            echo "</tr>\n";
                                                        }
                                                    }
                                                    $_SESSION["pick1stRegNo"] = $pick1stRegNo;

                                                    ?>
                                            </tbody>
                                        </table>
                                        <br><br>
                                    </div>
                                    <?php if ($YesDeficient == false) { ?>
                                    <div class="row" style="text-align: right">
                                        <form action='' method='post'>
                                            <input type='submit' name='Submit_grad_1st' class='btn btn-success btn-sm'
                                                value='Submit'>
                                        </form>
                                    </div>
                                    <?php } else { ?>
                                    <h3 style="color: red">Deficient Students need to be remove from the list before
                                        submitting</h3>
                                    <?php } ?>
                                    <?php } ?>
                                </div>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
if (isset($_POST["submit_class"])) {
    header('Location: classroom_course.php');
}

require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$usernames = $_SESSION['names'];
$cat = $_SESSION['cat'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$staffid = $_SESSION['staffid'];
$dept = strtoupper($_SESSION['deptcode']);
$_SESSION["course_title_assignment"] = "Assignment";


?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">
    <!-- Textarea Editor -->
    <link href="editor/css_/bootstrap3-wysihtml5.min.css" rel="stylesheet" media="screen" />
    <!--Download to excel-->
    <script src="assets/javascripts/tableToExcel_ATD.js"></script>
    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <?php
                $imgpf = str_replace('.', '_', $_SESSION['staffid']);

                ?>

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php

                            echo "<img src='https://staff.futminna.edu.ng/" . strtoupper($_SESSION['deptcode']) . "/images/" . strtoupper($imgpf) . "/MyPic1.jpg' alt='$usernames' class='img-circle' width='50' height='50' />";
                            ?>
                        </figure>
                        <div class="profile-info">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $staffid ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="staff_profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_staff.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="lock_screen.php"><i class="fa fa-lock"></i> Lock
                                    Screen</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout_staff.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>




                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_staff_class.php'; ?>
            <!-- end: sidebar -->
            <?php
            //$C_title="Classroom";



            if (isset($_POST["end_class"])) {
                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
                if ($_SESSION["topics_id"] == 0) {
                    $_SESSION["be_on_chat"] = "NO";
                } else {
                    $_SESSION["be_on_chat"] = "YES";
                }
            }

            if (isset($_POST["end_class_confirm"])) {
                $getccode = $_SESSION["getccode"];
                $sql = "DELETE FROM aaa_online_courses WHERE ccode='$getccode'";
                $result = $conn8->query($sql);

                $sql = "DELETE FROM aaa_online_stu WHERE ccode = '$getccode'";
                $result = $conn8->query($sql);

                $_SESSION["getccode"] = "";
                $_SESSION["inipost"] = "";
                $_SESSION["newtopic"] = "NO";
                $_SESSION["course_title"] = "Classroom";
                $_SESSION["topics"] = "Classroom";
                $_SESSION["topics_id"] = 0;
                $_SESSION["showchat"] = 0;
                $_SESSION["startchat"] = "YES";
                $_SESSION["noonline"] = 0;
            }

            if (isset($_POST["delete_chat"])) {
                $getccode = strtolower($_SESSION["getccode"]);
                $id_chat = $_POST["id_chat"];

                $sql = "DELETE FROM " . $getccode . " WHERE id='$id_chat'";
                $result = $conn8->query($sql);
            }

            if (isset($_POST["remove_meet"])) {
                $getccode = strtolower($_SESSION["getccode"]);
                $sql = "DELETE FROM meeturl WHERE ccode = '$getccode'";
                $result = $conn8->query($sql);
            }

            if (isset($_POST["submit_topic"]) || isset($_POST["viewtopic"]) || isset($_POST["savetopic"]) || isset($_POST["updatetopic"]) || isset($_POST["deletetopic"])) {

                //$_SESSION["topics_id"] = 0;
                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
                if ($_SESSION["topics_id"] == 0) {
                    $_SESSION["be_on_chat"] = "NO";
                } else {
                    $_SESSION["be_on_chat"] = "YES";
                }
            }

            if (isset($_POST["all_chat"]) || isset($_POST["submit_all"])) {

                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
                if ($_SESSION["topics_id"] == 0) {
                    $_SESSION["be_on_chat"] = "NO";
                } else {
                    $_SESSION["be_on_chat"] = "YES";
                }
            }

            if (isset($_POST["all_assesment2"]) || isset($_POST["sub_all_ass"])) {

                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
                if ($_SESSION["topics_id"] == 0) {
                    $_SESSION["be_on_chat"] = "NO";
                } else {
                    $_SESSION["be_on_chat"] = "YES";
                }
            }


            if (isset($_POST["sub_file"]) || isset($_POST["upfile"])) {

                $_SESSION["showchat"] = 0;
                $_SESSION["startchat"] = "NO";
                $_SESSION["be_on_chat"] = "YES";
            }

            if (isset($_POST["sub_video"]) || isset($_POST["sub_video_conf"])) {

                $_SESSION["showchat"] = 0;
                $_SESSION["startchat"] = "NO";
                $_SESSION["be_on_chat"] = "YES";
            }

            if (isset($_POST["sub_meet"]) || isset($_POST["sub_meet_conf"])) {

                $_SESSION["showchat"] = 0;
                $_SESSION["startchat"] = "NO";
                $_SESSION["be_on_chat"] = "YES";
            }

            if (isset($_POST["attendance"])) {
                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
                if ($_SESSION["topics_id"] == 0) {
                    $_SESSION["be_on_chat"] = "NO";
                } else {
                    $_SESSION["be_on_chat"] = "YES";
                }
            }

            if (isset($_POST["submit_ccode"])) {
                //$_SESSION["inipost"]="XX";
                $getccode = $_POST["getccode"];
                $_SESSION["getccode"] = $getccode;

                $sql = "select 1 from " . $getccode;
                $exists = $conn8->query($sql);

                if ($exists == FALSE) {
                    $TabCreate = strtolower($getccode);
                    $sql = "CREATE TABLE " . $TabCreate . " SELECT * FROM aaa_tempt";
                    $result = $conn8->query($sql);


                    $sql = "ALTER TABLE " . $TabCreate . " ADD id INT NOT NULL AUTO_INCREMENT PRIMARY KEY";
                    $result = $conn8->query($sql);
                }

                $sql = "SELECT C_codding, C_title, credit FROM gencoursesupload WHERE C_codding = '$getccode'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["course_title"] = $row["C_title"];
                    }
                }

                $sql = "SELECT * FROM aaa_id_increament WHERE id_code = '$getccode' AND session1 = '$curtsession'";
                $result = $conn8->query($sql);
                if ($result->num_rows == 0) {
                    $sql2 = "INSERT INTO aaa_id_increament (id_code, session1)VALUE('$getccode', '$curtsession')";
                    $result2 = $conn8->query($sql2);
                }

                $dbsession = str_replace("/", "_", $curtsession);
                $sql = "SELECT * FROM courses_register_" . $dbsession . " WHERE CCode = '$getccode'";
                $result = $conn->query($sql);
                $_SESSION["noregister"] = mysqli_num_rows($result);


                $sql = "SELECT * FROM aaa_online_stu WHERE ccode = '$getccode' AND status = 'online'";
                $result = $conn8->query($sql);
                $_SESSION["noonline"] = mysqli_num_rows($result);

                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
            }

            if (isset($_POST["submit_ccode"])) {
                //$lectduration = $_POST["lectduration"];
                //$topic_id=$_POST["sel_topic"];
                $getccode = $_SESSION["getccode"];
                $course_title = $_SESSION["course_title"];
                $noregister = $_SESSION["noregister"];
                date_default_timezone_set("Africa/Lagos");
                $getnow = date('Y-m-d H:i:s');
                $sql = "SELECT * FROM aaa_online_courses WHERE ccode = '$getccode'";
                $result = $conn8->query($sql);
                if ($result->num_rows > 0) {
                    //$sql2 = "UPDATE aaa_online_courses SET lectduration = '$lectduration', c_title = '$course_title', noregstu = '$noregister', staffid = '$staffid', staffname = '$usernames', staffdept = '$dept' WHERE ccode='$getccode'";
                    $sql2 = "UPDATE aaa_online_courses SET  c_title = '$course_title', noregstu = '$noregister', staffid = '$staffid', staffname = '$usernames', staffdept = '$dept', timestart = '$getnow' WHERE ccode='$getccode'";
                    //$sql2 = "UPDATE aaa_online_courses SET  c_title = '$course_title', noregstu = '$noregister', staffid = '$staffid', staffname = '$usernames', staffdept = '$dept' WHERE ccode='$getccode'";
                    $result2 = $conn8->query($sql2);
                } else {
                    //$sql2 = "INSERT INTO aaa_online_courses (ccode, c_title, noregstu, staffid, staffname, staffdept, lectduration)VALUE('$getccode', '$course_title', '$noregister', '$staffid', '$usernames', '$dept', '$lectduration')";
                    $sql2 = "INSERT INTO aaa_online_courses (ccode, c_title, noregstu, staffid, staffname, staffdept, timestart)VALUE('$getccode', '$course_title', '$noregister', '$staffid', '$usernames', '$dept', '$getnow')";
                    //$sql2 = "INSERT INTO aaa_online_courses (ccode, c_title, noregstu, staffid, staffname, staffdept)VALUE('$getccode', '$course_title', '$noregister', '$staffid', '$usernames', '$dept')";
                    $result2 = $conn8->query($sql2);
                }
                $_SESSION["startchat"] = "NO";
            }

            if (isset($_POST["submit_sel_topic"])) {
                $topic_id = $_POST["sel_topic"];
                $_SESSION["topics_id"] = $topic_id;
                $getccode = $_SESSION["getccode"];
                $_SESSION["newtopic"] == "NO";
                $_SESSION["startchat"] = "NO";
                $sql = "SELECT * FROM aaa_course_topic WHERE id = '$topic_id'";
                $result = $conn8->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["topics"] = $row["topics"];
                    }
                }

                $sql2 = "UPDATE aaa_online_courses SET topic_id = '$topic_id' WHERE ccode='$getccode'";
                $result2 = $conn8->query($sql2);

                $_SESSION["showchat"] = 1;
            }

            if (isset($_POST["submit_new_topic"])) {

                $_SESSION["showchat"] = 0;
            }

            if (isset($_POST["submit_back_to_chat"])) {

                $_SESSION["showchat"] = 1;
                $_SESSION["be_on_chat"] = "NO";
            }
            ?>
            <section role="main" class="content-body">
                <header class="page-header" style="background-color:<?php echo $_SESSION['sch_color'] ?>">
                    <h2><?php echo $_SESSION["course_title"] . " (" . $_SESSION["getccode"] . ")" ?></h2>

                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>

                                <a href="classroom_start.php" class='btn btn-primary btn-xs'><i class="fa fa-home"></i>
                                    Home</a>
                            </li>

                            <li>
                                <form class="form-horizontal bucket-form" method="Post">
                                    <?php if ($_SESSION["showchat"] == 1) { ?>
                                        <input type="submit" value="New Topic" name="submit_new_topic" class='btn btn-primary btn-xs' style="margin-right: 1em">
                                    <?php } ?>
                                    <?php if ($_SESSION["be_on_chat"] == "YES") { ?>
                                        <input type="submit" value="Back to Chat" name="submit_back_to_chat" class='btn btn-primary btn-xs' style="margin-right: 1em">
                                    <?php } ?>
                                    <input type="submit" value="View All Chat" name="all_chat" class='btn btn-primary btn-xs' style="margin-right: 1em">


                                </form>

                            </li>
                            <li>
                                <form class="form-horizontal bucket-form" method="Post" action="classroom_course.php">
                                    <input type="submit" value="Classroom" name="submit" class='btn btn-info btn-xs'>

                                </form>

                            </li>

                        </ol>

                        <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">


                            <div class="nano">
                                <div class="form-group" style="padding-left: 1em; padding-right: 1em">
                                    <!--<form action="" class="search nav-form">
											<div class="input-group input-search">
												<input type="text" class="form-control" name="q" id="q" placeholder="Search...">
												<span class="input-group-btn">
													<button class="btn btn-default" name="searchres" type="submit"><i class="fa fa-search"></i></button>
												</span>
											</div>
										</form>-->
                                    <div class="widget-header clearfix">
                                        <h6 class="title pull-left mt-xs" style="color: #ffffff">Reg. Students:
                                            <?php echo number_format($_SESSION["noregister"], 0) ?></h6>
                                        <div class="pull-right">
                                            <a href="#" class="btn btn-dark btn-sm btn-widget-act">Online:
                                                <?php echo $_SESSION["noonline"] ?></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="nano-content">

                                    <div class="inner-menu-toggle-inside">
                                        <a href="#" class="inner-menu-collapse">
                                            <i class="fa fa-chevron-up visible-xs-inline"></i><i class="fa fa-chevron-left hidden-xs-inline"></i> Hide Bar
                                        </a>
                                        <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                            Show Bar <i class="fa fa-chevron-down"></i>
                                        </a>
                                    </div>

                                    <div class="inner-menu-content">



                                        <hr class="separator" />
                                        <?php
                                        if ($_SESSION["startchat"] == "NO") {
                                            if (isset($_POST["submit_ccode"])) {
                                                $getccode = $_POST["getccode"];
                                                $_SESSION["getccode"] = $getccode;
                                            }

                                        ?>

                                            <div class="sidebar-widget widget-friends" id="online_status">

                                            </div>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">

                            <div class="inner-toolbar clearfix" style="color:#ffffff">
                                <ul>
                                    <li>
                                        <?php if ($_SESSION["startchat"] == "NO" && $_SESSION["getccode"] !== "") { ?>
                                            <form class="" method="post">
                                                <input type="submit" value="Attendance" name="attendance" class='btn btn-success btn-xs'>
                                            </form>
                                        <?php } ?>
                                    </li>
                                    <li>
                                        <?php if ($_SESSION["startchat"] == "YES") { ?>
                                            <a href="classroom_assignment.php" class='btn btn-primary btn-xs'><i class="fa fa-graduation-cap"></i> Assignment</a>
                                        <?php } ?>
                                    </li>
                                    <li>
                                        <?php if ($_SESSION["startchat"] == "NO" && $_SESSION["getccode"] !== "") { ?>
                                            <a href="classroom_quiz.php" class='btn btn-primary btn-xs'><i class="fa fa-laptop"></i> Quiz</a>
                                        <?php } ?>
                                    </li>
                                    <li>
                                        <?php if ($_SESSION["startchat"] == "NO" && $_SESSION["getccode"] !== "") { ?>
                                            <form class="" method="post">
                                                <input type="submit" value="End Class" name="end_class" class='btn btn-success btn-xs'>
                                            </form>
                                        <?php } ?>
                                    </li>
                                    <li>
                                        <?php echo $_SESSION["topics"] ?>
                                    </li>
                                    <li class="right">

                                        <ul class="nav nav-pills nav-pills-primary">
                                            <?php if (isset($_POST["submit_ccode"]) || isset($_POST["submit_new_topic"])) { ?>
                                                <?php $getccode = $_SESSION["getccode"] ?>
                                                <li>
                                                    <label>Select Topic:</label>
                                                </li>

                                                <li>
                                                    <form class="" method="post">
                                                        <table>
                                                            <tbody>
                                                                <tr>
                                                                    <td style="padding-right: 1em">
                                                                        <select name="sel_topic" class="form-control input-sm mb-md" style="color:#000000; font-size: xx-small">
                                                                            <?php
                                                                            $sql = "SELECT * FROM aaa_course_topic WHERE ccode='$getccode' ORDER BY id";
                                                                            $result = $conn8->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    $topic_id = $row["id"];
                                                                                    $topics = $row["topics"];
                                                                                    echo "<option value = '$topic_id'>$topics</option>";
                                                                            ?>

                                                                            <?php
                                                                                }
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </td>

                                                                    <td style="padding-right: 1em">
                                                                        <input type="submit" value="Submit" name="submit_sel_topic" class='btn btn-success'>

                                                                    </td>

                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </form>
                                                </li>



                                            <?php } ?>
                                            <!--
												<?php //if(isset($_POST["submit_ccode"])){ 
                                                ?>
												
												<li>
													<form class="" method="post">
														<table>
															<tbody>
																<tr><td style="padding-right: 1em">
																	<label>Lecture Duration(Mins):</label>
																</td>
																
																<td style="padding-right: 1em">
																	<div class="input-group mb-md">
																		<input type="number" class="form-control" name="lectduration" required="required">
																		<span class="input-group-btn">
																			<input type="submit" value="Submit" name="submit_duration" class='btn btn-success'>
																		</span>
																	</div>
																</td>
																
																</tr>
															</tbody>
														</table>
														
			                                        </form>
												</li>
												<?php //} 
                                                ?>
												-->
                                            <?php if ($_SESSION["startchat"] == "NO") { ?>
                                                <li>
                                                    <form class="" method="post">
                                                        <input type="submit" value="Add Topic" name="submit_topic" class='btn btn-info'>
                                                    </form>
                                                </li>
                                            <?php } ?>

                                        </ul>
                                    </li>
                                </ul>
                            </div>


                            <?php if (isset($_POST["submit_topic"]) || isset($_POST["viewtopic"]) || isset($_POST["savetopic"]) || isset($_POST["updatetopic"]) || isset($_POST["deletetopic"])) { ?>
                                <div class="col-lg-12" style="padding-bottom: 5em">
                                    <?php $getccode = $_SESSION["getccode"]; ?>
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>

                                            <h2 class="panel-title">Create New Topic for <?php echo $getccode ?></h2>
                                        </header>
                                        <?php

                                        if (isset($_POST["savetopic"])) {

                                            $newtopic = str_replace("'", "''", $_POST['newtopic']);
                                            $newtopic = filter_var($newtopic, FILTER_SANITIZE_STRING);
                                            $sql = "INSERT INTO aaa_course_topic (topics, ccode)VALUE('$newtopic', '$getccode')";
                                            $result = $conn8->query($sql);
                                        }

                                        if (isset($_POST["updatetopic"])) {
                                            $getidview = $_POST["idview"];
                                            $newtopic = str_replace("'", "''", $_POST['newtopic']);
                                            $newtopic = filter_var($newtopic, FILTER_SANITIZE_STRING);
                                            $sql = "UPDATE aaa_course_topic SET topics='$newtopic' WHERE id='$getidview'";
                                            $result = $conn8->query($sql);
                                        }

                                        if (isset($_POST["deletetopic"])) {
                                            $getidview = $_POST["id"];
                                            $sql = "DELETE FROM aaa_course_topic WHERE id='$getidview'";
                                            $result = $conn8->query($sql);
                                        }
                                        ?>
                                        <div class="panel-body">
                                            <div class="col-lg-2">

                                            </div>
                                            <div class="col-lg-8">
                                                <?php

                                                $sql = "SELECT * FROM aaa_course_topic WHERE ccode = '$getccode' ORDER BY id";
                                                $result = $conn8->query($sql);

                                                if ($result->num_rows > 0) {
                                                ?>
                                                    <table class="table mb-none">
                                                        <thead>
                                                            <tr>
                                                                <th>SNo</th>
                                                                <th>Topics</th>
                                                                <th>Course Code</th>
                                                                <th>Action</th>
                                                                <th>Action</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>


                                                            <?php
                                                            $sno = 0;
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $id = $row["id"];
                                                                $topic = $row["topics"];
                                                                echo "<tr><td>$sno</td><th>$topic</th><th>$getccode</th>
												    	
												    	
												    	 <form action='' method='post'>
			                                                  <input type='hidden' value=$id name='id'>
			                                                  <td><input type='submit' name = 'viewtopic' class='btn btn-primary btn-xs' value='View'></td>
			                                                  
			                                                  <td><input type='submit' name = 'deletetopic' class='btn btn-danger btn-xs' value='Delete'></td>
			                                             </form>
												    	</tr>";
                                                            }

                                                            ?>
                                                        </tbody>
                                                    </table>
                                                <?php } ?>
                                                <hr class="separator" />
                                                <br>
                                                <?php
                                                $newtopic = "";
                                                if (isset($_POST["viewtopic"])) {
                                                    $idview = $_POST["id"];
                                                    $sql = "SELECT * FROM aaa_course_topic WHERE id = '$idview'";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $newtopic = $row["topics"];
                                                        }
                                                    }
                                                }
                                                ?>
                                                <form action='' method='post'>
                                                    <div class="form-group">
                                                        <label class="col-lg-3 control-label">Topic</label>
                                                        <div class="col-lg-6">
                                                            <input type="text" class="form-control" style="color:#000000" maxlength="200" name="newtopic" value="<?php echo $newtopic ?>">
                                                        </div>
                                                        <?php if (isset($_POST["viewtopic"])) { ?>
                                                            <?php $idview = $_POST["id"]; ?>
                                                            <input type="hidden" class="form-control" name="idview" value="<?php echo $idview ?>">
                                                            <div class="col-lg-3">
                                                                <input type="submit" value="Update" name="updatetopic" class='btn btn-info btn-xs'>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="col-lg-3">
                                                                <input type="submit" value="Save" name="savetopic" class='btn btn-primary btn-xs'>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                </form>

                                            </div>
                                            <div class="col-lg-2">

                                            </div>

                                        </div>
                                    </section>
                                </div>

                            <?php } ?>


                            <?php if (isset($_POST["sub_file"]) || isset($_POST["upfile"])) { ?>
                                <div class="col-lg-12" style="padding-bottom: 5em">
                                    <?php
                                    $getccode = $_SESSION["getccode"];
                                    $staffid = $_SESSION['staffid'];
                                    $curtsession = $_SESSION['corntsession'];
                                    $usernames = $_SESSION['names'];
                                    $topics_id = $_SESSION["topics_id"];
                                    $topics = $_SESSION["topics"];
                                    ?>
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>

                                            <h2 class="panel-title">Upload File for <?php echo $getccode ?></h2>
                                        </header>

                                        <div class="panel-body">
                                            <?php
                                            $dept = $_SESSION['deptcode'];

                                            $msgsuces = $message = "";
                                            $sessionreplace = str_replace("/", "_", $curtsession);

                                            if (isset($_POST['upfile']) && !empty($_POST['upfile'])) {
                                                $fileTmpPath = $_FILES['file']['tmp_name'];
                                                $fileName = $_FILES['file']['name'];
                                                $fileSize = $_FILES['file']['size'];
                                                $fileType = $_FILES['file']['type'];
                                                $fileNameCmps = explode(".", $fileName);
                                                $fileExtension = strtolower(end($fileNameCmps));


                                                $fileName = str_replace("'", "''", $fileName);
                                                $fileName = filter_var($fileName, FILTER_SANITIZE_STRING);
                                                $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                                                $newFileName = $fileName;

                                                if ($cat == "Administrator") {
                                                    $maxfilesize = 51200;
                                                    $allowedfileExtensions = array('jpg', 'gif', 'png', 'zip', 'txt', 'xls', 'xlsx', 'doc', 'docx', 'pdf', 'mp3', 'mp4');
                                                } else {
                                                    $maxfilesize = 2048;
                                                    $allowedfileExtensions = array('jpg', 'gif', 'png', 'zip', 'txt', 'xls', 'xlsx', 'doc', 'docx', 'pdf', 'mp3');
                                                }

                                                if (in_array($fileExtension, $allowedfileExtensions)) {
                                                    // directory in which the uploaded file will be moved
                                                    if ($_FILES['file']['size'] / 1024 <= $maxfilesize) { // 2MB or 50MB
                                                        //$savepath="Content/".$savesession."/".$_POST["courses"]."/";
                                                        $uploadFileDir = "classroom/" . $sessionreplace . "/" . $getccode . "/";

                                                        if (!file_exists($uploadFileDir)) {
                                                            mkdir($uploadFileDir, 0777, true);
                                                        }

                                                        $sql = "SELECT * FROM aaa_id_increament WHERE id_code = '$getccode' AND session1 = '$curtsession'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $id_number = $row["id_number"];
                                                            }
                                                        }
                                                        $id_number++;

                                                        $dest_path = $uploadFileDir . $id_number . "." . $fileExtension;

                                                        if (move_uploaded_file($fileTmpPath, $dest_path)) {
                                                            $getccode2 = strtolower($getccode);
                                                            $sql = "INSERT INTO " . $getccode2 . " (user_id, fullname, session1, topic_id, image_url, imgname, filetype, topics) VALUES ('$staffid', '$usernames', '$curtsession', '$topics_id', '$dest_path', '$newFileName', '$fileExtension', '$topics')";
                                                            $result = $conn8->query($sql);

                                                            $sql = "UPDATE aaa_id_increament set id_number = '$id_number' WHERE id_code = '$getccode' AND session1 = '$curtsession'";
                                                            $result = $conn8->query($sql);

                                                            $msgsuces = 'File is successfully uploaded.';
                                                        } else {
                                                            $message = 'Error in moving the file. Make sure you select correct file type.';
                                                        }
                                                    } else {
                                                        $message = 'File should be maximun 2MB in size!';
                                                    }
                                                } else {
                                                    $message = 'Error: Select the right file format';
                                                }
                                            }
                                            ?>
                                            <div class="col-lg-12">
                                                <h2 style="color:#0000ff"><?php echo $msgsuces ?></h2>
                                                <h2 style="color: #ff0000"><?php echo $message ?></h2>
                                                <?php
                                                if ($cat == "Administrator") {
                                                    echo "<h4>You can upload files in the following extensions ( jpg, gif, png, zip, txt, xls, xlsx, doc, docx, pdf, mp3, mp4)</h4><br>";
                                                    echo "<h4>Maximum of 50MB for videos and 2MB for others</h4><br>";
                                                } else {
                                                    echo "<h4>You can upload files in the following extensions ( jpg, gif, png, zip, txt, xls, xlsx, doc, docx, pdf, mp3)</h4><br>";
                                                    echo "<h4>Maximum of 2MB</h4><br>";
                                                }
                                                ?>

                                                <form enctype="multipart/form-data" action="" method="post">
                                                    <div class="form-group">
                                                        <label class="col-md-2 control-label">File Upload</label>
                                                        <div class="col-md-6">
                                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                                <div class="input-append">
                                                                    <div class="uneditable-input">
                                                                        <i class="fa fa-file fileupload-exists"></i>
                                                                        <span class="fileupload-preview"></span>
                                                                    </div>
                                                                    <span class="btn btn-default btn-file">
                                                                        <span class="fileupload-exists">Change</span>
                                                                        <span class="fileupload-new">Select file</span>
                                                                        <input type="file" name="file" />
                                                                    </span>
                                                                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2">
                                                            <input type="submit" name="upfile" value="Upload File" class="btn btn-primary btn-sm">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </section>
                                </div>
                            <?php } ?>

                            <!-- Add Video Link -->
                            <?php if (isset($_POST["sub_video"]) || isset($_POST["sub_video_conf"])) { ?>
                                <div class="col-lg-12" style="padding-bottom: 5em">
                                    <?php
                                    $getccode = $_SESSION["getccode"];
                                    $staffid = $_SESSION['staffid'];
                                    $curtsession = $_SESSION['corntsession'];
                                    $usernames = $_SESSION['names'];
                                    $topics_id = $_SESSION["topics_id"];
                                    $topics = $_SESSION["topics"];
                                    ?>
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>

                                            <h2 class="panel-title">Upload Video for <?php echo $getccode ?></h2>
                                        </header>

                                        <div class="panel-body">
                                            <?php

                                            $videomsg = "";
                                            if (isset($_POST['sub_video_conf'])) {
                                                $videotitle = str_replace("'", "''", $_POST['videotitle']);
                                                $videotitle = filter_var($videotitle, FILTER_SANITIZE_STRING);
                                                $videotitle = $videotitle . ".mp4";

                                                $videourl = str_replace("'", "''", $_POST['videourl']);
                                                $videourl = filter_var($videourl, FILTER_SANITIZE_STRING);
                                                $getccode2 = strtolower($getccode);
                                                $sql = "INSERT INTO " . $getccode2 . " (user_id, fullname, session1, topic_id, image_url, imgname, filetype, topics) VALUES ('$staffid', '$usernames', '$curtsession', '$topics_id', '$videourl', '$videotitle', 'mp4', '$topics')";
                                                $result = $conn8->query($sql);

                                                $videomsg = "Record Inserted";
                                            }
                                            ?>
                                            <div class="col-lg-12">
                                                <h3 style="color:#0000ff"><?php echo $videomsg ?></h3>
                                                <center>
                                                    <h4>Upload your vidoes into youtube and add the link here</h4>
                                                </center>
                                                <br><br>
                                                <form action="" method="post">
                                                    <div class="form-group">
                                                        <label class="col-md-3 control-label">Video Title</label>
                                                        <div class="col-md-6">
                                                            <input type="text" name="videotitle" class="form-control input-rounded" required="required">
                                                        </div>
                                                        <div class="col-lg-2">

                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-3 control-label">Video Youtube Link</label>
                                                        <div class="col-md-6">
                                                            <input type="text" name="videourl" class="form-control input-rounded" required="required">
                                                        </div>
                                                        <div class="col-lg-2">
                                                            <input type="submit" name="sub_video_conf" value="Submit" class="btn btn-primary btn-sm">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </section>
                                </div>

                                <?php
                                $sql = "SELECT * FROM aaa_online_courses WHERE ccode = '$getccode'";
                                $result = $conn8->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $codetime = $row["timestart"];
                                    }
                                }
                                date_default_timezone_set("Africa/Lagos");
                                $today = date('Y-m-d H:i:s');

                                //$minutes = abs(strtotime($codetime) - time()) / 60;

                                $time = new DateTime($codetime);
                                $diff = $time->diff(new DateTime());
                                $minutes = ($diff->days * 24 * 60) +
                                    ($diff->h * 60) + $diff->i;
                                //$gettoday = new DateTime($today);
                                //$codetime2 = new DateTime($codetime);
                                //$diffdob = $gettoday->diff($codetime2);

                                //$getdiffdob= $diffdob->y.' Years, ' .$diffdob->m.' Months, ' .$diffdob->d.' Days, ' .$diffdob->h.' Hours, ' .$diffdob->i.' Mins, ' .$diffdob->s.' Secs';
                                //$getdaysb=$diffdob->days;

                                echo "$minutes";
                                echo "<br>";
                                //echo "$codetime2";
                                ?>
                            <?php } ?>

                            <!-- Add Meet Link -->
                            <?php if (isset($_POST["sub_meet"]) || isset($_POST["sub_meet_conf"])) { ?>
                                <div class="col-lg-12" style="padding-bottom: 5em">
                                    <?php
                                    $getccode = $_SESSION["getccode"];
                                    $staffid = $_SESSION['staffid'];
                                    $curtsession = $_SESSION['corntsession'];
                                    $usernames = $_SESSION['names'];
                                    $topics_id = $_SESSION["topics_id"];
                                    $topics = $_SESSION["topics"];
                                    ?>
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>

                                            <h2 class="panel-title">Add Meet url for <?php echo $getccode ?></h2>
                                        </header>

                                        <div class="panel-body">
                                            <?php

                                            $videomsg = "";
                                            if (isset($_POST['sub_meet_conf'])) {
                                                $meeturl = str_replace("'", "''", $_POST['meeturl']);
                                                $meeturl = filter_var($meeturl, FILTER_SANITIZE_STRING);
                                                $getccode2 = strtolower($getccode);

                                                $sql = "SELECT * FROM meeturl WHERE ccode = '$getccode2'";
                                                $result = $conn8->query($sql);
                                                if ($result->num_rows > 0) {
                                                    $sql2 = "UPDATE meeturl SET url = '$meeturl' WHERE ccode='$getccode2'";
                                                    $result2 = $conn8->query($sql2);
                                                } else {
                                                    $sql2 = "INSERT INTO meeturl (ccode, url) VALUES ('$getccode2', '$meeturl')";
                                                    $result2 = $conn8->query($sql2);
                                                }

                                                $videomsg = "Record Inserted";
                                                echo "<br>Meet url: <a href='https://$meeturl' target='_blank'>Click to connect</a>";
                                            }
                                            ?>
                                            <div class="col-lg-12">
                                                <h3 style="color:#0000ff"><?php echo $videomsg ?></h3>
                                                <center>
                                                    <h4>Add Meet url here</h4>
                                                </center>
                                                <br><br>
                                                <form action="" method="post">

                                                    <div class="form-group">
                                                        <label class="col-md-3 control-label">Meet Link</label>
                                                        <div class="col-md-6">
                                                            <input type="text" name="meeturl" class="form-control input-rounded" required="required">
                                                        </div>
                                                        <div class="col-lg-2">
                                                            <input type="submit" name="sub_meet_conf" value="Submit" class="btn btn-primary btn-sm">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </section>
                                </div>
                            <?php } ?>

                            <!--Download Attendance-->
                            <?php if (isset($_POST["attendance"])) { ?>
                                <?php $getccode = $_SESSION["getccode"]; ?>
                                <div class="row">
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>

                                            <h2 class="panel-title">Download Attendance for <?php echo $getccode ?></h2>
                                        </header>
                                        <?php

                                        $GetTitle = "Attendance for " . $getccode . " on " . date('d F, Y');
                                        ?>
                                        <div class="panel-body">
                                            <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups" frame="hsides" border="2">
                                                <caption><?php echo $GetTitle ?></caption>
                                                <colgroup align="center"></colgroup>
                                                <colgroup align="left"></colgroup>
                                                <colgroup span="2"></colgroup>
                                                <colgroup span="3" align="center"></colgroup>
                                                <thead>
                                                    <tr>
                                                        <th>SNo</th>
                                                        <th>Matric No</th>
                                                        <th>Name</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sno = 0;
                                                    $sql = "SELECT * FROM aaa_online_stu WHERE ccode= '$getccode' AND status= 'online' ORDER BY regdid";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $attregdid = $row["regdid"];
                                                            $attname1 = $row["name1"];
                                                            echo "<tr><td>$sno</td><td>$attregdid</td><td>$attname1</td></tr>\n";
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <br>
                                            <div style="text-align: right">
                                                <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                            <?php } ?>
                            <!--End Attendance-->

                            <!--View All Chat-->
                            <?php if (isset($_POST["all_chat"]) || isset($_POST["submit_all"])) { ?>
                                <div class="row">
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="content">Select Course:</label>
                                                <div class="col-lg-8">
                                                    <select class="country form-control" style="color:#000000" name="all_course">
                                                        <?php
                                                        $sql = "SELECT * FROM coursealocation WHERE PFNo='$staffid' AND SessionReg='$curtsession' AND Semester='$cursemester' ORDER BY CCode";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $CCode = $row["CCode"];
                                                                $CTitle = $row["CTitle"];
                                                                echo "<option value=$CCode>$CCode $CTitle</option>";
                                                            }
                                                        }
                                                        ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="regid">Filter:</label>
                                                <div class="col-lg-5">
                                                    <select name="filterchat" class="form-control" style="color:#000000">
                                                        <option value="byme">Chat From Staff</option>
                                                        <option value="byothers">Chat From Sudents</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-3">
                                                    <button type="submit" name="submit_all" class="btn btn-primary btn-sm">Submit</button>

                                                </div>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                                <hr class="separator" />
                                <?php if (isset($_POST["submit_all"])) { ?>
                                    <?php
                                    $getallcourses = $_POST["all_course"];
                                    $getfilter = $_POST["filterchat"];

                                    //$getccode=$_SESSION["getccode"]; 
                                    //$staffid = $_SESSION['staffid'];
                                    $curtsession = $_SESSION['corntsession'];
                                    $usernames = $_SESSION['names'];
                                    $topics_id = $_SESSION["topics_id"];

                                    $sql = "SELECT C_codding, C_title FROM gencoursesupload WHERE C_codding = '$getallcourses'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $getctitle = $row["C_title"];
                                        }
                                    }

                                    $sql = "SELECT * FROM coursealocation WHERE CCode = '$getallcourses'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $getlecturer = $row["PFNo"];
                                        }
                                    }
                                    ?>
                                    <div class="col-lg-12">
                                        <section class="panel">
                                            <header class="panel-heading">

                                                <h2 class="panel-title"><?php echo $getctitle . " (" . $getallcourses . ")" ?>
                                                </h2>
                                            </header>
                                            <div class="panel-body">

                                                <table class="table table-bordered table-striped mb-none" id="datatable-default">
                                                    <thead style='text-align:center'>
                                                        <tr>
                                                            <th>S/No</th>
                                                            <th>Sender's Name</th>
                                                            <th>Topic</th>
                                                            <th>Message</th>
                                                            <th>Date</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $sno = 0;
                                                        $getallcourses2 = strtolower($getallcourses);
                                                        if ($getfilter == "byme") {
                                                            $sql = "SELECT * FROM " . $getallcourses2 . " WHERE session1='$curtsession' AND usertype='staff' ORDER BY topic_id, date1";
                                                        } else {
                                                            $sql = "SELECT * FROM " . $getallcourses2 . " WHERE session1='$curtsession' AND usertype = 'stu' ORDER BY topic_id, date1";
                                                        }

                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $user_id = $row["user_id"];
                                                                $message = $row["message"];
                                                                $date1 = $row["date1"];
                                                                $fullname = $row["fullname"];
                                                                $image_url = $row["image_url"];
                                                                $imgname = $row["imgname"];
                                                                $filetype = $row["filetype"];
                                                                $topics = $row["topics"];
                                                                echo "<tr><td>$sno</td><td>$fullname</td><td>$topics</td><td>";
                                                        ?>
                                                                <?php if ($filetype == "jpg" || $filetype == "gif" || $filetype == "png") { ?>
                                                                    <a class="thumb-image" href="<?php echo $image_url ?>" target="_blank">
                                                                        <img src="<?php echo $image_url ?>" width="100" height="100">
                                                                    </a>
                                                                <?php } elseif ($filetype == "mp3") { ?>

                                                                    <audio>
                                                                        <source src="<?php echo $image_url ?>" type="audio/mpeg">

                                                                    </audio>
                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/audio_icon.svg" width="40" height="40"><?php echo $imgname ?></a>

                                                                <?php } elseif ($filetype == "mp4") { ?>


                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/video_icon.jpg" width="40" height="40"><?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "doc" || $filetype == "docx") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/word_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "xls" || $filetype == "xlsx") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/excel_icon.png" width="40" height="40">
                                                                        <?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "pdf") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/pdf_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "zip") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/zip_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "txt") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/txt.png" width="40" height="40"><?php echo $imgname ?></a>

                                                                <?php } ?>
                                                                <?php echo $message ?>
                                                        <?php
                                                                echo "</td><td>$date1</td></tr>";
                                                            }
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                    </div>
                                <?php } ?>
                            <?php } ?>
                            <!--End View All Chat-->



                            <?php if (isset($_POST["end_class"])) { ?>
                                <div class="col-lg-12" style="padding-bottom: 5em">
                                    <section class="panel">
                                        <header class="panel-heading">

                                            <h2 class="panel-title">
                                                <?php echo $_SESSION["course_title"] . " (" . $_SESSION["getccode"] . ")" ?>
                                            </h2>
                                        </header>
                                        <div class="panel-body">
                                            <center>
                                                <h3>Confirm ending class</h3>
                                            </center>
                                            <form class="" method="post">
                                                <center><input type="submit" value="End Class" name="end_class_confirm" class='btn btn-success btn-sm'></center>
                                            </form>
                                        </div>
                                    </section>
                                </div>
                            <?php } ?>


                            <?php
                            if ($_SESSION["showchat"] == 1) { ?>

                                <div class="col-lg-12" style="padding-bottom: 10em">
                                    <section class="panel">
                                        <header class="panel-heading">

                                            <h2 class="panel-title"><?php echo $_SESSION["topics"] ?></h2>
                                        </header>
                                        <div class="panel-body" id="chat_body" style="background-color: #999999">

                                        </div>
                                    </section>
                                </div>

                                <div style="color:#ffffff; width:100%; position: fixed; background-color:#000000; bottom: 0; border-radius: 25px">

                                    <div class="form-group col-lg-7 col-md-7 col-sm-7" style="padding-top: 1em">

                                        <ul class="chats">
                                            <li class="by-me">
                                                <div class="avatar pull-left">
                                                    <img alt='' class='img-circle' src='https://staff.futminna.edu.ng/<?php echo strtoupper($dept) ?>/images/<?php echo $staffid ?>/MyPic1.jpg' width='50' height='50'>

                                                </div>

                                                <div class="chat-content">
                                                    <textarea name="mychat" id="mychat" class="form-control" rows="3" placeholder="Type your message"></textarea>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="form-group col-lg-5 col-md-5 col-sm-5" style="padding-top: 1em; padding-right: 2em">
                                        <button type="submit" name="sub_post" id="sub_post" class="btn btn-primary btn-xs">Post</button><br><br>
                                        <form action='' method='post'>
                                            <button type="submit" name="sub_file" class="btn btn-success btn-xs"><i class="fa fa-paperclip"></i>Attach File</button>
                                            <button type="submit" name="sub_video" class="btn btn-default btn-xs"><i class="fa fa-paperclip"></i>Attach Video</button><br>

                                            <?php
                                            $getccode2 = strtolower($_SESSION["getccode"]);
                                            $sql = "SELECT * FROM meeturl WHERE ccode = '$getccode2'";
                                            $result = $conn8->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $mymeeturl = $row["url"];
                                                }
                                                echo "<button type='submit' name='remove_meet' class='btn btn-primary btn-xs'><i class='fa fa-paperclip'></i>Remove Meet Link</button>";
                                                echo "<br><a href='https://$mymeeturl' target='_blank'>Click to connect to meet</a>";
                                            } else {
                                                echo "<button type='submit' name='sub_meet' class='btn btn-primary btn-xs'><i class='fa fa-paperclip'></i>Attach Meet Link</button>";
                                            }

                                            ?>
                                        </form>
                                    </div>
                                </div>
                            <?php } ?>

                        </div>

                    </div>

                </section>
                <!-- end: page -->
            </section>
        </div>

        <aside id="sidebar-right" class="sidebar-right">
            <div class="nano">
                <div class="nano-content">
                    <a href="#" class="mobile-close visible-xs">
                        Collapse <i class="fa fa-chevron-right"></i>
                    </a>

                    <div class="sidebar-right-wrapper">

                        <?php
                        $getday = date('D');
                        if ($getday == "Mon") {
                            $getday = "M";
                            $getperiod = "MHr";
                        } elseif ($getday == "Tue") {
                            $getday = "T";
                            $getperiod = "THr";
                        } elseif ($getday == "Wed") {
                            $getday = "W";
                            $getperiod = "WHr";
                        } elseif ($getday == "Thu") {
                            $getday = "Th";
                            $getperiod = "ThHr";
                        } elseif ($getday == "Fri") {
                            $getday = "F";
                            $getperiod = "FHr";
                        } elseif ($getday == "Sat") {
                            $getday = "S";
                            $getperiod = "SHr";
                        }

                        $closemsg = 0;
                        $ccodearry = "";
                        $timearry = "";

                        ?>
                        <div class="sidebar-widget widget-friends">
                            <h5 style="color:#ffffff">Today's Lecture(s)</h5>
                            <ul>

                                <?php

                                $sql2 = "SELECT * FROM coursealocation WHERE PFNo='$staffid' AND SessionReg='$curtsession' AND Semester='$cursemester' ORDER BY CCode";
                                $result2 = $conn->query($sql2);
                                if ($result2->num_rows > 0) {
                                    while ($row2 = $result2->fetch_assoc()) {
                                        $CCode = $row2['CCode'];
                                        $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                if ($getday == "M" || $getday == "T" || $getday == "W" || $getday == "Th" || $getday == "F" || $getday == "S") {
                                                    $C_title = $row["C_title"];
                                                    $thetimearry = $row[$getday];
                                                    $theperiod = $row[$getperiod];
                                                    if (strlen($thetimearry) > 1) {

                                ?>
                                                        <li class="status-online">

                                                            <div class="profile-info">
                                                                <span class="name"><?php echo $CCode ?></span>
                                                                <span class="title"><?php echo $C_title ?></span>
                                                                <span class="title"><?php echo $thetimearry . "  " . $theperiod . "hr(s)" ?></span>
                                                            </div>
                                                        </li>
                                <?php
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                ?>
                            </ul>
                        </div>

                        <?php if ($_SESSION["showchat"] == 1) { ?>
                            <div class="sidebar-widget widget-friends" id="aside_chat">

                            </div>
                        <?php } ?>


                    </div>
                </div>
            </div>
        </aside>
    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>

    <!--Textarea Editor-->
    <script src="editor/js_/app.js" type="text/javascript"></script>
    <script src="editor/js_/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="editor/js_/ckeditor.js" type="text/javascript"></script>
    <script src="editor/js_/jquery.js" type="text/javascript"></script>
    <script src="editor/js_/editor1.js" type="text/javascript"></script>
    <!--Insert Chat-->
    <script>
        $(document).ready(function() {
            $("#sub_post").click(function() {
                var mychat = $("#mychat").val();

                $.ajax({
                    url: 'ajax_save_rec/chat_insert.php',
                    method: 'POST',
                    data: {
                        mychat: mychat

                    },
                    success: function(data) {
                        alert(data);
                    }

                });
                document.getElementById("mychat").value = "";
            });
        });
    </script>

    <!--Fetch Chat-->
    <!--<script src="http://code.jquery.com/jquery-latest.js"></script>-->
    <script>
        (function($) {
            $(document).ready(function() {
                $.ajaxSetup({
                    cache: false,
                    beforeSend: function() {
                        $('#chat_body').hide();
                        $('#loading').show();
                    },
                    complete: function() {
                        $('#loading').hide();
                        $('#chat_body').show();
                    },
                    success: function() {
                        $('#loading').hide();
                        $('#chat_body').show();
                    }
                });
                var $container = $("#chat_body");
                $container.load("ajax_save_rec/chat_area.php");
                var refreshId = setInterval(function() {
                    $container.load('ajax_save_rec/chat_area.php');
                }, 9000);
            });
        })(jQuery);
    </script>

    <script>
        (function($) {
            $(document).ready(function() {
                $.ajaxSetup({
                    cache: false,
                    beforeSend: function() {
                        $('#aside_chat').hide();
                        $('#loading').show();
                    },
                    complete: function() {
                        $('#loading').hide();
                        $('#aside_chat').show();
                    },
                    success: function() {
                        $('#loading').hide();
                        $('#aside_chat').show();
                    }
                });
                var $container = $("#aside_chat");
                $container.load("ajax_save_rec/aside_chat.php");
                var refreshId = setInterval(function() {
                    $container.load('ajax_save_rec/aside_chat.php');
                }, 9000);
            });
        })(jQuery);
    </script>

    <script>
        (function($) {
            $(document).ready(function() {
                $.ajaxSetup({
                    cache: false,
                    beforeSend: function() {
                        $('#online_status').hide();
                        $('#loading').show();
                    },
                    complete: function() {
                        $('#loading').hide();
                        $('#online_status').show();
                    },
                    success: function() {
                        $('#loading').hide();
                        $('#online_status').show();
                    }
                });
                var $container = $("#online_status");
                $container.load("ajax_save_rec/load_online.php");
                var refreshId = setInterval(function() {
                    $container.load('ajax_save_rec/load_online.php');
                }, 9000);
            });
        })(jQuery);
    </script>
</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

include_once 'includes/get_stu_level.php';

?>



<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Print Div-->
    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Course Registration</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_stu.php">Home</a>
                        </li>
                        <li>
                            Course Registration
                        </li>

                        <li class="active">
                            <strong>Course Reg Preview</strong>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper wrapper-content animated fadeInUp">
                        <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

?>
                        <div class="ibox">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10 panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                                <div class="panel-heading">
                                    Course Reg Preview

                                </div>
                                <div class="panel-body">
                                    <form class="form-horizontal" role="form" method="post" action="">
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label"><strong>Session:</strong></label>
                                            <div class="col-lg-6">
                                                <?php
                                                $iniyear = 2015;
                                                //$D = exec('date /T');
                                                //$T = exec('time /T');
                                                //$DT = strtotime(str_replace("/", "-", $D . " " . $T));
                                                //$finalyear = date("Y",$DT);
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="sesion" class="form-control" style="color:#000000"
                                                    id="sesion">
                                                    <option value="<?php echo $curtsession ?>">
                                                        <?php echo $curtsession ?>
                                                    </option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>

                                            </div>
                                            <button type="submit" name="registered"
                                                class="btn btn-primary btn-sm">Submit</button>
                                        </div>

                                    </form>
                                    <br><br>
                                    <div id="printableArea">
                                        <?php
                                        if (isset($_POST["registered"])) {
                                            $curtsession = $_POST['sesion'];
                                            $corntsession = $_SESSION['corntsession'];
                                            $tot1stoutunit = $tot2ndoutunit = 0;
                                            $leveladv = $HOD = $Dean = $Registrar = "Yet";

                                            $regid = $_SESSION["regid"];
                                            $dept = $_SESSION['deptcode'];

                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }

                                            $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession'  AND matricno = '$regid'";
                                            $result = $conn_stu->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $leveladv = $row["LevelAdvice"];
                                                    $HOD = $row["HOD"];
                                                    $Dean = $row["Dean"];
                                                    $Registrar = $row["Registrar"];
                                                    $LAName = $row["LAName"];
                                                    $HODName = $row["HODName"];
                                                }
                                            }
$conn_stu->close();

                                        ?>
                                        <table style="width: 100%">
                                            <tr>
                                                <td><?php echo "Matric No: " . $regid; ?><br><?php echo "Name:  " . $_SESSION['names']; ?>
                                                </td>
                                                <td style="text-align:right">
                                                    <?php
                                                        $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                        $passptfile = str_replace("/", "", $_SESSION['passportid']) . "_passport.jpg";
                                                        echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='100' height='100'>";
                                                        ?>
                                                </td>
                                            </tr>
                                        </table>
                                        <?php if ($leveladv == "Validate") { ?>
                                        <h3 style="text-align: center;"><strong> Approved Courses</strong> </h3>
                                        <?php } ?>
                                        <h3 style='text-align:center'><strong><?php echo $_SESSION['deptname'] ?>
                                                Department<br>Course Registration Form</strong></h3>

                                        <?php
                                            $curtsession2 = str_replace("/", "_", $curtsession);
                                            $sql = "SELECT * FROM courses_register_" . $curtsession2 . " WHERE Regn1 = '$regid' AND SemTaken = '1ST'";
                                            $result = $conn->query($sql);

                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                            ?>
                                        <center>
                                            <h3>Session: <?php echo $curtsession ?><br>1ST Semester Courses</h3>
                                        </center>

                                        <table class="table table-bordered" cellspacing="0" rules="all" border="1"
                                            style="width: 100%">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["sn"];
                                                            $ccode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $Nature = $row["Nature"];

                                                            $tot1stoutunit += $row['CUnit'];


                                                            //echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['Nature']}</td></tr>\n";
                                                            echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>$Nature</td></tr>\n";
                                                        }
                                                        ?>
                                            </tbody>
                                        </table>

                                        <?php

                                            } else {
                                                echo "0 results";
                                            }
                                            //$conn->close();
                                            echo "<center> Total Credit Units : $tot1stoutunit</center>";
                                            ?>

                                        <br /><br />
                                        <?php



                                            $sql = "SELECT * FROM courses_register_" . $curtsession2 . " WHERE Regn1 = '$regid' AND SemTaken = '2ND'";
                                            $result = $conn->query($sql);

                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                            ?>
                                        <center> <strong>2ND Semester Courses</strong></center>
                                        <table class="table table-bordered" cellspacing="0" rules="all" border="1"
                                            style="width: 100%">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                        while ($row = $result->fetch_assoc()) {

                                                            $id = $row["sn"];
                                                            $ccode = $row["CCode"];
                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $Nature = $row["Nature"];

                                                            $tot2ndoutunit += $row['CUnit'];


                                                            //echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['Nature']}</td></tr>\n";
                                                            echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>$Nature</td></tr>\n";
                                                        }
                                                        ?>
                                            </tbody>
                                        </table>

                                        <?php

                                            }
                                            //$conn->close();
                                            echo "<center> Total Credit Units : $tot2ndoutunit</center>";


                                            ?>
                                        <br>

                                        <div>
                                            <table width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td style="width: 50%">
                                                            <?php if ($leveladv == "Validate") { ?>
                                                            <strong><input type="checkbox" name="LevelAdvice"
                                                                    disabled="disabled" checked> Level Adviser</strong>
                                                            <br>Validated By <?php echo $LAName ?><br>
                                                            <?php } else { ?>
                                                            <input type="checkbox" name="LevelAdvice"
                                                                disabled="disabled">
                                                            Level Adviser<br>
                                                            <?php } ?>
                                                        </td>
                                                        <td style="width: 50%">
                                                            <?php if ($HOD == "Validate") { ?>
                                                            <strong><input type="checkbox" name="HOD"
                                                                    disabled="disabled" checked> HOD</strong>
                                                            <br>Validated By <?php echo $HODName ?><br>
                                                            <?php } else { ?>
                                                            <input type="checkbox" name="HOD" disabled="disabled">
                                                            HOD<br>
                                                            <?php } ?>
                                                        </td>

                                                        <!--  <td style="width: 25%">
                                                            <?php if ($Dean == "Validate") { ?>
                                                            <strong><input type="checkbox" name="Dean"
                                                                    disabled="disabled" checked> Dean</strong>
                                                            <br>Validated
                                                            <?php } else { ?>
                                                            <input type="checkbox" name="Dean" disabled="disabled">
                                                            Dean<br>
                                                            <?php } ?>
                                                        </td>
                                                        <td>
                                                            <?php if ($Registrar == "Validate") { ?>
                                                            <strong><input type="checkbox" name="Registrar"
                                                                    disabled="disabled" checked> Registrar</strong>
                                                            <br>Validated
                                                            <?php } else { ?>
                                                            <input type="checkbox" name="Registrar" disabled="disabled">
                                                            Registrar<br>
                                                            <?php } ?>
                                                        </td> -->
                                                    </tr>
                                                </tbody>
                                            </table>

                                        </div>



                                    </div>
                                    <br><br>
                                    <div style="text-align: right">
                                        <?php if ($leveladv == "Validate") { ?>
                                        <input type="button" onclick="printDiv('printableArea')" value="print"
                                            class="btn-success" />
                                        <?php } ?>
                                    </div>
                                    <?php } ?>
                                    <br /><br />
                                </div>
                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                        <?php
$conn->close();
                        ?>
                    </div>
                </div>

            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
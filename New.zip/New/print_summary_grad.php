<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?>, Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword"
        content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light"
        rel="stylesheet" type="text/css">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>


    <style>
    .btn-xs,
    .btn-group-xs>.btn {
        padding: 1px 5px;
        font-size: 12px;
        line-height: 1.5;
        border-radius: 3px;
    }
    </style>


    <style type="text/css">
    table {
        page-break-inside: avoid;
        border: 2em;
    }

    /*h3 {
            page-break-before: always;
        }*/
    @page {
        size: A4 portrait;
        font-size: small;
    }

    @page :left {
        margin-left: 1cm;
    }

    @page :right {
        margin-left: 2cm;
    }
    </style>
    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: auto; height=auto; font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <?php

    $deptname = "";

    $getdept = $_SESSION['dept_sctny'];
    $getyeargrad = $_SESSION['getyeargrad'];
    $getsemester = $_SESSION['semesterSel'];
    if ($_SESSION['InstType'] == "Polytechnic") {
        $getprogram = $_SESSION['getprogram'];
        if ($getprogram == "ND") {
            $prog = "National Diploma";
        } elseif ($getprogram == "HND") {
            $prog = "Higher National Diploma";
        }
    }
    $deptname = $_SESSION["deptname"];
    ?>
    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
        <form class="form-horizontal form-bordered" method="post">
            <div class="row">

                <div class="row">
                    <div class="col-lg-5">
                        Department: <?php echo $deptname; ?>
                    </div>
                    <div class="col-lg-4">
                        Year of Graduation: <?php echo $_SESSION['getyeargrad']; ?>
                    </div>
                    <div class="col-lg-3">
                        Semester: <?php echo $_SESSION['semesterSel']; ?>
                    </div>

                </div>
                <hr class="separator" />
                <br>
                <div class="col-lg-12">
                    <div id="printableArea" style="width: auto; float: none">
                        <h4 style="text-align: center">
                            <?php echo $_SESSION['instname'] ?><br>
                            <?php echo $_SESSION['sch_faculty'] ?> OF <?php echo strtoupper($_SESSION['schname']) ?><br>

                            DEPARTMENT OF <?php echo strtoupper($deptname) ?><br>
                            <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                            <?php echo strtoupper($prog) ?><br>
                            <?php } ?>
                            SUMMARY OF EXAMINATION RESULTS<br>
                        </h4>
                        <table class="table table-bordered" cellspacing="0" rules="all" border="1">
                            <thead style='text-align:center'>
                                <tr>
                                    <th>S/No</th>
                                    <th>Matric No</th>
                                    <th>Name</th>
                                    <th>CGPA</th>
                                    <th>Class of Degree</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $ccgpa = 0;
                                $classdegree = "";
                                //$sno=0;
                                $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = 0;

                                $gradstuReg = $_SESSION["gradstuReg"];
                                $gradStuName = $_SESSION["gradStuName"];
                                $snoArray = $_SESSION["snoArray"];
                                $sno = $_SESSION["sno"];
                                $gradStuCGPA = $_SESSION["gradStuCGPA"];
                                $gradStuDOpt = $_SESSION["gradStuDOpt"];
                                //$arryclassdegree = $_SESSION["arryclassdegree"];

                                for ($i = 1; $i <= $sno; $i++) {
                                    $no = $snoArray[$i];
                                    $matno = $gradstuReg[$i];
                                    $names = $gradStuName[$i];
                                    $ccgpa = $gradStuCGPA[$i];
                                    $Deptopt2 = $gradStuDOpt[$i];
                                    $cgpa = $ccgpa;
                                    include 'modulesInSess/classofdegree_inc.php';

                                    echo "<tr><td>$no</td><td>$matno</td><td>$names</td><td>$ccgpa</td><td>$classdegree</td></tr>";
                                }


                                ?>
                            </tbody>
                        </table>
                        <br>
                        <h4 style="text-align: center">SUMMARY</h4>
                        <table class="table table-bordered" cellspacing="0" rules="all" border="1">
                            <thead style='text-align:center'>
                                <tr>
                                    <th>S/No</th>
                                    <th>Class of Degree</th>
                                    <th>Number</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                echo "<tr><td>1</td><td>First Class</td><td>$Countfirst</td></tr>";
                                echo "<tr><td>2</td><td>Second Class Upper</td><td>$Count2Upper</td></tr>";
                                echo "<tr><td>3</td><td>Second Class Lower</td><td>$Count2Lower</td></tr>";
                                echo "<tr><td>4</td><td>Third Class</td><td>$Count3Class</td></tr>";
                                echo "<tr><td>5</td><td>Pass</td><td>$CountPass</td></tr>";
                                echo "<tr><td></td><th>Total</th><td>$sno</td></tr>";
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-lg-12" style="text-align: right">
                        <input type="button" onclick="printDiv('printableArea')" value="print to PDF" />
                    </div>
                    <br><br>
                </div>

            </div>
        </form>
    </div>


</body>

</html>
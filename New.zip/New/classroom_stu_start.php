<?php
session_start();

$_SESSION["mystatus"] = "student";
$_SESSION["getccode"] = "";
$_SESSION["inipost"] = "";
$_SESSION["newtopic"] = "NO";
$_SESSION["course_title"] = "Classroom";
$_SESSION["topics"] = "Classroom";
$_SESSION["topics_id"] = 0;
$_SESSION["showchat"] = 0;
$_SESSION["startchat"] = "YES";
$_SESSION["noonline"] = 0;
$_SESSION["noregister"] = 0;
$_SESSION["be_on_chat"] = "NO";
$_SESSION["staffid"] = "";

$_SESSION["staffname"] = "";
$_SESSION["staffdept"] = "";
$_SESSION["lectduration"] = 0;
//$_SESSION["timestart"] = 0;

//header('Location: classroom_stu.php');

require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$usernames = $_SESSION['names'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
//$stdid = $_SESSION['stdid'];
//$mystdid = $_SESSION['stdid'];
$dept = strtoupper($_SESSION['deptcode']);
$regid = $_SESSION["regid"];
$myregid = $_SESSION["regid"];
$email = $_SESSION['email'];
$staff_pic_folder = $_SESSION['staff_pic_folder'];

?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">


    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php
                            if ($_SESSION['progtype'] == "UG") {

                                $sql = "SELECT image FROM std_pictures WHERE matric_no='$regid'";
                                $sth = $conn2->query($sql);
                                $result2 = mysqli_fetch_array($sth);

                                echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['image']) . '"  width="50" height="50"/>';
                                //echo "<img src='https://eportal.futminna.edu.ng/rpport/passport_".$_SESSION['stdid'].".jpg' alt='$usernames' class='img-circle' width='50' height='50' data-lock-picture='https://eportal.futminna.edu.ng/rpport/passport_".$_SESSION['stdid'].".jpg' />";
                            } else {
                                //echo "<img src='https://eportal.futminna.edu.ng/pg/uploads/" . $_SESSION['stdid'] . "_passport.jpg' alt='$usernames' class='img-circle' width='50' height='50' data-lock-picture='https://eportal.futminna.edu.ng/rpport/passport_" . $_SESSION['stdid'] . ".jpg' />";
                            }

                            ?>
                        </figure>
                        <div class="profile-info" data-lock-name="<?php echo $regid ?>" data-lock-email="<?php echo $email ?>">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $regid  ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_stu.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>
                            <!--<li>
									<a role="menuitem" tabindex="-1" href="lock_screen_stu.php" data-lock-screen="true"><i class="fa fa-lock"></i> Lock Screen</a>
								</li>-->



                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_class.php'; ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>">
                    <h2>Welcome to <?php echo $_SESSION['instname'] ?></h2>

                    <div class="right-wrapper pull-right">

                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">

                            <div class="nano">
                                <div class="form-group" style="padding-left: 1em; padding-right: 1em">

                                    <div class="widget-header clearfix">


                                    </div>
                                </div>
                                <div class="nano-content">

                                    <div class="inner-menu-toggle-inside">
                                        <a href="#" class="inner-menu-collapse">
                                            <i class="fa fa-chevron-up visible-xs-inline"></i><i class="fa fa-chevron-left hidden-xs-inline"></i> Hide Bar
                                        </a>
                                        <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                            Show Bar <i class="fa fa-chevron-down"></i>
                                        </a>
                                    </div>

                                    <div class="inner-menu-content">
                                        <h4 style="text-align: center;">Calendar</h4>
                                        <div data-plugin-datepicker data-plugin-skin="dark"></div>

                                    </div>
                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">

                            <div class="inner-toolbar clearfix" style="color:#ffffff">

                            </div>



                            <div class="row mg-files" data-sort-destination data-sort-id="media-gallery">
                                <?php

                                $curtsession2 = str_replace("/", "_", $curtsession);
                                $sql = "SELECT * FROM courses_register_" . $curtsession2 . " WHERE Regn1='$regid' AND SemTaken='$cursemester' ORDER BY CCode";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $CCode = $row["CCode"];
                                        $CTitle = $row["CTitle"];
                                        $nostaf = 0;
                                        $sql2 = "SELECT * FROM coursealocation WHERE SessionReg='$curtsession' AND CCode='$CCode'";
                                        $result2 = $conn->query($sql2);

                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $nostaf++;
                                                $PFNo = $row2["PFNo"];
                                                $sql3 = "SELECT * FROM users WHERE staffid='$PFNo'";
                                                if ($_SESSION['progtype'] == "UG") {
                                                    $result3 = $conn->query($sql3);
                                                } else {
                                                    $result3 = $conn5->query($sql3);
                                                }

                                                if ($result3->num_rows > 0) {
                                                    while ($row3 = $result3->fetch_assoc()) {
                                                        $otherstffdept = $row3["staffacddept"];
                                                    }
                                                }
                                            }
                                        }


                                ?>
                                        <div class="col-sm-6 col-md-4 col-lg-3">

                                            <section class="panel panel-quartenary">
                                                <header class="panel-heading bg-primary" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                                                    <div class="panel-heading-icon">
                                                        <?php if ($nostaf == 0) { ?>
                                                            <img src="img/favicon.ico" class="img-responsive" alt="<?php echo $CCode ?>">
                                                        <?php } elseif ($nostaf == 1) { ?>

                                                            <img src="<?php echo $staff_pic_folder ?>/<?php echo strtoupper($otherstffdept) ?>/images/<?php echo strtoupper($PFNo) ?>/MyPic1.jpg" class="img-responsive img-circle" style="height: 100px; width: 100px" alt="<?php echo $CCode ?>">


                                                        <?php } else { ?>
                                                            <img src="img/favicon.ico" class="img-responsive" alt="<?php echo $CCode ?>">
                                                        <?php } ?>
                                                    </div>
                                                </header>
                                                <div class="panel-body">
                                                    <div style="height: 100px; font-size: 14px">

                                                        <center>

                                                            <form class="form-horizontal bucket-form" method="Post" action="classroom_stu_course.php">
                                                                <input type='hidden' value='<?php echo $CCode ?>' name='getccode'>
                                                                <button type="submit" name="view_course" style="background: none!important; border: none; padding: 0!important; font-family: arial, sans-serif; color: #069; cursor: pointer; font-size:xx-large"><span style="text-transform: capitalize;"><?php echo $CCode ?></span></button>
                                                            </form>
                                                        </center>
                                                        <center>
                                                            <form class="form-horizontal bucket-form" method="Post" action="classroom_stu_course.php">
                                                                <input type='hidden' value='<?php echo $CCode ?>' name='getccode'>
                                                                <button type="submit" name="view_course" style="background: none!important; border: none; padding: 0!important; font-family: arial, sans-serif; color: #069; cursor: pointer"><span style="text-transform: capitalize;"><?php echo $CTitle ?></span></button>
                                                            </form>

                                                        </center>
                                                    </div>
                                                    <div class="summary-footer">
                                                        <hr class="separator" />

                                                        <?php
                                                        $countcomp = 0;
                                                        $countnotcomp = 0;
                                                        $sql2 = "SELECT *  FROM aaa_course_topic WHERE ccode = '$CCode'";
                                                        $result2 = $conn8->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {

                                                                $delivered = $row2["delivered"];
                                                                if ($delivered == "YES") {
                                                                    $countcomp++;
                                                                } else {
                                                                    $countnotcomp++;
                                                                }
                                                            }
                                                        }
                                                        if ($countcomp + $countnotcomp == 0) {
                                                            $perct = 0;
                                                        } else {
                                                            $perct = round(($countcomp / ($countcomp + $countnotcomp)) * 100);
                                                        }

                                                        ?>
                                                        <div class="progress light m-md">
                                                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $perct ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $perct ?>%;">
                                                                <?php echo $perct ?>% Complete
                                                            </div>
                                                        </div>
                                                        <div class="summary-footer" style="text-align: right">
                                                            <hr class="separator" />
                                                            <form class="form-horizontal bucket-form" method="Post" action="classroom_stu_course.php">
                                                                <input type='hidden' value='<?php echo $CCode ?>' name='getccode'>
                                                                <input type="submit" value="View" name="view_course" class='btn btn-primary btn-xs'>
                                                            </form>


                                                        </div>




                                                    </div>

                                                </div>

                                            </section>



                                        </div>
                                <?php
                                    }
                                }

                                ?>

                            </div>
                        </div>
                    </div>
                </section>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>


    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>


</body>

</html>
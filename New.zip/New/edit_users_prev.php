<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['create_users'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<?php $usercat = $_SESSION['cat']; ?>

<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Edit Users</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Users
                            </li>

                            <li class="active">
                                <strong>Edit Users</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Edit Users
                        </div>
                        <div class="panel-body">
                            <?php
                            if (isset($_POST["submitstaff"])) {
                                $sn = $_POST['sn'];
                                $_SESSION["sn"] = $sn;
                            } else {
                                $sn = $_SESSION["sn"];
                            }
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $sql = "SELECT * FROM users WHERE sn = '$sn'";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                // output data of each row
                                while ($row = $result->fetch_assoc()) {
                                    $pfno = $row["staffid"];
                                    $fullname = $row["full_name"];
                                    $phoneno = $row["phone"];
                                    $email = $row["emailAdd"];
                                    $Examiner = $row["Examiner"];
                                    $Ass_Examiner = $row["Ass_Examiner"];
                                    $PG_Coord = $row["PG_Coord"];
                                    $Seminer_Coord = $row["Seminer_Coord"];
                                    $SIWES_Coord = $row["SIWES_Coord"];
                                    $L100 = $row["L100"];
                                    $L200 = $row["L200"];
                                    $L300 = $row["L300"];
                                    $L400 = $row["L400"];
                                    $L500 = $row["L500"];
                                    $spill_over = $row["spill_over"];
                                    $CourseLec = $row["CourseLec"];
                                }
                            }
                            $conn->close();

                            ?>
                            <br>
                            <form class="form-horizontal" enctype="multipart/form-data" method="post"
                                action="edit_users_smt.php">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">PF Number:</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" style="color:#000000"
                                                    name="pfno" readonly value="<?php echo $pfno ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Full Name:</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" style="color:#000000"
                                                    name="fullname" value="<?php echo $fullname ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Phone Number:</label>
                                            <div class="col-lg-6">
                                                <input type="number" class="form-control" style="color:#000000"
                                                    name="phoneno" value="<?php echo $phoneno ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">email:</label>
                                            <div class="col-lg-6">
                                                <input type="email" class="form-control" style="color:#000000"
                                                    name="email" value="<?php echo $email ?>" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Passport:</label>
                                            <div class="col-lg-6">
                                                <?php
                                                $staff_pic_folder = $_SESSION['staff_pic_folder'];
                                                $filename = $staff_pic_folder . $pfno . '.jpg';

                                                if (file_exists($filename)) {
                                                    echo "<img alt='' class='' src='$staff_pic_folder" . $pfno . ".jpg' width='100' height='100'>";
                                                } else {
                                                    echo "<img alt=''  class='' src='img/logo.ico' width='100' height='100'>";
                                                }
                                                ?>
                                            </div>

                                        </div>

                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Change Staff Passport:</label>
                                            <div class="col-lg-6">
                                                <div class="fileinput fileinput-new input-group"
                                                    data-provides="fileinput">
                                                    <div class="form-control" data-trigger="fileinput">
                                                        <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                                        <span class="fileinput-filename"></span>
                                                    </div>
                                                    <span class="input-group-addon btn btn-default btn-file"><span
                                                            class="fileinput-new">Select
                                                            file</span><span
                                                            class="fileinput-exists">Change</span><input type="file"
                                                            name="uploaded"></span>
                                                    <a href="#"
                                                        class="input-group-addon btn btn-default fileinput-exists"
                                                        data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Course Lecturer:</label>
                                            <div class="col-lg-6">
                                                <select name="CourseLec" class="form-control" style="color:#000000"
                                                    id="CourseLec">
                                                    <option value="<?php echo $CourseLec ?>"><?php echo $CourseLec  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Exam Officer:</label>
                                            <div class="col-lg-6">
                                                <select name="Examiner" class="form-control" style="color:#000000"
                                                    id="Examiner">
                                                    <option value="<?php echo $Examiner ?>"><?php echo $Examiner  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Ass. Exam Officer:</label>
                                            <div class="col-lg-6">
                                                <select name="Ass_Examiner" class="form-control" style="color:#000000"
                                                    id="Ass_Examiner">
                                                    <option value="<?php echo $Ass_Examiner ?>">
                                                        <?php echo $Ass_Examiner  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <?php if ($_SESSION['InstType'] == "University") { ?>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">100 Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L100" class="form-control" style="color:#000000"
                                                    id="L100">
                                                    <option value="<?php echo $L100 ?>"><?php echo $L100  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">200 Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L200" class="form-control" style="color:#000000"
                                                    id="L200">
                                                    <option value="<?php echo $L200 ?>"><?php echo $L200  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">300 Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L300" class="form-control" style="color:#000000"
                                                    id="L300">
                                                    <option value="<?php echo $L300 ?>"><?php echo $L300  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">400 Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L400" class="form-control" style="color:#000000"
                                                    id="L400">
                                                    <option value="<?php echo $L400 ?>"><?php echo $L400  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">500 Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L500" class="form-control" style="color:#000000"
                                                    id="L500">
                                                    <option value="<?php echo $L500 ?>"><?php echo $L500  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Spill Over Level Adviser:</label>
                                            <div class="col-lg-6">
                                                <select name="spill_over" class="form-control" style="color:#000000"
                                                    id="spill_over">
                                                    <option value="<?php echo $spill_over ?>"><?php echo $spill_over  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Seminar Coordinator:</label>
                                            <div class="col-lg-6">
                                                <select name="Seminer_Coord" class="form-control" style="color:#000000"
                                                    id="Seminer_Coord">
                                                    <option value="<?php echo $Seminer_Coord ?>">
                                                        <?php echo $Seminer_Coord  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">PG Coordinator:</label>
                                            <div class="col-lg-6">
                                                <select name="PG_Coord" class="form-control" style="color:#000000"
                                                    id="PG_Coord">
                                                    <option value="<?php echo $PG_Coord ?>"><?php echo $PG_Coord  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">SIWES Coordinator:</label>
                                            <div class="col-lg-6">
                                                <select name="SIWES_Coord" class="form-control" style="color:#000000"
                                                    id="SIWES_Coord">
                                                    <option value="<?php echo $SIWES_Coord ?>">
                                                        <?php echo $SIWES_Coord  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">NDI Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L100" class="form-control" style="color:#000000"
                                                    id="L100">
                                                    <option value="<?php echo $L100 ?>"><?php echo $L100  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">NDII Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L200" class="form-control" style="color:#000000"
                                                    id="L200">
                                                    <option value="<?php echo $L200 ?>"><?php echo $L200  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">HNDI Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L300" class="form-control" style="color:#000000"
                                                    id="L300">
                                                    <option value="<?php echo $L300 ?>"><?php echo $L300  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">HNDII Level Advise:</label>
                                            <div class="col-lg-6">
                                                <select name="L400" class="form-control" style="color:#000000"
                                                    id="L400">
                                                    <option value="<?php echo $L400 ?>"><?php echo $L400  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Spill Over Level Adviser:</label>
                                            <div class="col-lg-6">
                                                <select name="spill_over" class="form-control" style="color:#000000"
                                                    id="spill_over">
                                                    <option value="<?php echo $spill_over ?>"><?php echo $spill_over  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Seminar Coordinator:</label>
                                            <div class="col-lg-6">
                                                <select name="Seminer_Coord" class="form-control" style="color:#000000"
                                                    id="Seminer_Coord">
                                                    <option value="<?php echo $Seminer_Coord ?>">
                                                        <?php echo $Seminer_Coord  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">SIWES Coordinator:</label>
                                            <div class="col-lg-6">
                                                <select name="SIWES_Coord" class="form-control" style="color:#000000"
                                                    id="SIWES_Coord">
                                                    <option value="<?php echo $SIWES_Coord ?>">
                                                        <?php echo $SIWES_Coord  ?>
                                                    </option>
                                                    <option value="NO">NO</option>
                                                    <option value="YES">YES</option>
                                                </select>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <br>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label"></label>
                                            <div class="col-lg-6">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </form>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- Sparkline -->
    <script src="js/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>

    <!-- Data picker -->
    <script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>
</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <?php

        $deptoption = $_SESSION['deptoption'];
        $deptname = $_SESSION["deptname"];
        $schcode = $_SESSION['schcode'];
        ?>
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Special List</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Special List</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            <?php echo $deptname ?> Department
                        </div>
                        <div class="panel-body">

                            <div class="row">

                                <div class="col-md-1">
                                </div>
                                <div class="col-md-10">
                                    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
                                        <form class="form-horizontal form-bordered" method="post">
                                            <div class="row">

                                                <div class="col-lg-4">
                                                    <div class="row">
                                                        <label class="control-label col-lg-5" for="content">Select
                                                            Department:</label>
                                                        <div class="col-lg-7">
                                                            <select class="country form-control" style="color:#000000"
                                                                name="dept">
                                                                <option value="SelectItem">Select Item</option>
                                                                <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

   
                                                                $dept = $_SESSION['deptcode'];

                                                                if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                                } else {
                                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                                }


                                                                $result = $conn->query($sql);

                                                                if ($result->num_rows > 0) {
                                                                    // output data of each row
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $deptcode2 = strtolower($row["DeptCode"]);
                                                                        $deptname2 = $row["DeptName"];
                                                                        echo "<option value=$deptcode2>$deptname2</option>";
                                                                    }
                                                                }
                                                                $conn->close();
                                                                ?>

                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="row">
                                                        <label class="control-label col-lg-5">Level:</label>
                                                        <div class="col-lg-7">

                                                            <select name="getlevel" class="form-control"
                                                                style="color:#000000" id="getlevel" required="required">
                                                                <option value="">Select Item</option>
                                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                                <option value="100">100 Level</option>
                                                                <option value="200">200 Level</option>
                                                                <option value="300">300 Level</option>
                                                                <option value="400">400 Level</option>
                                                                <option value="500">500 Level</option>
                                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                                <option value="100">ND I</option>
                                                                <option value="200">ND II</option>
                                                                <option value="300">HND I</option>
                                                                <option value="400">HND II</option>

                                                                <?php } else { ?>

                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="row">
                                                        <label class="control-label col-lg-5" for="regid">Select
                                                            Item:</label>
                                                        <div class="col-lg-7">
                                                            <select name="getitem" class="form-control"
                                                                style="color:#000000" id="getitem" required="required">
                                                                <option value="">Select Item</option>
                                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                                <option value="VL">VL</option>
                                                                <option value="DL">DL</option>
                                                                <option value="IGS">IGS</option>
                                                                <option value="DEF">DEF</option>
                                                                <option value="P">P</option>
                                                                <option value="SP1">SP1</option>
                                                                <option value="SP2">SP2(WD)</option>
                                                                <option value="10-8-8">10-8-8</option>
                                                                <option value="BL2">BL2</option>
                                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                                <option value="VL">RHL</option>
                                                                <option value="DL">DHL</option>
                                                                <option value="IGS">IGS</option>
                                                                <option value="DEF">COV</option>
                                                                <option value="P">PRO</option>
                                                                <option value="SP1">WAR</option>
                                                                <option value="SP2">WD</option>

                                                                <?php } else { ?>

                                                                <?php } ?>

                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="row">
                                                <br>
                                                <div class="col-lg-4">
                                                    <div class="row">
                                                        <label class="control-label col-lg-5" for="content">Select
                                                            Session:</label>
                                                        <div class="col-lg-7">
                                                            <?php
                                                            $iniyear = 2015;
                                                            $finalyear = substr($_SESSION['corntsession'], 5);

                                                            ?>
                                                            <select name="getsession" class="form-control"
                                                                style="color:#000000" id="getsession">
                                                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                                    <?php echo $_SESSION['corntsession'] ?>
                                                                </option>
                                                                <?php
                                                                while ($iniyear <= $finalyear) {
                                                                    $addyear = $iniyear + 1;

                                                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                                    $iniyear++;
                                                                }

                                                                ?>

                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="row">
                                                        <label class="control-label col-lg-5" for="regid">Select
                                                            Semester:</label>
                                                        <div class="col-lg-7">
                                                            <select name="getsemester" class="form-control"
                                                                style="color:#000000" id="getsemester"
                                                                required="required">
                                                                <option value="">Select Item</option>
                                                                <option value="1ST">1ST</option>
                                                                <option value="2ND">2ND</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="col-lg-4">
                                                    <div class="row">

                                                        <div class="col-lg-4">
                                                            <button type="submit" name="submit"
                                                                class="btn btn-primary btn-sm">Submit</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                        </form>
                                    </div>
                                    <hr class="separator" />
                                    <div style="padding-left:3em; padding-right: 3em;">

                                        <?php if (isset($_POST["submit"])) { ?>
                                        <?php
                                           

                                            $dept = $_POST["dept"];
                                            $getlevel = $_POST["getlevel"];
                                            $getitem = $_POST["getitem"];
                                            $getsession = $_POST["getsession"];
                                            $getsemester = $_POST["getsemester"];

                                            ?>
                                        <div class="col-lg-12">
                                            <div class="col-lg-4">
                                                <h5><b>Department: <?php echo $deptname; ?></b></h5>
                                            </div>
                                            <div class="col-lg-2">
                                                <h5><b>Level: <?php echo $getlevel; ?></b></h5>
                                            </div>
                                            <div class="col-lg-3">
                                                <h5><b>Session: <?php echo $getsession; ?></b></h5>
                                            </div>
                                            <div class="col-lg-3">
                                                <h5><b>Semester: <?php echo $getsemester; ?></b></h5>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <table
                                                class="table table-striped table-bordered table-hover dataTables-example">
                                                <thead style='text-align:center'>
                                                    <tr>
                                                        <th>S/ No</th>
                                                        <th>Matric_No</th>
                                                        <th>Name</th>
                                                        <th>PCGPA</th>
                                                        <th>SGPA</th>
                                                        <th>CGPA</th>
                                                        <th>RMK</th>
                                                        <th>Deff. & Outstanding</th>


                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php

                                                        $sno = 0;
                                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                        if ($conn_stu->connect_error) {
                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                        }
                                                        $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND RMK = '$getitem' ORDER BY Regn";
                                                        $result = $conn_stu->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $regid = $row["Regn"];
                                                                $names = $row["Name1"];
                                                                $PCGPA = $row["PCGPA"];
                                                                $SGPA = $row["SGPA"];
                                                                $CGPA = $row["CGPA"];

                                                                $RMK = $row["RMK"];
                                                                if ($_SESSION['InstType'] == "Polytechnic") {

                                                                    if ($RMK == "VL") {
                                                                        $RMK = "RHL";
                                                                    } elseif ($RMK == "DL") {
                                                                        $RMK = "DHL";
                                                                    } elseif ($RMK == "IGS") {
                                                                        $RMK = "IGS";
                                                                    } elseif ($RMK == "DEF") {
                                                                        $RMK = "COV";
                                                                    } elseif ($RMK == "P") {
                                                                        $RMK = "PRO";
                                                                    } elseif ($RMK == "SP1") {
                                                                        $RMK = "WAR";
                                                                    } elseif ($RMK == "SP2") {
                                                                        $RMK = "WD";
                                                                    }
                                                                }
                                                                $def_out = $row["def_out"];

                                                                echo "<tr><td>$sno</td><td>$regid </td><td> $names</td><td>$PCGPA</td><td>$SGPA</td><td>$CGPA</td><td>$RMK</td><td>$def_out</td></tr>\n";
                                                            }
                                                        }
$conn_stu->close();

                                                        ?>
                                                </tbody>
                                            </table>
                                        </div>

                                        <?php } ?>

                                    </div>

                                </div>
                                <div class="col-md-1">
                                </div>

                            </div>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
    $(document).ready(function() {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [{
                    extend: 'copy'
                },
                {
                    extend: 'csv'
                },
                {
                    extend: 'excel',
                    title: 'ExampleFile'
                },
                {
                    extend: 'pdf',
                    title: 'ExampleFile'
                },

                {
                    extend: 'print',
                    customize: function(win) {
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });

    });
    </script>
</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>
    <script src="js/getexcel/tableToExcel_Staff.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    $user1 = $_SESSION['staffid'];
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li><span>APU</span></li>
                            <li><span>Students Record</span></li>
                            <li class="active">
                                <strong>By State of Origin</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            By State of Origin
                        </div>
                        <div class="panel-body">
                            <?php
                            //error_reporting(0);
                            if (isset($_POST["submit"])) {
                                if (!$_POST["getsession"]) {
                                    $getsession = $_SESSION["getsession"];
                                }
                            }
                            ?>

                            <!-- start: page -->
                            <div class="row">

                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="form-group">
                                        <label class="control-label col-lg-3" style="font-size: larger">Session</label>
                                        <div class="col-lg-4">
                                            <?php if (!isset($_POST["submit"])) { ?>
                                                <?php
                                                $iniyear = 2018;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>
                                            <?php } else { ?>
                                                <?php echo $_SESSION["getsession"] ?>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-5">


                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-lg-2">
                                        </div>
                                        <div class="col-lg-8">
                                            <?php
                                            $sql = "SELECT * FROM states ORDER BY state";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                            ?>
                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th>Select</th>
                                                            <th>State Code</th>
                                                            <th>State</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["sn"];
                                                            $StateCode = $row["StateCode"];
                                                            $state = $row["state"];
                                                            echo "<tr>
                                    <td><input type='checkbox' name='chosen1c[" . $id . "]' value='" . $id . "'/></td>
                                    <td>
                                    <label id='statecode' name='statecode[" . $id . "]'>$StateCode</label>
                                    <input type='hidden' id='statecode' name='statecode[" . $id . "]' value='" . $StateCode . "'/>
                                    </td>
                                    <td>
                                    <label id='statetitle' name='statetitle[" . $id . "]'>$state</label>
                                    <input type='hidden' id='statetitle' name='statetitle[" . $id . "]' value='" . $state . "'/>
                                    </td>
                                    
                                    </tr>\n";
                                                        }
                                                        ?>

                                                    </tbody>
                                                </table>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-2">
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        <div class="col-lg-2">
                                        </div>
                                        <div class="col-lg-8" style="text-align: right">
                                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                        <div class="col-lg-2">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">
                                <?php

                                /*$sql = "SELECT * FROM staff_profile";
                $result = $conn7->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $PSN=$row["PSN"];
                        $name=$row["Name1"];
                        $parts = explode(" ", $name);
                        if(count($parts) > 1) {
                            $lastname = array_pop($parts);
                            $firstname = implode(" ", $parts);
                        }
                        else
                        {
                            $firstname = $name;
                            $lastname = " ";
                        }
                        $firstname = str_replace("'", "''", $firstname);
                        $lastname = str_replace("'", "''", $lastname);
                        $sql2="UPDATE staff_profile SET sname='$lastname', oname='$firstname' WHERE PSN='$PSN'";
                        $result2 = $conn7->query($sql2);
                        //echo "Lastname: $lastname\n";
                        //echo "Firstname: $firstname\n";
                    }
                }*/
                                //$_SESSION["getsession"]="XX";
                                ?>
                                <?php if (!empty($_POST["chosen1c"])) { ?>
                                    <?php
                                    set_time_limit(500);
                                    error_reporting(E_ERROR);

                                    $sql = "DELETE FROM state_select WHERE user1='$user1'";
                                    $result = $conn->query($sql);
                                    foreach ($_POST["chosen1c"] as $key => $value) {

                                        $statecode = $_POST["statecode"][$key];
                                        $statetitle = $_POST["statetitle"][$key];

                                        $sql = "INSERT INTO state_select (statecode, state, user1) VALUES ('$statecode', '$statetitle', '$user1')";
                                        $result = $conn->query($sql);
                                    }
                                    if ($_POST["getsession"]) {
                                        $getsession = $_POST["getsession"];
                                        $_SESSION["getsession"] = $getsession;
                                        $sql = "DELETE FROM dap_stu_dept WHERE user1='$user1'";
                                        $result = $conn->query($sql);
                                    } else {
                                        $getsession = $_SESSION["getsession"];
                                    }

                                    $GetTitle = "Students Count by State of Origin(" . $getsession . ")";

                                    $totmale = $totfemale = $tottotal = 0;
                                    $totcount100M = $totcount100F = $totcount200M = $totcount200F = $totcount300M = $totcount300F = $totcount400M = $totcount400F = $totcount500M = $totcount500F = $totcount600M = $totcount600F = 0;
                                    ?>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>State</th>
                                                    <th>Male</th>
                                                    <th>Female</th>
                                                    <th>Total</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $sql = "SELECT * FROM state_select WHERE user1='$user1' ORDER BY state";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $statecode = $row["statecode"];
                                                        $statetitle = $row["state"];
                                                        $statetitle2 = $row["state"];
                                                        $male = $female = $total = 0;
                                                        $count100M = $count100F = $count200M = $count200F = $count300M = $count300F = $count400M = $count400F = $count500M = $count500F = $count600M = $count600F = 0;

                                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                        if ($conn_stu->connect_error) {
                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                        }

                                                        $sql3 = "SELECT * FROM std_data_view WHERE state = '$statecode' OR state = '$statetitle2'";
                                                        $result3 = $conn2->query($sql3);
                                                        if ($result3->num_rows > 0) {
                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                $sex = $row3["gender"];
                                                                $dept = $row3["dept_code"];
                                                                $matricno = $row3["matric_no"];
                                                                $matriclen = strlen($matricno);
                                                                if ($matriclen >= 10) {
                                                                    //$getdept = strtolower($dept) . "_hod_list";
                                                                    $sql2 = "SELECT * FROM hod_list WHERE Session1 = '$getsession' AND matricno = '$matricno'";
                                                                    $result2 = $conn_stu->query($sql2);
                                                                    if ($result2->num_rows > 0) {
                                                                        while ($row2 = $result2->fetch_assoc()) {
                                                                            $StuLevel = $row2["StuLevel"];
                                                                            if ($sex == "Male") {
                                                                                $male++;
                                                                                $totmale++;
                                                                                if ($StuLevel == "100") {
                                                                                    $count100M++;
                                                                                    $totcount100M++;
                                                                                } elseif ($StuLevel == "200") {
                                                                                    $count200M++;
                                                                                    $totcount200M++;
                                                                                } elseif ($StuLevel == "300") {
                                                                                    $count300M++;
                                                                                    $totcount300M++;
                                                                                } elseif ($StuLevel == "400") {
                                                                                    $count400M++;
                                                                                    $totcount400M++;
                                                                                } elseif ($StuLevel == "500") {
                                                                                    $count500M++;
                                                                                    $totcount500M++;
                                                                                } elseif ($StuLevel >= "600") {
                                                                                    $count600M++;
                                                                                    $totcount600M++;
                                                                                }
                                                                            } elseif ($sex == "Female") {
                                                                                $female++;
                                                                                $totfemale++;
                                                                                if ($StuLevel == "100") {
                                                                                    $count100F++;
                                                                                    $totcount100F++;
                                                                                } elseif ($StuLevel == "200") {
                                                                                    $count200F++;
                                                                                    $totcount200F++;
                                                                                } elseif ($StuLevel == "300") {
                                                                                    $count300F++;
                                                                                    $totcount300F++;
                                                                                } elseif ($StuLevel == "400") {
                                                                                    $count400F++;
                                                                                    $totcount400F++;
                                                                                } elseif ($StuLevel == "500") {
                                                                                    $count500F++;
                                                                                    $totcount500F++;
                                                                                } elseif ($StuLevel >= "600") {
                                                                                    $count600F++;
                                                                                    $totcount600F++;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }


                                                        $total = $male + $female;
                                                        if ($total > 0) {

                                                            $sql3 = "SELECT * FROM dap_stu_dept WHERE deptcode = '$statecode' AND user1='$user1'";
                                                            $result3 = $conn->query($sql3);
                                                            if ($result3->num_rows == 0) {
                                                                $sql2 = "INSERT INTO dap_stu_dept (depttitle, nomale, nofemale, no100m, no100f, no200m, no200f, no300m, no300f, no400m, no400f, no500m, no500f, no600m, no600f, total, deptcode, user1) VALUES ('$statetitle', '$male', '$female', '$count100M', '$count100F', '$count200M', '$count200F', '$count300M', '$count300F', '$count400M', '$count400F', '$count500M', '$count500F', '$count600M', '$count600F', '$total', '$statecode', '$user1')";
                                                                $result2 = $conn->query($sql2);
                                                            }
                                                        }
                                                    }
                                                }
                                                $sql3 = "SELECT * FROM dap_stu_dept WHERE user1='$user1' ORDER BY depttitle";
                                                $result3 = $conn->query($sql3);
                                                if ($result3->num_rows > 0) {
                                                    while ($row3 = $result3->fetch_assoc()) {
                                                        $sno++;
                                                        //$DeptCode = $row3["deptcode"];
                                                        $statetitle = $row3["depttitle"];
                                                        $male = $row3["nomale"];
                                                        $female = $row3["nofemale"];
                                                        $total = $row3["total"];
                                                        echo "<tr><td>$sno</td><td>$statetitle</td><td>$male</td><td>$female</td>";
                                                        echo "<td>$total</td></tr>\n";
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>

                                <?php } ?>
                                <div class="form-group">
                                    <div class="col-lg-2">
                                    </div>
                                    <div class="col-lg-8" style="text-align: right">
                                        <?php if (!empty($_POST["chosen1c"])) { ?>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <button type="submit" name="conclude" class="btn btn-primary btn-sm">Conclude</button>
                                            </form>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-2">
                                    </div>
                                </div>
                                <?php if (isset($_POST["conclude"])) { ?>
                                    <?php
                                    $getsession = $_SESSION["getsession"];
                                    $GetTitle = "Students Count by State of Origin(" . $getsession . ")";
                                    ?>
                                    <h2 class="panel-title"><?php echo $GetTitle ?></h2>
                                    <?php
                                    $totmale = $totfemale = $tottotal = 0;
                                    $totcount100M = $totcount100F = $totcount200M = $totcount200F = $totcount300M = $totcount300F = $totcount400M = $totcount400F = $totcount500M = $totcount500F = $totcount600M = $totcount600F = 0;
                                    ?>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>State</th>
                                                    <th>Male</th>
                                                    <th>Female</th>
                                                    <th>100(M)</th>
                                                    <th>100(F)</th>
                                                    <th>200(M)</th>
                                                    <th>200(F)</th>
                                                    <th>300(M)</th>
                                                    <th>300(F)</th>
                                                    <th>400(M)</th>
                                                    <th>400(F)</th>
                                                    <th>500(M)</th>
                                                    <th>500(F)</th>
                                                    <th>Spill(M)</th>
                                                    <th>Spill(F)</th>
                                                    <th>Total</th>
                                                    <th>State Code</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $male = $female = $total = 0;
                                                $count100M = $count100F = $count200M = $count200F = $count300M = $count300F = $count400M = $count400F = $count500M = $count500F = $count600M = $count600F = 0;
                                                $sql = "SELECT * FROM dap_stu_dept WHERE user1='$user1' ORDER BY depttitle";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $statecode = $row["deptcode"];
                                                        $statetitle = $row["depttitle"];
                                                        $male = $row["nomale"];
                                                        $female = $row["nofemale"];
                                                        $count100M = $row["no100m"];
                                                        $count100F = $row["no100f"];
                                                        $count200M = $row["no200m"];
                                                        $count200F = $row["no200f"];
                                                        $count300M = $row["no300m"];
                                                        $count300F = $row["no300f"];
                                                        $count400M = $row["no400m"];
                                                        $count400F = $row["no400f"];
                                                        $count500M = $row["no500m"];
                                                        $count500F = $row["no500f"];
                                                        $count600M = $row["no600m"];
                                                        $count600F = $row["no600f"];
                                                        $total = $row["total"];
                                                        $totmale = $totmale + $male;
                                                        $totfemale = $totfemale + $female;
                                                        $totcount100M = $totcount100M + $count100M;
                                                        $totcount100F = $totcount100F + $count100F;
                                                        $totcount200M = $totcount200M + $count200M;
                                                        $totcount200F = $totcount200F + $count200F;
                                                        $totcount300M = $totcount300M + $count300M;
                                                        $totcount300F = $totcount300F + $count300F;
                                                        $totcount400M = $totcount400M + $count400M;
                                                        $totcount400F = $totcount400F + $count400F;
                                                        $totcount500M = $totcount500M + $count500M;
                                                        $totcount500F = $totcount500F + $count500F;
                                                        $totcount600M = $totcount600M + $count600M;
                                                        $totcount600F = $totcount600F + $count600F;

                                                        $sno++;
                                                        echo "<tr><td>$sno</td><td>$statetitle</td><td>$male</td><td>$female</td><td>$count100M</td><td>$count100F</td>";
                                                        echo "<td>$count200M</td><td>$count200F</td><td>$count300M</td><td>$count300F</td><td>$count400M</td><td>$count400F</td>";
                                                        echo "<td>$count500M</td><td>$count500F</td><td>$count600M</td><td>$count600F</td>";
                                                        echo "<td>$total</td><td>$statecode</td><td>
                                                <form action='dap_stu_list.php' method='post'>
                                                    <input type='hidden' value='$statecode' name='id'>
                                                    <input type='hidden' value='$statetitle' name='id2'>
                                                    <input type='hidden' value='yesstate' name='deptstate'>
                                                    <input type='hidden' value='$getsession' name='mysession'>
                                                    <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                                </form>
                                                </td>
                                                    
                                                </tr>\n";
                                                    }
                                                }
                                                $tottotal = $totmale + $totfemale;
                                                echo "<tr><th></th><th>Total</th><th>$totmale</th><th>$totfemale</th><th>$totcount100M</th><th>$totcount100F</th>";
                                                echo "<th>$totcount200M</th><th>$totcount200F</th><th>$totcount300M</th><th>$totcount300F</th><th>$totcount400M</th><th>$totcount400F</th>";
                                                echo "<th>$totcount500M</th><th>$totcount500F</th><th>$totcount600M</th><th>$totcount600F</th>";
                                                echo "<th>$tottotal</th><th></th><th></th>
                                                            
                                           </tr>\n";
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <br><br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                    </div>

                                    <?php
                                    $sql = "DELETE FROM dap_stu_dept WHERE user1='$user1'";
                                    $result = $conn->query($sql);
                                    ?>
                                <?php } ?>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$usernames = $_SESSION['names'];
$cat = $_SESSION['cat'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$staffid = $_SESSION['staffid'];
$dept = strtoupper($_SESSION['deptcode']);

?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">
    <!-- Textarea Editor -->
    <link href="editor/css_/bootstrap3-wysihtml5.min.css" rel="stylesheet" media="screen" />
    <!--Download to excel-->
    <script src="assets/javascripts/tableToExcel_ATD.js"></script>
    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <?php
                $imgpf = str_replace('.', '_', $_SESSION['staffid']);

                ?>

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php

                            echo "<img src='https://staff.futminna.edu.ng/" . strtoupper($_SESSION['deptcode']) . "/images/" . strtoupper($imgpf) . "/MyPic1.jpg' alt='$usernames' class='img-circle' width='50' height='50' />";
                            ?>
                        </figure>
                        <div class="profile-info">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $staffid ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="staff_profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_staff.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="lock_screen.php"><i class="fa fa-lock"></i> Lock
                                    Screen</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout_staff.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>




                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_staff_class.php'; ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>">
                    <h2>Welcome to Nigerian Army University, Biu e-Classroom</h2>

                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>

                                <a href="classroom_start.php" class='btn btn-primary btn-xs'><i class="fa fa-home"></i>
                                    Home</a>
                            </li>

                            <li>
                                <form class="form-horizontal bucket-form" method="Post" action="classroom_course.php">
                                    <input type="submit" value="Back to Classroom" name="submit_class" class='btn btn-info btn-xs'>
                                </form>

                            </li>

                        </ol>
                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">


                            <div class="nano">
                                <div class="form-group" style="padding-left: 1em; padding-right: 1em">

                                </div>
                                <div class="nano-content">

                                    <div class="inner-menu-toggle-inside">
                                        <a href="#" class="inner-menu-collapse">
                                            <i class="fa fa-chevron-up visible-xs-inline"></i><i class="fa fa-chevron-left hidden-xs-inline"></i> Hide Bar
                                        </a>
                                        <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                            Show Bar <i class="fa fa-chevron-down"></i>
                                        </a>
                                    </div>

                                    <div class="inner-menu-content">


                                    </div>
                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">

                            <?php if (isset($_POST["view_assessment2"])) { ?>

                                <h3><?php echo $_SESSION["ccode"] ?> Assignment</h3>

                                <div class="row">
                                    <div class="col-md-12">
                                        <section class="panel">
                                            <div class="panel-body">
                                                <?php
                                                $id = $_POST["id"];
                                                $sql = "SELECT * FROM aaa_assignment WHERE id = '$id'";
                                                $result = $conn8->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {

                                                        $assignment_no = $row["assignment_no"];
                                                        if ($assignment_no == 1) {
                                                            $assign_cat = "First Assignment";
                                                        } elseif ($assignment_no == 2) {
                                                            $assign_cat = "Second Assignment";
                                                        } else {
                                                            $assign_cat = "Third Assignment";
                                                        }
                                                        $message = $row["message"];
                                                        $tot_mark = $row["tot_mark"];
                                                        $file_url = $row["file_url"];
                                                        $filename = $row["filename"];
                                                        $status1 = $row["status"];
                                                        $deadline = date('d F, Y', strtotime($row["deadline"]));
                                                    }
                                                }
                                                ?>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label"><?php echo $assign_cat ?>:
                                                    </label>
                                                    <div class="col-md-9">
                                                        <?php echo $message ?>
                                                    </div>

                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Deadline: </label>
                                                    <div class="col-md-9">
                                                        <?php echo $deadline ?>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">PDF File: </label>
                                                    <div class="col-md-9">
                                                        <?php
                                                        if (strlen($file_url) > 1) {
                                                        ?>
                                                            <a href="<?php echo $file_url ?>" target="_blank"><img src="assets/images/pdf_icon.png" width="40" height="40"><?php echo $filename ?></a>
                                                        <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Status: </label>
                                                    <div class="col-md-9">
                                                        <?php echo $status1 ?>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Total Mark: </label>
                                                    <div class="col-md-9">
                                                        <?php echo $tot_mark ?>
                                                    </div>
                                                </div>
                                            </div>

                                        </section>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>

                    </div>

                </section>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>

    <!--Textarea Editor-->
    <script src="editor/js_/app.js" type="text/javascript"></script>
    <script src="editor/js_/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="editor/js_/ckeditor.js" type="text/javascript"></script>
    <script src="editor/js_/jquery.js" type="text/javascript"></script>
    <script src="editor/js_/editor1.js" type="text/javascript"></script>

</body>

</html>
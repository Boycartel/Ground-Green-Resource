<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}

?>
<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">


    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Users Management</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_staff.php">Home</a>
                        </li>
                        <li>
                            <a>Users</a>
                        </li>
                        <li class="active">
                            <strong>Users Management</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <?php
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $success = $recexist = $errorpf = "";
            $errorcode = "NO";
            if (isset($_POST["submitAddNew"])) {
                $pfno = validate_input($_POST['pfno']);
                $fullname = validate_input($_POST['fullname']);
                $phoneno = validate_input($_POST['phoneno']);
                $email = validate_input($_POST['email']);
                $dept = validate_input($_POST['dept']);

                if (strlen($pfno) < 5) {
                    $errorcode = "YES";
                }
                if ($_POST['pfno'] == "" || $_POST['fullname'] == "" || $_POST['phoneno'] == "" || $_POST['email'] == "" || $_POST['dept'] == "") {
                    $errorpf = "All Fields are Required";
                } else {
                    if ($errorcode == "NO") {
                        $password3 = rand(100000, 1000000);
                        $password2 = md5($password3);

                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $School = $row["School"];
                            }
                        }

                        $sql = "SELECT * FROM users WHERE staffid = '$pfno'";
                        $result = $conn->query($sql);
                        if ($result->num_rows == 0) {
                            $sql2 = "INSERT INTO users(staffid, password2, password3, full_name, phone, emailAdd, department, staffacddept, SchCode) VALUES ('$pfno', '$password2', '$password3', '$fullname', '$phoneno', '$email', '$dept', '$dept', '$School')";
                            $result2 = $conn->query($sql2);
                            $success = "<h2 class='alert alert-success'>Record Saved Successfully with Password: $password3</h2>";
                        } else {
                            $recexist = "<h2 class='alert alert-danger'>Record Already Exist ...</h2>";
                        }
                    } else {
                        $errorpf = "Wrong File Number Format";
                    }
                }
            }


            if (isset($_POST["update"])) {
                $id = $_POST['id'];
                $pfno = validate_input($_POST['pfno']);
                $fullname = validate_input($_POST['fullname']);
                $phoneno = validate_input($_POST['phoneno']);
                $email = validate_input($_POST['email']);
                $dept = validate_input($_POST['dept']);

                $activestatus = validate_input($_POST['activestatus']);
                $helpdesk = validate_input($_POST['helpdesk']);
                $otp = validate_input($_POST['otp']);

                $Dean = $_POST["Dean"];
                $HOD = $_POST["HOD"];
                $SchExaminer = $_POST["SchExaminer"];
                $POs = $_POST["POs"];
                $APU = $_POST["APU"];
                $QAP = $_POST["QAP"];
                $AcadSec = $_POST["AcadSec"];
                $Acad_Ofice = $_POST["Acad_Ofice"];
                $transcript = $_POST["transcript"];

                $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $School = $row["School"];
                    }
                }

                $sql = "UPDATE users SET full_name ='$fullname', phone ='$phoneno', emailAdd ='$email', department ='$dept', staffacddept ='$dept', SchCode ='$School', active_status ='$activestatus', helpdesk ='$helpdesk', pwd_reset_token ='$otp' WHERE sn='$id'";
                $result = $conn->query($sql);

                if ($Dean == "YES") {
                    $sql3 = "UPDATE users SET Dean = 'NO' WHERE SchCode = '$School'";
                    $result3 = $conn->query($sql3);
                }
                if ($HOD == "YES") {
                    $sql3 = "UPDATE users SET HOD = 'NO' WHERE staffacddept = '$dept'";
                    $result3 = $conn->query($sql3);
                }
                if ($SchExaminer == "YES") {
                    $sql3 = "UPDATE users SET SchExaminer = 'NO' WHERE SchCode = '$School'";
                    $result3 = $conn->query($sql3);
                }
                if ($AcadSec == "YES") {
                    $sql3 = "UPDATE users SET AcadSec = 'NO'";
                    $result3 = $conn->query($sql3);
                }

                $sql = "UPDATE users SET Dean ='$Dean', HOD ='$HOD', SchExaminer ='$SchExaminer', POs ='$POs', APU ='$APU', QAP ='$QAP', AcadSec ='$AcadSec', Acad_Ofice ='$Acad_Ofice', transcript ='$transcript' WHERE sn='$id'";
                $result = $conn->query($sql);

                $success = "<h2 class='alert alert-success'>Record Update Successfully ...</h2>";
            }

            if (isset($_POST["passwdreset"])) {
                $id = $_POST['id'];
                $password3 = rand(100000, 1000000);
                $password2 = md5($password3);

                $sql = "UPDATE users SET password2 ='$password2', password3 ='$password3' WHERE sn='$id'";
                $result = $conn->query($sql);

                $success = "<h2 class='alert alert-success'>Record Saved Successfully with Password: $password3</h2>";
            }

            if (isset($_POST["delete"])) {
                $id = $_POST['id'];

                $sql = "DELETE FROM users WHERE sn = '$id'";
                $result = $conn->query($sql);

                $success = "<h2 class='alert alert-success'>Record Deleted Successfully ...</h2>";
            }
            ?>
            <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Users Management</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-user">
                                        <li><a href="#">Config option 1</a>
                                        </li>
                                        <li><a href="#">Config option 2</a>
                                        </li>
                                    </ul>
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-sm-7">
                                        <h3></h3>
                                    </div>
                                    <div class="col-sm-3">

                                        <center><strong>
                                                <h3 style="color:#F00"><?php echo $recexist ?></h3>
                                            </strong></center>
                                        <center><strong>
                                                <h3 style="color:#F00"><?php echo $errorpf ?></h3>
                                            </strong></center>
                                        <center><strong>
                                                <h3 style="color:#00C"><?php echo $success ?></h3>
                                            </strong></center>
                                    </div>
                                    <div class="col-sm-2">
                                        <a href="#addEmployeeModal" class="btn btn-success btn-xs"
                                            data-toggle="modal"><i class="material-icons"></i> <span>Add New</span></a>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered table-hover dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>S/No</th>
                                                <th>File Number</th>
                                                <th>Name</th>
                                                <th>Department</th>
                                                <th>Role</th>
                                                <th>Phone Number</th>
                                                <th>email</th>
                                                <!-- <th>Online Status</th> -->
                                                <th>Active Status</th>
                                                <th>Help Desk Officer</th>
                                                <th>OTP</th>
                                                <th>Action</th>
                                                <th>Paaswd Reset</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sno = 0;

                                            $sql = "SELECT * FROM users WHERE staffid <> 'PF0723'";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $resposblt = "";
                                                    $sno++;
                                                    $id = $row["sn"];
                                                    $staffid = $row["staffid"];
                                                    $full_name = $row["full_name"];
                                                    $staffacddept = $row["staffacddept"];
                                                    $cat = $row["cat"];
                                                    $phone = $row["phone"];
                                                    $emailAdd = $row["emailAdd"];
                                                    $level = $row["Level1"];
                                                    $online_status = $row["online_status"];
                                                    $active_status = $row["active_status"];
                                                    $helpdesk = $row["helpdesk"];
                                                    $pwd_reset_token = $row["pwd_reset_token"];

                                                    $Dean = $row["Dean"];
                                                    $HOD = $row["HOD"];
                                                    $SchExaminer = $row["SchExaminer"];
                                                    $POs = $row["POs"];
                                                    $APU = $row["APU"];
                                                    $QAP = $row["QAP"];
                                                    $AcadSec = $row["AcadSec"];
                                                    $Acad_Ofice = $row["Acad_Ofice"];
                                                    $transcript = $row["transcript"];

                                                    $Examiner = $row["Examiner"];
                                                    $Ass_Examiner = $row["Ass_Examiner"];
                                                    $PG_Coord = $row["PG_Coord"];
                                                    $Seminer_Coord = $row["Seminer_Coord"];
                                                    $SIWES_Coord = $row["SIWES_Coord"];
                                                    $L100 = $row["L100"];
                                                    $L200 = $row["L200"];
                                                    $L300 = $row["L300"];
                                                    $L400 = $row["L400"];
                                                    $L500 = $row["L500"];
                                                    $spill_over = $row["spill_over"];
                                                    $CourseLec = $row["CourseLec"];

                                                    if ($CourseLec == "YES") {
                                                        $resposblt = $resposblt . "Course Lecturer";
                                                    }
                                                    if ($Dean == "YES") {
                                                        $resposblt = $resposblt . ", Dean";
                                                    }
                                                    if ($HOD == "YES") {
                                                        $resposblt = $resposblt . ", HOD";
                                                    }
                                                    if ($SchExaminer == "YES") {
                                                        $resposblt = $resposblt . ", School/Faculty Exam Officer";
                                                    }
                                                    if ($POs == "YES") {
                                                        $resposblt = $resposblt . ", Principal Officer";
                                                    }
                                                    if ($APU == "YES") {
                                                        $resposblt = $resposblt . ", APU";
                                                    }
                                                    if ($QAP == "YES") {
                                                        $resposblt = $resposblt . ", QAP";
                                                    }
                                                    if ($AcadSec == "YES") {
                                                        $resposblt = $resposblt . ", Academic Secretary";
                                                    }
                                                    if ($Acad_Ofice == "YES") {
                                                        $resposblt = $resposblt . ", Academic Officer";
                                                    }
                                                    if ($transcript == "YES") {
                                                        $resposblt = $resposblt . ", Transcript Officer";
                                                    }
                                                    if ($Examiner == "YES") {
                                                        $resposblt = $resposblt . ", Exam Officer";
                                                    }
                                                    if ($Ass_Examiner == "YES") {
                                                        $resposblt = $resposblt . ", Ass. Exam Officer";
                                                    }
                                                    if ($PG_Coord == "YES") {
                                                        $resposblt = $resposblt . ", PG Coordinator";
                                                    }
                                                    if ($Seminer_Coord == "YES") {
                                                        $resposblt = $resposblt . ", Seminar Coordinator";
                                                    }
                                                    if ($SIWES_Coord == "YES") {
                                                        $resposblt = $resposblt . ", SIWES Coordinator";
                                                    }
                                                    if ($_SESSION['InstType'] == "University") {

                                                        if ($L100 == "YES") {
                                                            $resposblt = $resposblt . ", 100 Level Adviser";
                                                        }
                                                        if ($L200 == "YES") {
                                                            $resposblt = $resposblt . ", 200 Level Adviser";
                                                        }
                                                        if ($L300 == "YES") {
                                                            $resposblt = $resposblt . ", 300 Level Adviser";
                                                        }
                                                        if ($L400 == "YES") {
                                                            $resposblt = $resposblt . ", 400 Level Adviser";
                                                        }
                                                        if ($L500 == "YES") {
                                                            $resposblt = $resposblt . ", 500 Level Adviser";
                                                        }
                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {

                                                        if ($L100 == "YES") {
                                                            $resposblt = $resposblt . ", NDI Level Adviser";
                                                        }
                                                        if ($L200 == "YES") {
                                                            $resposblt = $resposblt . ", NDII Level Adviser";
                                                        }
                                                        if ($L300 == "YES") {
                                                            $resposblt = $resposblt . ", HNDI Level Adviser";
                                                        }
                                                        if ($L400 == "YES") {
                                                            $resposblt = $resposblt . ", HNDII Level Adviser";
                                                        }
                                                    }
                                                    if ($spill_over == "YES") {
                                                        $resposblt = $resposblt . ", Spill Over Adviser";
                                                    }



                                                    if ($online_status == "Online") {
                                                        $online_status2 = "<span class='label label-success pull-right'>Online</span>";
                                                    } else {
                                                        $online_status2 = "<span class='label label-danger pull-right'>Offline</span>";
                                                    }

                                                    if ($active_status == 1) {
                                                        $active_status2 = "<span class='label label-success pull-right'>Active</span>";
                                                    } else {
                                                        $active_status2 = "<span class='label label-danger pull-right'>Inactive</span>";
                                                    }

                                                    if ($helpdesk == "YES") {
                                                        $helpdesk2 = "<span class='label label-success pull-right'>Desk Officer</span>";
                                                    } else {
                                                        $helpdesk2 = "";
                                                    }

                                                    if ($pwd_reset_token > 0) {
                                                        $pwd_reset_token2 = "<span class='label label-success pull-right'>$pwd_reset_token</span>";
                                                    } else {
                                                        $pwd_reset_token2 = "";
                                                    }
                                            ?>
                                            <tr id='<?php echo $id ?>'>
                                                <td><?php echo $sno ?></td>
                                                <td><?php echo $staffid ?></td>
                                                <td><?php echo $full_name ?></td>
                                                <td><?php echo $staffacddept ?></td>
                                                <td><?php echo $resposblt ?></td>
                                                <td><?php echo $phone ?></td>
                                                <td><?php echo $emailAdd ?></td>

                                                <td><?php echo $active_status2 ?></td>
                                                <td><?php echo $helpdesk2 ?></td>
                                                <td><?php echo $pwd_reset_token2 ?></td>

                                                <td>

                                                    <a href="#editEmployeeModal" class="edit" data-toggle="modal">

                                                        <i class="material-icons update" data-toggle="tooltip"
                                                            data-id="<?php echo $row["sn"]; ?>"
                                                            data-pfno="<?php echo $staffid; ?>"
                                                            data-fullname="<?php echo $full_name; ?>"
                                                            data-dept="<?php echo $staffacddept; ?>"
                                                            data-cat="<?php echo $cat; ?>"
                                                            data-phoneno="<?php echo $phone; ?>"
                                                            data-email="<?php echo $emailAdd; ?>"
                                                            data-onlinestatus="<?php echo $online_status; ?>"
                                                            data-activestatus="<?php echo $active_status; ?>"
                                                            data-helpdesk="<?php echo $helpdesk; ?>"
                                                            data-otp="<?php echo $pwd_reset_token; ?>"
                                                            data-dean="<?php echo $Dean; ?>"
                                                            data-hod="<?php echo $HOD; ?>"
                                                            data-schexaminer="<?php echo $SchExaminer; ?>"
                                                            data-pos="<?php echo $POs; ?>"
                                                            data-apu="<?php echo $APU; ?>"
                                                            data-qap="<?php echo $QAP; ?>"
                                                            data-acadsec="<?php echo $AcadSec; ?>"
                                                            data-acadofice="<?php echo $Acad_Ofice; ?>"
                                                            data-transcript="<?php echo $transcript; ?>"
                                                            title="Edit"></i>
                                                    </a>
                                                    <?php
                                                            echo '<a href="#deleteEmployeeModal" class="delete" data-id="' . $row['sn'] . '"><i class="material-icons" data-toggle="tooltip" title="Delete" style="color:red">&#xE872;</i></a>';
                                                            ?>

                                                </td>

                                                <td>

                                                    <?php
                                                            echo '<a href="#passwdresetEmployeeModal" class="passwdreset" data-id="' . $row['sn'] . '" data-fullname="' . $row['staffid'] . " " . $row['full_name'] . '"><i class="material-icons key data-toggle="tooltip" title="Reset Password" style="color:red">&#xe73c;</i></a>';
                                                            ?>

                                                </td>

                                            </tr>

                                            <?php
                                                }
                                            }
                                            ?>

                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>S/No</th>
                                                <th>File Number</th>
                                                <th>Name</th>
                                                <th>Department</th>
                                                <th>Role</th>
                                                <th>Phone Number</th>
                                                <th>email</th>
                                                <!-- <th>Online Status</th> -->
                                                <th>Active Status</th>
                                                <th>Help Desk Officer</th>
                                                <th>OTP</th>
                                                <th>Action</th>
                                                <th>Paaswd Reset</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $conn->close();
            ?>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
    </div>

    <!-- Add Modal HTML -->
    <div id="addEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="user_form" action="" method="post">
                    <div class="modal-header">
                        <h4 class="modal-title">Add New</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <center><strong>
                                    <h4 style="color:#000">Staff Number in at least 5 character e.g. F0001</h4>
                                </strong></center>
                            <label>File Number:</label>
                            <input type="text" class="form-control" style="color:#000000" name="pfno" required>
                        </div>
                        <div class="form-group">
                            <label>Full Name:</label>
                            <input type="text" class="form-control" style="color:#000000" name="fullname" required>
                        </div>
                        <div class="form-group">
                            <label>Phone Number:</label>
                            <input type="number" class="form-control" style="color:#000000" name="phoneno" required>
                        </div>
                        <div class="form-group">
                            <label>email:</label>
                            <input type="email" class="form-control" style="color:#000000" name="email" required>
                        </div>

                        <div class="form-group">
                            <label>Department</label>

                            <select name="dept" class="form-control" style="color:#000000" required="required">
                                <option value="">Select Item</option>
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                $sql = "SELECT * FROM deptcoding";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $DeptCode = $row["DeptCode"];
                                        $DeptName = $row["DeptName"];
                                        echo "<option value='$DeptCode'>$DeptName</option>";
                                    }
                                }
                                $conn->close();
                                ?>
                            </select>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <input type="hidden" value="1" name="type">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <button type="submit" name="submitAddNew" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Edit Modal HTML -->
    <div id="editEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="update_form" action="" method="post">
                    <div class="modal-header">
                        <h4 class="modal-title">Edit Record</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="id_u" name="id" class="form-control" required>
                        <div class="form-group">
                            <label>File Number:</label>
                            <input type="text" class="form-control" style="color:#000000" name="pfno" id="pfno_u"
                                readonly>
                        </div>
                        <div class="form-group">
                            <label>Full Name:</label>
                            <input type="text" class="form-control" style="color:#000000" name="fullname"
                                id="fullname_u" required>
                        </div>
                        <div class="form-group">
                            <label>Phone Number:</label>
                            <input type="number" class="form-control" style="color:#000000" name="phoneno"
                                id="phoneno_u" required>
                        </div>
                        <div class="form-group">
                            <label>email:</label>
                            <input type="email" class="form-control" style="color:#000000" name="email" id="email_u"
                                required>
                        </div>

                        <div class="form-group">
                            <label>Department</label>

                            <select name="dept" class="form-control" style="color:#000000" id="dept_u"
                                required="required">
                                <option value="">Select Item</option>
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                $sql = "SELECT * FROM deptcoding";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $DeptCode = $row["DeptCode"];
                                        $DeptName = $row["DeptName"];
                                        echo "<option value='$DeptCode'>$DeptName</option>";
                                    }
                                }
                                $conn->close();

                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <h2 style="text-align: center;">Role</h2>
                            <div class="row">
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Dean:</label>
                                    <div class="col-lg-6">
                                        <select name="Dean" class="form-control" style="color:#000000" id="dean_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">HOD:</label>
                                    <div class="col-lg-6">
                                        <select name="HOD" class="form-control" style="color:#000000" id="hod_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">School Exam Officer:</label>
                                    <div class="col-lg-6">
                                        <select name="SchExaminer" class="form-control" style="color:#000000"
                                            id="schexaminer_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Principal Officer:</label>
                                    <div class="col-lg-6">
                                        <select name="POs" class="form-control" style="color:#000000" id="pos_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">APU:</label>
                                    <div class="col-lg-6">
                                        <select name="APU" class="form-control" style="color:#000000" id="apu_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">QAP:</label>
                                    <div class="col-lg-6">
                                        <select name="QAP" class="form-control" style="color:#000000" id="qap_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Academic Secretary:</label>
                                    <div class="col-lg-6">
                                        <select name="AcadSec" class="form-control" style="color:#000000"
                                            id="acadsec_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Academic Officer:</label>
                                    <div class="col-lg-6">
                                        <select name="Acad_Ofice" class="form-control" style="color:#000000"
                                            id="acadofice_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Transcript Officer:</label>
                                    <div class="col-lg-6">
                                        <select name="transcript" class="form-control" style="color:#000000"
                                            id="transcript_u">
                                            <option value="NO">NO</option>
                                            <option value="YES">YES</option>
                                        </select>
                                    </div>
                                </div>

                            </div>

                        </div>

                        <div class="form-group">
                            <label>Active Status:</label>
                            <select name="activestatus" class="form-control" style="color:#000000" id="activestatus_u"
                                required="required">
                                <option value="">Select Item</option>
                                <option value='1'>Active</option>
                                <option value='0'>Inactive</option>

                            </select>
                        </div>
                        <div class="form-group">
                            <label>Help Desk Officer:</label>
                            <select name="helpdesk" class="form-control" style="color:#000000" id="helpdesk_u"
                                required="required">
                                <option value="">Select Item</option>
                                <option value='YES'>YES</option>
                                <option value='NO'>NO</option>

                            </select>
                        </div>
                        <div class="form-group">
                            <label>OTP:</label>
                            <input type="number" class="form-control" style="color:#000000" name="otp" id="otp_u"
                                required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" value="2" name="type">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                        <!--<button type="button" class="btn btn-info" id="update">Update</button>-->
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Password Modal HTML -->

    <div id="passwdresetEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- give your form an action and method -->
                <form action="" method="POST">
                    <div class="modal-header">
                        <h4 class="modal-title" style="color: #F00;"><strong>Password Reset</strong></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">

                        <p>Are you sure you want to Reset these Password?</p>
                        <div class="form-group">

                            <input type="text" class="form-control" style="color:#000000" name="fullname" value=""
                                readonly />
                        </div>
                        <p class="text-warning"><small>This action cannot be undone.</small></p>
                    </div>
                    <div class="modal-footer">
                        <!-- add a hidden input field to store ID for next step -->
                        <input type="hidden" name="id" value="" />
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <!-- change your delete link to a submit button -->
                        <button name="passwdreset" class="btn btn-danger" type="submit">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Modal HTML -->

    <div id="deleteEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- give your form an action and method -->
                <form action="" method="POST">
                    <div class="modal-header">
                        <h4 class="modal-title">Delete Record</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="session1" value="" />
                        <p>Are you sure you want to delete these Records?</p>
                        <p class="text-warning"><small>This action cannot be undone.</small></p>
                    </div>
                    <div class="modal-footer">
                        <!-- add a hidden input field to store ID for next step -->
                        <input type="hidden" name="id" value="" />
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <!-- change your delete link to a submit button -->
                        <button name="delete" class="btn btn-danger" type="submit">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </section>




    <script>
    $(function() {
        $('a.passwdreset').click(function(e) {
            e.preventDefault();
            var link = this;
            var passwdresetModal = $("#passwdresetEmployeeModal");
            // store the ID inside the modal's form
            passwdresetModal.find('input[name=fullname]').val(link.dataset.fullname);
            passwdresetModal.find('input[name=id]').val(link.dataset.id);
            // open modal
            passwdresetModal.modal();
        });
    });
    </script>

    <script>
    $(function() {
        $('a.delete').click(function(e) {
            e.preventDefault();
            var link = this;
            var deleteModal = $("#deleteEmployeeModal");
            // store the ID inside the modal's form
            deleteModal.find('input[name=session1]').val(link.dataset.session1);
            deleteModal.find('input[name=id]').val(link.dataset.id);
            // open modal
            deleteModal.modal();
        });
    });
    </script>

    <script>
    $(document).on('click', '.update', function(e) {

        var id = $(this).attr("data-id");
        var pfno = $(this).attr("data-pfno");
        var fullname = $(this).attr("data-fullname");
        var dept = $(this).attr("data-dept");
        var cat = $(this).attr("data-cat");
        var phoneno = $(this).attr("data-phoneno");
        var email = $(this).attr("data-email");
        var onlinestatus = $(this).attr("data-onlinestatus");
        var activestatus = $(this).attr("data-activestatus");
        var helpdesk = $(this).attr("data-helpdesk");
        var otp = $(this).attr("data-otp");
        var dean = $(this).attr("data-dean");
        var hod = $(this).attr("data-hod");
        var schexaminer = $(this).attr("data-schexaminer");
        var pos = $(this).attr("data-pos");
        var apu = $(this).attr("data-apu");
        var qap = $(this).attr("data-qap");
        var acadsec = $(this).attr("data-acadsec");
        var acadofice = $(this).attr("data-acadofice");
        var transcript = $(this).attr("data-transcript");
        $('#id_u').val(id);
        $('#pfno_u').val(pfno);
        $('#fullname_u').val(fullname);
        $('#dept_u').val(dept);
        $('#cat_u').val(cat);
        $('#phoneno_u').val(phoneno);
        $('#email_u').val(email);
        $('#onlinestatus_u').val(onlinestatus);
        $('#activestatus_u').val(activestatus);
        $('#helpdesk_u').val(helpdesk);
        $('#otp_u').val(otp);
        $('#dean_u').val(dean);
        $('#hod_u').val(hod);
        $('#schexaminer_u').val(schexaminer);
        $('#pos_u').val(pos);
        $('#apu_u').val(apu);
        $('#qap_u').val(qap);
        $('#acadsec_u').val(acadsec);
        $('#acadofice_u').val(acadofice);
        $('#transcript_u').val(transcript);

    });
    </script>



    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Page-Level Scripts -->
    <script>
    $(document).ready(function() {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [{
                    extend: 'copy'
                },
                {
                    extend: 'csv'
                },
                {
                    extend: 'excel',
                    title: 'ExampleFile'
                },
                {
                    extend: 'pdf',
                    title: 'ExampleFile'
                },

                {
                    extend: 'print',
                    customize: function(win) {
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });

    });
    </script>

</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['transcript_email'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">


    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Send Transcript</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>
                            <li>
                                Send Transcript
                            </li>
                            <li class="active">
                                <strong>Original Copy</strong>
                            </li>
                        </ol>

                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Original Copy
                        </div>
                        <div class="panel-body">
                            <?php


                            $schcode = $_SESSION['schcode2'];
                            $names = $_SESSION['names'];
                            $staffid = strtoupper($_SESSION['staffid']);
                            $file_url = $msgsuces = $message = "";

                            if (isset($_POST["submit"])) {
                                $fullname = $dept = $email = "";

                                $matricno = str_replace("'", "", $_POST['matno']);
                                $matricno = filter_var(strtoupper($matricno), FILTER_SANITIZE_STRING);
                                $sql = "SELECT * FROM register WHERE matricno ='$matricno'";
                                $result = $conn9->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $fullname = $row["fullname"];
                                        $dept = $row["dept"];
                                        $email = $row["recipient_email"];
                                    }
                                }
                            }

                            if (isset($_POST['upfile_assign']) && !empty($_POST['upfile_assign'])) {
                                $matricno = $_POST['matno2'];
                                $sql = "SELECT * FROM register WHERE matricno ='$matricno'";
                                $result = $conn9->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $fullname = $row["fullname"];
                                        $dept = $row["dept"];
                                        $email = $row["recipient_email"];
                                    }
                                }

                                $fileTmpPath = $_FILES['file_assign']['tmp_name'];
                                $fileName = $_FILES['file_assign']['name'];
                                $fileSize = $_FILES['file_assign']['size'];
                                $fileType = $_FILES['file_assign']['type'];
                                $fileNameCmps = explode(".", $fileName);
                                $fileExtension = strtolower(end($fileNameCmps));


                                $fileName = str_replace("'", "''", $fileName);
                                $fileName = filter_var($fileName, FILTER_SANITIZE_STRING);
                                $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                                $newFileName = $fileName;

                                $allowedfileExtensions = array('pdf');
                                if (in_array($fileExtension, $allowedfileExtensions)) {
                                    // directory in which the uploaded file will be moved
                                    if ($fileName == str_replace("/", "_", $matricno . ".pdf")) {

                                        $uploadFileDir = "Content/transcript/original/";

                                        if (!file_exists($uploadFileDir)) {
                                            mkdir($uploadFileDir, 0777, true);
                                        }


                                        //$dest_path = $uploadFileDir . $newFileName.".".$fileExtension;
                                        $dest_path = $uploadFileDir . $newFileName;

                                        if (move_uploaded_file($fileTmpPath, $dest_path)) {
                                            //$sql = "UPDATE aaa_assignment set file_url = '$dest_path', filename = '$newFileName' WHERE ccode = '$getccode' AND session1 = '$curtsession' AND assignment_no='$assign_no'";
                                            //$result = $conn8->query($sql);
                                            //$file_url=$uploadFileDir . $newFileName.".".$fileExtension;
                                            $file_url = $uploadFileDir . $newFileName;
                                            $msgsuces = 'File is successfully uploaded.';
                                        } else {
                                            $message = 'Error in moving the file. Make sure you select correct file type.';
                                        }
                                    } else {
                                        $message = 'Error: Select file of the same Matric Number';
                                    }
                                } else {
                                    $message = 'Error: Select pdf file';
                                }
                            }


                            ?>

                            <div class="row">

                                <div class="col-lg-12  col-md-12">

                                    <div class="col-lg-12">
                                        <div class="panel panel-primary">
                                            <div class="panel-heading">
                                                Original Copy of Transcript
                                            </div>
                                            <div class="panel-body">
                                                <div class="col-lg-1 col-md-1">

                                                </div>
                                                <div class="col-lg-8 col-md-8">
                                                    <?php
                                                    if (isset($_POST["submit_email"])) {
                                                        $matricno = $_POST['matno3'];
                                                        $matricnoedit = str_replace("/", "_", $matricno);
                                                        $sql = "SELECT * FROM register WHERE matricno ='$matricno'";
                                                        $result = $conn9->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $fullname = $row["fullname"];
                                                                $dept = $row["dept"];
                                                                $email = $row["recipient_email"];
                                                            }
                                                        }
                                                        // just edit these
                                                        $to          = $email; // addresses to email pdf to
                                                        $from        = "registrar@futminna.edu.ng"; // address message is sent from
                                                        $subject     = "$fullname Transcript"; // email subject
                                                        $body        = "<p>Find attached the e-copy transcript of <b>$fullname</b>.<br>The hard copy will be sent later.</p>"; // email body
                                                        $pdfLocation = "Content/transcript/original/" . $matricnoedit . ".pdf"; // file location
                                                        $pdfName     = $matricnoedit . ".pdf"; // pdf file name recipient will get
                                                        $filetype    = "application/pdf"; // type

                                                        // creates headers and mime boundary
                                                        $eol = PHP_EOL;
                                                        $semi_rand     = md5(time());
                                                        $mime_boundary = "==Multipart_Boundary_$semi_rand";
                                                        $headers       = "From: $from$eolMIME-Version: Transcript$eol" .
                                                            "Content-Type: multipart/mixed;$eol boundary=\"$mime_boundary\"";

                                                        // add html message body
                                                        $message = "--$mime_boundary$eol" .
                                                            "Content-Type: text/html; charset=\"iso-8859-1\"$eol" .
                                                            "Content-Transfer-Encoding: 7bit$eol$eol$body$eol";

                                                        // fetches pdf
                                                        $file = fopen($pdfLocation, 'rb');
                                                        $data = fread($file, filesize($pdfLocation));
                                                        fclose($file);
                                                        $pdf = chunk_split(base64_encode($data));

                                                        // attaches pdf to email
                                                        $message .= "--$mime_boundary$eol" .
                                                            "Content-Type: $filetype;$eol name=\"$pdfName\"$eol" .
                                                            "Content-Disposition: attachment;$eol filename=\"$pdfName\"$eol" .
                                                            "Content-Transfer-Encoding: base64$eol$eol$pdf$eol--$mime_boundary--";

                                                        // Sends the email
                                                        if (mail($to, $subject, $message, $headers)) {
                                                            echo "<h4 style='color: blue'>File sent successfully</h4>";
                                                        } else {
                                                            echo "<h4 style='color: red'>Error</h4>";
                                                        }
                                                    }
                                                    ?>

                                                    <form class="form-horizontal" role="form" method="post" action="">
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label"><strong>Matric
                                                                    No:</strong></label>
                                                            <div class="col-lg-7">
                                                                <input type="text" name="matno" id="matno" class="form-control" value="">
                                                            </div>
                                                            <div class="col-lg-2">
                                                                <button type="submit" name="submit" class="btn btn-primary btn-xm">Submit</button>
                                                            </div>

                                                        </div>
                                                    </form>
                                                    <hr class="separator" />
                                                    <?php if (isset($_POST["submit"]) || isset($_POST['upfile_assign'])) { ?>
                                                        <form enctype="multipart/form-data" class="form-horizontal" action="" method="post">
                                                            <div class="form-group">
                                                                <label class="col-lg-3 control-label"><strong>Matric
                                                                        No:</strong></label>
                                                                <div class="col-lg-7">
                                                                    <input type="hidden" name="matno2" id="matno2" class="form-control" value="<?php echo $matricno ?>">
                                                                    <?php echo $matricno ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-lg-3 control-label"><strong>Name:</strong></label>
                                                                <div class="col-lg-7">
                                                                    <?php echo $fullname ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-lg-3 control-label"><strong>Department:</strong></label>
                                                                <div class="col-lg-7">
                                                                    <?php echo $dept ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-lg-3 control-label"><strong>Recipient
                                                                        Email:</strong></label>
                                                                <div class="col-lg-7">
                                                                    <?php echo $email ?>
                                                                </div>
                                                            </div>
                                                            <br><br>
                                                            <div class="form-group">
                                                                <label class="col-md-2 control-label">File Upload</label>
                                                                <div class="col-md-6">

                                                                    <div class="fileinput fileinput-new input-group" data-provides="fileinput">
                                                                        <div class="form-control" data-trigger="fileinput">
                                                                            <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                                                            <span class="fileinput-filename"></span>
                                                                        </div>
                                                                        <span class="input-group-addon btn btn-default btn-file"><span class="fileinput-new">Select
                                                                                file</span><span class="fileinput-exists">Change</span><input type="file" name="file_assign"></span>
                                                                        <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-4">
                                                                    <input type="submit" name="upfile_assign" value="Upload File" class="btn btn-primary btn-sm">
                                                                </div>
                                                            </div>
                                                        </form>
                                                        <br><br>
                                                        <?php if (isset($_POST['upfile_assign'])) { ?>

                                                            <h4 style="color: red"><?php echo $message ?></h4>
                                                            <?php if ($msgsuces !== "") { ?>
                                                                <iframe src="<?php echo $file_url ?>" width="100%" height="300px"></iframe>
                                                                <br><br>
                                                                <form class="form-horizontal" role="form" method="post" action="">
                                                                    <div class="form-group">
                                                                        <label class="col-md-2 control-label"></label>
                                                                        <div class="col-md-6">
                                                                            <input type="hidden" name="matno3" id="matno3" class="form-control" value="<?php echo $matricno ?>">

                                                                        </div>
                                                                        <div class="col-lg-4">
                                                                            <input type="submit" name="submit_email" value="Send to email" class="btn btn-primary btn-sm">
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            <?php } ?>
                                                        <?php } ?>

                                                    <?php } ?>
                                                </div>
                                                <div class="col-lg-1 col-md-1">

                                                </div>

                                            </div>
                                        </div>


                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>

</body>

</html>
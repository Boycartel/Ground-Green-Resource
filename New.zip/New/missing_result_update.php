<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">


    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>





    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>
        <?php

        $deptoption = $_SESSION['deptoption'];
        $deptname = $_SESSION["deptname"];
        $schcode = $_SESSION['schcode'];

        $deptname = $_SESSION['deptname'];
        $dept = $_SESSION['deptcode'];
        ?>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Missing Results Update</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Missing Results Update</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Missing Results Update
                        </div>
                        <div class="panel-body">
                            <div class="card">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="regid">Matric Number:</label>
                                                <div class="col-lg-7">
                                                    <input type="text" class="form-control" name="regid" required="required">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">

                                        </div>
                                    </div>
                                </form>

                            </div>
                            <hr class="separator" />
                            <?php


                            $success = "";
                            $cursession = $_SESSION['resultsession'];
                            $resultsemester = $_SESSION['resultsemester'];
                            if (isset($_POST["submitAddNew"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }
                                $regid = validate_input($_SESSION['regid']);
                                $CCode = validate_input($_POST["CCode"]);
                                $getSession = validate_input($_POST["getSession"]);
                                $getCA = validate_input($_POST["CA"]);
                                $getExam = validate_input($_POST["Exam"]);

                                $GrPoint = 0;
                                $deptoption = $_SESSION['deptoption'];
                                $Dept_Option = "NO";
                                $date1 = date("Y-m-d");
                                $GroupCode = "NO";
                                //if ($deptoption == "YES") {
                                $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                $result = $conn2->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $Dept_Option = $row["Dept_Option"];
                                        $curriculum = $row["curriculum"];
                                        $stuName = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                    }
                                }
                                //}

                                if ($deptoption == "YES") {
                                    $sql = "SELECT * FROM grouping_couses WHERE GroupCode = '$CCode' AND OptCode = '$Dept_Option'";
                                } else {
                                    $sql = "SELECT * FROM grouping_couses WHERE GroupCode = '$CCode'";
                                }
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $GroupCode = $row["GroupCode"];
                                        //$C_title=$row["C_title"];
                                    }
                                }

                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }


                                if ($curriculum == "OLD") {
                                    $curri2 = "";
                                } else {
                                    $curri2 = "_" . $curriculum;
                                }
                                $sql = "SELECT * FROM gencourses" . $curri2 . " WHERE C_codding = '$CCode'";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $credit = $row["credit"];
                                        $C_title = $row["C_title"];
                                        $CNature = $row["Nature1"];
                                        $semester = $row["semester"];
                                    }
                                }

                                $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode'";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $motherDept = $row["Department"];
                                    }
                                }

                                $repairTOTAL = $getCA + $getExam;
                                $total = $repairTOTAL;
                                include 'modulesInSess/grading_system.php';


                                $sngReCGP = $gp;
                                $semgrade = $grade;

                                $StuCurSess = str_ireplace("/", "_", $getSession);
                                $deptcorreg = "correg_" . $StuCurSess;
                                $rawresults = "raw_results_" . $StuCurSess;

                                $resRun = false;
                                //$dept_scrutiny_senate = $dept . "_scrutiny_senate";
                                $sql2 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND semester = '$resultsemester' AND session1 = '$cursession'";
                                $result2 = $conn_stu->query($sql2);
                                if ($result2->num_rows > 0) {
                                    $resRun = true;
                                }

                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$regid' AND SessionRegis = '$getSession' AND CCode = '$CCode'";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows == 0) {
                                    if ($getSession == $cursession && $semester == $resultsemester && $resRun == false) {
                                        $sql2 = "INSERT INTO " . $deptcorreg . "(Regn1, deptOption, CCode, CUnit, CTitle, SemTaken, CNature, SessionRegis, CA, Exam, grade, point, Grouping, coursecondon, noexam, date, curriculum) VALUES ('$regid', '$Dept_Option', '$CCode', '$credit', '$C_title', '$semester', '$CNature', '$getSession', '$getCA', '$getExam', '$semgrade', '$sngReCGP', '$GroupCode', 'NO', 'NO', '$date1', '$curriculum')";
                                        $result2 = $conn_stu->query($sql2);

                                        $sql2 = "SELECT * FROM " . $rawresults . " WHERE Regn1 = '$regid'";
                                        $result2 = $conn2->query($sql2);
                                        if ($result2->num_rows == 0) {
                                            $sql3 = "INSERT INTO " . $rawresults . "(CCode, SessionRegis, CA, Exam, Regn1, name1, mother_dept, stu_dept) VALUES ('$CCode', '$getSession', '$getCA', '$getExam', '$regid', '$stuName', '$motherDept', '$dept')";
                                            $result3 = $conn->query($sql3);
                                        }

                                        $success = "<h2 style='color: green'>Record Saved Successfully ...</h2>";
                                    } else {
                                        $success = "<h2 style='color: red'>Not Applicable ...</h2>";
                                    }
                                } else {
                                    $success = "<h2 style='color: red'>Record Already Exist ...</h2>";
                                }
                                $conn->close();
                                $conn2->close();
                                $conn_stu->close();
                            }


                            if (isset($_POST["update"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }
                                $id = $_POST['id'];

                                $CCode = $_POST["CCode"];
                                $getCA = $_POST["CA"];
                                $getExam = $_POST["Exam"];
                                $getSession = $_POST["session1"];
                                $GrPoint = 0;
                                $regid = $_SESSION['regid'];

                                $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                $result = $conn2->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $Dept_Option = $row["Dept_Option"];
                                        $curriculum = $row["curriculum"];
                                    }
                                }
                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                if ($curriculum == "OLD") {
                                    $curri2 = "";
                                } else {
                                    $curri2 = "_" . $curriculum;
                                }
                                $sql = "SELECT * FROM gencourses" . $curri2 . " WHERE C_codding = '$CCode'";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $credit = $row["credit"];
                                        $C_title = $row["C_title"];
                                        $CNature = $row["Nature1"];
                                        $semester = $row["semester"];
                                    }
                                }

                                $repairTOTAL = $getCA + $getExam;

                                $total = $repairTOTAL;
                                include 'modulesInSess/grading_system.php';


                                $sngReCGP = $gp;
                                $semgrade = $grade;



                                $StuCurSess = str_ireplace("/", "_", $getSession);
                                $deptcorreg = "correg_" . $StuCurSess;
                                $rawresults = "raw_results_" . $StuCurSess;

                                $sql = "UPDATE " . $deptcorreg . " SET CA ='$getCA', Exam ='$getExam', grade ='$semgrade', point ='$sngReCGP' WHERE id='$id'";
                                $result = $conn_stu->query($sql);

                                $sql = "UPDATE " . $rawresults . " SET CA ='$getCA', Exam ='$getExam' WHERE Regn1 = '$regid' AND CCode = '$CCode' AND SessionRegis = '$getSession'";
                                $result = $conn->query($sql);

                                $success = "<h2 style='color: green'>Record Update Successfully ...</h2>";
                                $conn->close();
                                $conn2->close();
                                $conn_stu->close();
                            }

                            if (isset($_POST["delete"])) {
                                $regid = $_SESSION['regid'];
                                $id = $_POST['id'];
                                $session1 = $_POST['session1'];


                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }
                                $StuCurSess = str_ireplace("/", "_", $session1);
                                $deptcorreg = "correg_" . $StuCurSess;
                                $sql = "DELETE FROM " . $deptcorreg . " WHERE id = '$id'";
                                $result = $conn_stu->query($sql);

                                $success = "<h2 style='color: green'>Record Deleted Successfully ...</h2>";
                                $conn_stu->close();
                            }

                            ?>

                            <?php if (isset($_POST["submit"]) || isset($_POST["update"]) || isset($_POST["submitAddNew"]) || isset($_POST["delete"])) { ?>
                                <?php
                                if (isset($_POST["submit"])) {
                                    $regid = $_POST["regid"];
                                    $_SESSION['regid'] = $regid;
                                } else {
                                    $regid = $_SESSION['regid'];
                                }

                                $studept = "XX";
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }
                                $cursession = $_SESSION['resultsession'];
                                $resultsemester = $_SESSION['resultsemester'];
                                //$dept = $_SESSION['deptcode'];

                                $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                $result = $conn2->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                        $entry_session = $row['entry_session'];
                                        $studept = $row['dept_code'];
                                    }
                                }

                                //echo $dept;
                                ?>
                                <div class="table-wrapper">
                                    <div class="table-title">
                                        <div class="row">

                                            <div class="col-sm-7">
                                                <h3><?php echo $regid ?> <b><?php echo $names ?></b></h3>
                                            </div>
                                            <div class="col-sm-3">
                                                <?php echo $success ?>
                                            </div>
                                            <div class="col-sm-2">
                                                <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons"></i> <span>Add New</span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap; padding:2em">
                                        <table class="table table-striped table-bordered table-hover dataTables-example">
                                            <thead>
                                                <tr>
                                                    <!--<th>
                                        <span class="custom-checkbox">
                                            <input type="checkbox" id="selectAll">
                                            <label for="selectAll"></label>
                                        </span>
                                    </th>-->
                                                    <th>S/No</th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Credit Unit</th>
                                                    <th>Semester</th>
                                                    <th>Session</th>
                                                    <!--<th>Uploaded CA</th>-->
                                                    <th>CA</th>
                                                    <!--<th>Uploaded Exam</th>-->
                                                    <th>Exam</th>
                                                    <th>Action</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                if ($studept == "XX") {
                                                    goto NoRec;
                                                }
                                                $FinalYear = (int)substr($cursession, 0, 4);
                                                $StartYear = (int)substr($entry_session, 0, 4);


                                                for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                    $x1 = $x + 1;
                                                    $TheSession = $x . "/" . $x1;

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($studept);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    $StuCurSess = str_ireplace("/", "_", $TheSession);
                                                    // $dept_scrutiny_senate = $dept . "_scrutiny_senate";
                                                    $deptcorreg = "correg_" . $StuCurSess;

                                                    $sql = "SELECT * FROM $deptcorreg WHERE Regn1 = '$regid' ORDER BY SemTaken, CCode";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $id = $row["id"];
                                                            $CCode = $row["CCode"];

                                                            $CTitle = $row["CTitle"];
                                                            $CUnit = $row["CUnit"];
                                                            $SemTaken = $row["SemTaken"];
                                                            $SessionRegis = $row["SessionRegis"];
                                                            $CA = $row["CA"];
                                                            $Exam = $row["Exam"];
                                                            $CA2 = 0;
                                                            $Exam2 = 0;
                                                            $grade = $row["grade"];

                                                            $dbsession = str_replace("/", "_", $SessionRegis);
                                                            $sql2 = "select 1 from raw_results_" . $dbsession;
                                                            $exists = $conn->query($sql2);

                                                            if ($exists == true) {
                                                                $sql2 = "SELECT * FROM  raw_results_" . $dbsession . " WHERE Regn1 = '$regid' AND CCode = '$CCode'";
                                                                $result2 = $conn->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $CA2 = $row2["CA"];
                                                                        $Exam2 = $row2["Exam"];
                                                                    }
                                                                }
                                                            }

                                                            $resRun = false;
                                                            $sql2 = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND semester = '$resultsemester' AND session1 = '$cursession'";
                                                            $result2 = $conn_stu->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                $resRun = true;
                                                            }

                                                ?>
                                                            <tr id="<?php echo $row["id"]; ?>">
                                                                <!--<td>
                                                    <span class="custom-checkbox">
                                                        <input type="checkbox" class="user_checkbox" data-user-id="<?php /*echo $row["id"]; */ ?>">
                                                        <label for="checkbox2"></label>
                                                    </span>
                                                </td>-->
                                                                <td><?php echo $sno; ?></td>
                                                                <td><?php echo $CCode; ?></td>
                                                                <td><?php echo $CTitle; ?></td>
                                                                <td><?php echo $CUnit; ?></td>
                                                                <td><?php echo $SemTaken; ?></td>
                                                                <td><?php echo $SessionRegis; ?></td>
                                                                <!--<td><?php /*echo $CA2; */ ?></td>-->
                                                                <td><?php echo $CA; ?></td>
                                                                <!--<td><?php /*echo $Exam2; */ ?></td>-->
                                                                <td><?php echo $Exam; ?></td>

                                                                <td>
                                                                    <?php //if ($TheSession == $cursession && $SemTaken == $resultsemester && $resRun == false) { 
                                                                    ?>
                                                                    <a href="#editEmployeeModal" class="edit" data-toggle="modal">
                                                                        <i class="material-icons update" data-toggle="tooltip" data-id="<?php echo $row["id"]; ?>" data-CCode="<?php echo $CCode; ?>" data-CTitle="<?php echo $CTitle; ?>" data-session1="<?php echo $SessionRegis; ?>" data-CA="<?php echo $CA; ?>" data-Exam="<?php echo $Exam; ?>" title="Edit"></i>
                                                                    </a>
                                                                    <?php
                                                                    echo '<a href="#deleteEmployeeModal" class="delete" data-id="' . $row['id'] . '" data-session1="' . $row['SessionRegis'] . '" data-CCode="' . $row['CCode'] . '"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>';
                                                                    ?>
                                                                    <!--<a href="#deleteEmployeeModal" class="delete" data-id="<?php /*echo $row["id"]; */ ?>" data-toggle="modal"><i class="material-icons" data-toggle="tooltip"
                                                                                                                                                           title="Delete"></i></a>-->
                                                                    <?php //} 
                                                                    ?>
                                                                </td>
                                                            </tr>

                                                <?php
                                                        }
                                                    }
                                                }

                                                ?>

                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                                <?php

                                $conn_stu->close();
                                NoRec:
                                $conn->close();
                                $conn2->close();
                                ?>

                            <?php } ?>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>


    <!-- Add Modal HTML -->
    <div id="addEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="user_form" action="" method="post">
                    <div class="modal-header">
                        <h4 class="modal-title">Add New</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Course Code</label>
                            <select class="form-control" style="color:#000000" id="CCode" name="CCode" required="required">
                                <option value="SelectItem">Select Item</option>
                                <?php
                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                $sql = "SELECT * FROM gencourses";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $C_codding = $row["C_codding"];
                                        $C_title = $row["C_title"];
                                        echo "<option value=$C_codding>$C_codding $C_title</option>";
                                    }
                                }
                                $conn_stu->close();
                                ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <label>Session</label>
                            <?php

                            $finalyear = substr($_SESSION['resultsession'], 5);
                            $iniyear = $finalyear - 7;
                            ?>
                            <select name="getSession" class="form-control" style="color:#000000" id="getSession" required="required">
                                <option value="SelectItem">Select Item</option>
                                <?php
                                while ($iniyear <= $finalyear) {
                                    $addyear = $iniyear + 1;

                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                    $iniyear++;
                                }

                                ?>


                            </select>
                        </div>
                        <div class="form-group">
                            <label>CA</label>
                            <input type="text" id="CA" name="CA" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Exam</label>
                            <input type="text" id="Exam" name="Exam" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" value="1" name="type">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <button type="submit" name="submitAddNew" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Edit Modal HTML -->
    <div id="editEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="update_form" action="" method="post">
                    <div class="modal-header">
                        <h4 class="modal-title">Edit Record</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="id_u" name="id" class="form-control" required>
                        <div class="form-group">
                            <label>Course Code</label>
                            <input type="text" id="CCode_u" name="CCode" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Course Title</label>
                            <input type="text" id="CTitle_u" name="CTitle" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Session</label>
                            <input type="text" id="session1_u" name="session1" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>CA</label>
                            <input type="text" id="CA_u" name="CA" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Exam</label>
                            <input type="text" id="Exam_u" name="Exam" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" value="2" name="type">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                        <!--<button type="button" class="btn btn-info" id="update">Update</button>-->
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Delete Modal HTML -->

    <div id="deleteEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- give your form an action and method -->
                <form action="" method="POST">
                    <div class="modal-header">
                        <h4 class="modal-title">Delete Record</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="session1" value="" />
                        <p>Are you sure you want to delete these Records?</p>
                        <p class="text-warning"><small>This action cannot be undone.</small></p>
                    </div>
                    <div class="modal-footer">
                        <!-- add a hidden input field to store ID for next step -->
                        <input type="hidden" name="id" value="" />
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                        <!-- change your delete link to a submit button -->
                        <button name="delete" class="btn btn-danger" type="submit">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </section>




    <script>
        $(function() {
            $('a.delete').click(function(e) {
                e.preventDefault();
                var link = this;
                var deleteModal = $("#deleteEmployeeModal");
                // store the ID inside the modal's form
                deleteModal.find('input[name=session1]').val(link.dataset.session1);
                deleteModal.find('input[name=id]').val(link.dataset.id);
                // open modal
                deleteModal.modal();
            });
        });
    </script>

    <script>
        $(document).on('click', '.update', function(e) {


            var id = $(this).attr("data-id");
            var CCode = $(this).attr("data-CCode");
            var CTitle = $(this).attr("data-CTitle");
            var session1 = $(this).attr("data-session1");
            var CA = $(this).attr("data-CA");
            var Exam = $(this).attr("data-Exam");
            $('#id_u').val(id);
            $('#CCode_u').val(CCode);
            $('#CTitle_u').val(CTitle);
            $('#session1_u').val(session1);
            $('#CA_u').val(CA);
            $('#Exam_u').val(Exam);
        });
    </script>


    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {
            $('.dataTables-example').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [{
                        extend: 'copy'
                    },
                    {
                        extend: 'csv'
                    },
                    {
                        extend: 'excel',
                        title: 'ExampleFile'
                    },
                    {
                        extend: 'pdf',
                        title: 'ExampleFile'
                    },

                    {
                        extend: 'print',
                        customize: function(win) {
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                        }
                    }
                ]

            });

        });
    </script>
</body>

</html>
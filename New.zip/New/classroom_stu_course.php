<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$usernames = $_SESSION['names'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
//$stdid = $_SESSION['stdid'];
//$mystdid = $_SESSION['stdid'];
$dept = strtoupper($_SESSION['deptcode']);
$regid = $_SESSION["regid"];
$myregid = $_SESSION["regid"];
$email = $_SESSION['email'];

?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">

    <!-- Calendar -->


    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php
                            if ($_SESSION['progtype'] == "UG") {
                                //$stdid = $_SESSION['stdid'];
                                //$dept=$_SESSION['deptcode'];
                                $sql = "SELECT image FROM std_pictures WHERE matric_no='$regid'";
                                $sth = $conn2->query($sql);
                                $result2 = mysqli_fetch_array($sth);

                                echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['image']) . '"  width="50" height="50"/>';
                                //echo "<img src='https://eportal.futminna.edu.ng/rpport/passport_".$_SESSION['stdid'].".jpg' alt='$usernames' class='img-circle' width='50' height='50' data-lock-picture='https://eportal.futminna.edu.ng/rpport/passport_".$_SESSION['stdid'].".jpg' />";
                            } else {
                                //echo "<img src='https://eportal.futminna.edu.ng/pg/uploads/" . $_SESSION['stdid'] . "_passport.jpg' alt='$usernames' class='img-circle' width='50' height='50' data-lock-picture='https://eportal.futminna.edu.ng/rpport/passport_" . $_SESSION['stdid'] . ".jpg' />";
                            }

                            ?>
                        </figure>
                        <div class="profile-info" data-lock-name="<?php echo $regid ?>" data-lock-email="<?php echo $email ?>">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $regid  ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_stu.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>
                            <!--<li>
									<a role="menuitem" tabindex="-1" href="lock_screen_stu.php" data-lock-screen="true"><i class="fa fa-lock"></i> Lock Screen</a>
								</li>-->



                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_class.php'; ?>
            <!-- end: sidebar -->
            <?php

            if (isset($_POST["view_course"])) {
                $ccode = $_POST["getccode"];
                $_SESSION["ccode"] = $ccode;
            } else {
                $ccode = $_SESSION["ccode"];
            }

            ?>
            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>">
                    <h2><?php echo $ccode . ", " . $curtsession ?> </h2>

                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="classroom_stu_start.php">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li>

                                <form class="form-horizontal bucket-form" method="Post">

                                    <input type="submit" value="Classroom" name="submit_class" class='btn btn-primary btn-xs'>
                                </form>
                            </li>
                        </ol>

                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">

                            <div class="nano">
                                <div class="form-group" style="padding-left: 1em; padding-right: 1em">
                                    <?php

                                    $course_note_url = "classroom/course_note/" . $ccode . ".pdf";
                                    ?>
                                    <div class="widget-header clearfix">

                                    </div>

                                </div>
                                <div class="nano-content">

                                    <div class="inner-menu-toggle-inside">
                                        <a href="#" class="inner-menu-collapse">
                                            <i class="fa fa-chevron-up visible-xs-inline"></i><i class="fa fa-chevron-left hidden-xs-inline"></i> Hide Bar
                                        </a>
                                        <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                            Show Bar <i class="fa fa-chevron-down"></i>
                                        </a>
                                    </div>

                                    <div class="inner-menu-content">
                                        <h4 style="text-align: center;">Calendar</h4>
                                        <div data-plugin-datepicker data-plugin-skin="dark"></div>


                                        <div class="sidebar-widget widget-friends">
                                            <h3>Assignment(s)</h3>
                                            <table>
                                                <tbody>
                                                    <ul>
                                                        <?php
                                                        $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$ccode' AND session1 = '$curtsession'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $id = $row["id"];
                                                                $assign_status = $row["status"];
                                                                $assign_no1 = $row["assignment_no"];
                                                                $sub_date = $row["deadline"];

                                                                if ($assign_status == "open") {
                                                                    $assign_status2 = "Open";
                                                                } else {
                                                                    $assign_status2 = "Closed";
                                                                }

                                                                $sub_date2 = date_format(date_create($sub_date), "d/m/Y");
                                                        ?>


                                                                <tr>
                                                                    <td><img src="classroom/images/folder.png" alt="" class="img-circle" height="30px" width="30px">

                                                                    </td>
                                                                    <td>
                                                                        <?php
                                                                        if ($assign_no1 == 1) {
                                                                            echo "<span class='name'>1<sup>st</sup> Assignment</span>";
                                                                        } elseif ($assign_no1 == 2) {
                                                                            echo "<span class='name'>2<sup>nd</sup> Assignment</span>";
                                                                        } else {
                                                                            echo "<span class='name'>3<sup>rd</sup> Assignment</span>";
                                                                        }
                                                                        ?>
                                                                    </td>


                                                                </tr>
                                                                <tr>
                                                                    <td style="padding-right:1em">
                                                                        <time>Deadline: </time>
                                                                    </td>
                                                                    <td><time datetime="2014-04-19T00:00+00:00"><?php echo $sub_date2 ?></time>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="padding-right:1em">
                                                                        <time>Status: </time>
                                                                    </td>
                                                                    <td>
                                                                        <time><?php echo $assign_status2 ?></time>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="padding-bottom: 2em; padding-right:1em">

                                                                    </td>
                                                                    <td style="padding-bottom: 2em;">
                                                                        <form class="form-horizontal bucket-form" method="Post" action="classroom_view_assign_stu.php">
                                                                            <input type='hidden' value='<?php echo $id ?>' name='id'>
                                                                            <input type="submit" value="View" name="view_assessment2" class='btn btn-success btn-xs'>

                                                                        </form>
                                                                    </td>
                                                                </tr>


                                                        <?php
                                                            }
                                                        }
                                                        ?>


                                                    </ul>
                                                </tbody>
                                            </table>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">
                            <?php
                            $ccode = $_SESSION["ccode"];
                            $sql = "SELECT *  FROM gencoursesupload WHERE C_codding = '$ccode'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $getctitle = $row["C_title"];
                                    $credit = $row["credit"];
                                    $semester = $row["semester"];
                                    $totStu = $row["totStu"];
                                    $Descriptn = $row["Descriptn"];
                                    $venue = $row["venue"];
                                    $course_objective = $row["course_objective"];
                                    $lecture_outcome = $row["lecture_outcome"];
                                    $lecture_delivery = $row["lecture_delivery"];
                                    $evalu_method = $row["evalu_method"];

                                    $evalu_method = $row["evalu_method"];
                                    $refmaterial1 = $row["refmaterial1"];
                                    $refmaterial2 = $row["refmaterial2"];
                                    $refmaterial3 = $row["refmaterial3"];
                                    $refmaterial4 = $row["refmaterial4"];
                                    $refmaterial5 = $row["refmaterial5"];
                                    $refmaterial6 = $row["refmaterial6"];
                                    $refmaterial7 = $row["refmaterial7"];
                                    $refmaterial8 = $row["refmaterial8"];
                                    $refmaterial9 = $row["refmaterial9"];
                                    $refmaterial10 = $row["refmaterial10"];
                                }
                            }


                            ?>
                            <div class="inner-toolbar clearfix" style="color:#ffffff">
                                <ul>

                                    <li>

                                        <?php echo $ccode . "  " . $getctitle ?>
                                    </li>
                                    <li>

                                    </li>
                                    <li class="right">

                                        <ul class="nav nav-pills nav-pills-primary">

                                            <li>
                                                <form class="form-horizontal form-bordered" method="post" action="classroom_stu.php">

                                                    <input type='hidden' value='<?php echo $ccode ?>' name='getccode'>
                                                    <input type="submit" value="Course Forum & Chats" name="submit_ccode" class='btn btn-primary btn-xm'>
                                                </form>
                                            </li>

                                            <li>

                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>



                            <div class="row">
                                <div class="col-md-12">
                                    <section class="panel">
                                        <div class="panel-body">

                                            <div class="row" style="background-color:ghostwhite;">
                                                <div class="col-md-5">

                                                    <h2 style="color: #663399;"><?php echo $ccode . "  " . $getctitle ?>
                                                    </h2>
                                                    <div class="progress light m-md">
                                                        <?php
                                                        $countcomp = 0;
                                                        $countnotcomp = 0;
                                                        $sql = "SELECT *  FROM aaa_course_topic WHERE ccode = '$ccode'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {

                                                                $delivered = $row["delivered"];
                                                                if ($delivered == "YES") {
                                                                    $countcomp++;
                                                                } else {
                                                                    $countnotcomp++;
                                                                }
                                                            }
                                                        }
                                                        $perct = round(($countcomp / ($countcomp + $countnotcomp)) * 100);
                                                        ?>
                                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $perct ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $perct ?>%;">
                                                            <?php echo $perct ?>% Complete
                                                        </div>
                                                    </div>
                                                    <h3><a href="<?php echo $course_note_url ?>" target="_blank"><img src="assets/images/pdf_icon.png" width="40" height="40">
                                                            Click to Download <?php echo $ccode ?> Course Content</a>
                                                    </h3>



                                                    <h3>Course Lecturer(s)</h3>
                                                    <table class="table mb-none">
                                                        <tbody>
                                                            <thead>
                                                                <th>Name</th>
                                                                <th>Phone</th>
                                                            </thead>
                                                            <?php
                                                            $sql2 = "SELECT * FROM coursealocation WHERE SessionReg='$curtsession' AND CCode='$ccode'";
                                                            $result2 = $conn->query($sql2);

                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $PFNo = $row2["PFNo"];
                                                                    $sql3 = "SELECT * FROM users WHERE staffid='$PFNo'";
                                                                    if ($_SESSION['progtype'] == "UG") {
                                                                        $result3 = $conn->query($sql3);
                                                                    } else {
                                                                        $result3 = $conn5->query($sql3);
                                                                    }

                                                                    if ($result3->num_rows > 0) {
                                                                        while ($row3 = $result3->fetch_assoc()) {
                                                                            $otherstffdept = $row3["department"];
                                                                            $full_name = $row3["full_name"];
                                                                            $phone = $row3["phone"];
                                                                            echo "<tr><td>$full_name</td><td>$phone</td></tr>";
                                                                        }
                                                                    }
                                                                }
                                                            }


                                                            ?>
                                                        </tbody>
                                                    </table>

                                                </div>
                                                <div class="col-md-7" style="padding-right: 1em;">
                                                    <table class="table mb-none">
                                                        <thead>
                                                            <tr style="background-color: <?php echo $_SESSION['sch_color'] ?>; color:#ffffff">
                                                                <th>Day</th>
                                                                <th>8:00AM</th>
                                                                <th>9:00AM</th>
                                                                <th>10:00AM</th>
                                                                <th>11:00AM</th>
                                                                <th>12:00PM</th>
                                                                <th>1:00PM</th>
                                                                <th>2:00PM</th>
                                                                <th>3:00PM</th>
                                                                <th>4:00PM</th>
                                                                <th>5:00PM</th>
                                                                <th>6:00PM</th>

                                                            </tr>
                                                        </thead>
                                                        <?php
                                                        $getday = date('D');
                                                        if ($getday == "Mon") {
                                                            $getday = "M";
                                                        } elseif ($getday == "Tue") {
                                                            $getday = "T";
                                                        } elseif ($getday == "Wed") {
                                                            $getday = "W";
                                                        } elseif ($getday == "Thu") {
                                                            $getday = "Th";
                                                        } elseif ($getday == "Fri") {
                                                            $getday = "F";
                                                        } elseif ($getday == "Sat") {
                                                            $getday = "S";
                                                        }

                                                        $x = 0;
                                                        $ccodearry2[] = "";
                                                        $corntsession2 = str_replace("/", "_", $curtsession);
                                                        $sql2 = "SELECT CCode FROM courses_register_" . $corntsession2 . " WHERE Regn1 = '$regid' AND SemTaken = '$cursemester'";
                                                        $result2 = $conn->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $ccodearry2[$x] = $row2['CCode'];
                                                                $x++;
                                                            }
                                                        }
                                                        ?>
                                                        <tbody>
                                                            <?php if ($getday == "M") { ?>
                                                                <tr style=" background-color: #9d33d6; color: #ffffff">
                                                                <?php } else { ?>
                                                                <tr>
                                                                <?php } ?>

                                                                <th>Mon</th>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '8AM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '9AM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '10AM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '11AM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '12PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '1PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '2PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '3PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '4PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '5PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '6PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . "hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>

                                                                </tr>
                                                                <?php if ($getday == "T") { ?>
                                                                    <tr style=" background-color: #9d33d6; color: #ffffff">
                                                                    <?php } else { ?>
                                                                    <tr>
                                                                    <?php } ?>
                                                                    <th>Tue</th>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '8AM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '9AM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '10AM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '11AM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '12PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '1PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '2PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '3PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '4PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '5PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '6PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . "hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>

                                                                    </tr>
                                                                    <?php if ($getday == "W") { ?>
                                                                        <tr style=" background-color: #9d33d6; color: #ffffff">
                                                                        <?php } else { ?>
                                                                        <tr>
                                                                        <?php } ?>
                                                                        <th>Wed</th>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '8AM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '9AM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '10AM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '11AM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '12PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '1PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '2PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '3PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '4PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '5PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '6PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . "hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>

                                                                        </tr>
                                                                        <?php if ($getday == "Th") { ?>
                                                                            <tr style=" background-color: <?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                            <?php } else { ?>
                                                                            <tr>
                                                                            <?php } ?>
                                                                            <th>Thur</th>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '8AM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '9AM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '10AM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '11AM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '12PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '1PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '2PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '3PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '4PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '5PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '6PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . "hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>

                                                                            </tr>
                                                                            <?php if ($getday == "F") { ?>
                                                                                <tr style=" background-color: <?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                                <?php } else { ?>
                                                                                <tr>
                                                                                <?php } ?>
                                                                                <th>Fri</th>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '8AM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '9AM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '10AM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '11AM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '12PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '1PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '2PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '3PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '4PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '5PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '6PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . "hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>

                                                                                </tr>
                                                                                <?php if ($getday == "S") { ?>
                                                                                    <tr style=" background-color: <?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                                    <?php } else { ?>
                                                                                    <tr>
                                                                                    <?php } ?>
                                                                                    <th>Sat</th>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '8AM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '9AM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '10AM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '11AM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '12PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '1PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '2PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '3PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '4PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '5PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '6PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . "hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>

                                                                                    </tr>
                                                        </tbody>
                                                        <tfoot>
                                                            <tr style="background-color: <?php echo $_SESSION['sch_color'] ?>; color:#ffffff">
                                                                <th>Day</th>
                                                                <th>8:00AM</th>
                                                                <th>9:00AM</th>
                                                                <th>10:00AM</th>
                                                                <th>11:00AM</th>
                                                                <th>12:00PM</th>
                                                                <th>1:00PM</th>
                                                                <th>2:00PM</th>
                                                                <th>3:00PM</th>
                                                                <th>4:00PM</th>
                                                                <th>5:00PM</th>
                                                                <th>6:00PM</th>

                                                            </tr>
                                                        </tfoot>
                                                    </table>

                                                </div>
                                            </div>
                                            <hr>
                                            <p style="color: black;"><b>Credit Unit:</b> <?php echo $credit ?></p>
                                            <p><b>Semester:</b> <?php echo $semester ?></p>
                                            <p><b>Registered Students:</b> <?php echo number_format($totStu, 0) ?>
                                            </p>
                                            <p><b>Description:</b> <?php echo $Descriptn ?></p>
                                            <br>
                                            <p><b>Course Objective:</b> <?php echo $course_objective ?></p>
                                            <p><b>Lecture Outcome:</b> <?php echo $lecture_outcome ?></p>
                                            <p><b>Lecture Delivery:</b> <?php echo $lecture_delivery ?></p>
                                            <p><b>Evaluation Method:</b> <?php echo $evalu_method ?></p>
                                            <br>
                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Topic</th>
                                                        <th>Video Lecture</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $snot = 0;
                                                    $sql = "SELECT *  FROM aaa_course_topic WHERE ccode = '$ccode'";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $snot++;
                                                            $cvideoid = $row["id"];
                                                            $course_video_url = "classroom/video_note/" . $cvideoid . ".MP4";
                                                            $topics = $row["topics"];
                                                            $delivered = $row["delivered"];
                                                            if ($delivered == "YES") {
                                                                $status1 = "Completed";
                                                            } else {
                                                                $status1 = "Not Completed";
                                                            }
                                                            echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$topics</td><td>";
                                                            echo "<video width='160' controls>
                                <source src='$course_video_url' type='video/mp4'>
                                
                                Your browser does not support HTML video.
                            </video>";
                                                            echo "</td>
                                                    <td>$status1</td>
                                                    </tr>";
                                                        }
                                                    }
                                                    ?>

                                                </tbody>
                                            </table>
                                            <hr>
                                            <h3 style="text-align: center;">References/Further Reading</h3>
                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>References Area</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $snot = 0;
                                                    if (strlen($refmaterial1) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial1</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial2) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial2</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial3) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial3</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial4) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial4</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial5) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial5</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial6) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial6</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial7) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial7</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial8) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial8</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial9) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial9</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial10) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial10</td></tr</n>";
                                                    }

                                                    ?>

                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="panel-footer">
                                            <?php echo $ccode . "  " . $getctitle ?>
                                        </div>
                                    </section>
                                </div>
                            </div>






                        </div>
                    </div>
                </section>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>


    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>


</body>

</html>
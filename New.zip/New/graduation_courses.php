<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_edit'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php';
    ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_D.js"> </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<?php
$staffid = $_SESSION['staffid'];
?>

<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Graduation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Graduation
                            </li>

                            <li class="active">
                                <strong>List by Course</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            List by Course
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal bucket-form" method="post" action="">
                                <div class="row">
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Session Course Taken:</label>
                                            <div class="col-sm-7">
                                                <select class="scale form-control m-bot15" name="sessiontaken"
                                                    required="required">
                                                    <option></option>
                                                    <?php
                                                    $finalyear = substr($_SESSION['resultsession'], 0, 4);
                                                    for ($x = 2015; $x <= $finalyear; $x++) {
                                                        $x2 = $x + 1;
                                                    ?>
                                                    <option><?php echo $x . "/" . $x2; ?></option>

                                                    <?php } ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Courses: </label>
                                            <div class="col-sm-7">
                                                <select class="state form-control m-bot15" name="courses"
                                                    required="required">
                                                    <option></option>
                                                    <?php
                                                    $sql = "SELECT * FROM gencoursesupload ORDER BY C_codding";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $C_codding = $row["C_codding"];
                                                            $C_title = $row["C_title"];
                                                            echo "<option value=$C_codding>$C_codding    $C_title</option>";
                                                        }
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-sm-2 col-xs-12">
                                        <div class="form-group">

                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Session of Graduation:</label>
                                            <div class="col-sm-7">
                                                <select class="scale form-control m-bot15" name="sessiongrad"
                                                    required="required">
                                                    <option></option>
                                                    <?php
                                                    $finalyear = substr($_SESSION['resultsession'], 0, 4);
                                                    for ($x = 2018; $x <= $finalyear; $x++) {
                                                        $x2 = $x + 1;
                                                    ?>
                                                    <option><?php echo $x . "/" . $x2; ?></option>

                                                    <?php } ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Semester of Graduation: </label>
                                            <div class="col-sm-7">
                                                <select class="state form-control m-bot15" name="semester"
                                                    required="required">
                                                    <option></option>
                                                    <option value='1ST'>1ST</option>
                                                    <option value='2ND'>2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 col-sm-2 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label"></label>
                                            <div class="col-sm-7">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </form>

                            <?php
                            //for ($i = 1; $i <= 10000; $i++) {
                            //echo addOrdinalNumberSuffix($i) . "\t";
                            //if ($i % 10 == 0) {
                            //echo "\n";
                            //}
                            //}

                            if (isset($_POST["submit"])) {
                                set_time_limit(5000);
                            ?>
                            <table id="myTable" style="font-size:12px" summary="" rules="groups" frame="hsides"
                                class="table mb-none" border="2">
                                <caption>Students List</caption>
                                <colgroup align="left"></colgroup>
                                <colgroup align="left"></colgroup>
                                <colgroup span="2"></colgroup>
                                <colgroup span="3" align="left"></colgroup>
                                <thead style='text-align:center'>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Matric No.</th>
                                        <th>Name</th>
                                        <th>Gender</th>
                                        <th>Parmenant Hone Address</th>
                                        <th>Department</th>
                                        <th>State of Origin</th>
                                        <th>LGA</th>
                                        <th>Programme</th>
                                        <th>Date of Birth</th>
                                        <th>Year of Graduation</th>
                                        <th>Session Graduate</th>
                                        <th>CGPA</th>
                                        <th>Course Code</th>
                                        <th>Total</th>
                                        <th>Position</th>
                                        <th>Class of Degree</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $sno = 0;
                                        $classdegree = "";
                                        $position = 0;
                                        $position2 = "";
                                        $cgpa = 0;
                                        $totalprev = 100;
                                        $nullposition = 0;

                                        $sessiontakenpost = $_POST["sessiontaken"];
                                        $sessiongradpost = $_POST["sessiongrad"];
                                        $coursespost = $_POST["courses"];
                                        $semesterpost = $_POST["semester"];




                                        $StuCurSess = str_ireplace("/", "_", $sessiontakenpost);
                                        $deptcorreg = "raw_results_" . $StuCurSess;
                                        //$sql2 = "SELECT * FROM " . $deptcorreg . " WHERE CCode = '$coursespost' AND stu_dept = 'MAT'";
                                        $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE CCode = '$coursespost'";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $id = $row2["sn"];
                                                $CA = $row2["CA"];
                                                $Exam = $row2["Exam"];

                                                $total = $CA + $Exam;
                                                $sql = "UPDATE " . $deptcorreg . " SET total ='$total' WHERE sn='$id'";
                                                $result = $conn->query($sql);
                                            }
                                        }

                                        $StuCurSess = str_ireplace("/", "_", $sessiontakenpost);
                                        $deptcorreg = "raw_results_" . $StuCurSess;
                                        //$sql3 = "SELECT * FROM " . $deptcorreg . " WHERE CCode = '$coursespost' AND stu_dept = 'MAT' ORDER BY total DESC";
                                        $sql3 = "SELECT * FROM " . $deptcorreg . " WHERE CCode = '$coursespost' ORDER BY total DESC";
                                        $result3 = $conn->query($sql3);
                                        if ($result3->num_rows > 0) {
                                            while ($row3 = $result3->fetch_assoc()) {
                                                $matno = $row3["Regn1"];
                                                $DeptCode = strtolower($row3["stu_dept"]);
                                                //$CA = $row3["CA"];
                                                //$Exam = $row3["Exam"];

                                                $total = $row3["total"];



                                                $dept_db = $_SESSION['deptdb'] . strtolower($DeptCode);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }
                                                $sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND graduated = 'YES' AND session1 = '$sessiongradpost' AND semester = '$semesterpost'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {

                                                        $sno++;
                                                        $Name_full = $row["Name1"];
                                                        $Sex = $row["sex"];
                                                        $ParmtAdress = $row["p_address"];
                                                        $YAddmitted = $row["yearadmt"];
                                                        //$Department = $row["Department"];
                                                        $stateOfOrigin = $row["stateOfOrigin"];
                                                        $LGA = $row["lga"];
                                                        $programme = $row["progfull"];
                                                        $dob = $row["dob"];
                                                        $yearGrd = $row["yearGrad"];
                                                        $session = $row["session1"];
                                                        $cgpa = number_format((float)$row["CGPA"], 2, '.', '');

                                                        //$nextposition=$nextposition+1;
                                                        if ($totalprev == $total) {
                                                            $position = $position;
                                                            $nullposition++;
                                                        } else {
                                                            $position = $position + 1;
                                                            $position = $position + $nullposition;
                                                            $nullposition = 0;
                                                        }


                                                        $classdegree = $row["classdegree"];


                                                        $totalprev = $total;
                                                        $position2 = addOrdinalNumberSuffix($position);
                                                    }
                                                    echo "<tr><td>$sno</td><td>$matno</td><td>$Name_full</td><td>$Sex</td><td>$ParmtAdress</td><td>$DeptCode</td><td>$stateOfOrigin</td><td>$LGA</td><td>$programme</td><td>$dob</td><td>$yearGrd</td><td>$session</td><td>$cgpa</td><td>$coursespost</td><td>$total</td><td>$position2</td><td>$classdegree</td></tr>\n";
                                                }
                                                $conn_stu->close();
                                            }
                                        }



                                        echo "</tbody>";
                                        echo "</table>";

                                        //$sql = "DELETE FROM temptcourse WHERE users = '$staffid'";
                                        //$result = $conn->query($sql);

                                        ?>
                                    <br><br>
                                    <div class="form-group">
                                        <!-- Buttons -->
                                        <div class="col-lg-offset-2 col-lg-9" style="text-align: right;">
                                            <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                                class="btn btn-primary">Download</a>
                                        </div>
                                    </div>

                                    <?php
                                }    //End Submit
                                    ?>


                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>
        <?php

        function addOrdinalNumberSuffix($num)
        {
            if (!in_array(($num % 100), array(11, 12, 13))) {
                switch ($num % 10) {
                        // Handle 1st, 2nd, 3rd
                    case 1:
                        return $num . '<sup>st</sup>';
                    case 2:
                        return $num . '<sup>nd</sup>';
                    case 3:
                        return $num . '<sup>rd</sup>';
                }
            }
            return $num . '<sup>th</sup>';
        }

        ?>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php
        include_once 'includes/header2_pg.php';
        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/pg_aside_menu.php';
            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Course Registration</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="stu_course_reg.php">
                                    <i class="fa fa-list"></i>
                                </a>
                            </li>
                            <li><span>Course Reg.</span></li>
                            <li><span>Course Registration</span></li>
                            <li><span>Course Reg Preview</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">

                    <div class="col-md-1">
                    </div>
                    <div class="col-md-10">
                        <section class="panel panel-success">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">Confirm to Submit</h2>
                            </header>
                            <div class="panel-body">
                                <?php echo $regid ?>
                                <form class="form-horizontal" role="form" method="post" action="pg_course_reg_subt.php">
                                    <table class="table mb-none">
                                        <thead>
                                            <tr>
                                                <th>Course Code</th>
                                                <th>Course Title</th>
                                                <th>Unit</th>
                                                <th>Semester</th>
                                                <th>Nature</th>

                                            </tr>
                                        </thead>
                                        <tbody>


                                            <?php
                                            //if ($level == "400P"){
                                            //											$level = "400";	
                                            //										}
                                            $ccode2c = $CTitle2c = $CUnit2c = $SemTaken2c = $Nature2c = "";
                                            $ccode1c = $CTitle1c = $CUnit1c = $SemTaken1c = $Nature1c = "";
                                            $ccode = $CTitle = $CUnit = $SemTaken = $Nature = "";
                                            $stopit = "No";
                                            $countrepcourse = 0;
                                            //$get4lcourse = "";

                                            //$regid = $_SESSION["regid"];
                                            // sql to delete a record
                                            $sql = "DELETE FROM coursesregis WHERE Regn1 ='$regid'";
                                            $result = $conn->query($sql);

                                            $sum1st = $sum2nd = 0;


                                            if (!empty($_POST["chosen1c"])) {
                                                foreach ($_POST["chosen1c"] as $key => $value) {

                                                    //echo $_POST["chosen"][$key];

                                                    $ccode1c = $_POST["ccodec1"][$key];
                                                    $CTitle1c = str_replace("'", "''", $_POST["CTitlec1"][$key]);
                                                    $CUnit1c = $_POST["CUnitc1"][$key];
                                                    $SemTaken1c = $_POST["SemTakenc1"][$key];
                                                    $Nature1c = $_POST["Naturec1"][$key];

                                                    $sum1st += $CUnit1c;
                                                    echo "<tr><td>$ccode1c</td><td>$CTitle1c</td><td>$CUnit1c</td><td>$SemTaken1c</td><td>$Nature1c</td></tr>\n";
                                                    // sql to insert record
                                                    $sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode1c', '$CUnit1c', '$CTitle1c', '$SemTaken1c', '$Nature1c')";
                                                    $result = $conn->query($sql);
                                                }
                                            }

                                            //$array = $_POST["chosen"];
                                            if (!empty($_POST["chosen"])) {
                                                foreach ($_POST["chosen"] as $key => $value) {

                                                    $ccode = $_POST["ccode1"][$key];
                                                    $CTitle = str_replace("'", "''", $_POST["CTitle1"][$key]);
                                                    $CUnit = $_POST["CUnit1"][$key];
                                                    $SemTaken = $_POST["SemTaken1"][$key];
                                                    $Nature = $_POST["Nature1"][$key];

                                                    //$sum1st += $CUnit;
                                                    $sum1st += $CUnit;
                                                    echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td></tr>\n";
                                                    $sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature')";

                                                    $result = $conn->query($sql);
                                                }
                                            }


                                            if (!empty($_POST["chosenadd"])) {
                                                foreach ($_POST["chosenadd"] as $key => $value) {

                                                    $ccode = $_POST["ccode1"][$key];
                                                    $CTitle = str_replace("'", "''", $_POST["CTitle1"][$key]);
                                                    $CUnit = $_POST["CUnit1"][$key];
                                                    $SemTaken = $_POST["SemTaken1"][$key];
                                                    $Nature = $_POST["Nature1"][$key];


                                                    $sum1st += $CUnit;
                                                    echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td></tr>\n";
                                                    $sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature')";
                                                    $result = $conn->query($sql);
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                    <br>
                                    <?php

                                    echo "<center> Total Credit Units : $sum1st</center>";
                                    ?>

                                    <?php

                                    if ($sum1st > 24) {
                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of 24 Unit per semester</center></strong>";
                                        $stopit = "Yes";
                                    }



                                    ?>
                                    <br /><br>
                                    <table class="table mb-none">
                                        <thead>
                                            <tr>
                                                <th>Course Code</th>
                                                <th>Course Title</th>
                                                <th>Unit</th>
                                                <th>Semester</th>
                                                <th>Nature</th>

                                            </tr>
                                        </thead>
                                        <tbody>


                                            <?php
                                            if (!empty($_POST["chosen2c"])) {
                                                foreach ($_POST["chosen2c"] as $key => $value) {

                                                    //echo $_POST["chosen"][$key];

                                                    $ccode2c = $_POST["ccodec2"][$key];
                                                    $CTitle2c = str_replace("'", "''", $_POST["CTitlec2"][$key]);
                                                    $CUnit2c = $_POST["CUnitc2"][$key];
                                                    $SemTaken2c = $_POST["SemTakenc2"][$key];
                                                    $Nature2c = $_POST["Naturec2"][$key];

                                                    if ($countrepcourse == 0) {
                                                        $sum2nd += $CUnit2c;
                                                        echo "<tr><td>$ccode2c</td><td>$CTitle2c</td><td>$CUnit2c</td><td>$SemTaken2c</td><td>$Nature2c</td></tr>\n";
                                                        // sql to insert record
                                                        $sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode2c', '$CUnit2c', '$CTitle2c', '$SemTaken2c', '$Nature2c')";
                                                        $result = $conn->query($sql);
                                                    }
                                                }
                                            }

                                            if (!empty($_POST["chosen2"])) {
                                                foreach ($_POST["chosen2"] as $key => $value) {

                                                    //echo $_POST["chosen"][$key];

                                                    $ccode2 = $_POST["ccode2"][$key];
                                                    $CTitle2 = str_replace("'", "''", $_POST["CTitle2"][$key]);
                                                    $CUnit2 = $_POST["CUnit2"][$key];
                                                    $SemTaken2 = $_POST["SemTaken2"][$key];
                                                    $Nature2 = $_POST["Nature2"][$key];

                                                    if ($countrepcourse == 0) {
                                                        $sum2nd += $CUnit2;
                                                        echo "<tr><td>$ccode2</td><td>$CTitle2</td><td>$CUnit2</td><td>$SemTaken2</td><td>$Nature2</td></tr>\n";
                                                        $sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode2', '$CUnit2', '$CTitle2', '$SemTaken2', '$Nature2')";
                                                        $result = $conn->query($sql);
                                                    }
                                                }
                                            }

                                            if (!empty($_POST["chosenadd2"])) {
                                                foreach ($_POST["chosenadd2"] as $key => $value) {

                                                    //echo $_POST["chosen"][$key];

                                                    $ccode2 = $_POST["ccode2"][$key];
                                                    $CTitle2 = str_replace("'", "''", $_POST["CTitle2"][$key]);
                                                    $CUnit2 = $_POST["CUnit2"][$key];
                                                    $SemTaken2 = $_POST["SemTaken2"][$key];
                                                    $Nature2 = $_POST["Nature2"][$key];

                                                    if ($countrepcourse == 0) {
                                                        $sum2nd += $CUnit2;
                                                        echo "<tr><td>$ccode2</td><td>$CTitle2</td><td>$CUnit2</td><td>$SemTaken2</td><td>$Nature2</td></tr>\n";
                                                        // sql to insert record
                                                        $sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode2', '$CUnit2', '$CTitle2', '$SemTaken2', '$Nature2')";
                                                        $result = $conn->query($sql);
                                                    }
                                                }
                                            }

                                            ?>
                                        </tbody>
                                    </table>
                                    <br>
                                    <?php
                                    echo "<center> Total Credit Units : $sum2nd</center>";
                                    ?>

                                    <?php

                                    if ($sum2nd > 24) {
                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of 24 Unit per semester</center></strong>";
                                        $stopit = "Yes";
                                    }
                                    //$conn->close();
                                    ?>

                                    <br>
                                    <?php
                                    if ($stopit !== "Yes") {
                                    ?>
                                        <div class="col-lg-12 col-md-12" style="text-align:right">
                                            <button type="submit" name="submit2" class="btn btn-primary">Submit</button>

                                        </div>
                                    <?php
                                    }
                                    ?>
                                </form>

                            </div>
                        </section>

                    </div>
                    <div class="col-md-1">
                    </div>

                </div>

                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
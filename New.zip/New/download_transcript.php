<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['download_stu_biodata'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_Trasc.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php

    $resultsession = $_SESSION['resultsession'];
    $resultsemester = $_SESSION['resultsemester']
    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Download Transcript e-Copy</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Download
                            </li>

                            <li class="active">
                                <strong>Download Transcript e-Copy</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }
?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Download Transcript e-Copy
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form class="form-horizontal" method="post">

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-7">
                                                <select class="form-control" style="color:#000000" name="downloaddept"
                                                    required>
                                                    <option value="">Select Item</option>
                                                    <?php
                                                    //$cat = $_SESSION['cat'];
                                                    $dept = $_SESSION['deptcode'];

                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = strtolower($row["DeptCode"]);
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">
                                            <?php
                                            $finalyear = substr($_SESSION['resultsession'], 5) + 1;
                                            ?>
                                            <label class="control-label col-lg-5" for="regid">Year Graduated:</label>
                                            <div class="col-lg-7">
                                                <select name="getyearGrad" class="form-control" style="color:#000000"
                                                    id="getyearGrad">
                                                    <option value="<?php echo $finalyear ?>"><?php echo $finalyear ?>
                                                    </option>
                                                    <?php
                                                    $iniyear = substr($_SESSION['resultsession'], 5) - 3;
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear'>$iniyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="form-group">

                                            <label class="control-label col-lg-5" for="regid">Semester:</label>
                                            <div class="col-lg-7">
                                                <select name="getsemester" class="form-control" style="color:#000000"
                                                    id="getsemester" required>
                                                    <option value="">Select Item</option>
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-9">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"])) { ?>
                                <?php
                                    //echo substr("2018/2019", 5, 4);
                                    $downloaddept = $_POST['downloaddept'];
                                    $getyearGrad = $_POST['getyearGrad'];
                                    $getsemester = $_POST['getsemester'];

                                    $sql2 = "SELECT * FROM deptcoding WHERE DeptCode = '$downloaddept'";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row = $result2->fetch_assoc()) {
                                            $downdeptname = $row["DeptName"];
                                            $schcode = $row["School"];
                                            $DegreeAward = $row["DegreeAward"];
                                        }
                                    }

                                    $sql2 = "SELECT * FROM schoolname WHERE SchCode = '$schcode'";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row = $result2->fetch_assoc()) {
                                            $schfull = $row["SchName"];
                                        }
                                    }
                                    ?>
                                <div class="col-lg-12  col-md-12">

                                    <div class="table-responsive">
                                        <?php
                                            set_time_limit(500);
                                            $GetTitle = $downdeptname . " Department";
                                            $sno = 0;
                                            ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                            rules="groups" frame="hsides" border="2">

                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>


                                                    <th>Key</th>
                                                    <th>Matric No</th>
                                                    <th>Name</th>
                                                    <th>YAddmitted</th>
                                                    <th>Sex</th>
                                                    <th>ParmtAdress</th>
                                                    <th>School</th>
                                                    <th>Department</th>
                                                    <th>stateOfOrigin</th>
                                                    <th>LGA</th>
                                                    <th>programme</th>
                                                    <th>dob</th>
                                                    <th>PlaceBirth</th>
                                                    <th>yearGrd</th>
                                                    <th>SchFull</th>
                                                    <th>DegAward</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($downloaddept);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    $sql2 = "SELECT * FROM scrutiny_senate WHERE yearGrad= '$getyearGrad' AND semester = '$getsemester' AND graduated = 'YES' ORDER BY Regn";

                                                    $result2 = $conn_stu->query($sql2);
                                                    if ($result2->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $regid = $row2["Regn"];
                                                            $names = $row2["Name1"];
                                                            $sex = $row2["sex"];
                                                            $stateorigin = $row2["stateOfOrigin"];
                                                            $lga = $row2["lga"];
                                                            $getyearaddmt = substr($regid, 0, 4);
                                                            $sql = "SELECT * FROM states WHERE StateCode= '$stateorigin'";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $statefull = $row["state"];
                                                                }
                                                            }



                                                            $sql = "SELECT * FROM stdprofile WHERE regid= '$regid'";
                                                            $result = $conn2->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {


                                                                    $deptopt = $row["Dept_Option"];
                                                                    $permaddres = $row["ParmtAdress"];
                                                                    $dob = $row["dob"];
                                                                    $pob = $row["PlaceBirth"];
                                                                }
                                                            }

                                                            if ($deptopt == "NOP") {
                                                                $deptopt = $downdeptname;
                                                            } else {
                                                                $sql = "SELECT * FROM dept_option WHERE deptcode= '$downloaddept' AND Opt_Code = '$deptopt'";
                                                                $result = $conn->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $deptopt = $downdeptname . "(" . $row["Opt_Title"] . ")";
                                                                    }
                                                                }
                                                            }

                                                            echo "<tr><td>biodata</td><td>$regid</td><td>$names</td><td>$getyearaddmt</td><td>$sex</td><td>$permaddres</td><td>$schcode</td><td>$downdeptname</td><td>$statefull</td><td>$lga</td><td>$deptopt</td><td>$dob</td><td>$pob</td><td>$getyearGrad</td><td>$schfull</td><td>$DegreeAward</td></tr>\n";
                                                        }
                                                    }

                                                    $FinalYear = substr($resultsession, 5, 4);

                                                    $sql2 = "SELECT * FROM scrutiny_senate WHERE yearGrad= '$getyearGrad' AND semester = '$getsemester' AND graduated = 'YES' ORDER BY Regn";
                                                    $result2 = $conn_stu->query($sql2);
                                                    if ($result2->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $regid = $row2["Regn"];
                                                            $yearadmt = substr($row2["Regn"], 0, 4);
                                                            for ($x = $yearadmt; $x <= $FinalYear; $x++) {
                                                                //$StuCurSess = "2018_2019";
                                                                $prevyear = $x;
                                                                $nextyr = $x + 1;
                                                                $StuCurSess = $prevyear . "_" . $nextyr;

                                                                $deptcorreg = "correg_" . $StuCurSess;
                                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$regid'";
                                                                $result = $conn_stu->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $ccode = $row['CCode'];
                                                                        $ctitle = $row['CTitle'];
                                                                        $cunit = $row['CUnit'];
                                                                        $SemTaken = $row['SemTaken'];
                                                                        $SessionRegis = $row['SessionRegis'];
                                                                        $CA = $row['CA'];
                                                                        $Exam = $row['Exam'];
                                                                        $gpoint = $row['point'];
                                                                        $grade = $row['grade'];

                                                                        echo "<tr><td>result</td><td>$ccode</td><td>$ctitle</td><td>$cunit</td><td>$SemTaken</td><td>$SessionRegis</td><td>$CA</td><td>$Exam</td><td>$grade</td><td>$regid</td><td>$gpoint</td><td></td><td></td><td></td><td></td><td></td></tr>\n";
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }

                                                    ?>
                                            </tbody>
                                        </table>

                                    </div>
                                    <br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                            class="btn btn-primary">Download</a>
                                    </div>

                                </div>



                                <?php } ?>
                            </div>


                        </div>
                    </div>

                    <?php
$conn->close();
$conn2->close();
$conn_stu->close();
?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
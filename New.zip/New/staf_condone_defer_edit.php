<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_edit'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--To Delete
		<link href='delete_res/bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>-->
    <script src='delete_res/jquery-3.3.1.js' type='text/javascript'> </script>
    <script src='delete_res/bootstrap/js/bootstrap.min.js'> </script>
    <script src='delete_res/bootbox.min.js'> </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Missing Session/Semester</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Missing Session
                            </li>

                            <li class="active">
                                <strong>Missing Session/Semester</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Missing Session/Semester
                        </div>
                        <div class="panel-body">

                            <?php


                            if (isset($_POST["update"])) {
                                $sno = $_POST["sn"];

                                $sql = "SELECT * FROM missing_session WHERE id ='$sno'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $oldstatus = $row["oldstatus"];
                                        $matno = $row["matno"];
                                    }
                                }



                                $sql = "UPDATE std_data_view set status = '$oldstatus' WHERE matric_no = '$matno'";
                                $result = $conn3->query($sql);

                                $response = $_POST["response"];
                                $session = $_POST["sesion"];
                                $senateno = $_POST["senateno"];
                                $comment = $_POST["comment"];
                                $approval = $_POST["approval"];

                                if ($response == "Deferment") {
                                    $response_full = "Deferment";
                                } else if ($response == "Abscond") {
                                    $response_full = "Abscond";
                                } else if ($response == "Condonation") {
                                    $response_full = "Condonation";
                                } else if ($response == "Suspension") {
                                    $response_full = "Suspension";
                                } else if ($response == "Expulsion") {
                                    $response_full = "Expulsion";
                                } else if ($response == "VolWithdrawal") {
                                    $response_full = "Voluntary Withdrawal";
                                } else if ($response == "PoorWithdrawal") {
                                    $response_full = "Withdrawal(Poor Acad Performance)";
                                } else if ($response == "Notification_illhealth") {
                                    $response_full = "Notification of ill-health";
                                } else if ($response == "recall_susp") {
                                    $response_full = "Recall from Suspension";
                                } else if ($response == "recall_expul") {
                                    $response_full = "Recall from Expulsion";
                                }

                                if (!empty($_POST["semester1"]) && !empty($_POST["semester2"])) {
                                    $semester = "1ST,2ND";
                                } else if (!empty($_POST["semester1"])) {
                                    $semester = "1ST";
                                } else if (!empty($_POST["semester2"])) {
                                    $semester = "2ND";
                                } else {
                                    $semester = "";
                                }

                                $sql = "UPDATE missing_session set response = '$response', response_full = '$response_full', session = '$session', semester = '$semester', coment = '$comment', approval = '$approval', senateno = '$senateno', oldstatus = '$oldstatus' WHERE id = '$sno'";
                                $result = $conn->query($sql);

                                if ($response == "Suspension") {
                                    $sql = "UPDATE std_data_view set status = '8' WHERE stdid = '$stuid'";
                                    $result = $conn3->query($sql);
                                } else if ($response == "VolWithdrawal" || $response == "PoorWithdrawal" || $response == "Expulsion") {
                                    $sql = "UPDATE std_data_view set status = '14' WHERE stdid = '$stdid'";
                                    $result = $conn3->query($sql);
                                } else if ($response == "Deferment" || $response == "Condonation" || $response == "Abscond") {
                                    $sql = "UPDATE std_data_view set status = '9' WHERE stdid = '$stdid'";
                                    $result = $conn3->query($sql);
                                } else {
                                    $sql = "UPDATE std_data_view set status = '6' WHERE stdid = '$stdid'";
                                    $result = $conn3->query($sql);
                                }
                            }


                            ?>
                            <div class="row">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="col-lg-4">

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Matric Number: </label>
                                            <div class="col-lg-5">
                                                <input type="text" class="form-control" style="color:#000000" name="regid">
                                            </div>
                                            <div class="col-lg-3">
                                                <button type="submit" name="submit_regid" class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">

                                    </div>
                            </div>
                            <hr class="separator" />
                            <div class="row">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Date Range</label>
                                            <div class="col-md-6">
                                                <div class="input-daterange input-group">
                                                    <span class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </span>
                                                    <span class="input-group-addon">From</span>
                                                    <input type="date" class="form-control" name="start_date">
                                                    <span class="input-group-addon">to</span>
                                                    <input type="date" class="form-control" name="end_date">
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="control-label col-lg-2" for="regid">School:</label>
                                            <div class="col-lg-7">
                                                <select name="getschool" class="form-control" style="color:#000000">
                                                    <option value="All">All</option>
                                                    <?php
                                                    $sql2 = "SELECT * FROM schoolname ORDER BY SchName";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result2->num_rows > 0) {

                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $SchCode = $row2["SchCode"];
                                                            $SchName = $row2["SchName"];
                                                            echo "<option value = '$SchCode'>$SchName</option>";
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-lg-2">
                                                <button type="submit" name="submit_other" class="btn btn-primary btn-sm">Submit</button>
                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">
                                <div class="col-lg-2 col-md-2">
                                </div>
                                <div class="col-lg-8 col-md-8">

                                    <?php
                                    if (isset($_POST["view"])) {
                                        $sno = $_POST["id"];
                                        $sql = "SELECT * FROM missing_session WHERE id = '$sno'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $regid = $row["matno"];
                                                $name1 = $row["name1"];
                                                $cursession = $row["session"];
                                                $response = $row['response'];
                                                $semester = $row['semester'];
                                                $senateno = $row['senateno'];
                                                $comment = $row['coment'];
                                                $approval = $row["approval"];
                                                if ($response == "Deferment") {
                                                    $response_full = "Deferment";
                                                } else if ($response == "Abscond") {
                                                    $response_full = "Abscond";
                                                } else if ($response == "Condonation") {
                                                    $response_full = "Condonation";
                                                } else if ($response == "Suspension") {
                                                    $response_full = "Suspension";
                                                } else if ($response == "Expulsion") {
                                                    $response_full = "Expulsion";
                                                } else if ($response == "VolWithdrawal") {
                                                    $response_full = "Voluntary Withdrawal";
                                                } else if ($response == "PoorWithdrawal") {
                                                    $response_full = "Withdrawal(Poor Acad Performance)";
                                                } else if ($response == "Notification_illhealth") {
                                                    $response_full = "Notification of ill-health";
                                                } else if ($response == "recall_susp") {
                                                    $response_full = "Recall from Suspension";
                                                } else if ($response == "recall_expul") {
                                                    $response_full = "Recall from Expulsion";
                                                }
                                            }
                                        }

                                        $sql2 = "SELECT * FROM miss_session_senateno WHERE senateno='$senateno'";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $senatedate = $row2["senatedate"];
                                                $fulsenatedate = date_format(date_create($senatedate), "D") . ", " . date_format(date_create($senatedate), "j") . " " . date_format(date_create($senatedate), "M") . ", " . date_format(date_create($senatedate), "Y");
                                            }
                                        }

                                    ?>
                                        <form class="form-horizontal" role="form" method="post" action="">
                                            <!-- Content -->
                                            <div class="form-group">
                                                <input type='hidden' value=<?php echo $sno ?> name='sn'>
                                                <label class="control-label col-lg-4" for="regid"><strong>Matric
                                                        Number</strong></label>
                                                <label class="col-lg-7 control-label" name="regid" id="regid" style="text-align: left"><strong><?php echo $regid ?></strong></label>

                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-lg-4" for="regid"><strong>Name</strong></label>
                                                <label class="col-lg-7 control-label" name="regid" id="regid" style="text-align: left"><strong><?php echo $name1 ?></strong></label>

                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label"><strong>Session:</strong></label>
                                                <div class="col-lg-7">
                                                    <?php
                                                    $iniyear = 2015;
                                                    //$D = exec('date /T');
                                                    //												  $T = exec('time /T');
                                                    //												  $DT = strtotime(str_replace("/","-",$D." ".$T));
                                                    $finalyear = substr($_SESSION['corntsession'], 5);

                                                    ?>
                                                    <select name="sesion" class="form-control" style="color:#000000" id="sesion">
                                                        <option value="<?php echo $cursession ?>"><?php echo $cursession ?>
                                                        </option>
                                                        <?php
                                                        while ($iniyear <= $finalyear) {
                                                            $addyear = $iniyear + 1;

                                                            echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                            $iniyear++;
                                                        }

                                                        ?>

                                                    </select>

                                                </div>
                                                <div class="col-lg-1"></div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label"><strong>Response:</strong></label>
                                                <div class="col-lg-7">

                                                    <select name="response" class="form-control" style="color:#000000" id="response">
                                                        <option value="<?php echo $response ?>"><?php echo $response_full ?>
                                                        </option>
                                                        <option value="Deferment">Deferment</option>
                                                        <option value="Abscond">Abscond</option>
                                                        <option value="Condonation">Condonation</option>
                                                        <option value="Suspension">Suspension</option>
                                                        <option value="Expulsion">Expulsion</option>
                                                        <option value="VolWithdrawal">Voluntary Withdrawal</option>
                                                        <option value="PoorWithdrawal">Withdrawal(Poor Acad Performance)
                                                        </option>
                                                        <option value="Notification_illhealth">Notification of ill-health
                                                        </option>
                                                        <option value="recall_susp">Recall from Suspension</option>
                                                        <option value="recall_expul">Recall from Expulsion</option>

                                                    </select>

                                                </div>
                                                <div class="col-lg-1"></div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label"><strong>Semester:</strong></label>
                                                <div class="col-lg-7">
                                                    <?php if ($semester == "1ST") { ?>
                                                        <input type="checkbox" name="semester1" value="1ST" checked>1ST
                                                        <input type="checkbox" name="semester2" value="2ND">2ND
                                                    <?php } else if ($semester == "2ND") { ?>
                                                        <input type="checkbox" name="semester1" value="1ST">1ST
                                                        <input type="checkbox" name="semester2" value="2ND" checked>2ND
                                                    <?php } else if ($semester == "1ST,2ND") { ?>
                                                        <input type="checkbox" name="semester1" value="1ST" checked>1ST
                                                        <input type="checkbox" name="semester2" value="2ND" checked>2ND
                                                    <?php } else { ?>
                                                        <input type="checkbox" name="semester1" value="1ST">1ST
                                                        <input type="checkbox" name="semester2" value="2ND">2ND
                                                    <?php } ?>


                                                </div>
                                                <div class="col-lg-1"></div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label"><strong>Approval:</strong></label>
                                                <div class="col-lg-7">

                                                    <select name="approval" class="form-control" style="color:#000000" id="approval">
                                                        <option value="<?php echo $approval ?>"><?php echo $approval ?>
                                                        </option>
                                                        <option value="Approve">Approve</option>
                                                        <option value="Not_Approve">Not Approve</option>

                                                    </select>

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-lg-4" for="regid"><strong>Senate
                                                        Number:</strong></label>
                                                <div class="col-lg-7">
                                                    <select name="senateno" class="form-control" style="color:#000000" id="senateno">

                                                        <option value="<?php echo $senateno ?>">
                                                            <?php echo $senateno . ", " . $fulsenatedate ?></option>
                                                        <?php
                                                        $sql2 = "SELECT * FROM miss_session_senateno ORDER BY senateno DESC";
                                                        $result2 = $conn->query($sql2);
                                                        if ($result2->num_rows > 0) {

                                                            while ($row2 = $result2->fetch_assoc()) {

                                                                $senatedate = $row2["senatedate"];
                                                                $fulsenatedate = date_format(date_create($senatedate), "D") . ", " . date_format(date_create($senatedate), "j") . " " . date_format(date_create($senatedate), "M") . ", " . date_format(date_create($senatedate), "Y");
                                                                $senatenoget = $row2["senateno"];
                                                                echo "<option value = '$senatenoget'>$senatenoget, $fulsenatedate</option>";
                                                            }
                                                        }
                                                        ?>

                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-lg-4" for="regid"><strong>Comment (<i style="color:#609">Optional</i>):</strong></label>
                                                <div class="col-lg-7">
                                                    <input type="text" name="comment" id="comment" class="form-control" value="<?php echo $comment ?>">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <!-- Buttons -->
                                                <div class="col-lg-offset-6 col-lg-6" style="text-align: right">
                                                    <button type="submit" name="update" class="btn btn-primary btn-xs">Update</button>

                                                </div>
                                            </div>
                                            <br>
                                        </form>
                                    <?php } ?>


                                </div>
                                <div class="col-lg-2 col-md-2">
                                </div>
                            </div>

                            <?php if (isset($_POST["submit_regid"]) || isset($_POST["submit_other"]) || isset($_POST["view"]) || isset($_POST["update"])) { ?>
                                <?php
                                $regid = $fromdate = $todate = $getschool = "";
                                if (isset($_POST["submit_regid"])) {
                                    $regid = $_POST["regid"];
                                    $_SESSION["getregid"] = $regid;
                                    $_SESSION["respondid"] = "post_regid";
                                } elseif (isset($_POST["submit_other"])) {
                                    $fromdate = $_POST["start_date"];
                                    $todate = $_POST["end_date"];
                                    $getschool = $_POST["getschool"];
                                    $_SESSION["getstart_date"] = $fromdate;
                                    $_SESSION["getend_date"] = $todate;
                                    $_SESSION["getschool"] = $getschool;
                                    $_SESSION["respondid"] = "post_other";
                                } elseif (isset($_POST["view"])) {
                                    if ($_SESSION["respondid"] == "post_regid") {
                                        $regid = $_SESSION["getregid"];
                                    } elseif ($_SESSION["respondid"] == "post_other") {
                                        $fromdate = $_SESSION["getstart_date"];
                                        $todate = $_SESSION["getend_date"];
                                        $getschool = $_SESSION["getschool"];
                                    }
                                } elseif (isset($_POST["update"])) {
                                    if ($_SESSION["respondid"] == "post_regid") {
                                        $regid = $_SESSION["getregid"];
                                    } elseif ($_SESSION["respondid"] == "post_other") {
                                        $fromdate = $_SESSION["getstart_date"];
                                        $todate = $_SESSION["getend_date"];
                                        $getschool = $_SESSION["getschool"];
                                    }
                                }

                                ?>
                                <div class="row">

                                    <div class="col-lg-12  col-md-12">

                                        <div class="row">
                                            <div class="col-lg-4">
                                                Matric No: <?php echo $regid ?>
                                            </div>
                                            <div class="col-lg-4">
                                                Dtate Range: From: <?php echo $fromdate ?> To:
                                                <?php echo $todate ?>
                                            </div>
                                            <div class="col-lg-4">
                                                School: <?php echo $getschool ?>
                                            </div>
                                        </div>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Matric No.</th>
                                                    <th>Name</th>
                                                    <th>Response</th>
                                                    <th>Session</th>
                                                    <th>Semester</th>
                                                    <th>Comment</th>
                                                    <th>Approval</th>
                                                    <th>Senate Number</th>
                                                    <th>Desk Officer</th>
                                                    <th>Action</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>


                                            <tbody>

                                                <?php

                                                if (isset($_POST["submit_regid"])) {
                                                    $sql = "SELECT * FROM missing_session WHERE matno='$regid' ORDER BY id DESC";
                                                } elseif (isset($_POST["submit_other"])) {
                                                    if ($getschool == "All") {
                                                        if ($fromdate !== "" && $todate !== "") {
                                                            $sql = "SELECT * FROM missing_session WHERE date1 BETWEEN STR_TO_DATE('$fromdate','%Y-%m-%d') AND STR_TO_DATE('$todate','%Y-%m-%d') ORDER BY  id DESC";
                                                        } elseif ($fromdate !== "" && $todate == "") {
                                                            $sql = "SELECT * FROM missing_session WHERE date1 >= STR_TO_DATE('$fromdate','%Y-%m-%d') ORDER BY  id DESC";
                                                        } elseif ($fromdate == "" && $todate !== "") {
                                                            $sql = "SELECT * FROM missing_session WHERE date1 <= STR_TO_DATE('$todate','%Y-%m-%d') ORDER BY  id DESC";
                                                        }
                                                    } else {
                                                        if ($fromdate !== "" && $todate !== "") {
                                                            $sql = "SELECT * FROM missing_session WHERE (date1 BETWEEN STR_TO_DATE('$fromdate','%Y-%m-%d') AND STR_TO_DATE('$todate','%Y-%m-%d')) AND schcode='$getschool' ORDER BY  id DESC";
                                                        } elseif ($fromdate !== "" && $todate == "") {
                                                            $sql = "SELECT * FROM missing_session WHERE date1 >= STR_TO_DATE('$fromdate','%Y-%m-%d') AND schcode='$getschool' ORDER BY  id DESC";
                                                        } elseif ($fromdate == "" && $todate !== "") {
                                                            $sql = "SELECT * FROM missing_session WHERE date1 <= STR_TO_DATE('$todate','%Y-%m-%d') AND schcode='$getschool' ORDER BY  id DESC";
                                                        }
                                                    }
                                                } elseif (isset($_POST["view"])) {
                                                    if ($_SESSION["respondid"] == "post_regid") {
                                                        $sql = "SELECT * FROM missing_session WHERE matno='$regid' ORDER BY id DESC";
                                                    } elseif ($_SESSION["respondid"] == "post_other") {
                                                        if ($getschool == "All") {
                                                            if ($fromdate !== "" && $todate !== "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 BETWEEN STR_TO_DATE('$fromdate','%Y-%m-%d') AND STR_TO_DATE('$todate','%Y-%m-%d') ORDER BY  id DESC";
                                                            } elseif ($fromdate !== "" && $todate == "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 >= STR_TO_DATE('$fromdate','%Y-%m-%d') ORDER BY  id DESC";
                                                            } elseif ($fromdate == "" && $todate !== "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 <= STR_TO_DATE('$todate','%Y-%m-%d') ORDER BY  id DESC";
                                                            }
                                                        } else {
                                                            if ($fromdate !== "" && $todate !== "") {
                                                                $sql = "SELECT * FROM missing_session WHERE (date1 BETWEEN STR_TO_DATE('$fromdate','%Y-%m-%d') AND STR_TO_DATE('$todate','%Y-%m-%d')) AND schcode='$getschool' ORDER BY  id DESC";
                                                            } elseif ($fromdate !== "" && $todate == "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 >= STR_TO_DATE('$fromdate','%Y-%m-%d') AND schcode='$getschool' ORDER BY  id DESC";
                                                            } elseif ($fromdate == "" && $todate !== "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 <= STR_TO_DATE('$todate','%Y-%m-%d') AND schcode='$getschool' ORDER BY  id DESC";
                                                            }
                                                        }
                                                    }
                                                } elseif (isset($_POST["update"])) {
                                                    if ($_SESSION["respondid"] == "post_regid") {
                                                        $sql = "SELECT * FROM missing_session WHERE matno='$regid' ORDER BY id DESC";
                                                    } elseif ($_SESSION["respondid"] == "post_other") {
                                                        if ($getschool == "All") {
                                                            if ($fromdate !== "" && $todate !== "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 BETWEEN STR_TO_DATE('$fromdate','%Y-%m-%d') AND STR_TO_DATE('$todate','%Y-%m-%d') ORDER BY  id DESC";
                                                            } elseif ($fromdate !== "" && $todate == "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 >= STR_TO_DATE('$fromdate','%Y-%m-%d') ORDER BY  id DESC";
                                                            } elseif ($fromdate == "" && $todate !== "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 <= STR_TO_DATE('$todate','%Y-%m-%d') ORDER BY  id DESC";
                                                            }
                                                        } else {
                                                            if ($fromdate !== "" && $todate !== "") {
                                                                $sql = "SELECT * FROM missing_session WHERE (date1 BETWEEN STR_TO_DATE('$fromdate','%Y-%m-%d') AND STR_TO_DATE('$todate','%Y-%m-%d')) AND schcode='$getschool' ORDER BY  id DESC";
                                                            } elseif ($fromdate !== "" && $todate == "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 >= STR_TO_DATE('$fromdate','%Y-%m-%d') AND schcode='$getschool' ORDER BY  id DESC";
                                                            } elseif ($fromdate == "" && $todate !== "") {
                                                                $sql = "SELECT * FROM missing_session WHERE date1 <= STR_TO_DATE('$todate','%Y-%m-%d') AND schcode='$getschool' ORDER BY  id DESC";
                                                            }
                                                        }
                                                    }
                                                }


                                                $sno = 0;
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $id = $row['id'];
                                                        $response = $row['response'];
                                                        if ($response == "Deferment") {
                                                            $response_full = "Deferment";
                                                        } else if ($response == "Abscond") {
                                                            $response_full = "Abscond";
                                                        } else if ($response == "Condonation") {
                                                            $response_full = "Condonation";
                                                        } else if ($response == "Suspension") {
                                                            $response_full = "Suspension";
                                                        } else if ($response == "Expulsion") {
                                                            $response_full = "Expulsion";
                                                        } else if ($response == "VolWithdrawal") {
                                                            $response_full = "Voluntary Withdrawal";
                                                        } else if ($response == "PoorWithdrawal") {
                                                            $response_full = "Withdrawal(Poor Acad Performance)";
                                                        } else if ($response == "Notification_illhealth") {
                                                            $response_full = "Notification of ill-health";
                                                        } else if ($response == "recall_susp") {
                                                            $response_full = "Recall from Suspension";
                                                        } else if ($response == "recall_expul") {
                                                            $response_full = "Recall from Expulsion";
                                                        }
                                                        echo "<tr><td>$sno</td><td>{$row['matno']}</td><td>{$row['name1']}</td><td>$response_full</td><td>{$row['session']}</td><td>{$row['semester']}</td><td>{$row['coment']}</td><td>{$row['approval']}</td><td>{$row['senateno']}</td><td>{$row['officername']}</td>
													<td>												
														<form action='' method='post'>
															  <input type='hidden' value=$id name='id'>
															  <input type='submit' name = 'view' class='btn btn-primary btn-xs' value='View'>
															  
														 </form>
													</td>
													<td>
														<button class='delete_list btn btn-danger btn-xs' id='del_.$id' data-id='$id'>Delete</button>
													</td>
													</tr>\n";
                                                    }
                                                }


                                                ?>
                                            </tbody>
                                        </table>

                                    </div>

                                </div>
                            <?php } ?>

                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
        $(document).ready(function() {

            // Delete 
            $('.delete_list').click(function() {
                var el = this;

                // Delete id
                var deleteid = $(this).data('id');

                // Confirm box
                bootbox.confirm("Do you really want to delete record?", function(result) {

                    if (result) {
                        // AJAX Request
                        $.ajax({
                            url: 'delete_res/delete_missing.php',
                            type: 'POST',
                            data: {
                                id: deleteid
                            },
                            success: function(response) {

                                // Removing row from HTML Table
                                if (response == 1) {
                                    $(el).closest('tr').css('background', 'tomato');
                                    $(el).closest('tr').fadeOut(800, function() {
                                        $(this).remove();
                                    });
                                } else {
                                    bootbox.alert('Record not deleted.');
                                }

                            }
                        });
                    }

                });

            });

        });
    </script>
</body>

</html>
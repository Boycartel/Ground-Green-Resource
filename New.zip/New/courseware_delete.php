
<?php

require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$filedeleted = "";
$errordel = "";

$course = $_SESSION['getcoursedel'];
$curtsession = $_SESSION['corntsession'];
$savesession = substr($curtsession, 0, 4) . "_" . substr($curtsession, -4);

$id = $_POST["id"];
$filenam = $_POST["filenam"];
$delpath = "Content/$savesession/$course/$filenam";
// sql to delete a record
$sql = "DELETE FROM courseware WHERE id ='$id'";
$result = $conn->query($sql);


if (@unlink($delpath)) {
	$filedeleted = "File Deleted ... ";
} else {
	$errordel = "File can't be deleted";
}

echo "<br>
	<center><strong><h2 style='color:#F00'>$errordel</h2></strong></center>
	<center><strong><h2 style='color:#00C'>$filedeleted</h2></strong></center>";

$conn->close();
?>
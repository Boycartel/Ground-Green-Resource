<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_edit'] == false) {
    header('Location: Home_Staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_qap.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Sessional CGPA</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Sessional CGPA</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Sessional CGPA
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="form-group">

                                        <label class="control-label col-lg-2" for="regid">Session:</label>
                                        <div class="col-lg-3">
                                            <?php
                                            $iniyear = 2017;

                                            $finalyear = substr($_SESSION['corntsession'], 5);

                                            ?>
                                            <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                    <?php echo $_SESSION['corntsession'] ?></option>
                                                <?php
                                                while ($iniyear <= $finalyear) {
                                                    $addyear = $iniyear + 1;

                                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                    $iniyear++;
                                                }

                                                ?>

                                            </select>
                                        </div>
                                        <label class="control-label col-lg-2" for="regid">CGPA:</label>
                                        <div class="col-lg-3">
                                            <input type="text" class="form-control" style="color:#000000" name="cgpa">
                                        </div>
                                        <div class="col-lg-2">
                                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <hr class="separator" />
                            <?php if (isset($_POST["submit"])) {
                                $session = $_POST['getsession'];
                                $cgpa = $_POST['cgpa'];


                            ?>
                                <div class="row">

                                    <div class="col-lg-12  col-md-12">

                                        <?php
                                        set_time_limit(500);
                                        $GetTitle = "Session:- " . $session;
                                        ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>S/No</th>
                                                    <th>Department</th>
                                                    <th>Matric No</th>
                                                    <th>Name</th>
                                                    <th>CGPA</th>
                                                    <th>Level</th>
                                                    <th>Sex</th>
                                                    <th>State</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }
                                                $sno = 0;
                                                // To Change
                                                //$sql = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptName";
                                                $sql = "SELECT * FROM deptcoding WHERE DeptCode = 'MAT' ORDER BY DeptName";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno2 = 0;
                                                        //$level100=$level200=$level300=$level400=$level500="";
                                                        $dept = strtolower($row['DeptCode']);
                                                        $deptname = $row['DeptName'];

                                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                        if ($conn_stu->connect_error) {
                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                        }

                                                        $sql3 = "select 1 from scrutiny_senate";
                                                        $exists3 = $conn_stu->query($sql3);

                                                        if ($exists3 == true) {

                                                            $sql2 = "SELECT * FROM scrutiny_senate WHERE Session1 = '$session' AND semester = '2ND' AND CGPA >= '$cgpa' ORDER BY Level1, CGPA DESC ";
                                                            //$sql2 = "SELECT * FROM scrutiny_senate WHERE Session1 = '$session' AND semester = '2ND' ORDER BY Level1, CGPA DESC ";
                                                            $result2 = $conn_stu->query($sql2);

                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $sno2++;
                                                                    $sno++;
                                                                    $regid = $row2["Regn"];
                                                                    $name1 = $row2['Name1'];
                                                                    $level = $row2['Level1'];
                                                                    if ($_SESSION['InstType'] == "Polytechnic") {
                                                                        if ($level == 100) {
                                                                            $level = "ND I";
                                                                        } elseif ($level == 200) {
                                                                            $level = "ND II";
                                                                        } elseif ($level == 300) {
                                                                            $level = "HND I";
                                                                        } elseif ($level == 400) {
                                                                            $level = "HND II";
                                                                        }
                                                                    }
                                                                    $cgpa = number_format($row2['CGPA'], 2);
                                                                    $sex2 = $row2["sex"];
                                                                    $state = $row2["stateOfOrigin"];

                                                                    echo "<tr><td>$sno</td><td>$sno2</td><td>$deptname</td><td>$regid</td><td>$name1</td><td>$cgpa</td><td>$level</td><td>$sex2</td><td>$state</td>
                                                        <td>
                                                        <form action='staff_results.php' method='post'>
                                                            <input type='hidden' value='$regid' name='id'>
                                                            <input type='submit' name='viewCGPAresults' class='btn btn-primary btn-xs' value='View'>
                                                        </form>
                                                        </td>
                                                         </tr>\n";
                                                                    //
                                                                }
                                                            }
                                                        }
                                                        $conn_stu->close();


                                                        echo "<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>\n";
                                                    }
                                                }

                                                $conn->close();
                                                ?>
                                            </tbody>
                                        </table>


                                        <br>
                                        <div style="text-align: right">
                                            <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                        </div>


                                    </div>

                                </div>
                            <?php } ?>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
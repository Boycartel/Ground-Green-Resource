<?php
                                                                            require_once 'includes/db_connect.php';
                                                                            require_once 'includes/check_validity.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!--Print Div-->
    <script type="text/javascript">
    function printme() {
        var print_div = document.getElementById("printablediv");
        var print_area = window.open();
        print_area.document.write(print_div.innerHTML);
        print_area.document.close();
        print_area.focus();
        print_area.print();
        print_area.close();
    }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';
            $staffid = $_SESSION['staffid'];
            $corntsession = $_SESSION['corntsession'];
            $cursemester = $_SESSION['cursemester'];


            if (isset($_POST["updatesingle_profile"])) {
                $fname = str_replace("'", "", $_POST['fname']);
                $fname = htmlspecialchars(strtoupper($_POST['fname']), ENT_QUOTES);

                $surname = str_replace("'", "", $_POST['surname']);
                $surname = htmlspecialchars(strtoupper($_POST['surname']), ENT_QUOTES);

                //$surname = filter_var(strtoupper($surname), FILTER_SANITIZE_STRING);
                $othername = str_replace("'", "", $_POST['othername']);
                $othername = htmlspecialchars(strtoupper($_POST['othername']), ENT_QUOTES);

                //$othername = filter_var(strtoupper($othername), FILTER_SANITIZE_STRING);
                $email1 = str_replace("'", "", $_POST['email1']);
                //$email1 = filter_var($email1, FILTER_SANITIZE_EMAIL);
                $email1 = filter_var($email1, FILTER_SANITIZE_EMAIL, FILTER_VALIDATE_EMAIL);
                $phone1 = str_replace("'", "", $_POST['phone1']);
                $phone1 = filter_var($phone1, FILTER_SANITIZE_NUMBER_INT);
                $area_special = str_replace("'", "", $_POST['area_special']);
                $area_special = htmlspecialchars($_POST['area_special'], ENT_QUOTES);

                $apptype = $_POST['apptype'];
                $title1 = $_POST['title1'];
                $postrank = $_POST['postrank'];
                $leaveabsent = $_POST['leaveabsent'];
                $stepG = $_POST['stepG'];

                if ($postrank == "Prof") {
                    $salary_grade = "A07";
                } elseif ($postrank == "assprof") {
                    $salary_grade = "A06";
                } elseif ($postrank == "SL") {
                    $salary_grade = "A05";
                } elseif ($postrank == "LI") {
                    $salary_grade = "A04";
                } elseif ($postrank == "LII") {
                    $salary_grade = "A03";
                } elseif ($postrank == "AL") {
                    $salary_grade = "A02";
                } else {
                    $salary_grade = "A01";
                }

                $sql = "UPDATE staff_profile SET sname = '$surname', fname = '$fname', oname = '$othername', title = '$title1', Status = '$apptype', leaveabsent_study = '$leaveabsent', Rank1 = '$postrank', area_special = '$area_special', GradeL = '$salary_grade', StepG = '$stepG' WHERE PSN = '$staffid'";
                $result = $conn7->query($sql);

                $sql = "UPDATE users SET surname = '$surname', othernames = '$othername', mytitle = '$title1', apptype = '$apptype', leaveabsent_study = '$leaveabsent', postn_rank = '$postrank', area_special = '$area_special', emailAdd = '$email1', phone = '$phone1' WHERE staffid = '$staffid'";
                $result = $conn->query($sql);
            }


            if (isset($_POST["addnew_reserch"])) {
                $projectNo = htmlspecialchars(strtoupper($_POST['projectNo']), ENT_QUOTES);
                $awardTitle = htmlspecialchars($_POST['awardTitle'], ENT_QUOTES);
                $InKindReq = htmlspecialchars($_POST['InKindReq'], ENT_QUOTES);
                $ReleaseTime = htmlspecialchars($_POST['ReleaseTime'], ENT_QUOTES);
                $amount = str_replace("'", "", $_POST['amount']);
                $amount = filter_var($amount, FILTER_SANITIZE_NUMBER_FLOAT);
                //$remark = str_replace("'", "", $_POST['remark']);
                //$remark = filter_var($remark, FILTER_SANITIZE_STRING);
                $remark = htmlspecialchars($_POST['remark'], ENT_QUOTES);

                $sql = "INSERT INTO funded_research (staffid, projt_no, projt_title, reguire_grant, release_time, totamount, remark1, session1) VALUE ('$staffid', '$projectNo', '$awardTitle', '$InKindReq', '$ReleaseTime', '$amount', '$remark', '$corntsession')";
                $result = $conn7->query($sql);
            }

            if (isset($_POST["updatesingle_reserch"])) {
                $id = $_POST['update_id'];
                $projectNo = htmlspecialchars(strtoupper($_POST['projectNo']), ENT_QUOTES);
                $awardTitle = htmlspecialchars($_POST['awardTitle'], ENT_QUOTES);
                $InKindReq = htmlspecialchars($_POST['InKindReq'], ENT_QUOTES);
                $ReleaseTime = htmlspecialchars($_POST['ReleaseTime'], ENT_QUOTES);
                $amount = str_replace("'", "", $_POST['amount']);
                $amount = filter_var($amount, FILTER_SANITIZE_NUMBER_FLOAT);
                $remark = htmlspecialchars($_POST['remark'], ENT_QUOTES);

                $sql = "UPDATE funded_research SET projt_no = '$projectNo', projt_title = '$awardTitle', reguire_grant = '$InKindReq', release_time = '$ReleaseTime', totamount = '$amount', remark1 = '$remark' WHERE id = '$id'";
                $result = $conn7->query($sql);
            }

            if (isset($_POST["deletesingle_reserch"])) {
                //$id = $_POST["id"];
                $id = $_POST['delete_id'];

                $sql = "DELETE FROM funded_research WHERE id = '$id'";
                $result = $conn7->query($sql);
            }

            if (isset($_POST["addnew_Comm"])) {

                $type_comm = htmlspecialchars($_POST['type_comm'], ENT_QUOTES);
                $beneficiary = htmlspecialchars($_POST['beneficiary'], ENT_QUOTES);
                $effect = htmlspecialchars($_POST['effect'], ENT_QUOTES);
                $dateExecute = htmlspecialchars($_POST['dateExecute'], ENT_QUOTES);

                $sql = "INSERT INTO comm_service (staffid, type_comm, beneficiary, effect, date_comm, session1) VALUE ('$staffid', '$type_comm', '$beneficiary', '$effect', '$dateExecute', '$corntsession')";
                $result = $conn7->query($sql);
            }


            if (isset($_POST["updatesingle_comm"])) {
                //$id = $_POST["id"];
                $id = $_POST['update_id'];
                $type_comm = htmlspecialchars($_POST['type_comm'], ENT_QUOTES);
                $beneficiary = htmlspecialchars($_POST['beneficiary'], ENT_QUOTES);
                $effect = htmlspecialchars($_POST['effect'], ENT_QUOTES);
                $dateExecute = htmlspecialchars($_POST['dateExecute'], ENT_QUOTES);

                $sql = "UPDATE comm_service SET type_comm = '$type_comm', beneficiary = '$beneficiary', effect = '$effect', date_comm = '$dateExecute' WHERE id = '$id'";
                $result = $conn7->query($sql);
            }

            if (isset($_POST["deletesingle_comm"])) {
                //$id = $_POST["id"];
                $id = $_POST['delete_id'];

                $sql = "DELETE FROM comm_service WHERE id = '$id'";
                $result = $conn7->query($sql);
            }

            if (isset($_POST["submit_activity"])) {
                $activit_code = $_POST['typeactivit'];
                $activyear = $_POST['activyear'];
                $sql = "SELECT * FROM resp_table WHERE repcode = '$activit_code'";
                $result = $conn7->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $reptitle = $row['reptitle'];
                    }
                }

                if ($activit_code == "15" || $activit_code == "18" || $activit_code == "19") {
                    $specify = $_POST['specify'];
                } else {
                    $specify = "NO";
                }
                $sql = "INSERT INTO admin_duties (staffid, activit_code, activity_type, year1, specify, session1) VALUE ('$staffid', '$activit_code', '$reptitle', '$activyear', '$specify', '$corntsession')";
                $result = $conn7->query($sql);
            }

            if (isset($_POST["deletesingle_duties"])) {
                //$id = $_POST["id"];
                $id = $_POST['delete_id'];

                $sql = "DELETE FROM admin_duties WHERE id = '$id'";
                $result = $conn7->query($sql);
            }

            $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $emailAdd = $row['emailAdd'];
                    $phone = $row['phone'];
                }
            }

            $sql = "SELECT * FROM staff_profile WHERE PSN = '$staffid'";
            $result = $conn7->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $fname = $row['fname'];
                    $surname = $row['sname'];
                    $othernames = $row['oname'];
                    $mytitle = $row['title'];
                    $apptype = $row['Status'];
                    $leaveabsent_study = $row['leaveabsent_study'];
                    $postn_rank = $row['Rank1'];
                    $area_special = $row['area_special'];
                    $salary_grade = $row['GradeL'];
                    $stepG = $row['StepG'];
                }
            }

            if ($apptype == "fulltime") {
                $apptype_full = "Full Time";
            } else if ($apptype == "parttime") {
                $apptype_full = "Part Time";
            } else {
                $apptype_full = "Contract";
            }


            if ($postn_rank == "Prof") {
                $postn_rank_full = "Professor";
            } elseif ($postn_rank == "assprof") {
                $postn_rank_full = "Associate Professor";
            } elseif ($postn_rank == "SL") {
                $postn_rank_full = "Senior Lecturer";
            } elseif ($postn_rank == "LI") {
                $postn_rank_full = "Lecturer I";
            } elseif ($postn_rank == "LII") {
                $postn_rank_full = "Lecturer II";
            } elseif ($postn_rank == "AL") {
                $postn_rank_full = "Assistant Lecturer";
            } else {
                $postn_rank_full = "Graduate Assistant";
            }

            if ($leaveabsent_study == "leaveabsent") {
                $leaveabsent_study_full = "Leave of Absent";
            } else if ($leaveabsent_study == "studyleave") {
                $leaveabsent_study_full = "Study Leave";
            } else {
                $leaveabsent_study_full = $leaveabsent_study;
            }


            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>My Profile</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-file"></i>
                                </a>
                            </li>
                            <li><span>My Profile</span></li>

                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">
                    <div class="form-group">
                        <label class="col-lg-2 control-label"></label>
                        <label class="col-lg-4 control-label">Current Session: <?php echo  $corntsession ?></label>
                        <label class="col-lg-4 control-label">Semester: <?php echo  $cursemester ?></label>
                        <label class="col-lg-2 control-label"></label>
                    </div>
                    <hr class="separator" />
                    <section class="panel panel-success">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>

                            <h2 class="panel-title">PROFILE</h2>
                        </header>
                        <div class="panel-body">
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <div style="text-align: right">
                                    <a href="#editModal_profile" class="btn btn-primary btn-xs"
                                        data-toggle="modal"><span>Update Profile</span></a>
                                </div>
                                <hr class="separator" />
                                <div>
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="form-group" style="color: black">
                                            <label class="col-lg-6 control-label"
                                                style="text-align: left"><b>SurName:</b> <?php echo $surname ?></label>
                                            <label class="col-lg-3 control-label" style="text-align: left"><b>First
                                                    Name:</b> <?php echo $fname ?></label>
                                            <label class="col-lg-3 control-label" style="text-align: left"><b>Other
                                                    Name(s):</b> <?php echo $othernames ?></label>
                                        </div>

                                        <div class="form-group" style="color: black">
                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Title:</b>
                                                <?php echo $mytitle ?></label>
                                            <label class="col-lg-6 control-label"
                                                style="text-align: left"><b>Department:</b>
                                                <?php echo $_SESSION["deptname"] ?></label>
                                        </div>

                                        <div class="form-group" style="color: black">
                                            <label class="col-lg-6 control-label" style="text-align: left"><b>email:</b>
                                                <?php echo $emailAdd ?></label>
                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Phone:</b>
                                                <?php echo $phone ?></label>
                                        </div>

                                        <div class="form-group" style="color: black">
                                            <label class="col-lg-6 control-label"
                                                style="text-align: left"><b>Appointment Type:</b>
                                                <?php echo $apptype_full ?></label>
                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Leave of
                                                    Absence/Study Leave:</b>
                                                <?php echo $leaveabsent_study_full ?></label>
                                        </div>

                                        <div class="form-group" style="color: black">
                                            <label class="col-lg-6 control-label"
                                                style="text-align: left"><b>Position/Rank:</b>
                                                <?php echo $postn_rank_full ?></label>
                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Area of
                                                    Specialization:</b> <?php echo $area_special ?></label>
                                        </div>

                                        <div class="form-group" style="color: black">
                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Salary
                                                    Grade:</b> <?php echo $salary_grade ?></label>
                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Step:
                                                    <?php echo $stepG ?></b> </label>
                                        </div>

                                    </form>
                                </div>


                            </div>
                            <div class="col-md-1">
                            </div>
                        </div>
                    </section>

                    <hr class="separator" />
                    <section class="panel panel-success">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>

                            <h2 class="panel-title">ADMINISTRATIVE DUTIES</h2>
                        </header>
                        <div class="panel-body">

                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <form method="POST">
                                    <div style="text-align: right">

                                        <button type="submit" name="submit_Add_Duties"
                                            class="mb-xs mt-xs mr-xs btn btn-xs btn-primary">Add New</button>
                                    </div>
                                </form>

                                <?php
                                $sql = "SELECT * FROM admin_duties WHERE staffid = '$staffid' ORDER BY session1";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                ?>
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th hidden="hidden">ID</th>
                                            <th>Type of Activity</th>
                                            <th>Details</th>
                                            <th>Year</th>
                                            <th>Session</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                            while ($row = $result->fetch_assoc()) {
                                                $activit_code = $row['activit_code'];
                                                $activity_type = $row['activity_type'];
                                                $year1 = $row['year1'];
                                                $session1 = $row['session1'];
                                                $approval_duties = $row['approval'];
                                                $id = $row['id'];
                                                if ($activit_code == "15" || $activit_code == "18" || $activit_code == "19") {
                                                    $specify = $row['specify'];
                                                    echo "<tr><td hidden='hidden'>$id</td><td>$activity_type</td><td>$specify</td><td>$year1</td><td>$session1</td>";
                                                } else {
                                                    echo "<tr><td hidden='hidden'>$id</td><td>$activity_type</td><td></td><td>$year1</td><td>$session1</td>";
                                                }
                                            ?>
                                        <td>
                                            <?php if ($approval_duties == "NO") { ?>
                                            <button type='button' class='btn btn-default btn-xs delete_duties'><i
                                                    class='material-icons' data-toggle='tooltip' title='Delete'
                                                    style='color: red'>&#xE872;</i></button>
                                            <?php } ?>
                                        </td>
                                        </tr>
                                        <?php
                                            }

                                            ?>
                                    </tbody>
                                </table>
                                <?php } ?>
                                <?php if (isset($_POST["submit_Add_Duties"])) { ?>
                                <hr class="separator" />
                                <h3 style="text-align: center">ADD NEW</h3>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Type of Activities: </label>
                                        <div class="col-lg-7">
                                            <select class='activit form-control m-bot15' name='typeactivit'
                                                id='typeactivit'>
                                                <!-- <select name="typeactivit" id="ResponseSel" class="form-control" style="color:#000000" id="typeactivit" required="required"> -->
                                                <option value=""></option>
                                                <?php
                                                    $sql = "SELECT * FROM resp_table";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $repcode = $row['repcode'];
                                                            $reptitle = $row['reptitle'];
                                                            echo "<option value = '$repcode'>$reptitle</option>";
                                                        }
                                                    }
                                                    ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group" id="GetResponse">

                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Year: </label>
                                        <div class="col-lg-7">
                                            <?php
                                                $iniyear = 2015;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                            <select name="activyear" class="form-control" style="color:#000000"
                                                id="activyear">
                                                <option value=""></option>
                                                <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;
                                                        echo "<option value = '$addyear'>$addyear</option>";
                                                        $iniyear++;
                                                    }
                                                    ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label"></label>
                                        <div class="col-lg-7" style="text-align: right">
                                            <button type="submit" name="submit_activity"
                                                class="mb-xs mt-xs mr-xs btn btn-sm btn-info">Submit</button>
                                        </div>
                                    </div>
                                </form>
                                <?php } ?>
                            </div>
                            <div class="col-md-1">
                            </div>
                        </div>
                    </section>



                    <hr class="separator" />
                    <section class="panel panel-success">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>

                            <h2 class="panel-title">FUNDED RESEARCH AND CONSULTANCY</h2>
                        </header>
                        <div class="panel-body">

                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <div style="text-align: right">
                                    <a href="#addReserchModal" class="btn btn-primary btn-xs"
                                        data-toggle="modal"><span>Add New</span></a>
                                </div>
                                <?php
                                $sql = "SELECT * FROM funded_research WHERE staffid = '$staffid' ORDER BY session1";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                ?>
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th hidden="hidden">ID</th>
                                            <th>Project No</th>
                                            <th>Title of Award</th>
                                            <th>In-Kind Required by Grant</th>
                                            <th>Release Time</th>
                                            <th>Total (Amount)</th>
                                            <th>Remark</th>
                                            <th>Session</th>
                                            <th>Action</th>

                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                            while ($row = $result->fetch_assoc()) {
                                                $projt_no = $row['projt_no'];
                                                $projt_title = $row['projt_title'];
                                                $reguire_grant = $row['reguire_grant'];
                                                $release_time = $row['release_time'];
                                                //$totamount = number_format($row['totamount'], 2);
                                                $totamount = $row['totamount'];
                                                $remark1 = $row['remark1'];
                                                $id = $row['id'];
                                                $approval_research = $row['approval'];

                                                echo "<tr><td hidden='hidden'>$id</td><td>$projt_no</td><td>$projt_title</td><td>$reguire_grant</td><td>$release_time</td><td>$totamount</td><td>$remark1</td><td>$session1</td><td>";
                                                if ($approval_research == "NO") {
                                            ?>

                                        <button type='button' class='btn btn-default btn-xs editone_reserch'><i
                                                class='material-icons' data-toggle='tooltip'
                                                title='Edit'>&#xE254;</i></button>
                                        <button type='button' class='btn btn-default btn-xs delete_reserch'><i
                                                class='material-icons' data-toggle='tooltip' title='Delete'
                                                style='color: red'>&#xE872;</i></button>
                                        <?php
                                                }
                                                echo "</td></tr>";
                                            }

                                            ?>
                                    </tbody>
                                </table>
                                <?php } ?>

                            </div>
                            <div class="col-md-1">
                            </div>
                        </div>
                    </section>


                    <hr class="separator" />
                    <section class="panel panel-success">
                        <header class="panel-heading">
                            <div class="panel-actions">
                                <a href="#" class="fa fa-caret-down"></a>
                                <a href="#" class="fa fa-times"></a>
                            </div>

                            <h2 class="panel-title">COMMUNITY SERVICE (<i>Services Rendered Without Demand for
                                    Payment</i>)</h2>
                        </header>
                        <div class="panel-body">

                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <div style="text-align: right">
                                    <a href="#addCommModal" class="btn btn-primary btn-xs" data-toggle="modal"><span>Add
                                            New</span></a>
                                </div>
                                <br>
                                <?php
                                $sql = "SELECT * FROM comm_service WHERE staffid = '$staffid' ORDER BY session1";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                ?>
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th hidden="hidden">ID</th>
                                            <th>Type</th>
                                            <th>Beneficiary</th>
                                            <th>Effect</th>
                                            <th>Date</th>
                                            <th>Session</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                            while ($row = $result->fetch_assoc()) {
                                                $type_comm = $row['type_comm'];
                                                $beneficiary = $row['beneficiary'];
                                                $effect = $row['effect'];
                                                $date_comm = $row['date_comm'];
                                                $approval_comm = $row['approval'];
                                                $id = $row['id'];

                                                echo "<tr><td hidden='hidden'>$id</td><td>$type_comm</td><td>$beneficiary</td><td>$effect</td><td>$date_comm</td><td>$session1</td><td>";
                                                if ($approval_comm == "NO") {
                                            ?>

                                        <button type='button' class='btn btn-default btn-xs editone_comm'><i
                                                class='material-icons' data-toggle='tooltip'
                                                title='Edit'>&#xE254;</i></button>
                                        <button type='button' class='btn btn-default btn-xs delete_comm'><i
                                                class='material-icons' data-toggle='tooltip' title='Delete'
                                                style='color: red'>&#xE872;</i></button>

                                        <?php
                                                }
                                                echo "</td></tr>";
                                            }

                                            ?>
                                    </tbody>
                                </table>
                                <?php } ?>


                            </div>
                            <div class="col-md-1">
                            </div>
                        </div>



                    </section>

                </div>

                <!-- Staff Profile -->
                <!-- Edit Profile -->
                <div id="editModal_profile" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">

                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Profile</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">First Name: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="fname"
                                                value="<?php echo $fname ?>" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Surname: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="surname"
                                                value="<?php echo $surname ?>" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Other Names: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="othername" value="<?php echo $othernames ?>" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Appointment Type: </label>
                                        <div class="col-lg-7">
                                            <select name="apptype" class="form-control" style="color:#000000"
                                                id="apptype" required="required">
                                                <option value="<?php echo $apptype ?>"><?php echo $apptype_full ?>
                                                </option>
                                                <option value="fulltime">Full Time</option>
                                                <option value="parttime">Part Time</option>
                                                <option value="contract">Contract</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Title: </label>
                                        <div class="col-lg-7">
                                            <select name="title1" class="form-control" style="color:#000000" id="title1"
                                                required="required">
                                                <option value="<?php echo $mytitle ?>"><?php echo $mytitle ?></option>
                                                <option value="Prof">Prof</option>
                                                <option value="Dr">Dr</option>
                                                <option value="Mr">Mr</option>
                                                <option value="Mrs">Mrs</option>
                                                <option value="Miss">Miss</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">email: </label>
                                        <div class="col-lg-7">
                                            <input type="email" class="form-control" style="color:#000000" name="email1"
                                                value="<?php echo $emailAdd ?>" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Phone Number: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="phone1"
                                                value="<?php echo $phone ?>" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Position/Rank: </label>
                                        <div class="col-lg-7">
                                            <select name="postrank" class="form-control" style="color:#000000"
                                                id="postrank" required="required">
                                                <option value="<?php echo $postn_rank ?>"><?php echo $postn_rank_full ?>
                                                </option>
                                                <option value="Prof">Professor</option>
                                                <option value="assprof">Associate Professor</option>
                                                <option value="SL">Senior Lecturer</option>
                                                <option value="LI">Lecturer I</option>
                                                <option value="LII">Lecturer II</option>
                                                <option value="AL">Assistant Lecturer</option>
                                                <option value="GA">Graduate Assistant</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Step: </label>
                                        <div class="col-lg-7">
                                            <select name="stepG" class="form-control" style="color:#000000" id="stepG"
                                                required="required">
                                                <option value="<?php echo $stepG ?>"><?php echo $stepG ?></option>
                                                <option value="01">01</option>
                                                <option value="02">02</option>
                                                <option value="03">03</option>
                                                <option value="04">04</option>
                                                <option value="05">05</option>
                                                <option value="06">06</option>
                                                <option value="07">07</option>
                                                <option value="08">08</option>
                                                <option value="09">09</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                                <option value="13">13</option>
                                                <option value="14">14</option>
                                                <option value="15">15</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Leave of Absent/ Study Leave: </label>
                                        <div class="col-lg-7">
                                            <select name="leaveabsent" class="form-control" style="color:#000000"
                                                id="leaveabsent" required="required">
                                                <option value="<?php echo $leaveabsent_study ?>">
                                                    <?php echo $leaveabsent_study_full ?></option>
                                                <option value="No">No</option>
                                                <option value="leaveabsent">Leave of Absent</option>
                                                <option value="studyleave">Study Leave</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Area of Specialization: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="area_special" value="<?php echo $area_special ?>"
                                                required="required">
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="updatesingle_profile" class="btn btn-info" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                <!-- ADMINISTRATIVE DUTIES -->

                <!-- Add New Duties -->

                <!-- Edit Modal Duties -->

                <!-- Delete Modal Duties -->
                <div id="deleteModal_duties" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Adminisrative Duties</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id" id="delete_id">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_duties" class="btn btn-danger"
                                        value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>



                <!-- FUNDED RESERCH AND CONSULTANCY -->
                <!-- Add New Modal Reserach -->
                <div id="addReserchModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="post" action="">
                                <div class="modal-header">
                                    <h4 class="modal-title">Add New Funded Reserch and Consultancy</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Project No: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="projectNo" value="" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Title of Award: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="awardTitle" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">In-Kind Required by Grant: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="InKindReq" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Release Time: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control"
                                                    name="ReleaseTime" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Total(Amount): </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="amount"
                                                value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Remark: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="remark"
                                                value="" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" class="btn btn-success" name="addnew_reserch" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Edit Modal Reserch -->
                <div id="editModal_reserch" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <input type="hidden" name="update_id" id="update_id">
                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Record</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Project No: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="projectNo" id="projectNo" value="" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Title of Award: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="awardTitle" id="awardTitle" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">In-Kind Required by Grant: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="InKindReq" id="InKindReq" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Release Time: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control"
                                                    name="ReleaseTime" id="ReleaseTime" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Total(Amount): </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="amount"
                                                id="amount" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Remark: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="remark"
                                                id="remark" value="" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="updatesingle_reserch" class="btn btn-info" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Delete Modal Reserch -->
                <div id="deleteModal_reserch" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Reserch and Consultancy</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id" id="delete_id">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_reserch" class="btn btn-danger"
                                        value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>



                <!-- COMMUNITY SERVICE -->

                <!-- Add New Modal Community -->
                <div id="addCommModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="post" action="">
                                <div class="modal-header">
                                    <h4 class="modal-title">Add New Community Service</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Type: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="type_comm" id="type_comm" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Beneficiary: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="beneficiary" id="beneficiary" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Effect: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="effect"
                                                id="effect" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Date: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control"
                                                    name="dateExecute" id="dateExecute" required="required">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" class="btn btn-success" name="addnew_Comm" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Edit Modal Community -->
                <div id="editModal_comm" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <input type="hidden" name="update_id" id="update_id">
                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Record</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Type: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="type_comm" id="type_comm" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Beneficiary: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000"
                                                name="beneficiary" id="beneficiary" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Effect: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="effect"
                                                id="effect" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Date: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control"
                                                    name="dateExecute" id="dateExecute" required="required">
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="updatesingle_comm" class="btn btn-info" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Delete Modal Community -->
                <div id="deleteModal_comm" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Community Service</h4>
                                    <button type="button" class="close" data-dismiss="modal"
                                        aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id" id="delete_id">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_comm" class="btn btn-danger" value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>



                <!-- end: page -->
            </section>
        </div>


    </section>

    <!--Print Start-->
    <div id="printablediv" style="width: 100%; height: 200px;" hidden="hidden">
        <center><strong>
                <h3>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</h3>
            </strong></center>
        <center><strong>
                <h4>STUDENT'S ACADEMIC RECORD</h4>
            </strong></center>



    </div>

    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>

    <script type="text/javascript">
    $(document).ready(function() {
        $("select.activit").change(function() {
            var selectedState = $(".activit option:selected").val();
            $.ajax({
                type: "POST",
                url: 'ajax_save_rec/ajaxDataProfile.php',
                data: {
                    activit: selectedState
                }
            }).done(function(data) {
                $("#GetResponse").html(data);
            });
        });
    });
    </script>

    <!-- Administrative Duties -->
    <script>
    $(document).ready(function() {

        $('.delete_duties').on('click', function() {

            $('#deleteModal_duties').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);

            $('#delete_id').val(data[0]);

        });
    });
    </script>

    <!-- Community Service -->
    <script>
    $(document).ready(function() {

        $('.delete_comm').on('click', function() {

            $('#deleteModal_comm').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);

            $('#delete_id').val(data[0]);

        });
    });
    </script>

    <script>
    $(document).ready(function() {

        $('.editone_comm').on('click', function() {

            $('#editModal_comm').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);

            $('#update_id').val(data[0]);
            $('#type_comm').val(data[1]);
            $('#beneficiary').val(data[2]);
            $('#effect').val(data[3]);
            $('#dateExecute').val(data[4]);

        });
    });
    </script>


    <!-- Reserch and Consultancy -->
    <script>
    $(document).ready(function() {

        $('.delete_reserch').on('click', function() {

            $('#deleteModal_reserch').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);

            $('#delete_id').val(data[0]);

        });
    });
    </script>

    <script>
    $(document).ready(function() {

        $('.editone_reserch').on('click', function() {

            $('#editModal_reserch').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);

            $('#update_id').val(data[0]);
            $('#projectNo').val(data[1]);
            $('#awardTitle').val(data[2]);
            $('#InKindReq').val(data[3]);
            $('#ReleaseTime').val(data[4]);
            $('#amount').val(data[5]);
            $('#remark').val(data[6]);

        });
    });
    </script>

</body>

</html>
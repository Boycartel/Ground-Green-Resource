<?php
	session_start();
?>

<br /><br /><br />
<center><strong><h1>SORRY</h1></strong></center>
<br /><br />
<center><strong><h4><?php echo $_SESSION['widregid'] ?></h4></strong></center>
<center><strong><h4><?php echo $_SESSION['widnames'] ?></h4></strong></center>
<center><strong><h3 style="color:#F00">You have been Withdrawn from the University Since</h3></strong></center>
<center><strong><h4><?php echo $_SESSION['widdate'] ?></h4></strong></center>
<?php
require_once '../includes/db_connect2.php';
$dept = $_SESSION['deptcode'];

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

if (isset($_POST["pk"])) {
    if ($_SESSION['yesCurri'] == "YES") {
        $curri = $_SESSION['curri'];
        if ($curri == "OLD") {
            $curri2 = "";
        } else {
            $curri2 = "_" . $curri;
        }
        if (($_POST['name'] == "Core" && $_POST["value"] == "YES") || ($_POST['name'] == "CoreDE200" && $_POST["value"] == "YES") || ($_POST['name'] == "CoreDE300" && $_POST["value"] == "YES")) {
            echo $query = "UPDATE gencourses" . $curri2 . " SET Relevant = 'YES' WHERE id = '" . $_POST["pk"] . "'";
            $conn_stu->query($query);
        }
        echo $query = "UPDATE gencourses" . $curri2 . " SET " . $_POST['name'] . " = '" . $_POST["value"] . "' WHERE id = '" . $_POST["pk"] . "'";
        $conn_stu->query($query);
    } else {
        if (($_POST['name'] == "Core" && $_POST["value"] == "YES") || ($_POST['name'] == "CoreDE200" && $_POST["value"] == "YES") || ($_POST['name'] == "CoreDE300" && $_POST["value"] == "YES")) {
            echo $query = "UPDATE gencourses SET Relevant = 'YES' WHERE id = '" . $_POST["pk"] . "'";
            $conn_stu->query($query);
        }
        echo $query = "UPDATE gencourses SET " . $_POST['name'] . " = '" . $_POST["value"] . "' WHERE id = '" . $_POST["pk"] . "'";
        $conn_stu->query($query);
    }

    $conn_stu->close();
    //echo 'done';
}

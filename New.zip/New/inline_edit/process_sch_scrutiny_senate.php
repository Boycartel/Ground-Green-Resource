<?php
require_once '../includes/db_connect2.php';

$getdept = $_SESSION['dept_sctny'];
$apprFormat = $_SESSION['apprFormat'];

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$dept_db = $_SESSION['deptdb'] . strtolower($getdept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}

if (isset($_POST["pk"])) {

    $sql = "SELECT * FROM scrutiny_senate WHERE sn = '" . $_POST["pk"] . "'";
    $result = $conn_stu->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $regid = $row["Regn"];
        }
    }


    if ($apprFormat == "Scrutiny") {
        if ($_POST["value"] == "Approve") {
            echo $query = "UPDATE scrutiny_senate SET " . $_POST['name'] . " = '" . $_POST["value"] . "', graduated = 'YES' WHERE sn = '" . $_POST["pk"] . "'";
            $conn_stu->query($query);


            echo $query2 = "UPDATE std_data_view SET status = 12 WHERE matric_no = '$regid'";
            $conn2->query($query2);
        } else {

            echo $query = "UPDATE scrutiny_senate SET " . $_POST['name'] . " = '" . $_POST["value"] . "', graduated = 'NO' WHERE sn = '" . $_POST["pk"] . "'";
            $conn_stu->query($query);

            echo $query2 = "UPDATE std_data_view SET status = 6 WHERE matric_no = '$regid'";
            $conn2->query($query2);
        }
    } else {
        echo $query = "UPDATE scrutiny_senate SET " . $_POST['name'] . " = '" . $_POST["value"] . "' WHERE sn = '" . $_POST["pk"] . "'";
        $conn_stu->query($query);
    }
    $conn->close();
    $conn2->close();
    $conn_stu->close();

    //echo 'done';
}

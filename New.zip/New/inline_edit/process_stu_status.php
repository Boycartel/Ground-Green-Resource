<?php
require_once '../includes/db_connect2.php';
if (isset($_POST["pk"])) {

    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }

    $dept = $_SESSION["deptcode"];
    echo $query = "UPDATE std_data_view SET " . $_POST['name'] . " = '" . $_POST["value"] . "' WHERE id = '" . $_POST["pk"] . "'";
    $conn2->query($query);

    $conn2->close();

    /*  if ($_SESSION['deptoption'] == "YES") {
        $getOpt = $_POST["value"];
        $sql = "SELECT entry_session, matric_no FROM std_data_view WHERE id = '" . $_POST["pk"] . "'";
        $result = $conn2->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $regid = $row["matric_no"];
                $entry_session = $row["entry_session"];
            }
        }

        $dept_db = $_SESSION['deptdb'] . $dept;
        $conn_stu = new mysqli($_SESSION['servername'], $_SESSION['db_username'], $_SESSION['db_password'], $dept_db);
        if ($conn_stu->connect_error) {
            die("Connection failed: " . $conn_stu->connect_error);
        }

        do {
            $SessCount = 0;
            $IntYearAdmit = substr($entry_session, 0, 4);
            $sessionpres = $IntYearAdmit . "/" . ($IntYearAdmit + 1);
            $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionpres'";
            $result = $conn->query($sql);
            $Add1 = 0;
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $Add1++;
                }
            }
            if ($Add1 == 0) {
                $SessCount = $SessCount + 1;
                $StuSession[$SessCount] = $sessionpres;
            }

            if ($StuSession[$SessCount] == $GetTheSession) {
                break;
            }

            $IntYearAdmit = $IntYearAdmit + 1;
        } while ($SessCount < 10);

        for ($j = 1; $j <= $SessCount; $j++) {

            $StuCurSess = str_ireplace("/", "_", $StuSession[$j]);

            $deptcorreg = "correg_" . $StuCurSess;
            $sql4 = "UPDATE " . $deptcorreg . " SET deptOption ='$getOpt' WHERE Regn1 = '$regid'";
            $result4 = $conn->query($sql4);
        }
    } */
}

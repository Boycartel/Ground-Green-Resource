<?php
require_once '../includes/db_connect2.php';

if (isset($_POST["pk"])) {
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SESSION['InstType'] == "University") {
        echo $query = "UPDATE requirement_tab SET " . $_POST['name'] . " = '" . $_POST["value"] . "' WHERE id = '" . $_POST["pk"] . "'";
    } elseif ($_SESSION['InstType'] == "Polytechnic") {
        echo $query = "UPDATE requirement_tab_poly SET " . $_POST['name'] . " = '" . $_POST["value"] . "' WHERE id = '" . $_POST["pk"] . "'";
    }

    $conn->query($query);
    $conn->close();
    //echo 'done';
}

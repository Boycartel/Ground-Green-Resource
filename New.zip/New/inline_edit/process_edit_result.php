<?php
require_once '../includes/db_connect2.php';

$dept = $_SESSION['deptcode'];

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}
if (isset($_POST["pk"])) {
    //echo $query = "UPDATE correg SET ".$_POST['name']." = '".$_POST["value"]."' WHERE id = '".$_POST["pk"]."'";
    //$conn_stu->query($query);


}
$conn_stu->close();

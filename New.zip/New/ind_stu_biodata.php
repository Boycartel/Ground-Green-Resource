<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

if ($_SESSION['Administrator'] !== "YES") {
    header('Location:home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    < </head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Profile</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Student Biodata
                            </li>
                            <li class="active">
                                <strong>Undergraduate</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <div class="wrapper wrapper-content">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="row animated fadeInRight">
                        <!-- <div class="row">
                            <form class="form-horizontal form-bordered" method="post">
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Matric Number: </label>
                                    <div class="col-lg-5">
                                        <input type="text" class="form-control" style="color:#000000" name="regid">
                                    </div>
                                    <div class="col-lg-3">
                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                    </div>
                                </div>
                            </form>
                        </div> 

                        <hr class="separator" />
                        -->
                        <?php
                        if (isset($_POST["view"])) {
                            $id = $_POST["id"];
                            $_SESSION["id"] = $id;
                        } else {
                            $id = $_SESSION["id"];
                        }

                        $sql = "SELECT * FROM std_data_view WHERE id = '$id'";
                        $result = $conn2->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $stdid = $row["stdid"];
                                $regid = $row["matric_no"];
                                $surname = $row["surname"];
                                $firstname = $row["first_name"];
                                $othername = $row["other_name"];
                                $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                $jambno = $row["jamb_appl_no"];
                                $stateorigin = $row["state"];
                                $lga = $row["lga"];
                                $sex = $row["gender"];
                                $permaddres = $row["p_address"];
                                $contaddres = $row["c_address"];
                                $nationality = $row["nationality"];
                                $dob = $row["dob"];
                                $pob = "XX";
                                $phone1 = $row["phone_number"];
                                $maried = $row["marital_status"];
                                $email = $row["sch_email"];
                                $studept = $row["dept_code"];
                                $deptname = $row["department"];
                                $stuschool = $row["school_code"];
                                $schname = $row["school"];
                                $next_name = $row["next_name"];
                                $next_rel = $row["next_rel"];
                                $next_addr = $row["next_addr"];
                                $next_phone = $row["next_phone"];
                                $next_email = $row["next_email"];
                                $blood_group = $row["blood_group"];
                                $defer1st = $row["defer1styear"];
                                $entry_session = $row['entry_session'];

                                $f_examtype = $row['f_examtype'];
                                $f_examdate = $row['f_examdate'];
                                $f_examno = $row['f_examno'];
                                $s_examtype = $row['s_examtype'];
                                $s_examdate = $row['s_examdate'];
                                $s_examno = $row['s_examno'];

                                $s_rslt1 = $row['s_rslt1'];
                                $s_rslt2 = $row['s_rslt2'];
                                $s_rslt3 = $row['s_rslt3'];
                                $s_rslt4 = $row['s_rslt4'];
                                $s_rslt5 = $row['s_rslt5'];
                                $s_rslt6 = $row['s_rslt6'];
                                $s_rslt7 = $row['s_rslt7'];
                            }
                        }
                        $sql = "SELECT * FROM std_login WHERE stdid = '$stdid'";
                        $result = $conn2->query($sql);
                        if ($result->num_rows > 0) {
                            $passportid = $stdid;
                        } else {
                            $passportid = $regid;
                        }



                        ?>


                        <div class="col-md-5">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>Profile</h5>
                                </div>
                                <div>
                                    <div class="ibox-content no-padding border-left-right" style="text-align: center;">
                                        <?php
                                        $matpassport = str_replace("/", "_", $regid);
                                        echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='200' height='250'>";

                                        ?>
                                    </div>
                                    <div class="ibox-content profile-content">
                                        <table class="table table-hover margin">
                                            <tbody>
                                                <tr>
                                                    <th>Matric Number:</th>
                                                    <td><?php echo $regid ?></td>
                                                </tr>
                                                <tr>
                                                    <th>First Name:</th>
                                                    <td><?php echo ucwords(strtolower($firstname)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Other Name(s):</th>
                                                    <td><?php echo ucwords(strtolower($othername)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Surname:</th>
                                                    <td><?php echo ucwords(strtolower($surname)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Faculty/School:</th>
                                                    <td><?php echo ucwords(strtolower($schname)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Department:</th>
                                                    <td><?php echo ucwords(strtolower($deptname)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>JAMB No:</th>
                                                    <td><?php echo $jambno ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Nationality:</th>
                                                    <td><?php echo ucwords(strtolower($nationality)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>State:</th>
                                                    <td><?php echo ucwords(strtolower($stateorigin)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>LGA:</th>
                                                    <td><?php echo ucwords(strtolower($lga)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Gender:</th>
                                                    <td><?php echo $sex ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Parmanent Home Address:</th>
                                                    <td><?php echo ucwords(strtolower($permaddres)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Contact Address:</th>
                                                    <td><?php echo ucwords(strtolower($contaddres)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Date of Birth:</th>
                                                    <td><?php echo $dob ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Place of Birth:</th>
                                                    <td><?php echo $pob ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Phone No:</th>
                                                    <td><?php echo $phone1 ?></td>
                                                </tr>
                                                <tr>
                                                    <th>email:</th>
                                                    <td><?php echo $email ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Marital Status:</th>
                                                    <td><?php echo ucwords(strtolower($maried)) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Blood Group:</th>
                                                    <td><?php echo $blood_group ?></td>
                                                </tr>

                                            </tbody>
                                        </table>
                                        <br>
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <strong>Next of Kin:</strong>
                                            </div>
                                            <div class="col-lg-8">
                                                <table class="table table-hover margin bottom">
                                                    <tbody>

                                                        <tr>
                                                            <th>Name:</th>
                                                            <td><?php echo $next_name ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Relationship:</th>
                                                            <td><?php echo $next_rel ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Address:</th>
                                                            <td><?php echo $next_addr ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>email:</th>
                                                            <td><?php echo $next_email ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Phone:</th>
                                                            <td><?php echo $next_phone ?></td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <br>
                                        <h2 style="text-align: center;"><strong>Secondary School Results</strong></h2>
                                        <table class="table table-hover margin">
                                            <tbody>
                                                <tr>
                                                    <th>1<sup>st</sup> Exam Type:</th>
                                                    <td><?php echo $f_examtype ?></td>
                                                </tr>
                                                <tr>
                                                    <th>1<sup>st</sup> Exam Date:</th>
                                                    <td><?php echo $f_examdate ?></td>
                                                </tr>
                                                <tr>
                                                    <th>1<sup>st</sup> Exam Number:</th>
                                                    <td><?php echo $f_examno ?></td>
                                                </tr>
                                                <tr>
                                                    <th>2<sup>nd</sup> Exam Type:</th>
                                                    <td><?php echo $s_examtype ?></td>
                                                </tr>
                                                <tr>
                                                    <th>2<sup>nd</sup> Exam Date:</th>
                                                    <td><?php echo $s_examdate ?></td>
                                                </tr>
                                                <tr>
                                                    <th>2<sup>nd</sup> Exam Number:</th>
                                                    <td><?php echo $s_examno ?></td>
                                                </tr>
                                            </tbody>
                                        </table>

                                        <div class="row">
                                            <div class="col-lg-4">
                                                <strong>Results:</strong>
                                            </div>
                                            <div class="col-lg-8">
                                                <table class="table table-hover margin bottom">
                                                    <tbody>

                                                        <tr>
                                                            <td>1</td>
                                                            <td><?php echo $s_rslt1 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>2</td>
                                                            <td><?php echo $s_rslt2 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>3</td>
                                                            <td><?php echo $s_rslt3 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>4</td>
                                                            <td><?php echo $s_rslt4 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>5</td>
                                                            <td><?php echo $s_rslt5 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>6</td>
                                                            <td><?php echo $s_rslt6 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>7</td>
                                                            <td><?php echo $s_rslt7 ?></td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>Uploads</h5>

                                </div>
                                <div class="ibox-content">
                                    <div class="ibox float-e-margins">

                                        <div class="lightBoxGallery">

                                            <div class="item gallery">
                                                <div class="row">
                                                    <div class="col-sm-6 frame">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Pri_Leaving Cert.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">Primary Leaving
                                                            Certificate</strong>
                                                    </div>
                                                    <div class="col-sm-6 frame">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Olevel_1st.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">1<sup>st</sup> O' Level
                                                            Certificate</strong>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6 frame">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Olevel_2nd.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">2<sup>nd</sup> O' Level
                                                            Certificate</strong>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Signed accep_letter.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">Signed Acceptance
                                                            Letter</strong>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Birth Cert_Declr_age.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">Declaration of Age</strong>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Birth Certificate.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">Birth Certificate</strong>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Indigen Letter.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">Indegen Letter</strong>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Jamb Adm_letter.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">JAMB Admission
                                                            Letter</strong>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_JAMB Result.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">JAMB Result</strong>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_UTME_slip.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">UTME Slip</strong>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Jamb Result_DE_Slip.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">JAMB Result DE Slip</strong>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_State_Of_Origin.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">State Indegen
                                                            Letter</strong>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <?php
                                                        $stu_cred_folder = $_SESSION['stu_cred_folder'];
                                                        $credfile = str_replace("/", "", $passportid) . "_Med_cert_fitness.jpg";
                                                        echo "<img alt='' class='img-responsive' src='$stu_cred_folder/$credfile' width='400' height='600'>";
                                                        ?>
                                                        <strong style="text-align: center;">Medical Certificate of
                                                            Fitness</strong>
                                                    </div>
                                                    <div class="col-sm-6">

                                                    </div>


                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>
                </div>




            </div>
        </div>
        <!-- <div class="footer">
            <?php
            //include_once 'includes/footer2.php';
            ?>
        </div> -->
    </div>
    <div id="right-sidebar">

        <?php
        include_once 'includes/aside_right.php';
        ?>

    </div>



    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
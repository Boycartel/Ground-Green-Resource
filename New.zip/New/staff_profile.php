<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';


?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>My Profile</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>My Profile</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }

                    $conn7 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE7);
                    if ($conn7->connect_error) {
                        die("Connection failed: " . $conn7->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            My Profile
                        </div>
                        <div class="panel-body">
                            <!-- start: page -->
                            <div class="row">

                                <?php
                                $staffid = $_SESSION['staffid'];
                                $corntsession = $_SESSION['corntsession'];
                                $cursemester = $_SESSION['cursemester'];
                                $dept = $_SESSION['deptcode'];

                                if (isset($_POST["update_profile"])) {
                                    // $fname = str_replace("'", "", $_POST['fname']);
                                    // $fname = htmlspecialchars(strtoupper($_POST['fname']), ENT_QUOTES);

                                    // $surname = str_replace("'", "", $_POST['surname']);
                                    // $surname = htmlspecialchars(strtoupper($_POST['surname']), ENT_QUOTES);

                                    // $othername = str_replace("'", "", $_POST['othername']);
                                    // $othername = htmlspecialchars(strtoupper($_POST['othername']), ENT_QUOTES);


                                    $email1 = str_replace("'", "", $_POST['email1']);
                                    //$email1 = filter_var($email1, FILTER_SANITIZE_EMAIL);
                                    $email1 = filter_var($email1, FILTER_SANITIZE_EMAIL, FILTER_VALIDATE_EMAIL);
                                    $phone1 = str_replace("'", "", $_POST['phone1']);
                                    $phone1 = filter_var($phone1, FILTER_SANITIZE_NUMBER_INT);
                                    $phone2 = str_replace("'", "", $_POST['phone2']);
                                    $phone2 = filter_var($phone2, FILTER_SANITIZE_NUMBER_INT);
                                    $area_special = str_replace("'", "", $_POST['area_special']);
                                    $area_special = htmlspecialchars($_POST['area_special'], ENT_QUOTES);

                                    $marrystatus = htmlspecialchars($_POST['marrystatus'], ENT_QUOTES);
                                    $religion = htmlspecialchars($_POST['religion'], ENT_QUOTES);
                                    $nationality = htmlspecialchars($_POST['nationality'], ENT_QUOTES);
                                    if ($nationality == "Nigerian") {
                                        $country = "NO";
                                    } else {
                                        $country = htmlspecialchars($_POST['country'], ENT_QUOTES);
                                    }

                                    $stateOfOrigin = htmlspecialchars($_POST['stateOfOrigin'], ENT_QUOTES);
                                    $lga = htmlspecialchars($_POST['lga'], ENT_QUOTES);
                                    $healthstatus = htmlspecialchars($_POST['healthstatus'], ENT_QUOTES);
                                    if ($healthstatus == "Nill") {
                                        $healthtype = "NO";
                                    } else {
                                        $healthtype = htmlspecialchars($_POST['healthtype'], ENT_QUOTES);
                                    }


                                    $accommtype = htmlspecialchars($_POST['accommtype'], ENT_QUOTES);
                                    $datebirth = htmlspecialchars($_POST['datebirth'], ENT_QUOTES);
                                    $placebirth = htmlspecialchars($_POST['placebirth'], ENT_QUOTES);
                                    $permaddress = htmlspecialchars($_POST['permaddress'], ENT_QUOTES);
                                    $contaddress = htmlspecialchars($_POST['contaddress'], ENT_QUOTES);
                                    $datefirstapp = htmlspecialchars($_POST['datefirstapp'], ENT_QUOTES);
                                    $FApptMonth = date('F', strtotime($datefirstapp));
                                    $FApptYear = date('Y', strtotime($datefirstapp));
                                    $datepresapp = htmlspecialchars($_POST['datepresapp'], ENT_QUOTES);
                                    $bankname = htmlspecialchars($_POST['bankname'], ENT_QUOTES);
                                    $bankbranch = htmlspecialchars($_POST['bankbranch'], ENT_QUOTES);
                                    $bankaccount = htmlspecialchars($_POST['bankaccount'], ENT_QUOTES);
                                    $highquali = htmlspecialchars($_POST['highquali'], ENT_QUOTES);

                                    $nextkinname = htmlspecialchars($_POST['nextkinname'], ENT_QUOTES);
                                    $nextkinrelation = htmlspecialchars($_POST['nextkinrelation'], ENT_QUOTES);
                                    $nextkinadress = htmlspecialchars($_POST['nextkinadress'], ENT_QUOTES);
                                    $nextkinphone = htmlspecialchars($_POST['nextkinphone'], ENT_QUOTES);

                                    $apptype = $_POST['apptype'];
                                    $title1 = $_POST['title1'];
                                    $postrank = $_POST['postrank'];
                                    $leaveabsent = $_POST['leaveabsent'];
                                    $stepG = $_POST['stepG'];

                                    if ($postrank == "Prof") {
                                        $salary_grade = "A07";
                                    } elseif ($postrank == "assprof") {
                                        $salary_grade = "A06";
                                    } elseif ($postrank == "SL") {
                                        $salary_grade = "A05";
                                    } elseif ($postrank == "LI") {
                                        $salary_grade = "A04";
                                    } elseif ($postrank == "LII") {
                                        $salary_grade = "A03";
                                    } elseif ($postrank == "AL") {
                                        $salary_grade = "A02";
                                    } else {
                                        $salary_grade = "A01";
                                    }

                                    $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$staffid'";
                                    $result = $conn7->query($sql);
                                    $i = 0;
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $i++;
                                        }
                                    }

                                    if ($i == 0) {
                                        $sql = "INSERT INTO staff_profile_edit (PSN) VALUE ('$staffid')";
                                        //$sql = "INSERT INTO staff_profile_edit (PSN, sname, fname, oname, title, Status, leaveabsent_study, Rank1, area_special, GradeL, StepG, phonenumber, phonenumber2) VALUE ('$staffid', '$surname', '$fname', '$othername', '$title1', '$apptype', '$leaveabsent', '$postrank', '$area_special', '$salary_grade', '$stepG', '$phone1', '$phone2')";
                                        $result = $conn7->query($sql);
                                    }

                                    //$sql = "UPDATE staff_profile_edit SET sname = '$surname', fname = '$fname', oname = '$othername', title = '$title1', Status = '$apptype', leaveabsent_study = '$leaveabsent', Rank1 = '$postrank', area_special = '$area_special', GradeL = '$salary_grade', StepG = '$stepG', phonenumber = '$phone1', phonenumber2 = '$phone2' WHERE PSN = '$staffid'";
                                    //$result = $conn7->query($sql);

                                    $sql = "UPDATE staff_profile_edit SET  title = '$title1', email = '$email1', Status = '$apptype', leaveabsent_study = '$leaveabsent', Rank1 = '$postrank', area_special = '$area_special', GradeL = '$salary_grade', StepG = '$stepG', phonenumber = '$phone1', phonenumber2 = '$phone2' WHERE PSN = '$staffid'";
                                    $result = $conn7->query($sql);

                                    $sql = "UPDATE staff_profile_edit SET maritalstatus = '$marrystatus', religion = '$religion', nationality = '$nationality', stateOfOrigin = '$stateOfOrigin', country = '$country', LGA = '$lga', healthstatus = '$healthstatus', healthtype = '$healthtype' WHERE PSN = '$staffid'";
                                    $result = $conn7->query($sql);

                                    $sql = "UPDATE staff_profile_edit SET accommodation = '$accommtype', DateBirth = '$datebirth', placebirth = '$placebirth', ParmtAdress = '$permaddress', ContAdd = '$contaddress', FApptDate = '$datefirstapp', FApptMonth = '$FApptMonth', FApptYear = '$FApptYear', PApptDate = '$datepresapp', Bank = '$bankname', Branch = '$bankbranch', AccNo = '$bankaccount', HQualificatn = '$highquali' WHERE PSN = '$staffid'";
                                    $result = $conn7->query($sql);

                                    $sql = "UPDATE staff_profile_edit SET nextname = '$nextkinname', nextrelation = '$nextkinrelation', nextaddress = '$nextkinadress', nextphone = '$nextkinphone' WHERE PSN = '$staffid'";
                                    $result = $conn7->query($sql);

                                    $sql = "UPDATE staff_profile SET newrec = 'YES' WHERE PSN = '$staffid'";
                                    $result = $conn7->query($sql);

                                    $sql = "UPDATE users SET mytitle = '$title1', apptype = '$apptype', leaveabsent_study = '$leaveabsent', postn_rank = '$postrank', area_special = '$area_special', emailAdd = '$email1', phone = '$phone1' WHERE staffid = '$staffid'";
                                    $result = $conn->query($sql);
                                }


                                if (isset($_POST["addnew_reserch"])) {
                                    $projectNo = htmlspecialchars(strtoupper($_POST['projectNo']), ENT_QUOTES);
                                    $awardTitle = htmlspecialchars($_POST['awardTitle'], ENT_QUOTES);
                                    $InKindReq = htmlspecialchars($_POST['InKindReq'], ENT_QUOTES);
                                    $ReleaseTime = htmlspecialchars($_POST['ReleaseTime'], ENT_QUOTES);
                                    $amount = str_replace("'", "", $_POST['amount']);
                                    $amount = filter_var($amount, FILTER_SANITIZE_NUMBER_FLOAT);
                                    //$remark = str_replace("'", "", $_POST['remark']);
                                    //$remark = filter_var($remark, FILTER_SANITIZE_STRING);
                                    $remark = htmlspecialchars($_POST['remark'], ENT_QUOTES);

                                    $sql = "INSERT INTO funded_research (staffid, projt_no, projt_title, reguire_grant, release_time, totamount, remark1, session1) VALUE ('$staffid', '$projectNo', '$awardTitle', '$InKindReq', '$ReleaseTime', '$amount', '$remark', '$corntsession')";
                                    $result = $conn7->query($sql);
                                }

                                if (isset($_POST["updatesingle_reserch"])) {
                                    $id = $_POST['update_id_research'];
                                    $projectNo = htmlspecialchars(strtoupper($_POST['projectNo']), ENT_QUOTES);
                                    $awardTitle = htmlspecialchars($_POST['awardTitle'], ENT_QUOTES);
                                    $InKindReq = htmlspecialchars($_POST['InKindReq'], ENT_QUOTES);
                                    $ReleaseTime = htmlspecialchars($_POST['ReleaseTime'], ENT_QUOTES);
                                    $amount = str_replace("'", "", $_POST['amount']);
                                    $amount = filter_var($amount, FILTER_SANITIZE_NUMBER_FLOAT);
                                    $remark = htmlspecialchars($_POST['remark'], ENT_QUOTES);

                                    $sql = "UPDATE funded_research SET projt_no = '$projectNo', projt_title = '$awardTitle', reguire_grant = '$InKindReq', release_time = '$ReleaseTime', totamount = '$amount', remark1 = '$remark' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }

                                if (isset($_POST["deletesingle_reserch"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['delete_id_research'];

                                    $sql = "DELETE FROM funded_research WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }


                                if (isset($_POST["addnew_child"])) {
                                    $childname = htmlspecialchars($_POST['childname'], ENT_QUOTES);
                                    $childsex = htmlspecialchars($_POST['childsex'], ENT_QUOTES);
                                    $childdate = htmlspecialchars($_POST['childdate'], ENT_QUOTES);

                                    $sql = "INSERT INTO children (fileno, childname, datebirth, sex1) VALUE ('$staffid', '$childname', '$childdate', '$childsex')";
                                    $result = $conn7->query($sql);
                                }

                                if (isset($_POST["updatesingle_child"])) {
                                    $id = $_POST['update_id_child'];
                                    $childname = htmlspecialchars($_POST['childname'], ENT_QUOTES);
                                    $childsex = htmlspecialchars($_POST['childsex'], ENT_QUOTES);
                                    $childdate = htmlspecialchars($_POST['childdate'], ENT_QUOTES);

                                    $sql = "UPDATE children SET childname = '$childname', datebirth = '$childdate', sex1 = '$childsex' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }

                                if (isset($_POST["deletesingle_child"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['delete_id_child'];

                                    $sql = "DELETE FROM children WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }


                                if (isset($_POST["addnew_profbody"])) {
                                    $profbodyname = htmlspecialchars($_POST['profbodyname'], ENT_QUOTES);
                                    $profbodydate = htmlspecialchars($_POST['profbodydate'], ENT_QUOTES);

                                    $sql = "INSERT INTO professional_body (fileno, profname, profdate) VALUE ('$staffid', '$profbodyname', '$profbodydate')";
                                    $result = $conn7->query($sql);
                                }

                                if (isset($_POST["updatesingle_profbody"])) {
                                    $id = $_POST['update_id_profbody'];
                                    $profbodyname = htmlspecialchars($_POST['profbodyname'], ENT_QUOTES);
                                    $profbodydate = htmlspecialchars($_POST['profbodydate'], ENT_QUOTES);

                                    $sql = "UPDATE professional_body SET profname = '$profbodyname', profdate = '$profbodydate' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }

                                if (isset($_POST["deletesingle_profbody"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['delete_id_profbody'];

                                    $sql = "DELETE FROM professional_body WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }


                                if (isset($_POST["addnew_Comm"])) {

                                    $type_comm = htmlspecialchars($_POST['type_comm'], ENT_QUOTES);
                                    $beneficiary = htmlspecialchars($_POST['beneficiary'], ENT_QUOTES);
                                    $effect = htmlspecialchars($_POST['effect'], ENT_QUOTES);
                                    $dateExecute = htmlspecialchars($_POST['dateExecute'], ENT_QUOTES);

                                    $sql = "INSERT INTO comm_service (staffid, type_comm, beneficiary, effect, date_comm, session1) VALUE ('$staffid', '$type_comm', '$beneficiary', '$effect', '$dateExecute', '$corntsession')";
                                    $result = $conn7->query($sql);
                                }


                                if (isset($_POST["updatesingle_comm"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['update_id_comm'];
                                    $type_comm = htmlspecialchars($_POST['type_comm'], ENT_QUOTES);
                                    $beneficiary = htmlspecialchars($_POST['beneficiary'], ENT_QUOTES);
                                    $effect = htmlspecialchars($_POST['effect'], ENT_QUOTES);
                                    $dateExecute = htmlspecialchars($_POST['dateExecute'], ENT_QUOTES);

                                    $sql = "UPDATE comm_service SET type_comm = '$type_comm', beneficiary = '$beneficiary', effect = '$effect', date_comm = '$dateExecute' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }

                                if (isset($_POST["deletesingle_comm"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['delete_id_comm'];

                                    $sql = "DELETE FROM comm_service WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }

                                if (isset($_POST["submit_activity"])) {
                                    $activit_code = $_POST['typeactivit'];
                                    $activyear = $_POST['activyear'];
                                    $sql = "SELECT * FROM resp_table WHERE repcode = '$activit_code'";
                                    $result = $conn7->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $reptitle = $row['reptitle'];
                                        }
                                    }

                                    if ($activit_code == "15" || $activit_code == "18" || $activit_code == "19") {
                                        $specify = $_POST['specify'];
                                    } else {
                                        $specify = "NO";
                                    }
                                    $sql = "INSERT INTO admin_duties (staffid, activit_code, activity_type, year1, specify, session1) VALUE ('$staffid', '$activit_code', '$reptitle', '$activyear', '$specify', '$corntsession')";
                                    $result = $conn7->query($sql);

                                    $lstID = "";
                                    $sql = "SELECT * FROM admin_duties WHERE staffid = '$staffid' AND activit_code = '$activit_code' ORDER BY id DESC";
                                    $result = $conn7->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $lstID = $row['id'];
                                            break;
                                        }
                                    }

                                    if (count($_FILES) > 0) {

                                        if (is_uploaded_file($_FILES['uploaded_resp']['tmp_name'])) {

                                            $imgData = addslashes(file_get_contents($_FILES['uploaded_resp']['tmp_name']));
                                            $imageProperties = getimageSize($_FILES['uploaded_resp']['tmp_name']);
                                            $imageID = $staffid . "_" . $activit_code . "_" . $lstID;

                                            $sql = "INSERT INTO " . $dept . " (staffid, imageid, imageType, imageData, imagetitle, from_cert) VALUE ('$staffid', '$imageID', '{$imageProperties['mime']}', '{$imgData}', '$reptitle', 'YES')";
                                            $result = $conn12->query($sql);
                                        }
                                    }
                                }

                                if (isset($_POST["deletesingle_duties"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['delete_id'];

                                    $sql = "DELETE FROM admin_duties WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }



                                if (isset($_POST["addnew_institu"])) {
                                    $quali_obtain = htmlspecialchars($_POST['quali_obtain'], ENT_QUOTES);

                                    $sql = "SELECT * FROM institution WHERE fileno = '$staffid' AND qualiobtained = '$quali_obtain'";
                                    $result = $conn7->query($sql);
                                    $qualExist = 0;
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $qualExist++;
                                        }
                                    }

                                    if ($qualExist == 0) {
                                        $institu_name = htmlspecialchars($_POST['institu_name'], ENT_QUOTES);
                                        $yearFrom = htmlspecialchars($_POST['yearFrom'], ENT_QUOTES);
                                        $yearFrom = date('F, Y', strtotime($yearFrom));
                                        $yearTo = htmlspecialchars($_POST['yearTo'], ENT_QUOTES);
                                        $yearTo = date('F, Y', strtotime($yearTo));

                                        $quali_date = htmlspecialchars($_POST['quali_date'], ENT_QUOTES);

                                        $sql = "INSERT INTO institution (fileno, instiname, fromdate, todate, qualiobtained, qualidate) VALUE ('$staffid', '$institu_name', '$yearFrom', '$yearTo', '$quali_obtain', '$quali_date')";
                                        $result = $conn7->query($sql);

                                        if (count($_FILES) > 0) {

                                            if (is_uploaded_file($_FILES['uploaded_cert']['tmp_name'])) {

                                                $imgData = addslashes(file_get_contents($_FILES['uploaded_cert']['tmp_name']));
                                                $imageProperties = getimageSize($_FILES['uploaded_cert']['tmp_name']);

                                                $sql = "INSERT INTO " . $dept . " (staffid, imageid, imageType, imageData, imagetitle, from_cert) VALUE ('$staffid', '$quali_obtain', '{$imageProperties['mime']}', '{$imgData}', '$quali_obtain', 'YES')";
                                                $result = $conn12->query($sql);
                                            }
                                        }
                                    }
                                }


                                if (isset($_POST["updatesingle_institu"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['update_id_institu'];
                                    $institu_name = htmlspecialchars($_POST['institu_name'], ENT_QUOTES);
                                    $yearFrom = htmlspecialchars($_POST['yearFrom'], ENT_QUOTES);
                                    $yearFrom = date('F, Y', strtotime($yearFrom));
                                    $yearTo = htmlspecialchars($_POST['yearTo'], ENT_QUOTES);
                                    $yearTo = date('F, Y', strtotime($yearTo));
                                    $quali_obtain = htmlspecialchars($_POST['quali_obtain'], ENT_QUOTES);
                                    $quali_date = htmlspecialchars($_POST['quali_date'], ENT_QUOTES);

                                    $sql = "UPDATE institution SET instiname = '$institu_name', fromdate = '$yearFrom', todate = '$yearTo', qualidate = '$quali_date' WHERE id = '$id'";
                                    $result = $conn7->query($sql);

                                    if (count($_FILES) > 0) {

                                        if (is_uploaded_file($_FILES['uploaded_cert']['tmp_name'])) {

                                            $imgData = addslashes(file_get_contents($_FILES['uploaded_cert']['tmp_name']));
                                            $imageProperties = getimageSize($_FILES['uploaded_cert']['tmp_name']);


                                            $sql = "UPDATE " . $dept . " SET imageType = '{$imageProperties['mime']}', imageData = '{$imgData}' WHERE imageid = '$quali_obtain' AND staffid = '$staffid' AND from_cert = 'YES'";
                                            $result = $conn12->query($sql);
                                        }
                                    }
                                }

                                if (isset($_POST["deletesingle_institu"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['delete_id_institu'];

                                    $sql = "SELECT * FROM institution WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $quali_obtain = $row['qualiobtained'];
                                        }
                                    }

                                    $sql = "DELETE FROM institution WHERE id = '$id'";
                                    $result = $conn7->query($sql);

                                    $sql = "DELETE FROM " . $dept . " WHERE imageid = '$quali_obtain' AND staffid = '$staffid' AND from_cert = 'YES'";
                                    $result = $conn12->query($sql);
                                }



                                if (isset($_POST["upload_file"])) {
                                    if (count($_FILES) > 0) {
                                        $filename = $_POST['filename'];
                                        $imageid = "cert1";
                                        if (is_uploaded_file($_FILES['uploaded']['tmp_name'])) {

                                            $imgData = addslashes(file_get_contents($_FILES['uploaded']['tmp_name']));
                                            $imageProperties = getimageSize($_FILES['uploaded']['tmp_name']);

                                            $sql = "INSERT INTO " . $dept . " (staffid, imageid, imageType, imageData, imagetitle, from_cert) VALUE ('$staffid', '$imageid', '{$imageProperties['mime']}', '{$imgData}', '$filename', 'NO')";
                                            $result = $conn12->query($sql);
                                        }
                                    }
                                }

                                if (isset($_POST["deletesingle_image"])) {
                                    //$id = $_POST["id"];
                                    $id = $_POST['del_img_id'];

                                    $sql = "DELETE FROM " . $dept . " WHERE id = '$id'";
                                    $result = $conn12->query($sql);
                                }


                                if (isset($_POST["downloadsingle_image"])) {
                                }

                                $PSN = $staffid;
                                $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $emailAdd = $row['emailAdd'];
                                        $phone = $row['phone'];
                                    }
                                }

                                $sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $fname = $row['fname'];
                                        $surname = $row['sname'];
                                        $othernames = $row['oname'];
                                    }
                                }
                                $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$PSN'";
                                $result = $conn7->query($sql);
                                $i = 0;
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $i++;
                                    }
                                }

                                if ($i == 0) {
                                    $sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
                                } else {
                                    $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$PSN'";
                                }

                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {


                                        $mytitle = $row['title'];
                                        $apptype = $row['Status'];
                                        $leaveabsent_study = $row['leaveabsent_study'];
                                        $postn_rank = $row['Rank1'];
                                        $area_special = $row['area_special'];
                                        $salary_grade = $row['GradeL'];
                                        $stepG = $row['StepG'];

                                        $nationality = $row["nationality"];
                                        $placebirth = $row["placebirth"];
                                        $religion = $row["religion"];
                                        $healthstatus = $row["healthstatus"];
                                        $disable = $row["disable"];
                                        $healthtype = $row["healthtype"];
                                        $accommodation = $row["accommodation"];

                                        $DeptCode2 = $row["DeptCode"];
                                        $Department = $row["Department"];
                                        $Sex = $row["Sex"];
                                        $ParmtAdress = $row["ParmtAdress"];
                                        $ContAdd = $row["ContAdd"];
                                        $stateOfOrigin = $row["stateOfOrigin"];
                                        $LGA = $row["LGA"];
                                        $DateBirth = $row["DateBirth"];
                                        $FApptDate = $row["FApptDate"];
                                        $FApptMonth = $row["FApptMonth"];
                                        $FApptYear = $row["FApptYear"];
                                        $PApptDate = $row["PApptDate"];
                                        $BankCode2 = $row["BankCode"];
                                        $Bank = $row["Bank"];
                                        $Branch = $row["Branch"];
                                        $AccNo = $row["AccNo"];
                                        $email = $row["email"];
                                        $Scale = $row["Scale"];
                                        $HQualificatn = $row["HQualificatn"];
                                        $maritalstatus = $row["maritalstatus"];
                                        $nochildren = $row["nochildren"];
                                        $phonenumber = $row["phonenumber"];
                                        $phonenumber2 = $row["phonenumber2"];
                                        $Status = $row["Status"];
                                        $nextname = $row["nextname"];
                                        $nextrelation = $row["nextrelation"];
                                        $nextaddress = $row["nextaddress"];
                                        $nextphone = $row["nextphone"];
                                    }
                                }


                                if ($i !== 0) {

                                    $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $emailAdd_old = $row['emailAdd'];
                                            //$phone = $row['phone'];
                                        }
                                    }


                                    $sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
                                    $result = $conn7->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {

                                            //$fname = $row['fname'];
                                            //$surname = $row['sname'];
                                            //$othernames = $row['oname'];
                                            $mytitle_old = $row['title'];
                                            $apptype_old = $row['Status'];
                                            $leaveabsent_study_old = $row['leaveabsent_study'];
                                            $postn_rank_old = $row['Rank1'];
                                            $area_special_old = $row['area_special'];
                                            $salary_grade_old = $row['GradeL'];
                                            $stepG_old = $row['StepG'];

                                            $nationality_old = $row["nationality"];
                                            $placebirth_old = $row["placebirth"];
                                            $religion_old = $row["religion"];
                                            $healthstatus_old = $row["healthstatus"];

                                            $healthtype_old = $row["healthtype"];
                                            $accommodation_old = $row["accommodation"];


                                            $Sex_old = $row["Sex"];
                                            $ParmtAdress_old = $row["ParmtAdress"];
                                            $ContAdd_old = $row["ContAdd"];
                                            $stateOfOrigin_old = $row["stateOfOrigin"];
                                            $LGA_old = $row["LGA"];
                                            $DateBirth_old = $row["DateBirth"];
                                            $FApptDate_old = $row["FApptDate"];

                                            $PApptDate_old = $row["PApptDate"];
                                            $BankCode2_old = $row["BankCode"];
                                            $Bank_old = $row["Bank"];
                                            $Branch_old = $row["Branch"];
                                            $AccNo_old = $row["AccNo"];
                                            $email_old = $row["email"];

                                            $HQualificatn_old = $row["HQualificatn"];
                                            $maritalstatus_old = $row["maritalstatus"];

                                            $phonenumber_old = $row["phonenumber"];
                                            $phonenumber2_old = $row["phonenumber2"];
                                            $Status_old = $row["Status"];
                                            $nextname_old = $row["nextname"];
                                            $nextrelation_old = $row["nextrelation"];
                                            $nextaddress_old = $row["nextaddress"];
                                            $nextphone_old = $row["nextphone"];
                                        }
                                    }
                                }

                                if ($apptype == "fulltime") {
                                    $apptype_full = "Full Time";
                                } else if ($apptype == "parttime") {
                                    $apptype_full = "Part Time";
                                } else {
                                    $apptype_full = "Contract";
                                }


                                if ($postn_rank == "Prof") {
                                    $postn_rank_full = "Professor";
                                } elseif ($postn_rank == "assprof") {
                                    $postn_rank_full = "Associate Professor";
                                } elseif ($postn_rank == "SL") {
                                    $postn_rank_full = "Senior Lecturer";
                                } elseif ($postn_rank == "LI") {
                                    $postn_rank_full = "Lecturer I";
                                } elseif ($postn_rank == "LII") {
                                    $postn_rank_full = "Lecturer II";
                                } elseif ($postn_rank == "AL") {
                                    $postn_rank_full = "Assistant Lecturer";
                                } else {
                                    $postn_rank_full = "Graduate Assistant";
                                }

                                if ($leaveabsent_study == "leaveabsent") {
                                    $leaveabsent_study_full = "Leave of Absent";
                                } else if ($leaveabsent_study == "studyleave") {
                                    $leaveabsent_study_full = "Study Leave";
                                } else {
                                    $leaveabsent_study_full = $leaveabsent_study;
                                }

                                if ($nationality == "non") {
                                    $natinal_full = "Non Nigerian";
                                } else {
                                    $natinal_full = $nationality;
                                }

                                if ($accommodation == "campus") {
                                    $accommodation_full = "In Campus";
                                } else {
                                    $accommodation_full = "Off Campus";
                                }

                                if ($HQualificatn == "firstdegree") {
                                    $HQualificatn_full = "First Degree";
                                } else if ($HQualificatn == "masters") {
                                    $HQualificatn_full = "Masters";
                                } else {
                                    $HQualificatn_full = "Ph.D";
                                }

                                ?>
                                <div class="col-md-4 col-lg-1">
                                </div>
                                <div class="col-md-9 col-lg-10">

                                    <section class="panel panel-group">
                                        <div class="modal-header form-group">
                                            <?php if ($i == 0) { ?>
                                                <label class="col-lg-8 control-label" style="text-align: left; color: red"></label>
                                            <?php } else { ?>
                                                <label class="col-lg-8 control-label" style="text-align: left; color: red"><b>* New
                                                        Record Awaiting Approval</b></label>
                                            <?php } ?>

                                            <div class="col-lg-4" style="text-align: right">
                                                <a href="staff_profile_print.php" class="btn btn-primary btn-xs"><span>Print Preview</span></a>
                                            </div>

                                        </div>
                                        <header>

                                            <div>
                                                <div class="profile-picture">

                                                    <?php
                                                    $staff_pic_folder = $_SESSION['staff_pic_folder'];
                                                    echo "<img alt='' src='$staff_pic_folder/" . strtoupper($_SESSION['deptcode']) . "/images/" . strtoupper($staffid) . "/MyPic1.jpg' style='width:150px; hieght:150px'>";

                                                    ?>
                                                </div>
                                                <div>
                                                    <h4 class="name text-semibold">
                                                        <?php echo strtoupper($mytitle) . " " . $fname . " " . $othernames . " " . $surname ?>
                                                    </h4>
                                                    <h5 class="role"><?php echo $PSN ?></h5>

                                                </div>
                                            </div>

                                        </header>
                                        <div id="accordion">
                                            <div class="panel panel-accordion panel-accordion-first">


                                                <div class="panel-body">
                                                    <?php if ($i == 0) { ?>
                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>SurName:</b>
                                                                <?php echo $surname ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>First
                                                                    Name:</b> <?php echo $fname ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Other
                                                                    Name(s):</b> <?php echo $othernames ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>File
                                                                    Number:</b> <?php echo $PSN ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Title:</b>
                                                                <?php echo $mytitle ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Department:</b>
                                                                <?php echo $_SESSION["deptname"] ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>email:</b>
                                                                <?php echo $emailAdd ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Highest
                                                                    Qualification:</b>
                                                                <?php echo $HQualificatn_full ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Appointment Type:</b>
                                                                <?php echo $apptype_full ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Leave of
                                                                    Absence/Study Leave:</b>
                                                                <?php echo $leaveabsent_study_full ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Position/Rank:</b>
                                                                <?php echo $postn_rank_full ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Area of
                                                                    Specialization:</b> <?php echo $area_special ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Salary
                                                                    Grade:</b> <?php echo $salary_grade ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Step:
                                                                    <?php echo $stepG ?></b> </label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Marital
                                                                    Status:</b> <?php echo $maritalstatus ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Nationality:</b>
                                                                <?php echo $natinal_full ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>State of
                                                                    Origin:</b> <?php echo $stateOfOrigin ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>LGA:</b>
                                                                <?php echo $LGA ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Religion:</b>
                                                                <?php echo $religion ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Health
                                                                    Status:</b> <?php echo $healthstatus ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>If
                                                                    Disabled, Type:</b> <?php echo $healthtype ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Accommodation Status:</b>
                                                                <?php echo $accommodation_full ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Date of
                                                                    Birth:</b>
                                                                <?php echo date('d F, Y', strtotime($DateBirth)); ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Place of
                                                                    Birth: <?php echo $placebirth ?></b> </label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Permenet
                                                                    Home Address:</b> <?php echo $ParmtAdress ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Contact
                                                                    Address:</b> <?php echo $ContAdd ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Phone
                                                                    Number 1:</b> <?php echo $phonenumber ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Phone
                                                                    Number 2:</b> <?php echo $phonenumber2 ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Date of
                                                                    First Appointment:</b>
                                                                <?php echo date('d F, Y', strtotime($FApptDate)); ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Date of
                                                                    Present Appointment:</b>
                                                                <?php echo date('d F, Y', strtotime($PApptDate)); ?></b>
                                                            </label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Bank:</b>
                                                                <?php echo $Bank ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Branch:</b>
                                                                <?php echo $Branch ?></label>
                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Account
                                                                    Number:</b> <?php echo $AccNo ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"></label>
                                                        </div>
                                                    <?php } else { ?>
                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>SurName:</b>
                                                                <?php echo $surname ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>First
                                                                    Name:</b> <?php echo $fname ?></label>

                                                        </div>
                                                        <div class="form-group" style="color: black">
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Other
                                                                    Name(s):</b> <?php echo $othernames ?></label>
                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>File
                                                                    Number:</b> <?php echo $PSN ?></label>
                                                        </div>


                                                        <div class="form-group" style="color: black">
                                                            <?php if ($mytitle_old == $mytitle) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Title:</b>
                                                                    <?php echo $mytitle ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Title:</b> <?php echo $mytitle ?></label>
                                                            <?php } ?>

                                                            <label class="col-lg-6 control-label" style="text-align: left"><b>Department:</b>
                                                                <?php echo $_SESSION["deptname"] ?></label>

                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($emailAdd_old == $emailAdd) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>email:</b>
                                                                    <?php echo $emailAdd ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>email:</b> <?php echo $emailAdd ?></label>
                                                            <?php } ?>

                                                            <?php if ($HQualificatn_old == $HQualificatn) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Highest
                                                                        Qualification:</b>
                                                                    <?php echo $HQualificatn_full ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Highest Qualification:</b>
                                                                    <?php echo $HQualificatn_full ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($apptype_old == $apptype) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Appointment Type:</b>
                                                                    <?php echo $apptype_full ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Appointment Type:</b> <?php echo $apptype_full ?></label>
                                                            <?php } ?>

                                                            <?php if ($leaveabsent_study_old == $leaveabsent_study) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Leave of
                                                                        Absence/Study Leave:</b>
                                                                    <?php echo $leaveabsent_study_full ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Leave of Absence/Study Leave:</b>
                                                                    <?php echo $leaveabsent_study_full ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($postn_rank_old == $postn_rank) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Position/Rank:</b>
                                                                    <?php echo $postn_rank_full ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Position/Rank:</b> <?php echo $postn_rank_full ?></label>
                                                            <?php } ?>

                                                            <?php if ($area_special_old == $area_special) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Area of
                                                                        Specialization:</b> <?php echo $area_special ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Area of Specialization:</b>
                                                                    <?php echo $area_special ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($salary_grade_old == $salary_grade) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Salary
                                                                        Grade:</b> <?php echo $salary_grade ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Salary Grade:</b> <?php echo $salary_grade ?></label>
                                                            <?php } ?>

                                                            <?php if ($stepG_old == $stepG) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Step:
                                                                        <?php echo $stepG ?></b> </label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Step: <?php echo $stepG ?></b> </label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($maritalstatus_old == $maritalstatus) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Marital
                                                                        Status:</b> <?php echo $maritalstatus ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Marital Status:</b> <?php echo $maritalstatus ?></label>
                                                            <?php } ?>

                                                            <?php if ($nationality_old == $nationality) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Nationality:</b>
                                                                    <?php echo $natinal_full ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Nationality:</b> <?php echo $natinal_full ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($stateOfOrigin_old == $stateOfOrigin) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>State of
                                                                        Origin:</b> <?php echo $stateOfOrigin ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>State of Origin:</b> <?php echo $stateOfOrigin ?></label>
                                                            <?php } ?>

                                                            <?php if ($LGA_old == $LGA) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>LGA:</b>
                                                                    <?php echo $LGA ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>LGA:</b> <?php echo $LGA ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($religion_old == $religion) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Religion:</b>
                                                                    <?php echo $religion ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Religion:</b> <?php echo $religion ?></label>
                                                            <?php } ?>

                                                            <?php if ($healthstatus_old == $healthstatus) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Health
                                                                        Status:</b> <?php echo $healthstatus ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Health Status:</b> <?php echo $healthstatus ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($healthtype_old == $healthtype) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>If
                                                                        Disabled, Type:</b> <?php echo $healthtype ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>If Disabled, Type:</b> <?php echo $healthtype ?></label>
                                                            <?php } ?>

                                                            <?php if ($accommodation_old == $accommodation) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Accommodation Status:</b>
                                                                    <?php echo $accommodation_full ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Accommodation Status:</b>
                                                                    <?php echo $accommodation_full ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($DateBirth_old == $DateBirth) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Date of
                                                                        Birth:</b>
                                                                    <?php echo date('d F, Y', strtotime($DateBirth)); ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Date of Birth:</b>
                                                                    <?php echo date('d F, Y', strtotime($DateBirth)); ?></label>
                                                            <?php } ?>

                                                            <?php if ($placebirth_old == $placebirth) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Place of
                                                                        Birth: <?php echo $placebirth ?></b> </label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Place of Birth: <?php echo $placebirth ?></b> </label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($ParmtAdress_old == $ParmtAdress) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Permenet
                                                                        Home Address:</b> <?php echo $ParmtAdress ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Permenet Home Address:</b>
                                                                    <?php echo $ParmtAdress ?></label>
                                                            <?php } ?>

                                                            <?php if ($ContAdd_old == $ContAdd) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Contact
                                                                        Address:</b> <?php echo $ContAdd ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Contact Address:</b> <?php echo $ContAdd ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($phonenumber_old == $phonenumber) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Phone
                                                                        Number 1:</b> <?php echo $phonenumber ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Phone Number 1:</b> <?php echo $phonenumber ?></label>
                                                            <?php } ?>

                                                            <?php if ($phonenumber2_old == $phonenumber2) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Phone
                                                                        Number 2:</b> <?php echo $phonenumber2 ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Phone Number 2:</b> <?php echo $phonenumber2 ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($FApptDate_old == $FApptDate) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Date of
                                                                        First Appointment:</b>
                                                                    <?php echo date('d F, Y', strtotime($FApptDate)); ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Date of First Appointment:</b>
                                                                    <?php echo date('d F, Y', strtotime($FApptDate)); ?></label>
                                                            <?php } ?>

                                                            <?php if ($PApptDate_old == $PApptDate) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Date of
                                                                        Present Appointment:</b>
                                                                    <?php echo date('d F, Y', strtotime($PApptDate)); ?></b>
                                                                </label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Date of Present Appointment:</b>
                                                                    <?php echo date('d F, Y', strtotime($PApptDate)); ?></b>
                                                                </label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($Bank_old == $Bank) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Bank:</b>
                                                                    <?php echo $Bank ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Bank:</b> <?php echo $Bank ?></label>
                                                            <?php } ?>

                                                            <?php if ($Branch_old == $Branch) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Branch:</b>
                                                                    <?php echo $Branch ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Branch:</b> <?php echo $Branch ?></label>
                                                            <?php } ?>


                                                        </div>

                                                        <div class="form-group" style="color: black">
                                                            <?php if ($AccNo_old == $AccNo) { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><b>Account
                                                                        Number:</b> <?php echo $AccNo ?></label>
                                                            <?php } else { ?>
                                                                <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                    <b>Account Number:</b> <?php echo $AccNo ?></label>
                                                            <?php } ?>

                                                            <label class="col-lg-6 control-label" style="text-align: left"></label>
                                                        </div>

                                                    <?php } ?>
                                                </div>
                                                <hr class="separator" />
                                                <div class="form-group">
                                                    <label class="col-sm-3 control-label">Next of Kin:</label>
                                                    <div class="col-sm-8">

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-3 control-label"></label>
                                                    <div class="col-sm-8">
                                                        <table class="table mb-none">

                                                            <tbody>
                                                                <?php if ($i == 0) { ?>
                                                                    <tr>
                                                                        <th>Name:</th>
                                                                        <td><?php echo $nextname ?></td>
                                                                        <th>Relationship:</th>
                                                                        <td><?php echo $nextrelation ?></td>
                                                                    </tr>

                                                                    <tr>
                                                                        <th>Address:</th>
                                                                        <td><?php echo $nextaddress ?></td>
                                                                        <th>Phone:</th>
                                                                        <td><?php echo $nextphone ?></td>
                                                                    </tr>
                                                                <?php } else { ?>
                                                                    <tr>
                                                                        <?php if ($nextname_old == $nextname) { ?>
                                                                            <th>Name:</th>
                                                                        <?php } else { ?>
                                                                            <th><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                                Name:</th>
                                                                        <?php } ?>

                                                                        <td><?php echo $nextname ?></td>
                                                                        <?php if ($nextrelation_old == $nextrelation) { ?>
                                                                            <th>Relationship:</th>
                                                                        <?php } else { ?>
                                                                            <th><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                                Relationship:</th>
                                                                        <?php } ?>

                                                                        <td><?php echo $nextrelation ?></td>
                                                                    </tr>

                                                                    <tr>
                                                                        <?php if ($nextaddress_old == $nextaddress) { ?>
                                                                            <th>Address:</th>
                                                                        <?php } else { ?>
                                                                            <th><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                                Address:
                                                                            </th>
                                                                        <?php } ?>

                                                                        <td><?php echo $nextaddress ?></td>
                                                                        <?php if ($nextphone_old == $nextphone) { ?>
                                                                            <th>Phone:</th>
                                                                        <?php } else { ?>
                                                                            <th><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                                Phone:
                                                                            </th>
                                                                        <?php } ?>

                                                                        <td><?php echo $nextphone ?></td>
                                                                    </tr>
                                                                <?php } ?>

                                                            </tbody>
                                                        </table>

                                                    </div>
                                                </div>


                                            </div>

                                        </div>
                                    </section>
                                    <br><br><br>
                                    <hr class="separator" />
                                    <div class="panel panel-default">
                                        <header class="panel-heading">

                                            <b>Children</b>
                                        </header>
                                        <div class="panel-body">

                                            <div class="col-md-12">
                                                <div style="text-align: right">
                                                    <a href="#addchildModal" class="btn btn-primary btn-xs" data-toggle="modal"><span>Add New</span></a>
                                                </div>
                                                <br>
                                                <table class="table stats-table">
                                                    <thead>
                                                        <tr>
                                                            <th hidden="hidden">ID</th>
                                                            <th>Name</th>
                                                            <th>Sex</th>
                                                            <th>Date of Birth</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <?php
                                                        $sql = "SELECT * FROM children WHERE fileno = '$PSN'";
                                                        $result = $conn7->query($sql);
                                                        $sexsno = 0;
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sexsno++;
                                                                $id_child = $row["id"];
                                                                $childname = $row["childname"];
                                                                $childbirth = date('d F, Y', strtotime($row["datebirth"]));
                                                                $childsex = $row["sex1"];
                                                                $approval_child = $row['approval'];
                                                                echo "<tr><td hidden='hidden'>$id_child</td><td>$childname</td><td>$childsex</td><td>$childbirth</td><td>";

                                                                if ($approval_child == "NO") {
                                                        ?>

                                                                    <button type='button' class='btn btn-default btn-xs editone_child'><i class='material-icons' data-toggle='tooltip' title='Edit'>&#xE254;</i></button>
                                                                    <button type='button' class='btn btn-default btn-xs delete_child'><i class='material-icons' data-toggle='tooltip' title='Delete' style='color: red'>&#xE872;</i></button>
                                                        <?php
                                                                }
                                                                echo "</td></tr>";
                                                            }
                                                        }

                                                        ?>

                                                    </tbody>
                                                </table>


                                            </div>

                                        </div>
                                    </div>

                                    <hr class="separator" />
                                    <div class="panel panel-default">
                                        <header class="panel-heading">

                                            <b>Academic Qualification</b>
                                        </header>
                                        <div class="panel-body">

                                            <div style="text-align: right">
                                                <a href="#addAcadQualiModal" class="btn btn-primary btn-xs" data-toggle="modal"><span>Add New</span></a>
                                            </div>
                                            <?php
                                            $sql = "SELECT * FROM institution WHERE fileno = '$staffid'";
                                            $result = $conn7->query($sql);
                                            if ($result->num_rows > 0) {
                                            ?>
                                                <table class="table stats-table">
                                                    <thead>
                                                        <tr>
                                                            <th hidden="hidden">ID</th>
                                                            <th>Institution Name</th>
                                                            <th>From</th>
                                                            <th>To</th>
                                                            <th>Qualification Obtained</th>
                                                            <th>Qualification Date</th>
                                                            <th>Image</th>
                                                            <th>Action</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <?php

                                                        while ($row = $result->fetch_assoc()) {
                                                            $id_institu = $row["id"];
                                                            $instiname = $row["instiname"];
                                                            $fromdate = $row["fromdate"];
                                                            $todate = $row["todate"];
                                                            $qualiobtained = $row["qualiobtained"];
                                                            $qualidate = date('d F, Y', strtotime($row["qualidate"]));

                                                            $approval_institu = $row['approval'];
                                                            echo "<tr><td hidden='hidden'>$id_institu</td><td>$instiname</td><td>$fromdate</td><td>$todate</td><td>$qualiobtained</td><td>$qualidate</td><td>";
                                                            $sql2 = "SELECT * FROM " . $dept . " WHERE staffid = '$staffid' AND from_cert = 'YES' AND imageid = '$qualiobtained'";
                                                            $result2 = $conn12->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                        ?>
                                                                    <a href="data:image/jpeg;base64,<?php echo base64_encode($row2["imageData"]) ?>">

                                                                        <img src="data:image/jpeg;base64,<?php echo base64_encode($row2["imageData"]) ?>" alt="Project" style="width: 70px; height:70px" />
                                                                    </a>
                                                                    <!-- <a href="download.php?id=<?php echo $id_institu; ?>" target="_blank">
                                                            <?php echo $qualiobtained; ?>
                                                        </a> -->
                                                                <?php
                                                                }
                                                            }
                                                            echo "</td><td>";

                                                            if ($approval_institu == "NO") {
                                                                ?>

                                                                <button type='button' class='btn btn-default btn-xs editone_institu'><i class='material-icons' data-toggle='tooltip' title='Edit'>&#xE254;</i></button>
                                                                <button type='button' class='btn btn-default btn-xs delete_institu'><i class='material-icons' data-toggle='tooltip' title='Delete' style='color: red'>&#xE872;</i></button>
                                                        <?php
                                                            }
                                                            echo "</td></tr>";
                                                        }

                                                        ?>

                                                    </tbody>
                                                </table>

                                            <?php } ?>
                                        </div>
                                    </div>


                                    <hr class="separator" />
                                    <div class="panel panel-default">
                                        <header class="panel-heading">

                                            <b>Membership of Professional Bodies/Societies</b>
                                        </header>
                                        <div class="panel-body">

                                            <div class="col-md-12">
                                                <div style="text-align: right">
                                                    <a href="#addPofBodyModal" class="btn btn-primary btn-xs" data-toggle="modal"><span>Add New</span></a>
                                                </div>
                                                <br>
                                                <table class="table stats-table">
                                                    <thead>
                                                        <tr>
                                                            <th hidden="hidden">ID</th>
                                                            <th>Name</th>
                                                            <th>Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <?php
                                                        $sql = "SELECT * FROM professional_body WHERE fileno = '$PSN'";
                                                        $result = $conn7->query($sql);
                                                        $bodysno = 0;
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $bodysno++;
                                                                $id_prof_body = $row["id"];
                                                                $profname = $row["profname"];
                                                                $profdate = date('d F, Y', strtotime($row["profdate"]));
                                                                $approval_profbody = $row['approval'];
                                                                echo "<tr><td hidden='hidden'>$id_prof_body</td><td>$profname</td><td>$profdate</td><td>";
                                                                if ($approval_profbody == "NO") {
                                                        ?>
                                                                    <button type='button' class='btn btn-default btn-xs editone_profbody'><i class='material-icons' data-toggle='tooltip' title='Edit'>&#xE254;</i></button>
                                                                    <button type='button' class='btn btn-default btn-xs delete_profbody'><i class='material-icons' data-toggle='tooltip' title='Delete' style='color: red'>&#xE872;</i></button>
                                                        <?php
                                                                }
                                                                echo "</td></tr>";
                                                            }
                                                        }

                                                        ?>

                                                    </tbody>
                                                </table>


                                            </div>

                                        </div>
                                    </div>

                                    <hr class="separator" />
                                    <section class="panel panel-default">
                                        <header class="panel-heading">
                                            <b> ADMINISTRATIVE DUTIES(<i>Complete the Activity Form
                                                    with
                                                    Documentation Attached</i>)</b>
                                        </header>
                                        <div class="panel-body">

                                            <div style="text-align: right">
                                                <form method="POST">
                                                    <div style="text-align: right">

                                                        <button type="submit" name="submit_Add_Duties" class="mb-xs mt-xs mr-xs btn btn-xs btn-primary">Add
                                                            New</button>
                                                    </div>
                                                </form>
                                            </div>
                                            <?php
                                            $sql = "SELECT * FROM admin_duties WHERE staffid = '$staffid' ORDER BY session1";
                                            $result = $conn7->query($sql);
                                            if ($result->num_rows > 0) {
                                            ?>
                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th hidden="hidden">ID</th>
                                                            <th>Type of Activity</th>
                                                            <th>Details</th>
                                                            <th>Year</th>
                                                            <th>Session</th>
                                                            <th>Image</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>

                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $activit_code = $row['activit_code'];
                                                            $activity_type = $row['activity_type'];
                                                            $year1 = $row['year1'];
                                                            $session1 = $row['session1'];
                                                            $approval_duties = $row['approval'];
                                                            $id = $row['id'];
                                                            $imageID = $staffid . "_" . $activit_code . "_" . $id;
                                                            if ($activit_code == "15" || $activit_code == "18" || $activit_code == "19") {
                                                                $specify = $row['specify'];
                                                                echo "<tr><td hidden='hidden'>$id</td><td>$activity_type</td><td>$specify</td><td>$year1</td><td>$session1</td><td>";
                                                            } else {
                                                                echo "<tr><td hidden='hidden'>$id</td><td>$activity_type</td><td></td><td>$year1</td><td>$session1</td><td>";
                                                            }

                                                            $sql2 = "SELECT * FROM " . $dept . " WHERE staffid = '$staffid' AND from_cert = 'YES' AND imageid = '$imageID'";
                                                            $result2 = $conn12->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                        ?>
                                                                    <a href="data:image/jpeg;base64,<?php echo base64_encode($row2["imageData"]) ?>">

                                                                        <img src="data:image/jpeg;base64,<?php echo base64_encode($row2["imageData"]) ?>" alt="Project" style="width: 70px; height:70px" />
                                                                    </a>

                                                            <?php
                                                                }
                                                            }
                                                            echo "</td><td>";
                                                            ?>
                                                            <td>
                                                                <?php if ($approval_duties == "NO") { ?>
                                                                    <button type='button' class='btn btn-default btn-xs delete_duties'><i class='material-icons' data-toggle='tooltip' title='Delete' style='color: red'>&#xE872;</i></button>
                                                                <?php } ?>
                                                            </td>
                                                            </tr>
                                                        <?php
                                                        }

                                                        ?>
                                                    </tbody>
                                                </table>
                                            <?php } ?>
                                            <?php if (isset($_POST["submit_Add_Duties"])) { ?>
                                                <hr class="separator" />
                                                <h3 style="text-align: center">ADD NEW</h3>
                                                <form class="form-horizontal form-bordered" enctype="multipart/form-data" method="post">
                                                    <div class="form-group">
                                                        <label class="col-lg-4 control-label">Type of Activities: </label>
                                                        <div class="col-lg-7">
                                                            <select class='activit form-control m-bot15' name='typeactivit' id='typeactivit'>
                                                                <!-- <select name="typeactivit" id="ResponseSel" class="form-control" style="color:#000000" id="typeactivit" required="required"> -->
                                                                <option value=""></option>
                                                                <?php
                                                                $sql = "SELECT * FROM resp_table";
                                                                $result = $conn7->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $repcode = $row['repcode'];
                                                                        $reptitle = $row['reptitle'];
                                                                        echo "<option value = '$repcode'>$reptitle</option>";
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group" id="GetResponse">

                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-lg-4 control-label">Year: </label>
                                                        <div class="col-lg-7">
                                                            <?php
                                                            $iniyear = 2015;
                                                            $finalyear = substr($_SESSION['corntsession'], 5);

                                                            ?>
                                                            <select name="activyear" class="form-control" style="color:#000000" id="activyear">
                                                                <option value=""></option>
                                                                <?php
                                                                while ($iniyear <= $finalyear) {
                                                                    $addyear = $iniyear + 1;
                                                                    echo "<option value = '$addyear'>$addyear</option>";
                                                                    $iniyear++;
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-4 control-label">File Upload:</label>
                                                        <div class="col-md-8">
                                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                                <div class="input-append">
                                                                    <div class="uneditable-input">
                                                                        <i class="fa fa-file fileupload-exists"></i>
                                                                        <span class="fileupload-preview"></span>
                                                                    </div>
                                                                    <span class="btn btn-default btn-file">
                                                                        <span class="fileupload-exists">Change</span>
                                                                        <span class="fileupload-new">Select file</span>
                                                                        <input type="file" name="uploaded_resp" required />
                                                                    </span>
                                                                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-lg-4 control-label"></label>
                                                        <div class="col-lg-7" style="text-align: right">
                                                            <button type="submit" name="submit_activity" class="mb-xs mt-xs mr-xs btn btn-sm btn-info">Submit</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            <?php } ?>
                                        </div>
                                    </section>



                                    <hr class="separator" />
                                    <section class="panel panel-default">
                                        <header class="panel-heading">

                                            <b class="panel-title">FUNDED RESEARCH AND CONSULTANCY(<i>Complete the
                                                    Research
                                                    Activity Report Form with Documentation Attached</i>)</b>
                                        </header>
                                        <div class="panel-body">

                                            <div class="col-md-12">
                                                <div style="text-align: right">
                                                    <a href="#addReserchModal" class="btn btn-primary btn-xs" data-toggle="modal"><span>Add New</span></a>
                                                </div>
                                                <?php
                                                $sql = "SELECT * FROM funded_research WHERE staffid = '$staffid' ORDER BY session1";
                                                $result = $conn7->query($sql);
                                                if ($result->num_rows > 0) {
                                                ?>
                                                    <table class="table mb-none">
                                                        <thead>
                                                            <tr>
                                                                <th hidden="hidden">ID</th>
                                                                <th>Project No</th>
                                                                <th>Title of Award</th>
                                                                <th>In-Kind Required by Grant</th>
                                                                <th>Release Time</th>
                                                                <th>Total (Amount)</th>
                                                                <th>Remark</th>
                                                                <th>Session</th>
                                                                <th>Action</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                            while ($row = $result->fetch_assoc()) {
                                                                $projt_no = $row['projt_no'];
                                                                $projt_title = $row['projt_title'];
                                                                $reguire_grant = $row['reguire_grant'];
                                                                //$release_time = $row['release_time'];
                                                                $release_time = date('d F, Y', strtotime($row["release_time"]));
                                                                $session_research = $row['session1'];
                                                                //$totamount = number_format($row['totamount'], 2);
                                                                $totamount = $row['totamount'];
                                                                $remark1 = $row['remark1'];
                                                                $id_research = $row['id'];
                                                                $approval_research = $row['approval'];

                                                                echo "<tr><td hidden='hidden'>$id_research</td><td>$projt_no</td><td>$projt_title</td><td>$reguire_grant</td><td>$release_time</td><td>$totamount</td><td>$remark1</td><td>$session_research</td><td>";
                                                                if ($approval_research == "NO") {
                                                            ?>

                                                                    <button type='button' class='btn btn-default btn-xs editone_reserch'><i class='material-icons' data-toggle='tooltip' title='Edit'>&#xE254;</i></button>
                                                                    <button type='button' class='btn btn-default btn-xs delete_reserch'><i class='material-icons' data-toggle='tooltip' title='Delete' style='color: red'>&#xE872;</i></button>
                                                            <?php
                                                                }
                                                                echo "</td></tr>";
                                                            }

                                                            ?>
                                                        </tbody>
                                                    </table>
                                                <?php } ?>

                                            </div>

                                        </div>
                                    </section>


                                    <hr class="separator" />
                                    <section class="panel panel-default">
                                        <header class="panel-heading">

                                            <b>COMMUNITY SERVICE (<i>Services Rendered Without
                                                    Demand for
                                                    Payment</i>)</b>
                                        </header>
                                        <div class="panel-body">

                                            <div class="col-md-12">
                                                <div style="text-align: right">
                                                    <a href="#addCommModal" class="btn btn-primary btn-xs" data-toggle="modal"><span>Add New</span></a>
                                                </div>
                                                <br>
                                                <?php
                                                $sql = "SELECT * FROM comm_service WHERE staffid = '$staffid' ORDER BY session1";
                                                $result = $conn7->query($sql);
                                                if ($result->num_rows > 0) {
                                                ?>
                                                    <table class="table mb-none">
                                                        <thead>
                                                            <tr>
                                                                <th hidden="hidden">ID</th>
                                                                <th>Type</th>
                                                                <th>Beneficiary</th>
                                                                <th>Effect</th>
                                                                <th>Date</th>
                                                                <th>Session</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                            while ($row = $result->fetch_assoc()) {
                                                                $type_comm = $row['type_comm'];
                                                                $beneficiary = $row['beneficiary'];
                                                                $effect = $row['effect'];
                                                                // $date_comm = $row['date_comm'];
                                                                $date_comm = date('d F, Y', strtotime($row["date_comm"]));
                                                                $session_comm = $row['session1'];
                                                                $approval_comm = $row['approval'];
                                                                $id_comm = $row['id'];

                                                                echo "<tr><td hidden='hidden'>$id_comm</td><td>$type_comm</td><td>$beneficiary</td><td>$effect</td><td>$date_comm</td><td>$session_comm</td><td>";
                                                                if ($approval_comm == "NO") {
                                                            ?>

                                                                    <button type='button' class='btn btn-default btn-xs editone_comm'><i class='material-icons' data-toggle='tooltip' title='Edit'>&#xE254;</i></button>
                                                                    <button type='button' class='btn btn-default btn-xs delete_comm'><i class='material-icons' data-toggle='tooltip' title='Delete' style='color: red'>&#xE872;</i></button>

                                                            <?php
                                                                }
                                                                echo "</td></tr>";
                                                            }

                                                            ?>
                                                        </tbody>
                                                    </table>
                                                <?php } ?>


                                            </div>

                                        </div>
                                    </section>
                                    <br>
                                    <hr class="separator" />

                                    <div class="row">
                                        <div class="col-xs-12">
                                            <section class="panel">
                                                <header class="panel-heading">

                                                    <b>Add Credentials and other Certificates here
                                                    </b>
                                                </header>
                                                <div class="panel-body">
                                                    <form enctype="multipart/form-data" action="" method="POST">

                                                        <div class="modal-body">
                                                            <div class="form-group">
                                                                <label class="col-lg-3 control-label">File Name:
                                                                </label>
                                                                <div class="col-lg-9">
                                                                    <input type="text" class="form-control" style="color:#000000" name="filename" id="filename" required="required">
                                                                </div>

                                                            </div>
                                                            <br><br>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">File
                                                                    Upload</label>
                                                                <div class="col-md-9">
                                                                    <div class="fileinput fileinput-new input-group" data-provides="fileinput">
                                                                        <div class="form-control" data-trigger="fileinput">
                                                                            <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                                                            <span class="fileinput-filename"></span>
                                                                        </div>
                                                                        <span class="input-group-addon btn btn-default btn-file"><span class="fileinput-new">Select
                                                                                file</span><span class="fileinput-exists">Change</span><input type="file" name="uploaded"></span>
                                                                        <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                                    </div>


                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">

                                                            <input type="submit" name="upload_file" class="btn btn-sm btn-success" value="Upload">
                                                        </div>
                                                    </form>




                                                    <section class="content-with-menu-has-toolbar media-gallery">
                                                        <div class="content-with-menu-container">

                                                            <div class="row mg-files" data-sort-destination data-sort-id="media-gallery">

                                                                <?php

                                                                //$sql = "INSERT INTO " . $dept . " (staffid, imageid, imageType, imageData, imagetitle) VALUE ('$staffid', '$imageid', '{$imageProperties['mime']}', '{$imgData}', '$filename')";
                                                                //$result = $conn12->query($sql);


                                                                $sql = "SELECT * FROM " . $dept . " WHERE staffid = '$staffid'";
                                                                $result = $conn12->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $img_id = $row["id"];
                                                                        $from_cert = $row["from_cert"];
                                                                ?>
                                                                        <div class="isotope-item document col-sm-6 col-md-4 col-lg-3">
                                                                            <div class="thumbnail">
                                                                                <form class='form-horizontal form-bordered' method='post'>
                                                                                    <div class="thumb-preview">
                                                                                        <a class="thumb-image" href="data:image/jpeg;base64,<?php echo base64_encode($row["imageData"]) ?>">

                                                                                            <img src="data:image/jpeg;base64,<?php echo base64_encode($row["imageData"]) ?>" class="img-responsive" alt="Project" style="width: 447px; height:300px" />
                                                                                        </a>
                                                                                        <div class="mg-thumb-options">
                                                                                            <div class="mg-zoom"><i class="fa fa-search"></i>
                                                                                            </div>
                                                                                            <div class="mg-toolbar">

                                                                                                <div class="mg-group pull-right">
                                                                                                    <a href="#">EDIT</a>
                                                                                                    <button class="dropdown-toggle mg-toggle" type="button" data-toggle="dropdown">
                                                                                                        <i class="fa fa-caret-up"></i>
                                                                                                    </button>
                                                                                                    <ul class="dropdown-menu mg-menu" role="menu">
                                                                                                        <table class="table mb-none">
                                                                                                            <tbody>
                                                                                                                <tr>
                                                                                                                    <td hidden='hidden'>
                                                                                                                        <?php echo $img_id ?>
                                                                                                                    </td>
                                                                                                                    <td>
                                                                                                                        <!-- <li style="padding-bottom: 0.5em"><button type='button' class='btn btn-default btn-xs download_image'><i class='material-icons fa fa-download' style='color: black'></i> Download</button></li> -->
                                                                                                                        <?php if ($from_cert == "NO") { ?>
                                                                                                                            <li><button type='button' class='btn btn-default btn-xs delete_image'><i class='material-icons fa fa-trash-o' style='color: red'></i>
                                                                                                                                    Delete</button>
                                                                                                                            </li>
                                                                                                                        <?php } ?>
                                                                                                                    </td>
                                                                                                                </tr>
                                                                                                            </tbody>
                                                                                                        </table>

                                                                                                    </ul>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <h5 class="mg-title text-semibold">
                                                                                        <?php echo $row["imagetitle"] ?></h5>
                                                                                </form>
                                                                            </div>
                                                                        </div>
                                                                <?php
                                                                    }
                                                                }

                                                                ?>



                                                            </div>
                                                        </div>
                                                    </section>
                                                </div>
                                            </section>




                                        </div>

                                    </div>
                                </div>



                            </div>
                        </div>

                        <div class="footer">
                            <?php
                            include_once 'includes/footer2.php';
                            ?>
                        </div>
                    </div>
                    <div id="right-sidebar">

                        <?php
                        include_once 'includes/aside_right.php';
                        ?>

                    </div>

                </div>
                <?php
                $conn->close();
                $conn2->close();
                $conn7->close();
                ?>

                <!-- Delete Modal Duties -->
                <div id="deleteModal_duties" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Adminisrative Duties</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id" id="delete_id">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_duties" class="btn btn-danger" value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- PROFESSIONAL BODY -->
                <!-- Add New Modal Professional Body -->
                <div id="addPofBodyModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="post" action="">
                                <div class="modal-header">
                                    <h4 class="modal-title">Add New Professional Body</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Name: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="profbodyname" value="" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Date: </label>
                                        <div class="col-lg-7">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="profbodydate" required="required">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" class="btn btn-success" name="addnew_profbody" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Edit Modal Professional Body -->
                <div id="editModal_profbody" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <input type="hidden" name="update_id_profbody" id="update_id_profbody">
                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Record</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Name: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="profbodyname" id="profbodyname" value="" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Date: </label>
                                        <div class="col-lg-7">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="profbodydate" id="profbodydate" required=" required">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="updatesingle_profbody" class="btn btn-info" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Delete Modal Professional Body -->
                <div id="deleteModal_profbody" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Professional Body</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id_profbody" id="delete_id_profbody">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_profbody" class="btn btn-danger" value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                <!-- CHILDREN -->
                <!-- Add New Modal Children -->
                <div id="addchildModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="post" action="">
                                <div class="modal-header">
                                    <h4 class="modal-title">Add New Child</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Child Name: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="childname" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Child Sex: </label>
                                        <div class="col-lg-7">
                                            <select class="form-control" style="color:#000000" name="childsex" required="required">
                                                <option value=""></option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>

                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Date of Birth: </label>
                                        <div class="col-lg-7">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="childdate" required="required">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" class="btn btn-success" name="addnew_child" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Edit Modal Professional Body -->
                <div id="editModal_child" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <input type="hidden" name="update_id_child" id="update_id_child">
                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Record</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Child Name: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="childname" id="childname" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Child Sex: </label>
                                        <div class="col-lg-7">
                                            <select class="form-control" style="color:#000000" name="childsex" id="childsex" required="required">
                                                <option value=""></option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>

                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Date of Birth: </label>
                                        <div class="col-lg-7">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="childdate" id="childdate" required="required">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="updatesingle_child" class="btn btn-info" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Delete Modal Professional Body -->
                <div id="deleteModal_child" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Child</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id_child" id="delete_id_child">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_child" class="btn btn-danger" value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                <!-- FUNDED RESERCH AND CONSULTANCY -->
                <!-- Add New Modal Reserach -->
                <div id="addReserchModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="post" action="">
                                <div class="modal-header">
                                    <h4 class="modal-title">Add New Funded Reserch and Consultancy</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Project No: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="projectNo" value="" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Title of Award: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="awardTitle" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">In-Kind Required by Grant: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="InKindReq" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Release Time: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="ReleaseTime" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Total(Amount): </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="amount" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Remark: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="remark" value="" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" class="btn btn-success" name="addnew_reserch" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Edit Modal Reserch -->
                <div id="editModal_reserch" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <input type="hidden" name="update_id_research" id="update_id_research">
                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Record</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Project No: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="projectNo" id="projectNo" value="" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Title of Award: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="awardTitle" id="awardTitle" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">In-Kind Required by Grant: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="InKindReq" id="InKindReq" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Release Time: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="ReleaseTime" id="ReleaseTime" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Total(Amount): </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="amount" id="amount" value="" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Remark: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="remark" id="remark" value="" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="updatesingle_reserch" class="btn btn-info" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Delete Modal Reserch -->
                <div id="deleteModal_reserch" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Reserch and Consultancy</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id_research" id="delete_id_research">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_reserch" class="btn btn-danger" value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                <!-- COMMUNITY SERVICE -->

                <!-- Add New Modal Community -->
                <div id="addCommModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="post" action="">
                                <div class="modal-header">
                                    <h4 class="modal-title">Add New Community Service</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Type: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="type_comm" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Beneficiary: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="beneficiary" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Effect: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="effect" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Date: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="dateExecute" required="required">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" class="btn btn-success" name="addnew_Comm" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Edit Modal Community -->
                <div id="editModal_comm" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <input type="hidden" name="update_id_comm" id="update_id_comm">
                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Community Service</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Type: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="type_comm" id="type_comm" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Beneficiary: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="beneficiary" id="beneficiary" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Effect: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="effect" id="effect" required="required">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Date: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="dateExecute" id="dateExecute" required="required">
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="updatesingle_comm" class="btn btn-info" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Delete Modal Community -->
                <div id="deleteModal_comm" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Community Service</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id_comm" id="delete_id_comm">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_comm" class="btn btn-danger" value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- INSTITUTIONS ATTEND -->

                <!-- Add New Institution -->
                <div id="addAcadQualiModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form enctype="multipart/form-data" action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Add New Institution</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Institution Name: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="institu_name" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">From: </label>
                                        <div class="col-lg-7">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="yearFrom" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">To: </label>
                                        <div class="col-lg-7">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="yearTo" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Qualification Obtained: </label>
                                        <div class="col-lg-7">
                                            <select class="form-control" style="color:#000000" name="quali_obtain" required="required">
                                                <option value=""></option>
                                                <option value="Primary Certificate">Primary Certificate</option>
                                                <option value="Secondary Certificate">Secondary Certificate</option>
                                                <option value="ND Certificate">ND Certificate</option>
                                                <option value="HND Certificate">HND Certificate</option>
                                                <option value="NCE Certificate">NCE Certificate</option>
                                                <option value="First Degree Certificate">First Degree Certificate
                                                </option>
                                                <option value="Masters Certificate">Masters Certificate</option>
                                                <option value="PhD Certificate">PhD Certificate</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Qualification Date: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="quali_date" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">File Upload:</label>
                                        <div class="col-md-8">
                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                <div class="input-append">
                                                    <div class="uneditable-input">
                                                        <i class="fa fa-file fileupload-exists"></i>
                                                        <span class="fileupload-preview"></span>
                                                    </div>
                                                    <span class="btn btn-default btn-file">
                                                        <span class="fileupload-exists">Change</span>
                                                        <span class="fileupload-new">Select file</span>
                                                        <input type="file" name="uploaded_cert" required />
                                                    </span>
                                                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" class="btn btn-success" name="addnew_institu" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Edit Modal Institution -->
                <div id="editModal_institu" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form enctype="multipart/form-data" action="" method="POST">
                                <input type="hidden" name="update_id_institu" id="update_id_institu">
                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Institution Attended</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Institution Name: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="institu_name" id="institu_name" required="required">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">From: </label>
                                        <div class="col-lg-7">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="yearFrom" id="yearFrom" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">To: </label>
                                        <div class="col-lg-7">
                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="yearTo" id="yearTo" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Qualification Obtained: </label>
                                        <div class="col-lg-7">
                                            <input type="text" class="form-control" style="color:#000000" name="quali_obtain" id="quali_obtain" readonly />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Qualification Date: </label>
                                        <div class="col-lg-7">

                                            <div class="input-group">
                                                <span class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                </span>
                                                <input type="text" data-plugin-datepicker class="form-control" name="quali_date" id="quali_date" required="required">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">File Upload:</label>
                                        <div class="col-md-8">
                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                <div class="input-append">
                                                    <div class="uneditable-input">
                                                        <i class="fa fa-file fileupload-exists"></i>
                                                        <span class="fileupload-preview"></span>
                                                    </div>
                                                    <span class="btn btn-default btn-file">
                                                        <span class="fileupload-exists">Change</span>
                                                        <span class="fileupload-new">Select file</span>
                                                        <input type="file" name="uploaded_cert" required />
                                                    </span>
                                                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="updatesingle_institu" class="btn btn-info" value="Save">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Delete Modal Institution -->
                <div id="deleteModal_institu" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Institution Attended</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="delete_id_institu" id="delete_id_institu">
                                    <p>Are you sure you want to delete these Records?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_institu" class="btn btn-danger" value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                <!-- Delete Modal Images -->
                <div id="deleteModal_image" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete Image</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="del_img_id" id="del_img_id">
                                    <p>Are you sure you want to delete these image?</p>

                                    <p class="text-warning"><small>This action cannot be undone.</small></p>
                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="deletesingle_image" class="btn btn-danger" value="Delete">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Download Modal Images -->
                <div id="downloadModal_image" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="" method="POST">
                                <div class="modal-header">
                                    <h4 class="modal-title">Download Image</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="downl_img_id" id="downl_img_id">
                                    <p>Confirm Downloading these image?</p>

                                </div>
                                <div class="modal-footer">
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                    <input type="submit" name="downloadsingle_image" class="btn btn-info" value="Download">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <?php
                include_once 'includes/footer.php';
                ?>
                <!-- Jasny -->
                <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>

                <script type="text/javascript">
                    $(document).ready(function() {
                        $("select.activit").change(function() {
                            var selectedState = $(".activit option:selected").val();
                            $.ajax({
                                type: "POST",
                                url: 'ajax_save_rec/ajaxDataProfile.php',
                                data: {
                                    activit: selectedState
                                }
                            }).done(function(data) {
                                $("#GetResponse").html(data);
                            });
                        });
                    });
                </script>

                <!-- Administrative Duties -->
                <script>
                    $(document).ready(function() {

                        $('.delete_duties').on('click', function() {

                            $('#deleteModal_duties').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#delete_id').val(data[0]);

                        });
                    });
                </script>

                <!-- Children -->
                <script>
                    $(document).ready(function() {

                        $('.delete_child').on('click', function() {

                            $('#deleteModal_child').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#delete_id_child').val(data[0]);

                        });
                    });
                </script>

                <script>
                    $(document).ready(function() {

                        $('.editone_child').on('click', function() {

                            $('#editModal_child').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#update_id_child').val(data[0]);
                            $('#childname').val(data[1]);
                            $('#childsex').val(data[2]);
                            $('#childdate').val(data[3]);

                        });
                    });
                </script>


                <!-- Community Service -->
                <script>
                    $(document).ready(function() {

                        $('.delete_comm').on('click', function() {

                            $('#deleteModal_comm').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#delete_id_comm').val(data[0]);

                        });
                    });
                </script>

                <script>
                    $(document).ready(function() {

                        $('.editone_comm').on('click', function() {

                            $('#editModal_comm').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#update_id_comm').val(data[0]);
                            $('#type_comm').val(data[1]);
                            $('#beneficiary').val(data[2]);
                            $('#effect').val(data[3]);
                            $('#dateExecute').val(data[4]);

                        });
                    });
                </script>

                <!-- Professional Body -->
                <script>
                    $(document).ready(function() {

                        $('.delete_profbody').on('click', function() {

                            $('#deleteModal_profbody').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#delete_id_profbody').val(data[0]);

                        });
                    });
                </script>

                <script>
                    $(document).ready(function() {

                        $('.editone_profbody').on('click', function() {

                            $('#editModal_profbody').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#update_id_profbody').val(data[0]);
                            $('#profbodyname').val(data[1]);
                            $('#profbodydate').val(data[2]);


                        });
                    });
                </script>


                <!-- Reserch and Consultancy -->
                <script>
                    $(document).ready(function() {

                        $('.delete_reserch').on('click', function() {

                            $('#deleteModal_reserch').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#delete_id_research').val(data[0]);

                        });
                    });
                </script>

                <script>
                    $(document).ready(function() {

                        $('.editone_reserch').on('click', function() {

                            $('#editModal_reserch').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#update_id_research').val(data[0]);
                            $('#projectNo').val(data[1]);
                            $('#awardTitle').val(data[2]);
                            $('#InKindReq').val(data[3]);
                            $('#ReleaseTime').val(data[4]);
                            $('#amount').val(data[5]);
                            $('#remark').val(data[6]);

                        });
                    });
                </script>

                <!-- Institution Attend -->
                <script>
                    $(document).ready(function() {

                        $('.delete_institu').on('click', function() {

                            $('#deleteModal_institu').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#delete_id_institu').val(data[0]);

                        });
                    });
                </script>

                <script>
                    $(document).ready(function() {

                        $('.editone_institu').on('click', function() {

                            $('#editModal_institu').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#update_id_institu').val(data[0]);
                            $('#institu_name').val(data[1]);
                            $('#yearFrom').val(data[2]);
                            $('#yearTo').val(data[3]);
                            $('#quali_obtain').val(data[4]);
                            $('#quali_date').val(data[5]);

                        });
                    });
                </script>

                <!-- Images -->
                <script>
                    $(document).ready(function() {

                        $('.delete_image').on('click', function() {

                            $('#deleteModal_image').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#del_img_id').val(data[0]);

                        });
                    });
                </script>

                <script>
                    $(document).ready(function() {

                        $('.download_image').on('click', function() {

                            $('#downloadModal_image').modal('show');

                            $tr = $(this).closest('tr');

                            var data = $tr.children("td").map(function() {
                                return $(this).text();
                            }).get();

                            console.log(data);

                            $('#del_img_id').val(data[0]);

                        });
                    });
                </script>
</body>

</html>
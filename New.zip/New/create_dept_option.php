<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['Administrator'] !== "YES" && $_SESSION['Sub_Admin'] !== "YES") {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Create Dept Option</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Settings
                            </li>

                            <li class="active">
                                <strong>Create Dept Option</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Create Dept Option
                        </div>
                        <div class="panel-body">
                            <?php
                            $success = "";
                            $_SESSION['yesCurri'] = "NO";
                            $yesCurri = "NO";


                            $GetTheSession = $_SESSION['resultsession'];
                            if (isset($_POST["addnew"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                $optcode = strtoupper($_POST["optcode"]);
                                $opttitle = $_POST["opttitle"];
                                $crtOptDept = $_SESSION["crtOptDept"];

                                $sql = "UPDATE deptcoding SET deptoption = 'YES' WHERE DeptCode = '$crtOptDept'";
                                $result = $conn->query($sql);

                                //$dept2 = $_SESSION["dept"];

                                $dept_db = $_SESSION['deptdb'] . strtolower($crtOptDept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                if ($_SESSION['yesCurri'] == "YES") {
                                    $sql2 = "SELECT * FROM dept_curriculum WHERE deptcode = '$crtOptDept'";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $curri = $row2["curri_Code"];

                                            if ($curri == "OLD") {
                                                $curri2 = "";
                                            } else {
                                                $curri2 = "_" . $curri;
                                            }

                                            try {
                                                $sql = "ALTER TABLE gencourses" . $curri2 . " ADD NOP VARCHAR(10) NOT NULL AFTER Relevant";
                                                $result = $conn_stu->query($sql);

                                                $sql = "UPDATE gencourses" . $curri2 . " SET NOP='YES'";
                                                $result = $conn_stu->query($sql);
                                            } catch (Exception $e) {
                                            }

                                            $sql = "ALTER TABLE gencourses" . $curri2 . " ADD " . $optcode . " VARCHAR(10) NOT NULL AFTER NOP";
                                            $result = $conn_stu->query($sql);

                                            $sql = "UPDATE gencourses" . $curri2 . " SET " . $optcode . "='YES'";
                                            $result = $conn_stu->query($sql);

                                            $newCode = "Group" . $optcode;
                                            $sql = "ALTER TABLE gencourses" . $curri2 . " ADD " . $newCode . " VARCHAR(10) NOT NULL AFTER Grouping";
                                            $result = $conn_stu->query($sql);

                                            $sql = "UPDATE gencourses" . $curri2 . " SET " . $newCode . "='NO'";
                                            $result = $conn_stu->query($sql);

                                            $newCode = "Core_" . $optcode;
                                            $sql = "ALTER TABLE gencourses" . $curri2 . " ADD " . $newCode . " VARCHAR(10) NOT NULL AFTER Core";
                                            $result = $conn_stu->query($sql);

                                            $sql = "UPDATE gencourses" . $curri2 . " SET " . $newCode . "='NO'";
                                            $result = $conn_stu->query($sql);

                                            $newCode = "CoreDE200_" . $optcode;
                                            $sql = "ALTER TABLE gencourses" . $curri2 . " ADD " . $newCode . " VARCHAR(10) NOT NULL AFTER CoreDE200";
                                            $result = $conn_stu->query($sql);

                                            $sql = "UPDATE gencourses" . $curri2 . " SET " . $newCode . "='NO'";
                                            $result = $conn_stu->query($sql);

                                            $newCode = "CoreDE300_" . $optcode;
                                            $sql = "ALTER TABLE gencourses" . $curri2 . " ADD " . $newCode . " VARCHAR(10) NOT NULL AFTER CoreDE300";
                                            $result = $conn_stu->query($sql);

                                            $sql = "UPDATE gencourses" . $curri2 . " SET " . $newCode . "='NO'";
                                            $result = $conn_stu->query($sql);
                                        }
                                    }
                                } else {

                                    try {
                                        $sql = "ALTER TABLE gencourses ADD NOP VARCHAR(10) NOT NULL AFTER Relevant";
                                        $result = $conn_stu->query($sql);

                                        $sql = "UPDATE gencourses SET NOP='YES'";
                                        $result = $conn_stu->query($sql);
                                    } catch (Exception $e) {
                                    }

                                    $sql = "ALTER TABLE gencourses ADD " . $optcode . " VARCHAR(10) NOT NULL AFTER NOP";
                                    $result = $conn_stu->query($sql);

                                    $sql = "UPDATE gencourses SET " . $optcode . "='YES'";
                                    $result = $conn_stu->query($sql);

                                    $newCode = "Group" . $optcode;
                                    $sql = "ALTER TABLE gencourses ADD " . $newCode . " VARCHAR(10) NOT NULL AFTER Core";
                                    $result = $conn_stu->query($sql);

                                    $sql = "UPDATE gencourses SET " . $newCode . "='NO'";
                                    $result = $conn_stu->query($sql);

                                    $newCode = "Core_" . $optcode;
                                    $sql = "ALTER TABLE gencourses ADD " . $newCode . " VARCHAR(10) NOT NULL AFTER Core";
                                    $result = $conn_stu->query($sql);

                                    $sql = "UPDATE gencourses SET " . $newCode . "='NO'";
                                    $result = $conn_stu->query($sql);

                                    $newCode = "CoreDE200_" . $optcode;
                                    $sql = "ALTER TABLE gencourses ADD " . $newCode . " VARCHAR(10) NOT NULL AFTER CoreDE200";
                                    $result = $conn_stu->query($sql);

                                    $sql = "UPDATE gencourses SET " . $newCode . "='NO'";
                                    $result = $conn_stu->query($sql);

                                    $newCode = "CoreDE300_" . $optcode;
                                    $sql = "ALTER TABLE gencourses ADD " . $newCode . " VARCHAR(10) NOT NULL AFTER CoreDE300";
                                    $result = $conn_stu->query($sql);

                                    $sql = "UPDATE gencourses SET " . $newCode . "='NO'";
                                    $result = $conn_stu->query($sql);
                                }


                                $sql = "SELECT * FROM dept_option WHERE deptcode = '$crtOptDept' AND Opt_Code = '$optcode'";
                                $result = $conn->query($sql);
                                if ($result->num_rows == 0) {
                                    $sql2 = "INSERT INTO dept_option(Opt_Code, Opt_Title, deptcode) VALUES ('$optcode','$opttitle','$crtOptDept')";
                                    $result2 = $conn->query($sql2);
                                }
                                $sql = "SELECT * FROM dept_option WHERE deptcode = '$crtOptDept' AND Opt_Code = 'NOP'";
                                $result = $conn->query($sql);
                                if ($result->num_rows == 0) {
                                    $sql2 = "INSERT INTO dept_option(Opt_Code, Opt_Title, deptcode) VALUES ('NOP','No Option','$crtOptDept')";
                                    $result2 = $conn->query($sql2);
                                }

                                //$success = "Record Saved Successfully";
                                echo '<script type="text/javascript">';
                                echo 'window.location.href = "includes/logout.php"';
                                echo '</script>';
                                $conn->close();
                                $conn2->close();
                                $conn_stu->close();
                            }

                            if (isset($_POST['deletesingle'])) {
                                $id = $_POST['delete_id'];
                                $crtOptDept = $_SESSION["crtOptDept"];

                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                $sql = "SELECT * FROM dept_option WHERE id = '$id'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $optcode = $row["Opt_Code"];
                                    }
                                }

                                //$dept2 = $_SESSION["dept"];

                                $dept_db = $_SESSION['deptdb'] . strtolower($crtOptDept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                if ($_SESSION['yesCurri'] == "YES") {
                                    $sql2 = "SELECT * FROM dept_curriculum WHERE deptcode = '$crtOptDept'";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $curri = $row2["curri_Code"];

                                            if ($curri == "OLD") {
                                                $curri2 = "";
                                            } else {
                                                $curri2 = "_" . $curri;
                                            }

                                            $sql = "ALTER TABLE gencourses" . $curri2 . " DROP " . $optcode;
                                            $result = $conn_stu->query($sql);

                                            $newCode = "Group" . $optcode;
                                            $sql = "ALTER TABLE gencourses" . $curri2 . " DROP " . $newCode;
                                            $result = $conn_stu->query($sql);

                                            $newCode = "Core_" . $optcode;
                                            $sql = "ALTER TABLE gencourses" . $curri2 . " DROP " . $newCode;
                                            $result = $conn_stu->query($sql);

                                            $newCode = "CoreDE200_" . $optcode;
                                            $sql = "ALTER TABLE gencourses" . $curri2 . " DROP " . $newCode;
                                            $result = $conn_stu->query($sql);

                                            $newCode = "CoreDE300_" . $optcode;
                                            $sql = "ALTER TABLE gencourses" . $curri2 . " DROP " . $newCode;
                                            $result = $conn_stu->query($sql);
                                        }
                                    }
                                } else {
                                    $sql = "ALTER TABLE gencourses DROP " . $optcode;
                                    $result = $conn_stu->query($sql);

                                    $newCode = "Group" . $optcode;
                                    $sql = "ALTER TABLE gencourses DROP " . $newCode;
                                    $result = $conn_stu->query($sql);

                                    $newCode = "Core_" . $optcode;
                                    $sql = "ALTER TABLE gencourses DROP " . $newCode;
                                    $result = $conn_stu->query($sql);

                                    $newCode = "CoreDE200_" . $optcode;
                                    $sql = "ALTER TABLE gencourses DROP " . $newCode;
                                    $result = $conn_stu->query($sql);

                                    $newCode = "CoreDE300_" . $optcode;
                                    $sql = "ALTER TABLE gencourses DROP " . $newCode;
                                    $result = $conn_stu->query($sql);
                                }


                                $sql = "UPDATE std_data_new SET Dept_Option='NOP' WHERE Dept_Option = '$optcode'";
                                $result = $conn2->query($sql);

                                $StuCurSess = str_ireplace("/", "_", $GetTheSession);
                                $sql = "UPDATE correg_" . $StuCurSess . " SET deptOption='NOP' WHERE deptOption = '$optcode'";
                                $result = $conn_stu->query($sql);

                                $sql = "DELETE FROM scrutiny_senate WHERE DeptOpt='$optcode' AND session1='$GetTheSession'";
                                $result = $conn_stu->query($sql);

                                $sql = "DELETE FROM dept_option WHERE id='$id'";
                                $result = $conn->query($sql);

                                $sql = "SELECT * FROM dept_option";
                                $result = $conn->query($sql);
                                if ($result->num_rows <= 1) {
                                    $sql = "UPDATE deptcoding SET deptoption='NO' WHERE DeptCode = '$crtOptDept'";
                                    $result = $conn->query($sql);
                                }
                                $conn->close();
                                $conn2->close();
                                $conn_stu->close();
                                //$success = "Record Deleted Successfully";
                                echo '<script type="text/javascript">';
                                echo 'window.location.href = "includes/logout.php"';
                                echo '</script>';
                            }

                            if (isset($_POST['updatesingle'])) {
                                $id = $_POST['update_id'];
                                $opttitle = $_POST['opttitle'];

                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $sql = "UPDATE dept_option SET Opt_Title='$opttitle' WHERE id = '$id'";
                                $result = $conn->query($sql);
                                $conn->close();
                                $success = "Record Updated Successfully";
                            }

                            ?>
                            <div class="row">
                                <div class="col-lg-1">

                                </div>
                                <div class="col-lg-10">
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="row">

                                            <div class="col-lg-4">
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Select
                                                        Department:</label>
                                                    <div class="col-lg-7">
                                                        <select class="country form-control" style="color:#000000" name="dept">
                                                            <option value="SelectItem">Select Item</option>
                                                            <?php
                                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                            if ($conn->connect_error) {
                                                                die("Connection failed: " . $conn->connect_error);
                                                            }
                                                            $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                            $result = $conn->query($sql);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $deptcode2 = strtolower($row["DeptCode"]);
                                                                    $deptname2 = $row["DeptName"];
                                                                    echo "<option value=$deptcode2>$deptname2</option>";
                                                                }
                                                            }
                                                            $conn->close();
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-lg-4">
                                                <div class="row">

                                                    <div class="col-lg-4">
                                                        <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </form>

                                    <?php if (isset($_POST["submit"]) || isset($_POST["addnew"]) || isset($_POST["deletesingle"]) || isset($_POST["updatesingle"])) { ?>
                                        <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        if (isset($_POST["submit"])) {
                                            $crtOptDept = $_POST["dept"];
                                            $_SESSION["crtOptDept"] = $crtOptDept;

                                            //$crtOptDept = strtoupper($_SESSION["crtOptDept"]);
                                            $_SESSION['yesCurri'] = "NO";
                                            //$yesCurri = "NO";
                                            $sql = "SELECT DeptName, DeptCode, curriculum FROM deptcoding WHERE DeptCode = '$crtOptDept'";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $deptname = $row["DeptName"];
                                                    $yesCurri = $row["curriculum"];
                                                    $_SESSION['yesCurri'] = $yesCurri;
                                                }
                                            }
                                        } else {
                                            $crtOptDept = $_SESSION["crtOptDept"];
                                        }

                                        /* $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$crtOptDept'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $deptname = $row["DeptName"];
                                            }
                                        } */
                                        ?>

                                        <br>
                                        <br>
                                        <h2 style="color: blue"><?php echo $success ?></h2>
                                        <h2 style="text-align: center"><?php echo $deptname ?> Department</h2>

                                        <div style="text-align: right">
                                            <a href="#addEmployeeModal" class="btn btn-success btn-xs" data-toggle="modal"><span>Add
                                                    New</span></a>
                                            <!--<a href="#deleteEmployeeModal" class="btn btn-danger btn-xs" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>-->
                                        </div>
                                        <br>
                                        <table class="table table-bordered table-striped mb-none" id="datatable-default">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <span class="custom-checkbox">
                                                            <input type="checkbox" id="selectAll">
                                                            <label for="selectAll"></label>
                                                        </span>
                                                    </th>
                                                    <th hidden="hidden">ID</th>
                                                    <th style='text-align:center'>Option Code</th>
                                                    <th style='text-align:center'>Option Title</th>

                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                //$dept=$_POST["dept"];
                                                $sno = 0;

                                                $sql = "SELECT * FROM dept_option WHERE deptcode = '$crtOptDept' ORDER BY Opt_Title";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $Opt_Code = $row["Opt_Code"];
                                                        $Opt_Title = $row["Opt_Title"];
                                                        $id = $row["id"];
                                                ?>
                                                        <tr>
                                                            <td>
                                                                <span class="custom-checkbox">
                                                                    <input type="checkbox" id="checkbox1" name="options[]" value="1">
                                                                    <label for="checkbox1"></label>
                                                                </span>
                                                            </td>
                                                            <td hidden="hidden"><?php echo $id; ?></td>
                                                            <td><?php echo $Opt_Code; ?></td>
                                                            <td><?php echo $Opt_Title; ?></td>

                                                            <td>
                                                                <?php if ($Opt_Code != "NOP") { ?>
                                                                    <button type="button" class='btn btn-default btn-xs editone'><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></button>
                                                                    <button type="button" class='btn btn-default btn-xs deleteone'><i class="material-icons" data-toggle="tooltip" title="Delete" style="color: red">&#xE872;</i></button>
                                                                <?php } ?>
                                                            </td>

                                                        </tr>

                                                <?php
                                                    }
                                                }

                                                ?>


                                            </tbody>
                                        </table>

                                        <?php
                                        $conn->close();
                                        ?>
                                    <?php } ?>


                                    <!-- Add New Modal HTML -->
                                    <div id="addEmployeeModal" class="modal fade">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form method="post" action="">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Add New Option</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label>Option Code</label>
                                                            <input type="text" class="form-control" name="optcode" placeholder="Option Code..." required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option Title</label>
                                                            <input type="text" class="form-control" name="opttitle" placeholder="Option Title" required>
                                                        </div>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                        <input type="submit" class="btn btn-success" name="addnew" value="Save">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Edit Modal HTML -->
                                    <div id="editModal" class="modal fade">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="" method="POST">
                                                    <input type="hidden" name="update_id" id="update_id">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Edit Record</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label>Option Code</label>
                                                            <input type="text" name="optcode" id="optcode" disabled="disabled" class="form-control" placeholder="Enter Option Code">

                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option Title</label>
                                                            <input type="text" name="opttitle" id="opttitle" class="form-control" placeholder="Enter Option Title" required>

                                                        </div>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                        <input type="submit" name="updatesingle" class="btn btn-info" value="Save">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Delete Modal HTML -->
                                    <div id="deleteModal" class="modal fade">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="" method="POST">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Delete Option</h4>
                                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="delete_id" id="delete_id">
                                                        <p>Are you sure you want to delete these Records?</p>

                                                        <p class="text-warning"><small>This action cannot be
                                                                undone.</small>
                                                        </p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                        <input type="submit" name="deletesingle" class="btn btn-danger" value="Delete">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-lg-1">

                                </div>


                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
        $(document).ready(function() {
            // Activate tooltip
            $('[data-toggle="tooltip"]').tooltip();

            // Select/Deselect checkboxes
            var checkbox = $('table tbody input[type="checkbox"]');
            $("#selectAll").click(function() {
                if (this.checked) {
                    checkbox.each(function() {
                        this.checked = true;
                    });
                } else {
                    checkbox.each(function() {
                        this.checked = false;
                    });
                }
            });
            checkbox.click(function() {
                if (!this.checked) {
                    $("#selectAll").prop("checked", false);
                }
            });
        });
    </script>

    <script>
        $(document).ready(function() {

            $('.deleteone').on('click', function() {

                $('#deleteModal').modal('show');

                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function() {
                    return $(this).text();
                }).get();

                console.log(data);

                $('#delete_id').val(data[1]);

            });
        });
    </script>

    <script>
        $(document).ready(function() {

            $('.editone').on('click', function() {

                $('#editModal').modal('show');

                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function() {
                    return $(this).text();
                }).get();

                console.log(data);

                $('#update_id').val(data[1]);
                $('#optcode').val(data[2]);
                $('#opttitle').val(data[3]);

            });
        });
    </script>
</body>

</html>
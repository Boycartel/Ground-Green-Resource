<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: Home_Staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--To Delete
		<link href='delete_res/bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
    <script src='delete_res/jquery-3.3.1.js' type='text/javascript'> </script>
    <script src='delete_res/bootstrap/js/bootstrap.min.js'> </script>
    <script src='delete_res/bootbox.min.js'> </script>-->

    <!-- End To Delete -->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <?php
        $success = "";
        $cursession = $_SESSION['resultsession'];
        $resultsemester = $_SESSION['resultsemester'];
        $deptoption = $_SESSION['deptoption'];
        $deptname = $_SESSION["deptname"];
        $schcode = $_SESSION['schcode'];
        $corntsession = $_SESSION['corntsession'];

        $deptname = $_SESSION['deptname'];
        $dept = $_SESSION['deptcode'];

        if (isset($_POST["submit_level"])) {
            $regid = $_POST['regid'];
            $studept = $_POST['studept'];
            $getlevel = $_POST['getlevel'];
            $stuname = $_POST['stuname'];

            $dept_db = $_SESSION['deptdb'] . strtolower($studept);
            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
            if ($conn_stu->connect_error) {
                die("Connection failed: " . $conn_stu->connect_error);
            }

            $sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND session1 = '$cursession' AND semester = '$resultsemester'";
            $result = $conn_stu->query($sql);
            if ($result->num_rows == 0) {
                $sql2 = "INSERT INTO scrutiny_senate(Regn, Name1, semester, session1, Level1)VALUES('$regid', '$stuname', '$resultsemester', '$cursession', '$getlevel')";
                $result2 = $conn_stu->query($sql2);
            } else {
                $sql2 = "UPDATE scrutiny_senate SET Level1 = '$getlevel' WHERE Regn = '$regid' AND session1 = '$cursession' AND semester = '$resultsemester'";
                $result2 = $conn_stu->query($sql2);
            }

            $newLevel = $getlevel + 100;
            $sql = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 = '$corntsession'";
            $result = $conn_stu->query($sql);
            if ($result->num_rows > 0) {
                $sql2 = "UPDATE hod_list SET StuLevel = '$newLevel' WHERE matricno = '$regid' AND Session1 = '$corntsession'";
                $result2 = $conn_stu->query($sql2);
            }
            $conn_stu->close();
            $success = "<h2 style='color: green'>Record Saved Successfully ...</h2>";
        }

        if (isset($_POST["delete"])) {
            $id = $_POST['id'];
            $studept = $_POST['studept'];


            $dept_db = $_SESSION['deptdb'] . strtolower($studept);
            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
            if ($conn_stu->connect_error) {
                die("Connection failed: " . $conn_stu->connect_error);
            }

            $sql = "DELETE FROM diff_outs_courses WHERE sn = '$id'";
            $result = $conn_stu->query($sql);
            $conn_stu->close();
            $success = "<h2 style='color: green'>Record Deleted Successfully ... </h2>";
        }
        ?>
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Setup</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Setup</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Setup
                        </div>
                        <div class="panel-body">
                            <div>
                                <div class="col-lg-1">

                                </div>
                                <div class="col-lg-10 table-responsive">

                                    <h3><?php echo $success ?></h3>
                                    <div class="card">
                                        <form class="form-horizontal form-bordered" method="post">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="row">
                                                        <label class="control-label col-lg-5" for="regid">Matric
                                                            Number:</label>
                                                        <div class="col-lg-7">
                                                            <input type="text" class="form-control" name="regid" required="required">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3">

                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                    <hr class="separator" />
                                    <?php if (isset($_POST["submit"]) || isset($_POST["submit_level"]) || isset($_POST["delete"])) { ?>
                                        <?php
                                        if (isset($_POST["submit"])) {
                                            $regid = $_POST["regid"];
                                            $_SESSION['regid'] = $regid;
                                        } else {
                                            $regid = $_SESSION['regid'];
                                        }

                                        $studept = "XX";
                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        $cursession = $_SESSION['resultsession'];
                                        $resultsemester = $_SESSION['resultsemester'];

                                        $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                        $result = $conn2->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                $entry_session = $row['entry_session'];
                                                $studept = $row['dept_code'];
                                            }
                                        }
                                        if ($studept == "XX") {
                                            goto NotReg;
                                        }
                                        $dept_db = $_SESSION['deptdb'] . strtolower($studept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        $sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$regid' AND session1 = '$cursession' AND semester = '$resultsemester'";
                                        $result = $conn_stu->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $Level1 = $row['Level1'];
                                            }
                                        } else {
                                            $Level1 = "000";
                                        }


                                        ?>
                                        <div class="row">
                                            <h3>Matric No:- <?php echo $regid ?></h3>
                                            <h3>Name:- <?php echo $names ?></h3>
                                        </div>
                                        <div class="row">
                                            <form class="form-horizontal form-bordered" method="post">
                                                <div class="row">

                                                    <input type="hidden" name="regid" value="<?php echo $regid ?>">
                                                    <input type="hidden" name="studept" value="<?php echo $studept ?>">
                                                    <input type="hidden" name="stuname" value="<?php echo $names ?>">
                                                    <div class="col-lg-4">
                                                        <div class="form-group">
                                                            <label class="control-label col-lg-5" for="getlevel">Select Last
                                                                Level(500 for Spillover Students):</label>
                                                            <div class="col-lg-7">
                                                                <select name="getlevel" class="form-control" style="color:#000000" id="getlevel" required="required">
                                                                    <option value='<?php echo $Level1 ?>'>
                                                                        <?php echo $Level1 ?></option>
                                                                    <option value='0'>000</option>
                                                                    <option value='100'>100</option>
                                                                    <option value='200'>200</option>
                                                                    <option value='300'>300</option>
                                                                    <option value='400'>400</option>
                                                                    <option value='500'>500</option>

                                                                </select>
                                                            </div>
                                                        </div>

                                                    </div>



                                                    <div class="col-lg-4">
                                                        <div class="form-group">
                                                            <label class="control-label col-lg-6"></label>
                                                            <div class="col-lg-6">
                                                                <button type="submit" name="submit_level" class="btn btn-primary btn-sm">Save Level</button>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>



                                            </form>
                                        </div>
                                        <h3>Outstanding Courses</h3>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Credit Unit</th>
                                                    <th>Semester</th>

                                                    <th>Action</th>


                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                $sno = 0;

                                                $sql = "SELECT * FROM diff_outs_courses WHERE Regn1 = '$regid' ORDER BY SemTaken, CCode";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $id = $row["sn"];
                                                        $CCode = $row["CCode"];
                                                        $CTitle = $row["CTitle"];
                                                        $CUnit = $row["CUnit"];
                                                        $SemTaken = $row["SemTaken"];

                                                        echo "<tr id='$id'><td>$sno</td><td>$CCode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td>";


                                                ?>
                                                        <td>
                                                            <form class="form-horizontal form-bordered" method="post">
                                                                <input type="hidden" name="id" value="<?php echo $id ?>">
                                                                <input type="hidden" name="studept" value="<?php echo $studept ?>">
                                                                <button type="submit" name="delete" class="btn btn-danger btn-xs">Delete</button>
                                                            </form>
                                                        </td>
                                                <?php
                                                        echo "</tr>\n";
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <?php
                                        $conn2->close();
                                        goto End1;
                                        NotReg:
                                        echo "<h2>Not Registered</h2>";
                                        End1:
                                        $conn_stu->close();
                                        ?>
                                    <?php } ?>


                                </div>
                                <div class="col-lg-1">

                                </div>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>

        <script type="text/javascript">
            $(".remove-record").click(function() {
                var id = $(this).parents("tr").attr("id");
                if (confirm('Are you sure to delete this record ?')) {
                    $.ajax({
                        url: 'delete_res/delete_course_setup.php',
                        type: 'GET',
                        data: {
                            id: id
                        },
                        error: function() {
                            alert('Something is wrong, couldn\'t delete record');
                        },
                        success: function(data) {
                            $("#" + id).remove();
                            alert("Record delete successfully.");
                        }
                    });
                }
            });
        </script>
</body>

</html>
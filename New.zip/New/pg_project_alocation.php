<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pg_project_alocation'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <script src="assets/javascripts/tableToExcel_qap.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>


</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <?php
            $dept = $_SESSION['deptcode'];

            ?>

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>PG Project Allocation</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-support (alias)"></i>
                                </a>
                            </li>
                            <li><span>PG Pregress Report</span></li>
                            <li><span>PG Project Allocation</span></li>
                        </ol>


                    </div>
                </header>

                <!-- start: page -->
                <div class="row">
                    <?php
                    if (isset($_POST["update1"])) {

                        $progtitle = $_SESSION["progtitle"];
                        $sessionadmt = $_SESSION["sessionadmt"];
                        $project_title = str_replace("'", "''", $_POST['projtitle']);
                        $project_title = filter_var($project_title, FILTER_SANITIZE_STRING);
                        $regid2 = $_POST['regid2'];
                        $name2 = $_POST['name2'];
                        $majoesuper = $_POST['majoesuper'];

                        $sql = "SELECT * FROM users WHERE staffid='$majoesuper'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $major_dept = $row["staffacddept"];
                                $full_name = $row["full_name"];
                            }
                        }

                        $sql = "INSERT INTO progress_report (regid, full_name, prog_title, stu_dept, sessionadmt, project_title, major_sup_pf, major_sup_dept, major_sup) VALUES ('$regid2', '$name2', '$progtitle', '$dept', '$sessionadmt', '$project_title', '$majoesuper', '$major_dept', '$full_name')";
                        $result = $conn5->query($sql);

                        $sql = "SELECT * FROM supervisors WHERE fileno='$majoesuper'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows == 0) {
                            $sql2 = "INSERT INTO supervisors (fileno, name1, dept) VALUES ('$majoesuper', '$full_name', '$major_dept')";
                            $result2 = $conn5->query($sql2);
                        }

                        echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                    }

                    if (isset($_POST["updatemajorsup"])) {
                        $regid2 = $_POST['regid2'];
                        $progtitle = $_SESSION["progtitle"];
                        $project_title = str_replace("'", "''", $_POST['projtitle']);
                        $project_title = filter_var($project_title, FILTER_SANITIZE_STRING);

                        $majoesuper = $_POST['majoesuper'];

                        $sql = "SELECT * FROM users WHERE staffid='$majoesuper'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $dept_major = $row["staffacddept"];
                                $full_name_major = $row["full_name"];
                                $area_special_major = $row["area_special"];
                            }
                        }

                        $sql = "UPDATE progress_report SET project_title='$project_title', major_sup_pf='$majoesuper', major_sup_dept='$dept_major', major_sup='$full_name_major', major_sup_area_spec='$area_special_major' WHERE regid='$regid2'";

                        $result = $conn5->query($sql);

                        $sql = "SELECT * FROM supervisors WHERE fileno='$majoesuper'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows == 0) {
                            $sql2 = "INSERT INTO supervisors (fileno, name1, dept, area_special) VALUES ('$majoesuper', '$full_name_major', '$dept_major', '$area_special_major')";
                            $result2 = $conn5->query($sql2);
                        }

                        echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                    }

                    if (isset($_POST["updatecosup"])) {
                        $regid2 = $_POST['regid2'];
                        $progtitle = $_SESSION["progtitle"];

                        $cosuper1 = $_POST['cosuper1'];
                        $cosuper2 = $_POST['cosuper2'];

                        $sql = "SELECT * FROM users WHERE staffid='$cosuper1'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $dept_co1 = $row["staffacddept"];
                                $full_name_co1 = $row["full_name"];
                                $co_sup1_area_spec = $row["area_special"];
                            }
                        }

                        $sql = "SELECT * FROM users WHERE staffid='$cosuper2'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $dept_co2 = $row["staffacddept"];
                                $full_name_co2 = $row["full_name"];
                                $co_sup2_area_spec = $row["area_special"];
                            }
                        }


                        $sql = "UPDATE progress_report SET co_sup1_pf='$cosuper1', co_sup1_dept='$dept_co1', co_sup1='$full_name_co1', co_sup2_pf='$cosuper2', co_sup2_dept='$dept_co2', co_sup2='$full_name_co2', co_sup1_area_spec='$co_sup1_area_spec', co_sup2_area_spec='$co_sup2_area_spec' WHERE regid='$regid2'";
                        $result = $conn5->query($sql);

                        $sql = "SELECT * FROM supervisors WHERE fileno='$cosuper1'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows == 0) {
                            $sql2 = "INSERT INTO supervisors (fileno, name1, dept, area_special) VALUES ('$cosuper1', '$full_name_co1', '$dept_co1', '$co_sup1_area_spec')";
                            $result2 = $conn5->query($sql2);
                        }

                        $sql = "SELECT * FROM supervisors WHERE fileno='$cosuper2'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows == 0) {
                            $sql2 = "INSERT INTO supervisors (fileno, name1, dept, area_special) VALUES ('$cosuper2', '$full_name_co2', '$dept_co2', '$co_sup2_area_spec')";
                            $result2 = $conn5->query($sql2);
                        }

                        echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                    }

                    if (isset($_POST["updateprop"])) {
                        $regid2 = $_POST['regid2'];
                        $progtitle = $_SESSION["progtitle"];

                        $propdefdone = $_POST["propdefdone"];
                        $propdefcoment = str_replace("'", "''", $_POST['propdefcoment']);
                        $propdefcoment = filter_var($propdefcoment, FILTER_SANITIZE_STRING);
                        $propdefdate = str_replace("'", "''", $_POST['propdefdate']);
                        $propdefdate = filter_var($propdefdate, FILTER_SANITIZE_STRING);

                        if ($propdefdone !== "YES") {
                            $propdefcoment = "";
                            $propdefdate = "";
                        }

                        $sql = "SELECT * FROM request_defence WHERE regid = '$regid2' AND defencetype = 'Proporsal' AND responds='Approve'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows > 0) {
                            $sql = "UPDATE progress_report SET  proposal_defd='$propdefdone', prop_comments='$propdefcoment', date_of_propdefd='$propdefdate' WHERE regid='$regid2'";
                            $result = $conn5->query($sql);
                            echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                        } else {
                            echo "<h3 style='color: #fc0107; text-align: center'>Not Applicable! You need to sought for APPROVAL for the candidate's defence</h3>";
                        }
                    }

                    if (isset($_POST["updateseminar1"])) {
                        $regid2 = $_POST['regid2'];
                        $progtitle = $_SESSION["progtitle"];

                        $seminer1done = $_POST["seminer1done"];
                        $seminer1coment = str_replace("'", "''", $_POST['seminer1coment']);
                        $seminer1coment = filter_var($seminer1coment, FILTER_SANITIZE_STRING);
                        $seminer1date = str_replace("'", "''", $_POST['seminer1date']);
                        $seminer1date = filter_var($seminer1date, FILTER_SANITIZE_STRING);

                        if ($seminer1done !== "YES") {
                            $seminer1coment = "";
                            $seminer1date = "";
                        }

                        $sql = "SELECT * FROM request_defence WHERE regid = '$regid2' AND defencetype = 'Seminar1' AND responds='Approve'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows > 0) {
                            $sql = "UPDATE progress_report SET  seminar1='$seminer1done', seminar1_comments='$seminer1coment', date_of_seminar1='$seminer1date' WHERE regid='$regid2'";
                            $result = $conn5->query($sql);
                            echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                        } else {
                            echo "<center><h3 style='color: #fc0107'>Not Applicable! You need to sought for APPROVAL for the candidate's defence</h3></center>";
                        }
                    }

                    if (isset($_POST["updateseminar2"])) {
                        $regid2 = $_POST['regid2'];
                        $progtitle = $_SESSION["progtitle"];

                        $seminer2done = $_POST["seminer2done"];
                        $seminer2coment = str_replace("'", "''", $_POST['seminer2coment']);
                        $seminer2coment = filter_var($seminer2coment, FILTER_SANITIZE_STRING);
                        $seminer2date = str_replace("'", "''", $_POST['seminer2date']);
                        $seminer2date = filter_var($seminer2date, FILTER_SANITIZE_STRING);

                        if ($seminer2done !== "YES") {
                            $seminer2coment = "";
                            $seminer2date = "";
                        }

                        $sql = "SELECT * FROM request_defence WHERE regid = '$regid2' AND defencetype = 'Seminar2' AND responds='Approve'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows > 0) {
                            $sql = "UPDATE progress_report SET  seminar2='$seminer2done', seminar2_comments='$seminer2coment', date_of_seminar2='$seminer2date' WHERE regid='$regid2'";
                            $result = $conn5->query($sql);
                            echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                        } else {
                            echo "<center><h3 style='color: #fc0107'>Not Applicable! You need to sought for APPROVAL for the candidate's defence</h3></center>";
                        }
                    }

                    if (isset($_POST["updateoral"])) {
                        $regid2 = $_POST['regid2'];
                        $progtitle = $_SESSION["progtitle"];

                        $oraldone = $_POST["oraldone"];
                        $oralcoment = str_replace("'", "''", $_POST['oralcoment']);
                        $oralcoment = filter_var($oralcoment, FILTER_SANITIZE_STRING);
                        $oraldate = str_replace("'", "''", $_POST['oraldate']);
                        $oraldate = filter_var($oraldate, FILTER_SANITIZE_STRING);

                        if ($oraldone !== "YES") {
                            $oralcoment = "";
                            $oraldate = "";
                        }

                        $sql = "SELECT * FROM request_defence WHERE regid = '$regid2' AND defencetype = 'Oral' AND responds='Approve'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows > 0) {
                            $sql = "UPDATE progress_report SET  oral_defd='$oraldone', oral_defd_comments='$oralcoment', date_of_oraldefd='$oraldate' WHERE regid='$regid2'";
                            $result = $conn5->query($sql);
                            echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                        } else {
                            echo "<center><h3 style='color: #fc0107'>Not Applicable! You need to sought for APPROVAL for the candidate's defence</h3></center>";
                        }
                    }

                    if (isset($_POST["updatefinal"])) {
                        $regid2 = $_POST['regid2'];
                        $progtitle = $_SESSION["progtitle"];

                        $finaldone = $_POST["finaldone"];
                        $finalcoment = str_replace("'", "''", $_POST['finalcoment']);
                        $finalcoment = filter_var($finalcoment, FILTER_SANITIZE_STRING);
                        $finaldate = str_replace("'", "''", $_POST['finaldate']);
                        $finaldate = filter_var($finaldate, FILTER_SANITIZE_STRING);

                        if ($finaldone !== "YES") {
                            $finalcoment = "";
                            $finaldate = "";
                        }

                        $sql = "SELECT * FROM request_defence WHERE regid = '$regid2' AND defencetype = 'Final' AND responds='Approve'";
                        $result = $conn5->query($sql);
                        if ($result->num_rows > 0) {
                            $sql = "UPDATE progress_report SET  external_exam='$finaldone', external_exam_comments='$finalcoment', date_of_externalexam='$finaldate' WHERE regid='$regid2'";
                            $result = $conn5->query($sql);
                            echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                        } else {
                            echo "<center><h3 style='color: #fc0107'>Not Applicable! You need to sought for APPROVAL for the candidate's defence</h3></center>";
                        }
                    }

                    if (isset($_POST["updatethesis"])) {
                        $regid2 = $_POST['regid2'];
                        $progtitle = $_SESSION["progtitle"];

                        $finaltitle = str_replace("'", "''", $_POST['finalthesistitle']);
                        $finaltitle = filter_var($finaltitle, FILTER_SANITIZE_STRING);
                        $abstract = str_replace("'", "''", $_POST['abstract']);
                        $abstract = filter_var($abstract, FILTER_SANITIZE_STRING);
                        $date_of_upload = str_replace("'", "''", $_POST['thesisdate']);
                        $date_of_upload = filter_var($date_of_upload, FILTER_SANITIZE_STRING);

                        if ($finaldone !== "YES") {
                            $sql = "UPDATE progress_report SET  finaltitle='$finaltitle', abstract='$abstract', date_of_upload='$date_of_upload' WHERE regid='$regid2'";
                            $result = $conn5->query($sql);
                            echo "<h2 style='color: #0000ff'>Record Saved</h2>";
                        } else {
                            echo "<center><h3 style='color: #fc0107'>Not Applicable! Candidate yet to do defence</h3></center>";
                        }
                    }
                    ?>
                    <form class="form-horizontal" method="post" action="">

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Session Admitted:</label>
                            <div class="col-sm-2">
                                <?php
                                $iniyear = 2018;
                                $finalyear = substr($_SESSION['corntsession'], 5);

                                ?>
                                <select name="sessionadmt" class="form-control" style="color:#000000" required="required">

                                    <option></option>
                                    <?php
                                    while ($iniyear <= $finalyear) {
                                        $addyear = $iniyear + 1;

                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                        $iniyear++;
                                    }

                                    ?>

                                </select>
                            </div>
                            <label class="col-sm-3 control-label">Programme Title:</label>
                            <div class="col-sm-2">
                                <select class="form-control m-bot15" name="progtitle" required="required">
                                    <option value=""></option>
                                    <option value="PGD">PGD</option>
                                    <option value="M.Tech">M.Tech</option>
                                    <option value="M.Eng">M.Eng</option>
                                    <option value="Masters">Professional Masters</option>
                                    <option value="Ph.D">Ph.D</option>

                                </select>
                            </div>
                            <div class="col-sm-2" style="text-align:center">
                                <button type="submit" name="submit" class="btn btn-info">Submit</button>
                            </div>
                        </div>


                    </form>
                </div>
                <hr class="separator" />
                <div class="row">

                    <div class="col-lg-12  col-md-12">

                        <div class="col-lg-12">
                            <section class="panel panel-success">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>

                                    <h2 class="panel-title">PG Project Allocation</h2>
                                </header>
                                <div class="panel-body">
                                    <?php
                                    if (isset($_POST["uploadpropdefd"])) {
                                        $success = false;
                                        if (isset($_POST['uploadpropdefd']) && !empty($_POST['uploadpropdefd'])) {
                                            if (isset($_FILES['uploadproposal']['name']) && @$_FILES['uploadproposal']['name'] != "") {
                                                if ($_FILES['uploadproposal']['error'] > 0) {
                                                    echo '<h4>Increase post_max_size and upload_max_filesize limit in php.ini file.</h4>';
                                                } else {
                                                    $stuid = $_SESSION["stuid"];
                                                    if ($_FILES['uploadproposal']['size'] / 1024 <= 5120) {
                                                        // 5MB
                                                        if (
                                                            $_FILES['uploadproposal']['type'] == 'image/jpeg' ||
                                                            $_FILES['uploadproposal']['type'] == 'image/pjpeg' ||
                                                            $_FILES['uploadproposal']['type'] == 'image/png' ||
                                                            $_FILES['uploadproposal']['type'] == 'image/gif'
                                                        ) {

                                                            $source_file = $_FILES['uploadproposal']['tmp_name'];
                                                            $target_file = "pg_images/" . $stuid . "_proposal.jpg";
                                                            $width      = $_POST['width'];
                                                            $height     = $_POST['height'];
                                                            $quality    = $_POST['quality'];
                                                            //$image_name = $_FILES['uploadImg']['name'];
                                                            $success = compress_image($source_file, $target_file, $width, $height, $quality);
                                                            if ($success) {
                                                                // Optional. The original file is uploaded to the server only for the comparison purpose.
                                                                //copy($source_file, "uploads/original_" . $_FILES['uploadImg']['name']);
                                                                echo '<h4> Proposal Defence Report Upload Successful</h4>';
                                                            }
                                                        } else {
                                                            echo "<h3 style='color: #ff0000'>Error: Image must be in format .jpg, .png or .gif </h3>";
                                                        }
                                                    } else {
                                                        echo "<h3 style='color: #ff0000'>Image should be maximun 5MB in size!</h3>";
                                                    }
                                                }
                                            } else {
                                                echo "<h3 style='color: #ff0000'>Please select an image first!</h3>";
                                            }
                                        }
                                    }
                                    ?>

                                    <?php
                                    if (isset($_POST["uploadoraldefd"])) {
                                        $success = false;
                                        if (isset($_POST['uploadoraldefd']) && !empty($_POST['uploadoraldefd'])) {
                                            if (isset($_FILES['uploadoral']['name']) && @$_FILES['uploadoral']['name'] != "") {
                                                if ($_FILES['uploadoral']['error'] > 0) {
                                                    echo '<h4>Increase post_max_size and upload_max_filesize limit in php.ini file.</h4>';
                                                } else {
                                                    $stuid = $_SESSION["stuid"];
                                                    if ($_FILES['uploadoral']['size'] / 1024 <= 5120) {
                                                        // 5MB
                                                        if (
                                                            $_FILES['uploadoral']['type'] == 'image/jpeg' ||
                                                            $_FILES['uploadoral']['type'] == 'image/pjpeg' ||
                                                            $_FILES['uploadoral']['type'] == 'image/png' ||
                                                            $_FILES['uploadoral']['type'] == 'image/gif'
                                                        ) {

                                                            $source_file = $_FILES['uploadoral']['tmp_name'];
                                                            $target_file = "pg_images/" . $stuid . "_oral.jpg";
                                                            $width      = $_POST['width'];
                                                            $height     = $_POST['height'];
                                                            $quality    = $_POST['quality'];
                                                            //$image_name = $_FILES['uploadImg']['name'];
                                                            $success = compress_image($source_file, $target_file, $width, $height, $quality);
                                                            if ($success) {
                                                                // Optional. The original file is uploaded to the server only for the comparison purpose.
                                                                //copy($source_file, "uploads/original_" . $_FILES['uploadImg']['name']);
                                                                echo "<h4> Oral Defence Report Upload Successful</h4>";
                                                            }
                                                        } else {
                                                            echo "<h3 style='color: #ff0000'>Error: Image must be in format .jpg, .png or .gif </h3>";
                                                        }
                                                    } else {
                                                        echo "<h3 style='color: #ff0000'>Image should be maximun 5MB in size!</h3>";
                                                    }
                                                }
                                            } else {
                                                echo "<h3 style='color: #ff0000'>Please select an image first!</h3>";
                                            }
                                        }
                                    }
                                    ?>

                                    <?php
                                    if (isset($_POST["uploadfinaldefd"])) {
                                        $success = false;
                                        if (isset($_POST['uploadfinaldefd']) && !empty($_POST['uploadfinaldefd'])) {
                                            if (isset($_FILES['uploadfinal']['name']) && @$_FILES['uploadfinal']['name'] != "") {
                                                if ($_FILES['uploadfinal']['error'] > 0) {
                                                    echo '<h4>Increase post_max_size and upload_max_filesize limit in php.ini file.</h4>';
                                                } else {
                                                    $stuid = $_SESSION["stuid"];
                                                    if ($_FILES['uploadfinal']['size'] / 1024 <= 5120) {
                                                        // 5MB
                                                        if (
                                                            $_FILES['uploadfinal']['type'] == 'image/jpeg' ||
                                                            $_FILES['uploadfinal']['type'] == 'image/pjpeg' ||
                                                            $_FILES['uploadfinal']['type'] == 'image/png' ||
                                                            $_FILES['uploadfinal']['type'] == 'image/gif'
                                                        ) {

                                                            $source_file = $_FILES['uploadfinal']['tmp_name'];
                                                            $target_file = "pg_images/" . $stuid . "_final.jpg";
                                                            $width      = $_POST['width'];
                                                            $height     = $_POST['height'];
                                                            $quality    = $_POST['quality'];
                                                            //$image_name = $_FILES['uploadImg']['name'];
                                                            $success = compress_image($source_file, $target_file, $width, $height, $quality);
                                                            if ($success) {
                                                                // Optional. The original file is uploaded to the server only for the comparison purpose.
                                                                //copy($source_file, "uploads/original_" . $_FILES['uploadImg']['name']);
                                                                echo '<h4> Final Defence Report Upload Successful</h4>';
                                                            }
                                                        } else {
                                                            echo "<h3 style='color: #ff0000'>Error: Image must be in format .jpg, .png or .gif </h3>";
                                                        }
                                                    } else {
                                                        echo "<h3 style='color: #ff0000'>Image should be maximun 5MB in size!</h3>";
                                                    }
                                                }
                                            } else {
                                                echo "<h3 style='color: #ff0000'>Please select an image first!</h3>";
                                            }
                                        }
                                    }
                                    ?>


                                    <div class="col-lg-12 col-md-12">
                                        <div class="col-lg-5 col-md-12">
                                            <?php
                                            if (isset($_POST["submit"]) || isset($_POST["view"]) || isset($_POST["update1"]) || isset($_POST["updatemajorsup"]) || isset($_POST["updatecosup"]) || isset($_POST["updateprop"]) || isset($_POST["updateseminar1"]) || isset($_POST["updateseminar2"]) || isset($_POST["updateoral"]) || isset($_POST["updatefinal"])) {
                                                if (isset($_POST["view"]) || isset($_POST["update1"]) || isset($_POST["updatemajorsup"]) || isset($_POST["updatecosup"]) || isset($_POST["updateprop"]) || isset($_POST["updateseminar1"]) || isset($_POST["updateseminar2"]) || isset($_POST["updateoral"]) || isset($_POST["updatefinal"])) {
                                                    $sessionadmt = $_SESSION["sessionadmt"];
                                                    $progtitle = $_SESSION["progtitle"];
                                                } else {
                                                    $sessionadmt = $_POST["sessionadmt"];
                                                    $progtitle = $_POST["progtitle"];
                                                    $_SESSION["sessionadmt"] = $sessionadmt;
                                                    $_SESSION["progtitle"] = $progtitle;
                                                }
                                            ?>
                                                <table class="table mb-none">

                                                    <thead>
                                                        <tr>
                                                            <th>S/No</th>
                                                            <th>Registration No</th>
                                                            <th>Name</th>
                                                            <th>Action</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php



                                                        $sno = 0;
                                                        $sql = "SELECT * FROM pgapplication WHERE deptcode = '$dept' AND session = '$sessionadmt' AND programme_title = '$progtitle' AND regid<> ''";
                                                        $result = $conn4->query($sql);

                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $regid = $row["regid"];
                                                                $id = $row["regid"];
                                                                $name = $row["display_fullname"];
                                                                $sno++;

                                                                echo "<tr><td>$sno</td><td>$regid</td><td>$name</td><td>
																	<form action='' method='post'>
																	<input type='hidden' value='$id' name='id'>
																	<input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
																	</form>
																	</td></tr>\n";
                                                            }
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            <?php } ?>

                                        </div>
                                        <div class="col-lg-7 col-md-12">
                                            <?php
                                            if (isset($_POST["view"])) {
                                                $major_sup = $major_sup_pf = $major_sup_dept = $project_title = $co_sup1 = $co_sup1_pf = $co_sup1_dept = $co_sup2 = $co_sup2_pf = $co_sup2_dept = $proposal_defd = $prop_comments = $date_of_propdefd = $seminar1 = $seminar1_comments = $date_of_seminar1 = $seminar2 = $seminar2_comments = $date_of_seminar2 = $oral_defd = $oral_defd_comments = $date_of_oraldefd = $external_exam = $external_exam_comments = $date_of_externalexam = "";

                                                $add1 = 0;
                                                $regid = $_POST["id"];
                                                $sql = "SELECT * FROM pgapplication WHERE regid = '$regid'";
                                                $result = $conn4->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $stuid = $row["applicant_id"];
                                                        $name = $row["display_fullname"];
                                                        $prgtitle = $row["programme_title"];
                                                        $progstudy = $row["course1"];
                                                    }
                                                }
                                                $_SESSION["stuid"] = $stuid;

                                                $sql = "SELECT * FROM progress_report WHERE regid = '$regid'";
                                                $result = $conn5->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $add1++;

                                                        $project_title = $row["project_title"];
                                                        $major_sup = $row["major_sup"];
                                                        $co_sup1 = $row["co_sup1"];
                                                        $co_sup2 = $row["co_sup2"];
                                                        $major_sup_pf = $row["major_sup_pf"];
                                                        $co_sup1_pf = $row["co_sup1_pf"];
                                                        $co_sup2_pf = $row["co_sup2_pf"];
                                                        $major_sup_dept = $row["major_sup_dept"];
                                                        $co_sup1_dept = $row["co_sup1_dept"];
                                                        $co_sup2_dept = $row["co_sup2_dept"];

                                                        $major_sup_area_spec = $row["major_sup_area_spec"];
                                                        $co_sup1_area_spec = $row["co_sup1_area_spec"];
                                                        $co_sup2_area_spec = $row["co_sup2_area_spec"];

                                                        $proposal_defd = $row["proposal_defd"];
                                                        $prop_comments = $row["prop_comments"];
                                                        $date_of_propdefd = $row["date_of_propdefd"];
                                                        $seminar1 = $row["seminar1"];
                                                        $seminar1_comments = $row["seminar1_comments"];
                                                        $date_of_seminar1 = $row["date_of_seminar1"];
                                                        $seminar2 = $row["seminar2"];
                                                        $seminar2_comments = $row["seminar2_comments"];
                                                        $date_of_seminar2 = $row["date_of_seminar2"];
                                                        $oral_defd = $row["oral_defd"];
                                                        $oral_defd_comments = $row["oral_defd_comments"];
                                                        $date_of_oraldefd = $row["date_of_oraldefd"];
                                                        $external_exam = $row["external_exam"];
                                                        $external_exam_comments = $row["external_exam_comments"];
                                                        $date_of_externalexam = $row["date_of_externalexam"];

                                                        $finaltitle = $row["finaltitle"];
                                                        $abstract = $row["abstract"];
                                                        $date_of_upload = $row["date_of_upload"];

                                                        $val_topic = $row["val_topic"];
                                                        $val_co_sup = $row["val_co_sup"];
                                                        $val_proposal = $row["val_proposal"];
                                                        $val_seminar1 = $row["val_seminar1"];
                                                        $val_seminar2 = $row["val_seminar2"];
                                                        $val_oral = $row["val_oral"];
                                                        $val_external = $row["val_external"];
                                                        $val_thesis = $row["val_thesis"];
                                                    }

                                                    $sql2 = "SELECT * FROM deptcoding WHERE DeptCode='$major_sup_dept'";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $departt_major = $row2["DeptName"];
                                                        }
                                                    }
                                                    $sql2 = "SELECT * FROM deptcoding WHERE DeptCode='$co_sup1_dept'";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $departt_co1 = $row2["DeptName"];
                                                        }
                                                    }
                                                    $sql2 = "SELECT * FROM deptcoding WHERE DeptCode='$co_sup2_dept'";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $departt_co2 = $row2["DeptName"];
                                                        }
                                                    }
                                                }

                                                if ($add1 == 0) {
                                            ?>
                                                    <br>
                                                    <form class="form-horizontal" method="post" action="">
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Registration No.:</label>
                                                            <div class="col-sm-8">
                                                                <label class="control-label" style="color:#000"><?php echo $regid ?></label>
                                                                <input type="hidden" value="<?php echo $regid ?>" name="regid2" />
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Name:</label>
                                                            <div class="col-sm-8">
                                                                <label class="control-label" style="color:#000"><?php echo $name ?></label>
                                                                <input type="hidden" value="<?php echo $name ?>" name="name2" />
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Project/ Thesis/ Dissertation
                                                                Title:</label>
                                                            <div class="col-sm-8">
                                                                <textarea name="projtitle" style="color:#000000" class="form-control" cols="5" rows="2" required="required"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Supervisor:</label>
                                                            <div class="col-sm-8">
                                                                <select class="form-control m-bot15" name="majoesuper" required="required">
                                                                    <option value=""></option>
                                                                    <?php
                                                                    $sql = "SELECT * FROM users WHERE staffacddept='$dept' ORDER BY full_name";
                                                                    $result = $conn->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $staffid = $row["staffid"];
                                                                            $full_name = $row["full_name"];
                                                                            $area_special = $row["area_special"];
                                                                            echo "<option value=$staffid>$dept $staffid $full_name | $area_special</option>";
                                                                        }
                                                                    }

                                                                    $sql2 = "SELECT * FROM deptcoding WHERE DeptCode<>'$dept' ORDER BY DeptCode";
                                                                    $result2 = $conn4->query($sql2);
                                                                    if ($result2->num_rows > 0) {
                                                                        while ($row2 = $result2->fetch_assoc()) {
                                                                            $DeptCode = $row2["DeptCode"];
                                                                            //$full_name=$row["full_name"];
                                                                            $sql = "SELECT * FROM users WHERE staffacddept='$DeptCode' ORDER BY full_name";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    $staffid = $row["staffid"];
                                                                                    $full_name = $row["full_name"];
                                                                                    $area_special = $row["area_special"];
                                                                                    echo "<option value=$staffid>$DeptCode $staffid $full_name | $area_special</option>";
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label"></label>
                                                            <div class="col-sm-8" style="text-align:right">
                                                                <button type="submit" name="update1" class="btn btn-info">Update</button>
                                                            </div>
                                                        </div>
                                                    </form>

                                                <?php } else { ?>

                                                    <br>
                                                    <form class="form-horizontal" method="post" action="">
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Registration No.:</label>
                                                            <div class="col-sm-8">
                                                                <label class="control-label" style="color:#000"><?php echo $regid ?></label>
                                                                <input type="hidden" value="<?php echo $regid ?>" name="regid2" />
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Name:</label>
                                                            <div class="col-sm-8">
                                                                <label class="control-label" style="color:#000"><?php echo $name ?></label>
                                                            </div>
                                                        </div>
                                                        <?php if ($val_topic == "YES") { ?>
                                                            <div class="form-group">
                                                                <label class="col-sm-3 control-label">Project/Thesis/ Dissertation
                                                                    Title:</label>
                                                                <div class="col-sm-8">
                                                                    <label class="control-label" style="color:#000; text-align: justify;"><?php echo $project_title ?></label>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-sm-3 control-label">Supervisor:</label>
                                                                <div class="col-sm-8">
                                                                    <div class="form-group">

                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">PF Number:</label>
                                                                        <div class="col-sm-8">
                                                                            <label class="control-label" style="color:#000"><?php echo $major_sup_pf ?></label>

                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Name :</label>
                                                                        <div class="col-sm-8">
                                                                            <label class="control-label" style="color:#000"><?php echo $major_sup ?></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Department:</label>
                                                                        <div class='col-sm-8'>
                                                                            <label class="control-label" style="color:#000"><?php echo $departt_major ?></label>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>

                                                        <?php } else { ?>
                                                            <div class="form-group">
                                                                <label class="col-sm-3 control-label">Project/Thesis/ Dissertation
                                                                    Title:</label>
                                                                <div class="col-sm-8">
                                                                    <textarea name="projtitle" style="color:#000000" class="form-control" cols="5" rows="2" required="required"><?php echo $project_title ?></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-sm-3 control-label">Supervisor:</label>
                                                                <div class="col-sm-8">
                                                                    <select class="form-control m-bot15" name="majoesuper" required="required">
                                                                        <option value="<?php echo $major_sup_pf ?>">
                                                                            <?php echo $major_sup_dept . " " . $major_sup_pf . " " . $major_sup . " | " . $major_sup_area_spec ?>
                                                                        </option>
                                                                        <?php
                                                                        $sql = "SELECT * FROM users WHERE staffacddept='$dept' ORDER BY full_name";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                $staffid = $row["staffid"];
                                                                                $full_name = $row["full_name"];
                                                                                $area_special = $row["area_special"];
                                                                                echo "<option value=$staffid>$dept $staffid $full_name |   $area_special</option>";
                                                                            }
                                                                        }

                                                                        $sql2 = "SELECT * FROM deptcoding WHERE DeptCode<>'$dept' ORDER BY DeptCode";
                                                                        $result2 = $conn4->query($sql2);
                                                                        if ($result2->num_rows > 0) {
                                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                                $DeptCode = $row2["DeptCode"];
                                                                                //$full_name=$row["full_name"];
                                                                                $sql = "SELECT * FROM users WHERE staffacddept='$DeptCode' ORDER BY full_name";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        $staffid = $row["staffid"];
                                                                                        $full_name = $row["full_name"];
                                                                                        $area_special = $row["area_special"];
                                                                                        echo "<option value=$staffid>$DeptCode $staffid $full_name |   $area_special</option>";
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-sm-3 control-label"></label>
                                                                <div class="col-sm-8" style="text-align:right">
                                                                    <button type="submit" name="updatemajorsup" class="btn btn-info btn-xs">Update</button>
                                                                </div>
                                                            </div>
                                                        <?php } ?>

                                                        <?php if ($progtitle == "Ph.D") { ?>
                                                            <?php if ($val_co_sup == "YES") { ?>
                                                                <div class="form-group">
                                                                    <label class="col-sm-3 control-label">Co-Supervisor 1:</label>

                                                                    <div class="col-sm-8">
                                                                        <div class="form-group">

                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">PF Number:</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000"><?php echo $co_sup1_pf ?></label>

                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Name :</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000"><?php echo $co_sup1 ?></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Department:</label>
                                                                            <div class='col-sm-8'>
                                                                                <label class="control-label" style="color:#000"><?php echo $departt_co1 ?></label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label class="col-sm-3 control-label">Co-Supervisor 2:</label>

                                                                    <div class="col-sm-8">
                                                                        <div class="form-group">

                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">PF Number:</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000"><?php echo $co_sup2_pf ?></label>

                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Name :</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000"><?php echo $co_sup2 ?></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Department:</label>
                                                                            <div class='col-sm-8'>
                                                                                <label class="control-label" style="color:#000"><?php echo $departt_co2 ?></label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            <?php } elseif ($val_topic == "YES") { ?>
                                                                <div class="form-group">
                                                                    <label class="col-sm-3 control-label">Co-Supervisor 1:</label>
                                                                    <div class="col-sm-8">
                                                                        <select class="form-control m-bot15" name="cosuper1" required="required">
                                                                            <option value="<?php echo $co_sup1_pf ?>">
                                                                                <?php echo $co_sup1_dept . " " . $co_sup1_pf . " " . $co_sup1 . " | " . $co_sup1_area_spec ?>
                                                                            </option>
                                                                            <?php
                                                                            $sql = "SELECT * FROM users WHERE staffacddept='$dept' ORDER BY full_name";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    $staffid = $row["staffid"];
                                                                                    $full_name = $row["full_name"];
                                                                                    $area_special = $row["area_special"];
                                                                                    echo "<option value=$staffid>$dept $staffid $full_name | $area_special</option>";
                                                                                }
                                                                            }

                                                                            $sql2 = "SELECT * FROM deptcoding WHERE DeptCode<>'$dept' ORDER BY DeptCode";
                                                                            $result2 = $conn4->query($sql2);
                                                                            if ($result2->num_rows > 0) {
                                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                                    $DeptCode = $row2["DeptCode"];
                                                                                    //$full_name=$row["full_name"];
                                                                                    $sql = "SELECT * FROM users WHERE staffacddept='$DeptCode' ORDER BY full_name";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            $staffid = $row["staffid"];
                                                                                            $full_name = $row["full_name"];
                                                                                            $area_special = $row["area_special"];
                                                                                            echo "<option value=$staffid>$DeptCode $staffid $full_name | $area_special</option>";
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label class="col-sm-3 control-label">Co-Supervisor 2:</label>
                                                                    <div class="col-sm-8">
                                                                        <select class="form-control m-bot15" name="cosuper2" required="required">
                                                                            <option value="<?php echo $co_sup2_pf ?>">
                                                                                <?php echo $co_sup2_dept . " " . $co_sup2_pf . " " . $co_sup2 . " | " . $co_sup2_area_spec ?>
                                                                            </option>
                                                                            <?php
                                                                            $sql = "SELECT * FROM users WHERE staffacddept='$dept' ORDER BY full_name";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    $staffid = $row["staffid"];
                                                                                    $full_name = $row["full_name"];
                                                                                    $area_special = $row["area_special"];
                                                                                    echo "<option value=$staffid>$dept $staffid $full_name | $area_special</option>";
                                                                                }
                                                                            }

                                                                            $sql2 = "SELECT * FROM deptcoding WHERE DeptCode<>'$dept' ORDER BY DeptCode";
                                                                            $result2 = $conn4->query($sql2);
                                                                            if ($result2->num_rows > 0) {
                                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                                    $DeptCode = $row2["DeptCode"];
                                                                                    //$full_name=$row["full_name"];
                                                                                    $sql = "SELECT * FROM users WHERE staffacddept='$DeptCode' ORDER BY full_name";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            $staffid = $row["staffid"];
                                                                                            $full_name = $row["full_name"];
                                                                                            $area_special = $row["area_special"];
                                                                                            echo "<option value=$staffid>$DeptCode $staffid $full_name | $area_special</option>";
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label class="col-sm-3 control-label"></label>
                                                                    <div class="col-sm-8" style="text-align:right">
                                                                        <button type="submit" name="updatecosup" class="btn btn-info btn-xs">Update</button>
                                                                    </div>
                                                                </div>
                                                            <?php } ?>
                                                            <hr>
                                                            <div class="form-group">
                                                                <label class="col-sm-3 control-label">Proposal Defence:</label>
                                                                <div class="col-sm-8">
                                                                    <div class="form-group">

                                                                    </div>
                                                                    <?php if ($val_proposal == "YES") { ?>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Defence done :</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000"><?php echo $proposal_defd ?></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Comments :</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000; text-align: justify;"><?php echo $prop_comments ?></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Date of
                                                                                Defence:</label>
                                                                            <div class='col-sm-8'>
                                                                                <label class="control-label" style="color:#000"><?php echo $date_of_propdefd ?></label>
                                                                            </div>
                                                                        </div>
                                                                    <?php } elseif ($val_co_sup == "YES") { ?>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Defence done :</label>
                                                                            <div class="col-sm-8">
                                                                                <select class="form-control m-bot15" name="propdefdone">
                                                                                    <option> <?php echo $proposal_defd ?></option>
                                                                                    <option>YES</option>
                                                                                    <option>NO</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Comments :</label>
                                                                            <div class="col-sm-8">
                                                                                <textarea name="propdefcoment" style="color:#000000" class="form-control" cols="5" rows="2"><?php echo $prop_comments ?></textarea>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Date of
                                                                                Defence:</label>
                                                                            <div class='col-sm-8'>
                                                                                <input type="date" class="form-control round-input" value="<?php echo $date_of_propdefd ?>" name="propdefdate" />
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label"></label>
                                                                            <div class="col-sm-8" style="text-align:right">
                                                                                <button type="submit" name="updateprop" class="btn btn-info btn-xs">Update</button>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-sm-3 control-label">First Seminer:</label>
                                                                <div class="col-sm-8">
                                                                    <div class="form-group">

                                                                    </div>
                                                                    <?php if ($val_seminar1 == "YES") { ?>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Seminar done :</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000"><?php echo $seminar1 ?></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Comments :</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000; text-align: justify;"><?php echo $seminar1_comments ?></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Date of
                                                                                Seminar:</label>
                                                                            <div class='col-sm-8'>
                                                                                <label class="control-label" style="color:#000"><?php echo $date_of_seminar1 ?></label>
                                                                            </div>
                                                                        </div>
                                                                    <?php } elseif ($val_proposal == "YES") { ?>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Seminar done :</label>
                                                                            <div class="col-sm-8">
                                                                                <select class="form-control m-bot15" name="seminer1done">
                                                                                    <option> <?php echo $seminar1 ?></option>
                                                                                    <option>YES</option>
                                                                                    <option>NO</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Comments :</label>
                                                                            <div class="col-sm-8">
                                                                                <textarea name="seminer1coment" style="color:#000000" class="form-control" cols="5" rows="2"><?php echo $seminar1_comments ?></textarea>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Date of
                                                                                Seminar:</label>
                                                                            <div class='col-sm-8'>
                                                                                <input type="date" class="form-control round-input" value="<?php echo $date_of_seminar1 ?>" name="seminer1date" />
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label"></label>
                                                                            <div class="col-sm-8" style="text-align:right">
                                                                                <button type="submit" name="updateseminar1" class="btn btn-info btn-xs">Update</button>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                            <hr>
                                                            <div class="form-group">
                                                                <label class="col-sm-3 control-label">Second Seminer:</label>
                                                                <div class="col-sm-8">
                                                                    <div class="form-group">

                                                                    </div>
                                                                    <?php if ($val_seminar2 == "YES") { ?>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Seminar done :</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000"><?php echo $seminar2 ?></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Comments :</label>
                                                                            <div class="col-sm-8">
                                                                                <label class="control-label" style="color:#000; text-align: justify;"><?php echo $seminar2_comments ?></label>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Date of
                                                                                Seminar:</label>
                                                                            <div class='col-sm-8'>
                                                                                <label class="control-label" style="color:#000"><?php echo $date_of_seminar2 ?></label>
                                                                            </div>
                                                                        </div>
                                                                    <?php } elseif ($val_seminar1 == "YES") {  ?>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Seminar done :</label>
                                                                            <div class="col-sm-8">
                                                                                <select class="form-control m-bot15" name="seminer2done">
                                                                                    <option> <?php echo $seminar2 ?></option>
                                                                                    <option>YES</option>
                                                                                    <option>NO</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Comments :</label>
                                                                            <div class="col-sm-8">
                                                                                <textarea name="seminer2coment" style="color:#000000" class="form-control" cols="5" rows="2"><?php echo $seminar2_comments ?></textarea>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label">Date of
                                                                                Seminar:</label>
                                                                            <div class='col-sm-8'>
                                                                                <input type="date" class="form-control round-input" value="<?php echo $date_of_seminar2 ?>" name="seminer2date" />
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label class="col-sm-3 control-label"></label>
                                                                            <div class="col-sm-8" style="text-align:right">
                                                                                <button type="submit" name="updateseminar2" class="btn btn-info btn-xs">Update</button>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>

                                                        <?php } ?>
                                                        <hr>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Oral Defence:</label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">

                                                                </div>
                                                                <?php if ($val_oral == "YES") { ?>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Oral Defence done
                                                                            :</label>
                                                                        <div class="col-sm-8">
                                                                            <label class="control-label" style="color:#000"><?php echo $oral_defd ?></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Comments :</label>
                                                                        <div class="col-sm-8">
                                                                            <label class="control-label" style="color:#000; text-align: justify;"><?php echo $oral_defd_comments ?></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Date of Oral
                                                                            Defence:</label>
                                                                        <div class='col-sm-8'>
                                                                            <label class="control-label" style="color:#000"><?php echo $date_of_oraldefd ?></label>
                                                                        </div>
                                                                    </div>
                                                                <?php } elseif ($val_seminar2 == "YES") { ?>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Oral Defence done
                                                                            :</label>
                                                                        <div class="col-sm-8">
                                                                            <select class="form-control m-bot15" name="oraldone">
                                                                                <option> <?php echo $oral_defd ?></option>
                                                                                <option>YES</option>
                                                                                <option>NO</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Comments :</label>
                                                                        <div class="col-sm-8">
                                                                            <textarea name="oralcoment" style="color:#000000" class="form-control" cols="5" rows="2"><?php echo $oral_defd_comments ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Date of Oral
                                                                            Defence:</label>
                                                                        <div class='col-sm-8'>
                                                                            <input type="date" class="form-control round-input" value="<?php echo $date_of_oraldefd ?>" name="oraldate" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label"></label>
                                                                        <div class="col-sm-8" style="text-align:right">
                                                                            <button type="submit" name="updateoral" class="btn btn-info btn-xs">Update</button>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                        <hr>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Final Defence:</label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">

                                                                </div>
                                                                <?php if ($val_external == "YES") { ?>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Final Defence done
                                                                            :</label>
                                                                        <div class="col-sm-8">
                                                                            <label class="control-label" style="color:#000"><?php echo $external_exam ?></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Comments :</label>
                                                                        <div class="col-sm-8">
                                                                            <label class="control-label" style="color:#000; text-align: justify;"><?php echo $external_exam_comments ?></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Date of Final
                                                                            Defence:</label>
                                                                        <div class='col-sm-8'>
                                                                            <label class="control-label" style="color:#000"><?php echo $date_of_externalexam ?></label>
                                                                        </div>
                                                                    </div>
                                                                <?php } elseif ($val_oral == "YES") { ?>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Final Defence done
                                                                            :</label>
                                                                        <div class="col-sm-8">
                                                                            <select class="form-control m-bot15" name="finaldone">
                                                                                <option> <?php echo $external_exam ?></option>
                                                                                <option>YES</option>
                                                                                <option>NO</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Comments :</label>
                                                                        <div class="col-sm-8">
                                                                            <textarea name="finalcoment" style="color:#000000" class="form-control" cols="5" rows="2"><?php echo $external_exam_comments ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Date of Final
                                                                            Defence:</label>
                                                                        <div class='col-sm-8'>
                                                                            <input type="date" class="form-control round-input" value="<?php echo $date_of_externalexam ?>" name="finaldate" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label"></label>
                                                                        <div class="col-sm-8" style="text-align:right">
                                                                            <button type="submit" name="updatefinal" class="btn btn-info btn-xs">Update</button>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>

                                                        <br>
                                                        <hr>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Thesis:</label>
                                                            <div class="col-sm-8">
                                                                <div class="form-group">

                                                                </div>
                                                                <?php if ($val_thesis == "YES") { ?>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Final Thesis Title
                                                                            :</label>
                                                                        <div class="col-sm-8">
                                                                            <label class="control-label" style="color:#000"><?php echo $finaltitle ?></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Abstract :</label>
                                                                        <div class="col-sm-8">
                                                                            <label class="control-label" style="color:#000; text-align: justify;"><?php echo $abstract ?></label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Upload Date:</label>
                                                                        <div class='col-sm-8'>
                                                                            <label class="control-label" style="color:#000"><?php echo $date_of_upload ?></label>
                                                                        </div>
                                                                    </div>
                                                                <?php } elseif ($val_external == "YES") { ?>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Final Thesis Title
                                                                            :</label>
                                                                        <div class="col-sm-8">
                                                                            <textarea name="finalthesistitle" style="color:#000000" class="form-control" cols="5" rows="2"><?php echo $finaltitle ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Abstract :</label>
                                                                        <div class="col-sm-8">
                                                                            <textarea name="abstract" style="color:#000000" class="form-control" cols="5" rows="2"><?php echo $abstract ?></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label">Upload Date:</label>
                                                                        <div class='col-sm-8'>
                                                                            <input type="date" class="form-control round-input" value="<?php echo $date_of_upload ?>" name="thesisdate" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label class="col-sm-3 control-label"></label>
                                                                        <div class="col-sm-8" style="text-align:right">
                                                                            <button type="submit" name="updatethesis" class="btn btn-info btn-xs">Update</button>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>

                                                        <br>

                                                    </form>
                                                <?php } ?>
                                                <?php
                                                if ($proposal_defd == "YES") {
                                                ?>
                                                    <div class="form-group">
                                                        <?php $proplink = "pg_images/" . $stuid . "_proposal.jpg"; ?>
                                                        <div class="col-sm-12">
                                                            <?php if ($val_proposal !== "YES") { ?>
                                                                <form action="" method="post" enctype="multipart/form-data" class="form-horizontal bucket-form">
                                                                    <label hidden="hidden">New width</label><input hidden="hidden" type="text" name="width" value="">
                                                                    <label hidden="hidden">New height</label><input hidden="hidden" type="text" name="height" value="">
                                                                    <label hidden="hidden">Image quality</label><input hidden="hidden" type="text" name="quality" value="">

                                                                    <table border="0" align="center">
                                                                        <tr>
                                                                            <td style="padding-right: 2em">
                                                                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                                                                    <div class="input-append">
                                                                                        <div class="uneditable-input">
                                                                                            <i class="fa fa-file fileupload-exists"></i>
                                                                                            <span class="fileupload-preview"></span>
                                                                                        </div>
                                                                                        <span class="btn btn-default btn-file">
                                                                                            <span class="fileupload-exists">Change</span>
                                                                                            <span class="fileupload-new">Select
                                                                                                file</span>
                                                                                            <input type="file" name="uploadproposal" />
                                                                                        </span>
                                                                                        <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                                                    </div>
                                                                                </div>
                                                                            </td>

                                                                            <td>
                                                                                <input type="submit" name="uploadpropdefd" value="Upload Proposal Def Report" class="btn btn-info btn-xs" />
                                                                            </td>
                                                                        </tr>
                                                                    </table>

                                                                </form>
                                                            <?php } else { ?>
                                                                <label class="control-label" style="color:#000">Proposal Defence
                                                                    Report</label>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-sm-12">
                                                            <center><img src="<?php echo $proplink ?>" alt="" width="200" height="250" /></center>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php
                                                if ($oral_defd == "YES") {
                                                ?>
                                                    <div class="form-group">
                                                        <?php $orallink = "pg_images/" . $stuid . "_oral.jpg"; ?>
                                                        <div class="col-sm-12">
                                                            <?php if ($val_oral !== "YES") { ?>
                                                                <form action="" method="post" enctype="multipart/form-data" class="form-horizontal bucket-form">
                                                                    <label hidden="hidden">New width</label><input hidden="hidden" type="text" name="width" value="">
                                                                    <label hidden="hidden">New height</label><input hidden="hidden" type="text" name="height" value="">
                                                                    <label hidden="hidden">Image quality</label><input hidden="hidden" type="text" name="quality" value="">

                                                                    <table border="0" align="center">
                                                                        <tr>
                                                                            <td style="padding-right: 2em">
                                                                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                                                                    <div class="input-append">
                                                                                        <div class="uneditable-input">
                                                                                            <i class="fa fa-file fileupload-exists"></i>
                                                                                            <span class="fileupload-preview"></span>
                                                                                        </div>
                                                                                        <span class="btn btn-default btn-file">
                                                                                            <span class="fileupload-exists">Change</span>
                                                                                            <span class="fileupload-new">Select
                                                                                                file</span>
                                                                                            <input type="file" name="uploadoral" />
                                                                                        </span>
                                                                                        <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                                                    </div>
                                                                                </div>
                                                                            </td>

                                                                            <td>
                                                                                <input type="submit" name="uploadoraldefd" value="Upload Oral Def Report" class="btn btn-info btn-xs" />
                                                                            </td>
                                                                        </tr>
                                                                    </table>

                                                                </form>
                                                            <?php } else { ?>
                                                                <label class="control-label" style="color:#000">Oral Defence
                                                                    Report</label>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-sm-12">

                                                            <center><img src="<?php echo $orallink ?>" alt="" width="200" height="250" /></center>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php
                                                if ($external_exam == "YES") {
                                                ?>
                                                    <div class="form-group">
                                                        <?php $finallink = "pg_images/" . $stuid . "_final.jpg"; ?>
                                                        <div class="col-sm-12">
                                                            <?php if ($val_external !== "YES") { ?>
                                                                <form action="" method="post" enctype="multipart/form-data" class="form-horizontal bucket-form">
                                                                    <label hidden="hidden">New width</label><input hidden="hidden" type="text" name="width" value="">
                                                                    <label hidden="hidden">New height</label><input hidden="hidden" type="text" name="height" value="">
                                                                    <label hidden="hidden">Image quality</label><input hidden="hidden" type="text" name="quality" value="">

                                                                    <table border="0" align="center">
                                                                        <tr>
                                                                            <td style="padding-right: 2em">
                                                                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                                                                    <div class="input-append">
                                                                                        <div class="uneditable-input">
                                                                                            <i class="fa fa-file fileupload-exists"></i>
                                                                                            <span class="fileupload-preview"></span>
                                                                                        </div>
                                                                                        <span class="btn btn-default btn-file">
                                                                                            <span class="fileupload-exists">Change</span>
                                                                                            <span class="fileupload-new">Select
                                                                                                file</span>
                                                                                            <input type="file" name="uploadfinal" />
                                                                                        </span>
                                                                                        <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                                                    </div>
                                                                                </div>
                                                                            </td>

                                                                            <td>
                                                                                <input type="submit" name="uploadfinaldefd" value="Upload Final Def Report" class="btn btn-info btn-xs" />
                                                                            </td>
                                                                        </tr>
                                                                    </table>

                                                                </form>
                                                            <?php } else { ?>
                                                                <label class="control-label" style="color:#000">Final Defence
                                                                    Report</label>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="col-sm-12">
                                                            <center><img src="<?php echo $finallink ?>" alt="" width="200" height="250" /></center>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            <?php } ?>
                                        </div>

                                    </div>


                                </div>


                            </section>


                        </div>

                    </div>

                </div>

                <!-- end: page -->
            </section>
        </div>


    </section>

    <?php
    function compress_image($source_file, $target_file, $nwidth, $nheight, $quality)
    {
        //Return an array consisting of image type, height, widh and mime type.
        $image_info = getimagesize($source_file);
        if (!($nwidth > 0))
            $nwidth = $image_info[0];
        if (!($nheight > 0))
            $nheight = $image_info[1];


        if (!empty($image_info)) {
            switch ($image_info['mime']) {
                case 'image/jpeg':
                    if ($quality == '' || $quality < 0 || $quality > 100)
                        $quality = 75; //Default quality
                    // Create a new image from the file or the url.
                    $image = imagecreatefromjpeg($source_file);
                    $thumb = imagecreatetruecolor($nwidth, $nheight);
                    //Resize the $thumb image
                    imagecopyresized($thumb, $image, 0, 0, 0, 0, $nwidth, $nheight, $image_info[0], $image_info[1]);
                    // Output image to the browser or file.
                    return imagejpeg($thumb, $target_file, $quality);

                    break;

                case 'image/png':
                    if ($quality == '' || $quality < 0 || $quality > 9)
                        $quality = 6; //Default quality
                    // Create a new image from the file or the url.
                    $image = imagecreatefrompng($source_file);
                    $thumb = imagecreatetruecolor($nwidth, $nheight);
                    //Resize the $thumb image
                    imagecopyresized($thumb, $image, 0, 0, 0, 0, $nwidth, $nheight, $image_info[0], $image_info[1]);
                    // Output image to the browser or file.
                    return imagepng($thumb, $target_file, $quality);
                    break;

                case 'image/gif':
                    if ($quality == '' || $quality < 0 || $quality > 100)
                        $quality = 75; //Default quality
                    // Create a new image from the file or the url.
                    $image = imagecreatefromgif($source_file);
                    $thumb = imagecreatetruecolor($nwidth, $nheight);
                    //Resize the $thumb image
                    imagecopyresized($thumb, $image, 0, 0, 0, 0, $nwidth, $nheight, $image_info[0], $image_info[1]);
                    // Output image to the browser or file.
                    return imagegif($thumb, $target_file, $quality); //$success = true;
                    break;

                default:
                    echo "<h4>Not supported file type!</h4>";
                    break;
            }
        }
    }
    ?>

    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <script src="assets/vendor/jquery-autosize/jquery.autosize.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>


</body>

</html>
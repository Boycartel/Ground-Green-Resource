<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_alocation'] == false) {
    header('Location: home_staff.php');
}
?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Uploaded Results</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results and Profile Approval
                            </li>

                            <li class="active">
                                <strong>Uploaded Results</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Uploaded Results
                        </div>
                        <div class="panel-body">
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }
                            $cursession = $_SESSION['resultsession'];
                            $resultsemester = $_SESSION['resultsemester'];
                            $dept = $_SESSION['deptcode'];
                            $staffid = $_SESSION['staffid'];
                            //$_SESSION['CCode'] = "XXX";
                            ?>
                            <div style="text-align: center">
                                <h3>Session :- <?php echo $cursession ?></h3>
                            </div>
                            <div class="row" style="padding-left: 3em">
                                <table class="table table-bordered table-striped mb-none">
                                    <thead style='text-align:center'>
                                        <tr>
                                            <th>Course Code </th>
                                            <th>Course Title</th>
                                            <th>Credit Unit</th>
                                            <th>Course Lecturer(s)</th>
                                            <th>Registered Students</th>
                                            <th>Uploaded Results</th>
                                            <th>Approval</th>
                                            <th>Action</th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        <?php
                                        $dbsession = str_replace("/", "_", $cursession);
                                        $sql = "SELECT * FROM gencoursesupload WHERE Department = '$dept' AND  semester = '$resultsemester' ORDER BY C_codding";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $CCode = $row["C_codding"];
                                                $C_title = $row["C_title"];
                                                $credit = $row["credit"];
                                                $approval = "Yet";
                                                $IsRegister = 0;
                                                $submitted = "NO";
                                                $NoSubmit = 0;
                                                $LectureDetails = "";

                                                if ($CCode == "SIW400") {
                                                    $sql2 = "SELECT * FROM courses_register_" . $dbsession . " WHERE CCode = '$CCode' AND departments = '$dept'";
                                                } else {
                                                    $sql2 = "SELECT * FROM courses_register_" . $dbsession . " WHERE CCode = '$CCode'";
                                                }
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $IsRegister++;
                                                    }
                                                }

                                                if ($IsRegister > 0) {
                                                    $sql2 = "SELECT * FROM submitted_results_list WHERE CCode = '$CCode' AND Session1 = '$cursession'";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result2->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $approval = $row2["approval"];
                                                            $submitted = "YES";
                                                            $NoSubmit = $row2["No_students"];
                                                        }
                                                    }

                                                    $sql2 = "SELECT * FROM coursealocation WHERE CCode = '$CCode' AND SessionReg = '$cursession'";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result2->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $PFNo = $row2["PFNo"];
                                                            $sql3 = "SELECT * FROM users WHERE staffid = '$PFNo'";
                                                            $result3 = $conn->query($sql3);
                                                            if ($result3->num_rows > 0) {
                                                                while ($row3 = $result3->fetch_assoc()) {
                                                                    $LectureDetails = $LectureDetails . $row3["full_name"] . "(" . $row3["phone"] . ")<br> ";
                                                                }
                                                            }
                                                        }
                                                    }
                                                    echo "<tr>";
                                                    echo "<td>$CCode </td><td>$C_title</td><td> $credit</td><td>$LectureDetails</td><td>$IsRegister</td><td>$NoSubmit</td>";
                                                    echo "<td>$approval</td>";
                                                    echo "<td>";
                                                    if ($submitted == "YES") {
                                                        echo "<form class='form-horizontal form-bordered' method='post' action='raw_results_approval_view.php' target='_blank'>";
                                                        echo "<input type='hidden' value='$CCode' name='id'>";
                                                        echo "<input type='submit' name='view' class='btn btn-success btn-xs' value='View'>";
                                                        echo "</form>";
                                                    }
                                                    echo "</td>";
                                                    echo "</tr>";
                                                }
                                            }
                                        }


                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php
                            $conn->close();
                            ?>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
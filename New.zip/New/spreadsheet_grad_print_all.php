<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['board_format'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>


    <style type="text/css">
        table {
            page-break-inside: avoid;
        }

        h3 {
            page-break-before: always;
        }

        @page {
            size: A4 landscape;
            font-size: small;
        }

        @page :left {
            margin-left: 1cm;
        }

        @page :right {
            margin-left: 2cm;
        }
    </style>

    <script type="text/javascript">
        function printDiv(div_id) {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var content_vlue = document.getElementById(div_id).innerHTML;

            var docprint = window.open("", "", disp_setting);

            ///// Enable Bootstrap CSS
            //// Can also add customise CSS
            docprint.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="css/bootstrap.min.css">');
            docprint.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section>

        <!-- start: header -->
        <?php
        $userdept = $_SESSION['deptcode'];
        $userid = $_SESSION["staffid"];
        $usernames = $_SESSION['names'];
        $useremail = $_SESSION['email'];
        $deptname = $_SESSION['deptname'];
        //$cat = $_SESSION['cat'];
        $corntsession = $_SESSION['corntsession'];
        $cursemester = $_SESSION['cursemester'];
        ?>

        <div class="row" style="padding: 3em;">

            <section class="panel">
                <header class="panel-heading tab-bg-info">

                </header>
                <div class="panel-body">
                    <div class="tab-content">

                        <div id="printableArea" style="width: auto; float: none">
                            <?php
                            $getyeargrad = $_SESSION['getyeargrad'];
                            $getsemester = $_SESSION['semesterSel'];
                            $schcode = $_SESSION['schcode'];
                            $getdept = $_SESSION['deptcode'];

                            $gradstuReg = $_SESSION["gradstuReg"];
                            $gradStuName = $_SESSION["gradStuName"];
                            $snoArray = $_SESSION["snoArray"];
                            $sno = $_SESSION["sno"];
                            $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;
                            for ($i = 1; $i <= $sno; $i++) {
                                $no = $snoArray[$i];
                                $matno = $gradstuReg[$i];
                                $Name1 = $gradStuName[$i];
                                //$RegNo2 = substr($matno, 7, 7);

                                include 'Print_rec/print_all_grad.php';
                            }

                            ?>
                        </div>
                        <div style="text-align: right">
                            <input type="button" onclick="printDiv('printableArea')" value="print to PDF" class="btn-success" />
                        </div>
                    </div>
                </div>
            </section>



        </div>


    </section>



</body>

</html>
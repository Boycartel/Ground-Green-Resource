<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';


//$paystatus = "NO";
$stdid = $_SESSION['stdid'];


$regid = $_SESSION["regid"];
$dept = $_SESSION['deptcode'];
$corntsession = $_SESSION['corntsession'];

$_SESSION['noresult'] = "NO";
$tot1outunit = $tot2outunit = 0;
//include_once 'includes/get_stu_level.php';
require 'includes/reginclude1.php';
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--Check All checkbox-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function() {
            var $selectAll = $('#selectAll1'); // main checkbox inside table thead
            var $table = $('.tablechk1'); // table selector 
            var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
            var tdCheckboxChecked = 0; // checked checboxes

            // Select or deselect all checkboxes depending on main checkbox change
            $selectAll.on('click', function() {
                $tdCheckbox.prop('checked', this.checked);
            });

            // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
            $tdCheckbox.on('change', function(e) {
                tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                    .length; // Get count of checkboxes that is checked
                // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
                $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
            })
        });
    </script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function() {
            var $selectAll = $('#selectAll2'); // main checkbox inside table thead
            var $table = $('.tablechk2'); // table selector 
            var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
            var tdCheckboxChecked = 0; // checked checboxes

            // Select or deselect all checkboxes depending on main checkbox change
            $selectAll.on('click', function() {
                $tdCheckbox.prop('checked', this.checked);
            });

            // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
            $tdCheckbox.on('change', function(e) {
                tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                    .length; // Get count of checkboxes that is checked
                // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
                $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
            })
        });
    </script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function() {
            var $selectAll = $('#selectAll3'); // main checkbox inside table thead
            var $table = $('.tablechk3'); // table selector 
            var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
            var tdCheckboxChecked = 0; // checked checboxes

            // Select or deselect all checkboxes depending on main checkbox change
            $selectAll.on('click', function() {
                $tdCheckbox.prop('checked', this.checked);
            });

            // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
            $tdCheckbox.on('change', function(e) {
                tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                    .length; // Get count of checkboxes that is checked
                // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
                $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
            })
        });
    </script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function() {
            var $selectAll = $('#selectAll4'); // main checkbox inside table thead
            var $table = $('.tablechk4'); // table selector 
            var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
            var tdCheckboxChecked = 0; // checked checboxes

            // Select or deselect all checkboxes depending on main checkbox change
            $selectAll.on('click', function() {
                $tdCheckbox.prop('checked', this.checked);
            });

            // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
            $tdCheckbox.on('change', function(e) {
                tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                    .length; // Get count of checkboxes that is checked
                // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
                $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
            })
        });
    </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php
        include_once 'includes/header2_pg.php';
        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/pg_aside_menu.php';
            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Course Registration</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="stu_course_reg.php">
                                    <i class="fa fa-list"></i>
                                </a>
                            </li>
                            <li><span>Course Reg.</span></li>
                            <li><span>Course Registration</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">

                    <div class="col-md-1">
                    </div>
                    <div class="col-md-10">
                        <section class="panel panel-success">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">Course Registration for <?php echo $_SESSION['corntsession'] ?>
                                    Session</h2>
                            </header>
                            <div class="panel-body">

                                <form class="form-horizontal" role="form" method="post" action="pg_course_reg_preview.php">
                                    <?php

                                    // sql to delete a record
                                    $sql = "DELETE FROM coursesregis WHERE Regn1 ='$regid'";
                                    $result = $conn->query($sql);

                                    $sql = "SELECT * FROM " . $dept . "_diff_outs_courses WHERE regn1 = '$regid' AND SemTaken = '1ST'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                    ?>
                                        <h4>
                                            <center>Outstanding 1ST Semester Courses</center>
                                        </h4>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <?php
                                                    if ($tot1outunit > 24) {
                                                        echo "<th style='color:#FFFFFF'>Select</th>";
                                                    }
                                                    ?>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                while ($row = $result->fetch_assoc()) {
                                                    $id = $row["sn"];
                                                    $ccode = $row["CCode"];
                                                    $CTitle = $row["CTitle"];
                                                    $CUnit = $row["CUnit"];
                                                    $SemTaken = $row["SemTaken"];
                                                    $Nature = "Core";

                                                    if ($tot1outunit > 24) {
                                                        echo "<tr>
														<td><input type='checkbox' name='chosen1c[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccodec1' name='ccodec1[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccodec1' name='ccodec1[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitlec1' name='CTitlec1[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitlec1' name='CTitlec1[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnitc1' name='CUnitc1[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnitc1' name='CUnitc1[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTakenc1' name='SemTakenc1[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTakenc1' name='SemTakenc1[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														<td hidden='hidden'>
														<label id='Naturec1' name='Naturec1[" . $id . "]'>$Nature</label>
														<input type='hidden' id='Naturec1' name='Naturec1[" . $id . "]' value='" . $Nature . "'/>
														</td>
														
														</tr>\n";
                                                    } else {
                                                        echo "<tr>
														<td hidden='hidden'><input type='checkbox' checked='checked' name='chosen1c[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccodec1' name='ccodec1[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccodec1' name='ccodec1[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitlec1' name='CTitlec1[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitlec1' name='CTitlec1[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnitc1' name='CUnitc1[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnitc1' name='CUnitc1[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTakenc1' name='SemTakenc1[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTakenc1' name='SemTakenc1[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														<td hidden='hidden'>
														<label id='Naturec1' name='Naturec1[" . $id . "]'>$Nature</label>
														<input type='hidden' id='Naturec1' name='Naturec1[" . $id . "]' value='" . $Nature . "'/>
														</td>
														
														</tr>\n";
                                                    }
                                                }
                                                ?>

                                            </tbody>
                                        </table>

                                    <?php

                                    } else {
                                    }
                                    if ($tot1outunit !== 0) {
                                        echo "<center> Total Credit Units : $tot1outunit</center>";
                                    }
                                    ?>

                                    <br /><br />
                                    <?php



                                    $sql = "SELECT * FROM " . $dept . "_diff_outs_courses WHERE regn1 = '$regid' AND SemTaken = '2ND'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                    ?>
                                        <h4>
                                            <center> Outstanding 2ND Semester Courses</center>
                                        </h4>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <?php
                                                    if ($tot2outunit > 24) {
                                                        echo "<th style='color:#FFFFFF'>Select</th>";
                                                    }
                                                    ?>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>

                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                while ($row = $result->fetch_assoc()) {

                                                    $id = $row["sn"];
                                                    $ccode = $row["CCode"];
                                                    $CTitle = $row["CTitle"];
                                                    $CUnit = $row["CUnit"];
                                                    $SemTaken = $row["SemTaken"];
                                                    $Nature = "Core";

                                                    if ($tot2outunit > 24) {
                                                        echo "<tr>
														<td><input type='checkbox' name='chosen2c[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccodec2' name='ccodec2[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccodec2' name='ccodec2[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitlec2' name='CTitlec2[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitlec2' name='CTitlec2[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnitc2' name='CUnitc2[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnitc2' name='CUnitc2[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTakenc2' name='SemTakenc2[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTakenc2' name='SemTakenc2[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														<td hidden='hidden'>
														<label id='Naturec2' name='Naturec2[" . $id . "]'>$Nature</label>
														<input type='hidden' id='Naturec2' name='Naturec2[" . $id . "]' value='" . $Nature . "'/>
														</td>
														
														</tr>\n";
                                                    } else {
                                                        echo "<tr>
														<td hidden='hidden'><input type='checkbox' checked='checked' name='chosen2c[" . $id . "]' value='" . $id . "'/></td>
														<td>
														<label id='ccodec2' name='ccodec2[" . $id . "]'>$ccode</label>
														<input type='hidden' id='ccodec2' name='ccodec2[" . $id . "]' value='" . $ccode . "'/>
														</td>
														<td>
														<label id='CTitlec2' name='CTitlec2[" . $id . "]'>$CTitle</label>
														<input type='hidden' id='CTitlec2' name='CTitlec2[" . $id . "]' value='" . $CTitle . "'/>
														</td>
														<td>
														<label id='CUnitc2' name='CUnitc2[" . $id . "]'>$CUnit</label>
														<input type='hidden' id='CUnitc2' name='CUnitc2[" . $id . "]' value='" . $CUnit . "'/>
														</td>
														<td>
														<label id='SemTakenc2' name='SemTakenc2[" . $id . "]'>$SemTaken</label>
														<input type='hidden' id='SemTakenc2' name='SemTakenc2[" . $id . "]' value='" . $SemTaken . "'/>
														</td>
														<td hidden='hidden'>
														<label id='Naturec2' name='Naturec2[" . $id . "]'>$Nature</label>
														<input type='hidden' id='Naturec2' name='Naturec2[" . $id . "]' value='" . $Nature . "'/>
														</td>
														
														</tr>\n";
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <?php

                                    } else {
                                    }
                                    if ($tot2outunit <> 0) {
                                        echo "<center> Total Credit Units : $tot2outunit</center>";
                                    }

                                    ?>

                                    <h3>
                                        <center>Pick Courses to register</center>
                                    </h3>
                                    <h4>
                                        <center>1ST Semester</center>
                                    </h4>
                                    <?php

                                    $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND SemTaken = '1ST'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                        if ($tot1outunit < 24) {
                                    ?>

                                            <table class="table mb-none tablechk1">
                                                <thead>
                                                    <tr>
                                                        <th><input type="checkbox" id="selectAll1"></th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Nature</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php

                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["id"];
                                                        $ccode = $row["CCode"];
                                                        $CTitle = $row["CTitle"];
                                                        $CUnit = $row["CUnit"];
                                                        $SemTaken = $row["SemTaken"];
                                                        $Nature = $row["Nature"];

                                                        $sql2 = "SELECT * FROM " . $dept . "_diff_outs_courses WHERE regn1 = '$regid' AND CCode = '$ccode'";
                                                        $result2 = $conn->query($sql2);

                                                        if ($result2->num_rows > 0) {
                                                        } else {
                                                            echo "<tr>
															<td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
															
															<td>
															<label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
															<input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
															</td>
															<td>
															<label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
															<input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
															</td>
															<td>
															<label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
															<input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
															</td>
															<td>
															<label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
															<input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>
															</td>
															
															<td>
															<label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
															<input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
															</td>
															
															</tr>\n";
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>

                                        <?php
                                        }
                                    }

                                    $sql = "SELECT * FROM add_courses_cat WHERE Regn1 = '$regid' AND SemTaken = '1ST'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                        if ($tot1outunit < 24) {
                                        ?>

                                            <table class="table mb-none tablechk2">
                                                <thead>
                                                    <tr>
                                                        <th><input type="checkbox" id="selectAll2"></th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Nature</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php

                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["sn"];
                                                        $ccode = $row["CCode"];
                                                        $CTitle = $row["CTitle"];
                                                        $CUnit = $row["CUnit"];
                                                        $SemTaken = $row["SemTaken"];
                                                        $Nature = $row["Nature"];

                                                        echo "<tr>
                                                        <td><input type='checkbox' name='chosenadd[" . $id . "]' value='" . $id . "'/></td>
                                                        
                                                        <td>
                                                        <label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
                                                        <input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
                                                        </td>
                                                        <td>
                                                        <label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
                                                        <input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
                                                        </td>
                                                        <td>
                                                        <label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
                                                        <input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
                                                        </td>
                                                        <td>
                                                        <label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
                                                        <input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>

                                                        </td>
                                                        
                                                        <td>
                                                        <label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
                                                        <input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
                                                        </td>
                                                        
                                                        </tr>\n";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>

                                    <?php
                                        }
                                    } else {
                                    }
                                    //$conn->close();
                                    ?>
                                    <br /><br />
                                    <h4>
                                        <center>2ND Semester</center>
                                    </h4>
                                    <?php


                                    $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND SemTaken = '2ND'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                        if ($tot2outunit < 24) {
                                    ?>

                                            <table class="table mb-none  tablechk3">
                                                <thead>
                                                    <tr>
                                                        <th><input type="checkbox" id="selectAll3"></th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Nature</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php
                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["id"];
                                                        $ccode = $row["CCode"];
                                                        $CTitle = $row["CTitle"];
                                                        $CUnit = $row["CUnit"];
                                                        $SemTaken = $row["SemTaken"];
                                                        $Nature = $row["Nature"];

                                                        $sql2 = "SELECT * FROM " . $dept . "_diff_outs_courses WHERE regn1 = '$regid' AND CCode = '$ccode'";
                                                        $result2 = $conn->query($sql2);

                                                        if ($result2->num_rows > 0) {
                                                        } else {
                                                            echo "<tr>
															<td><input type='checkbox' name='chosen2[" . $id . "]' value='" . $id . "'/></td>
															
															<td>
															<label id='ccode2' name='ccode2[" . $id . "]'>$ccode</label>
															<input type='hidden' id='ccode2' name='ccode2[" . $id . "]' value='" . $ccode . "'/>
															</td>
															<td>
															<label id='CTitle2' name='CTitle2[" . $id . "]'>$CTitle</label>
															<input type='hidden' id='CTitle2' name='CTitle2[" . $id . "]' value='" . $CTitle . "'/>
															</td>
															<td>
															<label id='CUnit2' name='CUnit2[" . $id . "]'>$CUnit</label>
															<input type='hidden' id='CUnit2' name='CUnit2[" . $id . "]' value='" . $CUnit . "'/>
															</td>
															<td>
															<label id='SemTaken2' name='SemTaken2[" . $id . "]'>$SemTaken</label>
															<input type='hidden' id='SemTaken2' name='SemTaken2[" . $id . "]' value='" . $SemTaken . "'/>
															</td>
															
															<td>
															<label id='Nature2' name='Nature2[" . $id . "]'>$Nature</label>
															<input type='hidden' id='Nature2' name='Nature2[" . $id . "]' value='" . $Nature . "'/>
															</td>
															
															</tr>\n";
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>

                                        <?php
                                        }
                                    } else {
                                    }

                                    $sql = "SELECT * FROM add_courses_cat WHERE Regn1 = '$regid' AND SemTaken = '2ND'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                        if ($tot2outunit < 24) {
                                        ?>

                                            <table class="table mb-none  tablechk4">
                                                <thead>
                                                    <tr>
                                                        <th><input type="checkbox" id="selectAll4"></th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Nature</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php
                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["sn"];
                                                        $ccode = $row["CCode"];
                                                        $CTitle = $row["CTitle"];
                                                        $CUnit = $row["CUnit"];
                                                        $SemTaken = $row["SemTaken"];
                                                        $Nature = $row["Nature"];

                                                        echo "<tr>
                                                        <td><input type='checkbox' name='chosenadd2[" . $id . "]' value='" . $id . "'/></td>
                                                        
                                                        <td>
                                                        <label id='ccode2' name='ccode2[" . $id . "]'>$ccode</label>
                                                        <input type='hidden' id='ccode2' name='ccode2[" . $id . "]' value='" . $ccode . "'/>
                                                        </td>
                                                        <td>
                                                        <label id='CTitle2' name='CTitle2[" . $id . "]'>$CTitle</label>
                                                        <input type='hidden' id='CTitle2' name='CTitle2[" . $id . "]' value='" . $CTitle . "'/>
                                                        </td>
                                                        <td>
                                                        <label id='CUnit2' name='CUnit2[" . $id . "]'>$CUnit</label>
                                                        <input type='hidden' id='CUnit2' name='CUnit2[" . $id . "]' value='" . $CUnit . "'/>
                                                        </td>
                                                        <td>
                                                        <label id='SemTaken2' name='SemTaken2[" . $id . "]'>$SemTaken</label>
                                                        <input type='hidden' id='SemTaken2' name='SemTaken2[" . $id . "]' value='" . $SemTaken . "'/>
                                                        </td>
                                                        
                                                        <td>
                                                        <label id='Nature2' name='Nature2[" . $id . "]'>$Nature</label>
                                                        <input type='hidden' id='Nature2' name='Nature2[" . $id . "]' value='" . $Nature . "'/>
                                                        </td>
                                                        
                                                        </tr>\n";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>

                                    <?php
                                        }
                                    }
                                    //$conn->close();
                                    //$mysqli->close();

                                    ?>
                                    <br /><br />
                                    <div class="row" style="text-align:right">
                                        <button type="submit" name="submit" class="btn btn-primary">Preview</button>
                                    </div>
                                    <br /><br />
                                    <a class="" href="addcoursesreg_pg.php"><span>Add Courses from other Dept</span></a>
                                    <br /><br />
                                </form>

                            </div>
                        </section>
                    </div>
                    <div class="col-md-1">
                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
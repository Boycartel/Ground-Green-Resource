<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_List.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Download Admission List</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Download
                            </li>

                            <li class="active">
                                <strong>Download Admission List</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Download Admission List
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form class="form-horizontal" method="post">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="content">Select
                                                Programme:</label>
                                            <div class="col-lg-7">
                                                <select class="form-control" style="color:#000000" name="prog">
                                                    <option value="">Select Item</option>
                                                    <option value="All">All Admitted Students</option>
                                                    <?php if($_SESSION['InstType'] == "Polytrchnic"){ ?>
                                                    <option value="National Diploma (ND)">National Diploma (ND)</option>
                                                    <option value="Higher National Diploma (HND)">Higher National
                                                        Diploma (HND)</option>
                                                    <option value="Evening DCE">Evening DCE</option>
                                                    <?php } ?>
                                                    <option value="Not Addmitted">Not Addmitted</option>
                                                    <option value="Not Addmitted(UTME)">Not Addmitted(UTME)</option>
                                                </select>


                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <?php
                                            $finalyear = substr($_SESSION['corntsession'], 5);
                                            ?>
                                            <label class="control-label col-lg-5" for="regid">Session:</label>
                                            <div class="col-lg-7">
                                                <select name="entrysession" class="form-control" style="color:#000000"
                                                    id="entrysession">
                                                    <option value="">Select Session</option>
                                                    <?php
                                                    $iniyear = 2022;
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;
                                                        $nextsession = $iniyear . "/" . $addyear;
                                                        echo "<option value = '$nextsession'>$nextsession</option>";
                                                        $iniyear++;
                                                    }

                                                    //$conn->close();
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-9">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1">

                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }
                                ?>
                                <?php if (isset($_POST["submit"])) { ?>
                                <?php
                                    $prog = $_POST['prog'];
                                    $entrysession = $_POST['entrysession'];

                                    /* $sql2 = "SELECT * FROM std_data_view WHERE entry_session = '$entrysession' AND entry_session = '$entrysession'";
                                    $result2 = $conn2->query($sql2);

                                    if ($result2->num_rows > 0) {
                                        while ($row = $result2->fetch_assoc()) {
                                            $downdeptname = $row["DeptName"];
                                        }
                                    } */
                                    ?>
                                <div class="col-lg-12  col-md-12">

                                    <div class="table-responsive">
                                        <?php if ($prog == "Not Addmitted") { ?>
                                        <?php
                                                set_time_limit(500);
                                                $GetTitle = "Not Admitted Students " . $entrysession . " Session";
                                                //$GetTitle = "";
                                                $sno = 0;
                                                ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                            rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>

                                                    <th>SNo</th>
                                                    <th>Application No</th>
                                                    <th>Surname</th>
                                                    <th>First Name</th>
                                                    <th>Other Name</th>
                                                    <th>Date of Birth</th>
                                                    <th>email</th>
                                                    <th>Marital Status</th>
                                                    <th>State of Origin</th>
                                                    <th>LGA</th>
                                                    <th>Nationality</th>
                                                    <th>Phone Number</th>
                                                    <th>Gender</th>
                                                    <th>Session</th>
                                                    <th>Address</th>
                                                    <th>Application Date</th>
                                                    <th>Programme</th>
                                                    <th>Programme Category</th>
                                                    <th>Programme Type</th>
                                                    <th>Exam Type I</th>
                                                    <th>Exam Type II</th>
                                                    <th>Subject 1</th>
                                                    <th>Subject 1 Grade</th>
                                                    <th>Subject 2</th>
                                                    <th>Subject 2 Grade</th>
                                                    <th>Subject 3</th>
                                                    <th>Subject 3 Grade</th>
                                                    <th>Subject 4</th>
                                                    <th>Subject 4 Grade</th>
                                                    <th>Subject 5</th>
                                                    <th>Subject 5 Grade</th>
                                                    <th>Subject 6</th>
                                                    <th>Subject 6 Grade</th>
                                                    <th>A Level Class of Graduation</th>
                                                    <th>A Level Graduation Institution</th>
                                                    <th>A Level Year of Graduation</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                        $sql = "SELECT * FROM appl_data WHERE session = '$entrysession'";
                                                        $result = $conn2->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {

                                                                $id = $row["id"];
                                                                $jamb_appl_no = $row["application_no"];
                                                                $surname = $row["surname"];
                                                                $first_name = $row["first_name"];
                                                                $other_name = $row["other_name"];
                                                                $dob = $row["dob"];
                                                                $email = $row["email"];
                                                                $marital_status = $row["marital_status"];
                                                                $state = $row["state"];
                                                                $lga = $row["lga"];
                                                                $nationality = $row["nationality"];
                                                                $phone = $row["phone"];
                                                                $gender = $row["gender"];
                                                                $session = $row["session"];
                                                                $p_address = $row["p_address"];
                                                                $appl_advert_id = $row["appl_advert_id"];
                                                                $application_date = date_create($row["application_date"]);
                                                                $application_date = date_format($application_date, "d M, Y");

                                                                $sql2 = "SELECT * FROM appl_sch_grades WHERE appl_data_id = '$id'";
                                                                $result2 = $conn2->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $sec_sch = $row2["sec_sch"];
                                                                        $exam_type = $row2["exam_type"];
                                                                        $exam_type2 = $row2["exam_type2"];
                                                                        $sub1 = $row2["sub1"];
                                                                        $grade1 = $row2["grade1"];
                                                                        $sub2 = $row2["sub2"];
                                                                        $grade2 = $row2["grade2"];
                                                                        $sub3 = $row2["sub3"];
                                                                        $grade3 = $row2["grade3"];
                                                                        $sub4 = $row2["sub4"];
                                                                        $grade4 = $row2["grade4"];
                                                                        $sub5 = $row2["sub5"];
                                                                        $grade5 = $row2["grade5"];
                                                                        $sub6 = $row2["sub6"];
                                                                        $grade6 = $row2["grade6"];
                                                                        $sub7 = $row2["sub7"];
                                                                        $grade7 = $row2["grade7"];
                                                                        $class_of_graduation = $row2["class_of_graduation"];
                                                                        $graduation_institution = $row2["graduation_institution"];
                                                                        $graduation_year = $row2["graduation_year"];
                                                                    }
                                                                }

                                                                $sql2 = "SELECT * FROM appl_data_view WHERE application_no = '$jamb_appl_no'";
                                                                $result2 = $conn2->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $programme = $row2["programme"];
                                                                        $programme_category = $row2["programme_category"];
                                                                        $cat_class_degree_name = $row2["cat_class_degree_name"];
                                                                    }
                                                                }

                                                                $sql2 = "SELECT * FROM std_data WHERE jamb_appl_no = '$jamb_appl_no'";
                                                                $result2 = $conn2->query($sql2);
                                                                if ($result2->num_rows == 0) {
                                                                    $sno++;
                                                                    echo "<tr><td>$sno</td><td>$jamb_appl_no</td><td>$surname</td><td>$first_name</td><td>$other_name</td><td>$dob</td><td>$email</td><td>$marital_status</td><td>$state</td><td>$lga</td><td>$nationality</td><td>$phone</td><td>$gender</td><td>$session</td><td>$p_address</td><td>$application_date</td>";
                                                                    echo "<td>$programme</td><td>$programme_category</td><td>$cat_class_degree_name</td><td>$exam_type</td><td>$exam_type2</td><td>$sub1</td><td>$grade1</td><td>$sub2</td><td>$grade2</td><td>$sub3</td><td>$grade3</td><td>$sub4</td><td>$grade4</td><td>$sub5</td><td>$grade5</td><td>$sub6</td><td>$grade6</td><td>$class_of_graduation</td><td>$graduation_institution</td><td>$graduation_year</td></tr>\n";
                                                                }
                                                            }
                                                        }
                                                        ?>
                                            </tbody>
                                        </table>

                                        <?php } elseif ($prog == "Not Addmitted(UTME)") { ?>
                                        <?php
                                                set_time_limit(500);
                                                $GetTitle = "Not Admitted UTME Students " . $entrysession . " Session";
                                                //$GetTitle = "";
                                                $sno = 0;
                                                ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                            rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>

                                                    <th>SNo</th>
                                                    <th>JAMB</th>
                                                    <th>Name</th>
                                                    <th>email</th>
                                                    <th>State of Origin</th>
                                                    <th>LGA</th>
                                                    <th>Phone Number</th>
                                                    <th>Gender</th>
                                                    <th>Session</th>
                                                    <th>Address</th>
                                                    <th>Application Date</th>
                                                    <th>English Scores</th>
                                                    <th>Subject 2</th>
                                                    <th>Subject 2 Scores</th>
                                                    <th>Subject 3</th>
                                                    <th>Subject 3 Scores</th>
                                                    <th>Subject 4</th>
                                                    <th>Subject 4 Scores</th>
                                                    <th>Total Scores</th>
                                                    <th>Department</th>

                                                    <th>Exam Type I</th>
                                                    <th>Exam Type II</th>
                                                    <th>Subject 1</th>
                                                    <th>Subject 1 Grade</th>
                                                    <th>Subject 2</th>
                                                    <th>Subject 2 Grade</th>
                                                    <th>Subject 3</th>
                                                    <th>Subject 3 Grade</th>
                                                    <th>Subject 4</th>
                                                    <th>Subject 4 Grade</th>
                                                    <th>Subject 5</th>
                                                    <th>Subject 5 Grade</th>
                                                    <th>Subject 6</th>
                                                    <th>Subject 6 Grade</th>


                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                        $sql = "SELECT * FROM appl_data_utme WHERE session = '$entrysession'";
                                                        $result = $conn2->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {


                                                                $jamb_appl_no = $row["RegNumb"];
                                                                $cand_name = $row["cand_name"];
                                                                $email = $row["email"];
                                                                $state = $row["state"];
                                                                $lga = $row["lga"];
                                                                $phone = $row["phone"];
                                                                $gender = $row["gender"];
                                                                $session = $row["session"];
                                                                $p_address = $row["p_address"];
                                                                $application_date = date_create($row["application_date"]);
                                                                $application_date = date_format($application_date, "d M, Y");
                                                                $Engscore = $row["Engscore"];
                                                                $Subj2 = $row["Subj2"];
                                                                $Subj2Score = $row["Subj2Score"];
                                                                $Subj3 = $row["Subj3"];
                                                                $Subj3Score = $row["Subj3Score"];
                                                                $Subj4 = $row["Subj4"];
                                                                $Subj4Score = $row["Subj4Score"];
                                                                $TotalScore = $row["TotalScore"];
                                                                $DEPT_CODE = $row["DEPT_CODE"];

                                                                $sql2 = "SELECT * FROM appl_sch_grades_utme WHERE appl_data_id = '$jamb_appl_no'";
                                                                $result2 = $conn2->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $exam_type = $row2["exam_type"];
                                                                        $exam_type2 = $row2["exam_type2"];
                                                                        $sub1 = $row2["sub1"];
                                                                        $grade1 = $row2["grade1"];
                                                                        $sub2 = $row2["sub2"];
                                                                        $grade2 = $row2["grade2"];
                                                                        $sub3 = $row2["sub3"];
                                                                        $grade3 = $row2["grade3"];
                                                                        $sub4 = $row2["sub4"];
                                                                        $grade4 = $row2["grade4"];
                                                                        $sub5 = $row2["sub5"];
                                                                        $grade5 = $row2["grade5"];
                                                                        $sub6 = $row2["sub6"];
                                                                        $grade6 = $row2["grade6"];
                                                                    }
                                                                }

                                                                $sql2 = "SELECT * FROM std_data WHERE jamb_appl_no = '$jamb_appl_no'";
                                                                $result2 = $conn2->query($sql2);
                                                                if ($result2->num_rows == 0) {
                                                                    $sno++;
                                                                    echo "<tr><td>$sno</td><td>$jamb_appl_no</td><td>$cand_name</td><td>$email</td><td>$state</td><td>$lga</td><td>$phone</td><td>$gender</td><td>$session</td><td>$p_address</td><td>$application_date</td><td>$Engscore</td><td>$Subj2</td><td>$Subj2Score</td><td>$Subj3</td><td>$Subj3Score</td><td>$Subj4</td><td>$Subj4Score</td><td>$TotalScore</td><td>$DEPT_CODE</td>";
                                                                    echo "<td>$exam_type</td><td>$exam_type2</td><td>$sub1</td><td>$grade1</td><td>$sub2</td><td>$grade2</td><td>$sub3</td><td>$grade3</td><td>$sub4</td><td>$grade4</td><td>$sub5</td><td>$grade5</td><td>$sub6</td><td>$grade6</td></tr>\n";
                                                                }
                                                            }
                                                        }
                                                        ?>
                                            </tbody>
                                        </table>

                                        <?php } else { ?>
                                        <?php
                                                set_time_limit(500);
                                                if ($prog == "All") {
                                                    $GetTitle = "All Admitted Students " . $entrysession . " Session";
                                                } elseif ($prog == "Evening DCE") {
                                                    $GetTitle = "Admitted Evening DCE Students " . $entrysession . " Session";
                                                } else {
                                                    $GetTitle = "Admitted " . $prog . " " . $entrysession . " Session";
                                                }

                                                //$GetTitle = "";
                                                $sno = 0;
                                                ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                            rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>

                                                    <th>SNo</th>
                                                    <th>JAMB/Application No</th>
                                                    <th>Surname</th>
                                                    <th>First Name</th>
                                                    <th>Other Name</th>
                                                    <th>Cat Class</th>
                                                    <th>Duration</th>
                                                    <th>Mode of Entry</th>
                                                    <th>Student Mode</th>
                                                    <th>Entry Session</th>
                                                    <th>Matric No</th>
                                                    <th>Programme</th>
                                                    <th>Department</th>
                                                    <th>School</th>
                                                    <th>Student ID</th>

                                                    <th>State</th>
                                                    <th>LGA</th>
                                                    <th>Date of Birth</th>
                                                    <th>Gender</th>
                                                    <th>email</th>
                                                    <th>Phone</th>
                                                    <th>P Address</th>
                                                    <th>Religion</th>
                                                    <th>Marital Status</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                        if ($prog == "All") {
                                                            $sql = "SELECT * FROM std_data_view WHERE entry_session = '$entrysession' AND student_mode = 'fresh'";
                                                        } elseif ($prog == "Evening DCE") {
                                                            $sql = "SELECT * FROM std_data_view WHERE entry_session = '$entrysession' AND duration_time = '$prog' AND student_mode = 'fresh'";
                                                            //} elseif ($prog == "Not Addmitted") {
                                                            //$sql = "SELECT * FROM std_data_view WHERE entry_session = '$entrysession' AND (status = '1' OR status = '2' OR status = '3' OR status = '4')";
                                                        } elseif ($prog == "National Diploma (ND)" || $prog == "Higher National Diploma (HND)") {
                                                            $sql = "SELECT * FROM std_data_view WHERE entry_session = '$entrysession' AND cat_class_degree = '$prog' AND duration_time <> 'Evening DCE' AND student_mode = 'fresh'";
                                                        }
                                                        if ($prog !== "Not Addmitted") {
                                                            $result = $conn2->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {

                                                                    $sno++;
                                                                    $jamb_appl_no = $row["jamb_appl_no"];
                                                                    $cat_class_degree = $row["cat_class_degree"];
                                                                    $duration_time = $row["duration_time"];
                                                                    $modeofentry = $row["modeofentry"];
                                                                    $student_mode_entry = $row["student_mode_entry"];
                                                                    $entry_session = $row["entry_session"];
                                                                    $matric_no = $row["matric_no"];
                                                                    $programme = $row["programme"];
                                                                    $department = $row["department"];
                                                                    $school = $row["school"];
                                                                    $stdid = $row["stdid"];
                                                                    $surname = $row["surname"];
                                                                    $first_name = $row["first_name"];
                                                                    $other_name = $row["other_name"];

                                                                    $state = $row["state"];
                                                                    $lga = $row["lga"];
                                                                    $dob = $row["dob"];
                                                                    $gender = $row["gender"];
                                                                    $email = $row["email"];
                                                                    $phone_number = $row["phone_number"];
                                                                    $p_address = $row["p_address"];
                                                                    $religion = $row["religion"];
                                                                    $marital_status = $row["marital_status"];

                                                                    echo "<tr><td>$sno</td><td>$jamb_appl_no</td><td>$surname</td><td>$first_name</td><td>$other_name</td><td>$cat_class_degree</td><td>$duration_time</td><td>$modeofentry</td><td>$student_mode_entry</td><td>$entry_session</td><td>$matric_no</td><td>$programme</td><td>$department</td><td>$school</td><td>$stdid</td><td>$state</td><td>$lga</td><td>$dob</td><td>$gender</td><td>$email</td><td>$phone_number</td><td>$p_address</td><td>$religion</td><td>$marital_status</td></tr>\n";
                                                                }
                                                            }
                                                        }
                                                        ?>
                                            </tbody>
                                        </table>

                                        <?php } ?>

                                    </div>
                                    <br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                            class="btn btn-primary">Download</a>
                                    </div>
                                </div>



                                <?php } ?>
                                <?php
                                $conn->close();
                                $conn2->close();
                                ?>
                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
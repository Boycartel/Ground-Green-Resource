<?php

require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['Administrator'] !== "YES" && $_SESSION['Sub_Admin'] !== "YES") {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Create New Curriculum</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Settings
                            </li>

                            <li class="active">
                                <strong>Create New Curriculum</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Create New Students Group
                        </div>
                        <div class="panel-body">
                            <?php
                            $success = "";
                            $GetTheSession = $_SESSION['resultsession'];

                            if (isset($_POST["addnew"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                               
                                $grpcode = strtoupper($_POST["groupcode"]);
                                if ($grpcode == "G01") {
                                    $gTitle = "Group 1";
                                } elseif ($grpcode == "G02") {
                                    $gTitle = "Group 2";
                                } elseif ($grpcode == "G03") {
                                    $gTitle = "Group 3";
                                } elseif ($grpcode == "G04") {
                                    $gTitle = "Group 4";
                                } elseif ($grpcode == "G05") {
                                    $gTitle = "Group 5";
                                } elseif ($grpcode == "G06") {
                                    $gTitle = "Group 6";
                                } elseif ($grpcode == "G07") {
                                    $gTitle = "Group 7";
                                } elseif ($grpcode == "G08") {
                                    $gTitle = "Group 8";
                                } elseif ($grpcode == "G09") {
                                    $gTitle = "Group 9";
                                } elseif ($grpcode == "G10") {
                                    $gTitle = "Group 10";
                                }

                                $dept = strtoupper($_SESSION["deptAddGroup"]);
                                if ($_SESSION["getOptn"] == "YES") {
                                    $deptoption = $_POST["deptopt"];
                                } else {
                                    $deptoption = "NOP";
                                }
                                $_SESSION["optArray"] = $deptoption;
                                if ($_SESSION['InstType'] == "Polytechnic") {
                                    $prog = $_POST["groupprog"];


                                    $_SESSION["groupprog"] = $prog;
                                    $sql = "SELECT * FROM dept_stu_group WHERE deptcode = '$dept' AND prog = '$prog' AND deptoption = '$deptoption'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows == 0) {
                                        $sql2 = "INSERT INTO dept_stu_group(group_Code, group_Title, deptcode, prog, deptoption) VALUES ('NG','No Group','$dept', '$prog', '$deptoption')";
                                        $result2 = $conn->query($sql2);
                                    }

                                    $sql = "SELECT * FROM dept_stu_group WHERE group_Code = '$grpcode' AND deptcode = '$dept' AND prog = '$prog' AND deptoption = '$deptoption'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows == 0) {
                                        $sql2 = "INSERT INTO dept_stu_group(group_Code, group_Title, deptcode, prog, deptoption) VALUES ('$grpcode','$gTitle','$dept', '$prog', '$deptoption')";
                                        $result2 = $conn->query($sql2);
                                    }
                                } else {
                                    $prog = "XX";
                                    $sql = "SELECT * FROM dept_stu_group WHERE deptcode = '$dept' AND deptoption = '$deptoption'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows == 0) {
                                        $sql2 = "INSERT INTO dept_stu_group(group_Code, group_Title, deptcode, deptoption) VALUES ('NG','No Group','$dept', '$deptoption')";
                                        $result2 = $conn->query($sql2);
                                    }

                                    $sql = "SELECT * FROM dept_stu_group WHERE group_Code = '$grpcode' AND deptcode = '$dept' AND deptoption = '$deptoption'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows == 0) {
                                        $sql2 = "INSERT INTO dept_stu_group(group_Code, group_Title, deptcode, deptoption) VALUES ('$grpcode','$gTitle','$dept', '$deptoption')";
                                        $result2 = $conn->query($sql2);
                                    }
                                }
                                $conn->close();
                            }

                            if (isset($_POST['deletesingle'])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                               
                                $id = $_POST['delete_id'];
                                $sql2 = "DELETE FROM dept_stu_group WHERE id='$id'";
                                $result2 = $conn->query($sql2);

                                $conn->close();
                            }


                            ?>
                            <div class="row">

                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="row">

                                        <div class="col-lg-4">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="content">Select
                                                    Department:</label>
                                                <div class="col-lg-7">
                                                    <select class="country form-control" style="color:#000000"
                                                        name="dept">
                                                        <option value="SelectItem">Select Item</option>
                                                        <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $deptcode2 = strtolower($row["DeptCode"]);
                                                                $deptname2 = $row["DeptName"];
                                                                echo "<option value=$deptcode2>$deptname2</option>";
                                                            }
                                                        }
                                                        $conn->close();
                                                        ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="row">

                                                <div class="col-lg-4">
                                                    <button type="submit" name="submit"
                                                        class="btn btn-primary btn-sm">Submit</button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </form>

                                <?php if (isset($_POST["submit"]) || isset($_POST["addnew"]) || isset($_POST["deletesingle"])) { ?>
                                <?php
                                    if (isset($_POST["submit"])) {
                                        $dept = $_POST["dept"];
                                        $_SESSION["deptAddGroup"] = $dept;
                                    } else {
                                        $dept = $_SESSION["deptAddGroup"];
                                    }

                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }


                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $deptname = $row["DeptName"];
                                            $_SESSION["getOptn"] = $row["deptoption"];
                                        }
                                    }
                                    ?>

                                <br>
                                <br>
                                <div class="row">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <h2 style="color: blue"><?php echo $success ?></h2>
                                        <h2 style="text-align: center"><?php echo $deptname ?> Department</h2>

                                        <div style="text-align: right; padding-right:2em">
                                            <a href="#addEmployeeModal" class="btn btn-success btn-xs"
                                                data-toggle="modal"><span>Add
                                                    New</span></a>
                                            <!--<a href="#deleteEmployeeModal" class="btn btn-danger btn-xs" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>-->
                                        </div>
                                        <br>
                                        <table class="table table-bordered table-striped mb-none"
                                            id="datatable-default">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <span class="custom-checkbox">
                                                            <input type="checkbox" id="selectAll">
                                                            <label for="selectAll"></label>
                                                        </span>
                                                    </th>
                                                    <th hidden="hidden">ID</th>
                                                    <th style='text-align:center'>Group Code</th>
                                                    <th style='text-align:center'>Group Title</th>
                                                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                    <th style='text-align:center'>Programme</th>
                                                    <?php } ?>
                                                    <th style='text-align:center'>Department Option</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                    //$dept=$_POST["dept"];
                                                    $sno = 0;
                                                    $sql = "SELECT * FROM dept_stu_group WHERE deptcode = '$dept' ORDER BY group_Title";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $group_Code = $row["group_Code"];
                                                            $group_Title = $row["group_Title"];
                                                            $id = $row["id"];
                                                            $prog = $row["prog"];
                                                            $deptopt = $row["deptoption"];
                                                            if ($deptopt == "NOP") {
                                                                $Opt_Title = "No Option";
                                                            } else {
                                                                $sql2 = "SELECT * FROM dept_option WHERE deptcode = '$dept' AND Opt_Code = '$deptopt'";
                                                                $result2 = $conn->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $Opt_Title = $row2["Opt_Title"];
                                                                    }
                                                                }
                                                            }

                                                    ?>
                                                <tr>
                                                    <td>
                                                        <span class="custom-checkbox">
                                                            <input type="checkbox" id="checkbox1" name="options[]"
                                                                value="1">
                                                            <label for="checkbox1"></label>
                                                        </span>
                                                    </td>
                                                    <td hidden="hidden"><?php echo $id; ?></td>
                                                    <td><?php echo $group_Code; ?></td>
                                                    <td><?php echo $group_Title; ?></td>
                                                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                    <td><?php echo $prog; ?></td>
                                                    <?php } ?>
                                                    <td><?php echo $Opt_Title; ?></td>
                                                    <td>
                                                        <?php if ($group_Code != "NG") { ?>
                                                        <button type="button"
                                                            class='btn btn-default btn-xs deleteone'><i
                                                                class="material-icons" data-toggle="tooltip"
                                                                title="Delete" style="color: red">&#xE872;</i></button>
                                                        <?php } ?>
                                                    </td>

                                                </tr>

                                                <?php
                                                        }
                                                    }

                                                    ?>


                                            </tbody>
                                        </table>

                                    </div>
                                    <div class="col-lg-1">

                                    </div>
                                </div>
                                <?php
$conn->close();
?>

                                <?php } ?>


                                <!-- Add New Modal HTML -->
                                <div id="addEmployeeModal" class="modal fade">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="post" action="">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Add New Group</h4>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-hidden="true">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label>Group Code</label>
                                                        <select name="groupcode" class="form-control"
                                                            style="color:#000000">
                                                            <option value="G01">Group 1</option>
                                                            <option value="G02">Group 2</option>
                                                            <option value="G03">Group 3</option>
                                                            <option value="G04">Group 4</option>
                                                            <option value="G05">Group 5</option>
                                                            <option value="G06">Group 6</option>
                                                            <option value="G07">Group 7</option>
                                                            <option value="G08">Group 8</option>
                                                            <option value="G09">Group 9</option>
                                                            <option value="G10">Group 10</option>
                                                        </select>
                                                    </div>

                                                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                    <div class="form-group">
                                                        <label>Programme: </label>
                                                        <select name="groupprog" class="form-control"
                                                            style="color:#000000" required>
                                                            <option value="">Select Item</option>
                                                            <option value="ND">ND</option>
                                                            <option value="HND">HND</option>

                                                        </select>
                                                    </div>
                                                    <?php } ?>
                                                    <?php if ($_SESSION['getOptn'] == "YES") { ?>

                                                    <div class="form-group">
                                                        <label>Department Option: </label>
                                                        <select name="deptopt" class="form-control"
                                                            style="color:#000000" required>
                                                            <option value="">Select Item</option>
                                                            <?php
                                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                        if ($conn->connect_error) {
                                                            die("Connection failed: " . $conn->connect_error);
                                                        }

                                                     
                                                                $dept = $_SESSION["deptAddGroup"];
                                                                $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept'";
                                                                $result = $conn->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $Opt_Code = $row["Opt_Code"];
                                                                        $Opt_Title = $row["Opt_Title"];
                                                                        echo "<option value=$Opt_Code>$Opt_Title</option>";
                                                                    }
                                                                }
                                                                $conn->close();
                                                                ?>

                                                        </select>
                                                    </div>
                                                    <?php } ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <input type="button" class="btn btn-default" data-dismiss="modal"
                                                        value="Cancel">
                                                    <input type="submit" class="btn btn-success" name="addnew"
                                                        value="Save">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>



                                <!-- Delete Modal HTML -->
                                <div id="deleteModal" class="modal fade">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="" method="POST">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Delete Curriculum</h4>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-hidden="true">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="hidden" name="delete_id" id="delete_id">
                                                    <p>Are you sure you want to delete these Records?</p>

                                                    <p class="text-warning"><small>This action cannot be undone.</small>
                                                    </p>
                                                </div>
                                                <div class="modal-footer">
                                                    <input type="button" class="btn btn-default" data-dismiss="modal"
                                                        value="Cancel">
                                                    <input type="submit" name="deletesingle" class="btn btn-danger"
                                                        value="Delete">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>


                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <script>
    $(document).ready(function() {
        // Activate tooltip
        $('[data-toggle="tooltip"]').tooltip();

        // Select/Deselect checkboxes
        var checkbox = $('table tbody input[type="checkbox"]');
        $("#selectAll").click(function() {
            if (this.checked) {
                checkbox.each(function() {
                    this.checked = true;
                });
            } else {
                checkbox.each(function() {
                    this.checked = false;
                });
            }
        });
        checkbox.click(function() {
            if (!this.checked) {
                $("#selectAll").prop("checked", false);
            }
        });
    });
    </script>

    <script>
    $(document).ready(function() {

        $('.deleteone').on('click', function() {

            $('#deleteModal').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);

            $('#delete_id').val(data[1]);

        });
    });
    </script>



</body>

</html>
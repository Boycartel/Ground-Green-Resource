<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>
    <script src="js/getexcel/tableToExcel_Staff.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li><span>APU</span></li>
                            <li><span>Staff Record</span></li>
                            <li class="active">
                                <strong>By Department and State</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            By Department and State
                        </div>
                        <div class="panel-body">

                            <!-- start: page -->
                            <div class="row">

                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="form-group">
                                        <label class="control-label col-lg-3" style="font-size: larger">Scale</label>
                                        <div class="col-lg-4">
                                            <select name="scale" class="form-control" style="color:#000000" id="scale">
                                                <option value='CONUASS'>CONUASS</option>
                                                <option value='CONTISS'>CONTISS</option>
                                                <option value='CONMESS'>CONMESS</option>
                                                <option value='CONHESS'>CONHESS</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-5">
                                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                        </div>
                                    </div>

                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"])) { ?>
                                    <?php
                                    $scale = $_POST["scale"];
                                    $GetTitle = "Staff Count by Department and State of Origin(" . $scale . ")";
                                    ?>
                                    <h2 class="panel-title"><?php echo $GetTitle ?></h2>
                                    <?php
                                    $totmale = $totfemale = $totphdmale = $totphdfemale = $tottotal = 0;
                                    for ($x = 1; $x <= 15; $x++) {
                                        $totmaleG[$x] = 0;
                                        $totfemaleG[$x] = 0;
                                    }
                                    ?>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Department</th>
                                                    <th>Male</th>
                                                    <th>Female</th>

                                                    <?php
                                                    $x = 0;
                                                    $sql = "SELECT * FROM states WHERE state<>'Non Nigerian' ORDER BY state";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $x++;
                                                            $state[$x] = $row["state"];
                                                            $stateM[$x] = 0;
                                                            $stateF[$x] = 0;
                                                            $ToTstateM[$x] = 0;
                                                            $ToTstateF[$x] = 0;
                                                            echo "<th>$state[$x](M)</th>";
                                                            echo "<th>$state[$x](F)</th>";
                                                        }
                                                    }
                                                    $ToTNonNigM = 0;
                                                    $ToTNonNigF = 0;
                                                    ?>
                                                    <th>Non Nigerian(M)</th>
                                                    <th>Non Nigerian(F)</th>
                                                    <th>Total</th>
                                                    <th>Dept Code</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                if ($scale == "CONUASS") {
                                                    $sql = "SELECT * FROM deptcoding WHERE status = 'acad' ORDER BY DeptName";
                                                } else {
                                                    $sql = "SELECT * FROM deptcoding_all ORDER BY status, Depart";
                                                }

                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        for ($xx = 1; $xx <= $x; $xx++) {
                                                            $stateM[$xx] = 0;
                                                            $stateF[$xx] = 0;
                                                        }
                                                        if ($scale == "CONUASS") {
                                                            $DeptCode = $row["DeptCode"];
                                                            $DeptName = $row['DeptName'];
                                                        } else {
                                                            $DeptCode = $row["Code"];
                                                            $DeptName = $row['Depart'];
                                                        }

                                                        $male = $female = $total = 0;

                                                        if ($scale == "CONUASS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE DeptCode = '$DeptCode' AND Scale = 'CONUASS' AND nationality <> 'Non Nigerian'";
                                                        } elseif ($scale == "CONTISS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE DeptCode = '$DeptCode' AND Scale = 'CONTISS' AND nationality <> 'Non Nigerian'";
                                                        } elseif ($scale == "CONHESS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE DeptCode = '$DeptCode' AND Scale = 'CONHESS' AND nationality <> 'Non Nigerian'";
                                                        } elseif ($scale == "CONMESS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE DeptCode = '$DeptCode' AND Scale = 'CONMESS' AND nationality <> 'Non Nigerian'";
                                                        }

                                                        $result2 = $conn7->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $staffstate = $row2["stateOfOrigin"];

                                                                if ($row2["Sex"] == "M") {
                                                                    $male++;
                                                                    $totmale++;

                                                                    for ($xx = 1; $xx <= $x; $xx++) {
                                                                        if (strtoupper($state[$xx]) == $staffstate) {
                                                                            $stateM[$xx]++;
                                                                            $ToTstateM[$xx]++;
                                                                        }
                                                                    }
                                                                } elseif ($row2["Sex"] == "F") {
                                                                    $female++;
                                                                    $totfemale++;
                                                                    for ($xx = 1; $xx <= $x; $xx++) {
                                                                        if (strtoupper($state[$xx]) == $staffstate) {
                                                                            $stateF[$xx]++;
                                                                            $ToTstateF[$xx]++;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        $NonNigM = 0;
                                                        $NonNigF = 0;
                                                        if ($scale == "CONUASS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE DeptCode = '$DeptCode' AND Scale = 'CONUASS' AND nationality = 'Non Nigerian'";
                                                        } elseif ($scale == "CONTISS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE DeptCode = '$DeptCode' AND Scale = 'CONTISS' AND nationality = 'Non Nigerian'";
                                                        } elseif ($scale == "CONHESS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE DeptCode = '$DeptCode' AND Scale = 'CONHESS' AND nationality = 'Non Nigerian'";
                                                        } elseif ($scale == "CONMESS") {
                                                            $sql2 = "SELECT * FROM staff_profile WHERE DeptCode = '$DeptCode' AND Scale = 'CONMESS' AND nationality = 'Non Nigerian'";
                                                        }

                                                        $result2 = $conn7->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {

                                                                if ($row2["Sex"] == "M") {
                                                                    $male++;
                                                                    $totmale++;
                                                                    $NonNigM++;
                                                                    $ToTNonNigM++;
                                                                } elseif ($row2["Sex"] == "F") {
                                                                    $female++;
                                                                    $totfemale++;
                                                                    $NonNigF++;
                                                                    $ToTNonNigF++;
                                                                }
                                                            }
                                                        }
                                                        $total = $male + $female;
                                                        if ($total > 0) {
                                                            $sno++;
                                                            echo "<tr><td>$sno</td><td>$DeptName</td><td>$male</td><td>$female</td>";
                                                            for ($xx = 1; $xx <= $x; $xx++) {
                                                                echo "<td>$stateM[$xx]</td>";
                                                                echo "<td>$stateF[$xx]</td>";
                                                            }
                                                            echo "<td>$NonNigM</td><td>$NonNigF</td><td>$total</td><td>$DeptCode</td><td>
                                                        <form action='dap_staff_list.php' method='post'>
                                                            <input type='hidden' value='$DeptCode' name='id'>
                                                            <input type='hidden' value='yesdept' name='deptstate'>
                                                            <input type='hidden' value='$scale' name='myscale'>
                                                            <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                                        </form>
                                                        </td>
                                                            
                                                        </tr>\n";
                                                        }
                                                    }
                                                }
                                                $tottotal = $totmale + $totfemale;
                                                echo "<tr><td></td><td>Total</td><td>$totmale</td><td>$totfemale</td>";
                                                for ($xx = 1; $xx <= $x; $xx++) {
                                                    echo "<td>$ToTstateM[$xx]</td>";
                                                    echo "<td>$ToTstateF[$xx]</td>";
                                                }

                                                echo "<td>$ToTNonNigM</td><td>$ToTNonNigF</td><td>$tottotal</td><td></td><td></td>
                                                            
                                                        </tr>\n";

                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <br><br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                    </div>

                                <?php } ?>

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
        $(document).ready(function() {
            //fetch table data
            fetch();
            //clicking edit button
            $(document).on('click', '.editbutton', function() {
                var row = $(this).closest('tr');
                //hide values
                row.find('.editValue').hide();
                //show edit input
                row.find('.editInput').show();
                //show save button
                row.find('.savebutton').show();
                //hide edit button
                $(this).hide();
            });
            //save
            $(document).on('click', '.savebutton', function() {
                var row = $(this).closest('tr');
                //hide textbox
                row.find('.editInput').hide();
                //show value
                row.find('.editValue').show();
                //show edit button
                row.find('.editbutton').show();
                //hide save button
                $(this).hide();
                var id = row.attr('id');
                var form = row.find('.editInput').serializeArray();
                form.push({
                    name: 'id',
                    value: id
                });
                $.ajax({
                    method: 'POST',
                    url: 'inline_edit/senate_edit.php',
                    data: form,
                    dataType: 'json',
                    success: function(response) {
                        if (response.error) {
                            $('#response').show().removeClass('alert-sucess').addClass(
                                'alert-danger');
                            $('#message').html(response.message);
                        } else {
                            $('#response').show().removeClass('alert-danger').addClass(
                                'alert-success');
                            $('#message').html(response.message);

                            //populate table with updated row
                            row.find('.editValue.senate_aprove').html(response.member
                                .senate_aprove);
                            row.find('.editValue.senate_comment').html(response.member
                                .senate_comment);
                            //row.find('.editValue.pct').html(response.member.pct);
                            //row.find('.editValue.address').html(response.member.address);

                            row.find('.editInput.senate_aprove').val(response.member
                                .senate_aprove);
                            row.find('.editInput.senate_comment').val(response.member
                                .senate_comment);
                            //row.find('.editInput.pct').val(response.member.pct);
                            //row.find('.editInput.address').val(response.member.address);
                        }
                    }
                });
            });
            //clear msg
            $('#clearMsg').click(function() {
                $('#response').hide();
            });
        });
    </script>
</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$usernames = $_SESSION['names'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
//$stdid = $_SESSION['stdid'];
//$mystdid = $_SESSION['stdid'];
$dept = strtoupper($_SESSION['deptcode']);
$regid = $_SESSION["regid"];
$myregid = $_SESSION["regid"];
$email = $_SESSION['email'];

?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php
                            if ($_SESSION['progtype'] == "UG") {
                                //$stdid = $_SESSION['stdid'];
                                //$dept=$_SESSION['deptcode'];
                                $sql = "SELECT image FROM std_pictures WHERE matric_no='$regid'";
                                $sth = $conn2->query($sql);
                                $result2 = mysqli_fetch_array($sth);

                                echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['image']) . '"  width="50" height="50"/>';
                                //echo "<img src='https://eportal.futminna.edu.ng/rpport/passport_".$_SESSION['stdid'].".jpg' alt='$usernames' class='img-circle' width='50' height='50' data-lock-picture='https://eportal.futminna.edu.ng/rpport/passport_".$_SESSION['stdid'].".jpg' />";
                            } else {
                                //echo "<img src='https://eportal.futminna.edu.ng/pg/uploads/" . $_SESSION['stdid'] . "_passport.jpg' alt='$usernames' class='img-circle' width='50' height='50' data-lock-picture='https://eportal.futminna.edu.ng/rpport/passport_" . $_SESSION['stdid'] . ".jpg' />";
                            }

                            ?>
                        </figure>
                        <div class="profile-info" data-lock-name="<?php echo $regid ?>" data-lock-email="<?php echo $email ?>">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $regid ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_stu.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout_stu.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>
                            <!--<li>
									<a role="menuitem" tabindex="-1" href="lock_screen_stu.php" data-lock-screen="true"><i class="fa fa-lock"></i> Lock Screen</a>
								</li>-->



                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_class.php'; ?>
            <!-- end: sidebar -->
            <?php
            //$C_title="Classroom";

            if (isset($_POST["submit_class"])) {
                $_SESSION["getccode"] = "";
                $_SESSION["inipost"] = "";
                $_SESSION["newtopic"] = "NO";
                $_SESSION["course_title"] = "Classroom";
                $_SESSION["topics"] = "Classroom";
                $_SESSION["topics_id"] = 0;
                $_SESSION["showchat"] = 0;
                $_SESSION["startchat"] = "YES";
                $_SESSION["noonline"] = 0;
            }


            if (isset($_POST["sub_file"]) || isset($_POST["upfile"])) {

                $_SESSION["showchat"] = 0;
                $_SESSION["startchat"] = "NO";
                $_SESSION["be_on_chat"] = "YES";
            }

            if (isset($_POST["all_chat"]) || isset($_POST["submit_all"])) {

                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
                if ($_SESSION["topics_id"] == 0) {
                    $_SESSION["be_on_chat"] = "NO";
                } else {
                    $_SESSION["be_on_chat"] = "YES";
                }
            }

            if (isset($_POST["assignment"]) || isset($_POST["sub_assignment"])) {
                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
                if ($_SESSION["topics_id"] == 0) {
                    $_SESSION["be_on_chat"] = "NO";
                } else {
                    $_SESSION["be_on_chat"] = "YES";
                }
            }

            if (isset($_POST["quiz"]) || isset($_POST["sub_quiz"])) {
                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 0;
                if ($_SESSION["topics_id"] == 0) {
                    $_SESSION["be_on_chat"] = "NO";
                } else {
                    $_SESSION["be_on_chat"] = "YES";
                }
            }

            if (isset($_POST["submit_ccode"])) {
                //$_SESSION["inipost"]="XX";
                $getccode = $_POST["getccode"];
                $_SESSION["getccode"] = $getccode;

                $sql = "SELECT * FROM aaa_online_courses WHERE ccode = '$getccode'";
                $result = $conn8->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["course_title"] = $row["c_title"];
                        $_SESSION["topics_id"] = $row["topic_id"];
                        $_SESSION["staffid"] = $row["staffid"];
                        $_SESSION["staffname"] = $row["staffname"];
                        $_SESSION["staffdept"] = $row["staffdept"];
                        $_SESSION["lectduration"] = $row["lectduration"];
                        //$_SESSION["timestart"] = $row["timestart"];
                    }
                }
                $topics_id = $_SESSION["topics_id"];
                $sql = "SELECT * FROM aaa_course_topic WHERE ccode = '$getccode' AND id = '$topics_id'";
                $result = $conn8->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["topics"] = $row["topics"];
                    }
                }

                $sql = "SELECT * FROM aaa_online_stu WHERE stdid = '$mystdid'";
                $result = $conn8->query($sql);
                if ($result->num_rows == 0) {
                    $sql2 = "INSERT INTO aaa_online_stu (stdid, regdid, ccode, name1, dept, status)VALUE('$mystdid', '$myregid', '$getccode', '$usernames', '$dept', 'online')";
                    $result2 = $conn8->query($sql2);
                }

                $sql = "SELECT * FROM aaa_online_stu WHERE ccode = '$getccode' AND status = 'online'";
                $result = $conn8->query($sql);
                $_SESSION["noonline"] = mysqli_num_rows($result);

                $_SESSION["startchat"] = "NO";
                $_SESSION["showchat"] = 1;
            }


            if (isset($_POST["submit_back_to_chat"])) {

                $_SESSION["showchat"] = 1;
                $_SESSION["be_on_chat"] = "NO";
            }
            ?>
            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>">
                    <h2>
                        <?php if (isset($_POST["quiz"])) { ?>
                            <?php
                            //							$duration=0;
                            //							$getccode=$_SESSION["getccode"];
                            //							$sql = "SELECT * FROM aaa_quiz_list WHERE ccode = '$getccode' AND session1 = '$curtsession' AND quiz_begin = 'start'";
                            //							$result = $conn8->query($sql);
                            //							if ($result->num_rows > 0) {
                            //								while($row = $result->fetch_assoc()) {
                            //									$duration=$row["rem_time"];
                            //
                            //								}
                            //							}
                            ?>
                            <div id="quiz_counter2">

                            </div>

                        <?php } else { ?>
                            <?php echo $_SESSION["course_title"] . " (" . $_SESSION["getccode"] . ")" ?>
                        <?php } ?>

                    </h2>

                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="classroom_stu_start.php">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li>
                                <form class="form-horizontal bucket-form" method="Post" action="classroom_stu_course.php">
                                    <input type="submit" value="Classroom" name="submit_class" class='btn btn-primary btn-xs'>
                                </form>
                            </li>
                        </ol>

                        <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">

                            <div class="nano">
                                <div class="form-group" style="padding-left: 1em; padding-right: 1em">

                                    <div class="widget-header clearfix">
                                        <h6 class="btn btn-dark btn-sm btn-widget-act">Online:
                                            <?php echo $_SESSION["noonline"] ?></h6>

                                    </div>
                                </div>
                                <div class="nano-content">

                                    <div class="inner-menu-toggle-inside">
                                        <a href="#" class="inner-menu-collapse">
                                            <i class="fa fa-chevron-up visible-xs-inline"></i><i class="fa fa-chevron-left hidden-xs-inline"></i> Hide Bar
                                        </a>
                                        <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                            Show Bar <i class="fa fa-chevron-down"></i>
                                        </a>
                                    </div>

                                    <div class="inner-menu-content">


                                        <?php if (!isset($_POST["quiz"]) && !isset($_POST["sub_quiz"]) && !isset($_POST["sub_quiz_pdf"])) { ?>
                                            <hr class="separator" />
                                            <?php
                                            if ($_SESSION["startchat"] == "NO") {
                                                if (isset($_POST["submit_ccode"])) {
                                                    $getccode = $_POST["getccode"];
                                                    $_SESSION["getccode"] = $getccode;
                                                }

                                            ?>

                                                <div class="sidebar-widget widget-friends" id="online_status">

                                                </div>
                                            <?php } ?>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">

                            <div class="inner-toolbar clearfix" style="color:#ffffff">
                                <ul>
                                    <li>
                                        <?php
                                        if ($_SESSION["startchat"] == "NO") {
                                            $getccode = $_SESSION["getccode"];
                                            $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getccode' AND session1 = '$curtsession' AND status = 'open'";
                                            $result = $conn8->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    if ($row["deadline"] >= date("Y-m-d")) {
                                        ?>
                                                        <form class="" method="post">
                                                            <input type="submit" value="Assignment" name="assignment" class='btn btn-success btn-xs'>
                                                        </form>
                                        <?php
                                                    }
                                                }
                                            }
                                        }
                                        ?>

                                    </li>
                                    <li>
                                        <?php
                                        if ($_SESSION["startchat"] == "NO") {
                                            $getccode = $_SESSION["getccode"];

                                            $sql = "SELECT * FROM aaa_quiz_list WHERE ccode = '$getccode' AND session1 = '$curtsession' AND quiz_begin = 'start'";
                                            $result = $conn8->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                        ?>
                                                    <form class="" method="post">
                                                        <input type="submit" value="Quiz" name="quiz" class='btn btn-success btn-xs'>
                                                    </form>
                                        <?php
                                                }
                                            }
                                        }
                                        ?>
                                    </li>
                                    <li>
                                        <?php echo $_SESSION["topics"] ?>
                                    </li>
                                    <li>

                                    </li>
                                    <li class="right">

                                        <ul class="nav nav-pills nav-pills-primary">

                                            <li>
                                                <form class="form-horizontal form-bordered" method="post">
                                                    <input type="submit" value="View All Chat" name="all_chat" class='btn btn-primary btn-sm'>
                                                </form>
                                            </li>

                                            <li>

                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>



                            <?php if (isset($_POST["sub_file"]) || isset($_POST["upfile"])) { ?>
                                <div class="col-lg-12" style="padding-bottom: 5em">
                                    <?php
                                    $getccode = $_SESSION["getccode"];
                                    $staffid = $_SESSION['staffid'];
                                    $curtsession = $_SESSION['corntsession'];
                                    $usernames = $_SESSION['names'];
                                    $topics_id = $_SESSION["topics_id"];
                                    $topics = $_SESSION["topics"];
                                    ?>
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>

                                            <h2 class="panel-title">Upload File for <?php echo $getccode ?></h2>
                                        </header>

                                        <div class="panel-body">
                                            <?php
                                            $dept = $_SESSION['deptcode'];

                                            $msgsuces = $message = "";
                                            $sessionreplace = str_replace("/", "_", $curtsession);

                                            if (isset($_POST['upfile']) && !empty($_POST['upfile'])) {
                                                $fileTmpPath = $_FILES['file']['tmp_name'];
                                                $fileName = $_FILES['file']['name'];
                                                $fileSize = $_FILES['file']['size'];
                                                $fileType = $_FILES['file']['type'];
                                                $fileNameCmps = explode(".", $fileName);
                                                $fileExtension = strtolower(end($fileNameCmps));


                                                $fileName = str_replace("'", "''", $fileName);
                                                $fileName = filter_var($fileName, FILTER_SANITIZE_STRING);
                                                $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                                                $newFileName = $fileName;

                                                $allowedfileExtensions = array('jpg', 'gif', 'png', 'txt', 'xls', 'xlsx', 'doc', 'docx', 'pdf');
                                                if (in_array($fileExtension, $allowedfileExtensions)) {
                                                    // directory in which the uploaded file will be moved
                                                    if ($_FILES['file']['size'] / 1024 <= 5120) { // 5MB
                                                        $uploadFileDir = "./classroom/" . $sessionreplace . "/" . $getccode . "/";

                                                        if (!file_exists($uploadFileDir)) {
                                                            mkdir($uploadFileDir, 0777, true);
                                                        }

                                                        $sql = "SELECT * FROM aaa_id_increament WHERE id_code = '$getccode' AND session1 = '$curtsession'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $id_number = $row["id_number"];
                                                            }
                                                        }
                                                        $id_number++;

                                                        $dest_path = $uploadFileDir . $id_number . "." . $fileExtension;

                                                        if (move_uploaded_file($fileTmpPath, $dest_path)) {
                                                            $getccode2 = strtolower($getccode);
                                                            $sql = "INSERT INTO " . $getccode2 . " (user_id, fullname, session1, topic_id, image_url, imgname, filetype, topics) VALUES ('$mystdid', '$usernames', '$curtsession', '$topics_id', '$dest_path', '$newFileName', '$fileExtension', '$topics')";
                                                            $result = $conn8->query($sql);

                                                            $sql = "UPDATE aaa_id_increament set id_number = '$id_number' WHERE id_code = '$getccode' AND session1 = '$curtsession'";
                                                            $result = $conn8->query($sql);

                                                            $msgsuces = 'File is successfully uploaded.';
                                                        } else {
                                                            $message = 'Error in moving the file. Make sure you select correct file type.';
                                                        }
                                                    } else {
                                                        $message = 'File should be maximun 5MB in size!';
                                                    }
                                                }
                                            }
                                            ?>
                                            <div class="col-lg-12">
                                                <h2 style="color:#0000ff"><?php echo $msgsuces ?></h2>
                                                <h2 style="color: #ff0000"><?php echo $message ?></h2>
                                                <h4>You can upload files in the following extenssions ( jpg, gif, png, zip,
                                                    txt, xls, xlsx, doc, docx, pdf)</h4><br><br>
                                                <form enctype="multipart/form-data" action="" method="post">

                                                    <div class="form-group">
                                                        <label class="col-md-2 control-label">File Upload</label>
                                                        <div class="col-md-6">
                                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                                <div class="input-append">
                                                                    <div class="uneditable-input">
                                                                        <i class="fa fa-file fileupload-exists"></i>
                                                                        <span class="fileupload-preview"></span>
                                                                    </div>
                                                                    <span class="btn btn-default btn-file">
                                                                        <span class="fileupload-exists">Change</span>
                                                                        <span class="fileupload-new">Select file</span>
                                                                        <input type="file" name="file" />
                                                                    </span>
                                                                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2">
                                                            <input type="submit" name="upfile" value="Upload File" class="btn btn-primary btn-sm">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </section>
                                </div>
                            <?php } ?>

                            <?php if (isset($_POST["quiz"]) || isset($_POST["sub_quiz"]) || isset($_POST["sub_quiz_pdf"])) { ?>
                                <?php
                                $getccode = $_SESSION["getccode"];
                                $sql = "SELECT * FROM aaa_quiz_list WHERE ccode = '$getccode' AND session1 = '$curtsession' AND quiz_begin = 'start'";
                                $result = $conn8->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $quiz_opt = $row["quiz_opt"];
                                        $no_question = $row["no_question"];
                                        $quiz_no = $row["quiz_no"];
                                        $file_url = $row["file_url"];
                                    }
                                }

                                ?>
                                <?php if ($quiz_opt == "fulautho") { ?>
                                    <div class="row">
                                        <section class="panel">
                                            <header class="panel-heading">
                                                <div class="panel-actions">
                                                    <a href="#" class="fa fa-caret-down"></a>
                                                    <a href="#" class="fa fa-times"></a>
                                                </div>

                                                <h2 class="panel-title"><?php echo $getccode ?> Quiz</h2>
                                            </header>
                                            <div class="panel-body" style="font-size: 16px; color: #000000">
                                                <?php
                                                if (isset($_POST["sub_quiz"])) {
                                                    $myscores = 0;
                                                    $getccode = $_SESSION["getccode"];
                                                    $sql = "SELECT * FROM aaa_quiz_list WHERE ccode = '$getccode' AND session1 = '$curtsession' AND quiz_begin = 'start'";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        $myans = "";

                                                        $sql = "SELECT * FROM aaa_quiz WHERE ccode = '$getccode'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $id = $row["id"];
                                                                $ans = $row["ans"];
                                                                if (isset($_POST["options" . $id])) {
                                                                    $myans = $_POST["options" . $id];
                                                                    if ($myans == $ans) {
                                                                        $myscores++;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        echo "<h2 style='text-align: center' class='panel-title'>Scores: $myscores out of $no_question</h2>";
                                                    } else {
                                                        echo "<h2 style='text-align: center' class='panel-title' style='color: #ff0000'>Sorry: Time elapse before submission</h2>";
                                                    }

                                                    $sql = "SELECT * FROM aaa_quiz_results WHERE stdid = '$mystdid' AND ccode = '$getccode' AND session1 = '$curtsession'";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        $sql2 = "UPDATE aaa_quiz_results SET n" . $quiz_no . " = '$myscores' WHERE stdid = '$mystdid' AND ccode = '$getccode' AND session1 = '$curtsession'";
                                                        $result2 = $conn8->query($sql2);
                                                    } else {
                                                        $sql2 = "INSERT INTO aaa_quiz_results (stdid, stureg, name1, ccode, session1, n$quiz_no)VALUE('$mystdid', '$myregid', '$usernames', '$getccode', '$curtsession', '$myscores')";
                                                        $result2 = $conn8->query($sql2);
                                                    }

                                                    $sql2 = "INSERT INTO aaa_current_quiz (ccode, stdid)VALUE('$getccode', '$mystdid')";
                                                    $result2 = $conn8->query($sql2);
                                                }
                                                ?>

                                                <?php if (!isset($_POST["sub_quiz"])) { ?>
                                                    <form method="POST" class="form-horizontal" action="#">
                                                        <?php
                                                        $sno = 0;
                                                        $sql = "SELECT * FROM aaa_quiz WHERE ccode = '$getccode' ORDER BY RAND()";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $id = $row["id"];
                                                                $question = $row["question"];
                                                                $optA = $row["optA"];
                                                                $optB = $row["optB"];
                                                                $optC = $row["optC"];
                                                                $optD = $row["optD"];
                                                                $ans = $row["ans"];
                                                        ?>
                                                                <div class="form-group">
                                                                    <label class="col-md-2 control-label">Question
                                                                        <?php echo $sno ?></label>
                                                                    <div class="col-md-9">
                                                                        <label class=" control-label"><?php echo $question ?></label>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-2">
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="radio" name="options<?php echo $id ?>" value="A"> A.
                                                                        <label class=" control-label"><?php echo $optA ?></label>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-2">
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="radio" name="options<?php echo $id ?>" value="B"> B.
                                                                        <label class=" control-label"><?php echo $optB ?></label>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-2">
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="radio" name="options<?php echo $id ?>" value="C"> C.
                                                                        <label class=" control-label"><?php echo $optC ?></label>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-2">
                                                                    </div>
                                                                    <div class="col-md-9">
                                                                        <input type="radio" name="options<?php echo $id ?>" value="D"> D.
                                                                        <label class=" control-label"><?php echo $optD ?></label>
                                                                    </div>
                                                                </div>
                                                                <hr class="separator" />


                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                        <?php
                                                        $sql = "SELECT * FROM aaa_current_quiz WHERE ccode = '$getccode' AND stdid = '$mystdid'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows == 0) {
                                                        ?>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label"></label>
                                                                <div class="col-md-9">
                                                                    <button type="submit" name="sub_quiz" class="btn btn-primary">Submit</button>
                                                                </div>
                                                            </div>
                                                        <?php
                                                        }
                                                        ?>
                                                    </form>
                                                <?php } ?>
                                            </div>
                                        </section>
                                    </div>
                                <?php } else { ?>
                                    <div class="row">
                                        <section class="panel">
                                            <header class="panel-heading">
                                                <div class="panel-actions">
                                                    <a href="#" class="fa fa-caret-down"></a>
                                                    <a href="#" class="fa fa-times"></a>
                                                </div>

                                                <h2 class="panel-title"><?php echo $getccode ?> Quiz</h2>
                                            </header>
                                            <div class="panel-body" style="font-size: 16px; color: #000000">

                                                <?php
                                                if (isset($_POST["sub_quiz_pdf"])) {
                                                    $myans = "";
                                                    $myscores = 0;
                                                    $sql = "SELECT * FROM aaa_quiz_pdf WHERE ccode = '$getccode'";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["id"];
                                                            $ans = $row["ans"];
                                                            if (isset($_POST["options" . $id])) {
                                                                $myans = $_POST["options" . $id];
                                                                if ($myans == $ans) {
                                                                    $myscores++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    echo "<center><h2 class='panel-title'>Scores: $myscores out of $no_question</h2></center>";

                                                    $sql = "SELECT * FROM aaa_quiz_results WHERE stdid = '$mystdid' AND ccode = '$getccode' AND session1 = '$curtsession'";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        $sql2 = "UPDATE aaa_quiz_results SET n" . $quiz_no . " = '$myscores' WHERE stdid = '$mystdid' AND ccode = '$getccode' AND session1 = '$curtsession'";
                                                        $result2 = $conn8->query($sql2);
                                                    } else {
                                                        $sql2 = "INSERT INTO aaa_quiz_results (stdid, stureg, name1, ccode, session1, n$quiz_no)VALUE('$mystdid', '$myregid', '$usernames', '$getccode', '$curtsession', '$myscores')";
                                                        $result2 = $conn8->query($sql2);
                                                    }

                                                    $sql2 = "INSERT INTO aaa_current_quiz (ccode, stdid)VALUE('$getccode', '$mystdid')";
                                                    $result2 = $conn8->query($sql2);
                                                }
                                                ?>
                                                <?php if (!isset($_POST["sub_quiz_pdf"])) { ?>
                                                    <div class="col-lg-8">
                                                        <embed src="<?php echo $file_url ?>" width="100%" height="700px" />
                                                    </div>
                                                    <div class="col-lg-4">
                                                        <form method="POST" class="form-horizontal" action="#">
                                                            <?php
                                                            $sql = "SELECT * FROM aaa_quiz_pdf WHERE ccode = '$getccode' ORDER BY RAND()";
                                                            $result = $conn8->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $id = $row["id"];
                                                                    $q_number = $row["q_number"];

                                                            ?>
                                                                    <div class="form-group">
                                                                        <label class="col-md-5 control-label">Question
                                                                            <?php echo $q_number ?></label>
                                                                        <div class="col-md-7">
                                                                            <input type="radio" name="options<?php echo $id ?>" value="A">
                                                                            A&nbsp;
                                                                            <input type="radio" name="options<?php echo $id ?>" value="B">
                                                                            B&nbsp;
                                                                            <input type="radio" name="options<?php echo $id ?>" value="C">
                                                                            C&nbsp;
                                                                            <input type="radio" name="options<?php echo $id ?>" value="D">
                                                                            D&nbsp;
                                                                        </div>
                                                                    </div>

                                                                    <hr class="separator" />


                                                            <?php
                                                                }
                                                            }
                                                            ?>
                                                            <?php
                                                            $sql = "SELECT * FROM aaa_current_quiz WHERE ccode = '$getccode' AND stdid = '$mystdid'";
                                                            $result = $conn8->query($sql);
                                                            if ($result->num_rows == 0) {
                                                            ?>
                                                                <div class="form-group">
                                                                    <label class="col-md-3 control-label"></label>
                                                                    <div class="col-md-9">
                                                                        <button type="submit" name="sub_quiz_pdf" class="btn btn-primary">Submit</button>
                                                                    </div>
                                                                </div>
                                                            <?php
                                                            }
                                                            ?>
                                                        </form>
                                                    </div>

                                                <?php } ?>
                                            </div>
                                        </section>
                                    </div>
                                <?php } ?>
                            <?php } ?>

                            <?php if (isset($_POST["assignment"]) || isset($_POST["upfile_assign"])) { ?>
                                <div class="row">
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>

                                            <h2 class="panel-title">Assignment for <?php echo $getccode ?></h2>
                                        </header>

                                        <div class="panel-body">
                                            <?php
                                            $theassignment = $file_url = $deadline = $myfile_url = "";
                                            $getccode = $_SESSION["getccode"];
                                            $curtsession = $_SESSION['corntsession'];
                                            $sessionreplace = str_replace("/", "_", $curtsession);

                                            $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getccode' AND session1 = '$curtsession' AND status = 'open'";
                                            $result = $conn8->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    if ($row["deadline"] >= date("Y-m-d")) {
                                                        $theassignment = $row["message"];
                                                        $file_url = $row["file_url"];
                                                        $assignment_no = $row["assignment_no"];
                                                        $deadline = date('d F, Y', strtotime($row["deadline"]));
                                                    }
                                                }
                                            }

                                            if ($assignment_no == 1) {
                                                $assign_cat = "First Assignment";
                                            } elseif ($assignment_no == 2) {
                                                $assign_cat = "Second Assignment";
                                            } else {
                                                $assign_cat = "Third Assignment";
                                            }

                                            $sql = "SELECT * FROM aaa_sub_assignment_" . $sessionreplace . " WHERE ccode = '$getccode' AND stdid = '$mystdid' AND assign_no = '$assignment_no'";
                                            $result = $conn8->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $myfile_url = $row["file_url"];
                                                }
                                            }

                                            $msgsuces = $message = "";

                                            if (isset($_POST['upfile_assign']) && !empty($_POST['upfile_assign'])) {
                                                $fileTmpPath = $_FILES['file_assign']['tmp_name'];
                                                $fileName = $_FILES['file_assign']['name'];
                                                $fileSize = $_FILES['file_assign']['size'];
                                                $fileType = $_FILES['file_assign']['type'];
                                                $fileNameCmps = explode(".", $fileName);
                                                $fileExtension = strtolower(end($fileNameCmps));


                                                $fileName = str_replace("'", "''", $fileName);
                                                $fileName = filter_var($fileName, FILTER_SANITIZE_STRING);
                                                $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                                                $newFileName = $fileName;

                                                $allowedfileExtensions = array('pdf');
                                                if (in_array($fileExtension, $allowedfileExtensions)) {
                                                    // directory in which the uploaded file will be moved
                                                    if ($_FILES['file_assign']['size'] / 1024 <= 1024) { // 1MB
                                                        $assign_no = $_SESSION["assignment_no"];

                                                        $uploadFileDir = "classroom/assignment/" . $sessionreplace . "/" . $getccode . "/submited/";

                                                        if (!file_exists($uploadFileDir)) {
                                                            mkdir($uploadFileDir, 0777, true);
                                                        }


                                                        $dest_path = $uploadFileDir . $mystdid . "_" . $assignment_no . "." . $fileExtension;

                                                        if (move_uploaded_file($fileTmpPath, $dest_path)) {
                                                            $sql = "SELECT * FROM aaa_sub_assignment_" . $sessionreplace . " WHERE ccode = '$getccode' AND stdid = '$mystdid' AND assign_no = '$assignment_no'";
                                                            $result = $conn8->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                $sql = "UPDATE aaa_sub_assignment_" . $sessionreplace . " SET file_url = '$dest_path' WHERE ccode = '$getccode' AND stdid = '$mystdid' AND assign_no = '$assignment_no'";
                                                                $result = $conn8->query($sql);
                                                            } else {
                                                                $sql = "INSERT INTO aaa_sub_assignment_" . $sessionreplace . " (stdid, stureg, name1, ccode, assign_no, file_url)VALUE('$mystdid', '$myregid', '$usernames', '$getccode', '$assignment_no', '$dest_path')";
                                                                $result = $conn8->query($sql);
                                                            }

                                                            $msgsuces = 'File is successfully uploaded.';
                                                        } else {
                                                            $message = 'Error in moving the file. Make sure you select correct file type.';
                                                        }
                                                    } else {
                                                        $message = 'Error: File should be maximun 1MB in size!';
                                                    }
                                                } else {
                                                    $message = 'Error: Select Microsoft Word File file';
                                                }
                                            }



                                            ?>
                                            <div class="col-lg-1">

                                            </div>
                                            <div class="col-lg-10">
                                                <?php if ($myfile_url !== "") { ?>
                                                    <a href="<?php echo $myfile_url ?>">Click to Download your uploaded file
                                                        ...</a>
                                                    <br><br>
                                                <?php } ?>
                                                <center>
                                                    <h4><b><?php echo $assign_cat ?></b></h4>
                                                </center>
                                                <br>
                                                <label><?php echo $theassignment ?></label>
                                                <?php if ($file_url !== "") { ?>
                                                    <br><br>
                                                    <a href="<?php echo $file_url ?>">Click to Download ...</a>
                                                    <iframe src="<?php echo $file_url ?>" width="100%" height="500px"></iframe>
                                                    <br><br><br><br>
                                                <?php } ?>

                                                <center>
                                                    <h4>Submit Assignment here ...<b>(Deadline : <?php echo $deadline ?>
                                                            )</b></h4>
                                                </center>
                                                <center>
                                                    <h4>Your upload must be in pdf Format (".pdf")</h4>
                                                </center>
                                                <br>
                                                <h4>Maximum of 1MB</h4><br>
                                                <form enctype="multipart/form-data" action="" method="post">
                                                    <div class="form-group">
                                                        <label class="col-md-2 control-label" style="font-size: 14px">Upload
                                                            Assignment</label>
                                                        <div class="col-md-6">
                                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                                <div class="input-append">
                                                                    <div class="uneditable-input">
                                                                        <i class="fa fa-file fileupload-exists"></i>
                                                                        <span class="fileupload-preview"></span>
                                                                    </div>
                                                                    <span class="btn btn-default btn-file">
                                                                        <span class="fileupload-exists">Change</span>
                                                                        <span class="fileupload-new">Select file</span>
                                                                        <input type="file" name="file_assign" />
                                                                    </span>
                                                                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2">
                                                            <input type="submit" name="upfile_assign" value="Upload File" class="btn btn-primary btn-sm">
                                                        </div>
                                                    </div>
                                                </form>
                                                <?php if (isset($_POST['upfile_assign'])) { ?>
                                                    <center>
                                                        <h3 style="color:#0000ff"><?php echo $msgsuces ?></h3>
                                                    </center>
                                                    <center>
                                                        <h5 style="color:#ff0000"><?php echo $message ?></h5>
                                                    </center>

                                                <?php } ?>
                                            </div>
                                            <div class="col-lg-1">

                                            </div>
                                        </div>
                                    </section>

                                </div>
                            <?php } ?>

                            <?php if (isset($_POST["all_chat"]) || isset($_POST["submit_all"])) { ?>
                                <div class="row">
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="content">Select Course:</label>
                                                <div class="col-lg-8">
                                                    <select class="country form-control" style="color:#000000" name="all_course">
                                                        <?php
                                                        $dbsession = str_replace("/", "_", $curtsession);
                                                        $sql = "SELECT * FROM courses_register_" . $dbsession . " WHERE Regn1='$myregid' AND SemTaken='$cursemester' ORDER BY CCode";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $CCode = $row["CCode"];
                                                                $CTitle = $row["CTitle"];
                                                                echo "<option value='$CCode'>$CCode $CTitle</option>";
                                                            }
                                                        }
                                                        ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="control-label col-lg-3">Filter:</label>
                                                <div class="col-lg-5">
                                                    <select name="filterchat" class="form-control" style="color:#000000">
                                                        <option value="byme">Chat From Me</option>
                                                        <option value="bylecturer">Chat From Lecturer</option>
                                                        <option value="byothers">Chat From Others</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-3">
                                                    <button type="submit" name="submit_all" class="btn btn-primary btn-sm">Submit</button>

                                                </div>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                                <hr class="separator" />
                                <?php if (isset($_POST["submit_all"])) { ?>
                                    <?php
                                    $getallcourses = $_POST["all_course"];
                                    $getfilter = $_POST["filterchat"];

                                    //$getccode=$_SESSION["getccode"]; 
                                    $staffid = $_SESSION['staffid'];
                                    $curtsession = $_SESSION['corntsession'];
                                    $usernames = $_SESSION['names'];
                                    $topics_id = $_SESSION["topics_id"];

                                    $sql = "SELECT C_codding, C_title FROM gencoursesupload WHERE C_codding = '$getallcourses'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $getctitle = $row["C_title"];
                                        }
                                    }


                                    ?>
                                    <div class="col-lg-12">
                                        <section class="panel">
                                            <header class="panel-heading">

                                                <h2 class="panel-title"><?php echo $getctitle . " (" . $getallcourses . ")" ?>
                                                </h2>
                                            </header>
                                            <div class="panel-body">

                                                <table class="table table-bordered table-striped mb-none" id="datatable-default">
                                                    <thead style='text-align:center'>
                                                        <tr>
                                                            <th>S/No</th>
                                                            <th>Sender's Name</th>
                                                            <th>Topic</th>
                                                            <th>Message</th>
                                                            <th>Date</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $sno = 0;
                                                        $getallcourses2 = strtolower($getallcourses);

                                                        if ($getfilter == "byme") {
                                                            $sql = "SELECT * FROM " . $getallcourses2 . " WHERE session1='$curtsession' AND user_id='$mystdid' ORDER BY topic_id, date1";
                                                        } elseif ($getfilter == "bylecturer") {
                                                            $sql = "SELECT * FROM " . $getallcourses2 . " WHERE session1='$curtsession' AND usertype='staff' ORDER BY topic_id, date1";
                                                        } else {
                                                            $sql = "SELECT * FROM " . $getallcourses2 . " WHERE session1='$curtsession' AND user_id <> '$mystdid'  AND usertype = 'stu' ORDER BY topic_id, date1";
                                                        }

                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $user_id = $row["user_id"];
                                                                $message = $row["message"];
                                                                $date1 = $row["date1"];
                                                                $fullname = $row["fullname"];
                                                                $image_url = $row["image_url"];
                                                                $imgname = $row["imgname"];
                                                                $filetype = $row["filetype"];
                                                                $topics = $row["topics"];
                                                                echo "<tr><td>$sno</td><td>$fullname</td><td>$topics</td><td>";
                                                        ?>
                                                                <?php if ($filetype == "jpg" || $filetype == "gif" || $filetype == "png") { ?>
                                                                    <a class="thumb-image" href="<?php echo $image_url ?>" target="_blank">
                                                                        <img src="<?php echo $image_url ?>" width="100" height="100">
                                                                    </a>
                                                                <?php } elseif ($filetype == "mp3") { ?>

                                                                    <audio>
                                                                        <source src="<?php echo $image_url ?>" type="audio/mpeg">

                                                                    </audio>
                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/audio_icon.svg" width="40" height="40"><?php echo $imgname ?></a>

                                                                <?php } elseif ($filetype == "mp4") { ?>


                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/video_icon.jpg" width="40" height="40"><?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "doc" || $filetype == "docx") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/word_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "xls" || $filetype == "xlsx") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/excel_icon.png" width="40" height="40">
                                                                        <?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "pdf") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/pdf_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "zip") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/zip_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                                                <?php } elseif ($filetype == "txt") { ?>

                                                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/txt.png" width="40" height="40"><?php echo $imgname ?></a>

                                                                <?php } ?>
                                                                <?php echo $message ?>
                                                        <?php
                                                                echo "</td><td>$date1</td></tr>";
                                                            }
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                    </div>
                                <?php } ?>
                            <?php } ?>

                            <?php if ($_SESSION["startchat"] == "YES") { ?>

                                <div class="row mg-files" data-sort-destination data-sort-id="media-gallery">
                                    <?php

                                    $curtsession2 = str_replace("/", "_", $curtsession);
                                    $sql = "SELECT * FROM courses_register_" . $curtsession2 . " WHERE Regn1='$regid' AND SemTaken='$cursemester' ORDER BY CCode";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $CCode = $row["CCode"];
                                            $CTitle = $row["CTitle"];
                                            $nostaf = 0;
                                            $sql2 = "SELECT * FROM coursealocation WHERE SessionReg='$curtsession' AND CCode='$CCode'";
                                            $result2 = $conn->query($sql2);

                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $nostaf++;
                                                    $PFNo = $row2["PFNo"];
                                                    $sql3 = "SELECT * FROM users WHERE staffid='$PFNo'";
                                                    if ($_SESSION['progtype'] == "UG") {
                                                        $result3 = $conn->query($sql3);
                                                    } else {
                                                        $result3 = $conn5->query($sql3);
                                                    }

                                                    if ($result3->num_rows > 0) {
                                                        while ($row3 = $result3->fetch_assoc()) {
                                                            $otherstffdept = $row3["department"];
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    ?>

                                </div>
                            <?php } ?>


                            <?php
                            if ($_SESSION["showchat"] == 1) { ?>

                                <div class="col-lg-12" style="padding-bottom: 5em">
                                    <section class="panel">
                                        <header class="panel-heading">

                                            <h2 class="panel-title"><?php echo $_SESSION["topics"] ?></h2>
                                        </header>
                                        <div class="panel-body" id="chat_body" style="background-color: #999999">

                                        </div>
                                    </section>
                                </div>

                                <div style="color:#ffffff; width:100%; position: fixed; background-color:#000000; bottom: 0;">

                                    <div class="form-group col-lg-7 col-md-7 col-sm-7" style="padding-top: 1em">

                                        <ul class="chats">
                                            <li class="by-me">
                                                <div class="avatar pull-left">
                                                    <?PHP


                                                    $sql = "SELECT imageType, imageData FROM " . strtolower($dept) . " WHERE stdid='$mystdid'";
                                                    $sth = $conn10->query($sql);
                                                    $result2 = mysqli_fetch_array($sth);

                                                    echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['imageData']) . '"  width="50" height="50"/>';
                                                    ?>

                                                </div>

                                                <div class="chat-content">
                                                    <textarea name="mychat" id="mychat" class="form-control" rows="2" placeholder="Type your message"></textarea>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="form-group col-lg-4  col-md-4 col-sm-4" style="padding-top: 1em; padding-right: 2em">
                                        <button type="submit" name="sub_post" id="sub_post" class="btn btn-primary btn-xs">Post</button><br><br>
                                        <form action='' method='post'>
                                            <button type="submit" name="sub_file" class="btn btn-default btn-xs"><i class="fa fa-paperclip"></i>Attach File</button><br>
                                            <?php
                                            $getccode2 = strtolower($_SESSION["getccode"]);
                                            $sql = "SELECT * FROM meeturl WHERE ccode = '$getccode2'";
                                            $result = $conn8->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $mymeeturl = $row["url"];
                                                }
                                                echo "<a href='https://$mymeeturl' target='_blank'>Click to connect to meet</a>";
                                            }
                                            ?>
                                        </form>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </section>
                <!-- end: page -->
            </section>
        </div>

        <aside id="sidebar-right" class="sidebar-right">
            <div class="nano">
                <div class="nano-content">
                    <a href="#" class="mobile-close visible-xs">
                        Collapse <i class="fa fa-chevron-right"></i>
                    </a>

                    <div class="sidebar-right-wrapper">

                        <?php
                        $getday = date('D');
                        if ($getday == "Mon") {
                            $getday = "M";
                            $getperiod = "MHr";
                        } elseif ($getday == "Tue") {
                            $getday = "T";
                            $getperiod = "THr";
                        } elseif ($getday == "Wed") {
                            $getday = "W";
                            $getperiod = "WHr";
                        } elseif ($getday == "Thu") {
                            $getday = "Th";
                            $getperiod = "ThHr";
                        } elseif ($getday == "Fri") {
                            $getday = "F";
                            $getperiod = "FHr";
                        } elseif ($getday == "Sat") {
                            $getday = "S";
                            $getperiod = "SHr";
                        }

                        $closemsg = 0;
                        $ccodearry = "";
                        $timearry = "";

                        ?>
                        <div class="sidebar-widget widget-friends">
                            <h5 style="color:#ffffff">Today's Lecture(s)</h5>
                            <ul>

                                <?php
                                $curtsession2 = str_replace("/", "_", $curtsession);
                                $sql2 = "SELECT * FROM courses_register_" . $curtsession2 . " WHERE Regn1 = '$myregid' AND SemTaken = '$cursemester'";
                                $result2 = $conn->query($sql2);
                                if ($result2->num_rows > 0) {
                                    while ($row2 = $result2->fetch_assoc()) {
                                        $CCode = $row2['CCode'];
                                        $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                if ($getday == "M" || $getday == "T" || $getday == "W" || $getday == "Th" || $getday == "F" || $getday == "S") {
                                                    $C_title = $row["C_title"];
                                                    $thetimearry = $row[$getday];
                                                    $theperiod = $row[$getperiod];
                                                    if (strlen($thetimearry) > 1) {

                                ?>
                                                        <li class="status-online">

                                                            <div class="profile-info">
                                                                <span class="name"><?php echo $CCode ?></span>
                                                                <span class="title"><?php echo $C_title ?></span>
                                                                <span class="title"><?php echo $thetimearry . "  " . $theperiod . "hr(s)" ?></span>
                                                            </div>
                                                        </li>
                                <?php
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                ?>
                            </ul>
                        </div>

                        <?php if ($_SESSION["showchat"] == 1) { ?>
                            <div class="sidebar-widget widget-friends" id="aside_chat">

                            </div>
                        <?php } ?>


                    </div>
                </div>
            </div>
        </aside>
    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>


    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>

    <!--Insert Chat-->
    <script>
        $(document).ready(function() {
            $("#sub_post").click(function() {
                var mychat = $("#mychat").val();

                $.ajax({
                    url: 'ajax_save_rec/chat_insert_stu.php',
                    method: 'POST',
                    data: {
                        mychat: mychat

                    },
                    success: function(data) {
                        alert(data);
                    }
                });
                document.getElementById("mychat").value = "";
            });
        });
    </script>

    <!--Fetch Chat-->
    <!--<script src="http://code.jquery.com/jquery-latest.js"></script>-->
    <script>
        (function($) {
            $(document).ready(function() {
                $.ajaxSetup({
                    cache: false,
                    beforeSend: function() {
                        $('#chat_body').hide();
                        $('#loading').show();
                    },
                    complete: function() {
                        $('#loading').hide();
                        $('#chat_body').show();
                    },
                    success: function() {
                        $('#loading').hide();
                        $('#chat_body').show();
                    }
                });
                var $container = $("#chat_body");
                $container.load("ajax_save_rec/chat_area_stu.php");
                var refreshId = setInterval(function() {
                    $container.load('ajax_save_rec/chat_area_stu.php');
                }, 9000);
            });
        })(jQuery);
    </script>

    <script>
        (function($) {
            $(document).ready(function() {
                $.ajaxSetup({
                    cache: false,
                    beforeSend: function() {
                        $('#aside_chat').hide();
                        $('#loading').show();
                    },
                    complete: function() {
                        $('#loading').hide();
                        $('#aside_chat').show();
                    },
                    success: function() {
                        $('#loading').hide();
                        $('#aside_chat').show();
                    }
                });
                var $container = $("#aside_chat");
                $container.load("ajax_save_rec/aside_chat_stu.php");
                var refreshId = setInterval(function() {
                    $container.load('ajax_save_rec/aside_chat_stu.php');
                }, 9000);
            });
        })(jQuery);
    </script>

    <script>
        (function($) {
            $(document).ready(function() {
                $.ajaxSetup({
                    cache: false,
                    beforeSend: function() {
                        $('#online_status').hide();
                        $('#loading').show();
                    },
                    complete: function() {
                        $('#loading').hide();
                        $('#online_status').show();
                    },
                    success: function() {
                        $('#loading').hide();
                        $('#online_status').show();
                    }
                });
                var $container = $("#online_status");
                $container.load("ajax_save_rec/load_online.php");
                var refreshId = setInterval(function() {
                    $container.load('ajax_save_rec/load_online.php');
                }, 9000);
            });
        })(jQuery);
    </script>

    <script>
        (function($) {
            $(document).ready(function() {
                $.ajaxSetup({
                    cache: false,
                    beforeSend: function() {
                        $('#quiz_counter2').hide();
                        $('#loading').show();
                    },
                    complete: function() {
                        $('#loading').hide();
                        $('#quiz_counter2').show();
                    },
                    success: function() {
                        $('#loading').hide();
                        $('#quiz_counter2').show();
                    }
                });
                var $container = $("#quiz_counter2");
                $container.load("ajax_save_rec/time_counter.php");
                var refreshId = setInterval(function() {
                    $container.load('ajax_save_rec/time_counter.php');
                }, 20000);
            });
        })(jQuery);
    </script>

</body>

</html>
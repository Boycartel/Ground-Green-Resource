<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_edit'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_D.js"> </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Graduation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Graduation
                            </li>

                            <li class="active">
                                <strong>Students Record</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students Record
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal bucket-form" method="post" action="">
                                <div class="row">
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-6 control-label">Session of Graduation:</label>
                                            <div class="col-sm-6">
                                                <select class="scale form-control m-bot15" name="sessiongrad"
                                                    required="required">
                                                    <option></option>
                                                    <?php
                                                    $finalyear = substr($_SESSION['resultsession'], 0, 4);
                                                    for ($x = 2018; $x <= $finalyear; $x++) {
                                                        $x2 = $x + 1;
                                                    ?>
                                                    <option><?php echo $x . "/" . $x2; ?></option>

                                                    <?php } ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Semester of Graduation: </label>
                                            <div class="col-sm-7">
                                                <select class="state form-control m-bot15" name="semester"
                                                    required="required">
                                                    <option></option>
                                                    <option value='1ST'>1ST</option>
                                                    <option value='2ND'>2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label"></label>
                                            <div class="col-sm-7">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </form>

                            <?php

                            if (isset($_POST["submit"])) {

                                $sessiongradpost = $_POST["sessiongrad"];
                                $semesterpost = $_POST["semester"];
                            ?>
                            <?php if ($_SESSION['InstType'] == "University") { ?>
                            <table id="myTable" style="font-size:12px" summary="" rules="groups" frame="hsides"
                                border="2" class="table mb-none">
                                <caption>Students List</caption>
                                <colgroup align="left"></colgroup>
                                <colgroup align="left"></colgroup>
                                <colgroup span="2"></colgroup>
                                <colgroup span="3" align="left"></colgroup>
                                <thead style='text-align:center'>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Department</th>
                                        <th>First Class</th>
                                        <th>Second Class Upper</th>
                                        <th>Second Class Lower</th>
                                        <th>Third Class</th>
                                        <th>Pass</th>
                                        <th>Total</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                            set_time_limit(5000);
                                            $sno = 0;
                                            $FirstClassTOT = $SecondUpperTOT = $SecondLowerTOT = $ThirdClassTOT = $PassClassTOT = 0;
                                            $DeptTotGrand = 0;

                                            $sql2 = "SELECT DeptCode, DeptName FROM deptcoding ORDER BY DeptName";
                                            //$sql2 = "SELECT DeptCode, DeptName FROM deptcoding WHERE DeptCode='MAT' ORDER BY DeptName";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $FirstClass = $SecondUpper = $SecondLower = $ThirdClass = $PassClass = 0;
                                                    $DeptTot = 0;
                                                    $sno++;
                                                    $DeptCode = $row2["DeptCode"];
                                                    $DeptName = $row2["DeptName"];

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($DeptCode);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    $sql3 = "SELECT * FROM scrutiny_senate WHERE session1 = '$sessiongradpost' AND semester = '$semesterpost' AND graduated = 'YES'";
                                                    $result3 = $conn_stu->query($sql3);
                                                    if ($result3->num_rows > 0) {
                                                        while ($row3 = $result3->fetch_assoc()) {
                                                            $Regn = $row3["Regn"];
                                                            $cgpa = $row3["CGPA"];
                                                            if ($cgpa >= 4.495) {
                                                                $FirstClass = $FirstClass + 1;
                                                                $FirstClassTOT = $FirstClassTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            } elseif ($cgpa >= 3.495) {
                                                                $SecondUpper = $SecondUpper + 1;
                                                                $SecondUpperTOT = $SecondUpperTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            } elseif ($cgpa >= 2.395) {
                                                                $SecondLower = $SecondLower + 1;
                                                                $SecondLowerTOT = $SecondLowerTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            } elseif ($cgpa >= 1.495) {
                                                                $ThirdClass = $ThirdClass + 1;
                                                                $ThirdClassTOT = $ThirdClassTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            } elseif ($cgpa >= 1) {
                                                                $PassClass = $PassClass + 1;
                                                                $PassClassTOT = $PassClassTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            }
                                                        }
                                                    }
                                                    $conn_stu->close();

                                                    echo "<tr><td>$sno</td><td>$DeptName</td><td>$FirstClass</td><td>$SecondUpper</td><td>$SecondLower</td><td>$ThirdClass</td><td>$PassClass</td><td>$DeptTot</td></tr>\n";
                                                }
                                            }
                                            echo "<tr><td></td><td>Total</td><td>$FirstClassTOT</td><td>$SecondUpperTOT</td><td>$SecondLowerTOT</td><td>$ThirdClassTOT</td><td>$PassClassTOT</td><td>$DeptTotGrand</td></tr>\n";
                                            ?>
                                </tbody>
                            </table>

                            <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                            <table id="myTable" style="font-size:12px" summary="" rules="groups" frame="hsides"
                                border="2" class="table mb-none">
                                <caption>Students List</caption>
                                <colgroup align="left"></colgroup>
                                <colgroup align="left"></colgroup>
                                <colgroup span="2"></colgroup>
                                <colgroup span="3" align="left"></colgroup>
                                <thead style='text-align:center'>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Department</th>
                                        <th>Distinction</th>
                                        <th>Upper Credit</th>
                                        <th>Lower Credit</th>
                                        <th>Pass</th>
                                        <th>Total</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                            set_time_limit(5000);
                                            $sno = 0;
                                            $FirstClassTOT = $SecondUpperTOT = $SecondLowerTOT = $ThirdClassTOT = $PassClassTOT = 0;
                                            $DeptTotGrand = 0;

                                            $sql2 = "SELECT DeptCode, DeptName FROM deptcoding ORDER BY DeptName";
                                            //$sql2 = "SELECT DeptCode, DeptName FROM deptcoding WHERE DeptCode='MAT' ORDER BY DeptName";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $FirstClass = $SecondUpper = $SecondLower = $ThirdClass = $PassClass = 0;
                                                    $DeptTot = 0;
                                                    $sno++;
                                                    $DeptCode = $row2["DeptCode"];
                                                    $DeptName = $row2["DeptName"];

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($DeptCode);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    $sql3 = "SELECT * FROM scrutiny_senate WHERE session1 = '$sessiongradpost' AND semester = '$semesterpost' AND graduated = 'YES'";
                                                    $result3 = $conn_stu->query($sql3);
                                                    if ($result3->num_rows > 0) {
                                                        while ($row3 = $result3->fetch_assoc()) {
                                                            $Regn = $row3["Regn"];
                                                            $cgpa = $row3["CGPA"];

                                                            if ($cgpa >= 3.5) {
                                                                $FirstClass = $FirstClass + 1;
                                                                $FirstClassTOT = $FirstClassTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            } elseif ($cgpa >= 3) {
                                                                $SecondUpper = $SecondUpper + 1;
                                                                $SecondUpperTOT = $SecondUpperTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            } elseif ($cgpa >= 2.5) {
                                                                $SecondLower = $SecondLower + 1;
                                                                $SecondLowerTOT = $SecondLowerTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            } elseif ($cgpa >= 2) {
                                                                $PassClass = $PassClass + 1;
                                                                $PassClassTOT = $PassClassTOT + 1;
                                                                $DeptTot++;
                                                                $DeptTotGrand++;
                                                            }
                                                        }
                                                    }
                                                    $conn_stu->close();
                                                    echo "<tr><td>$sno</td><td>$DeptName</td><td>$FirstClass</td><td>$SecondUpper</td><td>$SecondLower</td><td>$PassClass</td><td>$DeptTot</td></tr>\n";
                                                }
                                            }
                                            echo "<tr><td></td><td>Total</td><td>$FirstClassTOT</td><td>$SecondUpperTOT</td><td>$SecondLowerTOT</td><td>$PassClassTOT</td><td>$DeptTotGrand</td></tr>\n";
                                            ?>
                                </tbody>
                            </table>
                            <?php } ?>
                            <br><br>
                            <div class="form-group">
                                <!-- Buttons -->
                                <div class="col-lg-offset-2 col-lg-9" style="text-align: right;">
                                    <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                        class="btn btn-primary">Download</a>
                                </div>
                            </div>

                            <?php
                            }    //End Submit
                            ?>


                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <?php

    function addOrdinalNumberSuffix($num)
    {
        if (!in_array(($num % 100), array(11, 12, 13))) {
            switch ($num % 10) {
                    // Handle 1st, 2nd, 3rd
                case 1:
                    return $num . '<sup>st</sup>';
                case 2:
                    return $num . '<sup>nd</sup>';
                case 3:
                    return $num . '<sup>rd</sup>';
            }
        }
        return $num . '<sup>th</sup>';
    }

    ?>
</body>

</html>
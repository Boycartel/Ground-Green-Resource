<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['HOD'] !== "YES" && $_SESSION['Administrator'] !== "YES" && $_SESSION['Sub_Admin'] !== "YES") {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <!--Refresh page when active tab-->
    <script>
        document.addEventListener("visibilitychange", function() {
            if (document.hidden) {
                console.log("Browser tab is hidden")
            } else {
                console.log("Browser tab is visible")
                location.reload();
            }
        });
    </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Results and Profile Approval</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results and Profile Approval
                            </li>

                            <li class="active">
                                <strong>Semester Results</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Semester Results
                        </div>
                        <div class="panel-body">
                            <?php

                            $cursession = $_SESSION['resultsession'];
                            $resultsemester = $_SESSION['resultsemester'];
                            $dept = $_SESSION['deptcode'];
                            $staffid = $_SESSION['staffid'];
                            //$_SESSION['CCode'] = "XXX";
                            ?>
                            <div style="text-align: center">
                                <h3>Session :- <?php echo $cursession ?></h3>
                                <h3>Semester :- <?php echo $resultsemester ?></h3>
                            </div>
                            <div class="row" style="padding-left: 3em">
                                <table class="table table-bordered table-striped mb-none">
                                    <thead style='text-align:center'>
                                        <tr>
                                            <th>Level </th>
                                            <th>Approval</th>
                                            <th>Action</th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $dbsession = str_replace("/", "_", $cursession);
                                        $sql = "SELECT * FROM hod_semester_res_approval WHERE deptCode = '$dept' AND  session_apprv = '$cursession' AND  semester_apprv = '$resultsemester' ORDER BY Level_Apprv";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $id = $row["sn"];
                                                $Level_Apprv = $row["Level_Apprv"];
                                                if ($_SESSION['InstType'] == "Polytechnic") {
                                                    if ($Level_Apprv == 100) {
                                                        $Level_Apprv = "ND I";
                                                    } elseif ($Level_Apprv == 200) {
                                                        $Level_Apprv = "ND II";
                                                    } elseif ($Level_Apprv == 300) {
                                                        $Level_Apprv = "HND I";
                                                    } elseif ($Level_Apprv == 400) {
                                                        $Level_Apprv = "HND II";
                                                    }
                                                }
                                                $approval = $row["Approval"];


                                                echo "<tr>";
                                                echo "<td>$Level_Apprv </td><td>$approval</td>";
                                                echo "<td>";
                                                echo "<form class='form-horizontal form-bordered' method='post' action='semester_res_approval_view.php'>";
                                                echo "<input type='hidden' value='$id' name='id'>";
                                                echo "<input type='submit' name='view' class='btn btn-success btn-xs' value='View'>";
                                                echo "</form>";
                                                echo "</td>";
                                                echo "</tr>";
                                            }
                                        }
                                        $conn->close();

                                        ?>
                                    </tbody>
                                </table>
                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['board_format'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?>, Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword" content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>


    <style>
        .btn-xs,
        .btn-group-xs>.btn {
            padding: 1px 5px;
            font-size: 12px;
            line-height: 1.5;
            border-radius: 3px;
        }
    </style>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">
        <?php
        if (isset($_POST["submit_sel"])) {
            $_SESSION['apprFormat'] = $_POST["apprFormat"];
            $_SESSION['semesterSel'] = $_POST["semesterSel"];
        }
        ?>
        <!-- start: page -->


        <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
            <form class="form-horizontal form-bordered" method="post">
                <div class="row">
                    <?php
                    if ($_SESSION['InstType'] == "University") {
                        if ($_SESSION['apprFormat'] == "SchBoard") {
                            $TheFormat = "Faculty Board";
                        } elseif ($_SESSION['apprFormat'] == "Scrutiny") {
                            $TheFormat = "Senate Business Committee";
                        } else {
                            $TheFormat = "Senate";
                        }
                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                        if ($_SESSION['apprFormat'] == "SchBoard") {
                            $TheFormat = "School Board";
                        } elseif ($_SESSION['apprFormat'] == "Scrutiny") {
                            $TheFormat = "Examination Results Board";
                        } else {
                            $TheFormat = "Senate";
                        }
                    }

                    ?>
                    <h2 class="panel-title" style="text-align: center">Graduating Spreadsheet(<?php echo $TheFormat ?>)
                    </h2>
                    <br><br><br>
                    <div class="col-lg-3">
                        <div class="row">
                            <label class="control-label col-lg-5" for="content">Select Department:</label>
                            <div class="col-lg-7">
                                <select class="country form-control" style="color:#000000" name="dept">
                                    <option value="SelectItem">Select Item</option>
                                    <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $dept = $_SESSION['deptcode'];

                                    if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                    } else {
                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                    }


                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $deptcode2 = strtolower($row["DeptCode"]);
                                            $deptname2 = $row["DeptName"];
                                            echo "<option value=$deptcode2>$deptname2</option>";
                                        }
                                    }
                                    $conn->close();
                                    ?>

                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="row">
                            <label class="control-label col-lg-5" for="regid">Year of Graduation:</label>
                            <div class="col-lg-7">
                                <?php
                                $iniyear = 2015;
                                $finalyear = substr($_SESSION['corntsession'], 5) + 2;

                                ?>
                                <select name="getyeargrad" class="form-control" style="color:#000000" id="getyeargrad">
                                    <option value="<?php echo $finalyear ?>"><?php echo $finalyear ?></option>
                                    <?php
                                    while ($iniyear <= $finalyear) {
                                        $addyear = $iniyear + 1;

                                        echo "<option value = '$iniyear'>$iniyear</option>";
                                        $iniyear++;
                                    }

                                    ?>


                                </select>
                            </div>
                        </div>
                    </div>
                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                        <div class="col-lg-2">
                            <div class="row">
                                <label class="control-label col-lg-5" for="regid">Programme:</label>
                                <div class="col-lg-7">

                                    <select name="getprogram" class="form-control" style="color:#000000" id="getprogram" required>
                                        <option value="">Select Item</option>
                                        <option value="ND">ND</option>
                                        <option value="HND">HND</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="col-lg-2">
                        <div class="row">
                            <label class="control-label col-lg-12" for="content">Semester:
                                <?php echo $_SESSION['semesterSel'] ?></label>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="row">

                            <div class="col-lg-4">
                                <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                            </div>
                        </div>
                    </div>
                </div>


            </form>
        </div>
        <hr class="separator" />

        <div style="padding-left:3em; padding-right: 3em;">


            <?php
            if (isset($_POST["submit"])) {
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $_SESSION['dept_sctny'] = $_POST["dept"];
                $_SESSION['getyeargrad'] = $_POST["getyeargrad"];
                if ($_SESSION['InstType'] == "Polytechnic") {
                    $_SESSION['getprogram'] = $_POST["getprogram"];
                    if ($_SESSION['getprogram'] == "ND") {
                        $prog = "National Diploma";
                    } elseif ($_SESSION['getprogram'] == "HND") {
                        $prog = "Higher National Diploma";
                    }
                }
                $_SESSION['sn'] = 0;

                $deptname = "";

                $getdept = $_SESSION['dept_sctny'];
                $getyeargrad = $_SESSION['getyeargrad'];
                $getsemester = $_SESSION['semesterSel'];
                $deptoption = $_SESSION['deptoption'];
                $deptname = $_SESSION["deptname"];
                $schcode = $_SESSION['schcode'];
                if ($_SESSION['InstType'] == "Polytechnic") {
                    $getprogram = $_SESSION['getprogram'];
                }
                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND (cat = 'HOD' OR cat = 'HODLAdvice' OR cat = 'HODDean' OR cat = 'PGHOD')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["HOD_Sign"] = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE SchCode = '$schcode' AND (cat = 'Dean' OR cat = 'HODDean' OR cat = 'PGExam')";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $_SESSION["Dean_Sign"] = $row["full_name"];
                    }
                }
                $conn->close();
            }





            ?>
            <?php if (isset($_POST["submit"])) { ?>
                <section class="panel panel-success">
                    <header class="panel-heading">
                        <div class="panel-actions">
                            <a href="#" class="fa fa-caret-down"></a>
                            <a href="#" class="fa fa-times"></a>
                        </div>


                    </header>
                    <div class="panel-body">

                        <div class="row">
                            <div class="col-lg-3">
                                <h5 class="panel-title">Department: <?php echo $deptname; ?></h5>
                            </div>
                            <div class="col-lg-3">
                                <h5 class="panel-title">Year of Graduation: <?php echo $_SESSION['getyeargrad']; ?></h5>
                            </div>
                            <div class="col-lg-3">
                                <h5 class="panel-title">Semester: <?php echo $getsemester; ?></h5>
                            </div>
                            <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                <div class="col-lg-3">
                                    <h5 class="panel-title">Programme: <?php echo $prog; ?></h5>
                                </div>
                            <?php } ?>
                        </div>
                        <hr class="separator" />
                        <br>

                        <div class="col-lg-12">

                            <table class="table table-striped table-bordered table-hover dataTables-example">
                                <thead style='text-align:center'>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Matric No</th>
                                        <th>Name</th>
                                        <th>CGPA</th>
                                        <th>Class of Degree</th>
                                        <?php if ($deptoption == "YES") { ?>
                                            <th>Department Option</th>
                                        <?php } ?>
                                        <th>Action</th>
                                        <th>Approval</th>
                                        <th>Comment</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                    if ($conn2->connect_error) {
                                        die("Connection failed: " . $conn2->connect_error);
                                    }

                                    //$getprogram = "ND";
                                    $ccgpa = 0;
                                    $classdegree = "";
                                    $sno = 0;
                                    $classdegree_code = 0;
                                    $NON_DE_Senate = false;
                                    $DE200Senate = false;
                                    $DE300Senate = false;
                                    $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;

                                    unset($corecoursearray);
                                    $corecoursearray[] = "";

                                    unset($groupCodearray);
                                    $groupCodearray[] = "";
                                    $groupCodecount = 0;
                                    //include 'modulesInSess/SubProcessResults.php';
                                    $optCount = 0;
                                    $deptgencourses = $getdept . "_gencourses";

                                    unset($regcoursesarray);
                                    $regcoursesarray[] = "";
                                    $countcoursesarray = 0;
                                    //$dept_scrutiny_senate = $getdept . "_scrutiny_senate";
                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                    if ($_SESSION['apprFormat'] == "SchBoard") {
                                        $sql = "UPDATE scrutiny_senate SET classdegree = 'XX', classdegree_code = '0' WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester'";
                                        $result = $conn_stu->query($sql);
                                    }

                                    if ($_SESSION['InstType'] == "University") {
                                        if ($_SESSION['apprFormat'] == "SchBoard") {
                                            if ($getsemester == "1ST") {
                                                $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester' AND grad_1st_sel = 'YES' AND graduated = 'NO' ORDER BY CGPA_grad_1st DESC";
                                            } else {
                                                $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester' AND def_out = '' AND graduated = 'NO' ORDER BY CGPA DESC";
                                            }
                                        } elseif ($_SESSION['apprFormat'] == "Scrutiny") {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester' AND grad_board_aproval = 'Approve' ORDER BY CGPA DESC";
                                        } else {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester' AND grad_secrutiny_aproval = 'Approve' ORDER BY CGPA DESC";
                                        }
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        if ($_SESSION['apprFormat'] == "SchBoard") {
                                            if ($getsemester == "1ST") {
                                                $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND mode_entry = '$getprogram' AND semester = '$getsemester' AND grad_1st_sel = 'YES' AND graduated = 'NO' ORDER BY CGPA_grad_1st DESC";
                                            } else {
                                                $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND mode_entry = '$getprogram' AND semester = '$getsemester' AND def_out = '' AND graduated = 'NO' ORDER BY CGPA DESC";
                                            }
                                        } elseif ($_SESSION['apprFormat'] == "Scrutiny") {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND mode_entry = '$getprogram' AND semester = '$getsemester' AND grad_board_aproval = 'Approve' ORDER BY CGPA DESC";
                                        } else {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND mode_entry = '$getprogram' AND semester = '$getsemester' AND grad_secrutiny_aproval = 'Approve' ORDER BY CGPA DESC";
                                        }
                                    }

                                    //$sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester' AND graduated = 'NO' ORDER BY CGPA DESC";
                                    $result = $conn_stu->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $id = $row["sn"];
                                            $regid = $row["Regn"];
                                            $names = $row["Name1"];
                                            if ($getsemester == "1ST") {
                                                $ccgpa = $row['CGPA_grad_1st'];
                                            } else {
                                                $ccgpa = $row['CGPA'];
                                            }
                                            $cgpa = $ccgpa;
                                            $NON_DE_Senate = false;
                                            $DE200Senate = false;
                                            $DE300Senate = false;

                                            if (empty($row["DeptOpt"])) {
                                                $Deptopt2 = "";
                                            } else {
                                                $Deptopt2 = $row["DeptOpt"];
                                            }

                                            $deptcorreg = $getdept . "_correg";
                                            $deptgencourses = $getdept . "_gencourses";

                                            include 'modulesInSess/classofdegree_inc.php';
                                            /*  if ($ccgpa >= 4.495) {
                                                $classdegree = "First Class";
                                                $classdegree_code = 1;
                                            } elseif ($ccgpa >= 3.495) {
                                                $classdegree = "Second Class Upper";
                                                $classdegree_code = 2;
                                            } elseif ($ccgpa >= 2.395) {
                                                $classdegree = "Second Class Lower";
                                                $classdegree_code = 3;
                                            } elseif ($ccgpa >= 1.495) {
                                                $classdegree = "Third Class";
                                                $classdegree_code = 4;
                                            } else {
                                                $classdegree = "Pass";
                                                $classdegree_code = 5;
                                            } */


                                            $sql2 = "UPDATE scrutiny_senate SET classdegree = '$classdegree', classdegree_code = '$classdegree_code' WHERE sn = '$id'";
                                            $result2 = $conn_stu->query($sql2);
                                        }
                                    }

                                    unset($gradstuReg);
                                    $gradstuReg[] = "";
                                    unset($gradStuName);
                                    $gradStuName[] = "";
                                    unset($gradStuCGPA);
                                    $gradStuCGPA[] = 0;
                                    unset($gradStuDOpt);
                                    $gradStuDOpt[] = "";
                                    unset($snoArray);
                                    $snoArray[] = 0;
                                    //unset($arryclassdegree);
                                    //$arryclassdegree[] = "";

                                    $sno = 0;
                                    if ($_SESSION['InstType'] == "University") {
                                        if ($_SESSION['apprFormat'] == "SchBoard") {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester' AND classdegree_code <> '0' AND graduated = 'NO' ORDER BY classdegree_code, Name1";
                                        } elseif ($_SESSION['apprFormat'] == "Scrutiny") {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester' AND grad_board_aproval = 'Approve' ORDER BY classdegree_code, Name1";
                                        } else {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$getsemester' AND grad_secrutiny_aproval = 'Approve' ORDER BY classdegree_code, Name1";
                                        }
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        if ($_SESSION['apprFormat'] == "SchBoard") {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND mode_entry = '$getprogram' AND semester = '$getsemester' AND classdegree_code <> '0' AND graduated = 'NO' ORDER BY classdegree_code, Name1";
                                        } elseif ($_SESSION['apprFormat'] == "Scrutiny") {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND mode_entry = '$getprogram' AND semester = '$getsemester' AND grad_board_aproval = 'Approve' ORDER BY classdegree_code, Name1";
                                        } else {
                                            $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND mode_entry = '$getprogram' AND semester = '$getsemester' AND grad_secrutiny_aproval = 'Approve' ORDER BY classdegree_code, Name1";
                                        }
                                    }

                                    $result = $conn_stu->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $sno++;
                                            $NON_DE_Senate = false;
                                            $DE200Senate = false;
                                            $DE300Senate = false;

                                            $regid = $row["Regn"];
                                            if (empty($row["DeptOpt"])) {
                                                $Deptopt2 = "";
                                            } else {
                                                $Deptopt2 = $row["DeptOpt"];
                                            }
                                            $names = $row["Name1"];
                                            if ($getsemester == "1ST") {
                                                $ccgpa = $row['CGPA_grad_1st'];
                                            } else {
                                                $ccgpa = $row['CGPA'];
                                            }
                                            //$ccgpa=$row['CGPA'];
                                            $classdegree = $row['classdegree'];

                                            $id = $row["sn"];
                                            //$aproval=$row['board_aproval'];
                                            //$coment = $row["board_comment"];
                                            $def_out = $row["def_out"];
                                            $ccgpa = number_format($ccgpa, 2);
                                            echo "<tr><td>$sno</td><td>$regid</td><td>$names</td><td>$ccgpa</td><td>$classdegree</td>";
                                            if ($deptoption == "YES") {
                                                echo "<td>$Deptopt2</td>";
                                            }

                                            echo "<td>
                                            <form action='spreadsheet_grad_view.php' method='post' target='_blank'>
                                                <input type='hidden' value='$regid' name='id'>
                                                
                                                <input type='submit' name='view' class='btn btn-info btn-xs' value='View'>
                                            </form>
                                            </td>";
                                            if ($_SESSION['apprFormat'] == "SchBoard") {
                                                if ($row["grad_secrutiny_aproval"] == 'Approve') {
                                                    echo "<td></td><td></td>";
                                                } else {
                                                    echo '<td><a href="#" class="grad_aproval" id="grad_board_aproval_' . $row["sn"] . '" data-type="select" data-pk="' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="grad_board_aproval">' . $row["grad_board_aproval"] . '</a></td>
                                                    <td><a href="#" class="grad_comment" id="grad_board_comment_' . $row["sn"] . '" data-type="text" data-pk = "' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="grad_board_comment">' . $row["grad_board_comment"] . '</a></td>';
                                                }
                                            } elseif ($_SESSION['apprFormat'] == "Scrutiny") {
                                                if ($row["grad_senate_aproval"] == 'Approve') {
                                                    echo "<td></td><td></td>";
                                                } else {
                                                    echo '<td><a href="#" class="grad_aproval" id="grad_secrutiny_aproval_' . $row["sn"] . '" data-type="select" data-pk="' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="grad_secrutiny_aproval">' . $row["grad_secrutiny_aproval"] . '</a></td>
                                                    <td><a href="#" class="grad_comment" id="grad_secrutiny_comment_' . $row["sn"] . '" data-type="text" data-pk = "' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="grad_secrutiny_comment">' . $row["grad_secrutiny_comment"] . '</a></td>';
                                                }
                                            } else {
                                                echo '<td><a href="#" class="grad_aproval" id="grad_senate_aproval_' . $row["sn"] . '" data-type="select" data-pk="' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="grad_senate_aproval">' . $row["grad_senate_aproval"] . '</a></td>
                                                <td><a href="#" class="grad_comment" id="grad_senate_comment_' . $row["sn"] . '" data-type="text" data-pk = "' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="grad_senate_comment">' . $row["grad_senate_comment"] . '</a></td>';
                                            }
                                            //echo "<td>$def_out</td>";

                                            echo "</tr>\n";
                                            $gradstuReg[$sno] = $regid;
                                            $gradStuName[$sno] = $names;
                                            $snoArray[$sno] = $sno;
                                            $gradStuCGPA[$sno] = $ccgpa;
                                            $gradStuDOpt[$sno] = $Deptopt2;
                                            //$arryclassdegree[$sno] = $classdegree;
                                        }
                                    }
                                    $conn->close();
                                    $conn2->close();
                                    $conn_stu->close();

                                    $_SESSION["sno"] = $sno;
                                    $_SESSION["gradstuReg"] = $gradstuReg;
                                    $_SESSION["gradStuName"] = $gradStuName;
                                    $_SESSION["snoArray"] = $snoArray;
                                    $_SESSION["gradStuCGPA"] = $gradStuCGPA;
                                    $_SESSION["gradStuDOpt"] = $gradStuDOpt;
                                    //$_SESSION["arryclassdegree"] = $arryclassdegree;
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <br><br>
                        <div class="row">
                            <div class="col-lg-6">

                            </div>
                            <div class="col-lg-2" style="text-align: right">
                                <form action='spreadsheet_grad_view_all.php' method='post' target='_blank'>
                                    <input type='submit' name='view_all' class='btn btn-info btn-sm' value='View All'>

                                </form>
                            </div>
                            <div class="col-lg-2" style="text-align: right">
                                <form action='print_summary_grad_2.php' method='post' target='_blank'>
                                    <input type='submit' name='print_suma' class='btn btn-outline-success btn-sm' value='Print Summary Page'>
                                </form>
                            </div>
                            <div class="col-lg-2" style="text-align: right">
                                <form action='spreadsheet_grad_print_all.php' method='post' target='_blank'>
                                    <input type='submit' name='print_all' class='btn btn-primary btn-sm' value='Print All Results'>

                                </form>
                            </div>

                        </div>

                    </div>

                    <br><br><br>
                </section>
            <?php } ?>

        </div>
        <!-- end: page -->
    </section>


    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>


    <script>
        //For Comment Table Column Data

        const grad_comment = document.getElementsByClassName('grad_comment');

        for (var count = 0; count < grad_comment.length; count++) {
            const grad_comment_data = document.getElementById(grad_comment[count].getAttribute('id'));

            const grad_comment_popover = new DarkEditable(grad_comment_data);
        }


        //For Approval Table column Data

        const grad_aproval = document.getElementsByClassName('grad_aproval');

        for (var count = 0; count < grad_aproval.length; count++) {
            const grad_aproval_data = document.getElementById(grad_aproval[count].getAttribute("id"));

            const grad_aproval_popover = new DarkEditable(grad_aproval_data, {
                source: [{
                        value: 'Yet',
                        text: 'Yet'
                    },
                    {
                        value: 'Approve',
                        text: 'Approve'
                    },
                    {
                        value: 'Not Approve',
                        text: 'Not Approve'
                    }
                ]
            });
        }
    </script>


</body>

</html>
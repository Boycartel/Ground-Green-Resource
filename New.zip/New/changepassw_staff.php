<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Change Password</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Change Password</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Change Password
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-3">

                            </div>
                            <div class="col-lg-6">
                                <ul>

                                    <li>Passwords must be at least 6 characters long</li>
                                    <li>Your password and confirmation must match exactly</li>
                                </ul>
                                <br />
                                <?php
                                $staffid = $_SESSION['staffid'];
                                if (isset($_POST["submit"])) {
                                    $password = $_POST["password"];
                                    $confirmpassword = $_POST["confirmpwd"];
                                    $password_not = $_POST["password"];
                                    $password = stripslashes($password);
                                    $password = mysqli_real_escape_string($conn, $password);

                                    $confirmpassword = stripslashes($confirmpassword);
                                    $confirmpassword = mysqli_real_escape_string($conn, $confirmpassword);

                                    if (strlen($password) >= 6) {
                                        if ($password == $confirmpassword) {
                                            $password = md5($password);

                                            //$sql = "UPDATE users SET password2='$password' WHERE staffid='$staffid'";
                                            //$result = $conn->query($sql);

                                            $sql = "UPDATE users SET password2='$password', password3='$password_not' WHERE staffid='$staffid'";
                                            $result = $conn->query($sql);

                                            echo "<h3 style='color:blue'>Password saved successfully</h3>";
                                        } else {
                                            echo "<h3 style='color: red'>Error: Password and confirmation must match exactly</h3>";
                                        }
                                    } else {
                                        echo "<h3 style='color: red'>Error: Passwords must be at least 6 characters long</h3>";
                                    }
                                }
                                ?>
                                <form class="form-horizontal" role="form" method="post" action="">

                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">New Password</label>
                                        <div class="col-lg-8">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-lock"></i></span>

                                                <input type="password" name="password" id="password"
                                                    class="form-control" placeholder="New Password">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Confirm Password</label>
                                        <div class="col-lg-8">
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-lock"></i></i></span>
                                                <input type="password" name="confirmpwd" id="confirmpwd"
                                                    class="form-control" placeholder="Confirm Password">
                                            </div>
                                            <br />

                                            <button type="submit" name="submit"
                                                class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                    </div>


                                </form>

                            </div>
                            <div class="col-lg-3">

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['submited_results'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Submited Result(s)</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Submited Result(s)</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Submited Result(s)
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-3" for="content">Select
                                                Department:</label>
                                            <div class="col-lg-8">
                                                <select class="country form-control" style="color:#000000" name="dept">
                                                    <option value="SelectItem">Select Item</option>
                                                    <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

   
                                                    $dept = $_SESSION['deptcode'];
                                                    $schcode = $_SESSION['schcode'];

                                                    if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                    } elseif ($cat_Dean == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE School = '$schcode'";
                                                    } else {
                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    }

                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = strtolower($row["DeptCode"]);
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }
                                                    $conn->close();
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-3" for="regid">Session:</label>
                                            <div class="col-lg-8">
                                                <?php
                                                $iniyear = 2015;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="getsession" class="form-control" style="color:#000000"
                                                    id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>


                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-3" for="regid">Semester:</label>
                                            <div class="col-lg-4">
                                                <select name="getsemester" class="form-control" style="color:#000000"
                                                    id="getsemester">
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>

                                                </select>
                                            </div>
                                            <div class="col-lg-5">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <hr class="separator" />
                            <?php
                            if (isset($_POST["submit"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                set_time_limit(500);
                                $dept = $_POST['dept'];
                                $getsession = $_POST['getsession'];
                                $getsemtaken = $_POST['getsemester'];
                                $courseRegSplitSess = $_SESSION['courseRegSplitSess'];

                                $sql = "SELECT DeptName, DeptCode FROM deptcoding WHERE DeptCode = '$dept'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $deptname = $row["DeptName"];
                                    }
                                }

                            ?>
                            <div class="row" style="font-size: 16px">
                                <div class="col-lg-4">
                                    Department: <?php echo $deptname; ?>
                                </div>
                                <div class="col-lg-4">
                                    Session: <?php echo $getsession; ?>
                                </div>
                                <div class="col-lg-4">
                                    Semester: <?php echo $getsemtaken; ?>
                                </div>

                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php
                                    $sno = 0;
                                    $sql = "SELECT * FROM gencoursesupload WHERE Department = '$dept' AND  semester = '$getsemtaken' ORDER BY C_codding";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                    ?>
                                <table class="table table-bordered table-striped mb-none" id="datatable-default">
                                    <thead>
                                        <tr>
                                            <th>S/No</th>
                                            <th>Course Code</th>
                                            <th>Course Title</th>
                                            <th>No. Reg. Students</th>
                                            <th>Submited Results</th>
                                            <th>Staff Name & Phone No.</th>
                                            <th>email</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>


                                        <?php
                                                while ($row = $result->fetch_assoc()) {
                                                    $id = $row["id"];
                                                    $ccode = $row['C_codding'];
                                                    $ctitle = $row['C_title'];

                                                    $email = "";
                                                    $phone = "";
                                                    $staffname = "";
                                                    $sql3 = "SELECT * FROM coursealocation WHERE CCode = '$ccode' AND SessionReg = '$getsession'";
                                                    $result3 = $conn->query($sql3);
                                                    if ($result3->num_rows > 0) {
                                                        while ($row3 = $result3->fetch_assoc()) {
                                                            $pfno = $row3['PFNo'];
                                                            $sql2 = "SELECT * FROM users WHERE staffid = '$pfno'";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $email = $email . $row2['emailAdd'] . "<br>";
                                                                    //$phone = $phone.$row2['phone'].", ";
                                                                    $staffname = $staffname . $row2['full_name'] . "(" . $row2['phone'] . ")<br> ";
                                                                }
                                                            }
                                                        }
                                                    }

                                                    $dbsession = str_replace("/", "_", $getsession);
                                                    if ($getsession < $courseRegSplitSess) {
                                                        $sql2 = "SELECT * FROM courses_register WHERE CCode = '$ccode' AND session = '$getsession'";
                                                    } else {
                                                        $sql2 = "SELECT * FROM courses_register_" . $dbsession . " WHERE CCode = '$ccode'";
                                                    }

                                                    $result2 = $conn->query($sql2);
                                                    $countstu = mysqli_num_rows($result2);

                                                    if ($countstu !== 0) {
                                                        $sno++;
                                                        $countnoresult = 0;
                                                        $sql2 = "SELECT * FROM raw_results_" . $dbsession . " WHERE CCode = '$ccode'";
                                                        //$sql2 = "SELECT * FROM ".$dept."_raw_correg WHERE CCode = '$ccode' AND SessionRegis = '$getsession'";
                                                        $result2 = $conn->query($sql2);
                                                        $countnoresult = mysqli_num_rows($result2);
                                                        //$countnoresult = $countstu;

                                                        echo "<tr><td>$sno</td><td>$ccode</td><td>$ctitle</td><td>{$countstu}</td><td>$countnoresult</td><td>$staffname </td><td>{$email}</td>";
                                                        if ($countnoresult == 0) {
                                                            echo "<td>
                                                
												</td></tr>\n";
                                                        } else {
                                                            echo "<td>
												 <form action='download_stu_result.php' method='post'>
													  <input type='hidden' value=$ccode name='course'>
													  <input type='hidden' value=$getsession name='getsession'>
													  <input type='submit' name='postresult' class='btn btn-primary btn-xs' value='Download'>
												 </form>
												
												</td></tr>\n";
                                                        }
                                                    }
                                                }
                                                ?>
                                    </tbody>
                                </table>

                                <?php

                                    }

                                    ?>

                            </div>
                            <?php
$conn->close();
$conn2->close();
                                ?>
                            <?php } ?>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['deptoption'] == "NO") {
    header('Location: home_staff.php');
}
if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">


    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Setup Courses</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Settings
                            </li>

                            <li class="active">
                                <strong>Setup Courses</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Setup Courses
                        </div>
                        <div class="panel-body">
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            unset($deptoptionCode);
                            unset($deptoptionTitle);
                            $deptoptCount = 0;
                            $dept = $_SESSION['deptcode'];
                            $deptoption = $_SESSION['deptoption'];
                            $deptname = $_SESSION["deptname"];
                            $schcode = $_SESSION['schcode'];
                            $DegType = $_SESSION['DegType'];
                            $yesCurri = "NO";



                            $sql = "SELECT * FROM deptcoding  WHERE DeptCode = '$dept'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $yesCurri = $row["curriculum"];
                                }
                            }

                            $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept' ORDER BY Opt_Code";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $deptoptCount++;
                                    $deptoptionCode[$deptoptCount] = $row["Opt_Code"];
                                    $deptoptionTitle[$deptoptCount] = $row["Opt_Title"];
                                }
                            }
                            $conn->close();

                            if (isset($_POST["submit"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                $id = $_POST["id"];
                                $getSemester = $_POST["getSemester"];
                                $getNature = $_POST["getNature"];
                                $getlevel = $_POST["getlevel"];
                                $CUnit = $_POST["CUnit"];

                                if ($yesCurri == "YES") {
                                    //$currisub = $_POST["curri2"];
                                    $curri = strtolower($_SESSION['curri']);
                                    if ($curri == "OLD") {
                                        $curri2 = "";
                                    } else {
                                        $curri2 = "_" . $curri;
                                    }
                                    $sql2 = "UPDATE gencourses" . $curri2 . " SET semester ='$getSemester', Nature1 ='$getNature', Level1 = '$getlevel', credit = '$CUnit' WHERE id = '$id'";
                                    $result2 = $conn_stu->query($sql2);
                                    for ($i = 1; $i <= $deptoptCount; $i++) {
                                        $Relevant = $_POST[$deptoptionCode[$i]];
                                        $CoreUME = $_POST["Core_" . $deptoptionCode[$i]];
                                        if ($_SESSION['InstType'] == "University") {
                                            $CoreDE200 = $_POST["CoreDE200_" . $deptoptionCode[$i]];
                                            $CoreDE300 = $_POST["CoreDE300_" . $deptoptionCode[$i]];

                                            $sql2 = "UPDATE gencourses" . $curri2 . " SET " . $deptoptionCode[$i] . " ='$Relevant', Core_" . $deptoptionCode[$i] . " ='$CoreUME', CoreDE200_" . $deptoptionCode[$i] . " ='$CoreDE200', CoreDE300_" . $deptoptionCode[$i] . " ='$CoreDE300' WHERE id = '$id'";
                                            $result2 = $conn_stu->query($sql2);

                                            if ($CoreUME == "YES" || $CoreDE200 == "YES" || $CoreDE300 == "YES") {
                                                $sql2 = "UPDATE gencourses" . $curri2 . " SET " . $deptoptionCode[$i] . " ='YES' WHERE id = '$id'";
                                                $result2 = $conn_stu->query($sql2);
                                            }
                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                            $sql2 = "UPDATE gencourses" . $curri2 . " SET " . $deptoptionCode[$i] . " ='$Relevant', Core_" . $deptoptionCode[$i] . " ='$CoreUME' WHERE id = '$id'";
                                            $result2 = $conn_stu->query($sql2);

                                            if ($CoreUME == "YES") {
                                                $sql2 = "UPDATE gencourses" . $curri2 . " SET " . $deptoptionCode[$i] . " ='YES' WHERE id = '$id'";
                                                $result2 = $conn_stu->query($sql2);
                                            }
                                        }
                                    }
                                    if ($_SESSION['InstType'] == "University") {
                                        if ($DegType == "BEng") {
                                            $Ten88 = $_POST["Ten88"];
                                            $sql2 = "UPDATE gencourses" . $curri2 . " SET Ten88 ='$Ten88' WHERE id = '$id'";
                                            $result2 = $conn_stu->query($sql2);
                                        }
                                    }
                                } else {
                                    $sql2 = "UPDATE gencourses SET semester ='$getSemester', Nature1 ='$getNature', Level1 = '$getlevel', credit = '$CUnit' WHERE id = '$id'";
                                    $result2 = $conn_stu->query($sql2);
                                    for ($i = 1; $i <= $deptoptCount; $i++) {
                                        $Relevant = $_POST[$deptoptionCode[$i]];
                                        $CoreUME = $_POST["Core_" . $deptoptionCode[$i]];
                                        if ($_SESSION['InstType'] == "University") {
                                            $CoreDE200 = $_POST["CoreDE200_" . $deptoptionCode[$i]];
                                            $CoreDE300 = $_POST["CoreDE300_" . $deptoptionCode[$i]];

                                            $sql2 = "UPDATE gencourses SET " . $deptoptionCode[$i] . " ='$Relevant', Core_" . $deptoptionCode[$i] . " ='$CoreUME', CoreDE200_" . $deptoptionCode[$i] . " ='$CoreDE200', CoreDE300_" . $deptoptionCode[$i] . " ='$CoreDE300' WHERE id = '$id'";
                                            $result2 = $conn_stu->query($sql2);

                                            if ($CoreUME == "YES" || $CoreDE200 == "YES" || $CoreDE300 == "YES") {
                                                $sql2 = "UPDATE gencourses SET " . $deptoptionCode[$i] . " ='YES' WHERE id = '$id'";
                                                $result2 = $conn_stu->query($sql2);
                                            }
                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                            $sql2 = "UPDATE gencourses SET " . $deptoptionCode[$i] . " ='$Relevant', Core_" . $deptoptionCode[$i] . " ='$CoreUME' WHERE id = '$id'";
                                            $result2 = $conn_stu->query($sql2);

                                            if ($CoreUME == "YES") {
                                                $sql2 = "UPDATE gencourses SET " . $deptoptionCode[$i] . " ='YES' WHERE id = '$id'";
                                                $result2 = $conn_stu->query($sql2);
                                            }
                                        }
                                    }
                                    if ($_SESSION['InstType'] == "University") {
                                        if ($DegType == "BEng") {
                                            $Ten88 = $_POST["Ten88"];
                                            $sql2 = "UPDATE gencourses SET Ten88 ='$Ten88' WHERE id = '$id'";
                                            $result2 = $conn_stu->query($sql2);
                                        }
                                    }
                                }
                                $conn->close();
                                $conn_stu->close();
                            }
                            ?>

                            <!-- start: page -->

                            <div class="row">
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                ?>
                                <?php if ($yesCurri == "YES") { ?>

                                <?php if (isset($_POST["submitcurri"]) || isset($_POST["view"]) || isset($_POST["submit"])) { ?>
                                <?php
                                        if (isset($_POST["submitcurri"])) {
                                            $curri = strtolower($_POST["curri"]);
                                            $_SESSION['curri'] = $curri;
                                        } else {
                                            $curri = $_SESSION['curri'];
                                        }



                                        if ($curri == "OLD") {
                                            $curri2 = "";
                                        } else {
                                            $curri2 = "_" . $curri;
                                        }
                                        $sql = "SELECT * FROM dept_curriculum WHERE curri_Code = '$curri' AND deptcode = '$dept'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $curriname2 = $row["curri_Title"];
                                            }
                                        }
                                        ?>

                                <h2><?php echo $curriname2 ?></h2>
                                <table>

                                    <tbody>
                                        <?php
                                                for ($i = 1; $i <= $deptoptCount; $i++) {
                                                    echo "<tr><td style='padding-right: 2em'>$deptoptionCode[$i] </td><th style='padding-right: 2em'>--</th><td style='padding-right: 2em'> $deptoptionTitle[$i]</td></tr>";
                                                }
                                                ?>
                                    </tbody>
                                </table>
                                <br><br>
                                <div class="row">
                                    <?php if (isset($_POST["view"])) { ?>
                                    <?php
                                                $curri = strtolower($_SESSION['curri']);
                                                if ($curri == "OLD") {
                                                    $curri2 = "";
                                                } else {
                                                    $curri2 = "_" . $curri;
                                                }
                                                $id = $_POST["id"];
                                                $sql = "SELECT * FROM gencourses" . $curri2 . " WHERE id = '$id'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $C_codding = $row["C_codding"];
                                                        $C_title = $row["C_title"];
                                                        //$id = $row["id"];
                                                        $credit = $row['credit'];
                                                        $semester = $row["semester"];
                                                        $Nature1 = $row["Nature1"];
                                                        $Level1 = $row["Level1"];
                                                        if ($DegType == "BEng") {
                                                            $Ten88 = $row["Ten88"];
                                                        }
                                                    }
                                                }
                                                if ($_SESSION['InstType'] == "University") {
                                                    $sql = "SELECT * FROM requirement_tab WHERE Requirement_Code = '$Nature1' AND DeptCode = '$dept' AND curri_Code = '$curri'";
                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                    $sql = "SELECT * FROM requirement_tab_poly WHERE Requirement_Code = '$Nature1' AND DeptCode = '$dept' AND curri_Code = '$curri'";
                                                }

                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $requireTitle = $row["Requirement_Name"];
                                                    }
                                                }
                                                ?>
                                    <form class="form-horizontal form-bordered" method="post">

                                        <div class="row" style="font-size: 14px">
                                            <input name="id" type="hidden" class="form-control input-lg"
                                                value="<?php echo $id ?>" />
                                            <div class="col-lg-4">
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Course
                                                        Code
                                                        :</label>
                                                    <label class="control-label col-lg-7" for="content"
                                                        style="text-align: left"><?php echo $C_codding ?></label>
                                                    <input name="CCode" type="hidden" class="form-control input-lg"
                                                        value="<?php echo $C_codding ?>" />
                                                </div>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Course
                                                        Title
                                                        :</label>
                                                    <label class="control-label col-lg-7" for="content"
                                                        style="text-align: left"><?php echo $C_title ?></label>
                                                    <input name="CTitle" type="hidden" class="form-control input-lg"
                                                        value="<?php echo $C_title ?>" />
                                                </div>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Credit
                                                        Unit
                                                        :</label>
                                                    <div class="col-lg-7">
                                                        <select name="CUnit" class="form-control" style="color:#000000"
                                                            id="CUnit">
                                                            <option value="<?php echo $credit ?>">
                                                                <?php echo $credit ?>
                                                            </option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                            <option value="6">6</option>1
                                                            <option value="7">7</option>
                                                            <option value="8">8</option>
                                                            <option value="9">9</option>
                                                            <option value="10">10</option>
                                                            <option value="11">11</option>
                                                            <option value="12">12</option>

                                                        </select>
                                                    </div>

                                                </div>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Semester
                                                        :</label>
                                                    <div class="col-lg-7">
                                                        <select name="getSemester" class="form-control"
                                                            style="color:#000000" id="getSemester">
                                                            <option value="<?php echo $semester ?>">
                                                                <?php echo $semester ?>
                                                            </option>
                                                            <option value="1ST">1ST</option>
                                                            <option value="2ND">2ND</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Course
                                                        Nature
                                                        :</label>
                                                    <div class="col-lg-7">
                                                        <select name="getNature" class="form-control"
                                                            style="color:#000000" id="getNature">
                                                            <option value="<?php echo $Nature1 ?>">
                                                                <?php echo $requireTitle ?></option>
                                                            <?php
                                                                        if ($_SESSION['InstType'] == "University") {
                                                                            $sql = "SELECT * FROM requirement_tab WHERE DeptCode = '$dept' AND curri_Code = '$curri'";
                                                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                                            $sql = "SELECT * FROM requirement_tab_poly WHERE DeptCode = '$dept' AND curri_Code = '$curri'";
                                                                        }

                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                $requireCode = $row["Requirement_Code"];
                                                                                $requireTitle = $row["Requirement_Name"];
                                                                                echo "<option value=$requireCode>$requireTitle</option>";
                                                                            }
                                                                        }
                                                                        ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Level
                                                        :</label>
                                                    <div class="col-lg-7">
                                                        <select name="getlevel" class="form-control"
                                                            style="color:#000000" id="getlevel">
                                                            <?php if ($_SESSION['InstType'] == "University") { ?>
                                                            <option value="<?php echo $Level1 ?>">
                                                                <?php echo $Level1 ?>
                                                            </option>
                                                            <option value="100">100</option>
                                                            <option value="200">200</option>
                                                            <option value="300">300</option>
                                                            <option value="400">400</option>
                                                            <option value="500">500</option>
                                                            <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                            <?php
                                                                            if ($Level1 == 100) {
                                                                                $Level2 = "ND I";
                                                                            } elseif ($Level1 == 200) {
                                                                                $Level2 = "ND II";
                                                                            } elseif ($Level1 == 300) {
                                                                                $Level2 = "HND I";
                                                                            } elseif ($Level1 == 400) {
                                                                                $Level2 = "HND II";
                                                                            }
                                                                            ?>
                                                            <option value="<?php echo $Level1 ?>">
                                                                <?php echo $Level2 ?>
                                                            </option>
                                                            <option value="100">ND I</option>
                                                            <option value="200">ND II</option>
                                                            <option value="300">HND I</option>
                                                            <option value="400">HND II</option>

                                                            <?php } else { ?>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <?php
                                                            for ($i = 1; $i <= $deptoptCount; $i++) {
                                                                $sql = "SELECT * FROM gencourses" . $curri2 . " WHERE id = '$id'";
                                                                $result = $conn_stu->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $Relevant = $row[$deptoptionCode[$i]];
                                                                        $Core = $row["Core_" . $deptoptionCode[$i]];
                                                                        $CoreDE200 = $row["CoreDE200_" . $deptoptionCode[$i]];
                                                                        $CoreDE300 = $row["CoreDE300_" . $deptoptionCode[$i]];
                                                                    }
                                                                }


                                                            ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Relevant
                                                        to
                                                        <?php echo $deptoptionCode[$i] ?> </label>
                                                    <div class="col-lg-7">
                                                        <select name="<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $Relevant ?>">
                                                                <?php echo $Relevant ?>
                                                            </option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Core UME
                                                        100 Level
                                                        (<?php echo $deptoptionCode[$i] ?> )</label>
                                                    <div class="col-lg-7">
                                                        <select name="Core_<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="Core_<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $Core ?>">
                                                                <?php echo $Core ?></option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Core DE
                                                        200 Level
                                                        (<?php echo $deptoptionCode[$i] ?> )</label>
                                                    <div class="col-lg-7">
                                                        <select name="CoreDE200_<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="CoreDE200_<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $CoreDE200 ?>">
                                                                <?php echo $CoreDE200 ?></option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Core DE
                                                        300 Level
                                                        (<?php echo $deptoptionCode[$i] ?> )</label>
                                                    <div class="col-lg-7">
                                                        <select name="CoreDE300_<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="CoreDE300_<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $CoreDE300 ?>">
                                                                <?php echo $CoreDE300 ?></option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Core
                                                        (<?php echo $deptoptionCode[$i] ?> )</label>
                                                    <div class="col-lg-7">
                                                        <select name="Core_<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="Core_<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $Core ?>">
                                                                <?php echo $Core ?></option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <?php } ?>
                                                <?php
                                                            }
                                                            ?>

                                            </div>

                                            <div class="col-lg-4">
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <?php if ($DegType == "BEng") { ?>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">10 - 8 -
                                                        8 :</label>
                                                    <div class="col-lg-7">
                                                        <select name="Ten88" class="form-control" style="color:#000000"
                                                            id="Ten88">
                                                            <option value="<?php echo $Ten88 ?>">
                                                                <?php echo $Ten88 ?>
                                                            </option>
                                                            <option value="Mathematics">Mathematics</option>
                                                            <option value="Physics">Physics</option>
                                                            <option value="Chemistry">Chemistry</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <?php } ?>
                                                <?php } ?>
                                                <div class="row">

                                                    <div class="col-lg-4">
                                                        <input name="curri2" type="hidden" class="form-control input-lg"
                                                            value="<?php echo $curri ?>" />
                                                        <button type="submit" name="submit"
                                                            class="btn btn-primary btn-sm">Submit</button>

                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                    <hr class="separator" />
                                    <?php } ?>
                                </div>

                                <div class="col-lg-12 table-responsive">
                                    <table class="table table-striped table-bordered table-hover dataTables-example">
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/ No</th>
                                                <th style='text-align:center'>Course Code</th>
                                                <th style='text-align:center'>Course Title</th>
                                                <th>Unit</th>
                                                <th>Semester</th>
                                                <th>Nature</th>
                                                <th>Level</th>
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <?php for ($i = 1; $i <= $deptoptCount; $i++) { ?>
                                                <th>Relevant to <?php echo $deptoptionCode[$i] ?></th>
                                                <th>Core UME 100 (<?php echo $deptoptionCode[$i] ?>)</th>
                                                <th>Core DE 200L (<?php echo $deptoptionCode[$i] ?>)</th>
                                                <th>Core DE 300L (<?php echo $deptoptionCode[$i] ?>)</th>
                                                <?php } ?>
                                                <?php if ($DegType == "BEng") { ?>
                                                <th>Ten88</th>
                                                <?php } ?>
                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                <?php for ($i = 1; $i <= $deptoptCount; $i++) { ?>
                                                <th>Relevant to <?php echo $deptoptionCode[$i] ?></th>
                                                <th>Core (<?php echo $deptoptionCode[$i] ?>)</th>

                                                <?php } ?>
                                                <?php } ?>
                                                <th>Course Code</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                    $sno = 0;
                                                    $curri = strtolower($_SESSION['curri']);
                                                    if ($curri == "OLD") {
                                                        $curri2 = "";
                                                    } else {
                                                        $curri2 = "_" . $curri;
                                                    }
                                                    $sql = "SELECT * FROM gencourses" . strtolower($curri2) . " ORDER BY Level1, C_codding";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $C_codding = $row["C_codding"];
                                                            $C_title = $row["C_title"];
                                                            $id = $row["id"];
                                                            $credit = $row['credit'];
                                                            $semester = $row["semester"];
                                                            $Nature1 = $row["Nature1"];
                                                            $Level1 = $row["Level1"];
                                                            if ($_SESSION['InstType'] == "Polytechnic") {
                                                                if ($Level1 == 100) {
                                                                    $Level1 = "ND I";
                                                                } elseif ($Level1 == 200) {
                                                                    $Level1 = "ND II";
                                                                } elseif ($Level1 == 300) {
                                                                    $Level1 = "HND I";
                                                                } elseif ($Level1 == 400) {
                                                                    $Level1 = "HND II";
                                                                }
                                                            }


                                                            echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$C_codding </td><td> $C_title</td><td>$credit</td>";
                                                            echo "<td> $semester</td><td>$Nature1</td><td>$Level1</td>";
                                                            if ($_SESSION['InstType'] == "University") {
                                                                for ($i = 1; $i <= $deptoptCount; $i++) {
                                                                    $Relevant = $row[$deptoptionCode[$i]];
                                                                    $Core = $row["Core_" . $deptoptionCode[$i]];
                                                                    $CoreDE200 = $row["CoreDE200_" . $deptoptionCode[$i]];
                                                                    $CoreDE300 = $row["CoreDE300_" . $deptoptionCode[$i]];
                                                                    echo "<td> $Relevant</td><td>$Core</td><td>$CoreDE200</td><td>$CoreDE300</td>";
                                                                }
                                                                if ($DegType == "BEng") {
                                                                    $Ten88 = $row["Ten88"];
                                                                    echo "<td> $Ten88</td>";
                                                                }
                                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                                $Relevant = $row[$deptoptionCode[$i]];
                                                                $Core = $row["Core_" . $deptoptionCode[$i]];

                                                                echo "<td> $Relevant</td><td>$Core</td>";
                                                            }
                                                            echo "<td> $C_codding</td>";
                                                            echo "<td>
                                            <form action='' method='post'>
                                                <input type='hidden' value='$id' name='id'>
                                                
                                                <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                            </form>
                                            </td>";
                                                            echo "</tr>\n";
                                                        }
                                                    }


                                                    ?>
                                        </tbody>
                                    </table>
                                </div>

                                <?php } else { ?>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="row">
                                        <label class="control-label col-lg-3" for="content">Select
                                            Curriculum:</label>
                                        <div class="col-lg-7">
                                            <select class="form-control" style="color:#000000" name="curri">
                                                <option value="SelectItem">Select Item</option>
                                                <?php
                                                        //$cat = $_SESSION['cat'];
                                                        $dept = $_SESSION['deptcode'];

                                                        $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept'";
                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $curricode2 = $row["curri_Code"];
                                                                $curriname2 = $row["curri_Title"];
                                                                echo "<option value=$curricode2>$curriname2</option>";
                                                            }
                                                        }
                                                        ?>

                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <button type="submit" name="submitcurri"
                                                class="btn btn-primary btn-sm">Submit</button>

                                        </div>
                                    </div>
                                </form>
                                <?php } ?>

                                <?php } else { ?>

                                <h2><?php echo $deptname ?></h2>
                                <table>

                                    <tbody>
                                        <?php
                                            for ($i = 1; $i <= $deptoptCount; $i++) {
                                                echo "<tr><td style='padding-right: 2em'>$deptoptionCode[$i] </td><th style='padding-right: 2em'>--</th><td style='padding-right: 2em'> $deptoptionTitle[$i]</td></tr>";
                                            }
                                            ?>
                                    </tbody>
                                </table>
                                <br><br>
                                <div class="row">
                                    <?php if (isset($_POST["view"])) { ?>
                                    <?php
                                            $id = $_POST["id"];
                                            $sql = "SELECT * FROM gencourses WHERE id = '$id'";
                                            $result = $conn_stu->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $C_codding = $row["C_codding"];
                                                    $C_title = $row["C_title"];
                                                    //$id = $row["id"];
                                                    $credit = $row['credit'];
                                                    $semester = $row["semester"];
                                                    $Nature1 = $row["Nature1"];
                                                    $Level1 = $row["Level1"];
                                                    if ($DegType == "BEng") {
                                                        $Ten88 = $row["Ten88"];
                                                    }
                                                }
                                            }

                                            if ($_SESSION['InstType'] == "University") {
                                                $sql = "SELECT * FROM requirement_tab WHERE Requirement_Code = '$Nature1' AND DeptCode = '$dept'";
                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                $sql = "SELECT * FROM requirement_tab_poly WHERE Requirement_Code = '$Nature1' AND DeptCode = '$dept'";
                                            }

                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $requireTitle = $row["Requirement_Name"];
                                                }
                                            }
                                            ?>
                                    <form class="form-horizontal form-bordered" method="post">

                                        <div class="row" style="font-size: 14px">
                                            <input name="id" type="hidden" class="form-control input-lg"
                                                value="<?php echo $id ?>" />
                                            <div class="col-lg-4">
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Course
                                                        Code
                                                        :</label>
                                                    <label class="control-label col-lg-7" for="content"
                                                        style="text-align: left"><?php echo $C_codding ?></label>
                                                    <input name="CCode" type="hidden" class="form-control input-lg"
                                                        value="<?php echo $C_codding ?>" />
                                                </div>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Course
                                                        Title
                                                        :</label>
                                                    <label class="control-label col-lg-7" for="content"
                                                        style="text-align: left"><?php echo $C_title ?></label>
                                                    <input name="CTitle" type="hidden" class="form-control input-lg"
                                                        value="<?php echo $C_title ?>" />
                                                </div>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Credit
                                                        Unit
                                                        :</label>
                                                    <div class="col-lg-7">
                                                        <select name="CUnit" class="form-control" style="color:#000000"
                                                            id="CUnit">
                                                            <option value="<?php echo $credit ?>">
                                                                <?php echo $credit ?>
                                                            </option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                            <option value="6">6</option>1
                                                            <option value="7">7</option>
                                                            <option value="8">8</option>
                                                            <option value="9">9</option>
                                                            <option value="10">10</option>
                                                            <option value="11">11</option>
                                                            <option value="12">12</option>

                                                        </select>
                                                    </div>

                                                </div>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Semester
                                                        :</label>
                                                    <div class="col-lg-7">
                                                        <select name="getSemester" class="form-control"
                                                            style="color:#000000" id="getSemester">
                                                            <option value="<?php echo $semester ?>">
                                                                <?php echo $semester ?>
                                                            </option>
                                                            <option value="1ST">1ST</option>
                                                            <option value="2ND">2ND</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">Course
                                                        Nature
                                                        :</label>
                                                    <div class="col-lg-7">
                                                        <select name="getNature" class="form-control"
                                                            style="color:#000000" id="getNature">
                                                            <option value="<?php echo $Nature1 ?>">
                                                                <?php echo $requireTitle ?></option>
                                                            <?php
                                                                    if ($_SESSION['InstType'] == "University") {
                                                                        $sql = "SELECT * FROM requirement_tab WHERE DeptCode = '$dept'";
                                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                                        $sql = "SELECT * FROM requirement_tab_poly WHERE DeptCode = '$dept'";
                                                                    }

                                                                    $result = $conn->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $requireCode = $row["Requirement_Code"];
                                                                            $requireTitle = $row["Requirement_Name"];
                                                                            echo "<option value=$requireCode>$requireTitle</option>";
                                                                        }
                                                                    }
                                                                    ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Level
                                                        :</label>
                                                    <div class="col-lg-7">
                                                        <select name="getlevel" class="form-control"
                                                            style="color:#000000" id="getlevel">
                                                            <?php if ($_SESSION['InstType'] == "University") { ?>
                                                            <option value="<?php echo $Level1 ?>">
                                                                <?php echo $Level1 ?>
                                                            </option>
                                                            <option value="100">100</option>
                                                            <option value="200">200</option>
                                                            <option value="300">300</option>
                                                            <option value="400">400</option>
                                                            <option value="500">500</option>
                                                            <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                            <?php
                                                                        if ($Level1 == 100) {
                                                                            $Level2 = "ND I";
                                                                        } elseif ($Level1 == 200) {
                                                                            $Level2 = "ND II";
                                                                        } elseif ($Level1 == 300) {
                                                                            $Level2 = "HND I";
                                                                        } elseif ($Level1 == 400) {
                                                                            $Level2 = "HND II";
                                                                        }
                                                                        ?>
                                                            <option value="<?php echo $Level1 ?>">
                                                                <?php echo $Level2 ?>
                                                            </option>
                                                            <option value="100">ND I</option>
                                                            <option value="200">ND II</option>
                                                            <option value="300">HND I</option>
                                                            <option value="400">HND II</option>

                                                            <?php } else { ?>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <?php
                                                        for ($i = 1; $i <= $deptoptCount; $i++) {
                                                            $sql = "SELECT * FROM gencourses WHERE id = '$id'";
                                                            $result = $conn_stu->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $Relevant = $row[$deptoptionCode[$i]];
                                                                    $Core = $row["Core_" . $deptoptionCode[$i]];
                                                                    $CoreDE200 = $row["CoreDE200_" . $deptoptionCode[$i]];
                                                                    $CoreDE300 = $row["CoreDE300_" . $deptoptionCode[$i]];
                                                                }
                                                            }


                                                        ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Relevant
                                                        to
                                                        <?php echo $deptoptionCode[$i] ?> </label>
                                                    <div class="col-lg-7">
                                                        <select name="<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $Relevant ?>">
                                                                <?php echo $Relevant ?>
                                                            </option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Core UME
                                                        100 Level
                                                        (<?php echo $deptoptionCode[$i] ?> )</label>
                                                    <div class="col-lg-7">
                                                        <select name="Core_<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="Core_<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $Core ?>">
                                                                <?php echo $Core ?></option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Core DE
                                                        200 Level
                                                        (<?php echo $deptoptionCode[$i] ?> )</label>
                                                    <div class="col-lg-7">
                                                        <select name="CoreDE200_<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="CoreDE200_<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $CoreDE200 ?>">
                                                                <?php echo $CoreDE200 ?></option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Core DE
                                                        300 Level
                                                        (<?php echo $deptoptionCode[$i] ?> )</label>
                                                    <div class="col-lg-7">
                                                        <select name="CoreDE300_<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="CoreDE300_<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $CoreDE300 ?>">
                                                                <?php echo $CoreDE300 ?></option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Core
                                                        (<?php echo $deptoptionCode[$i] ?> )</label>
                                                    <div class="col-lg-7">
                                                        <select name="Core_<?php echo $deptoptionCode[$i] ?>"
                                                            class="form-control" style="color:#000000"
                                                            id="Core_<?php echo $deptoptionCode[$i] ?>">
                                                            <option value="<?php echo $Core ?>">
                                                                <?php echo $Core ?></option>
                                                            <option value="NO">NO</option>
                                                            <option value="YES">YES</option>

                                                        </select>
                                                    </div>
                                                </div>
                                                <?php } ?>
                                                <?php
                                                        }
                                                        ?>

                                            </div>

                                            <div class="col-lg-4">
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <?php if ($DegType == "BEng") { ?>
                                                <div class="row" style="padding-bottom: 1em">
                                                    <label class="control-label col-lg-5" for="content">10 - 8 -
                                                        8 :</label>
                                                    <div class="col-lg-7">
                                                        <select name="Ten88" class="form-control" style="color:#000000"
                                                            id="Ten88">
                                                            <option value="<?php echo $Ten88 ?>">
                                                                <?php echo $Ten88 ?>
                                                            </option>
                                                            <option value="Mathematics">Mathematics</option>
                                                            <option value="Physics">Physics</option>
                                                            <option value="Chemistry">Chemistry</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <?php } ?>
                                                <?php } ?>
                                                <div class="row">

                                                    <div class="col-lg-4">
                                                        <button type="submit" name="submit"
                                                            class="btn btn-primary btn-sm">Submit</button>

                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                    <hr class="separator" />
                                    <?php } ?>
                                </div>

                                <div class="col-lg-12 table-responsive">
                                    <table class="table table-striped table-bordered table-hover dataTables-example">
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/ No</th>
                                                <th style='text-align:center'>Course Code</th>
                                                <th style='text-align:center'>Course Title</th>
                                                <th>Unit</th>
                                                <th>Semester</th>
                                                <th>Nature</th>
                                                <th>Level</th>
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <?php for ($i = 1; $i <= $deptoptCount; $i++) { ?>
                                                <th>Relevant to <?php echo $deptoptionCode[$i] ?></th>
                                                <th>Core UME 100 (<?php echo $deptoptionCode[$i] ?>)</th>
                                                <th>Core DE 200L (<?php echo $deptoptionCode[$i] ?>)</th>
                                                <th>Core DE 300L (<?php echo $deptoptionCode[$i] ?>)</th>
                                                <?php } ?>
                                                <?php if ($DegType == "BEng") { ?>
                                                <th>Ten88</th>
                                                <?php } ?>
                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                <?php for ($i = 1; $i <= $deptoptCount; $i++) { ?>
                                                <th>Relevant to <?php echo $deptoptionCode[$i] ?></th>
                                                <th>Core (<?php echo $deptoptionCode[$i] ?>)</th>

                                                <?php } ?>
                                                <?php } ?>
                                                <th>Course Code</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $sno = 0;

                                                $sql = "SELECT * FROM gencourses ORDER BY Level1, C_codding";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $C_codding = $row["C_codding"];
                                                        $C_title = $row["C_title"];
                                                        $id = $row["id"];
                                                        $credit = $row['credit'];
                                                        $semester = $row["semester"];
                                                        $Nature1 = $row["Nature1"];
                                                        $Level1 = $row["Level1"];



                                                        echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$C_codding </td><td> $C_title</td><td>$credit</td>";
                                                        echo "<td> $semester</td><td>$Nature1</td><td>$Level1</td>";
                                                        if ($_SESSION['InstType'] == "University") {
                                                            for ($i = 1; $i <= $deptoptCount; $i++) {
                                                                $Relevant = $row[$deptoptionCode[$i]];
                                                                $Core = $row["Core_" . $deptoptionCode[$i]];
                                                                $CoreDE200 = $row["CoreDE200_" . $deptoptionCode[$i]];
                                                                $CoreDE300 = $row["CoreDE300_" . $deptoptionCode[$i]];
                                                                echo "<td> $Relevant</td><td>$Core</td><td>$CoreDE200</td><td>$CoreDE300</td>";
                                                            }
                                                            if ($DegType == "BEng") {
                                                                $Ten88 = $row["Ten88"];
                                                                echo "<td> $Ten88</td>";
                                                            }
                                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                            for ($i = 1; $i <= $deptoptCount; $i++) {
                                                                $Relevant = $row[$deptoptionCode[$i]];
                                                                $Core = $row["Core_" . $deptoptionCode[$i]];

                                                                echo "<td> $Relevant</td><td>$Core</td>";
                                                            }
                                                        }
                                                        echo "<td> $C_codding</td>";
                                                        echo "<td>
                                            <form action='' method='post'>
                                                <input type='hidden' value='$id' name='id'>
                                                
                                                <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                            </form>
                                            </td>";
                                                        echo "</tr>\n";
                                                    }
                                                }


                                                ?>
                                        </tbody>
                                    </table>
                                </div>


                                <?php } ?>
                                <?php
                                $conn->close();
                                $conn_stu->close();
                                ?>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Page-Level Scripts -->
    <script>
    $(document).ready(function() {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: []

        });

    });
    </script>
</body>

</html>
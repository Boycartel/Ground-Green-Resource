<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';


?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php include_once 'includes/header2_staff.php'; ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_staff.php'; ?>
            <!-- end: sidebar -->


            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>My Profile</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-user"></i>
                                </a>
                            </li>
                            <li><span>My Profile</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">
                    <div class="col-md-4 col-lg-3">
                        <?php
                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                        if ($conn2->connect_error) {
                            die("Connection failed: " . $conn2->connect_error);
                        }

                        set_time_limit(500);
                        $sql = "SELECT * FROM stdprofile";

                        $result = $conn2->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $stdid = $row["stdid"];
                                $emailAdd = $row["email"];
                                $password = mt_rand(100000, 999999);
                                include 'includes/getencrypt.php';
                                $sql2 = "UPDATE account SET password2='$encryption', pwd='$password' WHERE stdid = '$stdid'";
                                $result2 = $conn2->query($sql2);

                                //$sql2 = "UPDATE stafflist SET password2='$encryption' WHERE staffid = '$staffid'";
                                //$result2 = $conn6->query($sql2);

                                $to = $emailAdd;
                                $subject = 'e-Portal Login Details';
                                $from = 'info@futminna.edu.ng';

                                // To send HTML mail, the Content-type header must be set
                                $headers  = 'MIME-Version: 1.0' . "\r\n";
                                $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

                                // Create email headers
                                $headers .= 'From: ' . $from . "\r\n" .
                                    'Reply-To: ' . $from . "\r\n" .
                                    'X-Mailer: PHP/' . phpversion();

                                // Compose a simple HTML email message
                                $message = '<html><body>';
                                $message .= '<h1 style="color:#020202;">Find below your e-portal/e-results login details</h1>';
                                $message .= "<p style='color:#080;font-size:18px;'>Username: " . $staffid . "</p>";
                                $message .= "<p style='color:#080;font-size:18px;'>Password: " . $password . "</p>";
                                $message .= '</body></html>';

                                // Sending email
                                if (mail($to, $subject, $message, $headers)) {
                                    echo 'Your mail has been sent successfully.';
                                } else {
                                    echo 'Unable to send email. Please try again.';
                                }
                            }
                        }
                        $conn->close();
                        $conn2->close();
                        /*for ($i = 0; $i<6; $i++)
                    {
                        $a = mt_rand(100000,999999);
                        echo $a."<br>";
                    }*/

                        ?>

                        <section class="panel">
                            <div class="panel-body">
                                <div class="thumb-info mb-md">

                                </div>


                                <hr class="dotted short">

                                <div class="social-icons-list">
                                    <a rel="tooltip" data-placement="bottom" target="_blank" href="#"
                                        data-original-title="Facebook"><i
                                            class="fa fa-facebook"></i><span>Facebook</span></a>
                                    <a rel="tooltip" data-placement="bottom" href="#" data-original-title="Twitter"><i
                                            class="fa fa-twitter"></i><span>Twitter</span></a>
                                    <a rel="tooltip" data-placement="bottom" href="#" data-original-title="Linkedin"><i
                                            class="fa fa-linkedin"></i><span>Linkedin</span></a>
                                </div>

                            </div>
                        </section>



                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
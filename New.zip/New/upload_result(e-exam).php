<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['upload_result(e-exam)'] == false) {
    header('Location: Home_Staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Upload e-exam Results</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-upload"></i>
                                </a>
                            </li>
                            <li><span>Upload</span></li>
                            <li><span>Upload e-exam Results</span></li>
                        </ol>


                    </div>
                </header>

                <!-- start: page -->

                <div class="row">

                    <div class="col-lg-12  col-md-12">

                        <div class="col-lg-12">
                            <section class="panel panel-success">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>

                                    <h2 class="panel-title">Upload e-exam Results</h2>
                                </header>
                                <div class="panel-body">
                                    <?php
                                    //$corntsession = $_SESSION['corntsession'];





                                    if (isset($_POST["upfile"])) {
                                        $ccode = $_POST['course'];
                                        $corntsession = $_POST['getsession'];
                                        $dbsession = str_replace("/", "_", $corntsession);

                                        $sql = "select 1 from e_exam_results_" . $dbsession;
                                        $exists = $conn->query($sql);

                                        if ($exists == false) {
                                            $TabCreate = "e_exam_results_" . $dbsession;
                                            $sql = "CREATE TABLE " . $TabCreate . " SELECT * FROM e_exam_results_empty";
                                            $result = $conn->query($sql);

                                            $sql = "ALTER TABLE " . $TabCreate . " ADD column sn int NOT NULL auto_increment Primary Key";
                                            $result = $conn->query($sql);
                                        }

                                        set_time_limit(500);
                                        error_reporting(E_ERROR);

                                        $filename = $_FILES["uploaded"]["tmp_name"];

                                        $file_ext = strtolower(end(explode('.', $_FILES['uploaded']['name'])));

                                        if ($file_ext == "csv") {
                                            if ($_FILES['uploaded']['name'] == $ccode . '.csv') {
                                                if ($_FILES["uploaded"]["size"] > 0) {
                                                    $file = fopen($filename, "r");
                                                    //$sql_data = "SELECT * FROM prod_list_1 ";
                                                    $count = 0;
                                                    while (($Row = fgetcsv($file, 10000, ",")) !== FALSE) {
                                                        $stuid = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                                        //$ccode = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                                        $ca = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                                        $exam = filter_var($Row[2], FILTER_SANITIZE_STRING);

                                                        $sql = "SELECT * FROM stdprofile WHERE stdid = '$stuid'";
                                                        $result = $conn2->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $matno = $row["regid"];
                                                            }
                                                        } else {
                                                            $matno = "XX";
                                                        }

                                                        $sql = "SELECT C_codding, C_title, credit, semester FROM gencoursesupload WHERE C_codding = '$ccode'";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row1 = $result->fetch_assoc()) {

                                                                $ctitle = $row1["C_title"];
                                                                $unit = $row1["credit"];
                                                                $semester = $row1["semester"];
                                                            }
                                                        }


                                                        $count++;
                                                        if ($count > 1) {
                                                            $sql2 = "SELECT matno, ccode, session_regist FROM e_exam_results_" . $dbsession . " WHERE matno = '$matno' AND ccode = '$ccode' AND session_regist = '$corntsession'";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows == 0) {
                                                                $sql = "INSERT INTO e_exam_results_" . $dbsession . "(matno, ccode, ctitle, unit, Semester, ca, exam, session_regist)VALUES('$matno', '$ccode', '$ctitle', '$unit', '$semester', '$ca', '$exam', '$corntsession')";
                                                                $result = $conn->query($sql);
                                                            } else {
                                                                $sql = "UPDATE e_exam_results_" . $dbsession . " SET ca ='$ca', exam ='$exam' WHERE matno = '$matno' AND ccode = '$ccode' AND session_regist = '$corntsession'";
                                                                $result = $conn->query($sql);
                                                            }
                                                        }
                                                    }
                                                    fclose($file);
                                                    echo '<center><p style="color:#006">CSV File has been successfully Imported</p></center>';
                                                } else
                                                    echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center>';
                                            } else {
                                                echo '<center><p style="color:#F00">Invalid File:Please Pick Correct File</p></center>';
                                            }
                                        } else {
                                            echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center></p>';
                                        }
                                    }
                                    ?>
                                    <form enctype="multipart/form-data" action="" method="post">
                                        <center>
                                            <h4>CSV File with the Format Below. File Name as the Course Code</h4>
                                        </center>
                                        <center><img src='assets/images/excelformateexam.jpg' width='250' height='150' alt=''></center>
                                        <br>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">Session: </label>
                                            <div class="col-lg-6">
                                                <?php

                                                $iniyear = 2015;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>
                                            </div>

                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-2 control-label">Select Course</label>
                                            <div class="col-lg-6">
                                                <select class="form-control" style="color:#000000" name="course">
                                                    <option value="SelectItem">Select Item</option>
                                                    <?php
                                                    $sql = "SELECT * FROM gencoursesupload ORDER BY C_codding";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $coursecode = $row["C_codding"];
                                                            $coursetitle = $row["C_title"];
                                                            echo "<option value='$coursecode'>$coursecode $coursetitle</option>";
                                                        }
                                                    }
                                                    //$conn->close();
                                                    ?>
                                                </select>
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <label class="col-md-2 control-label">File Upload</label>
                                            <div class="col-md-6">
                                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                                    <div class="input-append">
                                                        <div class="uneditable-input">
                                                            <i class="fa fa-file fileupload-exists"></i>
                                                            <span class="fileupload-preview"></span>
                                                        </div>
                                                        <span class="btn btn-default btn-file">
                                                            <span class="fileupload-exists">Change</span>
                                                            <span class="fileupload-new">Select file</span>
                                                            <input type="file" name="uploaded" />
                                                        </span>
                                                        <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-2">
                                                <input type="submit" name="upfile" value="Upload File" class="btn btn-primary btn-sm">
                                            </div>
                                        </div>
                                    </form>

                                </div>

                            </section>


                        </div>

                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-autosize/jquery.autosize.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--Auto pop up div-->
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("select.country").change(function() {
                var selectedCountry = $(".country option:selected").val();
                $.ajax({
                    type: "POST",
                    url: "includes/dept_course_list.php",
                    data: {
                        country: selectedCountry
                    }
                }).done(function(data) {
                    $("#getalldeptlist").html(data);
                });
            });
        });
    </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>
<?php
$result1 = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $regid = $_SESSION["regid"];
    $dept = $_SESSION['deptcode'];
    //$array = $_POST["chosen"];
    if (!empty($_POST["chosenalldept"])) {
        foreach ($_POST["chosenalldept"] as $key => $value) {

            $ccode = $_POST["ccode1"][$key];
            $CTitle = str_replace("'", "''", $_POST["CTitle1"][$key]);
            $CUnit = $_POST["CUnit1"][$key];
            $SemTaken = $_POST["SemTaken1"][$key];
            $Nature = $_POST["Nature1"][$key];
            // sql to insert record
            $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND CCode = '$ccode'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
            } else {
                $sql2 = "INSERT INTO add_courses_cat (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature')";
                $result2 = $conn->query($sql2);
            }
        }
    } else {
    }

    //$conn->close();
}

?>

<body>
    <section class="body">

        <!-- start: header -->
        <?php
        include_once 'includes/header2_pg.php';
        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/pg_aside_menu.php';
            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Course Registration</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="stu_course_reg.php">
                                    <i class="fa fa-list"></i>
                                </a>
                            </li>
                            <li><span>Course Reg.</span></li>
                            <li><span>Course Registration</span></li>
                            <li><span>Add Courses</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">

                    <div class="col-md-1">
                    </div>
                    <div class="col-md-10">
                        <section class="panel panel-success">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">Add Courses to Cart</h2>
                            </header>
                            <div class="panel-body">
                                <form class="form-horizontal" role="form" method="post" action="addcoursesreg_pg.php">
                                    <br />
                                    <h3>
                                        <center>1ST Semester</center>
                                    </h3>
                                    <?php

                                    $regid = $_SESSION["regid"];
                                    $dept = $_SESSION['deptcode'];

                                    $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND SemTaken = '1ST'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                    ?>

                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Nature</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php

                                                while ($row = $result->fetch_assoc()) {
                                                    $id = $row["id"];
                                                    $ccode = $row["CCode"];
                                                    $CTitle = $row["CTitle"];
                                                    $CUnit = $row["CUnit"];
                                                    $SemTaken = $row["SemTaken"];
                                                    $Nature = $row["Nature"];

                                                    echo "<tr>
                                                    <td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
                                                    
                                                    <td>
                                                    <label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
                                                    <input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
                                                    <input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
                                                    <input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
                                                    <input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>
                                                    </td>
                                                    
                                                    <td>
                                                    <label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
                                                    <input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
                                                    </td>
                                                    
                                                    </tr>\n";
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <?php
                                    }

                                    $sql = "SELECT * FROM add_courses_cat WHERE Regn1 = '$regid' AND SemTaken = '1ST'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                    ?>

                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Nature</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php

                                                while ($row = $result->fetch_assoc()) {
                                                    $id = $row["sn"];
                                                    $ccode = $row["CCode"];
                                                    $CTitle = $row["CTitle"];
                                                    $CUnit = $row["CUnit"];
                                                    $SemTaken = $row["SemTaken"];
                                                    $Nature = $row["Nature"];

                                                    echo "<tr>
                                                    <td><input type='checkbox' name='chosenadd[" . $id . "]' value='" . $id . "'/></td>
                                                    
                                                    <td>
                                                    <label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
                                                    <input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
                                                    <input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='CUnit1' name='CUnit1[" . $id . "]'>$CUnit</label>
                                                    <input type='hidden' id='CUnit1' name='CUnit1[" . $id . "]' value='" . $CUnit . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='SemTaken1' name='SemTaken1[" . $id . "]'>$SemTaken</label>
                                                    <input type='hidden' id='SemTaken1' name='SemTaken1[" . $id . "]' value='" . $SemTaken . "'/>

                                                    </td>
                                                    
                                                    <td>
                                                    <label id='Nature1' name='Nature1[" . $id . "]'>$Nature</label>
                                                    <input type='hidden' id='Nature1' name='Nature1[" . $id . "]' value='" . $Nature . "'/>
                                                    </td>
                                                    
                                                    </tr>\n";
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <?php
                                    }

                                    //$conn->close();
                                    ?>
                                    <br /><br />
                                    <h3>
                                        <center>2ND Semester</center>
                                    </h3>
                                    <?php


                                    $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND SemTaken = '2ND'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                    ?>

                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Nature</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                while ($row = $result->fetch_assoc()) {
                                                    $id = $row["id"];
                                                    $ccode = $row["CCode"];
                                                    $CTitle = $row["CTitle"];
                                                    $CUnit = $row["CUnit"];
                                                    $SemTaken = $row["SemTaken"];
                                                    $Nature = $row["Nature"];

                                                    echo "<tr>
                                                    <td><input type='checkbox' name='chosen2[" . $id . "]' value='" . $id . "'/></td>
                                                    
                                                    <td>
                                                    <label id='ccode2' name='ccode2[" . $id . "]'>$ccode</label>
                                                    <input type='hidden' id='ccode2' name='ccode2[" . $id . "]' value='" . $ccode . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='CTitle2' name='CTitle2[" . $id . "]'>$CTitle</label>
                                                    <input type='hidden' id='CTitle2' name='CTitle2[" . $id . "]' value='" . $CTitle . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='CUnit2' name='CUnit2[" . $id . "]'>$CUnit</label>
                                                    <input type='hidden' id='CUnit2' name='CUnit2[" . $id . "]' value='" . $CUnit . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='SemTaken2' name='SemTaken2[" . $id . "]'>$SemTaken</label>
                                                    <input type='hidden' id='SemTaken2' name='SemTaken2[" . $id . "]' value='" . $SemTaken . "'/>
                                                    </td>
                                                    
                                                    <td>
                                                    <label id='Nature2' name='Nature2[" . $id . "]'>$Nature</label>
                                                    <input type='hidden' id='Nature2' name='Nature2[" . $id . "]' value='" . $Nature . "'/>
                                                    </td>
                                                    
                                                    </tr>\n";
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <?php
                                    }

                                    $sql = "SELECT * FROM add_courses_cat WHERE Regn1 = '$regid' AND SemTaken = '2ND'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                    ?>

                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Nature</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                while ($row = $result->fetch_assoc()) {
                                                    $id = $row["sn"];
                                                    $ccode = $row["CCode"];
                                                    $CTitle = $row["CTitle"];
                                                    $CUnit = $row["CUnit"];
                                                    $SemTaken = $row["SemTaken"];
                                                    $Nature = $row["Nature"];

                                                    echo "<tr>
                                                    <td><input type='checkbox' name='chosenadd2[" . $id . "]' value='" . $id . "'/></td>
                                                    
                                                    <td>
                                                    <label id='ccode2' name='ccode2[" . $id . "]'>$ccode</label>
                                                    <input type='hidden' id='ccode2' name='ccode2[" . $id . "]' value='" . $ccode . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='CTitle2' name='CTitle2[" . $id . "]'>$CTitle</label>
                                                    <input type='hidden' id='CTitle2' name='CTitle2[" . $id . "]' value='" . $CTitle . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='CUnit2' name='CUnit2[" . $id . "]'>$CUnit</label>
                                                    <input type='hidden' id='CUnit2' name='CUnit2[" . $id . "]' value='" . $CUnit . "'/>
                                                    </td>
                                                    <td>
                                                    <label id='SemTaken2' name='SemTaken2[" . $id . "]'>$SemTaken</label>
                                                    <input type='hidden' id='SemTaken2' name='SemTaken2[" . $id . "]' value='" . $SemTaken . "'/>
                                                    </td>
                                                    
                                                    <td>
                                                    <label id='Nature2' name='Nature2[" . $id . "]'>$Nature</label>
                                                    <input type='hidden' id='Nature2' name='Nature2[" . $id . "]' value='" . $Nature . "'/>
                                                    </td>
                                                    
                                                    </tr>\n";
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <?php
                                    }
                                    //$conn->close();

                                    ?>

                                    <br /><br />
                                    <div class="form-group">
                                        <label class="col-lg-6 control-label">Select Department:</label>
                                        <div class="col-lg-6">
                                            <select class="country form-control" style="color:#000000" name="state">
                                                <option value="No">No</option>
                                                <?php

                                                $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    // output data of each row
                                                    while ($row = $result->fetch_assoc()) {
                                                        $deptcode = $row["DeptCode"];
                                                        $deptname = $row["DeptName"];
                                                        echo "<option value=$deptcode>$deptname</option>";
                                                    }
                                                }
                                                //$conn->close();
                                                ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group" id="getalldeptlist">

                                    </div>
                                    <br /><br />
                                    <div class="row" style="text-align:right">
                                        <button type="submit" name="submit" class="btn btn-primary">Add to Cart</button>
                                    </div>
                                    <div class="row">
                                        <a class="" href="pg_course_reg.php"><span>Back to Course Reg</span></a>
                                    </div>
                                    <br /><br />
                                </form>

                            </div>
                        </section>
                    </div>
                    <div class="col-md-1">
                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
<?php
//require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

$course = $_SESSION['downlcurse'];
$savesession = $_SESSION['downlsession'];

$filename = $_GET["filename1"];
$contenttype = "application/force-download";
header("Content-Type: " . $contenttype);
header("Content-Disposition: attachment; filename=\"" . basename($filename) . "\";");
readfile("Content/" . $savesession . "/" . $course . "/" . $filename);
exit();

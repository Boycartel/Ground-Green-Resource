<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Upload Courses</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Upload
                            </li>

                            <li class="active">
                                <strong>Upload Courses</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Upload Courses
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <?php
                                $msg = "";
                                $success_upl = "no";

                                if (isset($_POST["upfile"])) {
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    set_time_limit(500);
                                    error_reporting(E_ERROR);

                                    $filename = $_FILES["uploaded"]["tmp_name"];

                                    $file_ext = strtolower(end(explode('.', $_FILES['uploaded']['name'])));

                                    if ($file_ext == "csv") {
                                        //if($_FILES['uploaded']['name'] == $ccode.'.csv'){
                                        if ($_FILES["uploaded"]["size"] > 0) {
                                            $file = fopen($filename, "r");
                                            //$sql_data = "SELECT * FROM prod_list_1 ";
                                            $count = 0;
                                            while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                                $count++;
                                                $Row0 = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                                $Row1 = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                                $Row2 = filter_var($Row[2], FILTER_SANITIZE_STRING);
                                                $Row3 = filter_var($Row[3], FILTER_SANITIZE_STRING);
                                                $Row4 = filter_var($Row[4], FILTER_SANITIZE_STRING);
                                                $Row5 = filter_var($Row[5], FILTER_SANITIZE_STRING);

                                                $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$Row0' AND type1 = '$Row5'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    $sql2 = "UPDATE gencoursesupload SET C_title ='$Row1', credit ='$Row2', semester = '$Row3', Department ='$Row4', type1 ='$Row5' WHERE C_codding = '$Row0'";
                                                    $result2 = $conn->query($sql2);
                                                } else {
                                                    $sql2 = "INSERT INTO gencoursesupload(C_codding, C_title, credit, semester, Department, type1)VALUES('$Row0', '$Row1', '$Row2', '$Row3', '$Row4', '$Row5')";
                                                    $result2 = $conn->query($sql2);
                                                }
                                            }
                                            fclose($file);
                                            echo '<center><p style="color:#006">CSV File has been successfully Imported</p></center>';
                                            $success_upl = "yes";
                                        } else
                                            echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center>';
                                    } else {
                                        echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center></p>';
                                    }
                                    $conn->close();
                                }


                                ?>
                                <form enctype="multipart/form-data" action="" method="post">
                                    <h4 style="text-align: center">CSV File with the Format Below.</h4>
                                    <center><img src='img/upload_courses.png' width='500' height='300' alt=''>
                                    </center>
                                    <br><br>

                                    <div class="form-group" style="text-align: center;">
                                        <label class="col-md-2 control-label">File Upload</label>
                                        <div class="col-md-4">



                                            <div class="fileinput fileinput-new input-group" data-provides="fileinput">
                                                <div class="form-control" data-trigger="fileinput">
                                                    <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                                    <span class="fileinput-filename"></span>
                                                </div>
                                                <span class="input-group-addon btn btn-default btn-file"><span class="fileinput-new">Select
                                                        file</span><span class="fileinput-exists">Change</span><input type="file" name="uploaded"></span>
                                                <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <input type="submit" name="upfile" value="Upload File" class="btn btn-primary btn-sm">
                                        </div>
                                    </div>
                                </form>
                                <h3> <?php echo $msg ?> </h3>

                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>

</body>

</html>
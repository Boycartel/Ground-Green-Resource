<?php

require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>
<br /><br /><br />

<center><strong>
		<h4><?php echo $_SESSION['gradregid'] ?></h4>
	</strong></center>
<center><strong>
		<h4><?php echo $_SESSION['gradnames'] ?></h4>
	</strong></center>

<?php

/* $regid = $_SESSION['gradregid'];
$dept = $_SESSION['GradDept'];
$sumunits = $sumgp = 0;

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
	die("Connection failed: " . $conn_stu->connect_error);
}

$sql = "SELECT * FROM grad_correg WHERE Regn1 = '$regid'";
$result = $conn_stu->query($sql);

if ($result->num_rows > 0) {

	while ($row = $result->fetch_assoc()) {
		if ($row['CA'] + $row['Exam'] >= 70) {
			$point = 5;
		} elseif ($row['CA'] + $row['Exam'] >= 60) {
			$point = 4;
		} elseif ($row['CA'] + $row['Exam'] >= 50) {
			$point = 3;
		} elseif ($row['CA'] + $row['Exam'] >= 45) {
			$point = 2;
		} elseif ($row['CA'] + $row['Exam'] >= 40) {
			$point = 1;
		} elseif ($row['CA'] + $row['Exam'] <= 39.95) {
			$point = 0;
		}

		$sumunits += $row['CUnit'];
		$sumgp += $row['CUnit'] * $point;
	}
	echo "<center><h1>Graduated from the University with</h1></center>";

	$cgpa = number_format((float)$sumgp / $sumunits, 2, '.', '');
	if ($cgpa >= 4.495) {
		echo "<center><h1>First Class</h1></center>";
	} elseif ($cgpa >= 3.495) {
		echo "<center><h1>Second Class Upper</h1></center>";
	} elseif ($cgpa >= 2.395) {
		echo "<center><h1>Second Class Lower</h1></center>";
	} elseif ($cgpa >= 1.495) {
		echo "<center><h1>Third Class</h1></center>";
	}
} else {
	echo "<center><h1>NO Record</h1></center>";
}

$conn->close();
?> */
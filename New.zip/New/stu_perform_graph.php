<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['stu_perform_graph'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>

    <style type="text/css">
        table {

            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);

        }

        thead,
        tfoot {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }

        th,
        td {
            padding: 12px 15px;
        }
    </style>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Students Performance Analysis</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Students Performance Analysis</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students Performance Analysis
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal form-bordered" method="post">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="control-label col-lg-5" for="content">Select Department:</label>
                                        <div class="col-lg-7">
                                            <select class="country form-control" style="color:#000000" name="dept">
                                                <option value="SelectItem">Select Item</option>
                                                <?php
                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }


                                                $dept = $_SESSION['deptcode'];

                                                if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                } else {
                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                }


                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    // output data of each row
                                                    while ($row = $result->fetch_assoc()) {
                                                        $deptcode2 = strtolower($row["DeptCode"]);
                                                        $deptname2 = $row["DeptName"];
                                                        echo "<option value=$deptcode2>$deptname2</option>";
                                                    }
                                                }
                                                $conn->close();
                                                ?>

                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label class="control-label col-lg-3" for="regid">Session:</label>
                                        <div class="col-lg-8">
                                            <?php
                                            $iniyear = 2015;
                                            $finalyear = substr($_SESSION['corntsession'], 5);

                                            ?>
                                            <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                    <?php echo $_SESSION['corntsession'] ?></option>
                                                <?php
                                                while ($iniyear <= $finalyear) {
                                                    $addyear = $iniyear + 1;

                                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                    $iniyear++;
                                                }

                                                ?>


                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class="form-group">
                                        <label class="control-label col-lg-3" for="regid">Semester:</label>
                                        <div class="col-lg-5">
                                            <select name="getsemester" class="form-control" style="color:#000000" id="getsemester">
                                                <option value="1ST">1ST</option>
                                                <option value="2ND">2ND</option>

                                            </select>
                                        </div>
                                        <div class="col-lg-4">
                                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                        </div>
                                    </div>
                                </div>

                            </form>
                            <hr class="separator" />
                            <?php if (isset($_POST["submit"])) { ?>
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                $_SESSION['dept_sctny'] = $_POST["dept"];
                                $_SESSION['getsession_sctny'] = $_POST["getsession"];
                                $_SESSION['getsemester_sctny'] = $_POST["getsemester"];
                                //$_SESSION['getlevel_sctny'] = $_POST["getlevel"];
                                $_SESSION['sn'] = 0;

                                $deptname = "";

                                $getdept = $_SESSION['dept_sctny'];
                                $getsession = $_SESSION['getsession_sctny'];
                                $getsemester = $_SESSION['getsemester_sctny'];
                                //$getlevel = $_SESSION['getlevel_sctny'];

                                $sql = "SELECT DeptName, DeptCode FROM deptcoding WHERE DeptCode = '$getdept'";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    // output data of each row
                                    while ($row = $result->fetch_assoc()) {
                                        $deptname = $row["DeptName"];
                                    }
                                }

                                $totsturmk100 = $totsturmk200 = $totsturmk300 = $totsturmk400 = $totsturmk500 = 0;

                                $def100 = $igs100 = $p100 = $sp1100 = $sp2100 = $dl100 = $vl100 = 0;
                                $def200 = $igs200 = $p200 = $sp1200 = $sp2200 = $dl200 = $vl200 = 0;
                                $def300 = $igs300 = $p300 = $sp1300 = $sp2300 = $dl300 = $vl300 = 0;
                                $def400 = $igs400 = $p400 = $sp1400 = $sp2400 = $dl400 = $vl400 = 0;
                                $def500 = $igs500 = $p500 = $sp1500 = $sp2500 = $dl500 = $vl500 = 0;

                                $totvl = $totdl = $totigs = $totdef = $totp = $totsp1 = $totsp2 = 0;

                                $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }
                                //$sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND semester ='$getsemester' AND session1 ='$getsession'";
                                $sql = "SELECT * FROM scrutiny_senate WHERE semester ='$getsemester' AND session1 ='$getsession'";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {

                                        if ($_SESSION['InstType'] == "University") {
                                            if ($row["Level1"] == 100) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl100++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl100++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs100++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def100++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p100++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1100++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2100++;
                                                    $totsp2++;
                                                }
                                                $totsturmk100++;
                                            } elseif ($row["Level1"] == 200) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl200++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl200++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs200++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def200++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p200++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1200++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2200++;
                                                    $totsp2++;
                                                }
                                                $totsturmk200++;
                                            } elseif ($row["Level1"] == 300) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl300++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl300++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs300++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def300++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p300++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1300++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2300++;
                                                    $totsp2++;
                                                }
                                                $totsturmk300++;
                                            } elseif ($row["Level1"] == 400) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl400++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl400++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs400++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def400++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p400++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1400++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2400++;
                                                    $totsp2++;
                                                }
                                                $totsturmk400++;
                                            } elseif ($row["Level1"] == 500) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl500++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl500++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs500++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def500++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p500++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1500++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2500++;
                                                    $totsp2++;
                                                }
                                                $totsturmk500++;
                                            }
                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                            if ($row["Level1"] == 100) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl100++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl100++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs100++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def100++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p100++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1100++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2100++;
                                                    $totsp2++;
                                                }
                                                $totsturmk100++;
                                            } elseif ($row["Level1"] == 200) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl200++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl200++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs200++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def200++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p200++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1200++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2200++;
                                                    $totsp2++;
                                                }
                                                $totsturmk200++;
                                            } elseif ($row["Level1"] == 300) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl300++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl300++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs300++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def300++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p300++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1300++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2300++;
                                                    $totsp2++;
                                                }
                                                $totsturmk300++;
                                            } elseif ($row["Level1"] == 400) {
                                                if ($row["RMK"] == "VL") {
                                                    $vl400++;
                                                    $totvl++;
                                                } elseif ($row["RMK"] == "DL") {
                                                    $dl400++;
                                                    $totdl++;
                                                } elseif ($row["RMK"] == "IGS") {
                                                    $igs400++;
                                                    $totigs++;
                                                } elseif ($row["RMK"] == "DEF") {
                                                    $def400++;
                                                    $totdef++;
                                                } elseif ($row["RMK"] == "P") {
                                                    $p400++;
                                                    $totp++;
                                                } elseif ($row["RMK"] == "SP1") {
                                                    $sp1400++;
                                                    $totsp1++;
                                                } else {
                                                    $sp2400++;
                                                    $totsp2++;
                                                }
                                                $totsturmk400++;
                                            }
                                        } else {
                                        }
                                    }
                                }

                                //}
                                //}



                                $totstucd100 = $totstucd200 = $totstucd300 = $totstucd400 = $totstucd500 = 0;
                                $CountFC100 = $CountSCU100 = $CountSCL100 = $CountTC100 = $CountP100 = $CountF100 = 0;
                                $CountFC200 = $CountSCU200 = $CountSCL200 = $CountTC200 = $CountP200 = $CountF200 = 0;
                                $CountFC300 = $CountSCU300 = $CountSCL300 = $CountTC300 = $CountP300 = $CountF300 = 0;
                                $CountFC400 = $CountSCU400 = $CountSCL400 = $CountTC400 = $CountP400 = $CountF400 = 0;
                                $CountFC500 = $CountSCU500 = $CountSCL500 = $CountTC500 = $CountP500 = $CountF500 = 0;

                                $totFC = $totSCU = $totSCL = $totTC = $totP = $totF = 0;
                                //$sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND semester ='$getsemester' AND session1 ='$getsession'";
                                $sql = "SELECT * FROM scrutiny_senate WHERE semester ='$getsemester' AND session1 ='$getsession'";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $cgpa = $row["CGPA"];
                                        if ($_SESSION['InstType'] == "University") {
                                            if ($row["Level1"] == 100) {
                                                if ($row["CGPA"] > 4.49) {
                                                    $CountFC100++;
                                                    $totFC++;
                                                } elseif ($row["CGPA"] > 3.49 && $row["CGPA"] < 4.5) {
                                                    $CountSCU100++;
                                                    $totSCU++;
                                                } elseif ($row["CGPA"] > 2.39 && $row["CGPA"] < 3.5) {
                                                    $CountSCL100++;
                                                    $totSCL++;
                                                } elseif ($row["CGPA"] > 1.49 && $row["CGPA"] < 2.4) {
                                                    $CountTC100++;
                                                    $totTC++;
                                                } elseif ($row["CGPA"] > 0.99 && $row["CGPA"] < 1.5) {
                                                    $CountP100++;
                                                    $totP++;
                                                } else {
                                                    $CountF100++;
                                                    $totF++;
                                                }
                                                $totstucd100++;
                                            } elseif ($row["Level1"] == 200) {
                                                if ($row["CGPA"] > 4.49) {
                                                    $CountFC200++;
                                                    $totFC++;
                                                } elseif ($row["CGPA"] > 3.49 && $row["CGPA"] < 4.5) {
                                                    $CountSCU200++;
                                                    $totSCU++;
                                                } elseif ($row["CGPA"] > 2.39 && $row["CGPA"] < 3.5) {
                                                    $CountSCL200++;
                                                    $totSCL++;
                                                } elseif ($row["CGPA"] > 1.49 && $row["CGPA"] < 2.4) {
                                                    $CountTC200++;
                                                    $totTC++;
                                                } elseif ($row["CGPA"] > 0.99 && $row["CGPA"] < 1.5) {
                                                    $CountP200++;
                                                    $totP++;
                                                } else {
                                                    $CountF200++;
                                                    $totF++;
                                                }

                                                $totstucd200++;
                                            } elseif ($row["Level1"] == 300) {
                                                if ($row["CGPA"] > 4.49) {
                                                    $CountFC300++;
                                                    $totFC++;
                                                } elseif ($row["CGPA"] > 3.49 && $row["CGPA"] < 4.5) {
                                                    $CountSCU300++;
                                                    $totSCU++;
                                                } elseif ($row["CGPA"] > 2.39 && $row["CGPA"] < 3.5) {
                                                    $CountSCL300++;
                                                    $totSCL++;
                                                } elseif ($row["CGPA"] > 1.49 && $row["CGPA"] < 2.4) {
                                                    $CountTC300++;
                                                    $totTC++;
                                                } elseif ($row["CGPA"] > 0.99 && $row["CGPA"] < 1.5) {
                                                    $CountP300++;
                                                    $totP++;
                                                } else {
                                                    $CountF300++;
                                                    $totF++;
                                                }

                                                $totstucd300++;
                                            } elseif ($row["Level1"] == 400) {
                                                if ($row["CGPA"] > 4.49) {
                                                    $CountFC400++;
                                                    $totFC++;
                                                } elseif ($row["CGPA"] > 3.49 && $row["CGPA"] < 4.5) {
                                                    $CountSCU400++;
                                                    $totSCU++;
                                                } elseif ($row["CGPA"] > 2.39 && $row["CGPA"] < 3.5) {
                                                    $CountSCL400++;
                                                    $totSCL++;
                                                } elseif ($row["CGPA"] > 1.49 && $row["CGPA"] < 2.4) {
                                                    $CountTC400++;
                                                    $totTC++;
                                                } elseif ($row["CGPA"] > 0.99 && $row["CGPA"] < 1.5) {
                                                    $CountP400++;
                                                    $totP++;
                                                } else {
                                                    $CountF400++;
                                                    $totF++;
                                                }

                                                $totstucd400++;
                                            } elseif ($row["Level1"] == 500) {
                                                if ($row["CGPA"] > 4.49) {
                                                    $CountFC500++;
                                                    $totFC++;
                                                } elseif ($row["CGPA"] > 3.49 && $row["CGPA"] < 4.5) {
                                                    $CountSCU500++;
                                                    $totSCU++;
                                                } elseif ($row["CGPA"] > 2.39 && $row["CGPA"] < 3.5) {
                                                    $CountSCL500++;
                                                    $totSCL++;
                                                } elseif ($row["CGPA"] > 1.49 && $row["CGPA"] < 2.4) {
                                                    $CountTC500++;
                                                    $totTC++;
                                                } elseif ($row["CGPA"] > 0.99 && $row["CGPA"] < 1.5) {
                                                    $CountP500++;
                                                    $totP++;
                                                } else {
                                                    $CountF500++;
                                                    $totF++;
                                                }

                                                $totstucd500++;
                                            }
                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                            if ($row["Level1"] == 100) {
                                                if ($cgpa >= 3.5) {
                                                    $CountFC100++;
                                                    $totFC++;
                                                } elseif ($cgpa >= 3) {
                                                    $CountSCU100++;
                                                    $totSCU++;
                                                } elseif ($cgpa >= 2.5) {
                                                    $CountSCL100++;
                                                    $totSCL++;
                                                } elseif ($cgpa >= 2) {
                                                    $CountP100++;
                                                    $totP++;
                                                } else {
                                                    $CountF100++;
                                                    $totF++;
                                                }

                                                $totstucd100++;
                                            } elseif ($row["Level1"] == 200) {
                                                if ($cgpa >= 3.5) {
                                                    $CountFC200++;
                                                    $totFC++;
                                                } elseif ($cgpa >= 3) {
                                                    $CountSCU200++;
                                                    $totSCU++;
                                                } elseif ($cgpa >= 2.5) {
                                                    $CountSCL200++;
                                                    $totSCL++;
                                                } elseif ($cgpa >= 2) {
                                                    $CountP200++;
                                                    $totP++;
                                                } else {
                                                    $CountF200++;
                                                    $totF++;
                                                }

                                                $totstucd200++;
                                            } elseif ($row["Level1"] == 300) {
                                                if ($cgpa >= 3.5) {
                                                    $CountFC300++;
                                                    $totFC++;
                                                } elseif ($cgpa >= 3) {
                                                    $CountSCU300++;
                                                    $totSCU++;
                                                } elseif ($cgpa >= 2.5) {
                                                    $CountSCL300++;
                                                    $totSCL++;
                                                } elseif ($cgpa >= 2) {
                                                    $CountP300++;
                                                    $totP++;
                                                } else {
                                                    $CountF300++;
                                                    $totF++;
                                                }

                                                $totstucd300++;
                                            } elseif ($row["Level1"] == 400) {
                                                if ($cgpa >= 3.5) {
                                                    $CountFC400++;
                                                    $totFC++;
                                                } elseif ($cgpa >= 3) {
                                                    $CountSCU400++;
                                                    $totSCU++;
                                                } elseif ($cgpa >= 2.5) {
                                                    $CountSCL400++;
                                                    $totSCL++;
                                                } elseif ($cgpa >= 2) {
                                                    $CountP400++;
                                                    $totP++;
                                                } else {
                                                    $CountF400++;
                                                    $totF++;
                                                }

                                                $totstucd400++;
                                            }
                                        } else {
                                        }
                                    }
                                }
                                $conn->close();
                                $conn2->close();
                                $conn_stu->close();
                                ?>

                                <br>
                                <div class="col-lg-12">



                                    <div class="row" style="font-size: 16px">
                                        <div class="col-lg-6">
                                            Department: <?php echo $deptname; ?>
                                        </div>

                                        <div class="col-lg-3">
                                            Session: <?php echo $_SESSION['getsession_sctny']; ?>
                                        </div>
                                        <div class="col-lg-3">
                                            Semester: <?php echo $_SESSION['getsemester_sctny']; ?>
                                        </div>

                                    </div>
                                    <hr class="separator" />

                                    <h2>Students' Performance</h2>
                                    <div class="row">
                                        <div class="col-lg-6">

                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    Bar Chart
                                                </div>
                                                <div class="panel-body">
                                                    <canvas id="barChart" height="140"></canvas>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="panel panel-primary">
                                                <div class="panel-heading">
                                                    Line Chart
                                                </div>
                                                <div class="panel-body">
                                                    <canvas id="lineChart" height="140"></canvas>
                                                </div>
                                            </div>
                                        </div>
                                        <h2>Class of Degree</h2>

                                        <div class="row">
                                            <div class="col-lg-6">

                                                <div class="panel panel-primary">
                                                    <div class="panel-heading">
                                                        Bar Chart
                                                    </div>
                                                    <div class="panel-body">
                                                        <canvas id="barChart2" height="140"></canvas>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">

                                                <div class="panel panel-primary">
                                                    <div class="panel-heading">
                                                        Line Chart
                                                    </div>
                                                    <div class="panel-body">
                                                        <canvas id="lineChart2" height="140"></canvas>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>










                                        <h2>Results</h2>
                                        <?php $totalperfo = $totvl + $totdl + $totigs + $totdef + $totp + $totsp1 + $totsp2; ?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <table style="width: 100%" class="table table-hover">
                                                    <?php if ($_SESSION['InstType'] == "University") { ?>
                                                        <thead>
                                                            <tr>

                                                                <th>Remark</th>
                                                                <th>100 Level</th>
                                                                <th>200 Level</th>
                                                                <th>300 Level</th>
                                                                <th>400 Level</th>
                                                                <th>500 Level</th>
                                                                <th>Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <tr>
                                                                <td>VL</td>
                                                                <td><?php echo $vl100; ?></td>
                                                                <td><?php echo $vl200; ?></td>
                                                                <td><?php echo $vl300; ?></td>
                                                                <td><?php echo $vl400; ?></td>
                                                                <td><?php echo $vl500; ?></td>
                                                                <td><?php echo $totvl; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>DL</td>
                                                                <td><?php echo $dl100; ?></td>
                                                                <td><?php echo $dl200; ?></td>
                                                                <td><?php echo $dl300; ?></td>
                                                                <td><?php echo $dl400; ?></td>
                                                                <td><?php echo $dl500; ?></td>
                                                                <td><?php echo $totdl; ?></td>
                                                            </tr>

                                                            <tr>
                                                                <td>IGS</td>
                                                                <td><?php echo $igs100; ?></td>
                                                                <td><?php echo $igs200; ?></td>
                                                                <td><?php echo $igs300; ?></td>
                                                                <td><?php echo $igs400; ?></td>
                                                                <td><?php echo $igs500; ?></td>
                                                                <td><?php echo $totigs; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>DEF</td>
                                                                <td><?php echo $def100; ?></td>
                                                                <td><?php echo $def200; ?></td>
                                                                <td><?php echo $def300; ?></td>
                                                                <td><?php echo $def400; ?></td>
                                                                <td><?php echo $def500; ?></td>
                                                                <td><?php echo $totdef; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>P</td>
                                                                <td><?php echo $p100; ?></td>
                                                                <td><?php echo $p200; ?></td>
                                                                <td><?php echo $p300; ?></td>
                                                                <td><?php echo $p400; ?></td>
                                                                <td><?php echo $p500; ?></td>
                                                                <td><?php echo $totp; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>SP1</td>
                                                                <td><?php echo $sp1100; ?></td>
                                                                <td><?php echo $sp1200; ?></td>
                                                                <td><?php echo $sp1300; ?></td>
                                                                <td><?php echo $sp1400; ?></td>
                                                                <td><?php echo $sp1500; ?></td>
                                                                <td><?php echo $totsp1; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>SP2</td>
                                                                <td><?php echo $sp2100; ?></td>
                                                                <td><?php echo $sp2200; ?></td>
                                                                <td><?php echo $sp2300; ?></td>
                                                                <td><?php echo $sp2400; ?></td>
                                                                <td><?php echo $sp2500; ?></td>
                                                                <td><?php echo $totsp2; ?></td>
                                                            </tr>

                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <th>Total</th>
                                                                <th><?php echo $totsturmk100; ?></th>
                                                                <th><?php echo $totsturmk200; ?></th>
                                                                <th><?php echo $totsturmk300; ?></th>
                                                                <th><?php echo $totsturmk400; ?></th>
                                                                <th><?php echo $totsturmk500; ?></th>
                                                                <th><?php echo $totalperfo; ?></th>
                                                            </tr>
                                                        </tfoot>
                                                    <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                        <thead>
                                                            <tr>

                                                                <th>Remark</th>
                                                                <th>ND I</th>
                                                                <th>ND II</th>
                                                                <th>HND I</th>
                                                                <th>HND II</th>
                                                                <th>Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <tr>
                                                                <td>RHL</td>
                                                                <td><?php echo $vl100; ?></td>
                                                                <td><?php echo $vl200; ?></td>
                                                                <td><?php echo $vl300; ?></td>
                                                                <td><?php echo $vl400; ?></td>
                                                                <td><?php echo $totvl; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>DHL</td>
                                                                <td><?php echo $dl100; ?></td>
                                                                <td><?php echo $dl200; ?></td>
                                                                <td><?php echo $dl300; ?></td>
                                                                <td><?php echo $dl400; ?></td>
                                                                <td><?php echo $totdl; ?></td>
                                                            </tr>

                                                            <tr>
                                                                <td>IGS</td>
                                                                <td><?php echo $igs100; ?></td>
                                                                <td><?php echo $igs200; ?></td>
                                                                <td><?php echo $igs300; ?></td>
                                                                <td><?php echo $igs400; ?></td>
                                                                <td><?php echo $totigs; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>COV</td>
                                                                <td><?php echo $def100; ?></td>
                                                                <td><?php echo $def200; ?></td>
                                                                <td><?php echo $def300; ?></td>
                                                                <td><?php echo $def400; ?></td>
                                                                <td><?php echo $totdef; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>PRO</td>
                                                                <td><?php echo $p100; ?></td>
                                                                <td><?php echo $p200; ?></td>
                                                                <td><?php echo $p300; ?></td>
                                                                <td><?php echo $p400; ?></td>
                                                                <td><?php echo $totp; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>WAR</td>
                                                                <td><?php echo $sp1100; ?></td>
                                                                <td><?php echo $sp1200; ?></td>
                                                                <td><?php echo $sp1300; ?></td>
                                                                <td><?php echo $sp1400; ?></td>
                                                                <td><?php echo $totsp1; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>WD</td>
                                                                <td><?php echo $sp2100; ?></td>
                                                                <td><?php echo $sp2200; ?></td>
                                                                <td><?php echo $sp2300; ?></td>
                                                                <td><?php echo $sp2400; ?></td>
                                                                <td><?php echo $totsp2; ?></td>
                                                            </tr>

                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <th>Total</th>
                                                                <th><?php echo $totsturmk100; ?></th>
                                                                <th><?php echo $totsturmk200; ?></th>
                                                                <th><?php echo $totsturmk300; ?></th>
                                                                <th><?php echo $totsturmk400; ?></th>
                                                                <th><?php echo $totalperfo; ?></th>
                                                            </tr>
                                                        </tfoot>
                                                    <?php } else { ?>

                                                    <?php } ?>
                                                </table>

                                            </div>

                                            <?php $totclass = $totFC + $totSCU + $totSCL + $totTC + $totP + $totF; ?>
                                            <div class="col-md-6">
                                                <table style="width: 100%" class="table table-hover">
                                                    <?php if ($_SESSION['InstType'] == "University") { ?>
                                                        <thead>
                                                            <tr>

                                                                <th>Class of Degree</th>
                                                                <th>100 Level</th>
                                                                <th>200 Level</th>
                                                                <th>300 Level</th>
                                                                <th>400 Level</th>
                                                                <th>500 Level</th>
                                                                <th>Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <tr>
                                                                <td>First Class</td>
                                                                <td><?php echo $CountFC100; ?></td>
                                                                <td><?php echo $CountFC200; ?></td>
                                                                <td><?php echo $CountFC300; ?></td>
                                                                <td><?php echo $CountFC400; ?></td>
                                                                <td><?php echo $CountFC500; ?></td>
                                                                <td><?php echo $totFC; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Second Class Upper</td>
                                                                <td><?php echo $CountSCU100; ?></td>
                                                                <td><?php echo $CountSCU200; ?></td>
                                                                <td><?php echo $CountSCU300; ?></td>
                                                                <td><?php echo $CountSCU400; ?></td>
                                                                <td><?php echo $CountSCU500; ?></td>
                                                                <td><?php echo $totSCU; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Second Class Lower</td>
                                                                <td><?php echo $CountSCL100; ?></td>
                                                                <td><?php echo $CountSCL200; ?></td>
                                                                <td><?php echo $CountSCL300; ?></td>
                                                                <td><?php echo $CountSCL400; ?></td>
                                                                <td><?php echo $CountSCL500; ?></td>
                                                                <td><?php echo $totSCL; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Third Class</td>
                                                                <td><?php echo $CountTC100; ?></td>
                                                                <td><?php echo $CountTC200; ?></td>
                                                                <td><?php echo $CountTC300; ?></td>
                                                                <td><?php echo $CountTC400; ?></td>
                                                                <td><?php echo $CountTC500; ?></td>
                                                                <td><?php echo $totTC; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Pass</td>
                                                                <td><?php echo $CountP100; ?></td>
                                                                <td><?php echo $CountP200; ?></td>
                                                                <td><?php echo $CountP300; ?></td>
                                                                <td><?php echo $CountP400; ?></td>
                                                                <td><?php echo $CountP500; ?></td>
                                                                <td><?php echo $totP; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Fail</td>
                                                                <td><?php echo $CountF100; ?></td>
                                                                <td><?php echo $CountF200; ?></td>
                                                                <td><?php echo $CountF300; ?></td>
                                                                <td><?php echo $CountF400; ?></td>
                                                                <td><?php echo $CountF500; ?></td>
                                                                <td><?php echo $totF; ?></td>
                                                            </tr>

                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <th>Total</th>
                                                                <th><?php echo $totstucd100; ?></th>
                                                                <th><?php echo $totstucd200; ?></th>
                                                                <th><?php echo $totstucd300; ?></th>
                                                                <th><?php echo $totstucd400; ?></th>
                                                                <th><?php echo $totstucd500; ?></th>
                                                                <th><?php echo $totclass; ?></th>
                                                            </tr>
                                                        </tfoot>
                                                    <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                        <thead>
                                                            <tr>

                                                                <th>Class</th>
                                                                <th>ND I</th>
                                                                <th>ND II</th>
                                                                <th>HND I</th>
                                                                <th>HND II</th>
                                                                <th>Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <tr>
                                                                <td>Distinction</td>
                                                                <td><?php echo $CountFC100; ?></td>
                                                                <td><?php echo $CountFC200; ?></td>
                                                                <td><?php echo $CountFC300; ?></td>
                                                                <td><?php echo $CountFC400; ?></td>
                                                                <td><?php echo $totFC; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Upper Credit</td>
                                                                <td><?php echo $CountSCU100; ?></td>
                                                                <td><?php echo $CountSCU200; ?></td>
                                                                <td><?php echo $CountSCU300; ?></td>
                                                                <td><?php echo $CountSCU400; ?></td>
                                                                <td><?php echo $totSCU; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Lower Credit</td>
                                                                <td><?php echo $CountSCL100; ?></td>
                                                                <td><?php echo $CountSCL200; ?></td>
                                                                <td><?php echo $CountSCL300; ?></td>
                                                                <td><?php echo $CountSCL400; ?></td>
                                                                <td><?php echo $totSCL; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Pass</td>
                                                                <td><?php echo $CountP100; ?></td>
                                                                <td><?php echo $CountP200; ?></td>
                                                                <td><?php echo $CountP300; ?></td>
                                                                <td><?php echo $CountP400; ?></td>
                                                                <td><?php echo $totP; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Fail</td>
                                                                <td><?php echo $CountF100; ?></td>
                                                                <td><?php echo $CountF200; ?></td>
                                                                <td><?php echo $CountF300; ?></td>
                                                                <td><?php echo $CountF400; ?></td>
                                                                <td><?php echo $totF; ?></td>
                                                            </tr>

                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <th>Total</th>
                                                                <th><?php echo $totstucd100; ?></th>
                                                                <th><?php echo $totstucd200; ?></th>
                                                                <th><?php echo $totstucd300; ?></th>
                                                                <th><?php echo $totstucd400; ?></th>
                                                                <th><?php echo $totclass; ?></th>
                                                            </tr>
                                                        </tfoot>
                                                    <?php } else { ?>

                                                    <?php } ?>
                                                </table>

                                            </div>
                                        </div>

                                    </div>

                                <?php } ?>


                                </div>
                        </div>



                    </div>
                </div>

                <div class="footer">
                    <?php
                    include_once 'includes/footer2.php';
                    ?>
                </div>
            </div>
            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>
        <!-- ChartJS-->
        <script src="js/plugins/chartJs/Chart.min.js"></script>
        <!-- <script src="js/demo/chartjs-demo.js"></script> -->







        <script>
            $(function() {
                <?php if ($_SESSION['InstType'] == "University") { ?>
                    var lineData = {
                        labels: ["VL", "DL", "IGS", "DEF", "P", "SP1", "SP2"],
                        datasets: [

                            {
                                label: "100 Level",
                                backgroundColor: 'rgba(153, 255, 51, 0.5)',
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl100; ?>, <?php echo $dl100; ?>, <?php echo $igs100; ?>,
                                    <?php echo $def100; ?>, <?php echo $p100; ?>, <?php echo $sp1100; ?>,
                                    <?php echo $sp2100; ?>
                                ]
                            },
                            {
                                label: "200 Level",
                                backgroundColor: 'rgba(51, 204, 204,0.5)',
                                borderColor: "rgba(51, 204, 204,0.7)",
                                pointBackgroundColor: "rgba(51, 204, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl200; ?>, <?php echo $dl200; ?>, <?php echo $igs200; ?>,
                                    <?php echo $def200; ?>, <?php echo $p200; ?>, <?php echo $sp1200; ?>,
                                    <?php echo $sp2200; ?>
                                ]
                            },
                            {
                                label: "300 Level",
                                backgroundColor: 'rgba(155, 89, 182,0.5)',
                                borderColor: "rgba(155, 89, 182,0.7)",
                                pointBackgroundColor: "rgba(155, 89, 182,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl300; ?>, <?php echo $dl300; ?>, <?php echo $igs300; ?>,
                                    <?php echo $def300; ?>, <?php echo $p300; ?>, <?php echo $sp1300; ?>,
                                    <?php echo $sp2300; ?>
                                ]
                            },
                            {
                                label: "400 Level",
                                backgroundColor: 'rgba(0, 51, 204,0.5)',
                                borderColor: "rgba(0, 51, 204,0.7)",
                                pointBackgroundColor: "rgba(0, 51, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl400; ?>, <?php echo $dl400; ?>, <?php echo $igs400; ?>,
                                    <?php echo $def400; ?>, <?php echo $p400; ?>, <?php echo $sp1400; ?>,
                                    <?php echo $sp2400; ?>
                                ]
                            },
                            {
                                label: "500 Level",
                                backgroundColor: 'rgba(40, 180, 99,0.5)',
                                borderColor: "rgba(40, 180, 99,0.7)",
                                pointBackgroundColor: "rgba(40, 180, 99,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl500; ?>, <?php echo $dl500; ?>, <?php echo $igs500; ?>,
                                    <?php echo $def500; ?>, <?php echo $p500; ?>, <?php echo $sp1500; ?>,
                                    <?php echo $sp2500; ?>
                                ]
                            }
                        ]
                    };

                    var lineOptions = {
                        responsive: true
                    };


                    var ctx = document.getElementById("lineChart").getContext("2d");
                    new Chart(ctx, {
                        type: 'line',
                        data: lineData,
                        options: lineOptions
                    });
                <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                    var lineData = {
                        labels: ["RHL", "DHL", "IGS", "COV", "PRO", "WAR", "WD"],
                        datasets: [

                            {
                                label: "ND I",
                                backgroundColor: 'rgba(153, 255, 51, 0.5)',
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl100; ?>, <?php echo $dl100; ?>, <?php echo $igs100; ?>,
                                    <?php echo $def100; ?>, <?php echo $p100; ?>, <?php echo $sp1100; ?>,
                                    <?php echo $sp2100; ?>
                                ]
                            },
                            {
                                label: "ND II",
                                backgroundColor: 'rgba(51, 204, 204,0.5)',
                                borderColor: "rgba(51, 204, 204,0.7)",
                                pointBackgroundColor: "rgba(51, 204, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl200; ?>, <?php echo $dl200; ?>, <?php echo $igs200; ?>,
                                    <?php echo $def200; ?>, <?php echo $p200; ?>, <?php echo $sp1200; ?>,
                                    <?php echo $sp2200; ?>
                                ]
                            },
                            {
                                label: "HND I",
                                backgroundColor: 'rgba(155, 89, 182,0.5)',
                                borderColor: "rgba(155, 89, 182,0.7)",
                                pointBackgroundColor: "rgba(155, 89, 182,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl300; ?>, <?php echo $dl300; ?>, <?php echo $igs300; ?>,
                                    <?php echo $def300; ?>, <?php echo $p300; ?>, <?php echo $sp1300; ?>,
                                    <?php echo $sp2300; ?>
                                ]
                            },
                            {
                                label: "HND II",
                                backgroundColor: 'rgba(0, 51, 204,0.5)',
                                borderColor: "rgba(0, 51, 204,0.7)",
                                pointBackgroundColor: "rgba(0, 51, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl400; ?>, <?php echo $dl400; ?>, <?php echo $igs400; ?>,
                                    <?php echo $def400; ?>, <?php echo $p400; ?>, <?php echo $sp1400; ?>,
                                    <?php echo $sp2400; ?>
                                ]
                            }
                        ]
                    };

                    var lineOptions = {
                        responsive: true
                    };


                    var ctx = document.getElementById("lineChart").getContext("2d");
                    new Chart(ctx, {
                        type: 'line',
                        data: lineData,
                        options: lineOptions
                    });
                <?php } else { ?>

                <?php } ?>


                <?php if ($_SESSION['InstType'] == "University") { ?>
                    var lineData2 = {
                        labels: ["First Class", "Second Class Upper", "Second Class Lower", "Third Class", "Pass",
                            "Fail"
                        ],
                        datasets: [

                            {
                                label: "100 Level",
                                backgroundColor: 'rgba(153, 255, 51, 0.5)',
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC100; ?>, <?php echo $CountSCU100; ?>,
                                    <?php echo $CountSCL100; ?>,
                                    <?php echo $CountTC100; ?>, <?php echo $CountP100; ?>,
                                    <?php echo $CountF100; ?>
                                ]
                            },
                            {
                                label: "200 Level",
                                backgroundColor: 'rgba(51, 204, 204,0.5)',
                                borderColor: "rgba(51, 204, 204,0.7)",
                                pointBackgroundColor: "rgba(51, 204, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC200; ?>, <?php echo $CountSCU200; ?>,
                                    <?php echo $CountSCL200; ?>,
                                    <?php echo $CountTC200; ?>, <?php echo $CountP200; ?>,
                                    <?php echo $CountF200; ?>
                                ]
                            },
                            {
                                label: "300 Level",
                                backgroundColor: 'rgba(155, 89, 182,0.5)',
                                borderColor: "rgba(155, 89, 182,0.7)",
                                pointBackgroundColor: "rgba(155, 89, 182,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC300; ?>, <?php echo $CountSCU300; ?>,
                                    <?php echo $CountSCL300; ?>,
                                    <?php echo $CountTC300; ?>, <?php echo $CountP300; ?>,
                                    <?php echo $CountF300; ?>
                                ]
                            },
                            {
                                label: "400 Level",
                                backgroundColor: 'rgba(0, 51, 204,0.5)',
                                borderColor: "rgba(0, 51, 204,0.7)",
                                pointBackgroundColor: "rgba(0, 51, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC400; ?>, <?php echo $CountSCU400; ?>,
                                    <?php echo $CountSCL400; ?>,
                                    <?php echo $CountTC400; ?>, <?php echo $CountP400; ?>,
                                    <?php echo $CountF400; ?>
                                ]
                            },
                            {
                                label: "500 Level",
                                backgroundColor: 'rgba(40, 180, 99,0.5)',
                                borderColor: "rgba(40, 180, 99,0.7)",
                                pointBackgroundColor: "rgba(40, 180, 99,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC500; ?>, <?php echo $CountSCU500; ?>,
                                    <?php echo $CountSCL500; ?>,
                                    <?php echo $CountTC500; ?>, <?php echo $CountP500; ?>,
                                    <?php echo $CountF500; ?>
                                ]
                            }
                        ]
                    };

                    var lineOptions2 = {
                        responsive: true
                    };


                    var ctx2 = document.getElementById("lineChart2").getContext("2d");
                    new Chart(ctx2, {
                        type: 'line',
                        data: lineData2,
                        options: lineOptions2
                    });
                <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                    var lineData2 = {
                        labels: ["Distinction", "Upper Credit", "Lower Credit", "Pass", "Fail"],
                        datasets: [

                            {
                                label: "ND I",
                                backgroundColor: 'rgba(153, 255, 51, 0.5)',
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC100; ?>, <?php echo $CountSCU100; ?>,
                                    <?php echo $CountSCL100; ?>, <?php echo $CountP100; ?>,
                                    <?php echo $CountF100; ?>
                                ]
                            },
                            {
                                label: "ND II",
                                backgroundColor: 'rgba(51, 204, 204,0.5)',
                                borderColor: "rgba(51, 204, 204,0.7)",
                                pointBackgroundColor: "rgba(51, 204, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC200; ?>, <?php echo $CountSCU200; ?>,
                                    <?php echo $CountSCL200; ?>, <?php echo $CountP200; ?>,
                                    <?php echo $CountF200; ?>
                                ]
                            },
                            {
                                label: "HND I",
                                backgroundColor: 'rgba(155, 89, 182,0.5)',
                                borderColor: "rgba(155, 89, 182,0.7)",
                                pointBackgroundColor: "rgba(155, 89, 182,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC300; ?>, <?php echo $CountSCU300; ?>,
                                    <?php echo $CountSCL300; ?>, <?php echo $CountP300; ?>,
                                    <?php echo $CountF300; ?>
                                ]
                            },
                            {
                                label: "HND II",
                                backgroundColor: 'rgba(0, 51, 204,0.5)',
                                borderColor: "rgba(0, 51, 204,0.7)",
                                pointBackgroundColor: "rgba(0, 51, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC400; ?>, <?php echo $CountSCU400; ?>,
                                    <?php echo $CountSCL400; ?>, <?php echo $CountP400; ?>,
                                    <?php echo $CountF400; ?>
                                ]
                            }
                        ]
                    };

                    var lineOptions2 = {
                        responsive: true
                    };


                    var ctx2 = document.getElementById("lineChart2").getContext("2d");
                    new Chart(ctx2, {
                        type: 'line',
                        data: lineData2,
                        options: lineOptions2
                    });
                <?php } else { ?>

                <?php } ?>




                <?php if ($_SESSION['InstType'] == "University") { ?>
                    var barData = {
                        labels: ["VL", "DL", "IGS", "DEF", "P", "SP1", "SP2"],
                        datasets: [{
                                label: "100 Level",
                                backgroundColor: 'rgba(153, 255, 51, 0.5)',
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl100; ?>, <?php echo $dl100; ?>, <?php echo $igs100; ?>,
                                    <?php echo $def100; ?>, <?php echo $p100; ?>, <?php echo $sp1100; ?>,
                                    <?php echo $sp2100; ?>
                                ]
                            },
                            {
                                label: "200 Level",
                                backgroundColor: 'rgba(51, 204, 204,0.5)',
                                borderColor: "rgba(51, 204, 204,0.7)",
                                pointBackgroundColor: "rgba(51, 204, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl200; ?>, <?php echo $dl200; ?>, <?php echo $igs200; ?>,
                                    <?php echo $def200; ?>, <?php echo $p200; ?>, <?php echo $sp1200; ?>,
                                    <?php echo $sp2200; ?>
                                ]
                            },
                            {
                                label: "300 Level",
                                backgroundColor: 'rgba(155, 89, 182,0.5)',
                                borderColor: "rgba(155, 89, 182,0.7)",
                                pointBackgroundColor: "rgba(155, 89, 182,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl300; ?>, <?php echo $dl300; ?>, <?php echo $igs300; ?>,
                                    <?php echo $def300; ?>, <?php echo $p300; ?>, <?php echo $sp1300; ?>,
                                    <?php echo $sp2300; ?>
                                ]
                            },
                            {
                                label: "400 Level",
                                backgroundColor: 'rgba(0, 51, 204,0.5)',
                                borderColor: "rgba(0, 51, 204,0.7)",
                                pointBackgroundColor: "rgba(0, 51, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl400; ?>, <?php echo $dl400; ?>, <?php echo $igs400; ?>,
                                    <?php echo $def400; ?>, <?php echo $p400; ?>, <?php echo $sp1400; ?>,
                                    <?php echo $sp2400; ?>
                                ]
                            },
                            {
                                label: "500 Level",
                                backgroundColor: 'rgba(40, 180, 99,0.5)',
                                borderColor: "rgba(40, 180, 99,0.7)",
                                pointBackgroundColor: "rgba(40, 180, 99,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl500; ?>, <?php echo $dl500; ?>, <?php echo $igs500; ?>,
                                    <?php echo $def500; ?>, <?php echo $p500; ?>, <?php echo $sp1500; ?>,
                                    <?php echo $sp2500; ?>
                                ]
                            }
                        ]
                    };

                    var barOptions = {
                        responsive: true
                    };


                    var ctx2 = document.getElementById("barChart").getContext("2d");
                    new Chart(ctx2, {
                        type: 'bar',
                        data: barData,
                        options: barOptions
                    });
                <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                    var barData = {
                        labels: ["RHL", "DHL", "IGS", "COV", "PRO", "WAR", "WD"],
                        datasets: [{
                                label: "ND I",
                                backgroundColor: 'rgba(153, 255, 51, 0.5)',
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl100; ?>, <?php echo $dl100; ?>, <?php echo $igs100; ?>,
                                    <?php echo $def100; ?>, <?php echo $p100; ?>, <?php echo $sp1100; ?>,
                                    <?php echo $sp2100; ?>
                                ]
                            },
                            {
                                label: "ND II",
                                backgroundColor: 'rgba(51, 204, 204,0.5)',
                                borderColor: "rgba(51, 204, 204,0.7)",
                                pointBackgroundColor: "rgba(51, 204, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl200; ?>, <?php echo $dl200; ?>, <?php echo $igs200; ?>,
                                    <?php echo $def200; ?>, <?php echo $p200; ?>, <?php echo $sp1200; ?>,
                                    <?php echo $sp2200; ?>
                                ]
                            },
                            {
                                label: "HND I",
                                backgroundColor: 'rgba(155, 89, 182,0.5)',
                                borderColor: "rgba(155, 89, 182,0.7)",
                                pointBackgroundColor: "rgba(155, 89, 182,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl300; ?>, <?php echo $dl300; ?>, <?php echo $igs300; ?>,
                                    <?php echo $def300; ?>, <?php echo $p300; ?>, <?php echo $sp1300; ?>,
                                    <?php echo $sp2300; ?>
                                ]
                            },
                            {
                                label: "HND II",
                                backgroundColor: 'rgba(0, 51, 204,0.5)',
                                borderColor: "rgba(0, 51, 204,0.7)",
                                pointBackgroundColor: "rgba(0, 51, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $vl400; ?>, <?php echo $dl400; ?>, <?php echo $igs400; ?>,
                                    <?php echo $def400; ?>, <?php echo $p400; ?>, <?php echo $sp1400; ?>,
                                    <?php echo $sp2400; ?>
                                ]
                            }
                        ]
                    };

                    var barOptions = {
                        responsive: true
                    };


                    var ctx2 = document.getElementById("barChart").getContext("2d");
                    new Chart(ctx2, {
                        type: 'bar',
                        data: barData,
                        options: barOptions
                    });
                <?php } else { ?>

                <?php } ?>



                <?php if ($_SESSION['InstType'] == "University") { ?>
                    var barData2 = {
                        labels: ["First Class", "Second Class Upper", "Second Class Lower", "Third Class", "Pass",
                            "Fail"
                        ],
                        datasets: [{
                                label: "100 Level",
                                backgroundColor: 'rgba(153, 255, 51, 0.5)',
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC100; ?>, <?php echo $CountSCU100; ?>,
                                    <?php echo $CountSCL100; ?>,
                                    <?php echo $CountTC100; ?>, <?php echo $CountP100; ?>,
                                    <?php echo $CountF100; ?>
                                ]
                            },
                            {
                                label: "200 Level",
                                backgroundColor: 'rgba(51, 204, 204,0.5)',
                                borderColor: "rgba(51, 204, 204,0.7)",
                                pointBackgroundColor: "rgba(51, 204, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC200; ?>, <?php echo $CountSCU200; ?>,
                                    <?php echo $CountSCL200; ?>,
                                    <?php echo $CountTC200; ?>, <?php echo $CountP200; ?>,
                                    <?php echo $CountF200; ?>
                                ]
                            },
                            {
                                label: "300 Level",
                                backgroundColor: 'rgba(155, 89, 182,0.5)',
                                borderColor: "rgba(155, 89, 182,0.7)",
                                pointBackgroundColor: "rgba(155, 89, 182,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC300; ?>, <?php echo $CountSCU300; ?>,
                                    <?php echo $CountSCL300; ?>,
                                    <?php echo $CountTC300; ?>, <?php echo $CountP300; ?>,
                                    <?php echo $CountF300; ?>
                                ]
                            },
                            {
                                label: "400 Level",
                                backgroundColor: 'rgba(0, 51, 204,0.5)',
                                borderColor: "rgba(0, 51, 204,0.7)",
                                pointBackgroundColor: "rgba(0, 51, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC400; ?>, <?php echo $CountSCU400; ?>,
                                    <?php echo $CountSCL400; ?>,
                                    <?php echo $CountTC400; ?>, <?php echo $CountP400; ?>,
                                    <?php echo $CountF400; ?>
                                ]
                            },
                            {
                                label: "500 Level",
                                backgroundColor: 'rgba(40, 180, 99,0.5)',
                                borderColor: "rgba(40, 180, 99,0.7)",
                                pointBackgroundColor: "rgba(40, 180, 99,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC500; ?>, <?php echo $CountSCU500; ?>,
                                    <?php echo $CountSCL500; ?>,
                                    <?php echo $CountTC500; ?>, <?php echo $CountP500; ?>,
                                    <?php echo $CountF500; ?>
                                ]
                            }
                        ]
                    };

                    var barOptions2 = {
                        responsive: true
                    };


                    var ctx22 = document.getElementById("barChart2").getContext("2d");
                    new Chart(ctx22, {
                        type: 'bar',
                        data: barData2,
                        options: barOptions2
                    });
                <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                    var barData2 = {
                        labels: ["Distinction", "Upper Credit", "Lower Credit", "Pass", "Fail"],
                        datasets: [{
                                label: "ND I",
                                backgroundColor: 'rgba(153, 255, 51, 0.5)',
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC100; ?>, <?php echo $CountSCU100; ?>,
                                    <?php echo $CountSCL100; ?>, <?php echo $CountP100; ?>,
                                    <?php echo $CountF100; ?>
                                ]
                            },
                            {
                                label: "ND II",
                                backgroundColor: 'rgba(51, 204, 204,0.5)',
                                borderColor: "rgba(51, 204, 204,0.7)",
                                pointBackgroundColor: "rgba(51, 204, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC200; ?>, <?php echo $CountSCU200; ?>,
                                    <?php echo $CountSCL200; ?>, <?php echo $CountP200; ?>,
                                    <?php echo $CountF200; ?>
                                ]
                            },
                            {
                                label: "HND I",
                                backgroundColor: 'rgba(155, 89, 182,0.5)',
                                borderColor: "rgba(155, 89, 182,0.7)",
                                pointBackgroundColor: "rgba(155, 89, 182,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC300; ?>, <?php echo $CountSCU300; ?>,
                                    <?php echo $CountSCL300; ?>, <?php echo $CountP300; ?>,
                                    <?php echo $CountF300; ?>
                                ]
                            },
                            {
                                label: "HND II",
                                backgroundColor: 'rgba(0, 51, 204,0.5)',
                                borderColor: "rgba(0, 51, 204,0.7)",
                                pointBackgroundColor: "rgba(0, 51, 204,1)",
                                pointBorderColor: "#fff",
                                data: [<?php echo $CountFC400; ?>, <?php echo $CountSCU400; ?>,
                                    <?php echo $CountSCL400; ?>, <?php echo $CountP400; ?>,
                                    <?php echo $CountF400; ?>
                                ]
                            }
                        ]
                    };

                    var barOptions2 = {
                        responsive: true
                    };


                    var ctx22 = document.getElementById("barChart2").getContext("2d");
                    new Chart(ctx22, {
                        type: 'bar',
                        data: barData2,
                        options: barOptions2
                    });
                <?php } else { ?>

                <?php } ?>








            });
        </script>
</body>

</html>
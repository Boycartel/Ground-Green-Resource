<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pg_project_alocation'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <script src="assets/javascripts/tableToExcel_qap.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>


</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Defence Request</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-support (alias)"></i>
                                </a>
                            </li>
                            <li><span>PG Pregress Report</span></li>
                            <li><span>Defence Request</span></li>
                        </ol>


                    </div>
                </header>
                <?php
                $dept = $_SESSION['deptcode'];
                $corntsession = $_SESSION['corntsession'];

                ?>
                <!-- start: page -->
                <div class="row">
                    <form class="form-horizontal" method="post" action="">

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Session Admitted:</label>
                            <div class="col-sm-2">

                                <?php
                                $iniyear = 2018;
                                $finalyear = substr($_SESSION['corntsession'], 5);

                                ?>
                                <select name="sessionadmt" class="form-control" style="color:#000000" required="required">

                                    <option></option>
                                    <?php
                                    while ($iniyear <= $finalyear) {
                                        $addyear = $iniyear + 1;

                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                        $iniyear++;
                                    }

                                    ?>

                                </select>
                            </div>
                            <label class="col-sm-3 control-label">Programme Title:</label>
                            <div class="col-sm-2">
                                <select class="form-control m-bot15" name="progtitle" required="required">
                                    <option value=""></option>
                                    <option value="PGD">PGD</option>
                                    <option value="M.Tech">M.Tech</option>
                                    <option value="M.Eng">M.Eng</option>
                                    <option value="Masters">Professional Masters</option>
                                    <option value="Ph.D">Ph.D</option>

                                </select>
                            </div>
                            <div class="col-sm-2" style="text-align:center">
                                <button type="submit" name="submit" class="btn btn-info">Submit</button>
                            </div>
                        </div>


                    </form>
                </div>
                <hr class="separator" />
                <div class="row">

                    <div class="col-lg-12  col-md-12">

                        <div class="col-lg-12">
                            <section class="panel panel-success">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>

                                    <h2 class="panel-title">Defence Request</h2>
                                </header>
                                <div class="panel-body">

                                    <?php
                                    if (isset($_POST["makerequest"])) {

                                        $progtitle = $_SESSION["progtitle"];
                                        $sessionadmt = $_SESSION["sessionadmt"];
                                        $regid2 = $_POST['regid2'];
                                        $name2 = $_POST['name2'];
                                        $getdeftype = $_POST['getdeftype'];
                                        $propdate = $_POST['propdate'];
                                        $propdate = date('d F, Y', strtotime($propdate));
                                        $daterequest = date("d F, Y");
                                        $stuid = $_SESSION["stuid"];

                                        $sql = "SELECT * FROM payment_log WHERE applicant_id = '$stuid' AND PaymentSession = '$corntsession' AND PaymentState='Paid'";
                                        $result = $conn4->query($sql);
                                        if ($result->num_rows > 0) {
                                            $sql = "INSERT INTO request_defence (regid, name1, progtitle, defencetype, responds, daterequest, dept, proposedate) VALUES ('$regid2', '$name2', '$progtitle', '$getdeftype', 'Request', '$daterequest', '$dept', '$propdate')";
                                            $result = $conn5->query($sql);
                                            echo "<h2 style='color: #0000ff; text-align: center'>Record Saved</h2>";
                                        } else {
                                            echo "<h3 style='color: #fc0107; text-align: center'>Not Applicable! Candidate YET to pay current session school fees</h3>";
                                        }
                                    }

                                    if (isset($_POST["cancelrequest"])) {

                                        $progtitle = $_SESSION["progtitle"];
                                        $sessionadmt = $_SESSION["sessionadmt"];
                                        $regid2 = $_POST['regid2'];
                                        $name2 = $_POST['name2'];

                                        $daterequest = date("d F, Y");
                                        $deftype = $_SESSION["deftype"];

                                        $sql = "DELETE FROM  request_defence WHERE regid='$regid2' AND defencetype='$deftype'";
                                        $result = $conn5->query($sql);

                                        echo "<h2 style='color: #0000ff'>Record Deleted</h2>";
                                    }

                                    ?>

                                    <div class="col-lg-6 col-md-12">
                                        <?php
                                        if (isset($_POST["submit"]) || isset($_POST["view"]) || isset($_POST["makerequest"]) || isset($_POST["cancelrequest"])) {
                                            if (isset($_POST["view"]) || isset($_POST["makerequest"]) || isset($_POST["cancelrequest"])) {
                                                $sessionadmt = $_SESSION["sessionadmt"];
                                                $progtitle = $_SESSION["progtitle"];
                                            } else {
                                                $sessionadmt = $_POST["sessionadmt"];
                                                $progtitle = $_POST["progtitle"];
                                                $_SESSION["sessionadmt"] = $sessionadmt;
                                                $_SESSION["progtitle"] = $progtitle;
                                            }
                                        ?>
                                            <h4>Session Registered: <?php echo $sessionadmt ?><br>Programme Title:
                                                <?php echo $progtitle ?></h4>
                                            <table class="table mb-none">

                                                <thead>
                                                    <tr>
                                                        <th>S/No</th>
                                                        <th>Registration No</th>
                                                        <th>Name</th>
                                                        <th>Defence Type</th>
                                                        <th>Action</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php



                                                    $sno = 0;
                                                    $sql = "SELECT * FROM pgapplication WHERE deptcode = '$dept' AND session = '$sessionadmt' AND programme_title = '$progtitle' AND regid<> ''";
                                                    $result = $conn4->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $regid = $row["regid"];
                                                            $id = $row["regid"];
                                                            $name = $row["display_fullname"];
                                                            $sno++;

                                                            if ($progtitle == "Ph.D") {
                                                                echo "<tr><td>$sno</td><td>$regid</td><td>$name</td>
																<form action='' method='post'>

																<td>
																<select class='form-control m-bot15' name='deftype' required='required'>
																	<option value=''></option>
																	<option value='Proporsal'>Proporsal</option>
																	<option value='Seminar1'>Seminar 1</option>
																	<option value='Seminar2'>Seminar 2</option>
																	<option value='Oral'>Oral</option>
																	<option value='Final'>Final</option>
																</select>
																</td>
																<td>
																<input type='hidden' value='$id' name='id'>
																<input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
																</td>
																</form>
																</tr>\n";
                                                            } else {
                                                                echo "<tr><td>$sno</td><td>$regid</td><td>$name</td>
																<form action='' method='post'>

																<td>
																<select class='form-control m-bot15' name='deftype' required='required'>
																	<option value=''></option>
																	<option value='Oral'>Oral</option>
																	<option value='Final'>Final</option>
																</select>
																</td>
																<td>
																<input type='hidden' value='$id' name='id'>
																<input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
																</td>
																</form>
																</tr>\n";
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        <?php } ?>

                                    </div>
                                    <div class="col-lg-6 col-md-12">
                                        <?php
                                        if (isset($_POST["view"])) {
                                            $topic = "NO";
                                            $co_sup = "NO";
                                            $Proporsal = "NO";
                                            $Seminar1 = "NO";
                                            $Seminar2 = "NO";
                                            $Oral = "NO";
                                            $Final = "NO";
                                            $getRequest = "NO";
                                            $Requested = "NO";
                                            $RequestApprd = "NO";

                                            $comment_notApp = "";
                                            $add1 = 0;
                                            $regid = $_POST["id"];
                                            $deftype = $_POST["deftype"];
                                            $sql = "SELECT * FROM pgapplication WHERE regid = '$regid'";
                                            $result = $conn4->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $stuid = $row["applicant_id"];
                                                    $name = $row["display_fullname"];
                                                    $prgtitle = $row["programme_title"];
                                                    $progstudy = $row["course1"];
                                                }
                                            }
                                            $_SESSION["stuid"] = $stuid;
                                            $_SESSION["deftype"] = $deftype;

                                            $sql = "SELECT * FROM progress_report WHERE regid = '$regid' AND val_topic='YES'";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                                $topic = "YES";
                                            }
                                            $sql = "SELECT * FROM progress_report WHERE regid = '$regid' AND val_co_sup='YES'";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                                $co_sup = "YES";
                                            }

                                            $sql = "SELECT * FROM request_defence WHERE regid = '$regid' AND defencetype = 'Proporsal' AND responds = 'Approve'";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                                $Proporsal = "YES";
                                            }
                                            $sql = "SELECT * FROM request_defence WHERE regid = '$regid' AND defencetype = 'Seminar1' AND responds = 'Approve'";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                                $Seminar1 = "YES";
                                            }
                                            $sql = "SELECT * FROM request_defence WHERE regid = '$regid' AND defencetype = 'Seminar2' AND responds = 'Approve'";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                                $Seminar2 = "YES";
                                            }
                                            $sql = "SELECT * FROM request_defence WHERE regid = '$regid' AND defencetype = 'Oral' AND responds = 'Approve'";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                                $Oral = "YES";
                                            }
                                            $sql = "SELECT * FROM request_defence WHERE regid = '$regid' AND defencetype = 'Final' AND responds = 'Approve'";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                                $Final = "YES";
                                            }

                                            if ($progtitle == "Ph.D") {
                                                if ($deftype == "Proporsal") {
                                                    if ($Proporsal == "YES") {
                                                        $RequestApprd = "YES";
                                                    } else {
                                                        if ($co_sup == "YES") {
                                                            $getRequest = "YES";
                                                        }
                                                    }
                                                } elseif ($deftype == "Seminar1") {
                                                    if ($Seminar1 == "YES") {
                                                        $RequestApprd = "YES";
                                                    } else {
                                                        if ($Proporsal == "YES") {
                                                            $getRequest = "YES";
                                                        }
                                                    }
                                                } elseif ($deftype == "Seminar2") {
                                                    if ($Seminar2 == "YES") {
                                                        $RequestApprd = "YES";
                                                    } else {
                                                        if ($Seminar1 == "YES") {
                                                            $getRequest = "YES";
                                                        }
                                                    }
                                                } elseif ($deftype == "Oral") {
                                                    if ($Oral == "YES") {
                                                        $RequestApprd = "YES";
                                                    } else {
                                                        if ($Seminar2 == "YES") {
                                                            $getRequest = "YES";
                                                        }
                                                    }
                                                } elseif ($deftype == "Final") {
                                                    if ($Final == "YES") {
                                                        $RequestApprd = "YES";
                                                    } else {
                                                        if ($Oral == "YES") {
                                                            $getRequest = "YES";
                                                        }
                                                    }
                                                }
                                            } else {
                                                if ($deftype == "Oral") {
                                                    if ($Oral == "YES") {
                                                        $RequestApprd = "YES";
                                                    } else {
                                                        if ($topic == "YES") {
                                                            $getRequest = "YES";
                                                        }
                                                    }
                                                } elseif ($deftype == "Final") {
                                                    if ($Final == "YES") {
                                                        $RequestApprd = "YES";
                                                    } else {
                                                        if ($Oral == "YES") {
                                                            $getRequest = "YES";
                                                        }
                                                    }
                                                }
                                            }

                                            if ($getRequest == "YES") {
                                                $sql = "SELECT * FROM request_defence WHERE regid = '$regid' AND defencetype = '$deftype'";
                                                $result = $conn5->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $name1 = $row["name1"];
                                                        //$defencetype=$row["defencetype"];
                                                        $responds = $row["responds"];
                                                        $daterequest = $row["daterequest"];
                                                        $proposedate = $row["proposedate"];
                                                        $comment_notApp = $row["comment_notApp"];
                                                        $Requested = "YES";
                                                    }
                                                }
                                            } else {
                                            }

                                            if ($RequestApprd == "YES") {
                                                $sql = "SELECT * FROM request_defence WHERE regid = '$regid' AND defencetype = '$deftype'";
                                                $result = $conn5->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $name1 = $row["name1"];
                                                        //$defencetype=$row["defencetype"];
                                                        $responds = $row["responds"];
                                                        $daterequest = $row["daterequest"];
                                                        $proposedate = $row["proposedate"];
                                                        $comment_notApp = $row["comment_notApp"];
                                                        $Requested = "YES";
                                                    }
                                                }
                                            }

                                            if ($deftype == "Seminar1") {
                                                $deftype2 = "Seminar 1";
                                            } elseif ($deftype == "Seminar2") {
                                                $deftype2 = "Seminar 2";
                                            } else {
                                                $deftype2 = $deftype;
                                            }
                                            if ($RequestApprd == "YES") {
                                                echo "<h3 style='color: #012bfc; text-align: center'>Request Approved</h3>";
                                            } elseif ($getRequest == "NO") {
                                                echo "<h3 style='color: #fc0107; text-align: center'>Not Applicable!</h3>";
                                            }


                                        ?>
                                            <?php if ($RequestApprd == "YES") { ?>
                                                <br>
                                                <form class="form-horizontal" method="post" action="">
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Registration No.:</label>
                                                        <div class="col-sm-8">
                                                            <label class="control-label" style="color:#000"><?php echo $regid ?></label>
                                                            <input type="hidden" value="<?php echo $regid ?>" name="regid2" />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Name:</label>
                                                        <div class="col-sm-8">
                                                            <label class="control-label" style="color:#000"><?php echo $name ?></label>
                                                            <input type="hidden" value="<?php echo $name ?>" name="name2" />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Defence Type:</label>
                                                        <div class="col-sm-8">
                                                            <label class="control-label" style="color:#000"><?php echo $deftype2 ?></label>
                                                            <input type="hidden" value="<?php echo $deftype ?>" name="getdeftype" />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Proposed Date:</label>
                                                        <div class="col-sm-8">
                                                            <label class="control-label" style="color:#000"><?php echo $proposedate ?></label>

                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">PG School Comment:</label>
                                                        <div class="col-sm-8">
                                                            <label class="control-label" style="color:#000"><?php echo $comment_notApp ?></label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label"></label>
                                                        <div class="col-sm-8" style="text-align:right">
                                                            <label class="control-label" style="color:#000">Request
                                                                Approved</label></label>
                                                        </div>
                                                    </div>
                                                </form>

                                            <?php } ?>

                                            <?php if ($getRequest == "YES") { ?>
                                                <br>
                                                <form class="form-horizontal" method="post" action="">
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Registration No.:</label>
                                                        <div class="col-sm-8">
                                                            <label class="control-label" style="color:#000"><?php echo $regid ?></label>
                                                            <input type="hidden" value="<?php echo $regid ?>" name="regid2" />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Name:</label>
                                                        <div class="col-sm-8">
                                                            <label class="control-label" style="color:#000"><?php echo $name ?></label>
                                                            <input type="hidden" value="<?php echo $name ?>" name="name2" />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Defence Type:</label>
                                                        <div class="col-sm-8">
                                                            <label class="control-label" style="color:#000"><?php echo $deftype2 ?></label>
                                                            <input type="hidden" value="<?php echo $deftype ?>" name="getdeftype" />
                                                        </div>
                                                    </div>
                                                    <?php if ($Requested !== "YES") { ?>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Proposed Date:</label>
                                                            <div class="col-sm-8">

                                                                <input type="date" value="" name="propdate" required="required" />
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">PG School Comment:</label>
                                                            <div class="col-sm-8">
                                                                <label class="control-label" style="color:#000"><?php echo $comment_notApp ?></label>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label"></label>
                                                            <div class="col-sm-8" style="text-align:right">
                                                                <button type="submit" name="makerequest" class="btn btn-info btn-xs">Make Request</button>
                                                            </div>
                                                        </div>
                                                    <?php } else { ?>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">Proposed Date:</label>
                                                            <div class="col-sm-8">
                                                                <label class="control-label" style="color:#000"><?php echo $proposedate ?></label>

                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label">PG School Comment:</label>
                                                            <div class="col-sm-8">
                                                                <label class="control-label" style="color:#000"><?php echo $comment_notApp ?></label>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-sm-3 control-label"></label>
                                                            <div class="col-sm-8" style="text-align:right">
                                                                <?php if ($responds == "Request") { ?>
                                                                    <button type="submit" name="cancelrequest" class="btn btn-danger btn-xs">Cancel Request</button>
                                                                <?php } else { ?>
                                                                    <label class="control-label" style="color:#000">Request
                                                                        Approved</label></label>

                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                    <?php } ?>
                                                </form>

                                            <?php } ?>


                                        <?php } ?>

                                    </div>

                                </div>


                            </section>


                        </div>

                    </div>

                </div>

                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>


</body>

</html>
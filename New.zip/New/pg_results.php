<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$paystatus = "NO";
$stdid = $_SESSION['stdid'];
$corntsession = $_SESSION['corntsession'];

//include_once 'includes/check_stu_status.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--Print Div-->
    <script type="text/javascript">
        function printme() {
            var print_div = document.getElementById("printablediv");
            var print_area = window.open();
            print_area.document.write(print_div.innerHTML);
            print_area.document.close();
            print_area.focus();
            print_area.print();
            print_area.close();
        }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>
<?php

$regid = $_SESSION["regid"];
$dept = $_SESSION['deptcode'];
$curtsession = $_SESSION['corntsession'];
$names = $_SESSION['names'];


$cgpa = $totsumunits = $totsumgp = 0;
?>

<body>
    <section class="body">

        <!-- start: header -->
        <?php include_once 'includes/header2_pg.php'; ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/pg_aside_menu.php'; ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Results</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-file"></i>
                                </a>
                            </li>
                            <li><span>Results</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">
                    <div class="col-md-1">
                    </div>
                    <div class="col-md-10">
                        <section class="panel panel-success">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">Result</h2>
                            </header>
                            <div class="panel-body">
                                <form class="form-horizontal" method="post" action="">
                                    <?php
                                    $names = $_SESSION['names'];
                                    $stdid = $_SESSION['stdid'];

                                    $regid = $_SESSION["regid"];
                                    $dept = $_SESSION['deptcode'];
                                    $sumunits = $sumgp = $point = $cgpa = 0;
                                    $grade = "";

                                    $sql = "SELECT * FROM " . $dept . "_correg WHERE regn1 = '$regid' ORDER BY SessionRegis, SemTaken";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                    ?>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Session</th>
                                                    <th>Grade</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                while ($row = $result->fetch_assoc()) {
                                                    if ($row['CA'] + $row['Exam'] >= 70) {
                                                        $point = 5;
                                                        $grade = "A";
                                                    } elseif ($row['CA'] + $row['Exam'] >= 60) {
                                                        $point = 4;
                                                        $grade = "B";
                                                    } elseif ($row['CA'] + $row['Exam'] >= 50) {
                                                        $point = 3;
                                                        $grade = "C";
                                                    } elseif ($row['CA'] + $row['Exam'] >= 45) {
                                                        $point = 2;
                                                        $grade = "D";
                                                    } elseif ($row['CA'] + $row['Exam'] >= 40) {
                                                        $point = 1;
                                                        $grade = "E";
                                                    } elseif ($row['CA'] + $row['Exam'] <= 39.95) {
                                                        $point = 0;
                                                        $grade = "F";
                                                    }

                                                    echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['SessionRegis']}</td><td>$grade</td></tr>\n";
                                                    $sumunits += $row['CUnit'];

                                                    $sumgp += $row['CUnit'] * $point;
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <?php

                                    }

                                    echo "<center>";
                                    echo "Total Credit Units =   " . $sumunits . "<br>";
                                    echo "Total Grade Points =  " . $sumgp . "<br>";
                                    if ($sumunits <> 0)
                                        echo "CGPA =   "  . number_format((float)$sumgp / $sumunits, 2, '.', '');
                                    echo "<br><br>";
                                    ?>
                                    <div style="text-align: right">
                                        <input type="button" class='btn btn-info btn-sm' value="Print" onclick="printme()">
                                    </div>
                                    <?php

                                    echo "<br><br>";

                                    echo "</center>";


                                    //$conn->close();
                                    ?>

                                </form>
                            </div>
                        </section>
                    </div>
                    <div class="col-md-1">
                    </div>
                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>

    <!--Print Start-->
    <div id="printablediv" style="width: 100%; height: 200px;" hidden="hidden">
        <center><strong>
                <h3>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</h3>
            </strong></center>
        <center><strong>
                <h4>STUDENT'S ACADEMIC RECORD</h4>
            </strong></center>

        <?php

        $regid = $_SESSION["regid"];
        $dept = $_SESSION['deptcode'];
        $sumunits = $sumgp = $point = $cgpa = 0;
        $grade = "";

        echo "<div class='row'>";
        echo "<div class='col-lg-9'><br>";
        echo "Matric No:" . $regid;
        echo "<br>";
        echo "Name:  " . $names;
        echo "</div>";
        echo "<div class='col-lg-3' style='text-align:right'>";
        echo "<img alt='' src='https://eportal.futminna.edu.ng/pg/uploads/" . $_SESSION['stdid'] . "_passport.jpg' width='100' height='100'>";
        echo "</div>";
        echo "</div>";

        ?>
        <?php
        $sql = "SELECT * FROM " . $dept . "_correg WHERE regn1 = '$regid' ORDER BY SessionRegis, SemTaken, CCode";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        ?>
            <br><br>
            <table style="border-collapse: collapse; width: 100%;">
                <thead>
                    <tr>
                        <th style="text-align: left; border: 1px solid #ccc;">Course Code</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Course Title</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Unit</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Semester</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Session</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Grade</th>
                        <th style="text-align: left; border: 1px solid #ccc;">GP</th>
                    </tr>
                </thead>
                <tbody>


                    <?php
                    while ($row = $result->fetch_assoc()) {
                        if ($row['CA'] + $row['Exam'] >= 70) {
                            $grade = "A";
                            $gp = $row['CUnit'] * 5;
                        } elseif ($row['CA'] + $row['Exam'] >= 60) {
                            $grade = "B";
                            $gp = $row['CUnit'] * 4;
                        } elseif ($row['CA'] + $row['Exam'] >= 50) {
                            $grade = "C";
                            $gp = $row['CUnit'] * 3;
                        } elseif ($row['CA'] + $row['Exam'] >= 45) {
                            $grade = "D";
                            $gp = $row['CUnit'] * 2;
                        } elseif ($row['CA'] + $row['Exam'] >= 40) {
                            $grade = "E";
                            $gp = $row['CUnit'] * 1;
                        } elseif ($row['CA'] + $row['Exam'] <= 39.95) {
                            $grade = "F";
                            $gp = 0;
                        }

                        echo "<tr><td style='text-align: left; border: 1px solid #ccc;'>{$row['CCode']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['CTitle']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['CUnit']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['SemTaken']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['SessionRegis']}</td><td style='text-align: left; border: 1px solid #ccc;'>$grade</td><td style='text-align: left; border: 1px solid #ccc;'>$gp</td></tr>\n";
                        $sumunits += $row['CUnit'];

                        $sumgp += $gp;
                    }

                    echo "<tr><td style='text-align: left; border: 1px'></td><th style='text-align: left; border: 1px'>Total</th><th style='text-align: left; border: 1px'>$sumunits</th><td style='text-align: left; border: 1px'></td><td style='text-align: left; border: 1px'></td><td style='text-align: left; border: 1px'></td><th style='text-align: left; border: 1px'>$sumgp</th></tr>";
                    ?>
                </tbody>
            </table>


        <?php } ?>

        <br>
        <center>
            <?php
            $totsumunits += $sumunits;
            $totsumgp += $sumgp;
            ?>
            <?php if ($sumunits !== 0) ?>
            GPA = <?php echo number_format((float)$sumgp / $sumunits, 2, '.', ''); ?><br>
            <?php if ($totsumunits !== 0) ?>
            CGPA = <?php echo number_format((float)$totsumgp / $totsumunits, 2, '.', ''); ?>

        </center>

    </div>

    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
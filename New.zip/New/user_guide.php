<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['logintype'] !== "staff") {
    header('Location: index.php');
}

?>
<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/codemirror/codemirror.css" rel="stylesheet">
    <link href="css/plugins/codemirror/ambiance.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Users' Guide</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Users' Guide</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="fh-breadcrumb">

                    <div class="fh-column">
                        <div class="full-height-scroll">
                            <ul class="list-group elements-list">
                                <li class="list-group-item active">
                                    <a data-toggle="tab" href="#c01_courses">

                                        <strong>Course</strong>
                                        <div class="small m-t-xs">
                                            <p>
                                                Course Setup
                                            </p>

                                        </div>
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <a data-toggle="tab" href="#c02_courses">

                                        <strong>Course</strong>
                                        <div class="small m-t-xs">
                                            <p class="m-b-xs">
                                                Course Validation
                                                <br />
                                            </p>

                                        </div>
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <a data-toggle="tab" href="#tab-3">
                                        <small class="pull-right text-muted"> 08.04.2015</small>
                                        <strong>Michael Jackson</strong>
                                        <div class="small m-t-xs">
                                            <p class="m-b-xs">
                                                Look even slightly believable. If you are going to use a passage of.
                                            </p>
                                            <p class="m-b-none">
                                                <i class="fa fa-map-marker"></i> Berlin 120R/15
                                            </p>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <a data-toggle="tab" href="#tab-4">
                                        <small class="pull-right text-muted"> 16.02.2015</small>
                                        <strong>Mark Smith</strong>
                                        <div class="small m-t-xs">
                                            <p class="m-b-xs">
                                                It was popularised in the 1960s with the release of Letraset sheets
                                            </p>
                                            <p class="m-b-none">
                                                <i class="fa fa-map-marker"></i> San Francisko 12/100
                                            </p>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <a data-toggle="tab" href="#tab-1">
                                        <small class="pull-right text-muted"> 21.04.2015</small>
                                        <strong>Monica Novak</strong>
                                        <div class="small m-t-xs">
                                            <p class="m-b-xs">
                                                Printer took a galley of type and scrambled.
                                            </p>
                                            <p class="m-b-none">
                                                <i class="fa fa-map-marker"></i> New York 15/43
                                            </p>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <a data-toggle="tab" href="#tab-2">
                                        <small class="pull-right text-muted"> 03.12.2015</small>
                                        <strong>Jack Smith</strong>
                                        <div class="small m-t-xs">
                                            <p class="m-b-xs">
                                                Also the leap into electronic typesetting, remaining.
                                            </p>
                                            <p class="m-b-none">
                                                <i class="fa fa-map-marker"></i> Sant Fe 10/106
                                            </p>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <a data-toggle="tab" href="#tab-3">
                                        <small class="pull-right text-muted"> 08.04.2015</small>
                                        <strong>Michael Jackson</strong>
                                        <div class="small m-t-xs">
                                            <p class="m-b-xs">
                                                Look even slightly believable. If you are going to use a passage of.
                                            </p>
                                            <p class="m-b-none">
                                                <i class="fa fa-map-marker"></i> Berlin 120R/15
                                            </p>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <a data-toggle="tab" href="#tab-4">
                                        <small class="pull-right text-muted"> 16.02.2015</small>
                                        <strong>Mark Smith</strong>
                                        <div class="small m-t-xs">
                                            <p class="m-b-xs">
                                                It was popularised in the 1960s with the release of Letraset sheets
                                            </p>
                                            <p class="m-b-none">
                                                <i class="fa fa-map-marker"></i> San Francisko 12/100
                                            </p>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    <a data-toggle="tab" href="#tab-1">
                                        <small class="pull-right text-muted"> 21.04.2015</small>
                                        <strong>Monica Novak</strong>
                                        <div class="small m-t-xs">
                                            <p class="m-b-xs">
                                                Printer took a galley of type and scrambled.
                                            </p>
                                            <p class="m-b-none">
                                                <i class="fa fa-map-marker"></i> New York 15/43
                                            </p>
                                        </div>
                                    </a>
                                </li>


                            </ul>

                        </div>
                    </div>

                    <div class="full-height">
                        <div class="full-height-scroll white-bg border-left">

                            <div class="element-detail-box">

                                <div class="tab-content">
                                    <div id="c01_courses" class="tab-pane active">

                                        <div class="pull-right">
                                            <div class="tooltip-demo">
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="left" title="Plug this message"><i
                                                        class="fa fa-plug"></i> Plug it</button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title="Mark as read"><i class="fa fa-eye"></i>
                                                </button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title=""
                                                    data-original-title="Mark as important"><i
                                                        class="fa fa-exclamation"></i> </button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title="" data-original-title="Move to trash"><i
                                                        class="fa fa-trash-o"></i> </button>

                                            </div>
                                        </div>
                                        <div class="small text-muted">
                                            <i class="fa fa-clock-o"></i> Wednesday, 9 August 2023, 9:00 pm
                                        </div>

                                        <h1>
                                            Course Setup
                                        </h1>
                                        <p>Back when course registration was done manually, students required assistance
                                            in selecting which courses to register for each session. To aid them in this
                                            process, a notice board was made available with a comprehensive list of
                                            courses for every level, allowing students to easily determine which courses
                                            to register for.</p>
                                        <p>On this e-results platform, exam officers from each department can log in and
                                            set up courses for students at all levels to replace the manual process.</p>
                                        <p>To begin with, go to the left menu and select "Course Management" followed by
                                            "Course
                                            Setup". Next, you'll see a list of courses that have already been set up. To
                                            delete a course, simply click on the "Delete" button.</p>
                                        <p>If you wish to include a course in the list, start by clicking on the "Add
                                            Courses" option located at the bottom of the list. Next, select the
                                            department you're interested in from the "Select Department" drop-down list.
                                            This will trigger a list of courses from that particular department to
                                            appear. After that, choose the course you want by checking the checkbox
                                            located beside it. Additionally, you can configure other settings such as
                                            Semester, Nature, and Level. Lastly, click the "Submit" button to add the
                                            selected course(s) to the list.</p>
                                        <p>To gain a deeper comprehension, please view the video provided below.</p>

                                        <iframe width="560" height="315" src="https://www.youtube.com/embed/c3a7rjfJhjs"
                                            title="YouTube video player" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>
                                        <p class="small">
                                            <strong>Course Setup Video </strong>
                                        </p>


                                    </div>

                                    <div id="c02_courses" class="tab-pane">
                                        <div class="pull-right">
                                            <div class="tooltip-demo">
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="left" title="Plug this message"><i
                                                        class="fa fa-plug"></i> Plug it</button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title="Mark as read"><i class="fa fa-eye"></i>
                                                </button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title=""
                                                    data-original-title="Mark as important"><i
                                                        class="fa fa-exclamation"></i> </button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title="" data-original-title="Move to trash"><i
                                                        class="fa fa-trash-o"></i> </button>

                                            </div>
                                        </div>
                                        <div class="small text-muted">
                                            <i class="fa fa-clock-o"></i> Wednesday, 9 August 2023, 9:00 pm
                                        </div>

                                        <h1>
                                            Course Validation
                                        </h1>

                                        <p>In the past, students had to manually submit their course registration forms
                                            to multiple individuals, including the level adviser, HOD, Dean, and
                                            registrar, in order to receive approval. Nowadays, the entire process is
                                            automated and can be completed online, with all necessary signatories able
                                            to validate the form digitally.</p>
                                        <p>All faculty members with appropriate permissions can access this e-results
                                            platform to review and approve student course forms. Initially, level
                                            advisers will review and approve the forms before passing them on to the
                                            HOD, Dean, and Registrar for final approval.</p>
                                        <p>To get started, navigate to the left-hand menu and choose "Course
                                            Management", then
                                            select "Course Validation". From there, choose the "Yet to Validate" option
                                            and specify the department before clicking the "Submit" button to see a list
                                            of all unvalidated students. Click on a student's name to view their
                                            registered courses, and either "Validate" them or add a comment before
                                            moving on to the next student. If you need to, you can also download a list
                                            of validated students by selecting "Get Validated List".</p>

                                        <p>To gain a deeper comprehension, please view the video provided below.</p>
                                        <iframe width="560" height="315" src="https://www.youtube.com/embed/-Qo5YJ86nl4"
                                            title="YouTube video player" frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                            allowfullscreen></iframe>

                                        <p class="small">
                                            <strong>Course Validation Video </strong>
                                        </p>


                                    </div>

                                    <div id="tab-3" class="tab-pane">
                                        <div class="pull-right">
                                            <div class="tooltip-demo">
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="left" title="Plug this message"><i
                                                        class="fa fa-plug"></i> Plug it</button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title="Mark as read"><i class="fa fa-eye"></i>
                                                </button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title=""
                                                    data-original-title="Mark as important"><i
                                                        class="fa fa-exclamation"></i> </button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title="" data-original-title="Move to trash"><i
                                                        class="fa fa-trash-o"></i> </button>

                                            </div>
                                        </div>
                                        <div class="small text-muted">
                                            <i class="fa fa-clock-o"></i> Tuesday, 15 May 2014, 10:32 am
                                        </div>

                                        <h1>
                                            To take a trivial example
                                        </h1>

                                        <p>
                                            But who has any right to find fault with a man who chooses to enjoy a
                                            pleasure that has no annoying consequences, or one who avoids a pain that
                                            produces no resultant pleasure? On the other hand, we denounce with
                                            righteous indignation and dislike men who are so beguiled and demoralized by
                                            the charms of pleasure of the moment, so blinded by desire, that they cannot
                                            foresee the pain and trouble that are bound to ensue; and equal blame
                                            belongs to those who fail in their duty through weakness of will, which is
                                            the same as saying through shrinking from toil and pain.
                                        </p>
                                        <p>
                                            The bedding was hardly able to cover it and seemed ready to slide off any
                                            moment. His many legs, pitifully thin compared with the size of the rest of
                                            him, waved about helplessly as he looked. "What's happened to me?" he
                                            thought. It wasn't a dream. His room, a proper human room although a little
                                            too small, lay peacefully between its four familiar walls.
                                        </p>

                                        <p>
                                            he wise man therefore always holds in these matters to this principle of
                                            selection: he rejects pleasures to secure other greater pleasures, or else
                                            he endures pains to avoid worse pains.But I must explain to you how all this
                                            mistaken idea of denouncing pleasure and praising pain was born and.
                                        </p>
                                        <p>
                                            To achieve this, it would be necessary to have uniform grammar,
                                            pronunciation and more common words. If several languages coalesce, the
                                            grammar of the resulting language is more simple and regular than that of
                                            the individual languages. The new common language will be more simple and
                                            regular than the existing European languages. It will be as simple as
                                            Occidental; in fact, it will be Occidental. To an English person, it will
                                            seem like simplified English, as a skeptical Cambridge friend of mine told
                                            me what Occidental is.
                                        </p>

                                        <p>
                                            The European languages are members of the same family. Their separate
                                            existence is a myth. For science, music, sport, etc, Europe uses the same
                                            vocabulary.
                                        </p>
                                        <p>
                                            To take a trivial example, which of us ever undertakes laborious physical
                                            exercise, except to obtain some advantage from it? But who has any right to
                                            find fault with a man who chooses to enjoy a pleasure that has no annoying
                                            consequences, or one who avoids a pain that produces no resultant pleasure?
                                            On the other hand, we denounce.
                                        </p>
                                        <p class="small">
                                            <strong>Best regards, Anthony Smith </strong>
                                        </p>

                                        <div class="m-t-lg">
                                            <p>
                                                <span><i class="fa fa-paperclip"></i> 2 attachments - </span>
                                                <a href="#">Download all</a>
                                                |
                                                <a href="#">View all images</a>
                                            </p>

                                            <div class="attachment">
                                                <div class="file-box">
                                                    <div class="file">
                                                        <a href="#">
                                                            <span class="corner"></span>

                                                            <div class="icon">
                                                                <i class="fa fa-file"></i>
                                                            </div>
                                                            <div class="file-name">
                                                                Document_2014.doc
                                                                <br>
                                                                <small>Added: Jan 11, 2014</small>
                                                            </div>
                                                        </a>
                                                    </div>

                                                </div>
                                                <div class="file-box">
                                                    <div class="file">
                                                        <a href="#">
                                                            <span class="corner"></span>

                                                            <div class="icon">
                                                                <i class="fa fa-line-chart"></i>
                                                            </div>
                                                            <div class="file-name">
                                                                Seels_2015.xls
                                                                <br>
                                                                <small>Added: May 13, 2015</small>
                                                            </div>
                                                        </a>
                                                    </div>

                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="tab-4" class="tab-pane">
                                        <div class="pull-right">
                                            <div class="tooltip-demo">
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="left" title="Plug this message"><i
                                                        class="fa fa-plug"></i> Plug it</button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title="Mark as read"><i class="fa fa-eye"></i>
                                                </button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title=""
                                                    data-original-title="Mark as important"><i
                                                        class="fa fa-exclamation"></i> </button>
                                                <button class="btn btn-white btn-xs" data-toggle="tooltip"
                                                    data-placement="top" title="" data-original-title="Move to trash"><i
                                                        class="fa fa-trash-o"></i> </button>

                                            </div>
                                        </div>
                                        <div class="small text-muted">
                                            <i class="fa fa-clock-o"></i> Thursday, 27 april 2014, 10:32 am
                                        </div>

                                        <h1>
                                            Gregor Samsa woke from troubled dreams.
                                        </h1>

                                        <p>
                                            His many legs, pitifully thin compared with the size of the rest of him,
                                            waved about helplessly as he looked. "What's happened to me?" he thought. It
                                            wasn't a dream. His room, a proper human room although a little too small,
                                            lay peacefully between its four familiar walls.
                                        </p>
                                        <p>
                                            To achieve this, it would be necessary to have uniform grammar,
                                            pronunciation and more common words. If several languages coalesce, the
                                            grammar of the resulting language is more simple and regular than that of
                                            the individual languages. The new common language will be more simple and
                                            regular than the existing European languages. It will be as simple as
                                            Occidental; in fact, it will be Occidental. To an English person, it will
                                            seem like simplified English, as a skeptical Cambridge friend of mine told
                                            me what Occidental is.
                                        </p>
                                        <p>
                                            Travelling day in and day out. Doing business like this takes much more
                                            effort than doing your own business at home, and on top of that there's the
                                            curse of travelling, worries about making train connections, bad and
                                            irregular food, contact with different people all the time so that you can
                                            never get to know anyone or become friendly with them.
                                        </p>

                                        <p>
                                            The European languages are members of the same family. Their separate
                                            existence is a myth. For science, music, sport, etc, Europe uses the same
                                            vocabulary.
                                        </p>
                                        <p>
                                            To achieve this, it would be necessary to have uniform grammar,
                                            pronunciation and more common words. If several languages coalesce, the
                                            grammar of the resulting language is more simple and regular than that of
                                            the individual languages. The new common language will be more simple and
                                            regular than the existing European languages. It will be as simple as
                                            Occidental; in fact, it will be Occidental. To an English person, it will
                                            seem like simplified English, as a skeptical Cambridge friend of mine told
                                            me what Occidental is.
                                        </p>
                                        <p class="small">
                                            <strong>Best regards, Anthony Smith </strong>
                                        </p>

                                        <div class="m-t-lg">
                                            <p>
                                                <span><i class="fa fa-paperclip"></i> 2 attachments - </span>
                                                <a href="#">Download all</a>
                                                |
                                                <a href="#">View all images</a>
                                            </p>

                                            <div class="attachment">
                                                <div class="file-box">
                                                    <div class="file">
                                                        <a href="#">
                                                            <span class="corner"></span>

                                                            <div class="icon">
                                                                <i class="fa fa-file"></i>
                                                            </div>
                                                            <div class="file-name">
                                                                Document_2014.doc
                                                                <br>
                                                                <small>Added: Jan 11, 2014</small>
                                                            </div>
                                                        </a>
                                                    </div>

                                                </div>
                                                <div class="file-box">
                                                    <div class="file">
                                                        <a href="#">
                                                            <span class="corner"></span>

                                                            <div class="icon">
                                                                <i class="fa fa-line-chart"></i>
                                                            </div>
                                                            <div class="file-name">
                                                                Seels_2015.xls
                                                                <br>
                                                                <small>Added: May 13, 2015</small>
                                                            </div>
                                                        </a>
                                                    </div>

                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>



                </div>

            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';


?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Download to excel-->
    <script src="js/getexcel/tableToExcel_GRD.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>



<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Profile</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Student Biodata
                            </li>
                            <li class="active">
                                <strong>Graduated</strong>
                            </li>
                        </ol>
                        <br><br>
                        <div class="row">
                            <div class="col-md-1">

                            </div>

                            <div class="col-md-10">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="form-group">
                                        <label class="control-label col-lg-3" for="content">Select Department:</label>
                                        <div class="col-lg-8">
                                            <select class="form-control" style="color:#000000" name="dept">
                                                <option value="SelectItem">Select Item</option>
                                                <?php


                                                if ($cat_AcadSec == "YES") {
                                                    $sql = "SELECT * FROM deptcoding";
                                                } else {
                                                    //$sql = "SELECT * FROM deptcoding WHERE School = '$schcode' ORDER BY DeptName";
                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                }

                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    // output data of each row
                                                    while ($row = $result->fetch_assoc()) {
                                                        $deptcode2 = $row["DeptCode"];
                                                        $deptname2 = $row["DeptName"];
                                                        echo "<option value=$deptcode2>$deptname2</option>";
                                                    }
                                                }

                                                ?>

                                            </select>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-lg-3" for="content">Graduating Session:</label>
                                        <div class="col-lg-8">
                                            <select class="country form-control" style="color:#000000" name="session1">
                                                <?php
                                                $iniyear = 2018;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                    <?php echo $_SESSION['corntsession'] ?></option>
                                                <?php
                                                while ($iniyear <= $finalyear) {
                                                    $addyear = $iniyear + 1;

                                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                    $iniyear++;
                                                }

                                                ?>

                                            </select>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-lg-3" for="content"></label>
                                        <div class="col-lg-8">
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>

                                <hr class="separator" />

                                <?php if (isset($_POST["submit"])) { ?>
                                <?php
                                    $dept = $_POST['dept'];
                                    $session1 = $_POST['session1'];
                                    $_SESSION['dept'] = $dept;
                                    $_SESSION['session1'] = $session1;

                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $GetTitle = $row["DeptName"];
                                        }
                                    }

                                    ?>
                                <div class="form-group" style="visibility: collapse;">

                                    <table id="myTable" class="table stats-table" style="font-size:12px;" summary=""
                                        rules="groups" frame="hsides" border="2">
                                        <caption></caption>
                                        <colgroup align="center"></colgroup>
                                        <colgroup align="left"></colgroup>
                                        <colgroup span="2"></colgroup>
                                        <colgroup span="3" align="center"></colgroup>
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Matric No</th>
                                                <th>Name</th>
                                                <th hidden="hidden">JAMB</th>
                                                <th hidden="hidden">Graduating Session</th>
                                                <th hidden="hidden">Course of Study</th>
                                                <th hidden="hidden">Course Option</th>
                                                <th hidden="hidden">Degree</th>
                                                <th hidden="hidden">Phone No</th>
                                                <th hidden="hidden">email</th>
                                                <th hidden="hidden">State</th>
                                                <th hidden="hidden">LGA</th>
                                                <th hidden="hidden">Date of Birth</th>
                                                <th hidden="hidden">Place of Birth</th>
                                                <th hidden="hidden">Sex</th>
                                                <th hidden="hidden">Marital Status</th>
                                                <th hidden="hidden">Perm Address</th>
                                                <th hidden="hidden">Next of Kin</th>
                                                <th hidden="hidden">Next of Kin Addr</th>
                                                <th hidden="hidden">Next of Kin email</th>

                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $sno = 0;
                                                $sql = "SELECT * FROM graduated WHERE Deptcode = '$dept' AND yeargrad = '$session1' ORDER BY regid";

                                                $result = $conn2->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $id = $row["id"];
                                                        $regid = $row["regid"];
                                                        $names = $row["firstname"] . " " . $row["othername"] . " " . $row["surname"];
                                                        $names = strtolower($names);
                                                        $names = ucwords($names);
                                                        $JAMB = $row["JAMB_RegNo"];
                                                        $yeargrad = $row["yeargrad"];
                                                        $cstudy = $row["cstudy"];
                                                        $coption = $row["coption"];
                                                        $degree = $row["degree"];
                                                        $Phone = $row["Phone"];
                                                        $email = $row["email"];
                                                        $StateOfOrigin = $row["StateOfOrigin"];
                                                        $lga = $row["lga"];
                                                        $PlaceBirth = $row["PlaceBirth"];
                                                        $dob = $row["dob"];
                                                        $sex = $row["sex"];
                                                        $marital = $row["marital"];
                                                        $next_rel = $row["next_rel"];
                                                        $next_addr = $row["next_addr"];
                                                        $next_email = $row["next_email"];
                                                        $ParmtAdress = $row["ParmtAdress"];

                                                        echo "<tr><td>$sno</td><td>$regid</td><td>$names</td><td hidden='hidden'>$JAMB</td><td hidden='hidden'>$yeargrad</td><td hidden='hidden'>$cstudy</td><td hidden='hidden'>$coption</td><td hidden='hidden'>$degree</td><td hidden='hidden'>$Phone</td><td hidden='hidden'>$email</td><td hidden='hidden'>$StateOfOrigin</td><td hidden='hidden'>$lga</td><td hidden='hidden'>$dob</td><td hidden='hidden'>$PlaceBirth</td><td hidden='hidden'>$sex</td><td hidden='hidden'>$marital</td><td hidden='hidden'>$ParmtAdress</td><td hidden='hidden'>$next_rel</td><td hidden='hidden'>$next_addr</td><td hidden='hidden'>$next_email</td>
												
												<td>
												<form action='stu_biodata_print.php' method='post'>
													  <input type='hidden' value=$id name='id'>
													  <input type='submit' name = 'view' class='btn btn-primary btn-xs' value='View'>
												</form>
												</td>
															  
														 
												</tr>\n";
                                                    }
                                                }
                                                ?>
                                        </tbody>
                                    </table>

                                </div>

                                <section class="panel panel-success">
                                    <header class="panel-heading">
                                        <div class="panel-actions">
                                            <a href="#" class="fa fa-caret-down"></a>
                                            <a href="#" class="fa fa-times"></a>
                                        </div>

                                        <h2 class="panel-title"><?php echo $GetTitle ?> Department</h2>
                                    </header>
                                    <div class="panel-body">
                                        <table class="table table-bordered table-striped mb-none"
                                            id="datatable-tabletools"
                                            data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
                                            <thead>

                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Matric No</th>
                                                    <th>Name</th>
                                                    <th hidden="hidden">JAMB</th>
                                                    <th hidden="hidden">Graduating Session</th>
                                                    <th hidden="hidden">Course of Study</th>
                                                    <th hidden="hidden">Course Option</th>
                                                    <th hidden="hidden">Degree</th>
                                                    <th hidden="hidden">Phone No</th>
                                                    <th hidden="hidden">email</th>
                                                    <th hidden="hidden">State</th>
                                                    <th hidden="hidden">LGA</th>
                                                    <th hidden="hidden">Date of Birth</th>
                                                    <th hidden="hidden">Place of Birth</th>
                                                    <th hidden="hidden">Sex</th>
                                                    <th hidden="hidden">Marital Status</th>
                                                    <th hidden="hidden">Perm Address</th>
                                                    <th hidden="hidden">Next of Kin</th>
                                                    <th hidden="hidden">Next of Kin Addr</th>
                                                    <th hidden="hidden">Next of Kin email</th>

                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $sno = 0;
                                                    $sql = "SELECT * FROM graduated WHERE Deptcode = '$dept' AND yeargrad = '$session1' ORDER BY regid";

                                                    $result = $conn2->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $id = $row["id"];
                                                            $regid = $row["regid"];
                                                            $names = $row["firstname"] . " " . $row["othername"] . " " . $row["surname"];
                                                            $names = strtolower($names);
                                                            $names = ucwords($names);
                                                            $JAMB = $row["JAMB_RegNo"];
                                                            $yeargrad = $row["yeargrad"];
                                                            $cstudy = $row["cstudy"];
                                                            $coption = $row["coption"];
                                                            $degree = $row["degree"];
                                                            $Phone = $row["Phone"];
                                                            $email = $row["email"];
                                                            $StateOfOrigin = $row["StateOfOrigin"];
                                                            $lga = $row["lga"];
                                                            $PlaceBirth = $row["PlaceBirth"];
                                                            $dob = $row["dob"];
                                                            $sex = $row["sex"];
                                                            $marital = $row["marital"];
                                                            $next_rel = $row["next_rel"];
                                                            $next_addr = $row["next_addr"];
                                                            $next_email = $row["next_email"];
                                                            $ParmtAdress = $row["ParmtAdress"];

                                                            echo "<tr><td>$sno</td><td>$regid</td><td>$names</td><td hidden='hidden'>$JAMB</td><td hidden='hidden'>$yeargrad</td><td hidden='hidden'>$cstudy</td><td hidden='hidden'>$coption</td><td hidden='hidden'>$degree</td><td hidden='hidden'>$Phone</td><td hidden='hidden'>$email</td><td hidden='hidden'>$StateOfOrigin</td><td hidden='hidden'>$lga</td><td hidden='hidden'>$dob</td><td hidden='hidden'>$PlaceBirth</td><td hidden='hidden'>$sex</td><td hidden='hidden'>$marital</td><td hidden='hidden'>$ParmtAdress</td><td hidden='hidden'>$next_rel</td><td hidden='hidden'>$next_addr</td><td hidden='hidden'>$next_email</td>
													
													<td>
													<form action='stu_biodata_print.php' method='post'>
														  <input type='hidden' value=$id name='id'>
														  <input type='submit' name = 'view' class='btn btn-primary btn-xs' value='View'>
													</form>
													</td>
																  
															 
													</tr>\n";
                                                        }
                                                    }
                                                    ?>
                                            </tbody>
                                        </table>

                                    </div>
                                </section>
                                <div class="form-group">
                                    <!-- Buttons -->
                                    <div class="col-lg-offset-2 col-lg-9">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                            class="btn btn-primary">Download</a>
                                        <a href="picture_download.php" id="downloadpic" class="btn btn-primary">Download
                                            Pictures</a>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                            <div class="col-md-1">

                            </div>
                        </div>

                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <div class="wrapper wrapper-content">
                    <div class="row animated fadeInRight">

                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <?php
            include_once 'includes/footer2.php';
            ?>
        </div>

        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    $user1 = $_SESSION['staffid'];
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                APU
                            </li>
                            <li>PG Students Record</li>
                            <li class="active">
                                <strong>By Department</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            By Department
                        </div>
                        <div class="panel-body">
                            <!-- start: page -->
                            <div class="row">

                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="form-group">
                                        <label class="control-label col-lg-3" style="font-size: larger">Session</label>
                                        <div class="col-lg-4">
                                            <?php
                                            $iniyear = 2018;
                                            $finalyear = substr($_SESSION['corntsession'], 5);

                                            ?>
                                            <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                    <?php echo $_SESSION['corntsession'] ?></option>
                                                <?php
                                                while ($iniyear <= $finalyear) {
                                                    $addyear = $iniyear + 1;

                                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                    $iniyear++;
                                                }

                                                ?>

                                            </select>

                                        </div>
                                        <div class="col-lg-5">

                                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">
                                <?php

                                /*$sql = "SELECT * FROM staff_profile";
                $result = $conn7->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $PSN=$row["PSN"];
                        $name=$row["Name1"];
                        $parts = explode(" ", $name);
                        if(count($parts) > 1) {
                            $lastname = array_pop($parts);
                            $firstname = implode(" ", $parts);
                        }
                        else
                        {
                            $firstname = $name;
                            $lastname = " ";
                        }
                        $firstname = str_replace("'", "''", $firstname);
                        $lastname = str_replace("'", "''", $lastname);
                        $sql2="UPDATE staff_profile SET sname='$lastname', oname='$firstname' WHERE PSN='$PSN'";
                        $result2 = $conn7->query($sql2);
                        //echo "Lastname: $lastname\n";
                        //echo "Firstname: $firstname\n";
                    }
                }*/
                                //$_SESSION["getsession"]="XX";
                                ?>

                                <?php
                                set_time_limit(500);
                                error_reporting(E_ERROR);
                                $getsession = $_POST["getsession"];

                                $GetTitle = "Students Count by Department(" . $getsession . ")";

                                $totmale = $totfemale = $tottotal = $totPGDm = $totPGDf = $totMasterM = $totMasterF = $totPhDm = $totPhDf = 0;

                                ?>
                                <?php if (isset($_POST["submit"])) { ?>
                                    <h2><?php echo $GetTitle ?></h2>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Department</th>
                                                    <th>Male</th>
                                                    <th>Female</th>
                                                    <th>PGD(M)</th>
                                                    <th>PGD(F)</th>
                                                    <th>Masters(M)</th>
                                                    <th>Masters(F)</th>
                                                    <th>Ph.D(M)</th>
                                                    <th>Ph.D(F)</th>
                                                    <th>Total</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                //$sql = "SELECT * FROM deptcoding WHERE DeptCode='MAT' ORDER BY DeptName";
                                                $result = $conn5->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $DeptCode = $row["DeptCode"];
                                                        $DeptName = $row["DeptName"];

                                                        $male = $female = $total = 0;
                                                        $PGDm = $PGDf = $MasterM = $MasterF = $PhDm = $PhDf = 0;
                                                        $getdept = strtolower($DeptCode) . "_hod_list";
                                                        $sql2 = "SELECT * FROM " . $getdept . " WHERE Session1 = '$getsession'";
                                                        $result2 = $conn5->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $matricno = $row2["matricno"];
                                                                $matriclen = strlen($matricno);
                                                                if ($matriclen >= 10) {
                                                                    $StuLevel = $row2["StuLevel"];
                                                                    $sql3 = "SELECT * FROM e_data_profile WHERE regid = '$matricno'";
                                                                    $result3 = $conn4->query($sql3);
                                                                    $add1 = 0;
                                                                    if ($result3->num_rows > 0) {
                                                                        while ($row3 = $result3->fetch_assoc()) {
                                                                            $add1++;
                                                                            $appid = $row3["stdid"];
                                                                        }
                                                                    }
                                                                    if ($add1 > 0) {
                                                                        $sql3 = "SELECT * FROM pgapplication WHERE applicant_id = '$appid'";
                                                                        $result3 = $conn4->query($sql3);
                                                                        if ($result3->num_rows > 0) {
                                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                                $sex = strtoupper($row3["sex"]);
                                                                                $prog = strtoupper($row3["programme_title"]);
                                                                                if ($sex == "MALE" || $sex == "M") {
                                                                                    $male++;
                                                                                    $totmale++;
                                                                                    if ($prog == "PH.D" || $prog == "PhD") {
                                                                                        $PhDm++;
                                                                                        $totPhDm++;
                                                                                    } elseif ($prog == "PGD") {
                                                                                        $PGDm++;
                                                                                        $totPGDm++;
                                                                                    } else {
                                                                                        $MasterM++;
                                                                                        $totMasterM++;
                                                                                    }
                                                                                } elseif ($sex == "FEMALE" || $sex == "F") {
                                                                                    $female++;
                                                                                    $totfemale++;
                                                                                    if ($prog == "PH.D" || $prog == "PhD") {
                                                                                        $PhDf++;
                                                                                        $totPhDf++;
                                                                                    } elseif ($prog == "PGD") {
                                                                                        $PGDf++;
                                                                                        $totPGDf++;
                                                                                    } else {
                                                                                        $MasterF++;
                                                                                        $totMasterF++;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        $total = $male + $female;
                                                        if ($total > 0) {
                                                            $sno++;
                                                            echo "<tr><td>$sno</td><td>$DeptName</td><td>$male</td><td>$female</td><td>$PGDm</td><td>$PGDf</td><td>$MasterM</td><td>$MasterF</td><td>$PhDm</td><td>$PhDf</td>";
                                                            echo "<td>$total</td><td>
                                                <form action='dap_stu_list.php' method='post'>
                                                    <input type='hidden' value='$DeptCode' name='id'>
                                                    <input type='hidden' value='yesdept' name='deptstate'>
                                                    <input type='hidden' value='$getsession' name='mysession'>
                                                    <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                                </form>
                                                </td>
                                                    
                                                </tr>\n";
                                                        }
                                                    }
                                                }
                                                $tottotal = $totmale + $totfemale;
                                                echo "<tr><th></th><th>Total</th><th>$totmale</th><th>$totfemale</th><td>$totPGDm</td><td>$totPGDf</td><td>$totMasterM</td><td>$totMasterF</td><td>$totPhDm</td><td>$totPhDf</td>";
                                                echo "<th>$tottotal</th><th></th>
                                                            
                                   </tr>\n";
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <br><br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                    </div>

                                <?php } ?>
                            </div>
                            <!-- end: page -->

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
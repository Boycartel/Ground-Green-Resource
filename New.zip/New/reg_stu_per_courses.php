<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['reg_stu_per_courses'] == false) {
    header('Location: Home_Staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Check All checkbox-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        var $selectAll = $('#selectAll1'); // main checkbox inside table thead
        var $table = $('.tablechk1'); // table selector 
        var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
        var tdCheckboxChecked = 0; // checked checboxes

        // Select or deselect all checkboxes depending on main checkbox change
        $selectAll.on('click', function() {
            $tdCheckbox.prop('checked', this.checked);
        });

        // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
        $tdCheckbox.on('change', function(e) {
            tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                .length; // Get count of checkboxes that is checked
            // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
            $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
        })
    });
    </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Registered Students Per Course</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Registered Students Per Course</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Registered Students Per Course
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <div class="form-group">
                                            <label class="control-label col-lg-3" for="regid">Department:</label>
                                            <div class="col-lg-7">
                                                <select name="getccode" class="form-control" style="color:#000000"
                                                    id="getccode">
                                                    <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
                                                    $dept = $_SESSION['deptcode'];
                                                    $schcode = $_SESSION['schcode'];

                                                    if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept' AND students = 'yes'";
                                                    } elseif ($cat_Dean == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE School = '$schcode' AND students = 'yes' ORDER BY DeptName";
                                                    } else {
                                                        $sql = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptName";
                                                    }

                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $DeptCode = $row["DeptCode"];
                                                            $DeptName = $row["DeptName"];
                                                            echo "<option value=$DeptCode>$DeptName</option>";
                                                        }
                                                    }

                                                    $conn->close();

                                                    ?>

                                                </select>
                                            </div>
                                            <div class="col-lg-2">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-lg-1">

                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"])) { ?>
                                <div class="col-lg-12  col-md-12">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <form class="form-horizontal" method="post"
                                            action="reg_stu_per_courses_smt.php">
                                            <br>
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="regid">Session:</label>
                                                <div class="col-lg-8">
                                                    <?php
                                                        $iniyear = 2015;
                                                        $finalyear = substr($_SESSION['corntsession'], 5);

                                                        ?>
                                                    <select name="getsession" class="form-control" style="color:#000000"
                                                        id="getsession">

                                                        <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                            <?php echo $_SESSION['corntsession'] ?></option>
                                                        <?php
                                                            while ($iniyear <= $finalyear) {
                                                                $addyear = $iniyear + 1;

                                                                echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                                $iniyear++;
                                                            }

                                                            ?>

                                                    </select>
                                                </div>
                                            </div>
                                            <br>

                                            <table class="table mb-none tablechk1">
                                                <thead>
                                                    <tr>
                                                        <th><input type="checkbox" id="selectAll1"></th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                                        $deptcode = $_POST["getccode"];
                                                        $sql = "SELECT * FROM gencoursesupload WHERE Department = '$deptcode' ORDER BY C_codding";
                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {

                                                            while ($row = $result->fetch_assoc()) {
                                                                $id = $row["id"];
                                                                $ccode = $row["C_codding"];
                                                                $CTitle = $row["C_title"];

                                                                echo "<tr>
				                                                <td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
				                                                
				                                                <td>
				                                                <label id='ccode1' name='ccode1[" . $id . "]'>$ccode</label>
				                                                <input type='hidden' id='ccode1' name='ccode1[" . $id . "]' value='" . $ccode . "'/>
				                                                </td>
				                                                <td>
				                                                <label id='CTitle1' name='CTitle1[" . $id . "]'>$CTitle</label>
				                                                <input type='hidden' id='CTitle1' name='CTitle1[" . $id . "]' value='" . $CTitle . "'/>
				                                                </td>
				                                                
				                                                </tr>\n";
                                                            }
                                                        }
                                                        $conn->close();

                                                        ?>
                                                </tbody>
                                            </table>
                                            <br>
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                        </form>


                                    </div>
                                    <div class="col-lg-1">

                                    </div>


                                </div>



                                <?php } ?>
                            </div>
                            <!-- end: page -->

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Print Div-->
    <script type="text/javascript">
        function printme() {
            var print_div = document.getElementById("printablediv");
            var print_area = window.open();
            print_area.document.write(print_div.innerHTML);
            print_area.document.close();
            print_area.focus();
            print_area.print();
            print_area.close();
        }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Allocated</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Allocated</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Allocated
                        </div>
                        <div class="panel-body">
                            <div>
                                <div class="row">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <?php
                                        $corntsession = $_SESSION['corntsession'];
                                        $staffoffice = $_SESSION['staffoffice'];
                                        $ccode = $CTitle = $descriptn = "";
                                        $CUnit = 0;

                                        //if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                        if (isset($_POST["view"])) {
                                        ?>
                                            <form action='course_alocated_edit.php' method='post'>
                                                <?php
                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }

                                                $id = $_POST["id"];
                                                $status = $_POST["status"];
                                                $_SESSION['id'] = $id;
                                                $_SESSION['status'] = $status;

                                                $M = $T = $W = $Th = $F = $S = "";
                                                $sql = "SELECT * FROM coursealocation WHERE sn = '$id'";
                                                if ($status == "ug") {
                                                    $result = $conn->query($sql);
                                                } else {
                                                    $result = $conn5->query($sql);
                                                }
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $ccode = $row["CCode"];
                                                        $CTitle = $row["CTitle"];
                                                        $CUnit = $row["CUnit"];
                                                        $curri = $row["curri"];
                                                        $teamleader = $row["teamleader"];

                                                        $corntsession2 = str_replace("/", "_", $corntsession);
                                                        $sql2 = "SELECT * FROM courses_register_$corntsession2  WHERE CCode = '$ccode' AND Nature = '$curri'";
                                                        $result2 = $conn->query($sql2);
                                                        /*if ($status == "ug") {
                                                            $result2 = $conn->query($sql2);
                                                        } else {
                                                            $result2 = $conn5->query($sql2);
                                                        }*/
                                                        $countstu = mysqli_num_rows($result2);

                                                        $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$ccode' AND type1 = '$curri'";
                                                        $result2 = $conn->query($sql2);
                                                        /*if ($status == "ug") {
                                                            $result2 = $conn->query($sql2);
                                                        } else {
                                                            $result2 = $conn5->query($sql2);
                                                        }*/
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $descriptn = $row2["Descriptn"];
                                                                $M = $row2["M"];
                                                                $T = $row2["T"];
                                                                $W = $row2["W"];
                                                                $Th = $row2["Th"];
                                                                $F = $row2["F"];
                                                                $S = $row2["S"];

                                                                $MHr = $row2["MHr"];
                                                                $THr = $row2["THr"];
                                                                $WHr = $row2["WHr"];
                                                                $ThHr = $row2["ThHr"];
                                                                $FHr = $row2["FHr"];
                                                                $SHr = $row2["SHr"];
                                                                $venue = $row2["venue"];
                                                                $course_objective = $row2["course_objective"];
                                                                $lecture_outcome = $row2["lecture_outcome"];
                                                                $lecture_delivery = $row2["lecture_delivery"];
                                                                $evalu_method = $row2["evalu_method"];
                                                                $week1 = $row2["week1"];
                                                                $week2 = $row2["week2"];
                                                                $week3 = $row2["week3"];
                                                                $week4 = $row2["week4"];
                                                                $week5 = $row2["week5"];
                                                                $week6 = $row2["week6"];
                                                                $week7 = $row2["week7"];
                                                                $week8 = $row2["week8"];
                                                                $week9 = $row2["week9"];
                                                                $week10 = $row2["week10"];
                                                                $week11 = $row2["week11"];
                                                                $week12 = $row2["week12"];
                                                                $week13 = $row2["week13"];
                                                                $week14 = $row2["week14"];
                                                                $week15 = $row2["week15"];
                                                                $refmaterial1 = $row2["refmaterial1"];
                                                                $refmaterial2 = $row2["refmaterial2"];
                                                                $refmaterial3 = $row2["refmaterial3"];
                                                                $refmaterial4 = $row2["refmaterial4"];
                                                                $refmaterial5 = $row2["refmaterial5"];
                                                                $refmaterial6 = $row2["refmaterial6"];
                                                                $refmaterial7 = $row2["refmaterial7"];
                                                                $refmaterial8 = $row2["refmaterial8"];
                                                                $refmaterial9 = $row2["refmaterial9"];
                                                                $refmaterial10 = $row2["refmaterial10"];
                                                            }
                                                        }
                                                    }
                                                }

                                                $contday = "";
                                                if (strlen($M) > 0) {
                                                    $Hr = $MHr;
                                                    $Tm = $M;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Monday " . $M . " To " . $NTm . " <br>";
                                                    //$conthour =$conthour.$M.", ";
                                                }
                                                if (strlen($T) > 0) {
                                                    //$contday=$contday."Tuesday, ";
                                                    //$conthour =$conthour.$T.", ";
                                                    $Hr = $THr;
                                                    $Tm = $T;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Tuesday " . $T . " To " . $NTm . " <br>";
                                                }
                                                if (strlen($W) > 0) {
                                                    //$contday=$contday."Wednesday, ";
                                                    //$conthour =$conthour.$W.", ";
                                                    $Hr = $WHr;
                                                    $Tm = $W;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Wednesday " . $W . " To " . $NTm . " <br>";
                                                }
                                                if (strlen($Th) > 0) {
                                                    //$contday=$contday."Thursday, ";
                                                    //$conthour =$conthour.$Th.", ";
                                                    $Hr = $ThHr;
                                                    $Tm = $Th;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Thursday " . $Th . " To " . $NTm . " <br>";
                                                }
                                                if (strlen($F) > 0) {
                                                    //$contday=$contday."Friday, ";
                                                    //$conthour =$conthour.$F.", ";
                                                    $Hr = $FHr;
                                                    $Tm = $F;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Friday " . $F . " To " . $NTm . " <br>";
                                                }
                                                if (strlen($S) > 0) {
                                                    //$contday=$contday."Saturday, ";
                                                    //$conthour =$conthour.$S.", ";
                                                    $Hr = $SHr;
                                                    $Tm = $S;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Saturday " . $S . " To " . $NTm . " <br>";
                                                }


                                                ?>
                                                <table class="table mb-none">

                                                    <tbody>
                                                        <tr>
                                                            <td>Course Code: </td>
                                                            <td><?php echo $ccode ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Course Title: </td>
                                                            <td><?php echo $CTitle ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Credit Unit:</td>
                                                            <td><?php echo $CUnit ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Description: </td>
                                                            <td><?php echo $descriptn ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Registered Students: </td>
                                                            <td><?php echo $countstu ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Office Address: </td>
                                                            <td><?php echo $staffoffice ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Contact Hour(s): </td>
                                                            <td><?php echo $contday ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Venue: </td>
                                                            <td><?php echo $venue ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Objectives of the Course: </td>
                                                            <td><?php echo $course_objective ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Outcome: </td>
                                                            <td><?php echo $lecture_outcome ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Lecture Delivery: </td>
                                                            <td><?php echo $lecture_delivery ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Evaluation Methods: </td>
                                                            <td><?php echo $evalu_method ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 1: </td>
                                                            <td><?php echo $week1 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 2: </td>
                                                            <td><?php echo $week2 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 3: </td>
                                                            <td><?php echo $week3 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 4: </td>
                                                            <td><?php echo $week4 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 5: </td>
                                                            <td><?php echo $week5 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 6: </td>
                                                            <td><?php echo $week6 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 7: </td>
                                                            <td><?php echo $week7 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 8: </td>
                                                            <td><?php echo $week8 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 9: </td>
                                                            <td><?php echo $week9 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 10: </td>
                                                            <td><?php echo $week10 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 11: </td>
                                                            <td><?php echo $week11 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 12: </td>
                                                            <td><?php echo $week12 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 13: </td>
                                                            <td><?php echo $week13 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 14: </td>
                                                            <td><?php echo $week14 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Week 15: </td>
                                                            <td><?php echo $week15 ?></td>
                                                        </tr>

                                                        <tr>
                                                            <td>Reference Material(1): </td>
                                                            <td><?php echo $refmaterial1 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(2): </td>
                                                            <td><?php echo $refmaterial2 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(3): </td>
                                                            <td><?php echo $refmaterial3 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(4): </td>
                                                            <td><?php echo $refmaterial4 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(5): </td>
                                                            <td><?php echo $refmaterial5 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(6): </td>
                                                            <td><?php echo $refmaterial6 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(7): </td>
                                                            <td><?php echo $refmaterial7 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(8): </td>
                                                            <td><?php echo $refmaterial8 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(9): </td>
                                                            <td><?php echo $refmaterial9 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Reference Material(10): </td>
                                                            <td><?php echo $refmaterial10 ?></td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                                <br>
                                                <input type='hidden' value=<?php echo $ccode ?> name='ccode'>
                                                <input type="button" class='btn btn-primary btn-sm' value="Print" onclick="printme()">
                                                <?php if ($teamleader == "YES") { ?>
                                                    <input type='submit' name="edit" class='btn btn-info btn-sm' value='Edit' style="float:right">
                                                <?php } ?>
                                            </form>
                                            <?php
                                            $conn->close();
                                            ?>
                                        <?php } ?>


                                        <br><br>
                                        <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
                                        $stafid = $_SESSION['staffid'];

                                        $sql = "SELECT * FROM coursealocation WHERE PFNo = '$stafid' ORDER BY SessionReg DESC";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                        ?>

                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Session</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php
                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["sn"];
                                                        $c_session = $row["SessionReg"];



                                                        echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['Semester']}</td><td>{$row['SessionReg']}</td>";
                                                        if ($c_session == $corntsession) {
                                                            echo "<td>
												 <form action='' method='post'>
													  <input type='hidden' value='$id' name='id'>
													  <input type='hidden' value='ug' name='status'>
													  <input type='submit' name='view' class='btn btn-primary btn-xs' value='View Detail'>
												 </form>												
												</td>";
                                                        } else {
                                                            echo "<td></td>";
                                                        }
                                                        echo "</tr>\n";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>

                                        <?php } ?>
                                        <?php
                                        $conn->close();
                                        ?>
                                    </div>
                                    <div class="col-lg-1">

                                    </div>
                                </div>

                            </div>
                        </div>



                    </div>
                </div>

                <div class="footer">
                    <?php
                    include_once 'includes/footer2.php';
                    ?>
                </div>

                <div id="right-sidebar">

                    <?php
                    include_once 'includes/aside_right.php';
                    ?>

                </div>

            </div>
        </div>

        <!--Print -->
        <div id="printablediv" style="width: 100%; height: 200px;" hidden="hidden">
            <?php
            if (isset($_SESSION['id'])) {
                $id = $_SESSION['id'];
            } else {
                $id = 0;
            }

            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $status = $_SESSION['status'];
            $corntsession = $_SESSION['corntsession'];

            $M = $T = $W = $Th = $F = $S = '';
            $ccode = $CTitle = $CUnit = '';
            $MHr =  $THr = $WHr = $ThHr = $FHr = $SHr = 0;
            $venue = $course_objective = $lecture_outcome = $lecture_delivery = $evalu_method = $week1 = $week2 = $week3 = $week4 = $week5 = $week6 = $week7 = $week8 = $week9 = $week10 = $week11 = $week12 = $week13 = $week14 = $week15 = "";
            $refmaterial1 = $refmaterial2 = $refmaterial3 = $refmaterial4 = $refmaterial5 = $refmaterial6 = $refmaterial7 = $refmaterial8 = $refmaterial9 = $refmaterial10 = "";
            $countstu = 0;
            $sql = "SELECT * FROM coursealocation WHERE sn = '$id'";
            $result = $conn->query($sql);
            /*if ($status == "ug") {
                $result = $conn->query($sql);
            } else {
                $result = $conn5->query($sql);
            }*/

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $ccode = $row["CCode"];
                    $CTitle = $row["CTitle"];
                    $CUnit = $row["CUnit"];
                    $corntsession2 = str_replace("/", "_", $corntsession);
                    $sql2 = "SELECT * FROM courses_register_" . $corntsession2 . " WHERE CCode = '$ccode'";
                    $result2 = $conn->query($sql2);
                    /*if ($status == "ug") {
                        $result2 = $conn->query($sql2);
                    } else {
                        $result2 = $conn5->query($sql2);
                    }*/
                    $countstu = mysqli_num_rows($result2);
                    $semester = "1ST";
                    $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$ccode'";
                    $result2 = $conn->query($sql2);

                    if ($result2->num_rows > 0) {
                        while ($row2 = $result2->fetch_assoc()) {
                            $descriptn = $row2["Descriptn"];
                            $semester = $row2["semester"];
                            if ($semester == "1ST") {
                                $semester = "First Semester";
                            } else {
                                $semester = "Second Semester";
                            }
                            $M = $row2["M"];
                            $T = $row2["T"];
                            $W = $row2["W"];
                            $Th = $row2["Th"];
                            $F = $row2["F"];
                            $S = $row2["S"];

                            $MHr = $row2["MHr"];
                            $THr = $row2["THr"];
                            $WHr = $row2["WHr"];
                            $ThHr = $row2["ThHr"];
                            $FHr = $row2["FHr"];
                            $SHr = $row2["SHr"];
                            $venue = $row2["venue"];
                            $course_objective = $row2["course_objective"];
                            $lecture_outcome = $row2["lecture_outcome"];
                            $lecture_delivery = $row2["lecture_delivery"];
                            $evalu_method = $row2["evalu_method"];
                            $week1 = $row2["week1"];
                            $week2 = $row2["week2"];
                            $week3 = $row2["week3"];
                            $week4 = $row2["week4"];
                            $week5 = $row2["week5"];
                            $week6 = $row2["week6"];
                            $week7 = $row2["week7"];
                            $week8 = $row2["week8"];
                            $week9 = $row2["week9"];
                            $week10 = $row2["week10"];
                            $week11 = $row2["week11"];
                            $week12 = $row2["week12"];
                            $week13 = $row2["week13"];
                            $week14 = $row2["week14"];
                            $week15 = $row2["week15"];
                            $refmaterial1 = $row2["refmaterial1"];
                            $refmaterial2 = $row2["refmaterial2"];
                            $refmaterial3 = $row2["refmaterial3"];
                            $refmaterial4 = $row2["refmaterial4"];
                            $refmaterial5 = $row2["refmaterial5"];
                            $refmaterial6 = $row2["refmaterial6"];
                            $refmaterial7 = $row2["refmaterial7"];
                            $refmaterial8 = $row2["refmaterial8"];
                            $refmaterial9 = $row2["refmaterial9"];
                            $refmaterial10 = $row2["refmaterial10"];
                        }
                    }
                }
            }


            $contday = "";
            if (strlen($M) > 0) {
                $Hr = $MHr;
                $Tm = $M;
                include 'includes/lecture_period.php';
                $contday = $contday . "Monday " . $M . " To " . $NTm . " <br>";
                //$conthour =$conthour.$M.", ";
            }
            if (strlen($T) > 0) {
                //$contday=$contday."Tuesday, ";
                //$conthour =$conthour.$T.", ";
                $Hr = $THr;
                $Tm = $T;
                include 'includes/lecture_period.php';
                $contday = $contday . "Tuesday " . $T . " To " . $NTm . " <br>";
            }
            if (strlen($W) > 0) {
                //$contday=$contday."Wednesday, ";
                //$conthour =$conthour.$W.", ";
                $Hr = $WHr;
                $Tm = $W;
                include 'includes/lecture_period.php';
                $contday = $contday . "Wednesday " . $W . " To " . $NTm . " <br>";
            }
            if (strlen($Th) > 0) {
                //$contday=$contday."Thursday, ";
                //$conthour =$conthour.$Th.", ";
                $Hr = $ThHr;
                $Tm = $Th;
                include 'includes/lecture_period.php';
                $contday = $contday . "Thursday " . $Th . " To " . $NTm . " <br>";
            }
            if (strlen($F) > 0) {
                //$contday=$contday."Friday, ";
                //$conthour =$conthour.$F.", ";
                $Hr = $FHr;
                $Tm = $F;
                include 'includes/lecture_period.php';
                $contday = $contday . "Friday " . $F . " To " . $NTm . " <br>";
            }
            if (strlen($S) > 0) {
                //$contday=$contday."Saturday, ";
                //$conthour =$conthour.$S.", ";
                $Hr = $SHr;
                $Tm = $S;
                include 'includes/lecture_period.php';
                $contday = $contday . "Saturday " . $S . " To " . $NTm . " <br>";
            }





            ?>
            <center><strong><u>COURSEWARE OUTLINE</u></strong></center>
            <table style="width:100%" class="table mb-none">
                <tbody>
                    <tr>
                        <th style="width:20%; padding-bottom:0.5em; text-align:left">Session:</th>
                        <td style="padding:0.25em"><?php echo $corntsession ?></td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; text-align:left">Semester:</th>
                        <td style="padding:0.25em"><?php echo $semester ?></td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; vertical-align:top; text-align:left">Course Title/Code:
                        </th>
                        <td style="padding:0.25em; text-align:justify"><?php echo $CTitle . "(" . $ccode . ")" ?>
                        </td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; text-align:left">Credit Unit:</th>
                        <td style="padding:0.25em"><?php echo $CUnit ?></td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; text-align:left">Registered Students:</th>
                        <td style="padding:0.25em"><?php echo $countstu ?></td>
                    </tr>
                </tbody>

            </table>
            <br>
            <strong>Names, Offices and Contact Details of Course Lecturers:</strong>
            <ul>
                <?php
                $sql = "Select * from coursealocation WHERE CCode = '$ccode' AND SessionReg = '$corntsession'";
                $result = $conn->query($sql);
                /*if ($status == "ug") {
                    $result = $conn->query($sql);
                } else {
                    $result = $conn5->query($sql);
                }*/
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $fileno = $row["PFNo"];

                        $sql2 = "Select * from users WHERE staffid = '$fileno'";
                        $result2 = $conn->query($sql2);
                        if ($result2->num_rows > 0) {
                            while ($row2 = $result2->fetch_assoc()) {
                                $staname = $row2["full_name"];
                                $phone = $row2["phone"];
                                $email = $row2["emailAdd"];
                                $staffdept = strtoupper($row2["staffacddept"]);
                                $officeadd = $row2["office_address"];
                            }
                        }
                        $sql2 = "Select * from deptcoding WHERE DeptCode = '$staffdept'";
                        $result2 = $conn->query($sql2);
                        if ($result2->num_rows > 0) {
                            while ($row2 = $result2->fetch_assoc()) {
                                $staffdept2 = $row2["DeptName"];
                            }
                        }

                        echo "<li type='disc'><b>$staname</b> <br> Department of $staffdept2 <br> Contact No/email: $phone;  $email <br> Office: $officeadd</li><br>";
                    }
                }

                $conn->close();
                ?>

            </ul>

            <h4><strong><u>OUTLINE</u></strong></h4>
            <p style="text-align:justify"><b>Objectives of the Course:</b> <?php echo $course_objective ?></p>
            <p style="text-align:justify"><b>Outcome:</b> <?php echo $lecture_outcome ?></p>
            <p style="text-align:justify"><b>Lecture Delivery:</b> <?php echo $lecture_delivery ?></p>
            <p style="text-align:justify"><b>Evaluation Methods:</b> <?php echo $evalu_method ?></p>
            <table style="width:100%" class="table mb-none">
                <tbody>
                    <tr>
                        <th style="width:20%; padding-bottom:0.5em; vertical-align:top; text-align:left">Lecture
                            Period:
                        </th>
                        <td><?php echo $contday ?></td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; vertical-align:top; text-align:left">Lecture Venue:</th>
                        <td><?php echo $venue ?></td>
                    </tr>
                </tbody>
            </table>
            <h4><strong><u>SCHEME OF WORK</u></strong></h4>
            <table style="width:100%;" class="table mb-none">
                <thead>
                    <tr>
                        <th style="border: 0.5px solid black">Week</th>
                        <th style="border: 0.5px solid black">Topics</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="width:10%; text-align:center;border: 0.5px solid black">1</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week1 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center;border: 1px solid black">2</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week2 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">3</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week3 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">4</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week4 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">5</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week5 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">6</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week6 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">7</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week7 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">8</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week8 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">9</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week9 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">10</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week10 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">11</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week11 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">12</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week12 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">13</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week13 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">14</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week14 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 1px solid black">15</td>
                        <td style="text-align:justify;border: 1px solid black"><?php echo $week15 ?></td>
                    </tr>
                </tbody>
            </table>
            <h4><strong><u>RELEVANT REFERENCES</u></strong></h4>
            <ul>

                <?php
                if ($refmaterial1 <> "") {
                    echo "<li type='disc'>$refmaterial1</li><br>";
                }
                if ($refmaterial2 <> "") {
                    echo "<li type='disc'>$refmaterial2</li><br>";
                }
                if ($refmaterial3 <> "") {
                    echo "<li type='disc'>$refmaterial3</li><br>";
                }
                if ($refmaterial4 <> "") {
                    echo "<li type='disc'>$refmaterial4</li><br>";
                }
                if ($refmaterial5 <> "") {
                    echo "<li type='disc'>$refmaterial5</li><br>";
                }
                if ($refmaterial6 <> "") {
                    echo "<li type='disc'>$refmaterial6</li><br>";
                }
                if ($refmaterial7 <> "") {
                    echo "<li type='disc'>$refmaterial7</li><br>";
                }
                if ($refmaterial8 <> "") {
                    echo "<li type='disc'>$refmaterial8</li><br>";
                }
                if ($refmaterial9 <> "") {
                    echo "<li type='disc'>$refmaterial9</li><br>";
                }
                if ($refmaterial10 <> "") {
                    echo "<li type='disc'>$refmaterial10</li><br>";
                }
                ?>
            </ul>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>


</body>

</html>
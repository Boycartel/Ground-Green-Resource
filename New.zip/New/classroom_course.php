<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$usernames = $_SESSION['names'];
$cat = $_SESSION['cat'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$staffid = $_SESSION['staffid'];
$dept = strtoupper($_SESSION['deptcode']);
$_SESSION["course_title_assignment"] = "Assignment";


?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">
    <!-- Textarea Editor -->
    <link href="editor/css_/bootstrap3-wysihtml5.min.css" rel="stylesheet" media="screen" />
    <!--Download to excel-->
    <script src="assets/javascripts/tableToExcel_ATD.js"></script>
    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

    <style>
        .tooltip {
            position: relative;
            display: inline-block;
            border-bottom: 1px dotted black;
        }

        .tooltip .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: black;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px 0;

            /* Position the tooltip */
            position: absolute;
            z-index: 1;
        }

        .tooltip:hover .tooltiptext {
            visibility: visible;
        }
    </style>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <?php
                $imgpf = str_replace('.', '_', $_SESSION['staffid']);

                ?>

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php

                            echo "<img src='https://staff.futminna.edu.ng/" . strtoupper($_SESSION['deptcode']) . "/images/" . strtoupper($imgpf) . "/MyPic1.jpg' alt='$usernames' class='img-circle' width='50' height='50' />";
                            ?>
                        </figure>
                        <div class="profile-info">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $staffid ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="staff_profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_staff.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="lock_screen.php"><i class="fa fa-lock"></i> Lock
                                    Screen</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout_staff.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>




                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_staff_class.php'; ?>
            <!-- end: sidebar -->
            <?php
            if (isset($_POST["view_course"])) {
                $ccode = $_POST["getccode"];
                $_SESSION["ccode"] = $ccode;
            } else {
                $ccode = $_SESSION["ccode"];
            }

            $dbsession = str_replace("/", "_", $curtsession);
            $sql = "SELECT * FROM courses_register_" . $dbsession . " WHERE CCode = '$ccode'";
            $result = $conn->query($sql);
            $_SESSION["noregister"] = mysqli_num_rows($result);
            ?>
            <section role="main" class="content-body">
                <header class="page-header" style="background-color:<?php echo $_SESSION['sch_color'] ?>">
                    <h2><?php echo $ccode . ", " . $curtsession ?> Registered Students:
                        <?php echo number_format($_SESSION["noregister"], 0) ?></h2>
                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>

                                <a href="classroom_start.php" class='btn btn-primary btn-xs'><i class="fa fa-home"></i>
                                    Home</a>
                            </li>

                            <li>
                                <form class="form-horizontal bucket-form" method="Post">

                                    <input type="submit" value="Download Ass" name="all_assessment2" class='btn btn-success btn-xs' style="margin-right: 1em">

                                </form>

                            </li>

                        </ol>

                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">


                            <div class="nano">
                                <div class="form-group" style="padding-left: 1em; padding-right: 1em">
                                    <?php

                                    $course_note_url = "classroom/course_note/" . $ccode . ".pdf";
                                    ?>
                                    <div class="widget-header clearfix">

                                        <div class="pull-right">

                                        </div>
                                    </div>
                                </div>
                                <div class="nano-content">
                                    <h4 style="text-align: center;">Calendar</h4>
                                    <div data-plugin-datepicker data-plugin-skin="dark"></div>

                                    <div class="sidebar-widget widget-friends">
                                        <h3>Assignment(s)</h3>
                                        <table>
                                            <tbody>
                                                <ul>
                                                    <?php
                                                    $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$ccode' AND session1 = '$curtsession'";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["id"];
                                                            $assign_status = $row["status"];
                                                            $assign_no1 = $row["assignment_no"];
                                                            $sub_date = $row["deadline"];

                                                            if ($assign_status == "open") {
                                                                $assign_status2 = "Open";
                                                            } else {
                                                                $assign_status2 = "Closed";
                                                            }

                                                            $sub_date2 = date_format(date_create($sub_date), "d/m/Y");
                                                    ?>


                                                            <tr>
                                                                <td><img src="classroom/images/folder.png" alt="" class="img-circle" height="30px" width="30px">

                                                                </td>
                                                                <td>
                                                                    <?php
                                                                    if ($assign_no1 == 1) {
                                                                        echo "<span class='name'>1<sup>st</sup> Assignment</span>";
                                                                    } elseif ($assign_no1 == 2) {
                                                                        echo "<span class='name'>2<sup>nd</sup> Assignment</span>";
                                                                    } else {
                                                                        echo "<span class='name'>3<sup>rd</sup> Assignment</span>";
                                                                    }
                                                                    ?>
                                                                </td>


                                                            </tr>
                                                            <tr>
                                                                <td style="padding-right:1em">
                                                                    <time>Deadline: </time>
                                                                </td>
                                                                <td><time datetime="2014-04-19T00:00+00:00"><?php echo $sub_date2 ?></time>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding-right:1em">
                                                                    <time>Status: </time>
                                                                </td>
                                                                <td>
                                                                    <time><?php echo $assign_status2 ?></time>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding-bottom: 2em; padding-right:1em">

                                                                </td>
                                                                <td style="padding-bottom: 2em;">
                                                                    <form class="form-horizontal bucket-form" method="Post" action="classroom_view_assign.php">
                                                                        <input type='hidden' value='<?php echo $id ?>' name='id'>
                                                                        <input type="submit" value="View" name="view_assessment2" class='btn btn-success btn-xs'>

                                                                    </form>
                                                                </td>
                                                            </tr>


                                                    <?php
                                                        }
                                                    }
                                                    ?>


                                                </ul>
                                            </tbody>
                                        </table>

                                    </div>


                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">
                            <?php

                            //$ccode = $_SESSION["ccode"];

                            if (isset($_POST["cstatus"])) {
                                $id = $_POST["id"];
                                $delistatus = $_POST["delistatus"];

                                $sql2 = "UPDATE aaa_course_topic SET delivered = '$delistatus' WHERE id='$id'";
                                $result2 = $conn8->query($sql2);
                            }

                            $sql = "SELECT *  FROM gencoursesupload WHERE C_codding = '$ccode'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $getctitle = $row["C_title"];
                                    $credit = $row["credit"];
                                    $semester = $row["semester"];
                                    $totStu = $row["totStu"];
                                    $Descriptn = $row["Descriptn"];
                                    $venue = $row["venue"];
                                    $course_objective = $row["course_objective"];
                                    $lecture_outcome = $row["lecture_outcome"];
                                    $lecture_delivery = $row["lecture_delivery"];
                                    $evalu_method = $row["evalu_method"];
                                    $refmaterial1 = $row["refmaterial1"];
                                    $refmaterial2 = $row["refmaterial2"];
                                    $refmaterial3 = $row["refmaterial3"];
                                    $refmaterial4 = $row["refmaterial4"];
                                    $refmaterial5 = $row["refmaterial5"];
                                    $refmaterial6 = $row["refmaterial6"];
                                    $refmaterial7 = $row["refmaterial7"];
                                    $refmaterial8 = $row["refmaterial8"];
                                    $refmaterial9 = $row["refmaterial9"];
                                    $refmaterial10 = $row["refmaterial10"];
                                }
                            }


                            ?>
                            <div class="inner-toolbar clearfix" style="color:#ffffff">
                                <ul>

                                    <li>

                                        <?php echo $ccode . "  " . $getctitle ?>
                                    </li>
                                    <li>

                                    </li>
                                    <li class="right">

                                        <ul class="nav nav-pills nav-pills-primary">

                                            <li>
                                                <form class="form-horizontal form-bordered" method="post" action="classroom.php">

                                                    <input type='hidden' value='<?php echo $ccode ?>' name='getccode'>
                                                    <input type="submit" value="Course Forum & Chats" name="submit_ccode" class='btn btn-primary btn-xm'>
                                                </form>
                                            </li>

                                            <li>

                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>





                            <div class="row">
                                <div class="col-md-12">
                                    <section class="panel">
                                        <div class="panel-body">
                                            <div class="row">
                                                <!--Download Assessment-->
                                                <?php if (isset($_POST["all_assessment2"]) || isset($_POST["sub_all_ass"])) { ?>
                                                    <?php
                                                    $_SESSION["startchat"] = "NO";
                                                    $_SESSION["showchat"] = 0;
                                                    ?>

                                                    <div class="row">
                                                        <form class="form-horizontal form-bordered" method="post">
                                                            <div class="col-lg-2">

                                                            </div>
                                                            <div class="col-lg-8">
                                                                <div class="form-group">
                                                                    <label class="control-label col-lg-3" for="content">Select Course:</label>
                                                                    <div class="col-lg-7">
                                                                        <select class="country form-control" style="color:#000000" name="ass_course">
                                                                            <?php
                                                                            $sql = "SELECT * FROM coursealocation WHERE PFNo='$staffid' AND SessionReg='$curtsession' AND Semester='$cursemester' ORDER BY CCode";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    $CCode = $row["CCode"];
                                                                                    $CTitle = $row["CTitle"];
                                                                                    echo "<option value=$CCode>$CCode $CTitle</option>";
                                                                                }
                                                                            }
                                                                            ?>

                                                                        </select>
                                                                    </div>
                                                                    <div class="col-lg-2">
                                                                        <button type="submit" name="sub_all_ass" class="btn btn-primary btn-sm">Submit</button>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-2">

                                                            </div>
                                                        </form>
                                                    </div>
                                                    <hr class="separator" />
                                                    <?php if (isset($_POST["sub_all_ass"])) { ?>
                                                        <?php
                                                        $getasscourses = $_POST["ass_course"];

                                                        //$getccode=$_SESSION["getccode"]; 
                                                        //$staffid = $_SESSION['staffid'];
                                                        $curtsession = $_SESSION['corntsession'];
                                                        $usernames = $_SESSION['names'];
                                                        $topics_id = $_SESSION["topics_id"];

                                                        $sql = "SELECT C_codding, C_title FROM gencoursesupload WHERE C_codding = '$getasscourses'";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $getctitle = $row["C_title"];
                                                            }
                                                        }

                                                        $ass1_tot_mk = $ass2_tot_mk = $ass3_tot_mk = 0;
                                                        $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getasscourses' AND session1 = '$curtsession'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                if ($row["assignment_no"] == 1) {
                                                                    $ass1_tot_mk = $row["tot_mark"];
                                                                } elseif ($row["assignment_no"] == 2) {
                                                                    $ass2_tot_mk = $row["tot_mark"];
                                                                } elseif ($row["assignment_no"] == 3) {
                                                                    $ass3_tot_mk = $row["tot_mark"];
                                                                }
                                                            }
                                                        }

                                                        $q1_tot_mk = $q2_tot_mk = $q3_tot_mk = $q4_tot_mk = $q5_tot_mk = 0;
                                                        $sql = "SELECT * FROM aaa_quiz_list WHERE ccode = '$getasscourses' AND session1 = '$curtsession'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                if ($row["quiz_no"] == 1) {
                                                                    $q1_tot_mk = $row["no_question"];
                                                                } elseif ($row["quiz_no"] == 2) {
                                                                    $q2_tot_mk = $row["no_question"];
                                                                } elseif ($row["quiz_no"] == 3) {
                                                                    $q3_tot_mk = $row["no_question"];
                                                                } elseif ($row["quiz_no"] == 4) {
                                                                    $q4_tot_mk = $row["no_question"];
                                                                } elseif ($row["quiz_no"] == 5) {
                                                                    $q5_tot_mk = $row["no_question"];
                                                                }
                                                            }
                                                        }

                                                        ?>
                                                        <div class="col-lg-12">
                                                            <section class="panel">
                                                                <header class="panel-heading">

                                                                    <h2 class="panel-title">
                                                                        <?php echo $getctitle . " (" . $getasscourses . ")" ?>
                                                                    </h2>
                                                                </header>
                                                                <div class="panel-body">
                                                                    <?php
                                                                    set_time_limit(500);
                                                                    $GetTitle = $getctitle . " (" . $getasscourses . ")";
                                                                    $sno = 0;
                                                                    ?>
                                                                    <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups" frame="hsides" border="2">
                                                                        <caption><?php echo $GetTitle ?></caption>
                                                                        <colgroup align="center"></colgroup>
                                                                        <colgroup align="left"></colgroup>
                                                                        <colgroup span="2"></colgroup>
                                                                        <colgroup span="3" align="center"></colgroup>
                                                                        <thead style='text-align:center'>
                                                                            <tr>
                                                                                <th>S/No</th>
                                                                                <th>Matric No</th>
                                                                                <th>Name</th>
                                                                                <th>1<sup>st</sup>
                                                                                    Asst(<?php echo $ass1_tot_mk ?>%)</th>
                                                                                <th>2<sup>nd</sup>
                                                                                    Asst(<?php echo $ass2_tot_mk ?>%)</th>
                                                                                <th>3<sup>rd</sup>
                                                                                    Asst(<?php echo $ass3_tot_mk ?>%)</th>
                                                                                <th>Q1(<?php echo $q1_tot_mk ?>%)</th>
                                                                                <th>Q2(<?php echo $q2_tot_mk ?>%)</th>
                                                                                <th>Q3(<?php echo $q3_tot_mk ?>%)</th>
                                                                                <th>Q4(<?php echo $q4_tot_mk ?>%)</th>
                                                                                <th>Q5(<?php echo $q5_tot_mk ?>%)</th>

                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <?php
                                                                            $sno = 0;
                                                                            $sessionreplace = str_replace("/", "_", $curtsession);
                                                                            $sql = "SELECT * FROM courses_register_" . $sessionreplace . " WHERE session='$curtsession' AND CCode='$getasscourses' ORDER BY Regn1";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    $sno++;
                                                                                    $Regn1 = $row["Regn1"];
                                                                                    $name_ass = $row["name1"];
                                                                                    $ass1 = $ass2 = $ass3 = 0;
                                                                                    $q1 = $q2 = $q3 = $q4 = $q5 = 0;
                                                                                    $sql2 = "SELECT * FROM aaa_sub_assignment_" . $sessionreplace . " WHERE stureg='$Regn1' ORDER BY assign_no";
                                                                                    $result2 = $conn8->query($sql2);
                                                                                    if ($result2->num_rows > 0) {
                                                                                        while ($row2 = $result2->fetch_assoc()) {
                                                                                            if ($row2["assign_no"] == 1) {
                                                                                                $ass1 = $row2["scores"];
                                                                                            } elseif ($row2["assign_no"] == 2) {
                                                                                                $ass2 = $row2["scores"];
                                                                                            } elseif ($row2["assign_no"] == 3) {
                                                                                                $ass3 = $row2["scores"];
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    $sql2 = "SELECT * FROM aaa_quiz_results WHERE stureg='$Regn1'";
                                                                                    $result2 = $conn8->query($sql2);
                                                                                    if ($result2->num_rows > 0) {
                                                                                        while ($row2 = $result2->fetch_assoc()) {
                                                                                            $q1 = $row2["n1"];
                                                                                            $q2 = $row2["n2"];
                                                                                            $q3 = $row2["n3"];
                                                                                            $q4 = $row2["n4"];
                                                                                            $q5 = $row2["n5"];
                                                                                        }
                                                                                    }

                                                                                    echo "<tr><td>$sno</td><td>$Regn1</td><td>$name_ass</td><td>$ass1</td><td>$ass2</td><td>$ass3</td><td>$q1</td><td>$q2</td><td>$q3</td><td>$q4</td><td>$q5</td></tr>";
                                                                                }
                                                                            }
                                                                            ?>
                                                                        </tbody>
                                                                    </table>
                                                                    <br>
                                                                    <div style="text-align: left">
                                                                        <a href="classroom_course.php" class="btn btn-primary">Exit</a>
                                                                    </div>
                                                                    <div style="text-align: right">
                                                                        <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                                                    </div>
                                                                </div>
                                                            </section>
                                                        </div>
                                                    <?php } ?>
                                                <?php } ?>
                                                <!--End Download Assessment-->

                                            </div>
                                            <div class="row" style="background-color:ghostwhite;">
                                                <div class="col-md-5">
                                                    <h2 style="color: #663399;"><?php echo $ccode . "  " . $getctitle ?>
                                                    </h2>
                                                    <div class="progress light m-md">
                                                        <?php
                                                        $countcomp = 0;
                                                        $countnotcomp = 0;
                                                        $sql = "SELECT *  FROM aaa_course_topic WHERE ccode = '$ccode'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {

                                                                $delivered = $row["delivered"];
                                                                if ($delivered == "YES") {
                                                                    $countcomp++;
                                                                } else {
                                                                    $countnotcomp++;
                                                                }
                                                            }
                                                        }
                                                        $perct = round(($countcomp / ($countcomp + $countnotcomp)) * 100);
                                                        ?>
                                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $perct ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $perct ?>%;">
                                                            <?php echo $perct ?>% Complete
                                                        </div>
                                                    </div>
                                                    <h3><a href="<?php echo $course_note_url ?>" target="_blank"><img src="img/pdf_icon.png" width="40" height="40">
                                                            Click to Download <?php echo $ccode ?> Course Content</a>
                                                    </h3>
                                                </div>
                                                <div class="col-md-7" style="padding-right: 1em;">
                                                    <table class="table mb-none">
                                                        <thead>
                                                            <tr style="background-color:<?php echo $_SESSION['sch_color'] ?>; color:#ffffff">
                                                                <th>Day</th>
                                                                <th>8:00AM</th>
                                                                <th>9:00AM</th>
                                                                <th>10:00AM</th>
                                                                <th>11:00AM</th>
                                                                <th>12:00PM</th>
                                                                <th>1:00PM</th>
                                                                <th>2:00PM</th>
                                                                <th>3:00PM</th>
                                                                <th>4:00PM</th>
                                                                <th>5:00PM</th>
                                                                <th>6:00PM</th>

                                                            </tr>
                                                        </thead>
                                                        <?php
                                                        $getday = date('D');
                                                        if ($getday == "Mon") {
                                                            $getday = "M";
                                                        } elseif ($getday == "Tue") {
                                                            $getday = "T";
                                                        } elseif ($getday == "Wed") {
                                                            $getday = "W";
                                                        } elseif ($getday == "Thu") {
                                                            $getday = "Th";
                                                        } elseif ($getday == "Fri") {
                                                            $getday = "F";
                                                        } elseif ($getday == "Sat") {
                                                            $getday = "S";
                                                        }

                                                        $x = 0;
                                                        $ccodearry2[] = "";
                                                        $sql2 = "SELECT CCode FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$curtsession' AND Semester = '$cursemester'";
                                                        $result2 = $conn->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $ccodearry2[$x] = $row2['CCode'];
                                                                $x++;
                                                            }
                                                        }
                                                        ?>
                                                        <tbody>
                                                            <?php if ($getday == "M") { ?>
                                                                <tr style=" background-color:<?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                <?php } else { ?>
                                                                <tr>
                                                                <?php } ?>

                                                                <th>Mon</th>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '8AM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '9AM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '10AM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '11AM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '12PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '1PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '2PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '3PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '4PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '5PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>
                                                                <td style="font-size:12px">
                                                                    <?php

                                                                    for ($i = 0; $i < $x; $i++) {
                                                                        $CCode = $ccodearry2[$i];
                                                                        $sql = "SELECT MHr FROM gencoursesupload WHERE C_codding = '$CCode' AND M = '6PM'";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                echo $CCode . " (" . $row["MHr"] . " hr(s))";
                                                                            }
                                                                        }
                                                                    }

                                                                    ?>
                                                                </td>

                                                                </tr>
                                                                <?php if ($getday == "T") { ?>
                                                                    <tr style=" background-color: <?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                    <?php } else { ?>
                                                                    <tr>
                                                                    <?php } ?>
                                                                    <th>Tue</th>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '8AM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '9AM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '10AM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '11AM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '12PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '1PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '2PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '3PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '4PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '5PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>
                                                                    <td style="font-size:12px">
                                                                        <?php

                                                                        for ($i = 0; $i < $x; $i++) {
                                                                            $CCode = $ccodearry2[$i];
                                                                            $sql = "SELECT THr FROM gencoursesupload WHERE C_codding = '$CCode' AND T = '6PM'";
                                                                            $result = $conn->query($sql);
                                                                            if ($result->num_rows > 0) {
                                                                                while ($row = $result->fetch_assoc()) {
                                                                                    echo $CCode . " (" . $row["THr"] . " hr(s))";
                                                                                }
                                                                            }
                                                                        }

                                                                        ?>
                                                                    </td>

                                                                    </tr>
                                                                    <?php if ($getday == "W") { ?>
                                                                        <tr style=" background-color: <?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                        <?php } else { ?>
                                                                        <tr>
                                                                        <?php } ?>
                                                                        <th>Wed</th>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '8AM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '9AM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '10AM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '11AM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '12PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '1PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '2PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '3PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '4PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '5PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>
                                                                        <td style="font-size:12px">
                                                                            <?php

                                                                            for ($i = 0; $i < $x; $i++) {
                                                                                $CCode = $ccodearry2[$i];
                                                                                $sql = "SELECT WHr FROM gencoursesupload WHERE C_codding = '$CCode' AND W = '6PM'";
                                                                                $result = $conn->query($sql);
                                                                                if ($result->num_rows > 0) {
                                                                                    while ($row = $result->fetch_assoc()) {
                                                                                        echo $CCode . " (" . $row["WHr"] . " hr(s))";
                                                                                    }
                                                                                }
                                                                            }

                                                                            ?>
                                                                        </td>

                                                                        </tr>
                                                                        <?php if ($getday == "Th") { ?>
                                                                            <tr style=" background-color: <?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                            <?php } else { ?>
                                                                            <tr>
                                                                            <?php } ?>
                                                                            <th>Thur</th>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '8AM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '9AM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '10AM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '11AM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '12PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '1PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '2PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '3PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '4PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '5PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>
                                                                            <td style="font-size:12px">
                                                                                <?php

                                                                                for ($i = 0; $i < $x; $i++) {
                                                                                    $CCode = $ccodearry2[$i];
                                                                                    $sql = "SELECT ThHr FROM gencoursesupload WHERE C_codding = '$CCode' AND Th = '6PM'";
                                                                                    $result = $conn->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            echo $CCode . " (" . $row["ThHr"] . " hr(s))";
                                                                                        }
                                                                                    }
                                                                                }

                                                                                ?>
                                                                            </td>

                                                                            </tr>
                                                                            <?php if ($getday == "F") { ?>
                                                                                <tr style=" background-color: <?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                                <?php } else { ?>
                                                                                <tr>
                                                                                <?php } ?>
                                                                                <th>Fri</th>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '8AM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '9AM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '10AM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '11AM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '12PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '1PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '2PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '3PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '4PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '5PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>
                                                                                <td style="font-size:12px">
                                                                                    <?php

                                                                                    for ($i = 0; $i < $x; $i++) {
                                                                                        $CCode = $ccodearry2[$i];
                                                                                        $sql = "SELECT FHr FROM gencoursesupload WHERE C_codding = '$CCode' AND F = '6PM'";
                                                                                        $result = $conn->query($sql);
                                                                                        if ($result->num_rows > 0) {
                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                echo $CCode . " (" . $row["FHr"] . " hr(s))";
                                                                                            }
                                                                                        }
                                                                                    }

                                                                                    ?>
                                                                                </td>

                                                                                </tr>
                                                                                <?php if ($getday == "S") { ?>
                                                                                    <tr style=" background-color: <?php echo $_SESSION['sch_color'] ?>; color: #ffffff">
                                                                                    <?php } else { ?>


                                                                                    <tr>
                                                                                    <?php } ?>
                                                                                    <th>Sat</th>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '8AM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '9AM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '10AM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '11AM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '12PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '1PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '2PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '3PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '4PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '5PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>
                                                                                    <td style="font-size:12px">
                                                                                        <?php

                                                                                        for ($i = 0; $i < $x; $i++) {
                                                                                            $CCode = $ccodearry2[$i];
                                                                                            $sql = "SELECT SHr FROM gencoursesupload WHERE C_codding = '$CCode' AND S = '6PM'";
                                                                                            $result = $conn->query($sql);
                                                                                            if ($result->num_rows > 0) {
                                                                                                while ($row = $result->fetch_assoc()) {
                                                                                                    echo $CCode . " (" . $row["SHr"] . " hr(s))";
                                                                                                }
                                                                                            }
                                                                                        }

                                                                                        ?>
                                                                                    </td>

                                                                                    </tr>
                                                        </tbody>
                                                        <tfoot>
                                                            <tr style="background-color: <?php echo $_SESSION['sch_color'] ?>; color:#ffffff">
                                                                <th>Day</th>
                                                                <th>8:00AM</th>
                                                                <th>9:00AM</th>
                                                                <th>10:00AM</th>
                                                                <th>11:00AM</th>
                                                                <th>12:00PM</th>
                                                                <th>1:00PM</th>
                                                                <th>2:00PM</th>
                                                                <th>3:00PM</th>
                                                                <th>4:00PM</th>
                                                                <th>5:00PM</th>
                                                                <th>6:00PM</th>

                                                            </tr>
                                                        </tfoot>
                                                    </table>

                                                </div>
                                            </div>
                                            <hr>
                                            <p style="color: black;"><b>Credit Unit:</b> <?php echo $credit ?></p>
                                            <p><b>Semester:</b> <?php echo $semester ?></p>
                                            <p><b>Registered Students:</b> <?php echo number_format($totStu, 0) ?></p>
                                            <p><b>Description:</b> <?php echo $Descriptn ?></p>
                                            <br>
                                            <p><b>Course Objective:</b> <?php echo $course_objective ?></p>
                                            <p><b>Lecture Outcome:</b> <?php echo $lecture_outcome ?></p>
                                            <p><b>Lecture Delivery:</b> <?php echo $lecture_delivery ?></p>
                                            <p><b>Evaluation Method:</b> <?php echo $evalu_method ?></p>
                                            <br>
                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Topic</th>
                                                        <th>Video Lecture</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $snot = 0;
                                                    $sql = "SELECT *  FROM aaa_course_topic WHERE ccode = '$ccode'";
                                                    $result = $conn8->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $snot++;
                                                            $cvideoid = $row["id"];
                                                            $course_video_url = "classroom/video_note/" . $cvideoid . ".MP4";
                                                            $topics = $row["topics"];
                                                            $delivered = $row["delivered"];

                                                            echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$topics</td><td>";
                                                            echo "<video width='160' controls>
                                <source src='$course_video_url' type='video/mp4'>
                                
                                Your browser does not support HTML video.
                            </video>";
                                                            echo "</td><td>";

                                                            if ($delivered == "YES") {
                                                                echo "<form class='form-horizontal form-bordered' method='post'>";
                                                                echo "<input type='hidden' value='$cvideoid' name='id'>";
                                                                echo "<input type='hidden' value='NO' name='delistatus'>";
                                                                echo "<input type='submit' title='Click to Change to Not Completed' value='Completed' name='cstatus'
                                                                class='btn btn-default btn-xs'>";
                                                                echo "</form>";
                                                            } else {
                                                                echo "<form class='form-horizontal form-bordered' method='post' action=''>";
                                                                echo "<input type='hidden' value='$cvideoid' name='id'>";
                                                                echo "<input type='hidden' value='YES' name='delistatus'>";
                                                                echo "<input type='submit' title='Click to Change to Completed' value='Not Completed' name='cstatus'
                                                                class='btn btn-default btn-xs'>";
                                                                echo "</form>";
                                                            }


                                                            echo "</td></tr>";
                                                        }
                                                    }
                                                    ?>

                                                </tbody>
                                            </table>
                                            <br><br>
                                            <hr>
                                            <h3 style="text-align: center;">References/Further Reading</h3>
                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>References Area</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $snot = 0;
                                                    if (strlen($refmaterial1) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial1</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial2) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial2</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial3) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial3</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial4) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial4</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial5) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial5</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial6) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial6</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial7) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial7</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial8) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial8</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial9) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial9</td></tr</n>";
                                                    }
                                                    if (strlen($refmaterial10) > 2) {
                                                        $snot++;
                                                        echo "<tr><td style='font-size: large; color:#663399'>$snot</td><td style='font-size: large; color:#663399'>$refmaterial10</td></tr</n>";
                                                    }

                                                    ?>

                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="panel-footer">
                                            <?php echo $ccode . "  " . $getctitle ?>
                                        </div>
                                    </section>
                                </div>
                            </div>


                        </div>

                    </div>

                </section>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>

    <!--Textarea Editor-->
    <script src="editor/js_/app.js" type="text/javascript"></script>
    <script src="editor/js_/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="editor/js_/ckeditor.js" type="text/javascript"></script>
    <script src="editor/js_/jquery.js" type="text/javascript"></script>
    <script src="editor/js_/editor1.js" type="text/javascript"></script>
    <!--Insert Chat-->

</body>

</html>
<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Allocated</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Allocated</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Edit Course Information
                        </div>
                        <div class="panel-body">
                            <div>
                                <?php
                                //
                                if (isset($_POST["edit"])) {
                                    $ccode = $_POST["ccode"];
                                    $_SESSION["ccode"] = $ccode;
                                } else {
                                    $ccode = $_SESSION["ccode"];
                                }
                                $msg = "";
                                $staffid = $_SESSION['staffid'];
                                $status = $_SESSION['status'];
                                if (isset($_POST["submit"])) {
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $ccode2 = $_POST["ccode"];

                                    $week1 = str_replace("'", "''", $_POST['week1']);
                                    $week1 = filter_var($week1, FILTER_SANITIZE_STRING);
                                    $week2 = str_replace("'", "''", $_POST['week2']);
                                    $week2 = filter_var($week2, FILTER_SANITIZE_STRING);
                                    $week3 = str_replace("'", "''", $_POST['week3']);
                                    $week3 = filter_var($week3, FILTER_SANITIZE_STRING);
                                    $week4 = str_replace("'", "''", $_POST['week4']);
                                    $week4 = filter_var($week4, FILTER_SANITIZE_STRING);
                                    $week5 = str_replace("'", "''", $_POST['week5']);
                                    $week5 = filter_var($week5, FILTER_SANITIZE_STRING);
                                    $week6 = str_replace("'", "''", $_POST['week6']);
                                    $week6 = filter_var($week6, FILTER_SANITIZE_STRING);
                                    $week7 = str_replace("'", "''", $_POST['week7']);
                                    $week7 = filter_var($week7, FILTER_SANITIZE_STRING);
                                    $week8 = str_replace("'", "''", $_POST['week8']);
                                    $week8 = filter_var($week8, FILTER_SANITIZE_STRING);
                                    $week9 = str_replace("'", "''", $_POST['week9']);
                                    $week9 = filter_var($week9, FILTER_SANITIZE_STRING);
                                    $week10 = str_replace("'", "''", $_POST['week10']);
                                    $week10 = filter_var($week10, FILTER_SANITIZE_STRING);
                                    $week11 = str_replace("'", "''", $_POST['week11']);
                                    $week11 = filter_var($week11, FILTER_SANITIZE_STRING);
                                    $week12 = str_replace("'", "''", $_POST['week12']);
                                    $week12 = filter_var($week12, FILTER_SANITIZE_STRING);
                                    $week13 = str_replace("'", "''", $_POST['week13']);
                                    $week13 = filter_var($week13, FILTER_SANITIZE_STRING);
                                    $week14 = str_replace("'", "''", $_POST['week14']);
                                    $week14 = filter_var($week14, FILTER_SANITIZE_STRING);
                                    $week15 = str_replace("'", "''", $_POST['week15']);
                                    $week15 = filter_var($week15, FILTER_SANITIZE_STRING);
                                    $refmaterial1 = str_replace("'", "''", $_POST['refmaterial1']);
                                    $refmaterial1 = filter_var($refmaterial1, FILTER_SANITIZE_STRING);
                                    $refmaterial2 = str_replace("'", "''", $_POST['refmaterial2']);
                                    $refmaterial2 = filter_var($refmaterial2, FILTER_SANITIZE_STRING);
                                    $refmaterial3 = str_replace("'", "''", $_POST['refmaterial3']);
                                    $refmaterial3 = filter_var($refmaterial3, FILTER_SANITIZE_STRING);
                                    $refmaterial4 = str_replace("'", "''", $_POST['refmaterial4']);
                                    $refmaterial4 = filter_var($refmaterial4, FILTER_SANITIZE_STRING);
                                    $refmaterial5 = str_replace("'", "''", $_POST['refmaterial5']);
                                    $refmaterial5 = filter_var($refmaterial5, FILTER_SANITIZE_STRING);
                                    $refmaterial6 = str_replace("'", "''", $_POST['refmaterial6']);
                                    $refmaterial6 = filter_var($refmaterial6, FILTER_SANITIZE_STRING);
                                    $refmaterial7 = str_replace("'", "''", $_POST['refmaterial7']);
                                    $refmaterial7 = filter_var($refmaterial7, FILTER_SANITIZE_STRING);
                                    $refmaterial8 = str_replace("'", "''", $_POST['refmaterial8']);
                                    $refmaterial8 = filter_var($refmaterial8, FILTER_SANITIZE_STRING);
                                    $refmaterial9 = str_replace("'", "''", $_POST['refmaterial9']);
                                    $refmaterial9 = filter_var($refmaterial9, FILTER_SANITIZE_STRING);
                                    $refmaterial10 = str_replace("'", "''", $_POST['refmaterial10']);
                                    $refmaterial10 = filter_var($refmaterial10, FILTER_SANITIZE_STRING);

                                    $M = $_POST["M"];
                                    $T = $_POST["T"];
                                    $W = $_POST["W"];
                                    $Th = $_POST["Th"];
                                    $F = $_POST["F"];
                                    $S = $_POST["S"];

                                    $MHr = $_POST["MHr"];
                                    $THr = $_POST["THr"];
                                    $WHr = $_POST["WHr"];
                                    $ThHr = $_POST["ThHr"];
                                    $FHr = $_POST["FHr"];
                                    $SHr = $_POST["SHr"];
                                    $office_address = str_replace("'", "''", $_POST['office_address']);
                                    $office_address = filter_var($office_address, FILTER_SANITIZE_STRING);
                                    //$venue = $_POST["venue"];
                                    $venue = str_replace("'", "''", $_POST['venue']);
                                    $venue = filter_var($venue, FILTER_SANITIZE_STRING);
                                    //$course_objective = $_POST["course_objective"];
                                    $course_objective = str_replace("'", "''", $_POST['course_objective']);
                                    $course_objective = htmlspecialchars($course_objective);
                                    //$lecture_outcome = $_POST["lecture_outcome"];
                                    $lecture_outcome = str_replace("'", "''", $_POST['lecture_outcome']);
                                    $lecture_outcome = htmlspecialchars($lecture_outcome);
                                    //$lecture_delivery = $_POST["lecture_delivery"];
                                    $lecture_delivery = str_replace("'", "''", $_POST['lecture_delivery']);
                                    $lecture_delivery = htmlspecialchars($lecture_delivery);
                                    //$evalu_method = $_POST["evalu_method"];
                                    $evalu_method = str_replace("'", "''", $_POST['evalu_method']);
                                    $evalu_method = htmlspecialchars($evalu_method);



                                    $sql = "UPDATE gencoursesupload SET M='$M', T='$T', W='$W', Th='$Th', F='$F', S='$S', MHr='$MHr', THr='$THr', WHr='$WHr', ThHr='$ThHr', FHr='$FHr', SHr='$SHr', venue='$venue', course_objective='$course_objective', lecture_outcome='$lecture_outcome', lecture_delivery='$lecture_delivery', evalu_method='$evalu_method', week1='$week1', week2='$week2', week3='$week3', week4='$week4', week5='$week5', week6='$week6', week7='$week7', week8='$week8', week9='$week9', week10='$week10', week11='$week11', week12='$week12', week13='$week13', week14='$week14', week15='$week15', refmaterial1='$refmaterial1', refmaterial2='$refmaterial2', refmaterial3='$refmaterial3', refmaterial4='$refmaterial4', refmaterial5='$refmaterial5', refmaterial6='$refmaterial6', refmaterial7='$refmaterial7', refmaterial8='$refmaterial8', refmaterial9='$refmaterial9', refmaterial10='$refmaterial10' WHERE C_codding = '$ccode2'";
                                    if ($status == "ug") {
                                        $result = $conn->query($sql);
                                    } else {
                                        $result = $conn5->query($sql);
                                    }

                                    $sql = "UPDATE users SET office_address='$office_address' WHERE staffid = '$staffid'";
                                    $result = $conn->query($sql);

                                    $conn->close();
                                    //$msg = "Record Saved ...";
                                    echo "<script>location.replace('course_alocated.php')</script>";
                                }

    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

                                $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$ccode'";
                                if ($status == "ug") {
                                    $result2 = $conn->query($sql2);
                                } else {
                                    $result2 = $conn5->query($sql2);
                                }
                                if ($result2->num_rows > 0) {
                                    while ($row2 = $result2->fetch_assoc()) {
                                        $descriptn = $row2["Descriptn"];
                                        $M = $row2["M"];
                                        $MHr = $row2["MHr"];
                                        $T = $row2["T"];
                                        $THr = $row2["THr"];
                                        $W = $row2["W"];
                                        $WHr = $row2["WHr"];
                                        $Th = $row2["Th"];
                                        $ThHr = $row2["ThHr"];
                                        $F = $row2["F"];
                                        $FHr = $row2["FHr"];
                                        $S = $row2["S"];
                                        $SHr = $row2["SHr"];
                                        $venue = $row2["venue"];
                                        $course_objective = $row2["course_objective"];
                                        $lecture_outcome = $row2["lecture_outcome"];
                                        $lecture_delivery = $row2["lecture_delivery"];
                                        $evalu_method = $row2["evalu_method"];
                                        $week1 = $row2["week1"];
                                        $week2 = $row2["week2"];
                                        $week3 = $row2["week3"];
                                        $week4 = $row2["week4"];
                                        $week5 = $row2["week5"];
                                        $week6 = $row2["week6"];
                                        $week7 = $row2["week7"];
                                        $week8 = $row2["week8"];
                                        $week9 = $row2["week9"];
                                        $week10 = $row2["week10"];
                                        $week11 = $row2["week11"];
                                        $week12 = $row2["week12"];
                                        $week13 = $row2["week13"];
                                        $week14 = $row2["week14"];
                                        $week15 = $row2["week15"];
                                        $refmaterial1 = $row2["refmaterial1"];
                                        $refmaterial2 = $row2["refmaterial2"];
                                        $refmaterial3 = $row2["refmaterial3"];
                                        $refmaterial4 = $row2["refmaterial4"];
                                        $refmaterial5 = $row2["refmaterial5"];
                                        $refmaterial6 = $row2["refmaterial6"];
                                        $refmaterial7 = $row2["refmaterial7"];
                                        $refmaterial8 = $row2["refmaterial8"];
                                        $refmaterial9 = $row2["refmaterial9"];
                                        $refmaterial10 = $row2["refmaterial10"];
                                    }
                                }
                                $sql2 = "SELECT * FROM users WHERE staffid = '$staffid'";
                                $result2 = $conn->query($sql2);
                                if ($result2->num_rows > 0) {
                                    while ($row2 = $result2->fetch_assoc()) {
                                        $office_address = $row2["office_address"];
                                    }
                                }
                                ?>
                                <form action='course_alocated_edit.php' class="form-horizontal" role="form"
                                    method="post">
                                    <center>
                                        <p style="color:#009; font-weight:600"><?php echo $msg  ?></p>
                                    </center>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Course
                                            Code:</label>
                                        <div class="col-lg-9">
                                            <label class="control-label"><?php echo $ccode ?></label>
                                            <input type='hidden' value=<?php echo $ccode ?> name='ccode'>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Course
                                            Description:</label>
                                        <div class="col-lg-9">
                                            <label class="control-label"
                                                style="text-align:justify"><?php echo $descriptn ?></label>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Contact
                                            Hour(s):</label>
                                        <div class="col-lg-9">

                                            <table style="width:100%">
                                                <tbody>
                                                    <tr>
                                                        <td>Mon</td>
                                                        <td>Tue</td>
                                                        <td>Wed</td>
                                                        <td>Thu</td>
                                                        <td>Fri</td>
                                                        <td>Sat</td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <select name="M" class="form-control" style="color:#000000"
                                                                id="M">
                                                                <option value="<?php echo $M ?>"><?php echo $M ?>
                                                                </option>
                                                                <option value="">Null</option>
                                                                <option value="7AM">7AM</option>
                                                                <option value="8AM">8AM</option>
                                                                <option value="9AM">9AM</option>
                                                                <option value="10AM">10AM</option>
                                                                <option value="11AM">11AM</option>
                                                                <option value="12PM">12PM</option>
                                                                <option value="1PM">1PM</option>
                                                                <option value="2PM">2PM</option>
                                                                <option value="3PM">3PM</option>
                                                                <option value="4PM">4PM</option>
                                                                <option value="5PM">5PM</option>
                                                                <option value="6PM">6PM</option>
                                                                <option value="7PM">7PM</option>
                                                                <option value="8PM">8PM</option>
                                                            </select>Hour(s)
                                                            <select name="MHr" class="form-control"
                                                                style="color:#000000" id="MHr">
                                                                <option value="<?php echo $MHr ?>"><?php echo $MHr ?>
                                                                </option>
                                                                <option value="0">0</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select name="T" class="form-control" style="color:#000000"
                                                                id="T">
                                                                <option value="<?php echo $T ?>"><?php echo $T ?>
                                                                </option>
                                                                <option value="">Null</option>
                                                                <option value="7AM">7AM</option>
                                                                <option value="8AM">8AM</option>
                                                                <option value="9AM">9AM</option>
                                                                <option value="10AM">10AM</option>
                                                                <option value="11AM">11AM</option>
                                                                <option value="12PM">12PM</option>
                                                                <option value="1PM">1PM</option>
                                                                <option value="2PM">2PM</option>
                                                                <option value="3PM">3PM</option>
                                                                <option value="4PM">4PM</option>
                                                                <option value="5PM">5PM</option>
                                                                <option value="6PM">6PM</option>
                                                                <option value="7PM">7PM</option>
                                                                <option value="8PM">8PM</option>
                                                            </select>Hour(s)
                                                            <select name="THr" class="form-control"
                                                                style="color:#000000" id="THr">
                                                                <option value="<?php echo $THr ?>"><?php echo $THr ?>
                                                                </option>
                                                                <option value="0">0</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                            </select>

                                                        </td>
                                                        <td>
                                                            <select name="W" class="form-control" style="color:#000000"
                                                                id="W">
                                                                <option value="<?php echo $W ?>"><?php echo $W ?>
                                                                </option>
                                                                <option value="">Null</option>
                                                                <option value="7AM">7AM</option>
                                                                <option value="8AM">8AM</option>
                                                                <option value="9AM">9AM</option>
                                                                <option value="10AM">10AM</option>
                                                                <option value="11AM">11AM</option>
                                                                <option value="12PM">12PM</option>
                                                                <option value="1PM">1PM</option>
                                                                <option value="2PM">2PM</option>
                                                                <option value="3PM">3PM</option>
                                                                <option value="4PM">4PM</option>
                                                                <option value="5PM">5PM</option>
                                                                <option value="6PM">6PM</option>
                                                                <option value="7PM">7PM</option>
                                                                <option value="8PM">8PM</option>
                                                            </select>Hour(s)
                                                            <select name="WHr" class="form-control"
                                                                style="color:#000000" id="WHr">
                                                                <option value="<?php echo $WHr ?>"><?php echo $WHr ?>
                                                                </option>
                                                                <option value="0">0</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select name="Th" class="form-control" style="color:#000000"
                                                                id="Th">
                                                                <option value="<?php echo $Th ?>"><?php echo $Th ?>
                                                                </option>
                                                                <option value="">Null</option>
                                                                <option value="7AM">7AM</option>
                                                                <option value="8AM">8AM</option>
                                                                <option value="9AM">9AM</option>
                                                                <option value="10AM">10AM</option>
                                                                <option value="11AM">11AM</option>
                                                                <option value="12PM">12PM</option>
                                                                <option value="1PM">1PM</option>
                                                                <option value="2PM">2PM</option>
                                                                <option value="3PM">3PM</option>
                                                                <option value="4PM">4PM</option>
                                                                <option value="5PM">5PM</option>
                                                                <option value="6PM">6PM</option>
                                                                <option value="7PM">7PM</option>
                                                                <option value="8PM">8PM</option>
                                                            </select>Hour(s)
                                                            <select name="ThHr" class="form-control"
                                                                style="color:#000000" id="ThHr">
                                                                <option value="<?php echo $ThHr ?>"><?php echo $ThHr ?>
                                                                </option>
                                                                <option value="0">0</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select name="F" class="form-control" style="color:#000000"
                                                                id="F">
                                                                <option value="<?php echo $F ?>"><?php echo $F ?>
                                                                </option>
                                                                <option value="">Null</option>
                                                                <option value="7AM">7AM</option>
                                                                <option value="8AM">8AM</option>
                                                                <option value="9AM">9AM</option>
                                                                <option value="10AM">10AM</option>
                                                                <option value="11AM">11AM</option>
                                                                <option value="12PM">12PM</option>
                                                                <option value="1PM">1PM</option>
                                                                <option value="2PM">2PM</option>
                                                                <option value="3PM">3PM</option>
                                                                <option value="4PM">4PM</option>
                                                                <option value="5PM">5PM</option>
                                                                <option value="6PM">6PM</option>
                                                                <option value="7PM">7PM</option>
                                                                <option value="8PM">8PM</option>
                                                            </select>Hour(s)
                                                            <select name="FHr" class="form-control"
                                                                style="color:#000000" id="FHr">
                                                                <option value="<?php echo $FHr ?>"><?php echo $FHr ?>
                                                                </option>
                                                                <option value="0">0</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select name="S" class="form-control" style="color:#000000"
                                                                id="S">
                                                                <option value="<?php echo $S ?>"><?php echo $S ?>
                                                                </option>
                                                                <option value="">Null</option>
                                                                <option value="7AM">7AM</option>
                                                                <option value="8AM">8AM</option>
                                                                <option value="9AM">9AM</option>
                                                                <option value="10AM">10AM</option>
                                                                <option value="11AM">11AM</option>
                                                                <option value="12PM">12PM</option>
                                                                <option value="1PM">1PM</option>
                                                                <option value="2PM">2PM</option>
                                                                <option value="3PM">3PM</option>
                                                                <option value="4PM">4PM</option>
                                                                <option value="5PM">5PM</option>
                                                                <option value="6PM">6PM</option>
                                                                <option value="7PM">7PM</option>
                                                                <option value="8PM">8PM</option>
                                                            </select>Hour(s)
                                                            <select name="SHr" class="form-control"
                                                                style="color:#000000" id="SHr">
                                                                <option value="<?php echo $SHr ?>"><?php echo $SHr ?>
                                                                </option>
                                                                <option value="0">0</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                        </div>

                                    </div>

                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Office
                                            Address</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="office_address"
                                                cols="40" rows="3"><?php echo $office_address ?></textarea>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Venue(s)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="venue" cols="40"
                                                rows="3"><?php echo $venue ?></textarea>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Objectives of the
                                            Course</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="course_objective"
                                                cols="40" rows="4"><?php echo $course_objective ?></textarea>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Outcome</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="lecture_outcome"
                                                cols="40" rows="3"><?php echo $lecture_outcome ?></textarea>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Lecture
                                            Delivery</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="lecture_delivery"
                                                cols="40" rows="3"><?php echo $lecture_delivery ?></textarea>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Evaluation
                                            Methods</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="evalu_method"
                                                cols="40" rows="3"><?php echo $evalu_method ?></textarea>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 1</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week1" cols="40"
                                                rows="2"><?php echo $week1 ?></textarea>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 2</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week2" cols="40"
                                                rows="2"><?php echo $week2 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 3</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week3" cols="40"
                                                rows="2"><?php echo $week3 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 4</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week4" cols="40"
                                                rows="2"><?php echo $week4 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 5</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week5" cols="40"
                                                rows="2"><?php echo $week5 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 6</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week6" cols="40"
                                                rows="2"><?php echo $week6 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 7</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week7" cols="40"
                                                rows="2"><?php echo $week7 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 8</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week8" cols="40"
                                                rows="2"><?php echo $week8 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 9</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week9" cols="40"
                                                rows="2"><?php echo $week9 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 10</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week10" cols="40"
                                                rows="2"><?php echo $week10 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 11</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week11" cols="40"
                                                rows="2"><?php echo $week11 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 12</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week12" cols="40"
                                                rows="2"><?php echo $week12 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 13</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week13" cols="40"
                                                rows="2"><?php echo $week13 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 14</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week14" cols="40"
                                                rows="2"><?php echo $week14 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Week 15</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="week15" cols="40"
                                                rows="2"><?php echo $week15 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(1)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial1"
                                                cols="40" rows="2"><?php echo $refmaterial1 ?></textarea>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(2)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial2"
                                                cols="40" rows="2"><?php echo $refmaterial2 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(3)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial3"
                                                cols="40" rows="2"><?php echo $refmaterial3 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(4)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial4"
                                                cols="40" rows="2"><?php echo $refmaterial4 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(5)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial5"
                                                cols="40" rows="2"><?php echo $refmaterial5 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(6)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial6"
                                                cols="40" rows="2"><?php echo $refmaterial6 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(7)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial7"
                                                cols="40" rows="2"><?php echo $refmaterial7 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(8)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial8"
                                                cols="40" rows="2"><?php echo $refmaterial8 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(9)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial9"
                                                cols="40" rows="2"><?php echo $refmaterial9 ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label" style="font-weight:600">Reference
                                            Material(10)</label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" style="color:#000000" name="refmaterial10"
                                                cols="40" rows="2"><?php echo $refmaterial10 ?></textarea>
                                        </div>
                                    </div>
                                    <br>
                                    <input type='submit' class='btn btn-primary btn-sm' value='Submit' name="submit"
                                        style="float:right">
                                </form>
                                <?php
$conn->close();
?>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>
    </div>
    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
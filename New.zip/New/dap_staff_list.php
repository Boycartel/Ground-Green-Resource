<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>
    <script src="js/getexcel/tableToExcel_Staff.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>
                            <li><span>APU</span></li>
                            <li><span>Staff Record</span></li>
                            <?php
                            if (isset($_POST["view"])) {
                                $deptstate = $_POST["deptstate"];
                                if ($deptstate == "yesdept") {
                                    echo "<li><span>By Department</span></li>";
                                } else {
                                    echo "<li><span>By State of Origin</span></li>";
                                }
                            }

                            ?>

                            <li><span>Staff List</span></li>

                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Staff List
                        </div>
                        <div class="panel-body">
                            <?php
                            if (isset($_POST["view"])) {
                                $deptstate = $_POST["deptstate"];
                                $id = $_POST["id"];
                                $scale = $_POST["myscale"];
                                if ($deptstate == "yesdept") {
                                    $GetTitle = $id . " Department";
                                } else {
                                    $GetTitle = $id . " State";
                                }
                            }
                            ?>
                            <h2 class="panel-title"><?php echo $GetTitle ?></h2>
                            <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                    <caption><?php echo $GetTitle ?></caption>
                                    <colgroup align="center"></colgroup>
                                    <colgroup align="left"></colgroup>
                                    <colgroup span="2"></colgroup>
                                    <colgroup span="3" align="center"></colgroup>
                                    <thead style='text-align:center'>
                                        <tr>
                                            <th>S/No</th>
                                            <th>File No</th>
                                            <th>Surname</th>
                                            <th>Other Names</th>
                                            <th>Grade Level</th>
                                            <th>Step</th>
                                            <th>Rank</th>
                                            <th>Nationality</th>
                                            <th>Senatorial Zone</th>
                                            <th>State of Origin</th>
                                            <th>LGA</th>
                                            <th>Qualifications</th>
                                            <th>Date of Birth</th>
                                            <th>Employment Date</th>
                                            <th>Last Promotion Date</th>
                                            <th>Phone No</th>
                                            <th>email</th>
                                            <th>File No</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sno = 0;
                                        if ($deptstate == "yesdept") {
                                            $sql = "SELECT * FROM staff_profile WHERE DeptCode = '$id' AND Scale = '$scale' ORDER BY PSN";
                                        } elseif ($deptstate == "yesstate") {
                                            if ($id == "Non Nigerian") {
                                                $sql = "SELECT * FROM staff_profile WHERE nationality = '$id' AND Scale = '$scale' ORDER BY PSN";
                                            } else {
                                                $sql = "SELECT * FROM staff_profile WHERE stateOfOrigin = '$id' AND Scale = '$scale' ORDER BY PSN";
                                            }
                                        }

                                        $result = $conn7->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $sno++;
                                                $PSN = $row["PSN"];
                                                $sname = $row["sname"];
                                                $oname = $row["oname"];
                                                $GradeL = $row["GradeL"];
                                                $StepG = $row["StepG"];
                                                $Rank1 = $row["Rank1"];
                                                $nationality = $row["nationality"];
                                                $senate_distr = $row["senate_distr"];
                                                $stateOfOrigin = $row["stateOfOrigin"];
                                                $LGA = $row["LGA"];
                                                $qualification = $row["qualification"];
                                                $DateBirth = $row["DateBirth"];
                                                $FApptDate = $row["FApptDate"];
                                                $PApptDate = $row["PApptDate"];
                                                $phonenumber = $row["phonenumber"];
                                                $email = $row["email"];

                                                echo "<tr><td>$sno</td><td>$PSN</td><td>$sname</td><td>$oname</td><td>$GradeL</td><td>$StepG</td><td>$Rank1</td><td>$nationality</td><td>$senate_distr</td>
                                                <td>$stateOfOrigin</td><td>$LGA</td><td>$qualification</td><td>$DateBirth</td><td>$FApptDate</td><td>$PApptDate</td><td>$phonenumber</td><td>$email</td>";
                                                echo "<td>$PSN</td><td>
                                            <form action='staff_profile_print.php' method='post'>
                                                <input type='hidden' value='$PSN' name='id'>
                                                <input type='submit' name='viewdapProfile' class='btn btn-primary btn-xs' value='View'>
                                            </form>
                                            </td>
                                                
                                            </tr>\n";
                                            }
                                        }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <br><br>
                            <div style="text-align: right">
                                <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
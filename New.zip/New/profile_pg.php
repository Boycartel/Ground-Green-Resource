<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';


?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>


</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php include_once 'includes/header2_pg.php'; ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/pg_aside_menu.php'; ?>
            <!-- end: sidebar -->


            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>My Profile</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-user"></i>
                                </a>
                            </li>
                            <li><span>My Profile</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">
                    <div class="col-md-1">
                    </div>
                    <div class="col-md-10">
                        <section class="panel panel-success">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">My Profile</h2>
                            </header>
                            <div class="panel-body">
                                <?php

                                $schfull = $departfull = "";
                                $regno = $_SESSION["regid"];
                                $sql = "SELECT * FROM e_data_profile WHERE regid = '$regno'";
                                $result = $conn4->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $stuid = $row["stdid"];
                                        $paddr = $row["paddr"];
                                        $phone = $row["phone"];
                                        $marital = $row["marital"];
                                        $religion = $row["religion"];
                                        $blood_group = $row["blood_group"];
                                        $next_name = $row["next_name"];
                                        $next_rel = $row["next_rel"];
                                        $next_addr = $row["next_addr"];
                                        $next_phone = $row["next_phone"];
                                    }
                                    //$_SESSION['regno']=$regno;
                                    //$_SESSION['stuid']=$stuid;
                                }

                                $sql = "SELECT * FROM pgapplication WHERE applicant_id = '$stuid'";
                                $result = $conn4->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $application_date = $row["application_date"];
                                        $course1 = $row["course1"];
                                        $course_time = $row["course_time"];
                                        $programme_title = $row["programme_title"];
                                        $date_of_birth = $row["date_of_birth"];
                                        $surname = $row["surname"];
                                        $firstname = $row["firstname"];
                                        $middlename = $row["middlename"];
                                        $display_fullname = $row["display_fullname"];
                                        $email = $row["email"];
                                        $hq_degree = $row["hq_degree"];

                                        $m_institute = $row["m_institute"];
                                        $m_yr_grad = $row["m_yr_grad"];
                                        $m_degree_class = $row["m_degree_class"];
                                        $m_cgpa = $row["m_cgpa"];
                                        $m_gps = $row["m_gps"];
                                        $m_discipline = $row["m_discipline"];

                                        $b_institute = $row["b_institute"];
                                        $b_yr_grad = $row["b_yr_grad"];
                                        $b_degree_class = $row["b_degree_class"];
                                        $b_cgpa = $row["b_cgpa"];
                                        $b_gps = $row["b_gps"];
                                        $b_discipline = $row["b_discipline"];

                                        $p_institute = $row["p_institute"];
                                        $p_yr_grad = $row["p_yr_grad"];
                                        $p_degree_class = $row["p_degree_class"];
                                        $p_cgpa = $row["p_cgpa"];
                                        $p_gps = $row["p_gps"];
                                        $p_discipline = $row["p_discipline"];

                                        $h_institute = $row["h_institute"];
                                        $h_yr_grad = $row["h_yr_grad"];
                                        $h_degree_class = $row["h_degree_class"];
                                        $h_cgpa = $row["h_cgpa"];
                                        $h_gps = $row["h_gps"];
                                        $h_discipline = $row["h_discipline"];

                                        $o_institute = $row["o_institute"];
                                        $o_yr_grad = $row["o_yr_grad"];
                                        $o_degree_class = $row["o_degree_class"];
                                        $o_cgpa = $row["o_cgpa"];
                                        $o_gps = $row["o_gps"];
                                        $o_discipline = $row["o_discipline"];

                                        $lga = $row["lga"];
                                        //$p_address = $row["p_address"];
                                        $nationality = $row["nationality"];
                                        //$phone = $row["phone"];
                                        $sex = $row["sex"];
                                        //$blood_grp = $row["blood_grp"];
                                        $department = $row["department"];
                                        $school = $row["school"];
                                        $regid = $row["regid"];
                                    }
                                    //$_SESSION['regno']=$regno;
                                    //$_SESSION['stuid']=$stuid;
                                }

                                $length = strlen($lga);
                                $state = "";
                                $lga2 = "";
                                $countstate = 0;
                                for ($i = 0; $i < $length; $i++) {
                                    $c = $lga[$i];
                                    if ($c !== "_") {
                                        $state = $state . $c;
                                        $countstate++;
                                    } else {
                                        break;
                                    }
                                }

                                $countstate++;
                                for ($i = $countstate; $i < $length; $i++) {
                                    $c = $lga[$i];
                                    $lga2 = $lga2 . $c;
                                }


                                ?>

                                <form class="form-horizontal form-bordered" method="Post">

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Registration No. :</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo strtoupper($regno) ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Student ID:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo strtoupper($stuid) ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Surname:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $surname ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">First Name:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $firstname ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Other Names:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $middlename ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Gender:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $sex ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Parmenent Home Address:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $paddr ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Marital Status:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $marital ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Nationality:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $nationality ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">State of Origin:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo ucfirst($state) ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">LGA:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo ucfirst($lga2) ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Date of Birth:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $date_of_birth ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Place of Birth:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">School:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $school ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Department:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $department ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Programme of Study:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $course1 ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Programme Type:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo strtoupper($course_time) . " TIME" ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Programme Title:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $programme_title ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Highest Qualification:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $hq_degree ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Email:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $email ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Phone:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $phone ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Religion:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $religion ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Blood Group:</label>
                                        <div class="col-sm-8">
                                            <label class="control-label" style="color:#000"><?php echo $blood_group ?></label>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Certificates Obtained:</label>
                                        <div class="col-sm-8">
                                            <table class="table stats-table">
                                                <thead>
                                                    <tr>
                                                        <th>S/No</th>
                                                        <th>Certificate</th>
                                                        <th>Institution</th>
                                                        <th>Year of Graduation</th>
                                                        <th>Class of Degree</th>
                                                        <th>CGPA</th>
                                                        <th>Discipline</th>

                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                                    $sno2 = 0;
                                                    $sql = "SELECT * FROM pgapplication WHERE applicant_id = '$stuid'";
                                                    $result = $conn4->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {


                                                            if (strlen($o_institute) > 0) {
                                                                $sno2++;
                                                                echo "<tr><td>$sno2</td><td>OND</td><td>$o_institute</td><td>$o_yr_grad</td><td>$o_degree_class</td><td>$o_cgpa</td><td>$o_discipline</td></tr>";
                                                            }
                                                            if (strlen($h_institute) > 0) {
                                                                $sno2++;
                                                                echo "<tr><td>$sno2</td><td>HND</td><td>$h_institute</td><td>$h_yr_grad</td><td>$h_degree_class</td><td>$h_cgpa</td><td>$h_discipline</td></tr>";
                                                            }
                                                            if (strlen($p_institute) > 0) {
                                                                $sno2++;
                                                                echo "<tr><td>$sno2</td><td>PGD</td><td>$p_institute</td><td>$p_yr_grad</td><td>$p_degree_class</td><td>$p_cgpa</td><td>$p_discipline</td></tr>";
                                                            }
                                                            if (strlen($b_institute) > 0) {
                                                                $sno2++;
                                                                echo "<tr><td>$sno2</td><td>First Degree</td><td>$b_institute</td><td>$b_yr_grad</td><td>$b_degree_class</td><td>$b_cgpa</td><td>$b_discipline</td></tr>";
                                                            }
                                                            if (strlen($m_institute) > 0) {
                                                                $sno2++;
                                                                echo "<tr><td>$sno2</td><td>Masters Degree</td><td>$m_institute</td><td>$m_yr_grad</td><td>$m_degree_class</td><td>$m_cgpa</td><td>$m_discipline</td></tr>";
                                                            }
                                                        }
                                                    }

                                                    ?>

                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                    <br><br>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">O'Level Results:</label>
                                        <div class="col-sm-8">
                                            <table class="table stats-table">
                                                <thead>
                                                    <tr>
                                                        <th>S/No</th>
                                                        <th>Subject</th>
                                                        <th>Grade</th>

                                                    </tr>
                                                </thead>
                                                <tbody>

                                                    <?php
                                                    $sql = "SELECT * FROM pgapplication WHERE applicant_id = '$stuid'";
                                                    $result = $conn4->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {

                                                            $sub1 = $row["sub1"];
                                                            $sub2 = $row["sub2"];
                                                            $sub3 = $row["sub3"];
                                                            $sub4 = $row["sub4"];
                                                            $sub5 = $row["sub5"];
                                                            $sub6 = $row["sub6"];
                                                            $sub7 = $row["sub7"];

                                                            $grade1 = $row["grade1"];
                                                            $grade2 = $row["grade2"];
                                                            $grade3 = $row["grade3"];
                                                            $grade4 = $row["grade4"];
                                                            $grade5 = $row["grade5"];
                                                            $grade6 = $row["grade6"];
                                                            $grade7 = $row["grade7"];


                                                            echo "<tr><td>1</td><td>$sub1</td><td>$grade1</td></tr>";
                                                            echo "<tr><td>2</td><td>$sub2</td><td>$grade2</td></tr>";
                                                            echo "<tr><td>3</td><td>$sub3</td><td>$grade3</td></tr>";
                                                            echo "<tr><td>4</td><td>$sub4</td><td>$grade4</td></tr>";
                                                            echo "<tr><td>5</td><td>$sub5</td><td>$grade5</td></tr>";
                                                            echo "<tr><td>6</td><td>$sub6</td><td>$grade6</td></tr>";
                                                            echo "<tr><td>7</td><td>$sub7</td><td>$grade7</td></tr>";
                                                        }
                                                    }

                                                    ?>

                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Next of Kin:</label>
                                        <div class="col-sm-8">

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label"></label>
                                        <div class="col-sm-8">
                                            <table class="stats-table">

                                                <tbody>
                                                    <tr>
                                                        <th>Name:</th>
                                                        <td><?php echo $next_name ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Relationship:</th>
                                                        <td><?php echo $next_rel ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Address:</th>
                                                        <td><?php echo $next_addr ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Phone:</th>
                                                        <td><?php echo $next_phone ?></td>
                                                    </tr>

                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </section>
                    </div>
                    <div class="col-md-1">
                    </div>


                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
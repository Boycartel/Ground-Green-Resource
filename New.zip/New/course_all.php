<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_all'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <script src="js/getexcel/tableToExcel.js"></script>

    <!--Print Div-->
    <script type="text/javascript">
        function printme() {
            var print_div = document.getElementById("printablediv");
            var print_area = window.open();
            print_area.document.write(print_div.innerHTML);
            print_area.document.close();
            print_area.focus();
            print_area.print();
            print_area.close();
        }
    </script>
    <!--End Print Div-->
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Details</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Details</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php
                $id = 0;
                $schcode = $_SESSION['schcode2'];
                //$cat = $_SESSION['cat'];
                $dept = $_SESSION['deptcode'];
                $corntsession = $_SESSION['corntsession'];
                $numbschCurri = $_SESSION['numbschCurri'];

                if (isset($_POST["submit_dept"])) {
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $getdept = $_POST["getdept"];
                    $_SESSION['selAdminDept'] = $_POST["getdept"];
                    if ($getdept !== "All") {
                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$getdept'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $_SESSION['selAdminDeptName'] = $row["DeptName"];
                            }
                        }
                    } else {
                        $_SESSION['selAdminDeptName'] = "All Department";
                    }
                    $conn->close();
                } else {
                    $_SESSION['selAdminDeptName'] = $_SESSION['deptname'];
                }
                ?>
                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Details
                        </div>
                        <div class="panel-body">
                            < <?php if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES") { ?> <form class="form-horizontal form-bordered" method="post">
                                <div class="row">


                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="getdept">Department:</label>
                                            <div class="col-lg-7">
                                                <select name="getdept" class="form-control" style="color:#000000" id="getdept" required="required">
                                                    <option value='All'>All</option>

                                                    <?php
                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                    if ($conn->connect_error) {
                                                        die("Connection failed: " . $conn->connect_error);
                                                    }

                                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $DeptCode = $row["DeptCode"];
                                                            $DeptName = $row["DeptName"];
                                                            echo "<option value = '$DeptCode'>$DeptName</option>";
                                                        }
                                                    }

                                                    $sql = "SELECT * FROM schoolname ORDER BY SchName";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $SchCode = $row["SchCode"];
                                                            $SchName = $row["SchName"];
                                                            echo "<option value = '$SchCode'>$SchName</option>";
                                                        }
                                                    }
                                                    $conn->close();
                                                    ?>

                                                </select>
                                            </div>
                                        </div>

                                    </div>



                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-6"></label>
                                            <div class="col-lg-6">
                                                <button type="submit" name="submit_dept" class="btn btn-primary btn-sm">Submit</button>
                                            </div>
                                        </div>
                                    </div>

                                </div>



                                </form>
                            <?php } ?>
                            <div class="row" style="text-align: center;">
                                <?php
                                if (isset($_POST["submitAddNew"])) {

                                    $CCode = $_POST["CCode"];
                                    $CTitle = validate_input($_POST["CTitle"]);
                                    $CUnit = $_POST["CUnit"];
                                    $Semester = $_POST["Semester"];
                                    $Dept = $_POST["Dept"];
                                    $curri = $_POST["curri"];

                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = '$curri'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows == 0) {
                                        $sql2 = "INSERT INTO gencoursesupload(C_codding, C_title, credit, semester, Department, type1) VALUES ('$CCode', '$CTitle', '$CUnit', '$Semester', '$Dept', '$curri')";
                                        $result2 = $conn->query($sql2);
                                        echo "<h2 style='color: green'>Record Saved Successfully ...</h2>";
                                    } else {
                                        echo  "<h2 style='color: red'>$CCode Already Exist ...</h2>";
                                    }
                                    $conn->close();
                                }

                                if (isset($_POST["update"])) {
                                    $id = $_POST["id"];
                                    $CCode = $_POST["CCode"];
                                    $CTitle = validate_input($_POST["CTitle"]);
                                    $CUnit = $_POST["CUnit"];
                                    $Semester = $_POST["Semester"];
                                    $Dept = $_POST["Dept"];
                                    $curri = $_POST["curri"];
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $sql = "UPDATE gencoursesupload SET C_title ='$CTitle', credit ='$CUnit', semester ='$Semester', Department ='$Dept', type1 ='$curri' WHERE id='$id'";
                                    $result = $conn->query($sql);
                                    $conn->close();
                                    echo "<h2 style='color: green'>Record Saved Successfully ...</h2>";
                                }

                                if (isset($_POST["delete"])) {
                                    $id = $_POST["id"];

                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }
                                    $sql = "DELETE FROM gencoursesupload WHERE id = '$id'";
                                    $result = $conn->query($sql);
                                    $conn->close();
                                    echo "<h2 style='color: green'>Record Deleted Successfully ...</h2>";
                                }
                                ?>
                            </div>
                            <div class=" table-responsive">

                                <?php if (isset($_POST["download"])) { ?>

                                    <?php
                                    $GetTitle = "Course Details for " . $corntsession . " Session";

                                    ?>
                                    <table id="myTable" class="table table-hover margin bottom" style="font-size:12px" summary="" rules="groups" frame="hsides" border="2">
                                        <caption><?php echo $GetTitle ?></caption>
                                        <colgroup align="center"></colgroup>
                                        <colgroup align="left"></colgroup>
                                        <colgroup span="2"></colgroup>
                                        <colgroup span="3" align="center"></colgroup>
                                        <thead style='text-align:center'>
                                            <tr>
                                                <th>S/No</th>
                                                <th>Course Code</th>
                                                <th>Course Title</th>
                                                <th>Lecturers Details</th>
                                                <th>Objectives of the Course</th>
                                                <th>Outcome</th>
                                                <th>Lecture Delivery</th>
                                                <th>Evaluation Methods</th>
                                                <th>Lecture Period</th>
                                                <th>Lecture Venue</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            $M = $T = $W = $Th = $F = $S = '';
                                            if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES" || $cat_POs == "YES" || $cat_APU == "YES") {
                                                $selAdminDept = $_SESSION['selAdminDept'];
                                                if ($selAdminDept == "All") {
                                                    $sql2 = "SELECT * FROM gencoursesupload ORDER BY C_codding";
                                                } else {
                                                    $sql2 = "SELECT * FROM gencoursesupload WHERE Department = '$selAdminDept' ORDER BY C_codding";
                                                }
                                            } else if ($cat_HOD == "YES" || $cat_Examiner == "YES") {
                                                $sql2 = "SELECT * FROM gencoursesupload WHERE Department = '$dept' ORDER BY C_codding";
                                            }

                                            $sno = 0;
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $ccode = $row2["C_codding"];
                                                    $CTitle = $row2["C_title"];
                                                    $CUnit = $row2["credit"];
                                                    $sno++;

                                                    $descriptn = $row2["Descriptn"];
                                                    $semester = $row2["semester"];
                                                    if ($semester == "1ST") {
                                                        $semester = "First Semester";
                                                    } else {
                                                        $semester = "Second Semester";
                                                    }
                                                    $M = $row2["M"];
                                                    $T = $row2["T"];
                                                    $W = $row2["W"];
                                                    $Th = $row2["Th"];
                                                    $F = $row2["F"];
                                                    $S = $row2["S"];

                                                    $MHr = $row2["MHr"];
                                                    $THr = $row2["THr"];
                                                    $WHr = $row2["WHr"];
                                                    $ThHr = $row2["ThHr"];
                                                    $FHr = $row2["FHr"];
                                                    $SHr = $row2["SHr"];
                                                    $venue = $row2["venue"];
                                                    $course_objective = $row2["course_objective"];
                                                    $lecture_outcome = $row2["lecture_outcome"];
                                                    $lecture_delivery = $row2["lecture_delivery"];
                                                    $evalu_method = $row2["evalu_method"];
                                                    $week1 = $row2["week1"];
                                                    $week2 = $row2["week2"];
                                                    $week3 = $row2["week3"];
                                                    $week4 = $row2["week4"];
                                                    $week5 = $row2["week5"];
                                                    $week6 = $row2["week6"];
                                                    $week7 = $row2["week7"];
                                                    $week8 = $row2["week8"];
                                                    $week9 = $row2["week9"];
                                                    $week10 = $row2["week10"];
                                                    $week11 = $row2["week11"];
                                                    $week12 = $row2["week12"];
                                                    $week13 = $row2["week13"];
                                                    $week14 = $row2["week14"];
                                                    $week15 = $row2["week15"];
                                                    $refmaterial1 = $row2["refmaterial1"];
                                                    $refmaterial2 = $row2["refmaterial2"];
                                                    $refmaterial3 = $row2["refmaterial3"];
                                                    $refmaterial4 = $row2["refmaterial4"];
                                                    $refmaterial5 = $row2["refmaterial5"];
                                                    $refmaterial6 = $row2["refmaterial6"];
                                                    $refmaterial7 = $row2["refmaterial7"];
                                                    $refmaterial8 = $row2["refmaterial8"];
                                                    $refmaterial9 = $row2["refmaterial9"];
                                                    $refmaterial10 = $row2["refmaterial10"];
                                                    $staffdetails = "";

                                                    $sql = "SELECT * FROM coursealocation WHERE CCode = '$ccode' AND SessionReg = '$corntsession'";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $fileno = $row["PFNo"];

                                                            $sql3 = "Select * from users WHERE staffid = '$fileno'";
                                                            $result3 = $conn->query($sql3);
                                                            if ($result3->num_rows > 0) {
                                                                while ($row3 = $result3->fetch_assoc()) {
                                                                    $staname = $row3["full_name"];
                                                                    $phone = $row3["phone"];
                                                                    $email = $row3["emailAdd"];
                                                                    $staffdept = strtoupper($row3["staffacddept"]);
                                                                    $officeadd = $row3["office_address"];

                                                                    $sql4 = "Select * from deptcoding WHERE DeptCode = '$staffdept'";
                                                                    $result4 = $conn->query($sql4);
                                                                    if ($result4->num_rows > 0) {
                                                                        while ($row4 = $result4->fetch_assoc()) {
                                                                            $staffdept2 = $row4["DeptName"];
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            $staffdetails = $staffdetails . "<li type='disc'><b>$staname</b> <br> Department of $staffdept2 <br> Contact No/email: $phone;  $email <br> Office: $officeadd</li><br>";
                                                            //$staffdetails=$staffdetails. "<li type='disc'><b>$staname</b> , Department of $staffdept2 , Contact No/email: $phone;  $email , Office: $officeadd</li>";



                                                        }
                                                    }
                                                    $contday = "";
                                                    if (strlen($M) > 0) {
                                                        $Hr = $MHr;
                                                        $Tm = $M;
                                                        include 'includes/lecture_period.php';
                                                        $contday = $contday . "Monday " . $M . " To " . $NTm . " <br>";
                                                    }
                                                    if (strlen($T) > 0) {
                                                        $Hr = $THr;
                                                        $Tm = $T;
                                                        include 'includes/lecture_period.php';
                                                        $contday = $contday . "Tuesday " . $T . " To " . $NTm . " <br>";
                                                    }
                                                    if (strlen($W) > 0) {
                                                        $Hr = $WHr;
                                                        $Tm = $W;
                                                        include 'includes/lecture_period.php';
                                                        $contday = $contday . "Wednesday " . $W . " To " . $NTm . " <br>";
                                                    }
                                                    if (strlen($Th) > 0) {
                                                        $Hr = $ThHr;
                                                        $Tm = $Th;
                                                        include 'includes/lecture_period.php';
                                                        $contday = $contday . "Thursday " . $Th . " To " . $NTm . " <br>";
                                                    }
                                                    if (strlen($F) > 0) {
                                                        $Hr = $FHr;
                                                        $Tm = $F;
                                                        include 'includes/lecture_period.php';
                                                        $contday = $contday . "Friday " . $F . " To " . $NTm . " <br>";
                                                    }
                                                    if (strlen($S) > 0) {
                                                        $Hr = $SHr;
                                                        $Tm = $S;
                                                        include 'includes/lecture_period.php';
                                                        $contday = $contday . "Saturday " . $S . " To " . $NTm . " <br>";
                                                    }

                                                    //$sql = "SELECT * FROM courses_register WHERE CCode = '$ccode' AND session = '$corntsession'";
                                                    //$result = $conn->query($sql);
                                                    //$countstu=mysqli_num_rows($result);


                                                    echo "<tr><td>$sno</td><td>$ccode</td><td>$CTitle</td><td>$staffdetails</td><td>$course_objective</td><td>$lecture_outcome</td><td>$lecture_delivery</td><td>$evalu_method</td><td>$contday</td><td>$venue</td></tr>\n";
                                                }
                                            }
                                            $conn->close();
                                            echo "</tbody>";
                                            echo "</table>";
                                            ?>
                                            <br><br>
                                            <div class="form-group">
                                                <!-- Buttons -->
                                                <div class="col-lg-offset-2 col-lg-9">
                                                    <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                                </div>
                                            </div>

                                        <?php } ?>


                                        <?php if (isset($_POST["view"])) { ?>
                                            <?php

                                            $id = $_POST['id'];
                                            $_SESSION['id'] = $id;

                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            $sql = "SELECT * FROM coursealocation WHERE CCode = '$id' AND SessionReg = '$corntsession'";
                                            $result = $conn->query($sql);

                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $ccode = $row["CCode"];
                                                    $CTitle = $row["CTitle"];
                                                    $CUnit = $row["CUnit"];
                                                    $corntsession2 = str_replace("/", "_", $corntsession);
                                                    $sql2 = "SELECT * FROM courses_register_" . $corntsession2 . " WHERE CCode = '$ccode'";
                                                    $result2 = $conn->query($sql2);
                                                    $countstu = mysqli_num_rows($result2);
                                                    $M = $T = $W = $Th = $F = $S = '';
                                                    $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$ccode'";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result2->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $descriptn = $row2["Descriptn"];
                                                            $semester = $row2["semester"];
                                                            if ($semester == "1ST") {
                                                                $semester = "First Semester";
                                                            } else {
                                                                $semester = "Second Semester";
                                                            }
                                                            $M = $row2["M"];
                                                            $T = $row2["T"];
                                                            $W = $row2["W"];
                                                            $Th = $row2["Th"];
                                                            $F = $row2["F"];
                                                            $S = $row2["S"];

                                                            $MHr = $row2["MHr"];
                                                            $THr = $row2["THr"];
                                                            $WHr = $row2["WHr"];
                                                            $ThHr = $row2["ThHr"];
                                                            $FHr = $row2["FHr"];
                                                            $SHr = $row2["SHr"];
                                                            $venue = $row2["venue"];
                                                            $course_objective = $row2["course_objective"];
                                                            $lecture_outcome = $row2["lecture_outcome"];
                                                            $lecture_delivery = $row2["lecture_delivery"];
                                                            $evalu_method = $row2["evalu_method"];
                                                            $week1 = $row2["week1"];
                                                            $week2 = $row2["week2"];
                                                            $week3 = $row2["week3"];
                                                            $week4 = $row2["week4"];
                                                            $week5 = $row2["week5"];
                                                            $week6 = $row2["week6"];
                                                            $week7 = $row2["week7"];
                                                            $week8 = $row2["week8"];
                                                            $week9 = $row2["week9"];
                                                            $week10 = $row2["week10"];
                                                            $week11 = $row2["week11"];
                                                            $week12 = $row2["week12"];
                                                            $week13 = $row2["week13"];
                                                            $week14 = $row2["week14"];
                                                            $week15 = $row2["week15"];
                                                            $refmaterial1 = $row2["refmaterial1"];
                                                            $refmaterial2 = $row2["refmaterial2"];
                                                            $refmaterial3 = $row2["refmaterial3"];
                                                            $refmaterial4 = $row2["refmaterial4"];
                                                            $refmaterial5 = $row2["refmaterial5"];
                                                            $refmaterial6 = $row2["refmaterial6"];
                                                            $refmaterial7 = $row2["refmaterial7"];
                                                            $refmaterial8 = $row2["refmaterial8"];
                                                            $refmaterial9 = $row2["refmaterial9"];
                                                            $refmaterial10 = $row2["refmaterial10"];
                                                        }
                                                    }
                                                }

                                            ?>
                                                <?php
                                                $contday = "";
                                                if (strlen($M) > 0) {
                                                    $Hr = $MHr;
                                                    $Tm = $M;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Monday " . $M . " To " . $NTm . " <br>";
                                                    //$conthour =$conthour.$M.", ";
                                                }
                                                if (strlen($T) > 0) {
                                                    //$contday=$contday."Tuesday, ";
                                                    //$conthour =$conthour.$T.", ";
                                                    $Hr = $THr;
                                                    $Tm = $T;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Tuesday " . $T . " To " . $NTm . " <br>";
                                                }
                                                if (strlen($W) > 0) {
                                                    //$contday=$contday."Wednesday, ";
                                                    //$conthour =$conthour.$W.", ";
                                                    $Hr = $WHr;
                                                    $Tm = $W;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Wednesday " . $W . " To " . $NTm . " <br>";
                                                }
                                                if (strlen($Th) > 0) {
                                                    //$contday=$contday."Thursday, ";
                                                    //$conthour =$conthour.$Th.", ";
                                                    $Hr = $ThHr;
                                                    $Tm = $Th;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Thursday " . $Th . " To " . $NTm . " <br>";
                                                }
                                                if (strlen($F) > 0) {
                                                    //$contday=$contday."Friday, ";
                                                    //$conthour =$conthour.$F.", ";
                                                    $Hr = $FHr;
                                                    $Tm = $F;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Friday " . $F . " To " . $NTm . " <br>";
                                                }
                                                if (strlen($S) > 0) {
                                                    //$contday=$contday."Saturday, ";
                                                    //$conthour =$conthour.$S.", ";
                                                    $Hr = $SHr;
                                                    $Tm = $S;
                                                    include 'includes/lecture_period.php';
                                                    $contday = $contday . "Saturday " . $S . " To " . $NTm . " <br>";
                                                }





                                                ?>
                                                <center><strong><u>COURSEWARE OUTLINE</u></strong></center>
                                                <table style="width:100%" class="table table-hover margin bottom">
                                                    <tbody>
                                                        <tr>
                                                            <th style="width:20%; padding-bottom:0.5em; text-align:left">
                                                                Session:</th>
                                                            <td style="padding:0.25em"><?php echo $corntsession ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th style="padding-bottom:0.5em; text-align:left">
                                                                Semester:</th>
                                                            <td style="padding:0.25em"><?php echo $semester ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th style="padding-bottom:0.5em; vertical-align:top; text-align:left">
                                                                Course Title/Code:</th>
                                                            <td style="padding:0.25em; text-align:justify">
                                                                <?php echo $CTitle . "(" . $ccode . ")" ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th style="padding-bottom:0.5em; text-align:left">Credit
                                                                Unit:</th>
                                                            <td style="padding:0.25em"><?php echo $CUnit ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <br>
                                                <strong>Names, Offices and Contact Details of Course
                                                    Lecturers:</strong>
                                                <ul>
                                                    <?php
                                                    $sql = "Select * from coursealocation WHERE CCode = '$ccode' AND SessionReg = '$corntsession'";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $fileno = $row["PFNo"];

                                                            $sql2 = "Select * from users WHERE staffid = '$fileno'";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $staname = $row2["full_name"];
                                                                    $phone = $row2["phone"];
                                                                    $email = $row2["emailAdd"];
                                                                    $staffdept = strtoupper($row2["staffacddept"]);
                                                                    $officeadd = $row2["office_address"];
                                                                }
                                                            }
                                                            $sql2 = "Select * from deptcoding WHERE DeptCode = '$staffdept'";
                                                            $result2 = $conn->query($sql2);
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $staffdept2 = $row2["DeptName"];
                                                                }
                                                            }

                                                            echo "<li type='disc'><b>$staname</b> <br> Department of $staffdept2 <br> Contact No/email: $phone;  $email <br> Office: $officeadd</li><br>";
                                                        }
                                                    }
                                                    ?>

                                                </ul>

                                                <h4><strong><u>OUTLINE</u></strong></h4>
                                                <p style="text-align:justify"><b>Objectives of the Course:</b>
                                                    <?php echo $course_objective ?></p>
                                                <p style="text-align:justify"><b>Outcome:</b>
                                                    <?php echo $lecture_outcome ?></p>
                                                <p style="text-align:justify"><b>Lecture Delivery:</b>
                                                    <?php echo $lecture_delivery ?></p>
                                                <p style="text-align:justify"><b>Evaluation Methods:</b>
                                                    <?php echo $evalu_method ?></p>
                                                <table style="width:100%" class="table table-hover margin bottom">
                                                    <tbody>
                                                        <tr>
                                                            <th style="width:20%; padding-bottom:0.5em; vertical-align:top; text-align:left">
                                                                Lecture Period:</th>
                                                            <td><?php echo $contday ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th style="padding-bottom:0.5em; vertical-align:top; text-align:left">
                                                                Lecture Venue:</th>
                                                            <td><?php echo $venue ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <h4><strong><u>SCHEME OF WORK</u></strong></h4>
                                                <table style="width:100%;" class="table table-hover margin bottom">
                                                    <thead>
                                                        <tr>
                                                            <th style="border: 0.5px solid black">Week</th>
                                                            <th style="border: 0.5px solid black">Topics</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td style="width:10%; text-align:center;border: 0.5px solid black">
                                                                1
                                                            </td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week1 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center;border: 0.5px solid black">
                                                                2</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week2 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                3</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week3 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                4</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week4 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                5</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week5 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                6</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week6 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                7</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week7 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                8</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week8 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                9</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week9 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                10</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week10 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                11</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week11 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                12</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week12 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                13</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week13 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                14</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week14 ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td style="text-align:center; padding:0.25em;border: 0.5px solid black">
                                                                15</td>
                                                            <td style="text-align:justify;border: 0.5px solid black">
                                                                <?php echo $week15 ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <h4><strong><u>RELEVANT REFERENCES</u></strong></h4>
                                                <ul>

                                                    <?php
                                                    if ($refmaterial1 <> "") {
                                                        echo "<li type='disc'>$refmaterial1</li><br>";
                                                    }
                                                    if ($refmaterial2 <> "") {
                                                        echo "<li type='disc'>$refmaterial2</li><br>";
                                                    }
                                                    if ($refmaterial3 <> "") {
                                                        echo "<li type='disc'>$refmaterial3</li><br>";
                                                    }
                                                    if ($refmaterial4 <> "") {
                                                        echo "<li type='disc'>$refmaterial4</li><br>";
                                                    }
                                                    if ($refmaterial5 <> "") {
                                                        echo "<li type='disc'>$refmaterial5</li><br>";
                                                    }
                                                    if ($refmaterial6 <> "") {
                                                        echo "<li type='disc'>$refmaterial6</li><br>";
                                                    }
                                                    if ($refmaterial7 <> "") {
                                                        echo "<li type='disc'>$refmaterial7</li><br>";
                                                    }
                                                    if ($refmaterial8 <> "") {
                                                        echo "<li type='disc'>$refmaterial8</li><br>";
                                                    }
                                                    if ($refmaterial9 <> "") {
                                                        echo "<li type='disc'>$refmaterial9</li><br>";
                                                    }
                                                    if ($refmaterial10 <> "") {
                                                        echo "<li type='disc'>$refmaterial10</li><br>";
                                                    }
                                                    ?>
                                                </ul>
                                                <div style="text-align: right">
                                                    <input type="button" class='btn btn-primary btn-sm' value="Print" onclick="printme()">
                                                </div>
                                                <br>
                                                <hr class="separator" />
                                            <?php } else { ?>
                                                <h3 style="color:#F00"><b></b><?php echo $id ?> Not allocated
                                                    <?php echo $corntsession ?> Session</b></h3>
                                            <?php } ?>
                                            <?php
                                            $conn->close();
                                            ?>
                                        <?php } ?>


                                        <div class="row">
                                            <div class="col-sm-7">
                                                <h3><?php echo $_SESSION['selAdminDeptName']  ?> Department</h3>
                                            </div>
                                            <div class="col-sm-3">

                                            </div>
                                            <div class="col-sm-2">
                                                <?php if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES") { ?>
                                                    <a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons"></i> <span>Add
                                                            New</span></a>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="x_content table-responsive">

                                            <table class="table table-striped table-bordered table-hover dataTables-example">
                                                <thead>
                                                    <tr>
                                                        <th>S/No</th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Semester</th>
                                                        <th>Unit</th>
                                                        <th>Department</th>
                                                        <?php if ($numbschCurri > 1) { ?>
                                                            <th>Curriculum</th>
                                                        <?php } ?>
                                                        <th>#</th>
                                                        <?php
                                                        if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES") {
                                                            echo "<th>#</th>";
                                                            echo "<th>#</th>";
                                                        }
                                                        ?>

                                                    </tr>
                                                </thead>


                                                <tbody>

                                                    <?php
                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                    if ($conn->connect_error) {
                                                        die("Connection failed: " . $conn->connect_error);
                                                    }
                                                    if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES" || $cat_POs == "YES" || $cat_APU == "YES") {
                                                        $selAdminDept = $_SESSION['selAdminDept'];
                                                        if ($selAdminDept == "All") {
                                                            $sql = "SELECT id, C_codding, C_title, credit, semester, Department, Descriptn, type1 FROM gencoursesupload ORDER BY Department, C_codding";
                                                        } else {
                                                            $sql = "SELECT id, C_codding, C_title, credit, semester, Department, Descriptn, type1 FROM gencoursesupload WHERE Department = '$selAdminDept' ORDER BY Department, C_codding";
                                                        }
                                                    } else if ($cat_HOD == "YES" || $cat_Examiner == "YES") {
                                                        $sql = "SELECT id, C_codding, C_title, credit, semester, Department, Descriptn, type1 FROM gencoursesupload WHERE Department = '$dept' ORDER BY C_codding, semester";
                                                    }

                                                    $sno = 0;
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $id = $row['id'];
                                                            $C_codding = $row['C_codding'];
                                                            $C_title = $row['C_title'];
                                                            $credit = $row['credit'];
                                                            $semester = $row['semester'];
                                                            $Department = $row['Department'];
                                                            $type1 = $row['type1'];

                                                            echo "<tr><td>$sno</td><td>$C_codding</td><td>$C_title</td><td>$semester</td><td>$credit</td><td>$Department</td>";
                                                            if ($numbschCurri > 1) {
                                                                echo "<td>$type1</td>";
                                                            }
                                                            echo "<td>												
			                                            <form action='' method='post'>
			                                                  <input type='hidden' value=$C_codding name='id'>
			                                                  <input type='submit' name = 'view' class='btn btn-primary btn-xs' value='View'>
			                                                  
			                                             </form>
			                                        </td>";
                                                            if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES") {
                                                    ?>
                                                                <td>

                                                                    <a href="#editEmployeeModal" class="edit" data-toggle="modal">
                                                                        <i class="material-icons update" data-toggle="tooltip" data-id="<?php echo $row["id"]; ?>" data-CCode="<?php echo $C_codding; ?>" data-CTitle="<?php echo $C_title; ?>" data-unit="<?php echo $credit; ?>" data-semester="<?php echo $semester; ?>" data-Department="<?php echo $Department; ?>" data-curri="<?php echo $type1; ?>" title="Edit"></i>
                                                                    </a>

                                                                </td>
                                                                <td>

                                                                    <?php
                                                                    echo '<a href="#deleteEmployeeModal" class="delete" data-id="' . $row['id'] . '", data-ccode="' . $row['C_codding'] . '", data-ctitle="' . $row['C_title'] . '">
                                                            <b style="color:red"><i class="fa fa-trash" data-toggle="tooltip" title="Delete Record"></i></b></a>';
                                                                    ?>

                                                                </td>
                                                    <?php
                                                            }
                                                            echo "</tr>\n";
                                                        }
                                                    }
                                                    $conn->close();
                                                    ?>
                                                </tbody>
                                            </table>





                                            <br><br>
                                            <form action='' method='post'>
                                                <input type='submit' name='download' class='btn btn-primary btn-xs' value='Download'>

                                            </form>
                                        </div>


                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>


        <!--Print -->
        <div id="printablediv" style="width: 100%; height: 200px;" hidden="hidden">
            <?php
            if (isset($_SESSION['id'])) {
                $id = $_SESSION['id'];
            } else {
                $id = 0;
            }

            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            //$id = $_POST['id'];
            $corntsession = $_SESSION['corntsession'];
            $M = $T = $W = $Th = $F = $S = '';
            $ccode = $CTitle = $CUnit = '';
            $MHr =  $THr = $WHr = $ThHr = $FHr = $SHr = 0;
            $venue = $course_objective = $lecture_outcome = $lecture_delivery = $evalu_method = $week1 = $week2 = $week3 = $week4 = $week5 = $week6 = $week7 = $week8 = $week9 = $week10 = $week11 = $week12 = $week13 = $week14 = $week15 = "";
            $refmaterial1 = $refmaterial2 = $refmaterial3 = $refmaterial4 = $refmaterial5 = $refmaterial6 = $refmaterial7 = $refmaterial8 = $refmaterial9 = $refmaterial10 = "";
            $sql = "SELECT * FROM coursealocation WHERE sn = '$id'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $ccode = $row["CCode"];
                    $CTitle = $row["CTitle"];
                    $CUnit = $row["CUnit"];
                    $corntsession2 = str_replace("/", "_", $corntsession);
                    $sql2 = "SELECT * FROM courses_register_" . $corntsession2 . " WHERE CCode = '$ccode'";
                    $result2 = $conn->query($sql2);
                    $countstu = mysqli_num_rows($result2);

                    $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$ccode'";
                    $result2 = $conn->query($sql2);
                    if ($result2->num_rows > 0) {
                        while ($row2 = $result2->fetch_assoc()) {
                            $descriptn = $row2["Descriptn"];
                            $semester = $row2["semester"];
                            if ($semester == "1ST") {
                                $semester = "First Semester";
                            } else {
                                $semester = "Second Semester";
                            }
                            $M = $row2["M"];
                            $T = $row2["T"];
                            $W = $row2["W"];
                            $Th = $row2["Th"];
                            $F = $row2["F"];
                            $S = $row2["S"];

                            $MHr = $row2["MHr"];
                            $THr = $row2["THr"];
                            $WHr = $row2["WHr"];
                            $ThHr = $row2["ThHr"];
                            $FHr = $row2["FHr"];
                            $SHr = $row2["SHr"];
                            $venue = $row2["venue"];
                            $course_objective = $row2["course_objective"];
                            $lecture_outcome = $row2["lecture_outcome"];
                            $lecture_delivery = $row2["lecture_delivery"];
                            $evalu_method = $row2["evalu_method"];
                            $week1 = $row2["week1"];
                            $week2 = $row2["week2"];
                            $week3 = $row2["week3"];
                            $week4 = $row2["week4"];
                            $week5 = $row2["week5"];
                            $week6 = $row2["week6"];
                            $week7 = $row2["week7"];
                            $week8 = $row2["week8"];
                            $week9 = $row2["week9"];
                            $week10 = $row2["week10"];
                            $week11 = $row2["week11"];
                            $week12 = $row2["week12"];
                            $week13 = $row2["week13"];
                            $week14 = $row2["week14"];
                            $week15 = $row2["week15"];
                            $refmaterial1 = $row2["refmaterial1"];
                            $refmaterial2 = $row2["refmaterial2"];
                            $refmaterial3 = $row2["refmaterial3"];
                            $refmaterial4 = $row2["refmaterial4"];
                            $refmaterial5 = $row2["refmaterial5"];
                            $refmaterial6 = $row2["refmaterial6"];
                            $refmaterial7 = $row2["refmaterial7"];
                            $refmaterial8 = $row2["refmaterial8"];
                            $refmaterial9 = $row2["refmaterial9"];
                            $refmaterial10 = $row2["refmaterial10"];
                        }
                    }
                }
            }


            $contday = "";
            if (strlen($M) > 0) {
                $Hr = $MHr;
                $Tm = $M;
                include 'includes/lecture_period.php';
                $contday = $contday . "Monday " . $M . " To " . $NTm . " <br>";
                //$conthour =$conthour.$M.", ";
            }
            if (strlen($T) > 0) {
                //$contday=$contday."Tuesday, ";
                //$conthour =$conthour.$T.", ";
                $Hr = $THr;
                $Tm = $T;
                include 'includes/lecture_period.php';
                $contday = $contday . "Tuesday " . $T . " To " . $NTm . " <br>";
            }
            if (strlen($W) > 0) {
                //$contday=$contday."Wednesday, ";
                //$conthour =$conthour.$W.", ";
                $Hr = $WHr;
                $Tm = $W;
                include 'includes/lecture_period.php';
                $contday = $contday . "Wednesday " . $W . " To " . $NTm . " <br>";
            }
            if (strlen($Th) > 0) {
                //$contday=$contday."Thursday, ";
                //$conthour =$conthour.$Th.", ";
                $Hr = $ThHr;
                $Tm = $Th;
                include 'includes/lecture_period.php';
                $contday = $contday . "Thursday " . $Th . " To " . $NTm . " <br>";
            }
            if (strlen($F) > 0) {
                //$contday=$contday."Friday, ";
                //$conthour =$conthour.$F.", ";
                $Hr = $FHr;
                $Tm = $F;
                include 'includes/lecture_period.php';
                $contday = $contday . "Friday " . $F . " To " . $NTm . " <br>";
            }
            if (strlen($S) > 0) {
                //$contday=$contday."Saturday, ";
                //$conthour =$conthour.$S.", ";
                $Hr = $SHr;
                $Tm = $S;
                include 'includes/lecture_period.php';
                $contday = $contday . "Saturday " . $S . " To " . $NTm . " <br>";
            }





            ?>
            <center><strong><u>COURSEWARE OUTLINE</u></strong></center>
            <table style="width:100%" class="table mb-none">
                <tbody>
                    <tr>
                        <th style="width:20%; padding-bottom:0.5em; text-align:left">Session:</th>
                        <td style="padding:0.25em"><?php echo $corntsession ?></td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; text-align:left">Semester:</th>
                        <td style="padding:0.25em"><?php echo $semester ?></td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; vertical-align:top; text-align:left">Course Title/Code:</th>
                        <td style="padding:0.25em; text-align:justify"><?php echo $CTitle . "(" . $ccode . ")" ?></td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; text-align:left">Credit Unit:</th>
                        <td style="padding:0.25em"><?php echo $CUnit ?></td>
                    </tr>
                </tbody>
            </table>
            <br>
            <strong>Names, Offices and Contact Details of Course Lecturers:</strong>
            <ul>
                <?php
                $sql = "Select * from coursealocation WHERE CCode = '$ccode' AND SessionReg = '$corntsession'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $fileno = $row["PFNo"];

                        $sql2 = "Select * from users WHERE staffid = '$fileno'";
                        $result2 = $conn->query($sql2);
                        if ($result2->num_rows > 0) {
                            while ($row2 = $result2->fetch_assoc()) {
                                $staname = $row2["full_name"];
                                $phone = $row2["phone"];
                                $email = $row2["emailAdd"];
                                $staffdept = strtoupper($row2["staffacddept"]);
                                $officeadd = $row2["office_address"];
                            }
                        }
                        $sql2 = "Select * from deptcoding WHERE DeptCode = '$staffdept'";
                        $result2 = $conn->query($sql2);
                        if ($result2->num_rows > 0) {
                            while ($row2 = $result2->fetch_assoc()) {
                                $staffdept2 = $row2["DeptName"];
                            }
                        }

                        echo "<li type='disc'><b>$staname</b> <br> Department of $staffdept2 <br> Contact No/email: $phone;  $email <br> Office: $officeadd</li><br>";
                    }
                }
                ?>

            </ul>

            <h4><strong><u>OUTLINE</u></strong></h4>
            <p style="text-align:justify"><b>Objectives of the Course:</b> <?php echo $course_objective ?></p>
            <p style="text-align:justify"><b>Outcome:</b> <?php echo $lecture_outcome ?></p>
            <p style="text-align:justify"><b>Lecture Delivery:</b> <?php echo $lecture_delivery ?></p>
            <p style="text-align:justify"><b>Evaluation Methods:</b> <?php echo $evalu_method ?></p>
            <table style="width:100%" class="table mb-none">
                <tbody>
                    <tr>
                        <th style="width:20%; padding-bottom:0.5em; vertical-align:top; text-align:left">Lecture Period:
                        </th>
                        <td><?php echo $contday ?></td>
                    </tr>
                    <tr>
                        <th style="padding-bottom:0.5em; vertical-align:top; text-align:left">Lecture Venue:</th>
                        <td><?php echo $venue ?></td>
                    </tr>
                </tbody>
            </table>
            <h4><strong><u>SCHEME OF WORK</u></strong></h4>
            <table style="width:100%;" class="table mb-none">
                <thead>
                    <tr>
                        <th style="border: 0.5px solid black">Week</th>
                        <th style="border: 0.5px solid black">Topics</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="width:10%; text-align:center;border: 0.5px solid black">1</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week1 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center;border: 0.5px solid black">2</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week2 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">3</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week3 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">4</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week4 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">5</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week5 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">6</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week6 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">7</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week7 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">8</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week8 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">9</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week9 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">10</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week10 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">11</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week11 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">12</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week12 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">13</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week13 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">14</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week14 ?></td>
                    </tr>
                    <tr>
                        <td style="text-align:center; padding:0.25em;border: 0.5px solid black">15</td>
                        <td style="text-align:justify;border: 0.5px solid black"><?php echo $week15 ?></td>
                    </tr>
                </tbody>
            </table>
            <h4><strong><u>RELEVANT REFERENCES</u></strong></h4>
            <ul>

                <?php
                if ($refmaterial1 <> "") {
                    echo "<li type='disc'>$refmaterial1</li><br>";
                }
                if ($refmaterial2 <> "") {
                    echo "<li type='disc'>$refmaterial2</li><br>";
                }
                if ($refmaterial3 <> "") {
                    echo "<li type='disc'>$refmaterial3</li><br>";
                }
                if ($refmaterial4 <> "") {
                    echo "<li type='disc'>$refmaterial4</li><br>";
                }
                if ($refmaterial5 <> "") {
                    echo "<li type='disc'>$refmaterial5</li><br>";
                }
                if ($refmaterial6 <> "") {
                    echo "<li type='disc'>$refmaterial6</li><br>";
                }
                if ($refmaterial7 <> "") {
                    echo "<li type='disc'>$refmaterial7</li><br>";
                }
                if ($refmaterial8 <> "") {
                    echo "<li type='disc'>$refmaterial8</li><br>";
                }
                if ($refmaterial9 <> "") {
                    echo "<li type='disc'>$refmaterial9</li><br>";
                }
                if ($refmaterial10 <> "") {
                    echo "<li type='disc'>$refmaterial10</li><br>";
                }
                ?>
            </ul>

        </div>


        <!-- Add Modal HTML -->
        <div id="addEmployeeModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form id="user_form" action="" method="post">
                        <div class="modal-header">
                            <h4 class="modal-title">Add New</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Course Code</label>
                                <input type="text" name="CCode" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Course Title</label>
                                <input type="text" name="CTitle" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Credit Unit</label>
                                <select class="form-control" style="color:#000000" name="CUnit" required="required">
                                    <option value="0">0</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Semester</label>
                                <select class="form-control" style="color:#000000" name="Semester" required="required">
                                    <option value="1ST">1ST</option>
                                    <option value="2ND">2ND</option>

                                </select>
                            </div>
                            <div class="form-group">
                                <label>Service Department</label>
                                <select class="form-control" style="color:#000000" name="Dept" required="required">
                                    <option value="">Select Item</option>
                                    <?php

                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $DeptCode = $row["DeptCode"];
                                            $DeptName = $row["DeptName"];
                                            echo "<option value=$DeptCode>$DeptName</option>";
                                        }
                                    }
                                    ?>

                                </select>
                            </div>
                            <?php if ($numbschCurri > 1) { ?>
                                <div class="form-group">
                                    <label>Curriculum:</label>
                                    <select class="form-control" style="color:#000000" name="curri" required="required">
                                        <option value="">Select Item</option>
                                        <?php

                                        $sql2 = "SELECT * FROM sch_curriculum";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $curri_Code = $row2["curri_Code"];
                                                $curri_Title = $row2["curri_Title"];
                                                echo "<option value=$curri_Code>$curri_Title</option>";
                                            }
                                        }
                                        ?>

                                    </select>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="modal-footer">
                            <input type="hidden" value="1" name="type">
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                            <button type="submit" name="submitAddNew" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Edit Modal HTML -->
        <div id="editEmployeeModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form id="update_form" action="" method="post">
                        <div class="modal-header">
                            <h4 class="modal-title">Edit Record</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                        </div>

                        <div class="modal-body">
                            <input type="hidden" id="id_u" name="id" class="form-control">
                            <div class="form-group">
                                <label>Course Code</label>
                                <input type="text" id="CCode_u" name="CCode" class="form-control" readonly>
                            </div>
                            <div class="form-group">
                                <label>Course Title</label>
                                <input type="text" id="CTitle_u" name="CTitle" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label>Credit Unit</label>
                                <select class="form-control" style="color:#000000" id="unit_u" name="CUnit" required="required">
                                    <option value="0">0</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Semester</label>
                                <select class="form-control" style="color:#000000" id="semester_u" name="Semester" required="required">
                                    <option value="1ST">1ST</option>
                                    <option value="2ND">2ND</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Service Department</label>
                                <select class="form-control" style="color:#000000" id="Department_u" name="Dept" required="required">
                                    <?php

                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $DeptCode = $row["DeptCode"];
                                            $DeptName = $row["DeptName"];
                                            echo "<option value='$DeptCode'>$DeptName</option>";
                                        }
                                    }
                                    ?>

                                </select>
                            </div>
                            <?php if ($numbschCurri > 1) { ?>
                                <div class="form-group">
                                    <label>Curriculum:</label>
                                    <select class="form-control" style="color:#000000" id="curri_u" name="curri" required="required">
                                        <option value="">Select Item</option>
                                        <?php

                                        $sql2 = "SELECT * FROM sch_curriculum";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $curri_Code = $row2["curri_Code"];
                                                $curri_Title = $row2["curri_Title"];
                                                echo "<option value=$curri_Code>$curri_Title</option>";
                                            }
                                        }
                                        ?>

                                    </select>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="modal-footer">
                            <input type="hidden" value="2" name="type">
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                            <button type="submit" name="update" class="btn btn-primary">Update</button>
                            <!--<button type="button" class="btn btn-info" id="update">Update</button>-->
                        </div>
                    </form>
                </div>
            </div>
            <?php
            $conn->close();
            ?>
        </div>
        <!-- Delete Modal HTML -->

        <!-- Delete Modal HTML -->
        <div id="deleteEmployeeModal" class="modal inmodal" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form enctype="multipart/form-data" action="" method="POST" class="form-horizontal">
                        <div class="modal-header">
                            <h4 class="modal-title">Confirm Deleting Record of</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" id="id">
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Course Code: </label>
                                <div class="col-lg-7">
                                    <input type="text" class="form-control" style="color:#000000" name="ccode" id="ccode" readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Course Title: </label>
                                <div class="col-lg-7">
                                    <input type="text" class="form-control" style="color:#000000" name="ctitle" id="ctitle" readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <p>Are you sure you want to delete these Records?</p>
                                <p class="text-warning"><small>This action cannot be undone.</small></p>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                            <input type="submit" class="btn btn-success" name="delete" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>



        </section>

        <?php
        include_once 'includes/footer.php';
        ?>

        <script src="js/plugins/dataTables/datatables.min.js"></script>



        <script>
            $(document).on('click', '.update', function(e) {


                var id = $(this).attr("data-id");
                var CCode = $(this).attr("data-CCode");
                var CTitle = $(this).attr("data-CTitle");
                var unit = $(this).attr("data-unit");
                var semester = $(this).attr("data-semester");
                var Department = $(this).attr("data-Department");
                var curri = $(this).attr("data-curri");
                $('#id_u').val(id);
                $('#CCode_u').val(CCode);
                $('#CTitle_u').val(CTitle);
                $('#unit_u').val(unit);
                $('#semester_u').val(semester);
                $('#Department_u').val(Department);
                $('#curri_u').val(curri);


            });
        </script>

        <script>
            $(function() {
                $('a.delete').click(function(e) {
                    e.preventDefault();
                    var link = this;
                    var deleteModal = $("#deleteEmployeeModal");
                    // store the ID inside the modal's form
                    deleteModal.find('input[name=id]').val(link.dataset.id);
                    deleteModal.find('input[name=ctitle]').val(link.dataset.ctitle);
                    deleteModal.find('input[name=ccode]').val(link.dataset.ccode);
                    // open modal
                    deleteModal.modal();
                });
            });
        </script>

        <!-- Page-Level Scripts -->
        <script>
            $(document).ready(function() {
                $('.dataTables-example').DataTable({
                    pageLength: 25,
                    responsive: true,
                    dom: '<"html5buttons"B>lTfgitp',
                    buttons: [{
                            extend: 'copy'
                        },
                        {
                            extend: 'csv'
                        },
                        {
                            extend: 'excel',
                            title: 'ExampleFile'
                        },
                        {
                            extend: 'pdf',
                            title: 'ExampleFile'
                        },

                        {
                            extend: 'print',
                            customize: function(win) {
                                $(win.document.body).addClass('white-bg');
                                $(win.document.body).css('font-size', '10px');

                                $(win.document.body).find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');
                            }
                        }
                    ]

                });

            });
        </script>
</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$usernames = $_SESSION['names'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$staffid = $_SESSION['staffid'];
$dept = strtoupper($_SESSION['deptcode']);

?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">
    <!-- Textarea Editor -->
    <link href="editor/css_/bootstrap3-wysihtml5.min.css" rel="stylesheet" media="screen" />
    <!--Download to excel-->
    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <?php
                $imgpf = str_replace('.', '_', $_SESSION['staffid']);

                ?>

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php

                            echo "<img src='https://staff.futminna.edu.ng/" . strtoupper($_SESSION['deptcode']) . "/images/" . strtoupper($imgpf) . "/MyPic1.jpg' alt='$usernames' class='img-circle' width='50' height='50' />";
                            ?>
                        </figure>
                        <div class="profile-info">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $staffid ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="staff_profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_staff.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="lock_screen.php"><i class="fa fa-lock"></i> Lock
                                    Screen</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout_staff.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>




                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <?php
        $ful_assign = "";
        $sessionreplace = str_replace("/", "_", $curtsession);

        if (isset($_POST["assignment"])) {
            $getccode = $_POST["all_course"];
            $_SESSION["ccode_assig"] = $getccode;
        } else {
            $getccode = $_SESSION["ccode_assig"];
        }

        if (isset($_POST["get_assignment"]) || isset($_POST["sub_sel_assign"]) || isset($_POST["view"]) || isset($_POST["submit_score"])) {
            if (isset($_POST["get_assignment"])) {
                $assign_no = $_POST["assign_id"];
                $_SESSION["get_assign_id"] = $assign_no;
            } else {
                $assign_no = $_SESSION["get_assign_id"];
            }
            if ($assign_no == 1) {
                $ful_assign = "First Assignment";
            } elseif ($assign_no == 2) {
                $ful_assign = "Second Assignment";
            } else {
                $ful_assign = "Third Assignment";
            }
        }

        if (isset($_POST["submit_score"])) {
            $id = $_POST["id"];
            $getscore = $_POST["getscore"];
            $sql = "UPDATE aaa_sub_assignment_" . $sessionreplace . " SET scores='$getscore', marked='Marked'  WHERE id = '$id'";
            $result = $conn8->query($sql);
        }
        ?>
        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_staff_class.php'; ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>">
                    <h2>Assignment</h2>

                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">

                            <li>
                                <a href="classroom_start.php" class='btn btn-primary btn-xs'></i> Classroom</a>

                            </li>

                        </ol>

                        <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">
                            <?php if (isset($_POST["get_assignment"]) || isset($_POST["sub_sel_assign"]) || isset($_POST["view"]) || isset($_POST["submit_score"])) { ?>
                                <div class="form-group" style="padding-left: 1em; padding-right: 1em">
                                    <form action="" method="post">
                                        <button type="submit" name="download_ass_score" class="btn btn-block btn-primary"><i class="fa fa-download mr-xs"></i><?php echo $ful_assign ?></button>

                                    </form>
                                </div>
                            <?php } ?>
                            <div class="nano">
                                <div class="nano-content">
                                    <div class="inner-menu-content">
                                        <div class="sidebar-widget m-none">
                                            <div class="widget-content">
                                                <ul class="mg-folders">

                                                    <?php
                                                    $sno = 0;
                                                    if (isset($_POST["get_assignment"]) || isset($_POST["sub_sel_assign"]) || isset($_POST["view"]) || isset($_POST["submit_score"])) {

                                                        $sessionreplace = str_replace("/", "_", $curtsession);
                                                        $sql = "SELECT * FROM aaa_sub_assignment_" . $sessionreplace . " WHERE ccode = '$getccode' AND assign_no = '$assign_no'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $id = $row["id"];
                                                                $stureg = $row["stureg"];
                                                                $assn_name1 = $row["name1"];
                                                                $scores = $row["scores"];
                                                                $marked = $row["marked"];

                                                    ?>
                                                                <li>
                                                                    <form class="form-inline" method='post'>

                                                                        <label style="font-size: 14px"><strong><?php echo $sno ?></strong></label>

                                                                        <div class="form-group">
                                                                            <span class="name" style="color: #ffffff"><?php echo $assn_name1 . "(" . $stureg . ")" ?></span><br>
                                                                            <span class="name" style="color: #ffffff">Status:
                                                                                <?php echo $marked ?>; Scores:
                                                                                <?php echo $scores ?></span>
                                                                        </div>

                                                                        <div class="item-options">
                                                                            <input type='hidden' value=<?php echo $id ?> name='id'>
                                                                            <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>

                                                                        </div>
                                                                    </form>
                                                                </li>
                                                                <br>
                                                    <?php
                                                            }
                                                        }
                                                    }
                                                    ?>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">

                            <div class="inner-toolbar clearfix" style="color:#ffffff">
                                <ul>

                                    <li>
                                        <?php
                                        if (isset($_POST["assignment"])) {
                                            $getccode = $_POST["all_course"];
                                            $sql = "SELECT C_codding, C_title, credit FROM gencoursesupload WHERE C_codding = '$getccode'";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $_SESSION["course_title_assignment"] = $row["C_title"];
                                                }
                                            }
                                        }
                                        ?>
                                        <h4><b><?php echo $_SESSION["course_title_assignment"] ?></b></h4>
                                    </li>
                                    <li class="right">

                                        <ul class="nav nav-pills nav-pills-primary">

                                            <li>
                                                <form class="form-horizontal form-bordered" method="post">

                                                </form>
                                            </li>

                                        </ul>
                                    </li>
                                </ul>
                            </div>

                            <div class="row">

                                <form action="" method="post">
                                    <div class="form-group">
                                        <label class="control-label col-lg-2" style="font-size: 16px">Select
                                            Course:</label>
                                        <div class="col-lg-5">
                                            <select class="country form-control" style="color:#000000" name="all_course">
                                                <?php
                                                $sql = "SELECT * FROM coursealocation WHERE PFNo='$staffid' AND SessionReg='$curtsession' AND Semester='$cursemester' ORDER BY CCode";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $CCode = $row["CCode"];
                                                        $CTitle = $row["CTitle"];
                                                        echo "<option value=$CCode>$CCode $CTitle</option>";
                                                    }
                                                }
                                                ?>

                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <button type="submit" name="assignment" class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                            <br><br>
                            <?php if (isset($_POST["assignment"]) || isset($_POST["submit_assign"]) || isset($_POST["upfile_assign"]) || isset($_POST["get_assignment"]) || isset($_POST["sub_sel_assign"]) || isset($_POST["view"]) || isset($_POST["submit_score"]) || isset($_POST["download_ass_score"])) { ?>
                                <?php
                                //$first_ass=$second_ass=$third_ass="";

                                if (isset($_POST["assignment"]) || isset($_POST["get_assignment"]) || isset($_POST["sub_sel_assign"]) || isset($_POST["view"]) || isset($_POST["submit_score"])) {
                                    $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getccode' AND session1 = '$curtsession' ORDER BY assignment_no";
                                    $result = $conn8->query($sql);
                                    if ($result->num_rows > 0) {
                                ?>
                                        <div class="row">
                                            <section class="panel">
                                                <header class="panel-heading">

                                                    <h2 class="panel-title">Assignment List</h2>
                                                </header>
                                                <div class="panel-body">

                                                    <table class="table table-bordered table-striped mb-none" id="datatable-default">
                                                        <thead style='text-align:center'>
                                                            <tr>
                                                                <th>S/No</th>
                                                                <th>Number</th>
                                                                <th>Message</th>
                                                                <th>Attachement</th>
                                                                <th>Deadline</th>
                                                                <th>Total Mark(%)</th>
                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $sno = 0;
                                                            $assign_cat = "";
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $assign_id = $row["id"];
                                                                if ($row["deadline"] < date("Y-m-d")) {
                                                                    $sql2 = "UPDATE aaa_assignment SET status = 'close' WHERE id='$assign_id'";
                                                                    $result2 = $conn8->query($sql2);
                                                                }
                                                                $assignment_no = $row["assignment_no"];
                                                                if ($assignment_no == 1) {
                                                                    $assign_cat = "First Assignment";
                                                                } elseif ($assignment_no == 2) {
                                                                    $assign_cat = "Second Assignment";
                                                                } else {
                                                                    $assign_cat = "Third Assignment";
                                                                }
                                                                $message = $row["message"];
                                                                $tot_mark = $row["tot_mark"];
                                                                $file_url = $row["file_url"];
                                                                $filename = $row["filename"];
                                                                $deadline = date('d F, Y', strtotime($row["deadline"]));

                                                                echo "<tr><td>$sno</td><th>$assign_cat</th><th>$message</th><td>";
                                                                if (strlen($file_url) > 1) {
                                                            ?>
                                                                    <a href="<?php echo $file_url ?>" target="_blank"><img src="assets/images/pdf_icon.png" width="40" height="40"><?php echo $filename ?></a>
                                                            <?php
                                                                }
                                                                echo "</td><td>$deadline</td><td>$tot_mark</td>
													    	<form action='' method='post'>
				                                                <input type='hidden' value=$assignment_no name='assign_id'>
				                                                <td><input type='submit' name = 'get_assignment' class='btn btn-primary btn-xs' value='Mark Assignment'></td>
				                                             </form>
													    	</tr>";
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </section>
                                        </div>
                                    <?php } ?>
                                <?php } ?>
                                <div class="col-lg-12">
                                    <?php
                                    $message = $msgsuces = $savemsg = "";
                                    $getccode = $_SESSION["ccode_assig"];
                                    $staffid = $_SESSION['staffid'];
                                    $curtsession = $_SESSION['corntsession'];
                                    $usernames = $_SESSION['names'];

                                    $fassign_close = $sassign_close = $tassign_close = "";
                                    $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getccode' AND session1 = '$curtsession' AND assignment_no = '1'";
                                    $result = $conn8->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            if ($row["status"] == "open") {
                                                $ssign_type = "First Assignment";
                                                $_SESSION["assignment_no"] = 1;
                                            } else {
                                                $fassign_close = "close";
                                            }
                                        }
                                    } else {
                                        $ssign_type = "First Assignment";
                                        $_SESSION["assignment_no"] = 1;
                                    }

                                    if ($fassign_close == "close") {
                                        $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getccode' AND session1 = '$curtsession' AND assignment_no = '2'";
                                        $result = $conn8->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                if ($row["status"] == "open") {
                                                    $ssign_type = "Second Assignment";
                                                    $_SESSION["assignment_no"] = 2;
                                                } else {
                                                    $sassign_close = "close";
                                                }
                                            }
                                        } else {
                                            $ssign_type = "Second Assignment";
                                            $_SESSION["assignment_no"] = 2;
                                        }
                                    }

                                    if ($sassign_close == "close") {
                                        $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getccode' AND session1 = '$curtsession' AND assignment_no = '3'";
                                        $result = $conn8->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                if ($row["status"] == "open") {
                                                    $ssign_type = "Third Assignment";
                                                    $_SESSION["assignment_no"] = 3;
                                                } else {
                                                    $tassign_close = "close";
                                                }
                                            }
                                        } else {
                                            $ssign_type = "Third Assignment";
                                            $_SESSION["assignment_no"] = 3;
                                        }
                                    }


                                    if (isset($_POST["submit_assign"])) {
                                        $assign_no = $_SESSION["assignment_no"];

                                        $_SESSION["get_assign_id"] = $assign_no;
                                        //$assign_msg = str_replace("'", "''", $_POST['myassign']);
                                        //$assign_msg = filter_var($assign_msg, FILTER_SANITIZE_STRING);
                                        $assign_msg =  $_POST['myassign'];
                                        $deadline = $_POST['deadline'];
                                        $tot_mark = $_POST["tot_mark"];
                                        $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getccode' AND session1 = '$curtsession' AND assignment_no = '$assign_no'";
                                        $result = $conn8->query($sql);
                                        if ($result->num_rows > 0) {
                                            $sql = "UPDATE aaa_assignment SET message='$assign_msg', deadline='$deadline', tot_mark='$tot_mark', status='open' WHERE ccode = '$getccode' AND session1 = '$curtsession' AND assignment_no = '$assign_no'";
                                            $result = $conn8->query($sql);
                                        } else {
                                            $sql = "INSERT INTO aaa_assignment (ccode, session1, assignment_no, message, deadline, status, tot_mark) VALUES ('$getccode', '$curtsession', '$assign_no', '$assign_msg', '$deadline', 'open', '$tot_mark')";
                                            $result = $conn8->query($sql);
                                        }


                                        $savemsg = "Record Inserted";
                                    }

                                    $sessionreplace = str_replace("/", "_", $curtsession);

                                    if (isset($_POST['upfile_assign']) && !empty($_POST['upfile_assign'])) {
                                        $fileTmpPath = $_FILES['file_assign']['tmp_name'];
                                        $fileName = $_FILES['file_assign']['name'];
                                        $fileSize = $_FILES['file_assign']['size'];
                                        $fileType = $_FILES['file_assign']['type'];
                                        $fileNameCmps = explode(".", $fileName);
                                        $fileExtension = strtolower(end($fileNameCmps));


                                        $fileName = str_replace("'", "''", $fileName);
                                        $fileName = filter_var($fileName, FILTER_SANITIZE_STRING);
                                        $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                                        $newFileName = $fileName;

                                        $allowedfileExtensions = array('pdf');
                                        if (in_array($fileExtension, $allowedfileExtensions)) {
                                            // directory in which the uploaded file will be moved
                                            if ($_FILES['file_assign']['size'] / 1024 <= 5120) { // 5MB
                                                $assign_no = $_SESSION["assignment_no"];

                                                $uploadFileDir = "classroom/assignment/" . $sessionreplace . "/" . $getccode . "/";

                                                if (!file_exists($uploadFileDir)) {
                                                    mkdir($uploadFileDir, 0777, true);
                                                }


                                                $dest_path = $uploadFileDir . $assign_no . "." . $fileExtension;

                                                if (move_uploaded_file($fileTmpPath, $dest_path)) {
                                                    $sql = "UPDATE aaa_assignment set file_url = '$dest_path', filename = '$newFileName' WHERE ccode = '$getccode' AND session1 = '$curtsession' AND assignment_no='$assign_no'";
                                                    $result = $conn8->query($sql);
                                                    $msgsuces = 'File is successfully uploaded.';
                                                } else {
                                                    $message = 'Error in moving the file. Make sure you select correct file type.';
                                                }
                                            } else {
                                                $message = 'Error: File should be maximun 5MB in size!';
                                            }
                                        } else {
                                            $message = 'Error: Select pdf file';
                                        }
                                    }

                                    ?>


                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>

                                            <h2 class="panel-title">Assignment for <?php echo $getccode ?></h2>
                                        </header>

                                        <div class="panel-body">
                                            <?php if (isset($_POST["get_assignment"]) || isset($_POST["sub_sel_assign"]) || isset($_POST["view"]) || isset($_POST["submit_score"]) || isset($_POST["download_ass_score"]) || isset($_POST["submit_assign"])) { ?>
                                                <?php
                                                if (isset($_POST["get_assignment"])) {
                                                    $assign_no = $_POST["assign_id"];
                                                    $_SESSION["get_assign_id"] = $assign_no;
                                                } else {
                                                    $assign_no = $_SESSION["get_assign_id"];
                                                }

                                                if ($assign_no == 1) {
                                                    $ful_assign = "First Assignment";
                                                } elseif ($assign_no == 2) {
                                                    $ful_assign = "Second Assignment";
                                                } else {
                                                    $ful_assign = "Third Assignment";
                                                }
                                                ?>


                                                <?php

                                                ?>
                                                <br><br>
                                                <div class="row">

                                                    <?php if (isset($_POST["view"])) { ?>
                                                        <?php
                                                        $id = $_POST["id"];
                                                        $sql = "SELECT * FROM aaa_sub_assignment_" . $sessionreplace . " WHERE id = '$id'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $stureg = $row["stureg"];
                                                                $assn_name1 = $row["name1"];
                                                                $scores = $row["scores"];
                                                                $ass_file_url = $row["file_url"];
                                                            }
                                                        }
                                                        ?>
                                                        <center>
                                                            <h4><?php echo $stureg ?></h4>
                                                        </center>
                                                        <center>
                                                            <h4><?php echo $assn_name1 ?></h4>
                                                        </center>
                                                        <iframe src="<?php echo $ass_file_url ?>" width="100%" height="500px"></iframe>
                                                        <br><br>
                                                        <form class="form-horizontal form-bordered" method="post">
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Scores:</label>
                                                                <div class="col-md-3">
                                                                    <input type="hidden" name="id" value="<?php echo $id ?>">
                                                                    <input type="number" name="getscore" class="form-control input-rounded" required="required">
                                                                </div>
                                                                <div class="col-lg-3">
                                                                    <input type="submit" name="submit_score" value="Submit" class="btn btn-primary btn-sm">
                                                                </div>
                                                            </div>
                                                        </form>
                                                    <?php } ?>

                                                </div>

                                                <br><br>
                                                <div class="row">

                                                    <?php if (isset($_POST["download_ass_score"])) { ?>
                                                        <?php
                                                        $GetTitle = $getccode . " " . $ful_assign;
                                                        $sno = 0;
                                                        ?>
                                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups" frame="hsides" border="2">
                                                            <caption><?php echo $GetTitle ?></caption>
                                                            <colgroup align="center"></colgroup>
                                                            <colgroup align="left"></colgroup>
                                                            <colgroup span="2"></colgroup>
                                                            <colgroup span="3" align="center"></colgroup>
                                                            <thead>
                                                                <tr>
                                                                    <th>SNo</th>
                                                                    <th>Matric No</th>
                                                                    <th>Name</th>
                                                                    <th>Scores</th>
                                                                    <th>Status</th>

                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                $sql = "SELECT * FROM aaa_sub_assignment_" . $sessionreplace . " WHERE ccode = '$getccode' AND assign_no = '$assign_no'";
                                                                $result = $conn8->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $sno++;
                                                                        $stureg = $row['stureg'];
                                                                        $name1 = $row['name1'];
                                                                        $scores = $row['scores'];
                                                                        $marked = $row['marked'];

                                                                        echo "<tr><td>$sno</td><td>$stureg</td><td>$name1</td><td>$scores</td><td>$marked</td></tr>\n";
                                                                    }
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                        <br>
                                                        <div style="text-align: right">
                                                            <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                                        </div>

                                                    <?php } ?>

                                                </div>
                                            <?php } ?>


                                            <?php if (isset($_POST["assignment"]) || isset($_POST["submit_assign"])) { ?>
                                                <?php if ($tassign_close == "close") { ?>
                                                    <center>
                                                        <h3>Sorry all assignment has been taken</h3>
                                                    </center>
                                                <?php } else { ?>
                                                    <div class="col-lg-12">
                                                        <h3 style="color:#0000ff"><?php echo $savemsg ?></h3>
                                                        <br>
                                                        <center>
                                                            <h3><?php echo $ssign_type ?></h3>
                                                        </center>

                                                        <form method="POST" class="form-horizontal" action="#">
                                                            <div class="form-group skin-josh">
                                                                <label class="col-md-3 control-label">Assignment Question</label>
                                                                <div class="col-md-9">
                                                                    <textarea name="myassign" id="tinymce_basic"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Total Mark(%):</label>
                                                                <div class="col-md-5">
                                                                    <div class="input-group">
                                                                        <input type="number" style="color:#000000" class="form-control" name="tot_mark" required="required">
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Deadline:</label>
                                                                <div class="col-md-5">
                                                                    <div class="input-group">
                                                                        <input type="date" style="color:#000000" class="form-control" name="deadline" value="" required="required">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4" style="text-align: right">
                                                                    <button type="submit" name="submit_assign" class="btn btn-primary btn-sm">Submit</button>

                                                                </div>
                                                            </div>
                                                        </form>
                                                        <br><br>

                                                    </div>
                                                    <br>
                                                <?php } ?>
                                                <?php if (isset($_POST["submit_assign"])) { ?>
                                                    <p style="color: #000000">
                                                        <?php
                                                        $sql = "SELECT * FROM aaa_assignment WHERE ccode = '$getccode' AND session1 = '$curtsession' AND assignment_no = '$assign_no'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                echo $row["message"];
                                                            }
                                                        }
                                                        ?>
                                                    </p>
                                                <?php } ?>
                                            <?php } ?>

                                            <?php if (isset($_POST["submit_assign"])) { ?>
                                                <br><br>
                                                <center>
                                                    <h4 style="color: #0033cc"><?php echo $savemsg ?></h4>
                                                </center>

                                                <center>
                                                    <h4>You can also attach a pdf file here</h4>
                                                </center>
                                                <br><br>
                                                <form enctype="multipart/form-data" action="" method="post">
                                                    <div class="form-group">
                                                        <label class="col-md-2 control-label">File Upload</label>
                                                        <div class="col-md-4">
                                                            <div class="fileupload fileupload-new" data-provides="fileupload">
                                                                <div class="input-append">
                                                                    <div class="uneditable-input">
                                                                        <i class="fa fa-file fileupload-exists"></i>
                                                                        <span class="fileupload-preview"></span>
                                                                    </div>
                                                                    <span class="btn btn-default btn-file">
                                                                        <span class="fileupload-exists">Change</span>
                                                                        <span class="fileupload-new">Select file</span>
                                                                        <input type="file" name="file_assign" />
                                                                    </span>
                                                                    <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-2">
                                                            <input type="submit" name="upfile_assign" value="Upload File" class="btn btn-primary btn-sm">
                                                        </div>
                                                    </div>
                                                </form>
                                            <?php } ?>
                                            <?php if (isset($_POST['upfile_assign'])) { ?>
                                                <center>
                                                    <h3 style="color:#0000ff"><?php echo $msgsuces ?></h3>
                                                </center>
                                                <center>
                                                    <h5 style="color:#ff0000"><?php echo $message ?></h5>
                                                </center>
                                            <?PHP } ?>

                                        </div>
                                    </section>
                                </div>
                            <?php } ?>
                        </div>

                    </div>

                </section>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>

    <!--Textarea Editor-->
    <script src="editor/js_/app.js" type="text/javascript"></script>
    <script src="editor/js_/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="editor/js_/ckeditor.js" type="text/javascript"></script>
    <script src="editor/js_/jquery.js" type="text/javascript"></script>
    <script src="editor/js_/editor1.js" type="text/javascript"></script>

</body>

</html>
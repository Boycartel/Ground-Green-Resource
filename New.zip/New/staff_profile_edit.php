<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }

    $staffid = $_SESSION['staffid'];
    $corntsession = $_SESSION['corntsession'];
    $cursemester = $_SESSION['cursemester'];
    $PSN = $staffid;
    $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $emailAdd = $row['emailAdd'];
            $phone = $row['phone'];
        }
    }

    $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$staffid'";
    $result = $conn7->query($sql);
    $i = 0;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $i++;
        }
    }

    if ($i == 0) {
        $sql = "SELECT * FROM staff_profile WHERE PSN = '$staffid'";
    } else {
        $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$staffid'";
    }

    //$sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
    $result = $conn7->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            $fname = $row['fname'];
            $surname = $row['sname'];
            $othernames = $row['oname'];
            $mytitle = $row['title'];
            $apptype = $row['Status'];
            $leaveabsent_study = $row['leaveabsent_study'];
            $postn_rank = $row['Rank1'];
            $area_special = $row['area_special'];
            $salary_grade = $row['GradeL'];
            $stepG = $row['StepG'];


            $sname = $row["sname"];
            $oname = $row["oname"];
            $title = $row["title"];
            $nationality = $row["nationality"];
            $country = $row["country"];
            $_SESSION["country"] = $country;
            $placebirth = $row["placebirth"];
            $religion = $row["religion"];
            $healthstatus = $row["healthstatus"];
            $healthtype = $row["healthtype"];
            $_SESSION["healthtype"] = $healthtype;
            $disable = $row["disable"];
            $accommodation = $row["accommodation"];
            $Rank1 = $row["Rank1"];
            $GradeL = $row["GradeL"];
            $StepG = $row["StepG"];
            $DeptCode2 = $row["DeptCode"];
            $Department = $row["Department"];
            $Sex = $row["Sex"];
            $ParmtAdress = $row["ParmtAdress"];
            $ContAdd = $row["ContAdd"];
            $stateOfOrigin = $row["stateOfOrigin"];
            $LGA = $row["LGA"];
            $_SESSION["LGA"] = $LGA;
            $DateBirth = $row["DateBirth"];
            $FApptDate = $row["FApptDate"];
            $FApptMonth = $row["FApptMonth"];
            $FApptYear = $row["FApptYear"];
            $PApptDate = $row["PApptDate"];
            $BankCode2 = $row["BankCode"];
            $Bank = $row["Bank"];
            $Branch = $row["Branch"];
            $AccNo = $row["AccNo"];
            $email = $row["email"];
            $Scale = $row["Scale"];
            $HQualificatn = $row["HQualificatn"];
            $maritalstatus = $row["maritalstatus"];
            $nochildren = $row["nochildren"];
            $phonenumber = $row["phonenumber"];
            $phonenumber2 = $row["phonenumber2"];
            $Status = $row["Status"];
            $nextname = $row["nextname"];
            $nextrelation = $row["nextrelation"];
            $nextaddress = $row["nextaddress"];
            $nextphone = $row["nextphone"];
        }
    }

    if ($apptype == "fulltime") {
        $apptype_full = "Full Time";
    } else if ($apptype == "parttime") {
        $apptype_full = "Part Time";
    } else {
        $apptype_full = "Contract";
    }


    if ($postn_rank == "Prof") {
        $postn_rank_full = "Professor";
    } elseif ($postn_rank == "assprof") {
        $postn_rank_full = "Associate Professor";
    } elseif ($postn_rank == "SL") {
        $postn_rank_full = "Senior Lecturer";
    } elseif ($postn_rank == "LI") {
        $postn_rank_full = "Lecturer I";
    } elseif ($postn_rank == "LII") {
        $postn_rank_full = "Lecturer II";
    } elseif ($postn_rank == "AL") {
        $postn_rank_full = "Assistant Lecturer";
    } else {
        $postn_rank_full = "Graduate Assistant";
    }

    if ($leaveabsent_study == "leaveabsent") {
        $leaveabsent_study_full = "Leave of Absent";
    } else if ($leaveabsent_study == "studyleave") {
        $leaveabsent_study_full = "Study Leave";
    } else {
        $leaveabsent_study_full = $leaveabsent_study;
    }


    if ($nationality == "non") {
        $natinal_full = "Non Nigerian";
    } else {
        $natinal_full = $nationality;
    }

    if ($accommodation == "campus") {
        $accommodation_full = "In Campus";
    } else {
        $accommodation_full = "Off Campus";
    }

    if ($HQualificatn == "firstdegree") {
        $HQualificatn_full = "First Degree";
    } else if ($HQualificatn == "masters") {
        $HQualificatn_full = "Masters";
    } else {
        $HQualificatn_full = "Ph.D";
    }


    ?>

    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Staff Profile</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Staff Profile</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Staff Profile
                        </div>
                        <div class="panel-body">

                            <!-- start: page -->
                            <form class="form-horizontal form-bordered" action="staff_profile.php" method="post">

                                <div class="row">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-10">
                                        <section class="panel panel-group">
                                            <header class="panel-heading bg-primary">

                                                <div class="widget-profile-info">
                                                    <div class="profile-picture">

                                                        <?php
                                                        echo "<img alt='' src='https://staff.futminna.edu.ng/" . strtoupper($_SESSION['deptcode']) . "/images/" . strtoupper($staffid) . "/MyPic1.jpg'>";

                                                        ?>
                                                    </div>
                                                    <div class="profile-info">
                                                        <h4 class="name text-semibold">
                                                            <?php echo strtoupper($mytitle) . " " . $fname . " " . $othernames . " " . $surname ?>
                                                        </h4>
                                                        <h5 class="role"><?php echo $PSN ?></h5>
                                                        <div class="profile-footer">

                                                            <a href="staff_profile.php"
                                                                class="btn btn-primary btn-xs"><span>Back to
                                                                    Profile</span></a>
                                                        </div>
                                                    </div>
                                                </div>

                                            </header>
                                            <div id="accordion">
                                                <div class="panel panel-accordion panel-accordion-first">

                                                    <div class="panel-body">

                                                        <!--  <div class="form-group">
                                                <div class="col-lg-6">
                                                    <label class="col-lg-4 control-label">First Name: </label>
                                                    <div class="col-lg-7">
                                                        <input type="text" class="form-control" style="color:#000000" name="fname" value="<?php echo $fname ?>" required="required">
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <label class="col-lg-4 control-label">Surname: </label>
                                                    <div class="col-lg-7">
                                                        <input type="text" class="form-control" style="color:#000000" name="surname" value="<?php echo $surname ?>" required="required">
                                                    </div>
                                                </div>

                                            </div> -->

                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <!-- <label class="col-lg-4 control-label">Other Names: </label>
                                                    <div class="col-lg-7">
                                                        <input type="text" class="form-control" style="color:#000000" name="othername" value="<?php echo $othernames ?>" required="required">
                                                    </div> -->
                                                                <label class="col-lg-4 control-label">Appointment Type:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <select name="apptype" class="form-control"
                                                                        style="color:#000000" id="apptype"
                                                                        required="required">
                                                                        <option value="<?php echo $apptype ?>">
                                                                            <?php echo $apptype_full ?></option>
                                                                        <option value="fulltime">Full Time</option>
                                                                        <option value="parttime">Part Time</option>
                                                                        <option value="contract">Contract</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Title: </label>
                                                                <div class="col-lg-7">
                                                                    <select name="title1" class="form-control"
                                                                        style="color:#000000" id="title1"
                                                                        required="required">
                                                                        <option value="<?php echo $mytitle ?>">
                                                                            <?php echo $mytitle ?></option>
                                                                        <option value="Prof">Prof</option>
                                                                        <option value="Dr">Dr</option>
                                                                        <option value="Mr">Mr</option>
                                                                        <option value="Mrs">Mrs</option>
                                                                        <option value="Miss">Miss</option>
                                                                    </select>
                                                                </div>
                                                            </div>


                                                        </div>

                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Phone Number 1:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="phone1"
                                                                        value="<?php echo $phone ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Phone Number 2:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="phone2"
                                                                        value="<?php echo $phonenumber2 ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>


                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Position/Rank:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <select name="postrank" class="form-control"
                                                                        style="color:#000000" id="postrank"
                                                                        required="required">
                                                                        <option value="<?php echo $postn_rank ?>">
                                                                            <?php echo $postn_rank_full ?></option>
                                                                        <option value="Prof">Professor</option>
                                                                        <option value="assprof">Associate Professor
                                                                        </option>
                                                                        <option value="SL">Senior Lecturer</option>
                                                                        <option value="LI">Lecturer I</option>
                                                                        <option value="LII">Lecturer II</option>
                                                                        <option value="AL">Assistant Lecturer</option>
                                                                        <option value="GA">Graduate Assistant</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Step: </label>
                                                                <div class="col-lg-7">
                                                                    <select name="stepG" class="form-control"
                                                                        style="color:#000000" id="stepG"
                                                                        required="required">
                                                                        <option value="<?php echo $stepG ?>">
                                                                            <?php echo $stepG ?>
                                                                        </option>
                                                                        <option value="01">01</option>
                                                                        <option value="02">02</option>
                                                                        <option value="03">03</option>
                                                                        <option value="04">04</option>
                                                                        <option value="05">05</option>
                                                                        <option value="06">06</option>
                                                                        <option value="07">07</option>
                                                                        <option value="08">08</option>
                                                                        <option value="09">09</option>
                                                                        <option value="10">10</option>
                                                                        <option value="11">11</option>
                                                                        <option value="12">12</option>
                                                                        <option value="13">13</option>
                                                                        <option value="14">14</option>
                                                                        <option value="15">15</option>
                                                                    </select>
                                                                </div>
                                                            </div>


                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Leave of Absent/
                                                                    Study Leave:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <select name="leaveabsent" class="form-control"
                                                                        style="color:#000000" id="leaveabsent"
                                                                        required="required">
                                                                        <option
                                                                            value="<?php echo $leaveabsent_study ?>">
                                                                            <?php echo $leaveabsent_study_full ?>
                                                                        </option>
                                                                        <option value="No">No</option>
                                                                        <option value="leaveabsent">Leave of Absent
                                                                        </option>
                                                                        <option value="studyleave">Study Leave</option>

                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Area of
                                                                    Specialization:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="area_special"
                                                                        value="<?php echo $area_special ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Marital Status:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <select name="marrystatus" class="form-control"
                                                                        style="color:#000000" id="marrystatus"
                                                                        required="required">
                                                                        <option value="<?php echo $maritalstatus ?>">
                                                                            <?php echo $maritalstatus ?></option>
                                                                        <option value="Married">Married</option>
                                                                        <option value="Widowed">Widowed</option>
                                                                        <option value="Separated">Separated</option>
                                                                        <option value="Divorced">Divorced</option>
                                                                        <option value="Single">Single</option>

                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Religion: </label>
                                                                <div class="col-lg-7">
                                                                    <select name="religion" class="form-control"
                                                                        style="color:#000000" id="religion"
                                                                        required="required">
                                                                        <option value="<?php echo $religion ?>">
                                                                            <?php echo $religion ?></option>
                                                                        <option value="Islam">Islam</option>
                                                                        <option value="Christianity">Christianity
                                                                        </option>
                                                                        <option value="Others">Others</option>

                                                                    </select>
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Nationality:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <select name="nationality"
                                                                        class="nation form-control"
                                                                        style="color:#000000" id="nationality"
                                                                        required="required">
                                                                        <option value=""></option>
                                                                        <option value="Nigerian">Nigerian</option>
                                                                        <option value="non">Non Nigerian</option>

                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6" id="getnation">


                                                            </div>

                                                        </div>

                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">State of Origin:
                                                                </label>
                                                                <div class="col-lg-5">
                                                                    <select name="stateOfOrigin"
                                                                        class="state1 form-control"
                                                                        style="color:#000000" id="stateOfOrigin"
                                                                        required="required">
                                                                        <option value=""></option>
                                                                        <option value='Non Nigerian'>Non Nigerian
                                                                        </option>
                                                                        <?php
                                                                        $sql = "SELECT * FROM states ORDER BY state";
                                                                        $result = $conn->query($sql);
                                                                        if ($result->num_rows > 0) {
                                                                            while ($row = $result->fetch_assoc()) {
                                                                                $statename = $row["state"];

                                                                                echo "<option value = '$statename'>$statename</option>";
                                                                            }
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                                <label class="col-lg-3 control-label"
                                                                    style="text-align: left"><?php echo $stateOfOrigin ?></label>
                                                            </div>
                                                            <div class="col-lg-6" id="getlga">

                                                            </div>

                                                        </div>
                                                        <div class="form-group">

                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Health Status:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <select name="healthstatus"
                                                                        class="health form-control"
                                                                        style="color:#000000" id="healthstatus"
                                                                        required="required">
                                                                        <option value=""></option>
                                                                        <option value="Nill">Nill</option>
                                                                        <option value="Others">Others</option>

                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6" id="gethealth">

                                                            </div>
                                                        </div>



                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Accommodation
                                                                    Status: </label>
                                                                <div class="col-lg-7">
                                                                    <select name="accommtype" class="form-control"
                                                                        style="color:#000000" id="accommtype"
                                                                        required="required">
                                                                        <option value="<?php echo $accommodation ?>">
                                                                            <?php echo $accommodation_full ?></option>
                                                                        <option value="campus">In Campus</option>
                                                                        <option value="outsidecamp">Off Campus</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">email: </label>
                                                                <div class="col-lg-7">
                                                                    <input type="email" class="form-control"
                                                                        style="color:#000000" name="email1"
                                                                        value="<?php echo $emailAdd ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Date of Birth:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <div class="input-group">
                                                                        <span class="input-group-addon">
                                                                            <i class="fa fa-calendar"></i>
                                                                        </span>
                                                                        <input type="text" data-plugin-datepicker
                                                                            class="form-control" name="datebirth"
                                                                            value="<?php echo date('d F, Y', strtotime($DateBirth)) ?>"
                                                                            required="required">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Place of Birth:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="placebirth"
                                                                        value="<?php echo $placebirth ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Permenet Home
                                                                    Address:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="permaddress"
                                                                        value="<?php echo $ParmtAdress ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Contact Address:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="contaddress"
                                                                        value="<?php echo $ContAdd ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Date of First
                                                                    Appointment:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <div class="input-group">
                                                                        <span class="input-group-addon">
                                                                            <i class="fa fa-calendar"></i>
                                                                        </span>
                                                                        <input type="text" data-plugin-datepicker
                                                                            class="form-control" name="datefirstapp"
                                                                            value="<?php echo date('d F, Y', strtotime($FApptDate)) ?>"
                                                                            required="required">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Date of Present
                                                                    Appointment:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <div class="input-group">
                                                                        <span class="input-group-addon">
                                                                            <i class="fa fa-calendar"></i>
                                                                        </span>
                                                                        <input type="text" data-plugin-datepicker
                                                                            class="form-control" name="datepresapp"
                                                                            value="<?php echo date('d F, Y', strtotime($PApptDate)) ?>"
                                                                            required="required">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Bank Name:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="bankname"
                                                                        value="<?php echo $Bank ?>" required="required">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Bank Branch:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="bankbranch"
                                                                        value="<?php echo $Branch ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Account Number:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="bankaccount"
                                                                        value="<?php echo $AccNo ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Highest
                                                                    Qualification:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <select name="highquali" class="form-control"
                                                                        style="color:#000000" id="highquali"
                                                                        required="required">
                                                                        <option value="<?php echo $HQualificatn ?>">
                                                                            <?php echo $HQualificatn_full ?></option>
                                                                        <option value="firstdegree">First Degree
                                                                        </option>
                                                                        <option value="masters">Masters</option>
                                                                        <option value="phd">Ph.D</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <hr class="separator" />
                                                        <h2>Next of Kin</h2>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Name: </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="nextkinname"
                                                                        value="<?php echo $nextname ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Relationship:
                                                                </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="nextkinrelation"
                                                                        value="<?php echo $nextrelation ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Address: </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="nextkinadress"
                                                                        value="<?php echo $nextaddress ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <label class="col-lg-4 control-label">Phone: </label>
                                                                <div class="col-lg-7">
                                                                    <input type="text" class="form-control"
                                                                        style="color:#000000" name="nextkinphone"
                                                                        value="<?php echo $nextphone ?>"
                                                                        required="required">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <input type="submit" name="update_profile" class="btn btn-info"
                                                            value="Save">
                                                    </div>
                                                </div>
                                            </div>
                                        </section>


                                    </div>
                                    <div class="col-lg-1">

                                    </div>


                                </div>
                            </form>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>
    <?php
    $conn->close();
    $conn2->close();
    ?>
    <?php
    include_once 'includes/footer.php';
    ?>

    <script type="text/javascript">
    $(document).ready(function() {
        $("select.state1").change(function() {
            var selectedState = $(".state1 option:selected").val();
            $.ajax({
                type: "POST",
                url: 'ajax_save_rec/ajaxDataProfile.php',
                data: {
                    state1: selectedState
                }
            }).done(function(data) {
                $("#getlga").html(data);
            });
        });
    });
    </script>

    <script type="text/javascript">
    $(document).ready(function() {
        $("select.nation").change(function() {
            var selectedNation = $(".nation option:selected").val();
            $.ajax({
                type: "POST",
                url: 'ajax_save_rec/ajaxDataProfile.php',
                data: {
                    nation: selectedNation
                }
            }).done(function(data) {
                $("#getnation").html(data);
            });
        });
    });
    </script>

    <script type="text/javascript">
    $(document).ready(function() {
        $("select.health").change(function() {
            var selectedHealth = $(".health option:selected").val();
            $.ajax({
                type: "POST",
                url: 'ajax_save_rec/ajaxDataProfile.php',
                data: {
                    health: selectedHealth
                }
            }).done(function(data) {
                $("#gethealth").html(data);
            });
        });
    });
    </script>

</body>

</html>
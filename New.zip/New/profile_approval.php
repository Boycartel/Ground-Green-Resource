<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_alocation'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Profile Approval</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results and Profile Approval
                            </li>

                            <li class="active">
                                <strong>Profile Approval</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Profile Approval
                        </div>
                        <div class="panel-body">
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $conn7 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE7);
                            if ($conn7->connect_error) {
                                die("Connection failed: " . $conn7->connect_error);
                            }

                            $conn12 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE12);
                            if ($conn12->connect_error) {
                                die("Connection failed: " . $conn12->connect_error);
                            }

                            $dept = $_SESSION['deptcode'];

                            if (isset($_POST["approve_profile"])) {

                                $staffid = $_SESSION['staffid1'];
                                $PSN = $staffid;

                                $sql = "UPDATE staff_profile SET newrec = 'NO' WHERE PSN = '$PSN'";
                                $result = $conn7->query($sql);

                                $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$PSN'";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {

                                        $fname = $row['fname'];
                                        $surname = $row['sname'];
                                        $othernames = $row['oname'];
                                        $title1 = $row['title'];
                                        $apptype = $row['Status'];
                                        $leaveabsent = $row['leaveabsent_study'];
                                        $postrank  = $row['Rank1'];
                                        $area_special = $row['area_special'];
                                        $salary_grade = $row['GradeL'];
                                        $stepG = $row['StepG'];
                                        $email1 = $row['email'];

                                        $nationality = $row["nationality"];
                                        $country = $row["country"];
                                        $placebirth = $row["placebirth"];
                                        $religion = $row["religion"];
                                        $healthstatus = $row["healthstatus"];
                                        $disable = $row["disable"];
                                        $healthtype = $row["healthtype"];
                                        $accommtype = $row["accommodation"];

                                        $DeptCode2 = $row["DeptCode"];
                                        $Department = $row["Department"];
                                        $Sex = $row["Sex"];
                                        $permaddress = $row["ParmtAdress"];
                                        $contaddress = $row["ContAdd"];
                                        $stateOfOrigin = $row["stateOfOrigin"];
                                        $lga = $row["LGA"];
                                        $datebirth = $row["DateBirth"];
                                        $datefirstapp = $row["FApptDate"];
                                        $FApptMonth = date('F', strtotime($datefirstapp));
                                        $FApptYear = date('Y', strtotime($datefirstapp));
                                        //$FApptMonth = $row["FApptMonth"];
                                        //$FApptYear = $row["FApptYear"];
                                        $datepresapp = $row["PApptDate"];
                                        $BankCode2 = $row["BankCode"];
                                        $bankname = $row["Bank"];
                                        $bankbranch = $row["Branch"];
                                        $bankaccount = $row["AccNo"];

                                        $Scale = $row["Scale"];
                                        $highquali = $row["HQualificatn"];
                                        $marrystatus = $row["maritalstatus"];
                                        $nochildren = $row["nochildren"];
                                        $phone1 = $row["phonenumber"];
                                        $phone2 = $row["phonenumber2"];
                                        $Status = $row["Status"];
                                        $nextkinname = $row["nextname"];
                                        $nextkinrelation = $row["nextrelation"];
                                        $nextkinadress = $row["nextaddress"];
                                        $nextkinphone = $row["nextphone"];
                                    }
                                }

                                $sql = "UPDATE staff_profile SET  title = '$title1', email = '$email1', Status = '$apptype', leaveabsent_study = '$leaveabsent', Rank1 = '$postrank', area_special = '$area_special', GradeL = '$salary_grade', StepG = '$stepG', phonenumber = '$phone1', phonenumber2 = '$phone2' WHERE PSN = '$staffid'";
                                $result = $conn7->query($sql);

                                $sql = "UPDATE staff_profile SET maritalstatus = '$marrystatus', religion = '$religion', nationality = '$nationality', stateOfOrigin = '$stateOfOrigin', country = '$country', LGA = '$lga', healthstatus = '$healthstatus', healthtype = '$healthtype' WHERE PSN = '$staffid'";
                                $result = $conn7->query($sql);

                                $sql = "UPDATE staff_profile SET accommodation = '$accommtype', DateBirth = '$datebirth', placebirth = '$placebirth', ParmtAdress = '$permaddress', ContAdd = '$contaddress', FApptDate = '$datefirstapp', FApptMonth = '$FApptMonth', FApptYear = '$FApptYear', PApptDate = '$datepresapp', Bank = '$bankname', Branch = '$bankbranch', AccNo = '$bankaccount', HQualificatn = '$highquali' WHERE PSN = '$staffid'";
                                $result = $conn7->query($sql);

                                $sql = "UPDATE staff_profile SET nextname = '$nextkinname', nextrelation = '$nextkinrelation', nextaddress = '$nextkinadress', nextphone = '$nextkinphone' WHERE PSN = '$staffid'";
                                $result = $conn7->query($sql);

                                $sql = "DELETE FROM staff_profile_edit WHERE PSN = '$PSN'";
                                $result = $conn7->query($sql);
                            }


                            if (isset($_POST["submit"]) || isset($_POST["approve_duties"]) || isset($_POST["approve_reserch"]) || isset($_POST["approve_comm"]) || isset($_POST["approve_profile"]) || isset($_POST["approve_child"]) || isset($_POST["approve_institu"]) || isset($_POST["approve_prof_body"])) {
                                if (isset($_POST["submit"])) {
                                    $staffid = $_POST["staffid"];
                                    $_SESSION['staffid1'] = $staffid;
                                } else {
                                    $staffid = $_SESSION['staffid1'];
                                }

                                $PSN = $staffid;
                                $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $emailAdd = $row['emailAdd'];
                                        $phone = $row['phone'];
                                        $staffdept = strtolower($row['staffacddept']);
                                    }
                                }

                                $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$PSN'";
                                $result = $conn7->query($sql);
                                $i = 0;
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $i++;
                                    }
                                }

                                if ($i == 0) {
                                    $sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
                                } else {
                                    $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$PSN'";
                                }

                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {

                                        $fname = $row['fname'];
                                        $surname = $row['sname'];
                                        $othernames = $row['oname'];
                                        $mytitle = $row['title'];
                                        $apptype = $row['Status'];
                                        $leaveabsent_study = $row['leaveabsent_study'];
                                        $postn_rank = $row['Rank1'];
                                        $area_special = $row['area_special'];
                                        $salary_grade = $row['GradeL'];
                                        $stepG = $row['StepG'];

                                        $nationality = $row["nationality"];
                                        $placebirth = $row["placebirth"];
                                        $religion = $row["religion"];
                                        $healthstatus = $row["healthstatus"];
                                        $disable = $row["disable"];
                                        $healthtype = $row["healthtype"];
                                        $accommodation = $row["accommodation"];

                                        $DeptCode2 = $row["DeptCode"];
                                        $Department = $row["Department"];
                                        $Sex = $row["Sex"];
                                        $ParmtAdress = $row["ParmtAdress"];
                                        $ContAdd = $row["ContAdd"];
                                        $stateOfOrigin = $row["stateOfOrigin"];
                                        $LGA = $row["LGA"];
                                        $DateBirth = $row["DateBirth"];
                                        $FApptDate = $row["FApptDate"];
                                        $FApptMonth = $row["FApptMonth"];
                                        $FApptYear = $row["FApptYear"];
                                        $PApptDate = $row["PApptDate"];
                                        $BankCode2 = $row["BankCode"];
                                        $Bank = $row["Bank"];
                                        $Branch = $row["Branch"];
                                        $AccNo = $row["AccNo"];
                                        $email = $row["email"];
                                        $Scale = $row["Scale"];
                                        $HQualificatn = $row["HQualificatn"];
                                        $maritalstatus = $row["maritalstatus"];
                                        $nochildren = $row["nochildren"];
                                        $phonenumber = $row["phonenumber"];
                                        $phonenumber2 = $row["phonenumber2"];
                                        $Status = $row["Status"];
                                        $nextname = $row["nextname"];
                                        $nextrelation = $row["nextrelation"];
                                        $nextaddress = $row["nextaddress"];
                                        $nextphone = $row["nextphone"];
                                    }
                                }


                                if ($i !== 0) {

                                    $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $emailAdd_old = $row['emailAdd'];
                                            //$phone = $row['phone'];
                                        }
                                    }


                                    $sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
                                    $result = $conn7->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {

                                            //$fname = $row['fname'];
                                            //$surname = $row['sname'];
                                            //$othernames = $row['oname'];
                                            $mytitle_old = $row['title'];
                                            $apptype_old = $row['Status'];
                                            $leaveabsent_study_old = $row['leaveabsent_study'];
                                            $postn_rank_old = $row['Rank1'];
                                            $area_special_old = $row['area_special'];
                                            $salary_grade_old = $row['GradeL'];
                                            $stepG_old = $row['StepG'];

                                            $nationality_old = $row["nationality"];
                                            $placebirth_old = $row["placebirth"];
                                            $religion_old = $row["religion"];
                                            $healthstatus_old = $row["healthstatus"];

                                            $healthtype_old = $row["healthtype"];
                                            $accommodation_old = $row["accommodation"];


                                            $Sex_old = $row["Sex"];
                                            $ParmtAdress_old = $row["ParmtAdress"];
                                            $ContAdd_old = $row["ContAdd"];
                                            $stateOfOrigin_old = $row["stateOfOrigin"];
                                            $LGA_old = $row["LGA"];
                                            $DateBirth_old = $row["DateBirth"];
                                            $FApptDate_old = $row["FApptDate"];

                                            $PApptDate_old = $row["PApptDate"];
                                            $BankCode2_old = $row["BankCode"];
                                            $Bank_old = $row["Bank"];
                                            $Branch_old = $row["Branch"];
                                            $AccNo_old = $row["AccNo"];
                                            $email_old = $row["email"];

                                            $HQualificatn_old = $row["HQualificatn"];
                                            $maritalstatus_old = $row["maritalstatus"];

                                            $phonenumber_old = $row["phonenumber"];
                                            $phonenumber2_old = $row["phonenumber2"];
                                            $Status_old = $row["Status"];
                                            $nextname_old = $row["nextname"];
                                            $nextrelation_old = $row["nextrelation"];
                                            $nextaddress_old = $row["nextaddress"];
                                            $nextphone_old = $row["nextphone"];
                                        }
                                    }
                                }

                                if ($apptype == "fulltime") {
                                    $apptype_full = "Full Time";
                                } else if ($apptype == "parttime") {
                                    $apptype_full = "Part Time";
                                } else {
                                    $apptype_full = "Contract";
                                }


                                if ($postn_rank == "Prof") {
                                    $postn_rank_full = "Professor";
                                } elseif ($postn_rank == "assprof") {
                                    $postn_rank_full = "Associate Professor";
                                } elseif ($postn_rank == "SL") {
                                    $postn_rank_full = "Senior Lecturer";
                                } elseif ($postn_rank == "LI") {
                                    $postn_rank_full = "Lecturer I";
                                } elseif ($postn_rank == "LII") {
                                    $postn_rank_full = "Lecturer II";
                                } elseif ($postn_rank == "AL") {
                                    $postn_rank_full = "Assistant Lecturer";
                                } else {
                                    $postn_rank_full = "Graduate Assistant";
                                }

                                if ($leaveabsent_study == "leaveabsent") {
                                    $leaveabsent_study_full = "Leave of Absent";
                                } else if ($leaveabsent_study == "studyleave") {
                                    $leaveabsent_study_full = "Study Leave";
                                } else {
                                    $leaveabsent_study_full = $leaveabsent_study;
                                }

                                if ($nationality == "non") {
                                    $natinal_full = "Non Nigerian";
                                } else {
                                    $natinal_full = $nationality;
                                }

                                if ($accommodation == "campus") {
                                    $accommodation_full = "In Campus";
                                } else {
                                    $accommodation_full = "Off Campus";
                                }

                                if ($HQualificatn == "firstdegree") {
                                    $HQualificatn_full = "First Degree";
                                } else if ($HQualificatn == "masters") {
                                    $HQualificatn_full = "Masters";
                                } else {
                                    $HQualificatn_full = "Ph.D";
                                }
                            }


                            if (isset($_POST["approve_institu"])) {
                                $id = $_POST['id'];
                                $sql = "SELECT * FROM institution WHERE id = '$id'";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $approval = $row['approval'];
                                    }
                                }

                                if ($approval == "NO") {
                                    $sql = "UPDATE institution SET approval = 'YES' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                } else {
                                    $sql = "UPDATE institution SET approval = 'NO' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }
                            }

                            if (isset($_POST["approve_child"])) {
                                $id = $_POST['id'];
                                $sql = "SELECT * FROM children WHERE id = '$id'";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $approval = $row['approval'];
                                    }
                                }

                                if ($approval == "NO") {
                                    $sql = "UPDATE children SET approval = 'YES' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                } else {
                                    $sql = "UPDATE children SET approval = 'NO' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }
                            }

                            if (isset($_POST["approve_prof_body"])) {
                                $id = $_POST['id'];
                                $sql = "SELECT * FROM professional_body WHERE id = '$id'";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $approval = $row['approval'];
                                    }
                                }

                                if ($approval == "NO") {
                                    $sql = "UPDATE professional_body SET approval = 'YES' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                } else {
                                    $sql = "UPDATE professional_body SET approval = 'NO' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }
                            }

                            if (isset($_POST["approve_duties"])) {
                                $id = $_POST['id'];
                                $sql = "SELECT * FROM admin_duties WHERE id = '$id'";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $approval = $row['approval'];
                                    }
                                }

                                if ($approval == "NO") {
                                    $sql = "UPDATE admin_duties SET approval = 'YES' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                } else {
                                    $sql = "UPDATE admin_duties SET approval = 'NO' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }
                            }

                            if (isset($_POST["approve_reserch"])) {
                                $id = $_POST['id'];
                                $sql = "SELECT * FROM funded_research WHERE id = '$id'";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $approval = $row['approval'];
                                    }
                                }

                                if ($approval == "NO") {
                                    $sql = "UPDATE funded_research SET approval = 'YES' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                } else {
                                    $sql = "UPDATE funded_research SET approval = 'NO' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }
                            }

                            if (isset($_POST["approve_comm"])) {
                                $id = $_POST['id'];
                                $sql = "SELECT * FROM comm_service WHERE id = '$id'";
                                $result = $conn7->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $approval = $row['approval'];
                                    }
                                }

                                if ($approval == "NO") {
                                    $sql = "UPDATE comm_service SET approval = 'YES' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                } else {
                                    $sql = "UPDATE comm_service SET approval = 'NO' WHERE id = '$id'";
                                    $result = $conn7->query($sql);
                                }
                            }
                            ?>
                            <div class="row">


                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="form-group">
                                        <label class="col-lg-2 control-label">Select Staff: </label>
                                        <div class="col-lg-6">
                                            <select class='activit form-control m-bot15' name='staffid' required>
                                                <option value=""></option>
                                                <?php
                                                $sql = "SELECT * FROM users WHERE staffacddept = '$dept' ORDER BY staffid";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $staffid2 = $row['staffid'];
                                                        $full_name = $row['full_name'];
                                                        echo "<option value = '$staffid2'>$staffid2 $full_name</option>";
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="col-lg-4">
                                            <button type="submit" name="submit" class="mb-xs mt-xs mr-xs btn btn-sm btn-success">Submit</button>
                                        </div>
                                    </div>
                                </form>

                                <hr class="separator" />
                                <?php if (isset($_POST["submit"]) || isset($_POST["approve_duties"]) || isset($_POST["approve_reserch"]) || isset($_POST["approve_comm"]) || isset($_POST["approve_profile"]) || isset($_POST["approve_child"]) || isset($_POST["approve_institu"]) || isset($_POST["approve_prof_body"])) { ?>
                                    <?php
                                    if (isset($_POST["submit"])) {
                                        $staffid = $_POST["staffid"];
                                        $_SESSION['staffid1'] = $staffid;
                                    } else {
                                        $staffid = $_SESSION['staffid1'];
                                    }
                                    ?>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <?php if ($i == 0) { ?>
                                                <label class="col-lg-4 control-label" style="text-align: left; color: red"></label>
                                            <?php } else { ?>
                                                <label class="col-lg-4 control-label" style="text-align: left; color: red"><b>*
                                                        New
                                                        Record Awaiting Approval</b></label>
                                            <?php } ?>
                                            <label class="col-lg-4 control-label">Current Session:
                                                <?php echo  $corntsession ?></label>
                                            <label class="col-lg-4 control-label">Semester:
                                                <?php echo  $cursemester ?></label>

                                        </div>
                                        <hr class="separator" />
                                        <section class="panel panel-default">
                                            <header class="panel-heading">
                                                PROFILE
                                            </header>
                                            <div class="panel-body">
                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-10">

                                                    <div>
                                                        <?php
                                                        $staff_pic_folder = $_SESSION['staff_pic_folder'];
                                                        echo "<img alt='' src='$staff_pic_folder/" . strtoupper($_SESSION['deptcode']) . "/images/" . $staffid . "/MyPic1.jpg' width='90' height='100'>";
                                                        ?>
                                                        <br>
                                                        <form class="form-horizontal form-bordered" method="post">
                                                            <?php if ($i == 0) { ?>
                                                                <div class="form-group">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>SurName:</b>
                                                                        <?php echo $surname ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>First
                                                                            Name:</b> <?php echo $fname ?></label>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Other
                                                                            Name(s):</b> <?php echo $othernames ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>File
                                                                            Number:</b> <?php echo $PSN ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Title:</b>
                                                                        <?php echo $mytitle ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Department:</b>
                                                                        <?php echo $_SESSION["deptname"] ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>email:</b>
                                                                        <?php echo $emailAdd ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Highest
                                                                            Qualification:</b>
                                                                        <?php echo $HQualificatn_full ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Appointment Type:</b>
                                                                        <?php echo $apptype_full ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Leave
                                                                            of Absence/Study Leave:</b>
                                                                        <?php echo $leaveabsent_study_full ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Position/Rank:</b>
                                                                        <?php echo $postn_rank_full ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Area
                                                                            of Specialization:</b>
                                                                        <?php echo $area_special ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Salary
                                                                            Grade:</b> <?php echo $salary_grade ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Step:
                                                                            <?php echo $stepG ?></b> </label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Marital
                                                                            Status:</b>
                                                                        <?php echo $maritalstatus ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Nationality:</b>
                                                                        <?php echo $natinal_full ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>State
                                                                            of Origin:</b> <?php echo $stateOfOrigin ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>LGA:</b>
                                                                        <?php echo $LGA ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Religion:</b>
                                                                        <?php echo $religion ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Health
                                                                            Status:</b> <?php echo $healthstatus ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>If
                                                                            Disabled, Type:</b>
                                                                        <?php echo $healthtype ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Accommodation Status:</b>
                                                                        <?php echo $accommodation_full ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Date
                                                                            of Birth:</b>
                                                                        <?php echo date('d F, Y', strtotime($DateBirth)); ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Place
                                                                            of Birth: <?php echo $placebirth ?></b> </label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Permenet
                                                                            Home Address:</b>
                                                                        <?php echo $ParmtAdress ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Contact
                                                                            Address:</b>
                                                                        <?php echo $ContAdd ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Phone
                                                                            Number 1:</b> <?php echo $phonenumber ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Phone
                                                                            Number 2:</b> <?php echo $phonenumber2 ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Date
                                                                            of First Appointment:</b>
                                                                        <?php echo date('d F, Y', strtotime($FApptDate)); ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Date
                                                                            of Present Appointment:</b>
                                                                        <?php echo date('d F, Y', strtotime($PApptDate)); ?></b>
                                                                    </label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Bank:</b>
                                                                        <?php echo $Bank ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Branch:</b>
                                                                        <?php echo $Branch ?></label>
                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Account
                                                                            Number:</b>
                                                                        <?php echo $AccNo ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"></label>
                                                                </div>
                                                            <?php } else { ?>
                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>SurName:</b>
                                                                        <?php echo $surname ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>First
                                                                            Name:</b> <?php echo $fname ?></label>

                                                                </div>
                                                                <div class="form-group" style="color: black">
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Other
                                                                            Name(s):</b> <?php echo $othernames ?></label>
                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>File
                                                                            Number:</b> <?php echo $PSN ?></label>
                                                                </div>


                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($mytitle_old == $mytitle) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Title:</b>
                                                                            <?php echo $mytitle ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Title:</b>
                                                                            <?php echo $mytitle ?></label>
                                                                    <?php } ?>

                                                                    <label class="col-lg-6 control-label" style="text-align: left"><b>Department:</b>
                                                                        <?php echo $_SESSION["deptname"] ?></label>

                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($emailAdd_old == $emailAdd) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>email:</b>
                                                                            <?php echo $emailAdd ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>email:</b>
                                                                            <?php echo $emailAdd ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($HQualificatn_old == $HQualificatn) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Highest
                                                                                Qualification:</b>
                                                                            <?php echo $HQualificatn_full ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Highest
                                                                                Qualification:</b>
                                                                            <?php echo $HQualificatn_full ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($apptype_old == $apptype) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Appointment Type:</b>
                                                                            <?php echo $apptype_full ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Appointment
                                                                                Type:</b> <?php echo $apptype_full ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($leaveabsent_study_old == $leaveabsent_study) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Leave
                                                                                of Absence/Study Leave:</b>
                                                                            <?php echo $leaveabsent_study_full ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Leave of
                                                                                Absence/Study Leave:</b>
                                                                            <?php echo $leaveabsent_study_full ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($postn_rank_old == $postn_rank) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Position/Rank:</b>
                                                                            <?php echo $postn_rank_full ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Position/Rank:</b>
                                                                            <?php echo $postn_rank_full ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($area_special_old == $area_special) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Area
                                                                                of Specialization:</b>
                                                                            <?php echo $area_special ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Area of
                                                                                Specialization:</b>
                                                                            <?php echo $area_special ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($salary_grade_old == $salary_grade) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Salary
                                                                                Grade:</b> <?php echo $salary_grade ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Salary
                                                                                Grade:</b> <?php echo $salary_grade ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($stepG_old == $stepG) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Step:
                                                                                <?php echo $stepG ?></b> </label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Step:
                                                                                <?php echo $stepG ?></b> </label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($maritalstatus_old == $maritalstatus) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Marital
                                                                                Status:</b>
                                                                            <?php echo $maritalstatus ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Marital
                                                                                Status:</b> <?php echo $maritalstatus ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($nationality_old == $nationality) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Nationality:</b>
                                                                            <?php echo $natinal_full ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Nationality:</b> <?php echo $natinal_full ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($stateOfOrigin_old == $stateOfOrigin) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>State
                                                                                of Origin:</b> <?php echo $stateOfOrigin ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>State of
                                                                                Origin:</b> <?php echo $stateOfOrigin ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($LGA_old == $LGA) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>LGA:</b>
                                                                            <?php echo $LGA ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>LGA:</b>
                                                                            <?php echo $LGA ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($religion_old == $religion) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Religion:</b>
                                                                            <?php echo $religion ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Religion:</b>
                                                                            <?php echo $religion ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($healthstatus_old == $healthstatus) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Health
                                                                                Status:</b> <?php echo $healthstatus ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Health
                                                                                Status:</b> <?php echo $healthstatus ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($healthtype_old == $healthtype) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>If
                                                                                Disabled, Type:</b>
                                                                            <?php echo $healthtype ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>If Disabled,
                                                                                Type:</b> <?php echo $healthtype ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($accommodation_old == $accommodation) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Accommodation Status:</b>
                                                                            <?php echo $accommodation_full ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Accommodation
                                                                                Status:</b>
                                                                            <?php echo $accommodation_full ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($DateBirth_old == $DateBirth) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Date
                                                                                of Birth:</b>
                                                                            <?php echo date('d F, Y', strtotime($DateBirth)); ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Date of
                                                                                Birth:</b>
                                                                            <?php echo date('d F, Y', strtotime($DateBirth)); ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($placebirth_old == $placebirth) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Place
                                                                                of Birth: <?php echo $placebirth ?></b> </label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Place of Birth:
                                                                                <?php echo $placebirth ?></b> </label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($ParmtAdress_old == $ParmtAdress) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Permenet
                                                                                Home Address:</b>
                                                                            <?php echo $ParmtAdress ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Permenet Home
                                                                                Address:</b> <?php echo $ParmtAdress ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($ContAdd_old == $ContAdd) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Contact
                                                                                Address:</b>
                                                                            <?php echo $ContAdd ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Contact
                                                                                Address:</b> <?php echo $ContAdd ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($phonenumber_old == $phonenumber) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Phone
                                                                                Number 1:</b> <?php echo $phonenumber ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Phone Number
                                                                                1:</b> <?php echo $phonenumber ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($phonenumber2_old == $phonenumber2) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Phone
                                                                                Number 2:</b> <?php echo $phonenumber2 ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Phone Number
                                                                                2:</b> <?php echo $phonenumber2 ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($FApptDate_old == $FApptDate) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Date
                                                                                of First Appointment:</b>
                                                                            <?php echo date('d F, Y', strtotime($FApptDate)); ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Date of First
                                                                                Appointment:</b>
                                                                            <?php echo date('d F, Y', strtotime($FApptDate)); ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($PApptDate_old == $PApptDate) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Date
                                                                                of Present Appointment:</b>
                                                                            <?php echo date('d F, Y', strtotime($PApptDate)); ?></b>
                                                                        </label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Date of Present
                                                                                Appointment:</b>
                                                                            <?php echo date('d F, Y', strtotime($PApptDate)); ?></b>
                                                                        </label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($Bank_old == $Bank) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Bank:</b>
                                                                            <?php echo $Bank ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Bank:</b>
                                                                            <?php echo $Bank ?></label>
                                                                    <?php } ?>

                                                                    <?php if ($Branch_old == $Branch) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Branch:</b>
                                                                            <?php echo $Branch ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Branch:</b>
                                                                            <?php echo $Branch ?></label>
                                                                    <?php } ?>


                                                                </div>

                                                                <div class="form-group" style="color: black">
                                                                    <?php if ($AccNo_old == $AccNo) { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><b>Account
                                                                                Number:</b>
                                                                            <?php echo $AccNo ?></label>
                                                                    <?php } else { ?>
                                                                        <label class="col-lg-6 control-label" style="text-align: left"><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                            <b>Account
                                                                                Number:</b> <?php echo $AccNo ?></label>
                                                                    <?php } ?>

                                                                    <label class="col-lg-6 control-label" style="text-align: left"></label>
                                                                </div>

                                                            <?php } ?>
                                                        </form>

                                                    </div>
                                                    <hr class="separator" />
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label">Next of Kin:</label>
                                                        <div class="col-sm-8">

                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-3 control-label"></label>
                                                        <div class="col-sm-8">
                                                            <table class="table mb-none">

                                                                <tbody>
                                                                    <?php if ($i == 0) { ?>
                                                                        <tr>
                                                                            <th>Name:</th>
                                                                            <td><?php echo $nextname ?></td>
                                                                            <th>Relationship:</th>
                                                                            <td><?php echo $nextrelation ?></td>
                                                                        </tr>

                                                                        <tr>
                                                                            <th>Address:</th>
                                                                            <td><?php echo $nextaddress ?></td>
                                                                            <th>Phone:</th>
                                                                            <td><?php echo $nextphone ?></td>
                                                                        </tr>
                                                                    <?php } else { ?>
                                                                        <tr>
                                                                            <?php if ($nextname_old == $nextname) { ?>
                                                                                <th>Name:</th>
                                                                            <?php } else { ?>
                                                                                <th><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                                    Name:
                                                                                </th>
                                                                            <?php } ?>

                                                                            <td><?php echo $nextname ?></td>
                                                                            <?php if ($nextrelation_old == $nextrelation) { ?>
                                                                                <th>Relationship:</th>
                                                                            <?php } else { ?>
                                                                                <th><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                                    Relationship:</th>
                                                                            <?php } ?>

                                                                            <td><?php echo $nextrelation ?></td>
                                                                        </tr>

                                                                        <tr>
                                                                            <?php if ($nextaddress_old == $nextaddress) { ?>
                                                                                <th>Address:</th>
                                                                            <?php } else { ?>
                                                                                <th><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                                    Address:</th>
                                                                            <?php } ?>

                                                                            <td><?php echo $nextaddress ?></td>
                                                                            <?php if ($nextphone_old == $nextphone) { ?>
                                                                                <th>Phone:</th>
                                                                            <?php } else { ?>
                                                                                <th><span class="required" style="font-size: large" data-toggle="tooltip" data-placement="top" title="New Record Awaiting Approval">*</span>
                                                                                    Phone:
                                                                                </th>
                                                                            <?php } ?>

                                                                            <td><?php echo $nextphone ?></td>
                                                                        </tr>
                                                                    <?php } ?>


                                                                </tbody>
                                                            </table>

                                                        </div>
                                                    </div>
                                                    <diV style="text-align: right">
                                                        <form class='form-horizontal form-bordered' method='post'>
                                                            <?php if ($i !== 0) { ?>
                                                                <input type='submit' name='approve_profile' class='btn btn-success btn-xs' value='Approve'>
                                                            <?php } ?>
                                                        </form>
                                                    </diV>

                                                </div>
                                                <div class="col-md-1">
                                                </div>
                                            </div>
                                        </section>


                                        <hr class="separator" />
                                        <section class="panel panel-default">
                                            <header class="panel-heading">
                                                CHILDREN
                                            </header>
                                            <div class="panel-body">

                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-10">

                                                    <?php
                                                    $sql = "SELECT * FROM children WHERE fileno = '$staffid'";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                        <table class="table mb-none">
                                                            <thead>
                                                                <tr>
                                                                    <th>Name</th>
                                                                    <th>Sex</th>
                                                                    <th>Date of Birth</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                <?php
                                                                while ($row = $result->fetch_assoc()) {

                                                                    $id_child = $row["id"];
                                                                    $childname = $row["childname"];
                                                                    $childbirth = date('d F, Y', strtotime($row["datebirth"]));
                                                                    $childsex = $row["sex1"];
                                                                    $approval_child = $row['approval'];

                                                                    echo "<tr><td>$childname</td><td>$childsex</td><td>$childbirth</td><td>";


                                                                    echo "<form class='form-horizontal form-bordered' method='post'>";
                                                                    echo "<input type='hidden' value='$id_child' name='id'>";
                                                                    if ($approval_child == "YES") {
                                                                        echo "<input type='submit' name='approve_child' class='btn btn-danger btn-xs' value='Cancel Approval'>";
                                                                    } else {
                                                                        echo "<input type='submit' name='approve_child' class='btn btn-success btn-xs' value='Approve'>";
                                                                    }
                                                                    echo "</form>";
                                                                    echo "</td></tr>";
                                                                }

                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    <?php } ?>

                                                </div>
                                                <div class="col-md-1">
                                                </div>
                                            </div>
                                        </section>


                                        <hr class="separator" />
                                        <section class="panel panel-default">
                                            <header class="panel-heading">
                                                Academic Qualification
                                            </header>
                                            <div class="panel-body">
                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-10">
                                                    <?php
                                                    $sql = "SELECT * FROM institution WHERE fileno = '$staffid'";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                        <table class="table stats-table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Institution Name</th>
                                                                    <th>From</th>
                                                                    <th>To</th>
                                                                    <th>Qualification Obtained</th>
                                                                    <th>Qualification Date</th>
                                                                    <th>Image</th>
                                                                    <th>Action</th>

                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                <?php

                                                                while ($row = $result->fetch_assoc()) {
                                                                    $id_institu = $row["id"];
                                                                    $instiname = $row["instiname"];
                                                                    $fromdate = $row["fromdate"];
                                                                    $todate = $row["todate"];
                                                                    $qualiobtained = $row["qualiobtained"];
                                                                    $qualidate = date('d F, Y', strtotime($row["qualidate"]));

                                                                    $approval_institu = $row['approval'];
                                                                    echo "<tr><td>$instiname</td><td>$fromdate</td><td>$todate</td><td>$qualiobtained</td><td>$qualidate</td><td>";


                                                                    $sql2 = "SELECT * FROM " . $staffdept . " WHERE staffid = '$staffid' AND from_cert = 'YES' AND imageid = '$qualiobtained'";
                                                                    $result2 = $conn12->query($sql2);
                                                                    if ($result2->num_rows > 0) {
                                                                        while ($row2 = $result2->fetch_assoc()) {
                                                                ?>
                                                                            <a href="data:image/jpeg;base64,<?php echo base64_encode($row2["imageData"]) ?>">

                                                                                <img src="data:image/jpeg;base64,<?php echo base64_encode($row2["imageData"]) ?>" alt="Project" style="width: 70px; height:70px" />
                                                                            </a>
                                                                            <!-- <a href="download.php?id=<?php echo $id_institu; ?>" target="_blank">
                                                            <?php echo $qualiobtained; ?>
                                                        </a> -->
                                                                <?php
                                                                        }
                                                                    }
                                                                    echo "</td><td>";

                                                                    echo "<form class='form-horizontal form-bordered' method='post'>";
                                                                    echo "<input type='hidden' value='$id_institu' name='id'>";
                                                                    if ($approval_institu == "YES") {
                                                                        echo "<input type='submit' name='approve_institu' class='btn btn-danger btn-xs' value='Cancel Approval'>";
                                                                    } else {
                                                                        echo "<input type='submit' name='approve_institu' class='btn btn-success btn-xs' value='Approve'>";
                                                                    }
                                                                    echo "</form>";
                                                                    echo "</td></tr>";
                                                                }

                                                                ?>

                                                            </tbody>
                                                        </table>

                                                    <?php } ?>
                                                </div>
                                                <div class="col-md-1">
                                                </div>

                                            </div>
                                        </section>


                                        <hr class="separator" />
                                        <section class="panel panel-default">
                                            <header class="panel-heading">
                                                Membership of Professional Bodies/Societies
                                            </header>
                                            <div class="panel-body">

                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-10">

                                                    <table class="table stats-table">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Date</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                            $sql = "SELECT * FROM professional_body WHERE fileno = '$staffid'";
                                                            $result = $conn7->query($sql);
                                                            $bodysno = 0;
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $bodysno++;
                                                                    $id_prof_body = $row["id"];
                                                                    $profname = $row["profname"];
                                                                    $profdate = date('d F, Y', strtotime($row["profdate"]));
                                                                    $approval_profbody = $row['approval'];
                                                                    echo "<tr><td>$profname</td><td>$profdate</td><td>";

                                                                    echo "<form class='form-horizontal form-bordered' method='post'>";
                                                                    echo "<input type='hidden' value='$id_prof_body' name='id'>";
                                                                    if ($approval_profbody == "YES") {
                                                                        echo "<input type='submit' name='approve_prof_body' class='btn btn-danger btn-xs' value='Cancel Approval'>";
                                                                    } else {
                                                                        echo "<input type='submit' name='approve_prof_body' class='btn btn-success btn-xs' value='Approve'>";
                                                                    }
                                                                    echo "</form>";
                                                                    echo "</td></tr>";
                                                                }
                                                            }

                                                            ?>

                                                        </tbody>
                                                    </table>


                                                </div>
                                                <div class="col-md-1">
                                                </div>
                                            </div>
                                        </section>


                                        <hr class="separator" />
                                        <section class="panel panel-default">
                                            <header class="panel-heading">
                                                ADMINISTRATIVE DUTIES
                                            </header>
                                            <div class="panel-body">

                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-10">

                                                    <?php
                                                    $sql = "SELECT * FROM admin_duties WHERE staffid = '$staffid' ORDER BY session1";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                        <table class="table mb-none">
                                                            <thead>
                                                                <tr>

                                                                    <th>Type of Activity</th>
                                                                    <th>Details</th>
                                                                    <th>Year</th>
                                                                    <th>Session</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                <?php
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $activit_code = $row['activit_code'];
                                                                    $activity_type = $row['activity_type'];
                                                                    $year1 = $row['year1'];
                                                                    $session1 = $row['session1'];
                                                                    $approval = $row['approval'];
                                                                    $id = $row['id'];
                                                                    if ($activit_code == "15" || $activit_code == "18" || $activit_code == "19") {
                                                                        $specify = $row['specify'];
                                                                        echo "<tr><td>$activity_type</td><td>$specify</td><td>$year1</td><td>$session1</td><td>";
                                                                    } else {
                                                                        echo "<tr><td>$activity_type</td><td></td><td>$year1</td><td>$session1</td><td>";
                                                                    }

                                                                    echo "<form class='form-horizontal form-bordered' method='post'>";
                                                                    echo "<input type='hidden' value='$id' name='id'>";
                                                                    if ($session1 == $corntsession) {
                                                                        if ($approval == "YES") {
                                                                            echo "<input type='submit' name='approve_duties' class='btn btn-danger btn-xs' value='Cancel Approval'>";
                                                                        } else {
                                                                            echo "<input type='submit' name='approve_duties' class='btn btn-success btn-xs' value='Approve'>";
                                                                        }
                                                                    }
                                                                    echo "</form>";
                                                                    echo "</td></tr>";
                                                                }

                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    <?php } ?>

                                                </div>
                                                <div class="col-md-1">
                                                </div>
                                            </div>
                                        </section>




                                        <hr class="separator" />
                                        <section class="panel panel-default">
                                            <header class="panel-heading">
                                                FUNDED RESEARCH AND CONSULTANCY
                                            </header>
                                            <div class="panel-body">

                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-10">

                                                    <?php
                                                    $sql = "SELECT * FROM funded_research WHERE staffid = '$staffid' ORDER BY session1";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                        <table class="table mb-none">
                                                            <thead>
                                                                <tr>
                                                                    <th hidden="hidden">ID</th>
                                                                    <th>Project No</th>
                                                                    <th>Title of Award</th>
                                                                    <th>In-Kind Required by Grant</th>
                                                                    <th>Release Time</th>
                                                                    <th>Total (Amount)</th>
                                                                    <th>Remark</th>
                                                                    <th>Session</th>
                                                                    <th>Action</th>

                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                <?php
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $projt_no = $row['projt_no'];
                                                                    $projt_title = $row['projt_title'];
                                                                    $reguire_grant = $row['reguire_grant'];
                                                                    $release_time = $row['release_time'];
                                                                    //$totamount = number_format($row['totamount'], 2);
                                                                    $totamount = $row['totamount'];
                                                                    $remark1 = $row['remark1'];
                                                                    $id = $row['id'];
                                                                    $approval_research = $row['approval'];

                                                                    echo "<tr><td hidden='hidden'>$id</td><td>$projt_no</td><td>$projt_title</td><td>$reguire_grant</td><td>$release_time</td><td>$totamount</td><td>$remark1</td><td>$session1</td><td>";

                                                                    echo "<form class='form-horizontal form-bordered' method='post'>";
                                                                    echo "<input type='hidden' value='$id' name='id'>";
                                                                    if ($session1 == $corntsession) {
                                                                        if ($approval_research == "YES") {
                                                                            echo "<input type='submit' name='approve_reserch' class='btn btn-danger btn-xs' value='Cancel Approval'>";
                                                                        } else {
                                                                            echo "<input type='submit' name='approve_reserch' class='btn btn-success btn-xs' value='Approve'>";
                                                                        }
                                                                    }
                                                                    echo "</form>";
                                                                    echo "</td></tr>";
                                                                }

                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    <?php } ?>

                                                </div>
                                                <div class="col-md-1">
                                                </div>
                                            </div>
                                        </section>


                                        <hr class="separator" />
                                        <section class="panel panel-default">
                                            <header class="panel-heading">
                                                COMMUNITY SERVICE (<i>Services Rendered Without
                                                    Demand for
                                                    Payment</i>)
                                            </header>
                                            <div class="panel-body">

                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-10">

                                                    <?php
                                                    $sql = "SELECT * FROM comm_service WHERE staffid = '$staffid' ORDER BY session1";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                        <table class="table mb-none">
                                                            <thead>
                                                                <tr>
                                                                    <th hidden="hidden">ID</th>
                                                                    <th>Type</th>
                                                                    <th>Beneficiary</th>
                                                                    <th>Effect</th>
                                                                    <th>Date</th>
                                                                    <th>Session</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                                <?php
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $type_comm = $row['type_comm'];
                                                                    $beneficiary = $row['beneficiary'];
                                                                    $effect = $row['effect'];
                                                                    $date_comm = $row['date_comm'];
                                                                    $approval_comm = $row['approval'];
                                                                    $id = $row['id'];

                                                                    echo "<tr><td hidden='hidden'>$id</td><td>$type_comm</td><td>$beneficiary</td><td>$effect</td><td>$date_comm</td><td>$session1</td><td>";

                                                                    echo "<form class='form-horizontal form-bordered' method='post'>";
                                                                    echo "<input type='hidden' value='$id' name='id'>";
                                                                    if ($session1 == $corntsession) {
                                                                        if ($approval_comm == "YES") {
                                                                            echo "<input type='submit' name='approve_comm' class='btn btn-danger btn-xs' value='Cancel Approval'>";
                                                                        } else {
                                                                            echo "<input type='submit' name='approve_comm' class='btn btn-success btn-xs' value='Approve'>";
                                                                        }
                                                                    }
                                                                    echo "</form>";
                                                                    echo "</td></tr>";
                                                                }

                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    <?php } ?>


                                                </div>

                                            </div>



                                        </section>


                                        <hr class="separator" />
                                        <section class="content-with-menu-has-toolbar media-gallery">
                                            <div class="content-with-menu-container">

                                                <div class="row mg-files" data-sort-destination data-sort-id="media-gallery">

                                                    <?php

                                                    $sql = "SELECT * FROM " . $staffdept . " WHERE staffid = '$staffid'";
                                                    $result = $conn12->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $img_id = $row["id"];
                                                            $from_cert = $row["from_cert"];
                                                    ?>
                                                            <div class="isotope-item document col-sm-6 col-md-4 col-lg-3">
                                                                <div class="thumbnail">
                                                                    <form class='form-horizontal form-bordered' method='post'>
                                                                        <div>
                                                                            <a href="data:image/jpeg;base64,<?php echo base64_encode($row["imageData"]) ?>">

                                                                                <img src="data:image/jpeg;base64,<?php echo base64_encode($row["imageData"]) ?>" class="img-responsive" alt="Project" style="width: 447px; height:300px" />
                                                                            </a>
                                                                            <div class="mg-thumb-options">
                                                                                <div class="mg-zoom"><i class="fa fa-search"></i>
                                                                                </div>
                                                                                <div class="mg-toolbar">

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <h5 class="mg-title text-semibold">
                                                                            <?php echo $row["imagetitle"] ?>
                                                                        </h5>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                    <?php
                                                        }
                                                    }

                                                    ?>



                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                <?php } ?>
                                <?php
                                $conn->close();
                                $conn7->close();
                                $conn12->close();
                                ?>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
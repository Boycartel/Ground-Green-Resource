<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['e_exam_results'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--Print Div-->
    <script type="text/javascript">
        function printme() {
            var print_div = document.getElementById("printablediv");
            var print_area = window.open();
            print_area.document.write(print_div.innerHTML);
            print_area.document.close();
            print_area.focus();
            print_area.print();
            print_area.close();
        }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>e-Exam Results</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-file"></i>
                                </a>
                            </li>
                            <li><span>Results</span></li>
                            <li><span>e-Exam Results</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">
                    <form class="form-horizontal form-bordered" method="post">
                        <div class="col-lg-5">
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Matric Number: </label>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" style="color:#000000" name="regid">
                                </div>

                            </div>
                        </div>
                        <div class="col-lg-5">
                            <div class="form-group">
                                <label class="col-lg-4 control-label">Session: </label>
                                <div class="col-lg-6">
                                    <?php

                                    $iniyear = 2015;
                                    $finalyear = substr($_SESSION['corntsession'], 5);

                                    ?>
                                    <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                        <option value="<?php echo $_SESSION['corntsession'] ?>">
                                            <?php echo $_SESSION['corntsession'] ?></option>
                                        <?php
                                        while ($iniyear <= $finalyear) {
                                            $addyear = $iniyear + 1;

                                            echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                            $iniyear++;
                                        }

                                        ?>

                                    </select>
                                </div>

                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label class="col-lg-4 control-label"></label>
                                <div class="col-lg-6">
                                    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                </div>

                            </div>
                        </div>


                    </form>
                </div>
                <hr class="separator" />
                <div class="row">

                    <div class="col-md-1">
                    </div>
                    <div class="col-md-10">

                        <?php if (isset($_POST["submit"])) { ?>
                            <?php

                            ?>
                            <section class="panel panel-success">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>

                                    <h2 class="panel-title">e-Exam Results</h2>
                                </header>
                                <div class="panel-body">

                                    <div class="col-md-1">
                                    </div>
                                    <div class="col-md-10">

                                        <?php

                                        $regid = $_POST["regid"];
                                        $getsession = $_POST["getsession"];
                                        $_SESSION['regid'] = $regid;
                                        $_SESSION['getsession'] = $getsession;

                                        $sumunits = $sumgp = $point = $cgpa = 0;
                                        //$grade="";
                                        $sql = "SELECT * FROM stdprofile WHERE regid = '$regid'";
                                        $result = $conn2->query($sql);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $studept = $row["Deptcode"];
                                                $stdid = $row["stdid"];
                                                echo "<div class='row'>";
                                                echo "<div class='col-lg-9'>";
                                                echo "Matric No:" . $row['regid'];
                                                echo "<br>";
                                                $names = $row["firstname"] . " " . $row["othername"] . " " . $row["surname"];
                                                $names = strtolower($names);
                                                $names = ucwords($names);
                                                echo "Name:  " . $names;
                                                echo "<br>";
                                                echo "Session:  " . $getsession;
                                                echo "</div>";
                                                echo "<div class='col-lg-3' style='text-align:right'>";
                                        ?>
                                                <figure class="profile-picture">
                                                    <?php
                                                    $sql = "SELECT imageType, imageData FROM " . $studept . " WHERE stdid='$stdid'";
                                                    $sth = $conn10->query($sql);
                                                    $result2 = mysqli_fetch_array($sth);

                                                    echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['imageData']) . '"  width="100" height="100"/>';
                                                    ?>
                                                </figure>
                                            <?php
                                                echo "</div>";
                                                echo "</div>";
                                            }
                                        }


                                        if ($getsession == "2017/2018" || $getsession == "2018/2019") {
                                            $sql = "SELECT * FROM e_exam_results WHERE matno = '$regid' AND session_regist = '$getsession' ORDER BY ccode";
                                        } else {
                                            $gettable = "e_exam_results_" . str_replace("/", "_", $getsession);
                                            $sql = "SELECT * FROM " . $gettable . " WHERE matno = '$regid' AND session_regist = '$getsession' ORDER BY ccode";
                                        }


                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                            ?>
                                            <table class="table mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Session</th>
                                                        <th>CA</th>
                                                        <th>Exam</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo "<tr><td>{$row['ccode']}</td><td>{$row['ctitle']}</td><td>{$row['unit']}</td><td>{$row['Semester']}</td><td>{$row['session_regist']}</td><td>{$row['ca']}</td><td>{$row['exam']}</td></tr>\n";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <br />
                                        <?php

                                        }

                                        ?>

                                        <div style="text-align: right">
                                            <input type="button" class='btn btn-info btn-sm' value="Print" onclick="printme()">
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                    </div>

                                </div>
                            </section>
                        <?php } ?>
                    </div>
                    <div class="col-md-1">
                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>

    <!--Print Start-->
    <div id="printablediv" style="width: 100%; height: 200px;" hidden="hidden">
        <center><strong>
                <h3>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</h3>
            </strong></center>
        <center><strong>
                <h4>STUDENT'S ACADEMIC RECORD</h4>
            </strong></center>

        <?php

        $regid = $_SESSION["regid"];
        $getsession = $_SESSION["getsession"];
        //$dept = $_SESSION['deptcode'];
        $sumunits = $sumgp = $point = $cgpa = 0;
        //$grade="";
        $sql = "SELECT * FROM stdprofile WHERE regid = '$regid'";
        $result = $conn2->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $studept = $row["Deptcode"];
                $stdid = $row["stdid"];
                echo "<div class='row'>";
                echo "<div class='col-lg-9'>";
                echo "Matric No:" . $row['regid'];
                echo "<br>";
                $names = $row["firstname"] . " " . $row["othername"] . " " . $row["surname"];
                $names = strtolower($names);
                $names = ucwords($names);
                echo "Name:  " . $names;
                echo "<br>";
                echo "Session:  " . $getsession;
                echo "</div>";
                echo "<div class='col-lg-3' style='text-align:right'>";
        ?>
                <figure class="profile-picture">
                    <?php
                    $sql = "SELECT imageType, imageData FROM " . $studept . " WHERE stdid='$stdid'";
                    $sth = $conn10->query($sql);
                    $result2 = mysqli_fetch_array($sth);

                    echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['imageData']) . '"  width="100" height="100"/>';
                    ?>
                </figure>
            <?php
                echo "</div>";
                echo "</div>";
            }
        }


        if ($getsession == "2017/2018" || $getsession == "2018/2019") {
            $sql = "SELECT * FROM e_exam_results WHERE matno = '$regid' AND session_regist = '$getsession' ORDER BY ccode";
        } else {
            $gettable = "e_exam_results_" . str_replace("/", "_", $getsession);
            $sql = "SELECT * FROM " . $gettable . " WHERE matno = '$regid' AND session_regist = '$getsession' ORDER BY ccode";
        }
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            ?>
            <table style="border-collapse: collapse; width: 100%;">
                <thead>
                    <tr>
                        <th style="text-align: left; border: 1px solid #ccc;">Course Code</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Course Title</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Unit</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Semester</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Session</th>
                        <th style="text-align: left; border: 1px solid #ccc;">CA</th>
                        <th style="text-align: left; border: 1px solid #ccc;">Exam</th>
                    </tr>
                </thead>
                <tbody>


                    <?php
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr><td style='text-align: left; border: 1px solid #ccc;'>{$row['ccode']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['ctitle']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['unit']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['Semester']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['session_regist']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['ca']}</td><td style='text-align: left; border: 1px solid #ccc;'>{$row['exam']}</td></tr>\n";
                    }
                    ?>
                </tbody>
            </table>
            <br />
        <?php

        }

        ?>

    </div>

    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
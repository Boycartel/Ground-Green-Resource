<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_alocation'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Results and Profile Approval</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results and Profile Approval
                            </li>

                            <li class="active">
                                <strong>Uploaded Results</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }

                    if (isset($_POST["view"])) {
                        $CCode = $_POST['id'];
                        $_SESSION['CCode'] = $CCode;
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            <?php echo $_SESSION['CCode'] . ", " . $_SESSION['resultsession'] ?> Session
                        </div>
                        <div class="panel-body">

                            <?php

                            $cursession = $_SESSION['resultsession'];
                            $dept = $_SESSION['deptcode'];
                            $staffid = $_SESSION['staffid'];
                            //if(!isset($_POST["submitApr"]) && !isset($_POST["submitCanc"])){


                            /* $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $curriculum = $row["curriculum"];
                                        }
                                    } */



                            $approval = "NO";
                            $CCode = $_SESSION['CCode'];

                            if (isset($_POST["submitApr"])) {
                                $CCode = $_SESSION['CCode'];
                                $credit = 0;
                                $C_title = "XXXX";


                                $GrPoint = 0;
                                $dbsession = str_replace("/", "_", $cursession);
                                $sql = "SELECT * FROM raw_results_" . $dbsession . " WHERE CCode = '$CCode' ORDER BY Regn1";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $Regn1 = $row["Regn1"];
                                        $status1 = $row["status1"];
                                        $stu_dept = strtolower($row["stu_dept"]);
                                        $dept_db = $_SESSION['deptdb'] . $stu_dept;
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        $sql2 = "SELECT * FROM std_data_view WHERE matric_no = '$Regn1'";
                                        $result2 = $conn2->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $Deptcode = $row2["dept_code"];
                                                $curriculum = $row2["curriculum"];
                                            }
                                        }

                                        if ($curriculum == "OLD") {
                                            $curri2 = "";
                                        } else {
                                            $curri2 = "_" . $curri;
                                        }

                                        $sql2 = "SELECT * FROM gencourses" . $curri2 . " WHERE C_codding = '$CCode'";
                                        $result2 = $conn_stu->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $credit = $row2["credit"];
                                                $C_title = $row2["C_title"];
                                            }
                                        }

                                        /* if (empty($row["CA"])) {
                                            $repairCA = 0;
                                        } else {
                                            $repairCA = $row["CA"];
                                        }
                                        if ($row["Exam"]) {
                                            $repairEXAM = 0;
                                        } else {
                                            $repairEXAM = $row["Exam"];
                                        } */

                                        $repairCA = $row["CA"];
                                        $repairEXAM = $row["Exam"];
                                        $repairTOTAL = $repairCA + $repairEXAM;



                                        if ($_SESSION['InstType'] == "University") {
                                            if ($repairTOTAL >= 70) {
                                                $sngReCGP = $credit * 5;
                                                $semgrade = "A";
                                            } elseif ($repairTOTAL >= 60) {
                                                $sngReCGP = $credit * 4;
                                                $semgrade = "B";
                                            } elseif ($repairTOTAL >= 50) {
                                                $sngReCGP = $credit * 3;
                                                $semgrade = "C";
                                            } elseif ($repairTOTAL >= 45) {
                                                $sngReCGP = $credit * 2;
                                                $semgrade = "D";
                                            } elseif ($repairTOTAL >= 40) {
                                                $sngReCGP = $credit * 1;
                                                $semgrade = "E";
                                            } else {
                                                $sngReCGP = $credit * 0;
                                                $semgrade = "F";
                                            }
                                        } elseif (
                                            $_SESSION['InstType'] == "Polytechnic"
                                        ) {


                                            if ($row['CA'] + $row['Exam'] >= 75) {
                                                $sngReCGP = $credit * 4;
                                                $semgrade = "A";
                                            } elseif (
                                                $row['CA'] + $row['Exam'] >= 70
                                            ) {
                                                $sngReCGP = $credit * 3.5;
                                                $semgrade = "AB";
                                            } elseif (
                                                $row['CA'] + $row['Exam'] >= 65
                                            ) {
                                                $sngReCGP = $credit * 3.25;
                                                $semgrade = "B";
                                            } elseif (
                                                $row['CA'] + $row['Exam'] >= 60
                                            ) {
                                                $sngReCGP = $credit * 3;
                                                $semgrade = "BC";
                                            } elseif (
                                                $row['CA'] + $row['Exam'] >= 55
                                            ) {
                                                $sngReCGP = $credit * 2.75;
                                                $semgrade = "C";
                                            } elseif (
                                                $row['CA'] + $row['Exam'] >= 50
                                            ) {
                                                $sngReCGP = $credit * 2.5;
                                                $semgrade = "CD";
                                            } elseif (
                                                $row['CA'] + $row['Exam'] >= 45
                                            ) {
                                                $sngReCGP = $credit * 2.25;
                                                $semgrade = "D";
                                            } elseif (
                                                $row['CA'] + $row['Exam'] >= 40
                                            ) {
                                                $sngReCGP = $credit * 2;
                                                $semgrade = "E";
                                            } else {
                                                $sngReCGP = $credit * 0;
                                                $semgrade = "F";
                                            }
                                        } else {
                                        }



                                        $deptcorreg = "correg_" . $dbsession;

                                        if ($status1 == "D" || $status1 == "S" || $status1 == "W" || $status1 == "I" || $status1 == "N") {
                                            $sql3 = "SELECT * FROM absent_students WHERE CCode = '$CCode' AND session1 = '$cursession' AND matric_no = '$Regn1'";
                                            $result3 = $conn_stu->query($sql3);
                                            if ($result3->num_rows == 0) {
                                                $sql2 = "INSERT INTO absent_students(CCode, session1, CA, Exam, status1, matric_no)VALUES('$CCode', '$cursession', '$repairCA', '$repairEXAM', '$status1', '$Regn1')";
                                                $result2 = $conn_stu->query($sql2);
                                            }

                                            $sql3 = "DELETE FROM " . $deptcorreg . " WHERE CCode = '$CCode' AND Regn1 ='$Regn1'";
                                            $result3 = $conn_stu->query($sql3);
                                        } else {
                                            $sql2 = "UPDATE " . $deptcorreg . " SET CA ='$repairCA', Exam ='$repairEXAM', CUnit ='$credit', grade ='$semgrade', point ='$sngReCGP' WHERE CCode = '$CCode' AND Regn1 ='$Regn1'";
                                            $result2 = $conn_stu->query($sql2);
                                        }
                                        $conn_stu->close();
                                    }
                                }

                                $sql2 = "UPDATE submitted_results_list SET approval ='YES' WHERE CCode = '$CCode' AND Session1 = '$cursession'";
                                $result2 = $conn->query($sql2);
                            }

                            if (isset($_POST["submitCanc"])) {
                                $CCode = $_SESSION['CCode'];
                                $sql2 = "UPDATE submitted_results_list SET approval ='NO' WHERE CCode = '$CCode' AND Session1 = '$cursession'";
                                $result2 = $conn->query($sql2);

                                $dbsession = str_replace("/", "_", $cursession);
                                $sql = "SELECT * FROM raw_results_" . $dbsession . " WHERE CCode = '$CCode' ORDER BY Regn1";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $Regn1 = $row["Regn1"];
                                        $status1 = $row["status1"];
                                        $stu_dept = strtolower($row["stu_dept"]);
                                        $dept_db = $_SESSION['deptdb'] . strtolower($stu_dept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        $sql3 = "DELETE FROM absent_students WHERE CCode = '$CCode' AND matric_no ='$Regn1' AND session1 = '$cursession'";
                                        $result3 = $conn_stu->query($sql3);

                                        $deptcorreg = "correg_" . $dbsession;

                                        if ($status1 == "D" || $status1 == "S" || $status1 == "W" || $status1 == "I" || $status1 == "N") {
                                            $sql = "SELECT * FROM  " . $deptcorreg . " WHERE CCode = '$CCode' AND Regn1 ='$Regn1'";
                                            $result = $conn_stu->query($sql);
                                            if ($result->num_rows == 0) {
                                                $sql2 = "INSERT INTO " . $deptcorreg . "(CCode, Regn1, CA, Exam, grade, point)VALUES('$CCode', '$Regn1', '0', '0', 'F', '0')";
                                                $result2 = $conn_stu->query($sql2);
                                            }
                                        }

                                        $sql2 = "UPDATE " . $deptcorreg . " SET CA ='0', Exam ='0', grade ='F', point ='0' WHERE CCode = '$CCode' AND Regn1 ='$Regn1'";
                                        $result2 = $conn_stu->query($sql2);

                                        $conn_stu->close();
                                    }
                                }
                            }

                            $sql2 = "SELECT * FROM submitted_results_list WHERE CCode = '$CCode'";
                            $result2 = $conn->query($sql2);
                            if ($result2->num_rows > 0) {
                                while ($row2 = $result2->fetch_assoc()) {
                                    $approval = $row2["approval"];
                                }
                            }
                            ?>
                            <div class="row" style="padding-left: 3em">
                                <table class="table table-bordered table-striped mb-none">
                                    <thead style='text-align:center'>
                                        <tr>
                                            <th>SNo</th>
                                            <th>Reg. No </th>
                                            <th>Name</th>
                                            <?php if ($_SESSION['instcode'] !== "FPB") { ?>
                                                <th> CA</th>
                                                <th>Exam</th>
                                            <?php } ?>
                                            <th>Total</th>
                                            <th>Grade</th>
                                            <th>Status</th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        <?php
                                        $SNo = 0;
                                        $countA = $countAB = $countB = $countBC = $countC = $countCD = $countD = $countE = $countF = 0;
                                        $dbsession = str_replace("/", "_", $cursession);
                                        $sql = "SELECT * FROM raw_results_" . $dbsession . " WHERE CCode = '$CCode' ORDER BY Regn1";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $SNo++;
                                                $CCode = $row["CCode"];
                                                $Regn1 = $row["Regn1"];
                                                $CA = $row["CA"];
                                                $Exam = $row["Exam"];
                                                $name1 = $row["name1"];
                                                $status1 = $row["status1"];

                                                $total1 = $CA + $Exam;


                                                if ($_SESSION['InstType'] == "University") {
                                                    if ($total1 >= 70) {
                                                        $semgrade = "A";
                                                        $countA++;
                                                    } elseif ($total1 >= 60) {
                                                        $semgrade = "B";
                                                        $countB++;
                                                    } elseif ($total1 >= 50) {
                                                        $semgrade = "C";
                                                        $countC++;
                                                    } elseif ($total1 >= 45) {
                                                        $semgrade = "D";
                                                        $countD++;
                                                    } elseif ($total1 >= 40) {
                                                        $semgrade = "E";
                                                        $countE++;
                                                    } else {
                                                        $semgrade = "F";
                                                        $countF++;
                                                    }
                                                } elseif (
                                                    $_SESSION['InstType'] == "Polytechnic"
                                                ) {


                                                    if ($row['CA'] + $row['Exam'] >= 75) {
                                                        $countA++;
                                                        $semgrade = "A";
                                                    } elseif (
                                                        $row['CA'] + $row['Exam'] >= 70
                                                    ) {
                                                        $countAB++;
                                                        $semgrade = "AB";
                                                    } elseif (
                                                        $row['CA'] + $row['Exam'] >= 65
                                                    ) {
                                                        $countB++;
                                                        $semgrade = "B";
                                                    } elseif (
                                                        $row['CA'] + $row['Exam'] >= 60
                                                    ) {
                                                        $countBC++;
                                                        $semgrade = "BC";
                                                    } elseif (
                                                        $row['CA'] + $row['Exam'] >= 55
                                                    ) {
                                                        $countC++;
                                                        $semgrade = "C";
                                                    } elseif (
                                                        $row['CA'] + $row['Exam'] >= 50
                                                    ) {
                                                        $countCD++;
                                                        $semgrade = "CD";
                                                    } elseif (
                                                        $row['CA'] + $row['Exam'] >= 45
                                                    ) {
                                                        $countD++;
                                                        $semgrade = "D";
                                                    } elseif (
                                                        $row['CA'] + $row['Exam'] >= 40
                                                    ) {
                                                        $countE++;
                                                        $semgrade = "E";
                                                    } else {
                                                        $countF++;
                                                        $semgrade = "F";
                                                    }
                                                } else {
                                                }


                                                echo "<tr><td>$SNo</td><td>$Regn1 </td><td>$name1</td>";
                                                if ($_SESSION['instcode'] !== "FPB") {
                                                    echo "<td> $CA</td><td>$Exam</td>";
                                                }
                                                echo "<td>$total1</td><td>$semgrade</td><td>$status1</td></tr>";
                                            }
                                        }


                                        ?>
                                    </tbody>
                                </table>
                                <br><br>
                                <h2>SUMMARY</h2>
                                <table class="table-bordered table-striped mb-none">
                                    <thead>
                                        <tr>
                                            <th>Grade</th>
                                            <th>Number</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($_SESSION['InstType'] == "University") { ?>
                                            <tr>
                                                <td style="text-align: center">A</td>
                                                <td style="text-align: center"><?php echo $countA ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">B</td>
                                                <td style="text-align: center"><?php echo $countB ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">C</td>
                                                <td style="text-align: center"><?php echo $countC ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">D</td>
                                                <td style="text-align: center"><?php echo $countD ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">E</td>
                                                <td style="text-align: center"><?php echo $countE ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">F</td>
                                                <td style="text-align: center"><?php echo $countF ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">Total</td>
                                                <td style="text-align: center">
                                                    <?php echo $countA + $countB + $countC + $countD + $countE + $countF ?>
                                                </td>
                                            </tr>
                                        <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                            <tr>
                                                <td style="text-align: center">A</td>
                                                <td style="text-align: center"><?php echo $countA ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">AB</td>
                                                <td style="text-align: center"><?php echo $countAB ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">B</td>
                                                <td style="text-align: center"><?php echo $countB ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">BC</td>
                                                <td style="text-align: center"><?php echo $countBC ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">C</td>
                                                <td style="text-align: center"><?php echo $countC ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">CD</td>
                                                <td style="text-align: center"><?php echo $countCD ?></td>
                                            </tr>

                                            <tr>
                                                <td style="text-align: center">D</td>
                                                <td style="text-align: center"><?php echo $countD ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">E</td>
                                                <td style="text-align: center"><?php echo $countE ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">F</td>
                                                <td style="text-align: center"><?php echo $countF ?></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align: center">Total</td>
                                                <td style="text-align: center">
                                                    <?php echo $countA + $countAB + $countB + $countBC + $countC + $countCD + $countD + $countE + $countF ?>
                                                </td>
                                            </tr>
                                        <?php } else { ?>

                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <form class="form-horizontal form-bordered" method="post">
                                <div class="row" style="padding: 3em; text-align: right">
                                    <?php if ($approval == "YES") { ?>
                                        <button type="submit" name="submitCanc" class="btn btn-success btn-sm">Cancel
                                            Approval</button>

                                    <?php } else { ?>
                                        <button type="submit" name="submitApr" class="btn btn-primary btn-sm">Approve</button>
                                    <?php } ?>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php
                    $conn->close();
                    $conn2->close();
                    //$conn_stu->close();
                    ?>


                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
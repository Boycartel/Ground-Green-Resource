<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>
<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--To Prevent Backward -->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>
<?php
$regid = $_SESSION["regid"];
$dept = $_SESSION['deptcode'];
$curtsession = $_SESSION['corntsession'];
$names = $_SESSION['names'];



$sumunits = $sumgp = $point = $cgpa = 0;
$grade = "";

error_reporting(E_ERROR);

date_default_timezone_set("Africa/Lagos");
$prestimefull =  date("h:i:sa");

$prestime = date("ha");
$preday = date("l");



$sql = "SELECT * FROM " . $dept . "_correg WHERE regn1 = '$regid' ORDER BY SessionRegis, SemTaken";
$result = $conn->query($sql);

if ($result->num_rows > 0) {


    while ($row = $result->fetch_assoc()) {
        if ($row['CA'] + $row['Exam'] >= 70) {
            $point = 5;
            $grade = "A";
        } elseif ($row['CA'] + $row['Exam'] >= 60) {
            $point = 4;
            $grade = "B";
        } elseif ($row['CA'] + $row['Exam'] >= 50) {
            $point = 3;
            $grade = "C";
        } elseif ($row['CA'] + $row['Exam'] >= 45) {
            $point = 2;
            $grade = "D";
        } elseif ($row['CA'] + $row['Exam'] >= 40) {
            $point = 1;
            $grade = "E";
        } elseif ($row['CA'] + $row['Exam'] <= 39.95) {
            $point = 0;
            $grade = "F";
        }


        $sumunits += $row['CUnit'];

        $sumgp += $row['CUnit'] * $point;
    }
} else {
    $sumunits = 0;
}

$diff_outstand = 0;
$sql = "SELECT * FROM " . $dept . "_diff_outs_courses WHERE Regn1 = '$regid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $diff_outstand += $row['CUnit'];
    }
}


?>

<body>
    <section class="body">

        <!-- start: header -->
        <?php include_once 'includes/header2_pg.php'; ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/pg_aside_menu.php'; ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Dashboard</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li><span>Dashboard</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">
                    <div class="col-md-4">
                        <section class="panel panel-featured-left panel-featured-primary">
                            <div class="panel-body">
                                <div class="widget-summary">
                                    <div class="widget-summary-col widget-summary-col-icon">
                                        <div class="summary-icon bg-primary">
                                            <?php if ($sumunits <> 0) echo number_format((float)$sumgp / $sumunits, 2, '.', '') ?>
                                        </div>
                                    </div>
                                    <div class="widget-summary-col">
                                        <div class="summary">
                                            <h4 class="title">CGPA</h4>

                                        </div>
                                        <div class="summary-footer">
                                            <a class="text-muted text-uppercase" href="stu_results.php">(view all)</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="col-md-4">
                        <section class="panel panel-featured-left panel-featured-secondary">
                            <div class="panel-body">
                                <div class="widget-summary">
                                    <div class="widget-summary-col widget-summary-col-icon">
                                        <div class="summary-icon bg-secondary">
                                            <?php echo $diff_outstand ?>
                                        </div>
                                    </div>
                                    <div class="widget-summary-col">
                                        <div class="summary">
                                            <h4 class="title">Diff/Outstanding Courses</h4>

                                        </div>
                                        <div class="summary-footer">
                                            <a class="text-muted text-uppercase" href="outstanding_course.php">(view
                                                all)</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="col-md-4">
                        <section class="panel panel-featured-left panel-featured-quartenary">
                            <div class="panel-body">
                                <div class="widget-summary">
                                    <div class="widget-summary-col widget-summary-col-icon">
                                        <div class="summary-icon bg-quartenary">
                                            <i class="fa fa-user"></i>
                                        </div>
                                    </div>
                                    <div class="widget-summary-col">
                                        <div class="summary">
                                            <strong>email:</strong>
                                            <?php echo $_SESSION['email'] ?><br><strong>Dept:</strong>
                                            <?php echo $_SESSION['deptname'] ?>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <div>
                    <div class="col-md-8">
                        <section class="panel panel-info">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title"><?php echo $_SESSION['corntsession'] . " ";  ?> Academic
                                    Calendar</h2>
                            </header>
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table table-striped mb-none">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Semester</th>
                                                <th>Activity</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            $sql = "SELECT * FROM acad_calendar";
                                            $result = $conn->query($sql);

                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $date1 = $row["date1"];
                                                    $semester = $row["semester"];
                                                    $activity1 = $row["activity1"];
                                                    echo "<tr><td>$date1</td><td>$semester</td><td>$activity1</td></tr>\n";
                                                }
                                            }

                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="col-md-4">

                        <section class="panel panel-success">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">OUR VISION</h2>
                            </header>
                            <div class="panel-body">
                                <p>To become a solution centre in technology, research and development for the promotion
                                    of
                                    self-reliance, creativity and innovation in addressing the challenges of the NA, the
                                    military as well as the nation.</p>
                            </div>
                        </section>

                        <section class="panel panel-success">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">OUR MISSION</h2>
                            </header>
                            <div class="panel-body">
                                <p>To develop highly skilled military and civilian manpower with distinctive competence
                                    capable of providing technological solutions to the problems of the NA, the military
                                    and the nation.
                                </p>
                            </div>
                        </section>
                    </div>
                </div>


                <!-- end: page -->
            </section>
        </div>


    </section>

    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>



</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_view'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--Print Div-->
    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Sessional CGPA</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Sessional CGPA</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Sessional CGPA
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <div id="printableArea">
                                    <?php
                                    if (isset($_POST["view"])) {
                                        $regid = $_POST["id"];
                                        $_SESSION["sno"] = $regid;
                                    } else {
                                        $regid = $_SESSION["sno"];
                                    }


                                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                    if ($conn2->connect_error) {
                                        die("Connection failed: " . $conn2->connect_error);
                                    }


                                    //$dept = $_SESSION['deptcode'];
                                    $sumunits = $sumgp = $point = $cgpa = 0;
                                    $grade = "";
                                    $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                    $result = $conn2->query($sql);

                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            //$_SESSION['studeptcode']= $row['DeptName'];
                                            $studeptcode = strtolower($row['dept_code']);
                                            $stdid = $row['stdid'];
                                            echo "<div class='row'>";
                                            echo "<div class='col-lg-9'>";
                                            echo "Matric No:" . $row['matric_no'];
                                            echo "<br>";
                                            $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                            $names = strtolower($names);
                                            $names = ucwords($names);
                                            echo "Name:  " . $names;
                                            echo "</div>";
                                            echo "<div class='col-lg-3' style='text-align:right'>";
                                    ?>
                                    <figure class="profile-picture">
                                        <?php
                                                $matpassport = str_replace("/", "_", $regid);
                                                echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='100'>";


                                                ?>
                                    </figure>

                                    <?php
                                            echo "</div>";
                                            echo "</div>";
                                        }
                                    }
                                    //$studeptcode="aet";
                                    //echo "Yes";
                                    $norec = "YES";

                                    ?>
                                    <table class="table table-bordered" cellspacing="0" rules="all" border="1">
                                        <thead>
                                            <tr>
                                                <th>Course Code</th>
                                                <th>Course Title</th>
                                                <th>Unit</th>
                                                <th>Semester</th>
                                                <th>Session</th>
                                                <th>Grade</th>
                                            </tr>
                                        </thead>
                                        <tbody>


                                            <?php
                                            $resultsession = $_SESSION['resultsession'];
                                            $FinalYear = substr($resultsession, 0, 4);
                                            $StartYear = substr($regid, 0, 4);
                                            for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                $getstuSession2 = $x . "/" . ($x + 1);


                                                $dept_db = $_SESSION['deptdb'] . strtolower($studeptcode);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                $StuCurSess = str_ireplace("/", "_", $getstuSession2);
                                                if ($getstuSession2 < "2014/2015") {
                                                    $deptcorreg = "correg";
                                                } else {
                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                }

                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE regn1 = '$regid' AND SessionRegis = '$getstuSession2' ORDER BY SemTaken";
                                                $result = $conn_stu->query($sql);

                                                if ($result->num_rows > 0) {
                                                    // output data of each row
                                                    $norec = "NO";
                                                    while ($row = $result->fetch_assoc()) {

                                                        $gpoint = $row['point'];
                                                        $grade = $row['grade'];


                                                        echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['SessionRegis']}</td><td>$grade</td></tr>\n";
                                                        $sumunits += $row['CUnit'];

                                                        $sumgp += $row['CUnit'] * $gpoint;
                                                    }
                                                }
                                                $conn_stu->close();
                                            }
                                            ?>
                                        </tbody>
                                    </table>

                                    <?php

                                    $conn2->close();

                                    echo "<center>";
                                    echo "Total Credit Units =   " . $sumunits . "<br>";
                                    echo "Total Grade Points =  " . $sumgp . "<br>";
                                    if ($norec == "YES") {
                                        echo "CGPA =   "  . number_format(0, 2, '.', '');
                                    } else {
                                        echo "CGPA =   "  . number_format((float)$sumgp / $sumunits, 2, '.', '');
                                    }
                                    ?>
                                    <br>
                                </div>
                                <div style="text-align: right">
                                    <input type="button" onclick="printDiv('printableArea')" value="print"
                                        class="btn-success" />
                                </div>

                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

</body>

</html>
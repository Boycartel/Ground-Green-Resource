<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    $user1 = $_SESSION['staffid'];
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>


                            <li>APU</li>
                            <li>PG Students Record</li>
                            <li class="active">
                                <strong>By Department and State of Origin</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    if (isset($_POST["submit"])) {
                        if (!$_POST["getsession"]) {
                            $getsession = $_SESSION["getsession"];
                        }
                    }
                    ?>
                    <?php
                    $getsession = $_SESSION["getsession"];
                    $GetTitle = "Students Count by Department(" . $getsession . ")";
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            <?php echo $GetTitle ?>
                        </div>
                        <div class="panel-body">


                            <!-- start: page -->
                            <div class="row">

                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="form-group">
                                        <label class="control-label col-lg-3" style="font-size: larger">Session</label>
                                        <div class="col-lg-4">
                                            <?php if (!isset($_POST["submit"])) { ?>
                                                <?php
                                                $iniyear = 2018;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>
                                            <?php } else { ?>
                                                <?php echo $_SESSION["getsession"] ?>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-5">


                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-lg-2">
                                        </div>
                                        <div class="col-lg-8">
                                            <?php
                                            $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                            ?>
                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th>Select</th>
                                                            <th>Dept Code</th>
                                                            <th>Department</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["sn"];
                                                            $DeptCode = $row["DeptCode"];
                                                            $DeptName = $row['DeptName'];
                                                            echo "<tr>
                                    <td><input type='checkbox' name='chosen1c[" . $id . "]' value='" . $id . "'/></td>
                                    <td>
                                    <label id='deptcode' name='deptcode[" . $id . "]'>$DeptCode</label>
                                    <input type='hidden' id='deptcode' name='deptcode[" . $id . "]' value='" . $DeptCode . "'/>
                                    </td>
                                    <td>
                                    <label id='depttitle' name='depttitle[" . $id . "]'>$DeptName</label>
                                    <input type='hidden' id='depttitle' name='depttitle[" . $id . "]' value='" . $DeptName . "'/>
                                    </td>
                                    
                                    </tr>\n";
                                                        }
                                                        ?>

                                                    </tbody>
                                                </table>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-2">
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        <div class="col-lg-2">
                                        </div>
                                        <div class="col-lg-8" style="text-align: right">
                                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                        <div class="col-lg-2">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">
                                <?php

                                ?>
                                <?php if (!empty($_POST["chosen1c"])) { ?>
                                    <?php
                                    set_time_limit(500);
                                    error_reporting(E_ERROR);

                                    $sql = "DELETE FROM dept_select WHERE user1='$user1'";
                                    $result = $conn2->query($sql);
                                    foreach ($_POST["chosen1c"] as $key => $value) {

                                        $deptcode = $_POST["deptcode"][$key];
                                        $depttitle = $_POST["depttitle"][$key];

                                        $sql = "INSERT INTO dept_select (deptcode, depttitle, user1) VALUES ('$deptcode', '$depttitle', '$user1')";
                                        $result = $conn2->query($sql);
                                    }
                                    if ($_POST["getsession"]) {
                                        $getsession = $_POST["getsession"];
                                        $_SESSION["getsession"] = $getsession;
                                        $sql = "DELETE FROM dap_stu_dept_state WHERE user1='$user1'";
                                        $result = $conn2->query($sql);
                                    } else {
                                        $getsession = $_SESSION["getsession"];
                                    }

                                    $GetTitle = "Students Count by Department and State of Origin(" . $getsession . ")";

                                    $totmale = $totfemale = $tottotal = 0;
                                    $k = 0;
                                    $sql = "SELECT * FROM states ORDER BY StateCode";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $statecodeArr[$k] = $row["StateCode"];
                                            $statetitleArr[$k] = $row["state"];
                                            $stateM[$k] = 0;
                                            $stateF[$k] = 0;
                                            $k++;
                                        }
                                    }
                                    ?>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Department</th>
                                                    <th>Male</th>
                                                    <th>Female</th>
                                                    <th>Total</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $sql = "SELECT * FROM dept_select WHERE user1='$user1' ORDER BY depttitle";
                                                $result = $conn2->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $DeptCode = $row["deptcode"];
                                                        $DeptName = $row["depttitle"];

                                                        $male = $female = $total = 0;
                                                        //$count100M=$count100F=$count200M=$count200F=$count300M=$count300F=$count400M=$count400F=$count500M=$count500F=$count600M=$count600F=0;
                                                        for ($x = 1; $x <= 37; $x++) {
                                                            $stateM[$x] = 0;
                                                            $stateF[$x] = 0;
                                                        }
                                                        $getdept = strtolower($DeptCode) . "_hod_list";
                                                        $sql2 = "SELECT * FROM " . $getdept . " WHERE Session1 = '$getsession'";
                                                        $result2 = $conn5->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $matricno = $row2["matricno"];
                                                                $matriclen = strlen($matricno);
                                                                if ($matriclen >= 10) {
                                                                    //$StuLevel=$row2["StuLevel"];
                                                                    $sql3 = "SELECT * FROM pgapplication WHERE regid = '$matricno'";
                                                                    $result3 = $conn4->query($sql3);
                                                                    if ($result3->num_rows > 0) {
                                                                        while ($row3 = $result3->fetch_assoc()) {
                                                                            $sex = $row3["sex"];
                                                                            $stateOfOrigin = $row3["stateoforigin"];
                                                                            if ($sex == "M") {
                                                                                $male++;
                                                                                $totmale++;
                                                                                for ($x = 1; $x <= 37; $x++) {
                                                                                    if ($stateOfOrigin == $statecodeArr[$x] || strtoupper($stateOfOrigin) == $statetitleArr[$x]) {
                                                                                        $stateM[$x]++;
                                                                                    }
                                                                                }
                                                                            } elseif ($sex == "F") {
                                                                                $female++;
                                                                                $totfemale++;
                                                                                for ($x = 1; $x <= 37; $x++) {
                                                                                    if ($stateOfOrigin == $statecodeArr[$x] || strtoupper($stateOfOrigin) == $statetitleArr[$x]) {
                                                                                        $stateF[$x]++;
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        $total = $male + $female;
                                                        if ($total > 0) {

                                                            $sql3 = "SELECT * FROM dap_stu_dept_state WHERE deptcode = '$DeptCode' AND user1='$user1'";
                                                            $result3 = $conn2->query($sql3);
                                                            if ($result3->num_rows == 0) {
                                                                $sql2 = "INSERT INTO dap_stu_dept_state (depttitle, nomale, nofemale, total, deptcode, user1) VALUES ('$DeptName', '$male', '$female', '$total', '$DeptCode', '$user1')";
                                                                $result2 = $conn2->query($sql2);
                                                                $nostate = 0;
                                                                for ($x = 1; $x <= 37; $x++) {
                                                                    $getStateM = $statecodeArr[$x] . "m";
                                                                    $getStateF = $statecodeArr[$x] . "f";
                                                                    $statecountM = $stateM[$x];
                                                                    $statecountF = $stateF[$x];
                                                                    $nostate = $nostate + $statecountM + $statecountF;
                                                                    $sql2 = "UPDATE dap_stu_dept_state SET " . $getStateM . "='$statecountM', " . $getStateF . "='$statecountF' WHERE deptcode = '$DeptCode' AND user1='$user1'";
                                                                    $result2 = $conn2->query($sql2);
                                                                }
                                                                $nostate = $total - $nostate;
                                                                $sql2 = "UPDATE dap_stu_dept_state SET no_state='$nostate' WHERE deptcode = '$DeptCode' AND user1='$user1'";
                                                                $result2 = $conn2->query($sql2);
                                                            }
                                                        }
                                                    }
                                                }
                                                $sql3 = "SELECT * FROM dap_stu_dept_state WHERE user1='$user1' ORDER BY depttitle";
                                                $result3 = $conn2->query($sql3);
                                                if ($result3->num_rows > 0) {
                                                    while ($row3 = $result3->fetch_assoc()) {
                                                        $sno++;
                                                        $DeptCode = $row3["deptcode"];
                                                        $DeptName = $row3["depttitle"];
                                                        $male = $row3["nomale"];
                                                        $female = $row3["nofemale"];
                                                        $total = $row3["total"];
                                                        echo "<tr><td>$sno</td><td>$DeptName</td><td>$male</td><td>$female</td>";
                                                        echo "<td>$total</td></tr>\n";
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>

                                <?php } ?>
                                <div class="form-group">
                                    <div class="col-lg-2">
                                    </div>
                                    <div class="col-lg-8" style="text-align: right">
                                        <?php if (!empty($_POST["chosen1c"])) { ?>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <button type="submit" name="conclude" class="btn btn-primary btn-sm">Conclude</button>
                                            </form>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-2">
                                    </div>
                                </div>
                                <?php if (isset($_POST["conclude"])) { ?>

                                    <?php
                                    $totmale = $totfemale = $tottotal = 0;
                                    $k = 0;
                                    $sql = "SELECT * FROM states ORDER BY StateCode";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $statecodeArr[$k] = $row["StateCode"];
                                            $statetitleArr[$k] = $row["state"];
                                            $stateM[$k] = 0;
                                            $stateF[$k] = 0;
                                            $totstateM[$x] = 0;
                                            $totstateF[$x] = 0;
                                            $k++;
                                        }
                                    }

                                    ?>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Department</th>
                                                    <th>Male</th>
                                                    <th>Female</th>
                                                    <?php
                                                    for ($x = 1; $x <= 37; $x++) {
                                                        $stateTArr = $statetitleArr[$x];

                                                        echo "<th>$stateTArr(M)</th>";
                                                        echo "<th>$stateTArr(F)</th>";
                                                    }
                                                    ?>
                                                    <th>No State</th>
                                                    <th>Total</th>
                                                    <th>Dept Code</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $male = $female = $total = 0;
                                                for ($x = 1; $x <= 37; $x++) {
                                                    $stateM[$x] = 0;
                                                    $stateF[$x] = 0;
                                                }
                                                $sql = "SELECT * FROM dap_stu_dept_state WHERE user1='$user1' ORDER BY depttitle";
                                                $result = $conn2->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $DeptCode = $row["deptcode"];
                                                        $DeptName = $row["depttitle"];
                                                        $male = $row["nomale"];
                                                        $female = $row["nofemale"];
                                                        $no_state = $row["no_state"];
                                                        echo "<tr><td>$sno</td><td>$DeptName</td><td>$male</td><td>$female</td>";
                                                        for ($x = 1; $x <= 37; $x++) {
                                                            $stateC = $statecodeArr[$x];
                                                            $stateMx = $row[$stateC . "m"];
                                                            $stateFx = $row[$stateC . "f"];

                                                            echo "<td>$stateMx</td><td>$stateFx</td>";
                                                        }

                                                        $total = $row["total"];
                                                        $totmale = $totmale + $male;
                                                        $totfemale = $totfemale + $female;

                                                        echo "<td>$no_state</td><td>$total</td><td>$DeptCode</td><td>
                                                <form action='dap_stu_list.php' method='post'>
                                                    <input type='hidden' value='$DeptCode' name='id'>
                                                    <input type='hidden' value='yesdept' name='deptstate'>
                                                    <input type='hidden' value='$getsession' name='mysession'>
                                                    <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                                </form>
                                                </td>
                                                    
                                                </tr>\n";
                                                    }
                                                }

                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <br><br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                    </div>

                                    <?php
                                    $sql = "DELETE FROM dap_stu_dept_state WHERE user1='$user1'";
                                    $result = $conn2->query($sql);
                                    ?>
                                <?php } ?>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
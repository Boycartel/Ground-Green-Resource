<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <style>
    table,
    th,
    td {
        border: 1px solid black;
        padding-left: 1em;
        padding-right: 1em
    }

    table {
        border-collapse: collapse;
    }
    </style>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Change Department</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Change Department
                            </li>

                            <li class="active">
                                <strong>New Students</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Change Department
                        </div>
                        <div class="panel-body">

                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                            if ($conn2->connect_error) {
                                die("Connection failed: " . $conn2->connect_error);
                            }
                            $msg = "";
                            $success_upl = "no";
                            $cursession = $_SESSION['corntsession'];
                            $prevsession = $_SESSION['prevsession'];
                            $staffid = $_SESSION['staffid'];


                            if (isset($_POST["upfile"])) {
                                $sql = "DELETE FROM change_dept_new";
                                $result = $conn->query($sql);

                                set_time_limit(500);
                                error_reporting(E_ERROR);

                                $filename = $_FILES["uploaded"]["tmp_name"];

                                $file_ext = strtolower(end(explode('.', $_FILES['uploaded']['name'])));

                                if ($file_ext == "csv") {
                                    //if($_FILES['uploaded']['name'] == $ccode.'.csv'){
                                    if ($_FILES["uploaded"]["size"] > 0) {
                                        $file = fopen($filename, "r");
                                        //$sql_data = "SELECT * FROM prod_list_1 ";
                                        $count = 0;
                                        while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                            $count++;
                                            if ($count > 1) {
                                                $Row0 = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                                $Row1 = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                                $Row2 = filter_var($Row[2], FILTER_SANITIZE_STRING);

                                                $sql2 = "INSERT INTO change_dept_new(mat_no, dept, level)VALUES('$Row0', '$Row1', '$Row2')";
                                                $result2 = $conn->query($sql2);
                                            }
                                        }
                                        fclose($file);

                                        $success_upl = "yes";
                                    } else
                                        echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center>';


                                    //}else{
                                    //echo '<center><p style="color:#F00">Invalid File:Please Pick Correct File</p></center>';
                                    //}

                                } else {
                                    echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center></p>';
                                }
                            }

                            //Process
                            if (isset($_POST["submit"])) {
                                $curtsession = $_SESSION['corntsession'];
                                $curYear = substr($_SESSION['corntsession'], 0, 4);
                                $dbsession = str_replace("/", "_", $curtsession);

                                $sql = "SELECT * FROM change_dept_new";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $matric_no = strtoupper($row["mat_no"]);
                                        $dept = strtoupper($row["dept"]);

                                        $level = $row["level"];
                                        $YesNewDept = false;


                                        $sql3 = "SELECT * FROM std_data_view WHERE matric_no = '$matric_no'";
                                        $result3 = $conn2->query($sql3);
                                        if ($result3->num_rows > 0) {
                                            while ($row3 = $result3->fetch_assoc()) {
                                                $Olddept_code = $row3["dept_code"];
                                                $yearAdmt = $row3["YAddmitted"];
                                            }
                                        }

                                        if ($_SESSION['instcode'] == "FPB") {
                                            $sql3 = "SELECT * FROM std_dept WHERE dept = '$dept'";
                                            $result3 = $conn2->query($sql3);
                                            if ($result3->num_rows > 0) {
                                                while ($row3 = $result3->fetch_assoc()) {
                                                    $matri_code = $row3["matri_code"];
                                                }
                                                $YesNewDept = true;
                                            }

                                            $mat_sufix = substr($matric_no, -2);
                                            $new_mat = str_replace($mat_sufix, $matri_code, $matric_no);
                                        } elseif ($_SESSION['instcode'] == "NAUB") {
                                            $sql3 = "SELECT * FROM std_prog_courses WHERE programme_code = '$dept'";
                                            $result3 = $conn2->query($sql3);
                                            if ($result3->num_rows > 0) {
                                                while ($row3 = $result3->fetch_assoc()) {
                                                    $matri_code = $row3["matric_no_code"];
                                                }
                                                $YesNewDept = true;
                                            }
                                            $mat_sufix = substr($matric_no, 0, 3);
                                            $new_mat = str_replace($mat_sufix, $matri_code, $matric_no);
                                        }

                                        $dept_db = $_SESSION['deptdb'] . strtolower($Olddept_code);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        if ($YesNewDept == true) {
                                            $sql2 = "DELETE FROM hod_list WHERE matricno ='$matric_no' AND Session1 = '$curtsession'";
                                            $result2 = $conn_stu->query($sql2);

                                            $sql2 = "DELETE FROM correg_" . $dbsession . " WHERE Regn1 ='$matric_no'";
                                            $result2 = $conn_stu->query($sql2);

                                            for ($i = $yearAdmt; $i <= $curYear; $i++) {
                                                $yearAdmtPlus1 = $yearAdmt + 1;
                                                $getsession = $yearAdmt . "_" . $yearAdmtPlus1;

                                                $sql3 = "SELECT * FROM correg_" . $getsession . " WHERE Regn1 ='$matric_no'";
                                                $result3 = $conn_stu->query($sql3);
                                                if ($result3->num_rows > 0) {
                                                    while ($row3 = $result3->fetch_assoc()) {
                                                        $CCode = $row3["CCode"];
                                                        $CTitle = str_replace("'", "''", $row3["CTitle"]);
                                                        $CNature = $row3["CNature"];
                                                        $CUnit = $row3["CUnit"];
                                                        $SemTaken = $row3["SemTaken"];
                                                        $SessionRegis = $row3["SessionRegis"];
                                                        $CA = $row3["CA"];
                                                        $Exam = $row3["Exam"];
                                                        $prog_gradeid = $row3["grade"];
                                                        $progGrouping2_id = $row3["Grouping2"];
                                                        $Regn1 = $row3["Regn1"];
                                                        $coursecondon = $row3["coursecondon"];
                                                        $noexam = $row3["noexam"];
                                                        $deptOption = $row3["deptOption"];
                                                        $curriculum = $row3["curriculum"];

                                                        $sql4 = "INSERT INTO correg_" . $getsession . "(CCode, CTitle, CNature, CUnit, SemTaken, SessionRegis, CA, Exam, grade, Grouping2, Regn1, coursecondon, noexam, deptOption, curriculum) VALUES ('$CCode', '$CTitle', '$CNature', '$CUnit', '$SemTaken', '$SessionRegis', '$CA', '$Exam', '$grade', '$Grouping2', '$new_mat', '$coursecondon', '$noexam', '$deptOption', '$curriculum')";
                                                        $result4 = $conn_stu->query($sql4);
                                                    }
                                                }



                                                $sql2 = "DELETE FROM correg_" . $getsession . " WHERE Regn1 ='$matric_no'";
                                                $result2 = $conn_stu->query($sql2);
                                            }

                                            $sql3 = "SELECT * FROM std_prog_courses WHERE programme_code = '$dept'";
                                            $result3 = $conn2->query($sql3);
                                            if ($result3->num_rows > 0) {
                                                while ($row3 = $result3->fetch_assoc()) {
                                                    $prog_id = $row3["id"];
                                                }
                                            }


                                            $sql2 = "UPDATE std_data SET std_prog_courses_id ='$prog_id', level ='$level', matric_no ='$new_mat' WHERE matric_no = '$matric_no'";
                                            $result2 = $conn2->query($sql2);

                                            $sql2 = "UPDATE std_login SET matric_no ='$new_mat' WHERE matric_no = '$matric_no'";
                                            $result2 = $conn2->query($sql2);


                                            $sql2 = "DELETE FROM courses_register_" . $dbsession . " WHERE Regn1 ='$matric_no'";
                                            $result2 = $conn->query($sql2);
                                        }
                                        $conn_stu->close();
                                    }
                                }

                                //$msg = "Record Updated";
                                echo '<center><p style="color:#006">CSV File has been successfully Imported</p></center>';
                            }
                            ?>

                            <form enctype="multipart/form-data" action="" method="post">
                                <div class="row">
                                    <div class="col-md-6">
                                        <center>
                                            <h4>CSV File with the Format Below.</h4>
                                            <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                            <h4>ND I = 100<br>HND I = 100</h4>
                                            <?php } ?>
                                        </center>
                                        <center><img src='img/change_dept_new.png' width='300' height='150' alt=''>
                                        </center>
                                    </div>
                                    <div class="col-md-6"
                                        style="overflow-y: auto; max-height: 200px; border: 1px solid #ccc; padding: 10px;">
                                        <h4>Departments with Codes</h4>
                                        <table style="width: 97%">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        Department Code</th>
                                                    <th>
                                                        Department Title</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if ($_SESSION['instcode'] == "FPB") {
                                                    $sql3 = "SELECT * FROM std_dept ORDER BY name";
                                                    $result3 = $conn2->query($sql3);
                                                    if ($result3->num_rows > 0) {
                                                        while ($row3 = $result3->fetch_assoc()) {
                                                            $dept = $row3["dept"];
                                                            $name = $row3["name"];
                                                            echo "<tr><td>$dept</td><td>$name</td></tr>";
                                                        }
                                                    }
                                                } elseif ($_SESSION['instcode'] == "NAUB") {
                                                    $sql3 = "SELECT * FROM std_prog_courses ORDER BY name";
                                                    $result3 = $conn2->query($sql3);
                                                    if ($result3->num_rows > 0) {
                                                        while ($row3 = $result3->fetch_assoc()) {
                                                            $programme_code = $row3["programme_code"];
                                                            $name = $row3["name"];
                                                            echo "<tr><td>$programme_code</td><td>$name</td></tr>";
                                                        }
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <br>





                                <div class="form-group">
                                    <label class="col-md-2 control-label">File Upload</label>
                                    <div class="col-md-4">


                                        <div class="fileinput fileinput-new input-group" data-provides="fileinput">
                                            <div class="form-control" data-trigger="fileinput">
                                                <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                                <span class="fileinput-filename"></span>
                                            </div>
                                            <span class="input-group-addon btn btn-default btn-file"><span
                                                    class="fileinput-new">Select
                                                    file</span><span class="fileinput-exists">Change</span><input
                                                    type="file" name="uploaded"></span>
                                            <a href="#" class="input-group-addon btn btn-default fileinput-exists"
                                                data-dismiss="fileinput">Remove</a>
                                        </div>

                                    </div>
                                    <div class="col-lg-2">
                                        <input type="submit" name="upfile" value="Upload File"
                                            class="btn btn-primary btn-sm">
                                    </div>
                                </div>
                            </form>
                            <h3> <?php echo $msg ?> </h3>
                            <?php if ($success_upl == "yes") { ?>
                            <br>
                            <?php
                                $sql = "SELECT * FROM change_dept_new";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                ?>
                            <table class="table mb-none">
                                <thead>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Matric No</th>
                                        <th>New Dept</th>
                                        <th>Level</th>

                                    </tr>
                                </thead>
                                <tbody>


                                    <?php
                                            $sno = 0;
                                            while ($row = $result->fetch_assoc()) {
                                                $sno++;
                                                $mat_no = $row["mat_no"];
                                                $dept = $row["dept"];
                                                $level = $row["level"];

                                                echo "<tr><td>$sno</td><td>$mat_no</td><td>$dept</td><td>$level</td></tr>\n";
                                            }
                                            ?>
                                </tbody>
                            </table>
                            <?php } ?>
                            <br>
                            <form role="form" enctype="multipart/form-data" method="post" action="">
                                <button type="submit" name="submit" class="btn btn-primary btn-sm">Update</button>

                            </form>
                            <?php } ?>
                        </div>
                        <?php
                        $conn->close();
                        $conn2->close();
                        ?>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>
</body>

</html>
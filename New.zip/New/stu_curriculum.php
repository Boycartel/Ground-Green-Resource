<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?> Students Portal</title>
    <meta name="keywords" content="Result" />
    <meta name="description" content="e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword" content="Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';

    // $sql = "UPDATE `stdprofile` SET curriculum = 'OLD' WHERE Deptcode = 'MAT'";
    //$result = $conn2->query($sql);
    ?>
</head>

<body>
    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
        <form class="form-horizontal form-bordered" method="post">

            <div class="row">
                <h2 class="panel-title" style="text-align: center">Set Students' Curriculum</h2>
                <br><br><br>

                <div class="col-lg-5">
                    <div class="row">
                        <label class="control-label col-lg-5" for="regid">Year Admitted:</label>
                        <div class="col-lg-7">
                            <?php
                            $iniyear = 2015;
                            $finalyear = substr($_SESSION['corntsession'], 5);

                            ?>
                            <select name="getyearadmt" class="form-control" style="color:#000000" id="getyearadmt">
                                <option value="<?php echo $finalyear ?>"><?php echo $finalyear ?></option>
                                <?php
                                while ($iniyear <= $finalyear) {
                                    $addyear = $iniyear + 1;

                                    echo "<option value = '$iniyear'>$iniyear</option>";
                                    $iniyear++;
                                }

                                ?>


                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                        <div class="row">
                            <label class="control-label col-lg-5" for="regid">Programme:</label>
                            <div class="col-lg-7">

                                <select name="getprogram" class="form-control" style="color:#000000" id="getprogram" required>
                                    <option value="">Select Item</option>
                                    <option value="ND">ND</option>
                                    <option value="HND">HND</option>
                                </select>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <div class="col-lg-2">
                    <div class="row">

                        <div class="col-lg-4">
                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                        </div>
                    </div>
                </div>

            </div>
        </form>
        <hr class="separator" />
    </div>

    <?php
    if (isset($_POST["submitAll"])) {
        $curriCode = $_POST["getcurri"];

        $cursession = $_SESSION['resultsession'];
        $resultsemester = $_SESSION['resultsemester'];
        $dept = $_SESSION['deptcode'];
        $yearadmtd = $_SESSION['yearadmtd'];

        $sql2 = "UPDATE std_data_view SET curriculum = '$curriCode' WHERE dept_code = '$dept' AND YAddmitted = '$yearadmtd'";
        $result2 = $conn2->query($sql2);
    }
    ?>
    <div style="padding-left:3em; padding-right: 3em">

        <?php if (isset($_POST["submit"]) || isset($_POST["submitAll"])) { ?>
            <?php
            if (isset($_POST["submit"])) {
                $yearadmtd = $_POST["getyearadmt"];
                if ($_SESSION['InstType'] == "Polytechnic") {
                    $getprogram = $_POST["getprogram"];
                    $_SESSION['getprogram'] = $getprogram;
                }
                $_SESSION['yearadmtd'] = $yearadmtd;
            } else {
                $yearadmtd = $_SESSION['yearadmtd'];
                $getprogram = $_SESSION['getprogram'];
            }

            $cursession = $_SESSION['resultsession'];
            $resultsemester = $_SESSION['resultsemester'];
            $dept = $_SESSION['deptcode'];

            ?>

            <div class="panel-body">

                <br>
                <div class="col-lg-12 table-responsive">
                    <form class="form-horizontal form-bordered" method="post">
                        <!-- <div class="row">
                        <div class="col-lg-6">

                        </div>
                        <label class="control-label col-lg-2" for="regid">Select Curriculum:</label>
                        <div class="col-lg-3">
                            <select name="getcurri" class="form-control" style="color:#000000" id="getcurri" required>
                                <option value=''></option>
                                <?php
                                /* $dept = $_SESSION['deptcode'];
                                    $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept'";
                                    $result = $conn->query($sql);
                                    $Add1 = 0;
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $curri_Code = $row["curri_Code"];
                                            $curri_Title = $row["curri_Title"];
                                            echo "<option value = '$curri_Code'>$curri_Title</option>";
                                        }
                                    } */

                                ?>
                            </select>

                        </div>
                        <div class="col-lg-1" style="text-align: right">
                            <button type="submit" name="submitAll" class="btn btn-primary btn-xs">Submit All
                            </button>
                        </div>
                    </div> -->
                    </form>
                    <br>
                    <table class="table table-striped table-bordered">
                        <thead style='text-align:center'>
                            <tr>
                                <th>S/No</th>
                                <th>Matric_No</th>
                                <th>Name</th>
                                <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                    <th>Programme</th>
                                <?php } ?>
                                <th>Curriculum</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sno = 0;
                            if ($_SESSION['InstType'] == "University") {
                                $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND YAddmitted = '$yearadmtd' ORDER BY matric_no";
                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND YAddmitted = '$yearadmtd' AND modeofentry = '$getprogram' ORDER BY matric_no";
                            }

                            $result = $conn2->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $sno++;
                                    $regid = $row["matric_no"];
                                    $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                    //$id = $row["sn"];
                                    $curriculum = $row['curriculum'];


                                    echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$regid </td><td> $names</td>";
                                    if ($_SESSION['InstType'] == "Polytechnic") {
                                        $modeofentry = $row['modeofentry'];
                                        echo "<td>$modeofentry</td>";
                                    }
                                    echo '<td><a href="#" class="curriculum" id="curriculum' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_curriculum.php" data-name="curriculum">' . $row["curriculum"] . '</a></td>';

                                    echo "</tr>\n";
                                }
                            }

                            ?>
                        </tbody>
                    </table>
                </div>

            </div>

        <?php } ?>

    </div>


    <script>
        //For curriculum Table column Data

        const curriculum = document.getElementsByClassName('curriculum');

        for (var count = 0; count < curriculum.length; count++) {
            const curriculum_data = document.getElementById(curriculum[count].getAttribute("id"));

            const curriculum_popover = new DarkEditable(curriculum_data, {
                source: [
                    <?php
                    $dept = $_SESSION['deptcode'];
                    $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept'";
                    $result = $conn->query($sql);
                    $Add1 = 0;
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $curri_Code = $row["curri_Code"];
                            $curri_Title = $row["curri_Title"];
                    ?>

                            {
                                value: '<?php echo $curri_Code ?>',
                                text: '<?php echo $curri_Title ?>'
                            },
                    <?php
                        }
                    }
                    ?>
                ]
            });
        }
    </script>
</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['download_stu_reg_courses'] == false) {
    header('Location: home_staff.php');
}
?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_R.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Download Students Registered Courses</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Download
                            </li>

                            <li class="active">
                                <strong>Download Students Registered Courses</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Download Students Registered Courses
                        </div>
                        <div class="panel-body">

                            <div class="row">
                                <form class="form-horizontal" method="post">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-4" for="content">Select Course:</label>
                                            <div class="col-lg-7">
                                                <select class="form-control" style="color:#000000" name="course">
                                                    <option value="SelectItem">Select Item</option>
                                                    <?php
                                                    //$cat = $_SESSION['cat'];
                                                    $dept = $_SESSION['deptcode'];
                                                    $staffid = $_SESSION['staffid'];
                                                    $deptname = $_SESSION['deptname'];
                                                    $corntsession = $_SESSION['corntsession'];



                                                    if ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES" || $_SESSION['AcadSec'] == "YES" || $_SESSION['Acad_Ofice'] = "YES" || $cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                        $sql = "SELECT C_codding, C_title FROM gencoursesupload ORDER BY C_codding";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $coursecode = $row["C_codding"];
                                                                $coursetitle = $row["C_title"];
                                                                echo "<option value='$coursecode'>$coursecode $coursetitle</option>";
                                                            }
                                                        }
                                                    } else {
                                                        $sql = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$corntsession' ORDER BY CCode";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            // output data of each row
                                                            while ($row = $result->fetch_assoc()) {
                                                                $coursecode = $row["C_codding"];
                                                                $coursetitle = $row["C_title"];
                                                                echo "<option value='$coursecode'>$coursecode $coursetitle</option>";
                                                            }
                                                        }
                                                    }
                                                    ?>

                                                </select>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">

                                            <label class="control-label col-lg-3">Session:</label>
                                            <div class="col-lg-8">
                                                <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    $iniyear = 2015;
                                                    $finalyear = substr($_SESSION['corntsession'], 5);

                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    //$conn->close();
                                                    ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-9">
                                                <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1">

                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">

                                <?php if (isset($_POST["submit"])) { ?>
                                    <?php
                                    $course = $_POST['course'];
                                    $session = $_POST['getsession'];

                                    $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$course'";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $cursedept = strtolower($row2["Department"]);
                                            $coursetitle = $row2["C_title"];
                                        }
                                    }
                                    ?>
                                    <div class="col-lg-12  col-md-12">
                                        <div class="col-lg-1">

                                        </div>
                                        <div class="col-lg-10">
                                            <?php
                                            set_time_limit(500);
                                            $GetTitle = $coursetitle;
                                            $sno = 0;
                                            ?>
                                            <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups" frame="hsides" border="2">
                                                <caption><?php echo $GetTitle ?></caption>
                                                <colgroup align="center"></colgroup>
                                                <colgroup align="left"></colgroup>
                                                <colgroup span="2"></colgroup>
                                                <colgroup span="3" align="center"></colgroup>
                                                <thead>
                                                    <tr>

                                                        <th>SNo</th>
                                                        <th>Matric No</th>
                                                        <th>Name</th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Session</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $dbsession = str_replace("/", "_", $session);
                                                    $sql = "SELECT Regn1, name1, CCode, CTitle, CUnit, SemTaken, session FROM courses_register_" . $dbsession . " WHERE CCode= '$course' AND session= '$session' ORDER BY Regn1";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $regid = strtoupper($row["Regn1"]);
                                                            echo "<tr><td>$sno</td><td>$regid</td><td>{$row['name1']}</td><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['session']}</td></tr>\n";
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <br>
                                            <div style="text-align: right">
                                                <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                            </div>



                                        </div>
                                        <div class="col-lg-1">

                                        </div>


                                    </div>



                                <?php } ?>
                            </div>

                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>
                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
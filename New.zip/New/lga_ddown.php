<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$stateid = $_POST['post_id'];   // department id

$sql = "SELECT lga, state FROM lgas WHERE state='$stateid'";
$result = $conn->query($sql);
$lgas_arr = array();
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$lgaid = $row['state'];
		$name = $row['lga'];

		$lgas_arr[] = array("id" => $lgaid, "name" => $name);
	}
}


// encoding array to json format
echo json_encode($lgas_arr);

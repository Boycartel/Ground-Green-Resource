<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

?>
<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>

    <style type="text/css">
    .asd {
        background: transparent !important;
        border: none !important;
        outline: none !important;
        padding: 0px, 0px, 0px, 0px !important;
        cursor: pointer;

    }
    </style>




</head>
<?php
//$cat2 = $_SESSION['cat'];
$staflevel = $_SESSION['staflevel'];
$schcode = $_SESSION['schcode'];
$dept = $_SESSION['deptcode'];
$staffid = $_SESSION['staffid'];
$curtsession = $_SESSION['corntsession'];



?>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Messages</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_stu.php">Home</a>
                        </li>
                        <li class="active">
                            <strong>Messages</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>


            <div class="wrapper wrapper-content animated fadeInRight">

                <div class="row">
                    <div class="col-lg-12">

                        <div class="ibox chat-view">

                            <div class="ibox-title">

                                Chat room panel
                            </div>


                            <div class="ibox-content">

                                <div class="row">
                                    <div class="col-md-3">
                                        <form id="myForm" action="ajax_save_rec/staf_chatzone_load.php" method="POST">

                                            <h3 style="padding-left: 1.5em;">Select Recipient</h3>
                                            <select class="form-control" style="color:#000000" size="10"
                                                id="selectOption" name="selectOption" onchange="postFormData()">
                                                <?php if ($cat_Sub_Admin == "YES" || $cat_Administrator == "YES") { ?>
                                                <option value="All_stu" class="chat-user">All Students</option>
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <option value="L100_stu" class="chat-user">100 Level Students</option>
                                                <option value="L200_stu" class="chat-user">200 Level Students</option>
                                                <option value="L300_stu" class="chat-user">300 Level Students</option>
                                                <option value="L400_stu" class="chat-user">400 Level Students</option>
                                                <option value="L500_stu" class="chat-user">500 Level Students</option>
                                                <option value="spill_over_stu" class="chat-user">Spill Over Students
                                                </option>
                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                <option value="L100_stu" class="chat-user">NDI Students</option>
                                                <option value="L200_stu" class="chat-user">NDII Students</option>
                                                <option value="L300_stu" class="chat-user">HNDI Students</option>
                                                <option value="L400_stu" class="chat-user">HNDII Students</option>
                                                <option value="spill_over_stu" class="chat-user">Spill Over Students
                                                </option>
                                                <?php } else { ?>

                                                <?php } ?>

                                                <?php } ?>
                                                <?php if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") { ?>
                                                <option value="All" class="chat-user">All Students in the Department
                                                </option>
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <option value="L100" class="chat-user">100 Level Students</option>
                                                <option value="L200" class="chat-user">200 Level Students</option>
                                                <option value="L300" class="chat-user">300 Level Students</option>
                                                <option value="L400" class="chat-user">400 Level Students</option>
                                                <option value="L500" class="chat-user">500 Level Students</option>
                                                <option value="spill_over" class="chat-user">Spill Over Students
                                                </option>
                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                <option value="L100" class="chat-user">NDI Students</option>
                                                <option value="L200" class="chat-user">NDII Students</option>
                                                <option value="L300" class="chat-user">HNDI Students</option>
                                                <option value="L400" class="chat-user">HNDII Students</option>
                                                <option value="spill_over" class="chat-user">Spill Over Students
                                                </option>
                                                <?php } else { ?>

                                                <?php } ?>
                                                <?php } ?>
                                                <?php
                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }

                                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                                if ($conn2->connect_error) {
                                                    die("Connection failed: " . $conn2->connect_error);
                                                }

                                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                if ($cat_L100 == "YES" || $cat_L200 == "YES" || $cat_L300 == "YES" || $cat_L400 == "YES" || $cat_L500 == "YES" || $cat_spill_over == "YES") {
                                                    if ($_SESSION['InstType'] == "University") {
                                                        if ($cat_L100 == "YES") {
                                                            echo "<option value='L100' class='chat-user'> 100 Level Students</option>";
                                                        }
                                                        if ($cat_L200 == "YES") {
                                                            echo "<option value='L200' class='chat-user'> 200 Level Students</option>";
                                                        }
                                                        if ($cat_L300 == "YES") {
                                                            echo "<option value='L300' class='chat-user'> 300 Level Students</option>";
                                                        }
                                                        if ($cat_L400 == "YES") {
                                                            echo "<option value='L400' class='chat-user'> 400 Level Students</option>";
                                                        }
                                                        if ($cat_L500 == "YES") {
                                                            echo "<option value='L500' class='chat-user'> 500 Level Students</option>";
                                                        }
                                                        if ($cat_spill_over == "YES") {
                                                            echo "<option value='spill_over' class='chat-user'> Spill Over Students</option>";
                                                        }
                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {

                                                        if ($cat_L100 == "YES") {
                                                            echo "<option value='L100' class='chat-user'> NDI Level Students</option>";
                                                        }
                                                        if ($cat_L200 == "YES") {
                                                            echo "<option value='L200' class='chat-user'> NDII Level Students</option>";
                                                        }
                                                        if ($cat_L300 == "YES") {
                                                            echo "<option value='L300' class='chat-user'> HNDI Level Students</option>";
                                                        }
                                                        if ($cat_L400 == "YES") {
                                                            echo "<option value='L400' class='chat-user'> HNDII Level Students</option>";
                                                        }
                                                        if ($cat_spill_over == "YES") {
                                                            echo "<option value='spill_over' class='chat-user'> Spill Over Students</option>";
                                                        }
                                                    } else {
                                                    }
                                                }


                                                if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES" || $cat_L100 == "YES" || $cat_L200 == "YES" || $cat_L300 == "YES" || $cat_L400 == "YES" || $cat_L500 == "YES" || $cat_spill_over == "YES") {
                                                    $dbsession = str_replace("/", "_", $curtsession);
                                                    $sql = "SELECT PFNo, CCode, CTitle, SessionReg FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$curtsession' ORDER BY CCode";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $CCode = $row["CCode"];

                                                            echo "<option value='$CCode' class='chat-user'>$CCode Registered Students</option>";
                                                        }
                                                    }


                                                    $sql = "SELECT matricno, name1, Session1 FROM hod_list WHERE Session1 = '$curtsession' ORDER BY matricno";
                                                    $result = $conn_stu->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $regid2 = $row["matricno"];
                                                            $stuname2 = strtolower($row["name1"]);
                                                            $stuname2 = ucwords($stuname2);

                                                            echo "<option value='$regid2' class='chat-user'>$regid2 $stuname2</option>";
                                                        }
                                                    }
                                                }

                                                ?>
                                            </select>

                                            <input type="hidden" id="InstType" name="InstType"
                                                value="<?php echo $_SESSION['InstType'] ?>" onkeyup="postFormData()">
                                            <input type="hidden" id="stu_pic_folder" name="stu_pic_folder"
                                                value="<?php echo $_SESSION["stu_pic_folder"] ?>"
                                                onkeyup="postFormData()">

                                            <!-- Use a hidden input field to dynamically store the selected option -->
                                            <input type="hidden" id="selectedOptionHidden" name="selectedOptionHidden">
                                        </form>
                                    </div>
                                    <div class="col-md-9 ">
                                        <h3 style="text-align:center">Chat Body</h3>
                                        <div class="chat-discussion">
                                            <div id="chat_body">
                                                <?php



                                                $ArryCCode[1] = $ArryCCode[2] = $ArryCCode[3] = $ArryCCode[4] = $ArryCCode[5] = $ArryCCode[6] = $ArryCCode[7] = $ArryCCode[8] = $ArryCCode[9] = $ArryCCode[10] = "XX";
                                                $countArCode = 0;

                                                $dbsession = str_replace("/", "_", $curtsession);
                                                $sql = "SELECT PFNo, CCode, CTitle, SessionReg FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$curtsession' ORDER BY CCode";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $countArCode++;
                                                        $CCode = $row["CCode"];
                                                        $ArryCCode[$countArCode] = $row["CCode"];
                                                    }
                                                }

                                                $countrec = 0;
                                                if ($cat_Sub_Admin == "YES" || $cat_Administrator == "YES") {
                                                    //$sql = "SELECT * FROM staff_comment WHERE cat = 'Sub Admin I' OR cat = 'Administrator' ORDER BY id DESC";
                                                    $sql = "SELECT * FROM staff_comment WHERE cat = 'Sub_Admin' OR cat = 'Administrator' OR msgid = '$ArryCCode[1]' OR msgid = '$ArryCCode[2]' OR msgid = '$ArryCCode[3]' OR msgid = '$ArryCCode[4]' OR msgid = '$ArryCCode[5]' OR msgid = '$ArryCCode[6]' OR msgid = '$ArryCCode[7]' OR msgid = '$ArryCCode[8]' OR msgid = '$ArryCCode[9]' OR msgid = '$ArryCCode[10]' ORDER BY id DESC";
                                                    $result = $conn->query($sql);
                                                } else {
                                                    $sql = "SELECT * FROM staff_comment WHERE msgid = '$staffid' OR msgid = '$ArryCCode[1]' OR msgid = '$ArryCCode[2]' OR msgid = '$ArryCCode[3]' OR msgid = '$ArryCCode[4]' OR msgid = '$ArryCCode[5]' OR msgid = '$ArryCCode[6]' OR msgid = '$ArryCCode[7]' OR msgid = '$ArryCCode[8]' OR msgid = '$ArryCCode[9]' OR msgid = '$ArryCCode[10]' ORDER BY id DESC";
                                                    $result = $conn->query($sql);
                                                }



                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $cat2 = $row['matricno'];

                                                        if ($cat_Sub_Admin == "YES" || $cat_Administrator == "YES") {
                                                            $sql2 = "UPDATE staff_comment SET msgopen ='YES' WHERE (cat = 'Sub_Admin' AND cat = 'Administrator')";
                                                            $result2 = $conn->query($sql2);
                                                        } else {
                                                            $sql2 = "UPDATE staff_comment SET msgopen ='YES' WHERE msgid = '$staffid'";
                                                            $result2 = $conn->query($sql2);
                                                        }

                                                        if (is_null($row['recieve_coment'])) {

                                                ?>
                                                <div class="chat-message right">
                                                    <?php
                                                                $staff_pic_folder = $_SESSION['staff_pic_folder'];
                                                                $filename = $staff_pic_folder . $row['msgid'] . '.jpg';

                                                                if (file_exists($filename)) {
                                                                    echo "<img alt=''  class='message-avatar' src='$staff_pic_folder" . $row['msgid'] . ".jpg' width='50' height='50'>";
                                                                } else {
                                                                    echo "<img alt=''  class='message-avatar' src='img/logo.ico' width='50' height='50'>";
                                                                }

                                                                if ($_SESSION['InstType'] == "University") {
                                                                    if ($cat2 == "L100" || $cat2 == "L100_stu") {
                                                                        $getcat = "All 100 Level Students";
                                                                    } elseif ($cat2 == "L200" || $cat2 == "L200_stu") {
                                                                        $getcat = "All 200 Level Students";
                                                                    } elseif ($cat2 == "L300" || $cat2 == "L300_stu") {
                                                                        $getcat = "All 300 Level Students";
                                                                    } elseif ($cat2 == "L400" || $cat2 == "L400_stu") {
                                                                        $getcat = "All 400 Level Students";
                                                                    } elseif ($cat2 == "L500" || $cat2 == "L500_stu") {
                                                                        $getcat = "All 500 Level Students";
                                                                    } elseif ($cat2 == "spill_over" || $cat2 == "spill_over_stu") {
                                                                        $getcat = "All Spill Over Students";
                                                                    } elseif ($cat2 == "All") {
                                                                        $getcat = "All Students in the Departmet";
                                                                    } elseif ($cat2 == "All_stu") {
                                                                        $getcat = "All Students";
                                                                    } else {
                                                                        $getcat = $cat2;
                                                                    }
                                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {

                                                                    if ($cat2 == "L100" || $cat2 == "L100_stu") {
                                                                        $getcat = "All NDI Students";
                                                                    } elseif ($cat2 == "L200" || $cat2 == "L200_stu") {
                                                                        $getcat = "All NDII Students";
                                                                    } elseif ($cat2 == "L300" || $cat2 == "L300_stu") {
                                                                        $getcat = "All HNDI Students";
                                                                    } elseif ($cat2 == "L400" || $cat2 == "L400_stu") {
                                                                        $getcat = "All HNDII Students";
                                                                    } elseif ($cat2 == "spill_over" || $cat2 == "spill_over_stu") {
                                                                        $getcat = "All Spill Over Students";
                                                                    } elseif ($cat2 == "All") {
                                                                        $getcat = "All Students in the Departmet";
                                                                    } elseif ($cat2 == "All_stu") {
                                                                        $getcat = "All Students";
                                                                    } else {
                                                                        $getcat = $cat2;
                                                                    }
                                                                } else {
                                                                }
                                                                ?>

                                                    <div class="message">
                                                        <a class="message-author" href="#"> <?php echo $getcat ?> </a>
                                                        <span class="message-date"> <?php echo $row['date_time'] ?>
                                                        </span>
                                                        <span class="message-content" style="text-align: left;">
                                                            <?php
                                                                        echo $row['sent_coment'];
                                                                        ?>
                                                        </span>
                                                    </div>
                                                </div>
                                                <?php } else { ?>
                                                <div class="chat-message left">
                                                    <?php
                                                                $YesStu = false;
                                                                $sql3 = "SELECT matric_no FROM std_data_view WHERE matric_no = '$cat2'";
                                                                $result3 = $conn2->query($sql3);
                                                                if ($result3->num_rows > 0) {
                                                                    $YesStu = true;
                                                                }
                                                                if ($YesStu == true) {
                                                                    $sql3 = "SELECT stdid, matric_no, first_name, other_name, surname FROM std_data_view WHERE matric_no = '$cat2'";
                                                                    $result3 = $conn2->query($sql3);
                                                                    if ($result3->num_rows > 0) {
                                                                        while ($row3 = $result3->fetch_assoc()) {
                                                                            $stdid = $row["stdid"];
                                                                            $names = $row3["first_name"] . " " . $row3["other_name"] . " " . $row3["surname"];
                                                                            $names = strtolower($names);
                                                                            $names = ucwords($names);
                                                                        }
                                                                    }
                                                                    $sql3 = "SELECT * FROM std_login WHERE stdid = '$stdid'";
                                                                    $result3 = $conn2->query($sql3);
                                                                    if ($result3->num_rows > 0) {
                                                                        $passportid = $stdid;
                                                                    } else {
                                                                        $passportid = $cat2;
                                                                    }
                                                                    $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                                    $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                                                    echo "<img alt=''  class='message-avatar' src='$stu_pic_folder/$passptfile' width='50' height='50'>";
                                                                } else {
                                                                    echo '<img  class="message-avatar" src="img/logo.ico"  width="50" height="50"/>';
                                                                }

                                                                ?>

                                                    <div class="message">
                                                        <a class="message-author"
                                                            href="#"><?php echo $cat2 . "<br>" . $names ?> </a>
                                                        <span class="message-date"> <?php echo $row['date_time'] ?>
                                                        </span>
                                                        <span class="message-content">
                                                            <?php
                                                                        echo $row['recieve_coment'];
                                                                        ?>
                                                        </span>
                                                    </div>
                                                </div>
                                                <?php } ?>
                                                <?php } ?>
                                                <?php } ?>

                                                <?php
                                                $conn->close();
                                                $conn2->close();
                                                $conn_stu->close();
                                                ?>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <form id="myForm">
                                            <div class="col-md-3 ">
                                                <h3 style="text-align:center; color:black">Message To ...</h3>
                                                <div class="form-group" id="sendto">

                                                </div>
                                            </div>
                                            <div class="col-md-9 ">
                                                <div class="chat-message-form">

                                                    <div class="form-group">

                                                        <div class="col-md-11 ">
                                                            <textarea class="form-control message-input" id="mychat"
                                                                name="mychat" placeholder="Enter message text"
                                                                required></textarea>
                                                        </div>
                                                        <div class="col-md-1 ">
                                                            <button type="button" onclick="saveRecord()"
                                                                class="btn btn-primary btn-xs">Post</button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                                <br><br>

                            </div>

                        </div>
                    </div>

                </div>


            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>

    </div>



    <?php
    include_once 'includes/footer.php';
    ?>

    <!--Insert Chat-->

    <script>
    function saveRecord() {
        var recip_id = document.getElementById("recip_id").value;
        var mychat = document.getElementById("mychat").value;

        var formData = new FormData();
        formData.append("recip_id", recip_id);
        formData.append("mychat", mychat);

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "ajax_save_rec/staf_chatzone_insert.php", true);

        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Handle the response from the server
                console.log(xhr.responseText);
            }
        };

        xhr.send(formData);
        document.getElementById("mychat").value = "";
        document.getElementById("recip_id").value = "";
    }
    </script>




    <!--Fetch Chat-->
    <!--<script src="http://code.jquery.com/jquery-latest.js"></script>-->
    <script>
    $(document).ready(function() {
        setInterval(function() {
            $("#chat_body").load(window.location.href + " #chat_body");
        }, 3000);
    });
    </script>




    <script type="text/javascript">
    function postFormData() {
        var selectOption = document.getElementById("selectOption").value;
        var InstType = document.getElementById("InstType").value;
        var stu_pic_folder = document.getElementById("stu_pic_folder").value;

        // Assign the selected option to the hidden input field
        document.getElementById("selectedOptionHidden").value = selectOption;



        $.ajax({
            type: "POST",
            url: 'ajax_save_rec/staf_chatzone_load.php',
            data: {
                state1: selectOption,
                InstType1: InstType,
                stu_pic_folder1: stu_pic_folder

            }
        }).done(function(data) {
            $("#sendto").html(data);
        });

    }
    </script>

</body>

</html>
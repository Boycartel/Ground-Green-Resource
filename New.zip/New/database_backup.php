<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['download_stu_reg_courses'] == false) {
    header('Location: home_staff.php');
}
?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Database Backup</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Database Backup</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php $getsession = "" ?>
                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <?php
                    if (isset($_POST["submit"])) {
                        $getsession = $_POST["getsession"];
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Database Backup for <?php echo $getsession ?> Session
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <br><br>
                                <div class="col-lg-2">

                                </div>
                                <div class="col-lg-8">
                                    <form class="form-horizontal form-bordered" method="post">
                                        <label class="control-label col-lg-3" for="getsession">Session:</label>
                                        <div class="col-lg-5">
                                            <?php
                                            $iniyear = 2015;
                                            $finalyear = substr($_SESSION['corntsession'], 5);

                                            ?>
                                            <select name="getsession" class="form-control" style="color:#000000"
                                                id="getsession">
                                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                    <?php echo $_SESSION['corntsession'] ?></option>
                                                <?php
                                                while ($iniyear <= $finalyear) {
                                                    $addyear = $iniyear + 1;

                                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                    $iniyear++;
                                                }

                                                ?>


                                            </select>
                                        </div>
                                        <div class="col-lg-4">
                                            <button type="submit" name="submit"
                                                class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-lg-2">

                                </div>
                            </div>
                            <?php if (isset($_POST["submit"])) { ?>
                            <div class="table-responsive">

                                <?php
                                    set_time_limit(500);
                                    $GetTitle = "";
                                    $sno = 0;
                                    ?>
                                <table id="myTable" class="table mb-none" style="font-size:14px" summary=""
                                    rules="groups" frame="hsides" border="2">
                                    <caption><?php echo $GetTitle ?></caption>
                                    <colgroup align="center"></colgroup>
                                    <colgroup align="left"></colgroup>
                                    <colgroup span="2"></colgroup>
                                    <colgroup span="3" align="center"></colgroup>
                                    <thead>
                                        <tr>

                                            <th>SNo</th>
                                            <th>Course Code</th>
                                            <th>Course Title</th>
                                            <th>Course Nature</th>
                                            <th>Unit</th>
                                            <th>Semester</th>
                                            <th>Session</th>
                                            <th>CA</th>
                                            <th>Exam</th>
                                            <th>Grade</th>
                                            <th>Grouping</th>
                                            <th>Reg Number</th>
                                            <th>Course Condune</th>
                                            <th>No Exam</th>
                                            <th>Dept Option</th>
                                            <th>Stu Curriculum</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $dept = $_SESSION['deptcode'];
                                            //$resultsession = $_SESSION['resultsession'];

                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }

                                            $StuCurSess = str_ireplace("/", "_", $getsession);
                                            $deptcorreg = "correg_" . $StuCurSess;
                                            $user_arr = array();
                                            $sql = "SELECT * FROM " . $deptcorreg;
                                            $result = $conn_stu->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $sno++;
                                                    $CCode = $row['CCode'];
                                                    $CTitle = $row['CTitle'];
                                                    $CNature = $row['CNature'];
                                                    $CUnit = $row['CUnit'];
                                                    $SemTaken = $row['SemTaken'];
                                                    $SessionRegis = $row['SessionRegis'];
                                                    $CA = $row['CA'];
                                                    $Exam = $row['Exam'];
                                                    $grade = $row['grade'];
                                                    $Grouping = $row['Grouping'];
                                                    $Regn1 = $row['Regn1'];
                                                    $coursecondon = $row['coursecondon'];
                                                    $noexam = $row['noexam'];
                                                    $deptOption = $row['deptOption'];
                                                    $curriculum = $row['curriculum'];
                                                    $date = $row['date'];
                                            ?>
                                        <tr>
                                            <td><?php echo $sno; ?></td>
                                            <td><?php echo $CCode; ?></td>
                                            <td><?php echo $CTitle; ?></td>
                                            <td><?php echo $CNature; ?></td>
                                            <td><?php echo $CUnit; ?></td>
                                            <td><?php echo $SemTaken; ?></td>
                                            <td><?php echo $SessionRegis; ?></td>
                                            <td><?php echo $CA; ?></td>
                                            <td><?php echo $Exam; ?></td>
                                            <td><?php echo $grade; ?></td>
                                            <td><?php echo $Grouping; ?></td>
                                            <td><?php echo $Regn1; ?></td>
                                            <td><?php echo $coursecondon; ?></td>
                                            <td><?php echo $noexam; ?></td>
                                            <td><?php echo $deptOption; ?></td>
                                            <td><?php echo $curriculum; ?></td>
                                            <td><?php echo $date; ?></td>

                                        </tr>
                                        <?php
                                                }
                                            }
                                            ?>
                                    </tbody>
                                </table>

                            </div>

                            <br>
                            <div style="text-align: right">
                                <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                    class="btn btn-primary">Download</a>
                            </div>
                            <br><br>
                            <?php } ?>
                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
    function fnExcelReport() {
        var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
        tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';

        tab_text = tab_text + '<x:Name>Sheet1</x:Name>';

        tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
        tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';

        tab_text = tab_text + "<table border='1px'>";
        tab_text = tab_text + $('#myTable').html();
        tab_text = tab_text + '</table></body></html>';

        var data_type = 'data:application/vnd.ms-excel';

        var ua = window.navigator.userAgent;
        var msie = ua.indexOf("MSIE ");

        if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
            if (window.navigator.msSaveBlob) {
                var blob = new Blob([tab_text], {
                    type: "application/csv;charset=utf-8;"
                });
                navigator.msSaveBlob(blob, 'CorReg_<?php echo $StuCurSess ?>.xls');
            }
        } else {
            $('#test').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
            $('#test').attr('download', 'CorReg_<?php echo $StuCurSess ?>.xls');
        }

    }
    </script>
</body>

</html>
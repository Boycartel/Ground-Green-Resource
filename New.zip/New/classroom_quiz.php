<?php
                            require_once 'includes/db_connect.php';
                            require_once 'includes/check_validity.php';
                            
$usernames = $_SESSION['names'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$staffid = $_SESSION['staffid'];
$dept = strtoupper($_SESSION['deptcode']);

?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">
    <!-- Textarea Editor -->
    <link href="editor/css_/bootstrap3-wysihtml5.min.css" rel="stylesheet" media="screen" />
    <!--Download to excel-->
    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html"
                    data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <?php
                $imgpf = str_replace('.', '_', $_SESSION['staffid']);

                ?>

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php

                            echo "<img src='https://staff.futminna.edu.ng/" . strtoupper($_SESSION['deptcode']) . "/images/" . strtoupper($imgpf) . "/MyPic1.jpg' alt='$usernames' class='img-circle' width='50' height='50' />";
                            ?>
                        </figure>
                        <div class="profile-info">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $staffid ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="staff_profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_staff.php"><i
                                        class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="lock_screen.php"><i class="fa fa-lock"></i> Lock
                                    Screen</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout_staff.php"><i
                                        class="fa fa-power-off"></i> Logout</a>
                            </li>




                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <?php
        $getccode = $_SESSION["getccode"];
        ?>
        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_staff_class.php'; ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>">
                    <h2><?php echo $_SESSION["course_title"] . " (" . $_SESSION["getccode"] . ")" ?></h2>

                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="#">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>

                            <li>
                                <a href="classroom_course.php" class='btn btn-primary btn-xs'></i> Back to Class</a>

                            </li>

                        </ol>

                        <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">

                            <div class="form-group" style="padding-left: 1em; padding-right: 1em">
                                <!--<form action="" method="post">
											<button type="submit" name="download_ass_score" class="btn btn-block btn-primary"><i class="fa fa-download mr-xs"></i></button>
											
										</form>-->
                            </div>

                            <div class="nano">
                                <div class="nano-content">
                                    <div class="inner-menu-content">
                                        <div class="sidebar-widget m-none">
                                            <div class="widget-content">
                                                <!--
													<ul class="mg-folders">
													
												    	<li>
												    		<form class="form-inline" method='post'>
												    			
																<label style="font-size: 14px"></strong></label>
																
																<div class="form-group">
																	<span class="name" style="color: #ffffff"></span><br>
																	<span class="name" style="color: #ffffff">Status: </span>
																</div>
													    		
																<div class="item-options">
																	<input type='hidden' value='' name='id'>
					                                                <input type='submit' name = 'view' class='btn btn-primary btn-xs' value='View'>
					                                                	
					                                            </div>
															</form>
														</li>
														    	
													</ul>-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">

                            <div class="inner-toolbar clearfix" style="color:#ffffff">
                                <ul>

                                    <li>
                                        <?php if (isset($_POST["full_post"]) || isset($_POST["pdf_post"])) { ?>
                                        <div id="quiz_counter">

                                        </div>
                                        <?php
                                            //$getccode=$_SESSION["getccode"];

                                            //$duration=$_SESSION["duration"];
                                            //$duration=200;
                                            ?>

                                        <!--<span id="countdown-2">120 seconds</span>-->

                                        <?php } else { ?>
                                        <?php

                                            $sql = "SELECT C_codding, C_title, credit FROM gencoursesupload WHERE C_codding = '$getccode'";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $_SESSION["course_title_assignment"] = $row["C_title"];
                                                }
                                            }

                                            ?>
                                        <h5><b><?php echo $_SESSION["course_title_assignment"] . "(" . $getccode . ")" ?></b>
                                        </h5>
                                        <?php } ?>



                                    </li>
                                    <li class="right">

                                        <ul class="nav nav-pills nav-pills-primary">

                                            <li>
                                                <form class="form-horizontal form-bordered" method="post">

                                                </form>
                                            </li>

                                        </ul>
                                    </li>
                                </ul>
                            </div>

                            <div class="row">
                                <?php
                                //$_SESSION["id_view"]="";
                                $sql = "SELECT * FROM settings WHERE items = 'quiz'";
                                $result = $conn8->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $tot_quiz_slot = $row["nos"];
                                    }
                                }
                                $_SESSION["tot_quiz_slot"] = $tot_quiz_slot;

                                $sql = "SELECT * FROM aaa_quiz_list WHERE ccode = '$getccode' AND session1 = '$curtsession' AND status = 'close' ORDER BY quiz_no";
                                $result = $conn8->query($sql);
                                $no_quiz = mysqli_num_rows($result);
                                $_SESSION["no_quiz"] = $no_quiz + 1;

                                ?>
                                <div class="form-group" style="color: black">
                                    <center>
                                        <h3><?php echo $_SESSION["no_quiz"] . " of " . $tot_quiz_slot ?> Quiz Slots</h3>
                                    </center>
                                </div>
                                <?php if ($no_quiz < $tot_quiz_slot) { ?>
                                <form action="" method="post">
                                    <div class="form-group" style="color: black">
                                        <label class="control-label col-lg-2">Quiz Authoring Type:</label>
                                        <div class="col-lg-4">
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="optauthoring" value="fulautho" checked="">
                                                    Full Authoring
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" name="optauthoring" value="partautho">
                                                    Upload Question in pdf
                                                </label>
                                            </div>
                                        </div>
                                        <label class="control-label col-lg-1">Number of Questions:</label>
                                        <div class="col-lg-1">
                                            <input type="number" class="form-control" name="question_no"
                                                required="required">
                                        </div>
                                        <label class="control-label col-lg-1">Duration(In Mins):</label>
                                        <div class="col-lg-1">
                                            <input type="number" class="form-control" name="duration"
                                                required="required">
                                        </div>
                                        <div class="col-lg-2">
                                            <?php if (!isset($_POST['full_post']) && !isset($_POST['pdf_post'])) { ?>
                                            <button type="submit" name="sub_autho_type"
                                                class="btn btn-primary btn-sm">Submit</button>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </form>
                                <?php } else { ?>
                                <center>
                                    <h3>Sorry: You have exhausted your Quiz Slots</h3>
                                </center>
                                <?php } ?>
                            </div>
                            <hr class="separator" />
                            <?php
                            if (isset($_POST["sub_autho_type"]) || isset($_POST["submit_quiz_autho"]) || isset($_POST["view"]) || isset($_POST["update_quiz_autho"]) || isset($_POST["delete_quiz_autho"]) || isset($_POST["upfile_quiz"]) || isset($_POST['save_q_pdf']) || isset($_POST['pdf_post']) || isset($_POST['full_post'])) {
                                $no_quiz = $_SESSION["no_quiz"];
                                //$tot_quiz_slot=$_SESSION["tot_quiz_slot"];
                                $options = $ans = "";
                                if (isset($_POST["sub_autho_type"])) {
                                    $autho_opt = $_POST["optauthoring"];
                                    $_SESSION["autho_opt"] = $autho_opt;
                                    $duration = $_POST["duration"];
                                    $duration = $duration * 60;
                                    $question_no = $_POST["question_no"];
                                    $_SESSION["question_no"] = $question_no;

                                    $sql = "SELECT * FROM aaa_quiz_list WHERE ccode = '$getccode' AND session1 = '$curtsession' AND status = 'open'";
                                    $result = $conn8->query($sql);
                                    if ($result->num_rows > 0) {
                                        $sql2 = "UPDATE aaa_quiz_list SET duration = '$duration', no_question = '$question_no', quiz_opt = '$autho_opt' WHERE ccode = '$getccode' AND session1 = '$curtsession' AND status = 'open'";
                                        $result2 = $conn8->query($sql2);
                                    } else {
                                        $sql2 = "INSERT INTO aaa_quiz_list (ccode, session1, quiz_no, duration, quiz_opt, no_question, status)VALUE('$getccode', '$curtsession', '$no_quiz', '$duration', '$autho_opt', '$question_no', 'open')";
                                        $result2 = $conn8->query($sql2);

                                        $sql2 = "DELETE FROM aaa_quiz  WHERE ccode = '$getccode'";
                                        $result2 = $conn8->query($sql2);

                                        $sql2 = "DELETE FROM aaa_quiz_pdf  WHERE ccode = '$getccode'";
                                        $result2 = $conn8->query($sql2);
                                    }
                                } else {
                                    $autho_opt = $_SESSION["autho_opt"];
                                    $question_no = $_SESSION["question_no"];
                                }

                                if (isset($_POST["submit_quiz_autho"])) {
                                    $myquestion = $_POST["myquestion"];
                                    $optA = $_POST["optA"];
                                    $optB = $_POST["optB"];
                                    $optC = $_POST["optC"];
                                    $optD = $_POST["optD"];

                                    $options = $_POST["options"];
                                    if ($options == "ansA") {
                                        $ans = "A";
                                    } elseif ($options == "ansB") {
                                        $ans = "B";
                                    } elseif ($options == "ansC") {
                                        $ans = "C";
                                    } elseif ($options == "ansD") {
                                        $ans = "D";
                                    }

                                    $sql = "INSERT INTO aaa_quiz (ccode, question, optA, optB, optC, optD, ans) VALUES ('$getccode', '$myquestion', '$optA', '$optB', '$optC', '$optD', '$ans')";
                                    $result = $conn8->query($sql);
                                }

                                if (isset($_POST["delete_quiz_autho"])) {
                                    $id_view = $_SESSION["id_view"];
                                    $sql = "DELETE FROM aaa_quiz WHERE id = '$id_view'";
                                    $result = $conn8->query($sql);
                                }

                                if (isset($_POST["update_quiz_autho"])) {
                                    $id_view = $_SESSION["id_view"];
                                    $myquestion = $_POST["myquestion"];
                                    $optA = $_POST["optA"];
                                    $optB = $_POST["optB"];
                                    $optC = $_POST["optC"];
                                    $optD = $_POST["optD"];

                                    $options = $_POST["options"];
                                    if ($options == "ansA") {
                                        $ans = "A";
                                    } elseif ($options == "ansB") {
                                        $ans = "B";
                                    } elseif ($options == "ansC") {
                                        $ans = "C";
                                    } elseif ($options == "ansD") {
                                        $ans = "D";
                                    }

                                    $sql = "UPDATE aaa_quiz SET question='$myquestion', optA='$optA', optB='$optB', optC='$optC', optD='$optD', ans='$ans' WHERE id = '$id_view'";
                                    $result = $conn8->query($sql);
                                }

                                if (isset($_POST['full_post'])) {
                                    //$cur_time = date("h:i:sa");
                                    date_default_timezone_set("Africa/Lagos");
                                    $today = date('Y-m-d H:i:s');

                                    //$time = new DateTime($codetime);
                                    //$diff = $time->diff(new DateTime());
                                    //$minutes = ($diff->days * 24 * 60) + ($diff->h * 60) + $diff->i;

                                    $cur_time = date("H:i:s");

                                    $sql = "UPDATE aaa_quiz_list SET status = 'close', quiz_begin = 'end' WHERE ccode = '$getccode'";
                                    $result = $conn8->query($sql);

                                    $sql = "UPDATE aaa_quiz_list SET quiz_begin = 'start', time_start = '$cur_time', status = 'open', time_date_start = '$today' WHERE ccode = '$getccode' AND session1 = '$curtsession' AND quiz_no = '$no_quiz'";
                                    $result = $conn8->query($sql);

                                    $sql2 = "DELETE FROM aaa_current_quiz  WHERE ccode = '$getccode'";
                                    $result2 = $conn8->query($sql2);
                                }

                                if ($autho_opt == "fulautho") {

                                    $sql = "SELECT * FROM aaa_quiz WHERE ccode = '$getccode'";
                                    $result = $conn8->query($sql);
                                    $tot_question = mysqli_num_rows($result);

                                    $question_view = $optA_view = $optB_view = $optC_view = $optD_view = $ans_view = "";
                                    if (isset($_POST["view"])) {
                                        $id_view = $_POST["id"];
                                        $_SESSION["id_view"] = $id_view;
                                        $sql = "SELECT * FROM aaa_quiz WHERE id = '$id_view' ORDER BY id";
                                        $result = $conn8->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $question_view = $row["question"];
                                                $optA_view = $row["optA"];
                                                $optB_view = $row["optB"];
                                                $optC_view = $row["optC"];
                                                $optD_view = $row["optD"];
                                                $ans_view = $row["ans"];
                                            }
                                        }
                                    }


                            ?>
                            <div class="row">
                                <section class="panel">
                                    <header class="panel-heading">
                                        <h2 class="panel-title">Full Authoring</h2>
                                    </header>
                                    <div class="panel-body">
                                        <div class="col-lg-6">
                                            <?php if (!isset($_POST['full_post'])) { ?>
                                            <form method="POST" class="form-horizontal" action="#">
                                                <div class="form-group skin-josh">
                                                    <label class="col-md-2 control-label">Question</label>
                                                    <div class="col-md-10">
                                                        <textarea name="myquestion"
                                                            id="tinymce_basic"><?php echo $question_view ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-md-1">
                                                        <?php if (isset($_POST["view"]) && $ans_view == "A") { ?>
                                                        <input type="radio" name="options" value="ansA" checked="">
                                                        <?php } else { ?>
                                                        <input type="radio" name="options" value="ansA" checked="">
                                                        <?php } ?>
                                                    </div>
                                                    <label class="col-md-2 control-label">Option A:</label>
                                                    <div class="col-md-7">
                                                        <input type="text" class="form-control" name="optA"
                                                            value="<?php echo $optA_view ?>" required="required">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-md-1">
                                                        <?php if (isset($_POST["view"]) && $ans_view == "B") { ?>
                                                        <input type="radio" name="options" value="ansB" checked="">
                                                        <?php } else { ?>
                                                        <input type="radio" name="options" value="ansB">
                                                        <?php } ?>
                                                    </div>
                                                    <label class="col-md-2 control-label">Option B:</label>
                                                    <div class="col-md-7">
                                                        <input type="text" class="form-control" name="optB"
                                                            value="<?php echo $optB_view ?>" required="required">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-md-1">
                                                        <?php if (isset($_POST["view"]) && $ans_view == "C") { ?>
                                                        <input type="radio" name="options" value="ansC" checked="">
                                                        <?php } else { ?>
                                                        <input type="radio" name="options" value="ansC">
                                                        <?php } ?>
                                                    </div>
                                                    <label class="col-md-2 control-label">Option C:</label>
                                                    <div class="col-md-7">
                                                        <input type="text" class="form-control" name="optC"
                                                            value="<?php echo $optC_view ?>" required="required">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-md-1">
                                                        <?php if (isset($_POST["view"]) && $ans_view == "D") { ?>
                                                        <input type="radio" name="options" value="ansD" checked="">
                                                        <?php } else { ?>
                                                        <input type="radio" name="options" value="ansD">
                                                        <?php } ?>
                                                    </div>
                                                    <label class="col-md-2 control-label">Option D:</label>
                                                    <div class="col-md-7">
                                                        <input type="text" class="form-control" name="optD"
                                                            value="<?php echo $optD_view ?>" required="required">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-md-3 control-label"></label>
                                                    <div class="col-md-7" style="text-align: right">
                                                        <?php if (!isset($_POST["view"])) { ?>
                                                        <?php if ($tot_question < $question_no) { ?>
                                                        <button type="submit" name="submit_quiz_autho"
                                                            class="btn btn-primary btn-sm">Submit</button>
                                                        <?php } ?>
                                                        <?php } ?>
                                                        <?php if (isset($_POST["view"])) { ?>
                                                        <button type="submit" name="update_quiz_autho"
                                                            class="btn btn-info btn-sm">Update</button>
                                                        <button type="submit" name="delete_quiz_autho"
                                                            class="btn btn-danger btn-sm">Delete</button>
                                                        <?php } ?>
                                                    </div>
                                                </div>


                                            </form>
                                            <?php if ($tot_question >= $question_no) { ?>
                                            <hr class="separator" />
                                            <center>
                                                <h5>Click "post" to start quiz</h5>
                                            </center>
                                            <div class="row" style="text-align: center">
                                                <form method="POST" class="form-horizontal" action="#">
                                                    <button type="submit" name="full_post"
                                                        class="btn btn-primary">Post</button>
                                                </form>
                                            </div>
                                            <?php } ?>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-6">
                                            <?php if (!isset($_POST['full_post'])) { ?>
                                            <?php

                                                        $sno = 0;
                                                        $sql = "SELECT * FROM aaa_quiz WHERE ccode = '$getccode' ORDER BY id";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $id = $row["id"];
                                                                $question = $row["question"];
                                                                $optA = $row["optA"];
                                                                $optB = $row["optB"];
                                                                $optC = $row["optC"];
                                                                $optD = $row["optD"];
                                                                $ans = $row["ans"];
                                                        ?>
                                            <div class="form-group skin-josh">
                                                <label class="col-md-2 control-label">Question
                                                    <?php echo $sno ?></label>
                                                <div class="col-md-10">
                                                    <label class=" control-label"><?php echo $question ?></label>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-1">
                                                    <?php if ($ans == "A") { ?>
                                                    <input type="checkbox" value="" checked="" disabled="">
                                                    <?php } else { ?>
                                                    <input type="checkbox" value="" disabled="">
                                                    <?php } ?>
                                                </div>
                                                <label class="col-md-1 control-label">A.</label>
                                                <div class="col-md-9">
                                                    <label class=" control-label"><?php echo $optA ?></label>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-1">
                                                    <?php if ($ans == "B") { ?>
                                                    <input type="checkbox" value="" checked="" disabled="">
                                                    <?php } else { ?>
                                                    <input type="checkbox" value="" disabled="">
                                                    <?php } ?>
                                                </div>
                                                <label class="col-md-1 control-label">B.</label>
                                                <div class="col-md-9">
                                                    <label class=" control-label"><?php echo $optB ?></label>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-1">
                                                    <?php if ($ans == "C") { ?>
                                                    <input type="checkbox" value="" checked="" disabled="">
                                                    <?php } else { ?>
                                                    <input type="checkbox" value="" disabled="">
                                                    <?php } ?>
                                                </div>
                                                <label class="col-md-1 control-label">C.</label>
                                                <div class="col-md-9">
                                                    <label class=" control-label"><?php echo $optC ?></label>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-1">
                                                    <?php if ($ans == "D") { ?>
                                                    <input type="checkbox" value="" checked="" disabled="">
                                                    <?php } else { ?>
                                                    <input type="checkbox" value="" disabled="">
                                                    <?php } ?>
                                                </div>
                                                <label class="col-md-1 control-label">D.</label>
                                                <div class="col-md-9">
                                                    <label class=" control-label"><?php echo $optD ?></label>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-md-3 control-label"></label>
                                                <div class="col-md-9" style="text-align: right">
                                                    <form method="POST" class="form-horizontal" action="#">
                                                        <input type="hidden" class="form-control" name="id"
                                                            value="<?php echo $id ?>">
                                                        <button type="submit" name="view"
                                                            class="btn btn-primary btn-xs">View</button>
                                                    </form>
                                                </div>
                                            </div>

                                            <?php
                                                            }
                                                        }

                                                        ?>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </section>
                            </div>
                            <?php
                                } else {
                                ?>
                            <div class="row">
                                <section class="panel">
                                    <header class="panel-heading">
                                        <h2 class="panel-title">Upload Question in pdf</h2>
                                    </header>
                                    <div class="panel-body">
                                        <div class="row">
                                            <?php
                                                    $msgsuces = $message = "";
                                                    $sessionreplace = str_replace("/", "_", $curtsession);
                                                    if (isset($_POST['upfile_quiz']) && !empty($_POST['upfile_quiz'])) {
                                                        $fileTmpPath = $_FILES['file_quiz']['tmp_name'];
                                                        $fileName = $_FILES['file_quiz']['name'];
                                                        $fileSize = $_FILES['file_quiz']['size'];
                                                        $fileType = $_FILES['file_quiz']['type'];
                                                        $fileNameCmps = explode(".", $fileName);
                                                        $fileExtension = strtolower(end($fileNameCmps));


                                                        $fileName = str_replace("'", "''", $fileName);
                                                        $fileName = filter_var($fileName, FILTER_SANITIZE_STRING);
                                                        $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                                                        $newFileName = $fileName;

                                                        $allowedfileExtensions = array('pdf');
                                                        if (in_array($fileExtension, $allowedfileExtensions)) {
                                                            // directory in which the uploaded file will be moved
                                                            if ($_FILES['file_quiz']['size'] / 1024 <= 2048) { // 2MB

                                                                $uploadFileDir = "classroom/quiz/" . $sessionreplace . "/" . $getccode . "/";

                                                                if (!file_exists($uploadFileDir)) {
                                                                    mkdir($uploadFileDir, 0777, true);
                                                                }


                                                                $dest_path = $uploadFileDir . $no_quiz . "." . $fileExtension;

                                                                if (move_uploaded_file($fileTmpPath, $dest_path)) {
                                                                    $sql = "UPDATE aaa_quiz_list SET file_url = '$dest_path' WHERE ccode = '$getccode' AND session1 = '$curtsession' AND quiz_no = '$no_quiz' ";
                                                                    $result = $conn8->query($sql);

                                                                    $msgsuces = 'File is successfully uploaded.';
                                                                } else {
                                                                    $message = 'Error in moving the file. Make sure you select correct file type.';
                                                                }
                                                            } else {
                                                                $message = 'Error: File should be maximun 2MB in size!';
                                                            }
                                                        } else {
                                                            $message = 'Error: Select Microsoft Word File file';
                                                        }
                                                    }

                                                    if (isset($_POST['save_q_pdf'])) {
                                                        $q_no = $_POST["q_no"];
                                                        $ans_pdf = $_POST["ans_pdf"];

                                                        $sql = "SELECT * FROM aaa_quiz_pdf WHERE ccode = '$getccode' AND q_number = '$q_no'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            $sql2 = "UPDATE aaa_quiz_pdf SET ans = '$ans_pdf' WHERE ccode = '$getccode' AND q_number = '$q_no'";
                                                            $result2 = $conn8->query($sql2);
                                                        } else {
                                                            $sql2 = "INSERT INTO aaa_quiz_pdf (ccode, q_number, ans)VALUE('$getccode', '$q_no', '$ans_pdf')";
                                                            $result2 = $conn8->query($sql2);
                                                        }
                                                    }

                                                    if (isset($_POST['pdf_post'])) {
                                                        //$cur_time = date("h:i:sa");
                                                        $cur_time = date("H:i:s");
                                                        $sql = "UPDATE aaa_quiz_list SET status = 'close', quiz_begin = 'end' WHERE ccode = '$getccode'";
                                                        $result = $conn8->query($sql);

                                                        $sql = "UPDATE aaa_quiz_list SET quiz_begin = 'start', time_start = '$cur_time' WHERE ccode = '$getccode' AND session1 = '$curtsession' AND quiz_no = '$no_quiz'";
                                                        $result = $conn8->query($sql);

                                                        $sql2 = "DELETE FROM aaa_current_quiz  WHERE ccode = '$getccode'";
                                                        $result2 = $conn8->query($sql2);
                                                    }
                                                    ?>
                                            <center>
                                                <h3 style="color:#0000ff"><?php echo $msgsuces ?></h3>
                                            </center>
                                            <center>
                                                <h5 style="color:#ff0000"><?php echo $message ?></h5>
                                            </center>
                                            <center>
                                                <h4>Your upload must be in pdf Format (".pdf")</h4>
                                            </center>
                                            <br><br>
                                            <form enctype="multipart/form-data" action="" method="post">
                                                <div class="form-group">
                                                    <label class="col-md-2 control-label" style="font-size: 14px">Upload
                                                        Quiz Question</label>
                                                    <div class="col-md-6">
                                                        <div class="fileupload fileupload-new"
                                                            data-provides="fileupload">
                                                            <div class="input-append">
                                                                <div class="uneditable-input">
                                                                    <i class="fa fa-file fileupload-exists"></i>
                                                                    <span class="fileupload-preview"></span>
                                                                </div>
                                                                <span class="btn btn-default btn-file">
                                                                    <span class="fileupload-exists">Change</span>
                                                                    <span class="fileupload-new">Select file</span>
                                                                    <input type="file" name="file_quiz" />
                                                                </span>
                                                                <a href="#" class="btn btn-default fileupload-exists"
                                                                    data-dismiss="fileupload">Remove</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-2">
                                                        <?php if (!isset($_POST['pdf_post'])) { ?>
                                                        <input type="submit" name="upfile_quiz" value="Upload File"
                                                            class="btn btn-primary btn-sm">
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <br>
                                        <hr class="separator" />
                                        <div class="row">
                                            <div class="col-lg-9">
                                                <?php //if(isset($_POST['upfile_quiz'])){ 
                                                        ?>
                                                <?php
                                                        $sql = "SELECT * FROM aaa_quiz_list WHERE  ccode = '$getccode' AND session1 = '$curtsession' AND  quiz_no = '$no_quiz'";
                                                        $result = $conn8->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $file_url = $row["file_url"];
                                                            }
                                                        }
                                                        ?>
                                                <iframe src="<?php echo $file_url ?>" width="100%"
                                                    height="500px"></iframe>
                                                <?php //} 
                                                        ?>
                                            </div>
                                            <div class="col-lg-3">
                                                <?php if (strlen($file_url) > 1) { ?>
                                                <form method="POST" class="form-horizontal" action="#">
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Question No:</label>
                                                        <div class="col-md-4" style="text-align: right">
                                                            <select name="q_no" class="form-control input-sm mb-md"
                                                                required="">
                                                                <option></option>
                                                                <?php
                                                                            $question_no = $_SESSION["question_no"];
                                                                            for ($x = 1; $x <= $question_no; $x++) {
                                                                                echo "<option>$x</option>";
                                                                            }
                                                                            ?>
                                                            </select>
                                                        </div>

                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-md-5 control-label">Answer:</label>
                                                        <div class="col-md-4" style="text-align: right">
                                                            <select name="ans_pdf" class="form-control input-sm mb-md"
                                                                required="">
                                                                <option></option>
                                                                <option>A</option>
                                                                <option>B</option>
                                                                <option>C</option>
                                                                <option>D</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-3" style="text-align: right">
                                                            <?php if (!isset($_POST['pdf_post'])) { ?>
                                                            <button type="submit" name="save_q_pdf"
                                                                class="btn btn-primary btn-xs">Save</button>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                </form>
                                                <?php if (!isset($_POST['pdf_post'])) { ?>
                                                <?php
                                                                $pdf_tot_q_no = 0;
                                                                $sql = "SELECT * FROM aaa_quiz_pdf WHERE ccode = '$getccode' ORDER BY q_number";
                                                                $result = $conn8->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $pdf_tot_q_no++;
                                                                        $q_number = $row["q_number"];
                                                                        $ans = $row["ans"];
                                                                ?>
                                                <div class="form-group">
                                                    <label
                                                        class="col-md-3 control-label"><?php echo $q_number ?>.</label>
                                                    <label class="col-md-3 control-label"><?php echo $ans ?></label>

                                                </div>
                                                <?php
                                                                    }
                                                                }
                                                                ?>
                                                <?php if ($pdf_tot_q_no == $question_no) { ?>
                                                <hr class="separator" />
                                                <center>
                                                    <h5>Click "post" to start quiz</h5>
                                                </center>
                                                <div class="row" style="text-align: center">
                                                    <form method="POST" class="form-horizontal" action="#">
                                                        <button type="submit" name="pdf_post"
                                                            class="btn btn-primary">Post</button>
                                                    </form>
                                                </div>
                                                <?php } ?>
                                                <?php } ?>
                                                <?php } ?>
                                            </div>
                                        </div>

                                    </div>
                                </section>
                            </div>
                            <?php
                                }
                            }
                            ?>
                        </div>

                    </div>

                </section>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>

    <!--Textarea Editor-->
    <script src="editor/js_/app.js" type="text/javascript"></script>
    <script src="editor/js_/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="editor/js_/ckeditor.js" type="text/javascript"></script>
    <script src="editor/js_/jquery.js" type="text/javascript"></script>
    <script src="editor/js_/editor1.js" type="text/javascript"></script>

    <script>
    (function($) {
        $(document).ready(function() {
            $.ajaxSetup({
                cache: false,
                beforeSend: function() {
                    $('#quiz_counter').hide();
                    $('#loading').show();
                },
                complete: function() {
                    $('#loading').hide();
                    $('#quiz_counter').show();
                },
                success: function() {
                    $('#loading').hide();
                    $('#quiz_counter').show();
                }
            });
            var $container = $("#quiz_counter");
            $container.load("ajax_save_rec/quiz_timer.php");
            var refreshId = setInterval(function() {
                $container.load('ajax_save_rec/quiz_timer.php');
            }, 9000);
        });
    })(jQuery);
    </script>



</body>

</html>

</html>
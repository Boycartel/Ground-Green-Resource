<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer_edit'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_D.js"> </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Graduation</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Graduation
                            </li>

                            <li class="active">
                                <strong>Students Record</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students Record
                        </div>
                        <div class="panel-body">
                            <form class="form-horizontal bucket-form" method="post" action="">
                                <div class="row">
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-6 control-label">Session of Graduation:</label>
                                            <div class="col-sm-6">
                                                <select class="scale form-control m-bot15" name="sessiongrad"
                                                    required="required">
                                                    <option></option>
                                                    <?php
                                                    $finalyear = substr($_SESSION['resultsession'], 0, 4);
                                                    for ($x = 2018; $x <= $finalyear; $x++) {
                                                        $x2 = $x + 1;
                                                    ?>
                                                    <option><?php echo $x . "/" . $x2; ?></option>

                                                    <?php } ?>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label">Semester of Graduation: </label>
                                            <div class="col-sm-7">
                                                <select class="state form-control m-bot15" name="semester"
                                                    required="required">
                                                    <option></option>
                                                    <option value='1ST'>1ST</option>
                                                    <option value='2ND'>2ND</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-sm-4 col-xs-12">
                                        <div class="form-group">
                                            <label class="col-sm-5 control-label"></label>
                                            <div class="col-sm-7">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </form>

                            <?php


                            if (isset($_POST["submit"])) {

                                $sessiongradpost = $_POST["sessiongrad"];
                                $semesterpost = $_POST["semester"];
                            ?>
                            <?php if ($_SESSION['InstType'] == "University") { ?>
                            <table id="myTable" style="font-size:12px" summary="" rules="groups" frame="hsides"
                                border="2" class="table mb-none">
                                <caption>Students List</caption>
                                <colgroup align="left"></colgroup>
                                <colgroup align="left"></colgroup>
                                <colgroup span="2"></colgroup>
                                <colgroup span="3" align="left"></colgroup>
                                <thead style='text-align:center'>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Department</th>
                                        <th>First Class (Male)</th>
                                        <th>First Class (Female)</th>
                                        <th>Second Class Upper (Male)</th>
                                        <th>Second Class Upper (Female)</th>
                                        <th>Second Class Lower (Male)</th>
                                        <th>Second Class Lower (Female)</th>
                                        <th>Third Class (Male)</th>
                                        <th>Third Class (Female)</th>
                                        <th>Pass (Male)</th>
                                        <th>Pass (Female)</th>
                                        <th>Total (Male)</th>
                                        <th>Total (Female)</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                            set_time_limit(5000);
                                            $sno = 0;
                                            $M_FirstClassTOT = $M_SecondUpperTOT = $M_SecondLowerTOT = $M_ThirdClassTOT = $M_PassClassTOT = 0;
                                            $F_FirstClassTOT = $F_SecondUpperTOT = $F_SecondLowerTOT = $F_ThirdClassTOT = $F_PassClassTOT = 0;
                                            $DeptTotMaleGrand = $DeptTotFemaleGrand = 0;

                                            $sql2 = "SELECT DeptCode, DeptName FROM deptcoding ORDER BY DeptName";
                                            //$sql2 = "SELECT DeptCode, DeptName FROM deptcoding WHERE DeptCode='MAT' ORDER BY DeptName";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $M_FirstClass = $M_SecondUpper = $M_SecondLower = $M_ThirdClass = $M_PassClass = 0;
                                                    $F_FirstClass = $F_SecondUpper = $F_SecondLower = $F_ThirdClass = $F_PassClass = 0;
                                                    $DeptTotMale = $DeptTotFemale = 0;
                                                    $sno++;
                                                    $DeptCode = $row2["DeptCode"];
                                                    $DeptName = $row2["DeptName"];

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($DeptCode);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    $sql3 = "SELECT * FROM scrutiny_senate WHERE session1 = '$sessiongradpost' AND semester = '$semesterpost' AND graduated = 'YES'";
                                                    $result3 = $conn_stu->query($sql3);
                                                    if ($result3->num_rows > 0) {
                                                        while ($row3 = $result3->fetch_assoc()) {
                                                            $Regn = $row3["Regn"];
                                                            $Sex = strtoupper($row3["sex"]);
                                                            $cgpa = $row3["CGPA"];
                                                            if ($cgpa >= 4.495) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_FirstClass = $M_FirstClass + 1;
                                                                    $M_FirstClassTOT = $M_FirstClassTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_FirstClass = $F_FirstClass + 1;
                                                                    $F_FirstClassTOT = $F_FirstClassTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            } elseif ($cgpa >= 3.495) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_SecondUpper = $M_SecondUpper + 1;
                                                                    $M_SecondUpperTOT = $M_SecondUpperTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_SecondUpper = $F_SecondUpper + 1;
                                                                    $F_SecondUpperTOT = $F_SecondUpperTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            } elseif ($cgpa >= 2.395) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_SecondLower = $M_SecondLower + 1;
                                                                    $M_SecondLowerTOT = $M_SecondLowerTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_SecondLower = $F_SecondLower + 1;
                                                                    $F_SecondLowerTOT = $F_SecondLowerTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            } elseif ($cgpa >= 1.495) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_ThirdClass = $M_ThirdClass + 1;
                                                                    $M_ThirdClassTOT = $M_ThirdClassTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_ThirdClass = $F_ThirdClass + 1;
                                                                    $F_ThirdClassTOT = $F_ThirdClassTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            } elseif ($cgpa >= 1) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_PassClass = $M_PassClass + 1;
                                                                    $M_PassClassTOT = $M_PassClassTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_PassClass = $F_PassClass + 1;
                                                                    $F_PassClassTOT = $F_PassClassTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    $conn_stu->close();
                                                    echo "<tr><td>$sno</td><td>$DeptName</td><td>$M_FirstClass</td><td>$F_FirstClass</td><td>$M_SecondUpper</td><td>$F_SecondUpper</td><td>$M_SecondLower</td><td>$F_SecondLower</td><td>$M_ThirdClass</td><td>$F_ThirdClass</td><td>$M_PassClass</td><td>$F_PassClass</td><td>$DeptTotMale</td><td>$DeptTotFemale</td></tr>\n";
                                                }
                                            }
                                            echo "<tr><td></td><td>Total</td><td>$M_FirstClassTOT</td><td>$F_FirstClassTOT</td><td>$M_SecondUpperTOT</td><td>$F_SecondUpperTOT</td><td>$M_SecondLowerTOT</td><td>$F_SecondLowerTOT</td><td>$M_ThirdClassTOT</td><td>$F_ThirdClassTOT</td><td>$M_PassClassTOT</td><td>$F_PassClassTOT</td><td>$DeptTotMaleGrand</td><td>$DeptTotFemaleGrand</td></tr>\n";
                                            ?>
                                </tbody>
                            </table>
                            <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                            <table id="myTable" style="font-size:12px" summary="" rules="groups" frame="hsides"
                                border="2" class="table mb-none">
                                <caption>Students List</caption>
                                <colgroup align="left"></colgroup>
                                <colgroup align="left"></colgroup>
                                <colgroup span="2"></colgroup>
                                <colgroup span="3" align="left"></colgroup>
                                <thead style='text-align:center'>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Department</th>
                                        <th>Distinction (Male)</th>
                                        <th>Distinction (Female)</th>
                                        <th>Upper Credit (Male)</th>
                                        <th>Upper Credit (Female)</th>
                                        <th>Lower Credit (Male)</th>
                                        <th>Lower Credit (Female)</th>
                                        <th>Pass (Male)</th>
                                        <th>Pass (Female)</th>
                                        <th>Total (Male)</th>
                                        <th>Total (Female)</th>


                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                            set_time_limit(5000);
                                            $sno = 0;
                                            $M_FirstClassTOT = $M_SecondUpperTOT = $M_SecondLowerTOT = $M_ThirdClassTOT = $M_PassClassTOT = 0;
                                            $F_FirstClassTOT = $F_SecondUpperTOT = $F_SecondLowerTOT = $F_ThirdClassTOT = $F_PassClassTOT = 0;
                                            $DeptTotMaleGrand = $DeptTotFemaleGrand = 0;

                                            $sql2 = "SELECT DeptCode, DeptName FROM deptcoding ORDER BY DeptName";
                                            //$sql2 = "SELECT DeptCode, DeptName FROM deptcoding WHERE DeptCode='MAT' ORDER BY DeptName";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $M_FirstClass = $M_SecondUpper = $M_SecondLower = $M_ThirdClass = $M_PassClass = 0;
                                                    $F_FirstClass = $F_SecondUpper = $F_SecondLower = $F_ThirdClass = $F_PassClass = 0;
                                                    $DeptTotMale = $DeptTotFemale = 0;
                                                    $sno++;
                                                    $DeptCode = $row2["DeptCode"];
                                                    $DeptName = $row2["DeptName"];

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($DeptCode);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    $sql3 = "SELECT * FROM scrutiny_senate WHERE session1 = '$sessiongradpost' AND semester = '$semesterpost' AND graduated = 'YES'";
                                                    $result3 = $conn_stu->query($sql3);
                                                    if ($result3->num_rows > 0) {
                                                        while ($row3 = $result3->fetch_assoc()) {
                                                            $Regn = $row3["Regn"];
                                                            $Sex = strtoupper($row3["sex"]);
                                                            $cgpa = $row3["CGPA"];

                                                            if ($cgpa >= 3.5) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_FirstClass = $M_FirstClass + 1;
                                                                    $M_FirstClassTOT = $M_FirstClassTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_FirstClass = $F_FirstClass + 1;
                                                                    $F_FirstClassTOT = $F_FirstClassTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            } elseif ($cgpa >= 3) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_SecondUpper = $M_SecondUpper + 1;
                                                                    $M_SecondUpperTOT = $M_SecondUpperTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_SecondUpper = $F_SecondUpper + 1;
                                                                    $F_SecondUpperTOT = $F_SecondUpperTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            } elseif ($cgpa >= 2.5) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_SecondLower = $M_SecondLower + 1;
                                                                    $M_SecondLowerTOT = $M_SecondLowerTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_SecondLower = $F_SecondLower + 1;
                                                                    $F_SecondLowerTOT = $F_SecondLowerTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            } elseif ($cgpa >= 2) {
                                                                if ($Sex == "M" || $Sex == "MALE") {
                                                                    $M_PassClass = $M_PassClass + 1;
                                                                    $M_PassClassTOT = $M_PassClassTOT + 1;
                                                                    $DeptTotMale++;
                                                                    $DeptTotMaleGrand++;
                                                                }
                                                                if ($Sex == "F" || $Sex == "FEMALE") {
                                                                    $F_PassClass = $F_PassClass + 1;
                                                                    $F_PassClassTOT = $F_PassClassTOT + 1;
                                                                    $DeptTotFemale++;
                                                                    $DeptTotFemaleGrand++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    $conn_stu->close();
                                                    echo "<tr><td>$sno</td><td>$DeptName</td><td>$M_FirstClass</td><td>$F_FirstClass</td><td>$M_SecondUpper</td><td>$F_SecondUpper</td><td>$M_SecondLower</td><td>$F_SecondLower</td><td>$M_PassClass</td><td>$F_PassClass</td><td>$DeptTotMale</td><td>$DeptTotFemale</td></tr>\n";
                                                }
                                            }
                                            echo "<tr><td></td><td>Total</td><td>$M_FirstClassTOT</td><td>$F_FirstClassTOT</td><td>$M_SecondUpperTOT</td><td>$F_SecondUpperTOT</td><td>$M_SecondLowerTOT</td><td>$F_SecondLowerTOT</td><td>$M_PassClassTOT</td><td>$F_PassClassTOT</td><td>$DeptTotMaleGrand</td><td>$DeptTotFemaleGrand</td></tr>\n";
                                            ?>
                                </tbody>
                            </table>
                            <?php } ?>
                            <br><br>
                            <div class="form-group">
                                <!-- Buttons -->
                                <div class="col-lg-offset-2 col-lg-9" style="text-align: right;">
                                    <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                        class="btn btn-primary">Download</a>
                                </div>
                            </div>

                            <?php
                            }    //End Submit
                            ?>


                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();

                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
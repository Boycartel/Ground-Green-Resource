<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: Home_Staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Setup</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>
                            <li>
                                Course Setup
                            </li>
                            <li class="active">
                                <strong>Submit</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Setup
                        </div>
                        <?php $_SESSION['loadformval'] = "YES"; ?>
                        <div class="panel-body table-responsive">
                            <div>
                                <h2 style="color:#00C"><strong>
                                        <center>Record Saved</center>
                                    </strong></h2>
                                <?php
        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
        if ($conn2->connect_error) {
            die("Connection failed: " . $conn2->connect_error);
        }
                                $numbschCurri = $_SESSION['numbschCurri'];
                                $dept = $_SESSION['deptcode'];
                                $deptoptn = "NOP";
                                $dept_db = $_SESSION['deptdb'] . $dept;
                                try {
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                } catch (PDOException $e) {
                                }


                                if (!empty($_POST["chosen"])) {
                                    foreach ($_POST["chosen"] as $key => $value) {

                                        //echo $_POST["chosen"][$key];


                                        $ccode = $_POST["ccode"][$key];
                                        $CTitle = str_replace("'", "''", $_POST["CTitle"][$key]);
                                        $CUnit = $_POST["CUnit"][$key];
                                        $SemTaken = $_POST["SemTaken"][$key];
                                        $level = $_POST["level"][$key];
                                        $nature = $_POST["Nature"][$key];
                                        $Ctype = $_POST["Ctype"][$key];
                                        if ($_SESSION['deptoption'] == "YES") {
                                            $deptoptn = $_POST["deptoptn"][$key];
                                            $sql = "SELECT * FROM deptcourses WHERE CCode = '$ccode' AND dept = '$dept' AND deptoption = '$deptoptn'";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows == 0) {

                                                $sql2 = "INSERT INTO deptcourses (CCode, CTitle, CUnit, SemTaken, Nature, level, dept, deptoption, type1) VALUES ('$ccode', '$CTitle', '$CUnit', '$SemTaken', '$nature', '$level', '$dept', '$deptoptn', '$Ctype')";
                                                $result2 = $conn->query($sql2);
                                            }
                                        } else {
                                            $sql = "SELECT * FROM deptcourses WHERE CCode = '$ccode' AND dept = '$dept'";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows == 0) {

                                                $sql2 = "INSERT INTO deptcourses (CCode, CTitle, CUnit, SemTaken, Nature, level, dept, deptoption, type1) VALUES ('$ccode', '$CTitle', '$CUnit', '$SemTaken', '$nature', '$level', '$dept', '$deptoptn', '$Ctype')";
                                                $result2 = $conn->query($sql2);
                                            }
                                        }

                                        $sql = "SELECT * FROM gencourses WHERE C_codding = '$ccode'";
                                        $result = $conn_stu->query($sql);
                                        if ($result->num_rows == 0) {

                                            $sql2 = "INSERT INTO gencourses (C_codding, C_title, credit, semester, Nature1, Level1) VALUES ('$ccode', '$CTitle', '$CUnit', '$SemTaken', 'XXXX', '$level')";
                                            $result2 = $conn_stu->query($sql2);
                                        }
                                    }
                                }

                                $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' ORDER BY deptoption, level, SemTaken, CCode";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                ?>
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th>Course Code</th>
                                            <th>Course Title</th>
                                            <th>Unit</th>
                                            <th>Semester</th>
                                            <th>Nature</th>
                                            <th>Level</th>
                                            <?php if ($_SESSION['deptoption'] == "YES") { ?>
                                            <th>Department Option</th>
                                            <?php } ?>
                                            <?php if ($numbschCurri > 1) { ?>
                                            <th>Curriculum</th>
                                            <?php } ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            // output data of each row
                                            while ($row = $result->fetch_assoc()) {
                                                $id = $row["id"];
                                                $ccode = $row["CCode"];
                                                $CTitle = $row["CTitle"];
                                                $CUnit = $row["CUnit"];
                                                $SemTaken = $row["SemTaken"];
                                                $Nature = $row["Nature"];
                                                $level = $row["level"];
                                                $type1 = $row["type1"];

                                                $sql2 = "SELECT * FROM sch_curriculum WHERE curri_Code = '$type1'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $type1 = $row2["curri_Title"];
                                                    }
                                                }
                                                if ($_SESSION['deptoption'] == "YES") {
                                                    $deptoption = $row["deptoption"];
                                                    $sql2 = "SELECT * FROM dept_option WHERE deptcode = '$dept' AND Opt_Code = '$deptoption'";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result2->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $opttitle = $row2["Opt_Title"];
                                                        }
                                                    }
                                                }
                                                if ($_SESSION['InstType'] == "University") {
                                                    if ($_SESSION['deptoption'] == "YES") {
                                                        echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$level</td><td>$opttitle</td>";
                                                        if ($numbschCurri > 1) {
                                                            echo "<td>$type1</td>";
                                                        }
                                                        echo "</tr>\n";
                                                    } else {
                                                        echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$level</td>";
                                                        if ($numbschCurri > 1) {
                                                            echo "<td>$type1</td>";
                                                        }
                                                        echo "</tr>\n";
                                                    }
                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                    if ($row["level"] == 100) {
                                                        $stulevel2 = "ND I";
                                                    } elseif ($row["level"] == 200) {
                                                        $stulevel2 = "ND II";
                                                    } elseif ($row["level"] == 300) {
                                                        $stulevel2 = "HND I";
                                                    } elseif ($row["level"] == 400) {
                                                        $stulevel2 = "HND II";
                                                    }
                                                    if ($_SESSION['deptoption'] == "YES") {
                                                        echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$stulevel2</td><td>$opttitle</td>";
                                                        if ($numbschCurri > 1) {
                                                            echo "<td>$type1</td>";
                                                        }
                                                        echo "</tr>\n";
                                                    } else {
                                                        echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$stulevel2</td>";
                                                        if ($numbschCurri > 1) {
                                                            echo "<td>$type1</td>";
                                                        }
                                                        echo "</tr>\n";
                                                    }
                                                } else {
                                                }
                                            }
                                            ?>
                                    </tbody>
                                </table>

                                <?php
                                }
                                $conn->close();	
                                $conn2->close();	
                                ?>

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>


</body>

</html>
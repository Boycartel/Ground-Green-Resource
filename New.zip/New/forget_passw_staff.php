<?php
require_once 'includes/db_connect2.php';
require 'vendor/autoload.php'; // Include the PHPMailer autoloader

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//require 'vendor/autoload.php'; // Include Composer's autoloader
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>School Portal</title>
    <link rel="shortcut icon" href="img/logo.ico">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">


    <div class="middle-box text-center animated fadeInDown">
        <h2>Reset Password</h2>

        <div class="error-desc">
            Enter your file number
            <form class="form-inline m-t" role="form" method="post">
                <div class="form-group">
                    <input type="text" name="staffid" class="form-control" placeholder="File Number">
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>


    </div>
    <div>
        <?php
        if (isset($_POST['submitemail'])) {

            /* $to = $_POST['sendemail'];
            $subject = "New Password";
            $message = "This is an OTP number for you to reset your password:    ";
            $message .= $_POST['sendtoken'];
            $headers = "From: eresults@futminna.edu.ng";
            // Sending email
            if (mail($to, $subject, $message, $headers)) {
                $sno = $_POST['sno'];
                $sendtoken = $_POST['sendtoken'];
                $sql = "UPDATE users SET pwd_reset_token = '$sendtoken' WHERE sn='$sno'";
                $result = $conn->query($sql);

                echo "<h2  class='alert alert-success' style='text-align: center;'>";
                echo 'An OTP number has been sent to the email for you to reset your password<br>';
                echo $_POST['sendemail'];
                echo "<br>";
                echo "Check your inbox or spam folder";
                echo "<br>";
                echo "<a href= 'password_reset.php' class='btn btn-primary'>Reset</a>";
                echo "</h2>";
            } else {

                echo "<h2 class='alert alert-danger' style='text-align: center;'>";
                echo 'Unable to send email. Please try again.';
                echo "</h2>";
            } */




            /* $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->SMTPDebug = 0;                                   // Enable verbose debug output
                $mail->isSMTP();                                        // Set mailer to use SMTP
                $mail->Host       = '208-115-218-166.cprapid.com';                 // Specify main and backup SMTP servers
                $mail->SMTPAuth   = true;                               // Enable SMTP authentication
                $mail->Username   = 'eresults@naub.edu.ng';           // SMTP username
                $mail->Password   = 'naub@2024';                    // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;     // Enable TLS encryption, `ssl` also accepted
                $mail->Port       = 465;                                // TCP port to connect to

                //Recipients
                $mail->setFrom('eresults@naub.edu.ng', 'Mailer');
                $mail->addAddress('adamualhaj@gmail.com', 'Joe User'); // Add a recipient

                // Content
                $mail->isHTML(true);                                    // Set email format to HTML
                $mail->Subject = 'Here is the subject';
                $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                $mail->send();
                echo 'Message has been sent';
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
 */


            /* $host = 'mail.privateemail.com';
            $username = 'support@sendgridpro.com';
            $pwd = 'hello99...';

            $senderEmail = 'support@sendgridpro.com';
            $senderName = 'Nigerian Army University Biu';
            $recipientEmail = 'adamualhaj@gmail.com';
            $recipientName = 'Adamu Mohammed';

            $mailSubject = 'Test email';
            $mailBody = '<p>This is the HTML message body.</p>';

            $mail = new PHPMailer(true); // Create a new PHPMailer instance

            try {
                //Server settings
                $mail->SMTPDebug = 0; // Enable verbose debug output (change to 2 for more detailed debugging)
                $mail->isSMTP(); // Set mailer to use SMTP
                $mail->Host = $host; // Specify main and backup SMTP servers
                $mail->SMTPAuth = true; // Enable SMTP authentication
                $mail->Username = $username; // SMTP username
                $mail->Password = $pwd; // SMTP password
                $mail->SMTPSecure = 'tls'; // Enable TLS encryption, 'ssl' also accepted
                $mail->Port = 587; // TCP port to connect to

                //Recipients
                $mail->setFrom($senderEmail, $senderName); // Sender's email address and name
                $mail->addAddress($recipientEmail, $recipientName); // Recipient's email address and name

                //Content
                $mail->isHTML(true); // Set email format to HTML
                $mail->Subject = $mailSubject;
                $mail->Body    = $mailBody;

                $mail->send();
                echo 'Message has been sent';
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            } */
        }
        ?>
    </div>
    <?php if (isset($_POST['submit'])) { ?>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="col-lg-2">

        </div>
        <div class="col-lg-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 style="text-align: center;">Click Send button to send OTP to your email</h3>
                </div>
                <div class="panel-body">
                    <?php
                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        $staffid = $_POST['staffid'];
                        //$staffid = stripslashes($staffid);
                        //$staffid = mysqli_real_escape_string($conn, $staffid);
                        $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $sn = $row["sn"];
                                $names = $row["full_name"];
                                $email = $row["emailAdd"];
                                $active_status = $row['active_status'];
                            }
                            //$token = md5(rand() . time());
                            $token = rand(10000, 100000);
                        }
                        $conn->close();
                        ?>

                    <form role="form" enctype="multipart/form-data" method="post" action="">
                        <div class="form-group">
                            <label class="col-lg-5 control-label">PF Number</label>
                            <div class="col-lg-7">
                                <?php echo strtoupper($staffid) ?>
                            </div>
                            <br />
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="col-lg-5 control-label">Staff Name:</label>
                            <div class="col-lg-7">
                                <?php echo  $names ?>
                            </div>
                            <br />
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="col-lg-5 control-label">Staff email:</label>
                            <div class="col-lg-7">
                                <?php echo  $email ?>
                                <input type="hidden" class="form-control" style="color:#000000" name="sendemail"
                                    value="<?php echo  $email ?>">
                                <input type="hidden" class="form-control" style="color:#000000" name="sno"
                                    value="<?php echo  strtoupper($sn) ?>">
                                <input type="hidden" class="form-control" style="color:#000000" name="sendtoken"
                                    value="<?php echo  $token ?>">
                            </div>
                            <br />
                        </div>
                        <br /><br>
                        <?php if ($active_status == 0) { ?>
                        <h2 class='alert alert-danger' style='text-align: center;'>You are NOT an Active Member</h2>
                        <?php } else { ?>
                        <div class="form-group">
                            <label class="col-lg-5 control-label"></label>
                            <div class="col-lg-offset-2 col-lg-7" style="text-align: right;">
                                <button type="submit" name="submitemail" class="btn btn-primary">Send <i
                                        class="fa fa-send"></i></button>

                            </div>
                        </div>
                        <?php } ?>
                    </form>



                </div>
            </div>

        </div>
        <div class="col-lg-2">

        </div>

    </div>
    <?php } ?>
    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Courseware</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Courseware</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Courseware
                        </div>
                        <div class="panel-body">
                            <div class="col-md-1">
                            </div>
                            <div class="col-md-10">
                                <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
                                ?>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label" for="inputSuccess">Select Course:</label>
                                        <div class="col-md-6">
                                            <select class="form-control mb-md" name="courses">
                                                <?php
                                                $_SESSION['downlcurse'] = "";
                                                $_SESSION['downlsession'] = "";

                                                $curtsession = $_SESSION['corntsession'];
                                                $savesession = substr($curtsession, 0, 4) . "_" . substr($curtsession, -4);
                                                $regid = $_SESSION['regid'];

                                                $sql = "SELECT * FROM courses_register_" . $savesession . " WHERE Regn1 = '$regid' ORDER BY CCode";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    // output data of each row
                                                    while ($row = $result->fetch_assoc()) {
                                                        $ccode = $row["CCode"];
                                                        $ctitle = $row["CTitle"];
                                                        echo "<option value=$ccode>$ccode $ctitle</option>";
                                                    }
                                                }
                                                ?>
                                            </select>

                                        </div>
                                        <div class="col-md-2">
                                            <input type="submit" value="Submit" name="submit"
                                                class='btn btn-primary btn-sm'>
                                        </div>
                                    </div>
                                </form>
                                <hr class="separator" />
                                <table class="table mb-none">
                                    <thead>
                                        <tr>

                                            <th>Course Code</th>
                                            <th>Material Title</th>
                                            <th>Click to Download</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php


                                        if (isset($_POST["submit"])) {
                                            $thelist = "";
                                            $fname = "";
                                            $course = $_POST["courses"];
                                            $ckfolder = "Content/$savesession/$course";
                                            if (is_dir($ckfolder)) {
                                                if ($handle = opendir('Content/' . $savesession . '/' . $course)) {
                                                    while (false !== ($file = readdir($handle))) {
                                                        if ($file != "." && $file != "..") {
                                                            //$thelist .= '<li><a href="'.$file.'">'.$file.'</a></li>';
                                                            $sql = "SELECT * FROM courseware WHERE savepath = '$file'";
                                                            $result = $conn->query($sql);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $fname = $row["bookname"];
                                                                }
                                                            }

                                                            $thelist .= "<a href='download_courseware.php?filename1=" . $file . "'>$file</a>";
                                                            echo "<tr><td>$course</td><td>$fname</td><td>$thelist</td></tr>\n";
                                                            $thelist = "";
                                                        }
                                                    }
                                                    closedir($handle);
                                                    $_SESSION['downlcurse'] = $course;
                                                    $_SESSION['downlsession'] = $savesession;
                                                }
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                                <?php
$conn->close();
?>
                            </div>
                            <div class="col-md-1">
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
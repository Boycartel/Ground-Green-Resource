<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}
$deptname = $_SESSION['deptname'];
?>


<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <title><?php echo $_SESSION['instcode'] ?> Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword"
        content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>


    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $cursession = $_SESSION['resultsession'];
    $resultsemester = $_SESSION['resultsemester'];
    $dept = $_SESSION['deptcode'];

    $_SESSION['yesCurri'] = "NO";
    $yesCurri = "NO";
    $sql = "SELECT DeptName, DeptCode, curriculum FROM deptcoding WHERE DeptCode = '$dept'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            //$deptname = $row["DeptName"];
            $yesCurri = $row["curriculum"];
            $_SESSION['yesCurri'] = $yesCurri;
        }
    }

    ?>
    <div class="container">
        <h1 class="mt-5 mb-5 text-center text-primary"><?php echo $deptname ?> Department</h1>
        <?php if ($yesCurri == "YES") { ?>


        <?php if (isset($_POST["submitcurri"])) { ?>
        <?php
                if (isset($_POST["submitcurri"])) {
                    $curri = $_POST["curri"];
                    $_SESSION['curri'] = $curri;
                    if ($_SESSION['InstType'] == "Polytechnic") {
                        $prog = $_POST["prog"];
                        $_SESSION['prog'] = $prog;
                    }
                } else {
                    $curri = $_SESSION['curri'];
                    if ($_SESSION['InstType'] == "Polytechnic") {
                        $prog = $_SESSION['prog'];
                    }
                }

                $sql = "SELECT * FROM dept_curriculum WHERE curri_Code = '$curri' AND deptcode = '$dept'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $curriname2 = $row["curri_Title"];
                    }
                }
                ?>
        <h2 class="mt-5 mb-5 text-center text-primary"><?php echo $curriname2 ?></h2>
        <div class="card">
            <div class="card-header">Edit Minimum Credit Requirements</div>
            <div class="card-body">
                <div class="table-responsive">

                    <table class="table table-striped table-bordered">
                        <thead style='text-align:center'>
                            <tr>
                                <th>Requirement</th>

                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                <th>NON DE 100 Level</th>
                                <th>DE 200 Level</th>
                                <th>DE 300 Level</th>
                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                <th>Credit Unit</th>
                                <th>Programme</th>
                                <?php } ?>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                    $sno = 0;
                                    if ($_SESSION['InstType'] == "University") {
                                        $sql = "SELECT * FROM requirement_tab WHERE DeptCode = '$dept' AND curri_Code = '$curri'";
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        $sql = "SELECT * FROM requirement_tab_poly WHERE DeptCode = '$dept' AND curri_Code = '$curri' AND prog = '$prog'";
                                    }

                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $sno++;
                                            $Requirement_Name = $row["Requirement_Name"];

                                            echo "<tr><td>$Requirement_Name</td>";
                                            if ($_SESSION['InstType'] == "University") {
                                                echo '<td><a href="#" class="Requirement_100" id="Requirement_100_' . $row["id"] . '" data-type="text" data-pk="' . $row["id"] . '" data-url="inline_edit/process_requirement.php" data-name="Requirement_100">' . $row["Requirement_100"] . '</a></td>';
                                                echo '<td><a href="#" class="Requirement_DE200" id="Requirement_DE200_' . $row["id"] . '" data-type="text" data-pk="' . $row["id"] . '" data-url="inline_edit/process_requirement.php" data-name="Requirement_DE200">' . $row["Requirement_DE200"] . '</a></td>';
                                                echo '<td><a href="#" class="Requirement_DE300" id="Requirement_DE300_' . $row["id"] . '" data-type="text" data-pk="' . $row["id"] . '" data-url="inline_edit/process_requirement.php" data-name="Requirement_DE300">' . $row["Requirement_DE300"] . '</a></td>';
                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                $prog = $row["prog"];
                                                echo '<td><a href="#" class="Requirement_100" id="Requirement_100_' . $row["id"] . '" data-type="text" data-pk="' . $row["id"] . '" data-url="inline_edit/process_requirement.php" data-name="Requirement_100">' . $row["Requirement_100"] . '</a></td>';
                                                echo "<td>$Requirement_Name</td>";
                                            }
                                            echo "</tr>\n";
                                        }
                                    }

                                    ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php } else { ?>
        <form class="form-horizontal form-bordered" method="post">
            <div class="row">

                <label class="control-label col-lg-2" for="content">Select
                    Curriculum:</label>
                <div class="col-lg-4">
                    <select class="form-control" style="color:#000000" name="curri">
                        <option value="SelectItem">Select Item</option>
                        <?php
                                //$cat = $_SESSION['cat'];
                                $dept = $_SESSION['deptcode'];

                                $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept'";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $curricode2 = $row["curri_Code"];
                                        $curriname2 = $row["curri_Title"];
                                        echo "<option value=$curricode2>$curriname2</option>";
                                    }
                                }
                                ?>

                    </select>
                </div>
                <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                <label class="control-label col-lg-2" for="content">Select
                    Programme:</label>
                <div class="col-lg-2">
                    <select class="form-control" style="color:#000000" name="prog" required>
                        <option value="">Select Item</option>
                        <option value="ND">ND</option>
                        <option value="HND">HND</option>
                    </select>
                </div>
                <?php } ?>
                <div class="col-lg-2">
                    <button type="submit" name="submitcurri" class="btn btn-primary btn-sm">Submit</button>

                </div>

            </div>
        </form>
        <?php } ?>
        <?php } else { ?>
        <div class="card">
            <div class="card-header">Edit Minimum Credit Requirements</div>
            <div class="card-body">
                <div class="table-responsive">

                    <table class="table table-striped table-bordered">
                        <thead style='text-align:center'>
                            <tr>
                                <th>Requirement</th>

                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                <th>NON DE 100 Level</th>
                                <th>DE 200 Level</th>
                                <th>DE 300 Level</th>
                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                <th>Credit Unit</th>
                                <th>Programme</th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sno = 0;
                                if ($_SESSION['InstType'] == "University") {
                                    $sql = "SELECT * FROM requirement_tab WHERE DeptCode = '$dept'";
                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                    $sql = "SELECT * FROM requirement_tab_poly WHERE DeptCode = '$dept' AND prog = '$prog'";
                                }

                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $sno++;
                                        $Requirement_Name = $row["Requirement_Name"];


                                        echo "<tr><td>$Requirement_Name</td>";
                                        if ($_SESSION['InstType'] == "University") {
                                            echo '<td><a href="#" class="Requirement_100" id="Requirement_100_' . $row["id"] . '" data-type="text" data-pk="' . $row["id"] . '" data-url="inline_edit/process_requirement.php" data-name="Requirement_100">' . $row["Requirement_100"] . '</a></td>';
                                            echo '<td><a href="#" class="Requirement_DE200" id="Requirement_DE200_' . $row["id"] . '" data-type="text" data-pk="' . $row["id"] . '" data-url="inline_edit/process_requirement.php" data-name="Requirement_DE200">' . $row["Requirement_DE200"] . '</a></td>';
                                            echo '<td><a href="#" class="Requirement_DE300" id="Requirement_DE300_' . $row["id"] . '" data-type="text" data-pk="' . $row["id"] . '" data-url="inline_edit/process_requirement.php" data-name="Requirement_DE300">' . $row["Requirement_DE300"] . '</a></td>';
                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                            $prog = $row["prog"];
                                            echo '<td><a href="#" class="Requirement_100" id="Requirement_100_' . $row["id"] . '" data-type="text" data-pk="' . $row["id"] . '" data-url="inline_edit/process_requirement.php" data-name="Requirement_100">' . $row["Requirement_100"] . '</a></td>';
                                            echo "<td>$Requirement_Name</td>";
                                        }
                                        echo "</tr>\n";
                                    }
                                }

                                ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php } ?>
        <?php
$conn->close();
?>
        <br />
        <br />
    </div>
</body>

</html>

<script>
//For Requirement_100 Table column Data

const Requirement_100 = document.getElementsByClassName('Requirement_100');

for (var count = 0; count < Requirement_100.length; count++) {
    const Requirement_100_data = document.getElementById(Requirement_100[count].getAttribute('id'));

    const Requirement_100_popover = new DarkEditable(Requirement_100_data);
}

//For Requirement_DE200 Table column Data

const Requirement_DE200 = document.getElementsByClassName('Requirement_DE200');

for (var count2 = 0; count2 < Requirement_DE200.length; count2++) {
    const Requirement_DE200_data = document.getElementById(Requirement_DE200[count2].getAttribute('id'));

    const Requirement_DE200_popover = new DarkEditable(Requirement_DE200_data);
}

//For Requirement_DE300 Table column Data

const Requirement_DE300 = document.getElementsByClassName('Requirement_DE300');

for (var count3 = 0; count3 < Requirement_DE300.length; count3++) {
    const Requirement_DE300_data = document.getElementById(Requirement_DE300[count3].getAttribute('id'));

    const Requirement_DE300_popover = new DarkEditable(Requirement_DE300_data);
}
</script>
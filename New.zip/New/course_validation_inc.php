<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

if ($_SESSION['course_validation'] == false) {
    header('Location: Home_Staff.php');
}
//$_SESSION['loadformval']="NO";
$corntsession = $_SESSION['corntsession'];
$tot1stoutunit = $tot2ndoutunit = 0;
$validate = "";
$stuname = "";
$_SESSION['valcoment'] = "";
//$getvalcoment = "";
//$cat = $_SESSION['cat2'];


$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
            if ($conn2->connect_error) {
                die("Connection failed: " . $conn2->connect_error);
            }

$dept = strtolower($_SESSION['selectdept']);
//$dept = strtolower($_SESSION['valdept']);

$regid = $_GET['q'];
$sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
$result = $conn2->query($sql);
$name = "";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='row'>";
        echo "<div class='col-lg-9'>";
        echo "Matric No:" . $row['matric_no'];
        echo "<br>";
        $name = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
        $name = strtolower($name);
        $name = ucwords($name);
        echo "Name:  " . $name;
        echo "</div>";
        echo "</div>";
    }
}
//echo $_SESSION['valdept'];
$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}
$sql = "SELECT * FROM hod_list WHERE matricno = '$regid'";
$result = $conn_stu->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($_SESSION["seloption"] == "LevelAdviceVal") {
            $validate = $row['LevelAdvice'];
            $getvalcat = "LevelAdvice";
            $getvalcoment = $row['LAComment'];
            $getfieldcomt = "LAComment";
            $getfieldName = "LAName";
        } elseif ($_SESSION["seloption"] == "HODVal") {
            $validate = $row['HOD'];
            $getvalcat = "HOD";
            $getvalcoment = $row['HODComment'];
            $getfieldcomt = "HODComment";
            $getfieldName = "HODName";
        } elseif ($cat_HOD == "YES") {
            $validate = $row['HOD'];
            $getvalcat = "HOD";
            $getvalcoment = $row['HODComment'];
            $getfieldcomt = "HODComment";
            $getfieldName = "HODName";
        } elseif ($cat_L100 == "YES" || $cat_L200 == "YES" || $cat_L300 == "YES" || $cat_L400 == "YES" || $cat_L500 == "YES" || $cat_spill_over == "YES") {
            $validate = $row['LevelAdvice'];
            $getvalcat = "LevelAdvice";
            $getvalcoment = $row['LAComment'];
            $getfieldcomt = "LAComment";
            $getfieldName = "LAName";
        }
    }
}
$corntsession2 = str_replace("/", "_", $corntsession);
$sql = "SELECT * FROM courses_register_" . $corntsession2 . " WHERE Regn1 = '$regid' AND SemTaken = '1ST'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
?>

<p>
    <center>1ST Semester Courses</center>
</p>
<table class="table mb-none">
    <thead>
        <tr>
            <th>Course Code</th>
            <th>Course Title</th>
            <th>Unit</th>
            <th>Semester</th>
            <th>Status</th>

        </tr>
    </thead>
    <tbody>


        <?php
            while ($row = $result->fetch_assoc()) {
                $id = $row["sn"];
                $ccode = $row["CCode"];
                $CTitle = $row["CTitle"];
                $CUnit = $row["CUnit"];
                $SemTaken = $row["SemTaken"];
                $Nature = $row["Nature"];


                $tot1stoutunit += $row['CUnit'];


                echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['Nature']}</td></tr>\n";
            }
            ?>
    </tbody>
</table>

<?php

}
//$conn->close();
echo "<center> Total Credit Units : $tot1stoutunit</center>";
?>

<br /><br />
<?php



$sql = "SELECT * FROM courses_register_" . $corntsession2 . " WHERE Regn1 = '$regid' AND SemTaken = '2ND'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
?>
<p>
    <center>2ND Semester Courses</center>
</p>
<table class="table mb-none">
    <thead>
        <tr>
            <th>Course Code</th>
            <th>Course Title</th>
            <th>Unit</th>
            <th>Semester</th>
            <th>Status</th>

        </tr>
    </thead>
    <tbody>


        <?php
            while ($row = $result->fetch_assoc()) {

                $id = $row["sn"];
                $ccode = $row["CCode"];
                $CTitle = $row["CTitle"];
                $CUnit = $row["CUnit"];
                $SemTaken = $row["SemTaken"];
                $Nature = $row["Nature"];

                $tot2ndoutunit += $row['CUnit'];


                echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['Nature']}</td></tr>\n";
            }
            ?>
    </tbody>
</table>

<?php

}
$conn->close();
$conn2->close();
$conn_stu->close();
?>
<center> Total Credit Units : <?php echo $tot2ndoutunit ?></center>


<br>
<form class='form-horizontal' method='post' action='course_validation.php'>
    <div class='form-group'>
        <label class='control-label col-lg-3' for='comment'><strong>Comment:</strong></label>
        <div class='col-lg-7'>
            <input class='form-control' name='comment' id='comment' value='<?php echo $getvalcoment ?>'></input>

            <input type='hidden' value='<?php echo $regid ?>' name='valregid'>
            <input type='hidden' value='<?php echo $validate ?>' name='valcat'>
            <input type='hidden' value='<?php echo $getvalcat ?>' name='getvalcat'>
            <input type='hidden' value='<?php echo $getfieldcomt ?>' name='getfieldcomt'>
            <input type='hidden' value='<?php echo $getfieldName ?>' name='getfieldName'>
        </div>
        <div class='col-lg-2'>
            <button type='submit' name='sumcomment' class='btn btn-default btn-xs'>Save Comment</button>
        </div>
    </div>
    <div class='form-group'>
        <label class='control-label col-lg-3' for='comment'><strong></strong></label>
        <div class='col-lg-7'>

            <?php if ($validate == "Yet") { ?>
            <button type='submit' name='validate' class='btn btn-primary btn-sm'>Validate and Save Comment</button>
            <input type='hidden' value='Validate' name='valcoment'>
            <?php } else { ?>
            <button type='submit' name='validate' class='btn btn-primary btn-sm'>Cancel Validation and Save
                Comment</button>
            <input type='hidden' value='Yet' name='valcoment'>
            <?php } ?>
        </div>
        <div class='col-lg-2'>

        </div>
    </div>

</form>
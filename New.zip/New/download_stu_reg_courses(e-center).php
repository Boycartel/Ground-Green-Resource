<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['download_stu_reg_courses(e-center)'] == false) {
    header('Location: home_staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Download Students Registered Courses</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-download"></i>
                                </a>
                            </li>
                            <li><span>Download</span></li>
                            <li><span>Download Students Registered Courses</span></li>
                        </ol>


                    </div>
                </header>

                <!-- start: page -->
                <div class="row">
                    <form class="form-horizontal" method="post">
                        <div class="col-lg-1">

                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="control-label col-lg-4" for="content">Select Course:</label>
                                <div class="col-lg-7">
                                    <select class="form-control" style="color:#000000" name="course">
                                        <option value="SelectItem">Select Item</option>
                                        <?php
                                        $cat = $_SESSION['cat'];
                                        $dept = $_SESSION['deptcode'];
                                        $staffid = $_SESSION['staffid'];
                                        $deptname = $_SESSION['deptname'];
                                        $corntsession = $_SESSION['corntsession'];


                                        if ($cat == "CourseLec" || $cat == "LevelAdv") {
                                            $sql = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$corntsession' ORDER BY CCode";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                                while ($row = $result->fetch_assoc()) {
                                                    $coursecode = $row["CCode"];
                                                    $coursetitle = $row["CTitle"];
                                                    echo "<option value=$coursecode>$coursecode $coursetitle</option>";
                                                }
                                            }
                                        } elseif ($cat == "HOD" || $cat == "HODLAdvice" || $cat == "Examiner" || $cat == "ExamLAdvice" || $cat == "HODDean") {
                                            $sql = "SELECT * FROM gencoursesupload WHERE Department = '$dept' ORDER BY C_codding";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                                while ($row = $result->fetch_assoc()) {
                                                    $coursecode = $row["C_codding"];
                                                    $coursetitle = $row["C_title"];
                                                    echo "<option value=$coursecode>$coursecode $coursetitle</option>";
                                                }
                                            }
                                        } else {
                                            $sql = "SELECT * FROM gencoursesupload ORDER BY C_codding";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                // output data of each row
                                                while ($row = $result->fetch_assoc()) {
                                                    $coursecode = $row["C_codding"];
                                                    $coursetitle = $row["C_title"];
                                                    echo "<option value=$coursecode>$coursecode $coursetitle</option>";
                                                }
                                            }
                                        }

                                        ?>

                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">

                                <label class="control-label col-lg-3" for="regid">Session:</label>
                                <div class="col-lg-8">
                                    <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                        <option value="<?php echo $_SESSION['corntsession'] ?>">
                                            <?php echo $_SESSION['corntsession'] ?></option>
                                        <?php
                                        $iniyear = 2015;
                                        $finalyear = substr($_SESSION['corntsession'], 5);

                                        while ($iniyear <= $finalyear) {
                                            $addyear = $iniyear + 1;

                                            echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                            $iniyear++;
                                        }

                                        //$conn->close();
                                        ?>

                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-9">
                                    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-1">

                        </div>
                    </form>
                </div>
                <hr class="separator" />
                <div class="row">

                    <?php if (isset($_POST["submit"])) { ?>
                        <?php
                        set_time_limit(500);
                        $course = $_POST['course'];
                        $session = $_POST['getsession'];

                        $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$course'";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $ctitle = $row["C_title"];
                                $cunit = $row["credit"];
                            }
                        }
                        ?>
                        <div class="col-lg-12  col-md-12">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <section class="panel panel-success">
                                    <header class="panel-heading">
                                        <div class="panel-actions">
                                            <a href="#" class="fa fa-caret-down"></a>
                                            <a href="#" class="fa fa-times"></a>
                                        </div>

                                        <h2 class="panel-title">Students' Registered Courses</h2>
                                    </header>
                                    <div class="panel-body">
                                        <?php
                                        $courseRegSplitSess = $_SESSION['courseRegSplitSess'];
                                        if ($session < $courseRegSplitSess) {
                                            $sql = "SELECT Regn1, name1, CCode, session FROM courses_register WHERE CCode= '$course' AND session= '$session' ORDER BY Regn1";
                                            //$sql = "SELECT * FROM courses_register WHERE CCode = '$ccode1' AND session = '$session1'";
                                        } else {
                                            $dbsession = str_replace("/", "_", $session);
                                            $sql = "SELECT Regn1, name1, CCode, session FROM courses_register_" . $dbsession . " WHERE CCode= '$course' ORDER BY Regn1";
                                            //$sql = "SELECT * FROM courses_register_".$dbsession." WHERE CCode = '$ccode1'";
                                        }

                                        $result = $conn->query($sql);
                                        $sno = 0;
                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                        ?>



                                            <table id="myTable" class="table mb-none" summary="" rules="groups" frame="hsides" border="2">
                                                <caption>
                                                    <?php echo $course . " - " . $ctitle . "  [Units : " . $cunit . "] (" . $session . ")" ?>
                                                </caption>
                                                <colgroup align="center"></colgroup>
                                                <colgroup align="left"></colgroup>
                                                <colgroup span="2" align="center"></colgroup>
                                                <colgroup span="3" align="center"></colgroup>
                                                <thead style=" font-size:14px">
                                                    <tr>
                                                        <th>S/No</th>
                                                        <th>Stu ID</th>
                                                        <th>Matric No.</th>
                                                        <th>Name</th>
                                                        <th>Course Code</th>
                                                        <th>Department</th>
                                                        <th>School</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php
                                                    while ($row = $result->fetch_assoc()) {
                                                        $regid = $row["Regn1"];
                                                        $stdid = "";
                                                        $depart = "";
                                                        $school = "";
                                                        $sql2 = "SELECT * FROM stdprofile WHERE regid = '$regid'";
                                                        $result2 = $conn2->query($sql2);
                                                        $sno++;
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $stdid = $row2["stdid"];
                                                                $depart = $row2["Deptcode"];
                                                                $school = $row2["SchCode"];
                                                            }
                                                        }

                                                        echo "<tr><td>$sno</td><td>$stdid</td><td>{$row['Regn1']}</td><td>{$row['name1']}</td><td>{$row['CCode']}</td><td>$depart</td><td>$school</td></tr>\n";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>

                                        <?php

                                        }
                                        ?>
                                        <br><br>
                                        <div class="form-group">
                                            <div style="text-align: right">
                                                <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                            </div>
                                        </div>

                                    </div>
                                </section>
                            </div>
                            <div class="col-lg-1">

                            </div>
                        </div>



                    <?php } ?>
                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>

</body>

</html>
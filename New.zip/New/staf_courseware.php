<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';


?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_qap.js"></script>
    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Courseware</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>Courseware</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Courseware
                        </div>
                        <div class="panel-body">

                            <?php
                            $_SESSION['downlcurse'] = "";
                            $_SESSION['downlsession'] = "";

                            $curtsession = $_SESSION['corntsession'];
                            $savesession = substr($curtsession, 0, 4) . "_" . substr($curtsession, -4);
                            $staffid = $_SESSION['staffid'];
                            //error_reporting(E_ERROR);

                            //echo $savefile;
                            $errors = "NO";
                            $errorcoment = "";
                            $saveinfo = "";
                            ?>
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <a href="staf_view_courseware.php" class='btn btn-primary'>View All</a>
                                <br>
                                <center><strong>
                                        <h3> <?php echo $_SESSION['corntsession'] . " " ?>Session</h3>
                                    </strong></center>
                                <div>
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label class="control-label col-lg-3" style="color:#000000;">Select
                                                Course:</label>
                                            <div class="col-lg-8">
                                                <select name="courses" class="form-control" style="color:#000000"
                                                    id="courses">
                                                    <?php
                                                    $staffid = $_SESSION['staffid'];

                                                    $sql = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$curtsession' ORDER BY CCode";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $ccode = $row["CCode"];
                                                            $ctitle = $row["CTitle"];
                                                            echo "<option value=$ccode>$ccode $ctitle</option>";
                                                        }
                                                    }
                                                    //$conn->close();


                                                    ?>


                                                </select>
                                            </div>
                                        </div>
                                        <br><br>
                                        <h4>Select PDF file not more than 2MB to upload:</h4>

                                        <br>


                                        <div class="form-group">
                                            <label class="col-md-3 control-label">File Upload</label>
                                            <div class="col-md-6">

                                                <div class="fileinput fileinput-new input-group"
                                                    data-provides="fileinput">
                                                    <div class="form-control" data-trigger="fileinput">
                                                        <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                                        <span class="fileinput-filename"></span>
                                                    </div>
                                                    <span class="input-group-addon btn btn-default btn-file"><span
                                                            class="fileinput-new">Select
                                                            file</span><span
                                                            class="fileinput-exists">Change</span><input type="file"
                                                            name="file_upload"></span>
                                                    <a href="#"
                                                        class="input-group-addon btn btn-default fileinput-exists"
                                                        data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <input type="submit" value="Upload File" name="submit"
                                                    class='btn btn-primary btn-sm'>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <br>
                                <diV>


                                    <table class="table mb-none">
                                        <thead>
                                            <tr>

                                                <th>Course Code</th>
                                                <th>Material Title</th>
                                                <th>Click to Download</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            //$target_dir = "img/staffpassport/";
                                            if (isset($_FILES['file_upload'])) {

                                                $savefile = mt_rand(1000, 9999);
                                                $path = "Content/" . $savesession . "/" . $_POST["courses"] . "/";
                                                function createPath($path)
                                                {
                                                    if (is_dir($path)) return true;
                                                    $prev_path = substr($path, 0, strrpos($path, '/', -2) + 1);
                                                    $return = createPath($prev_path);
                                                    return ($return && is_writable($prev_path)) ? mkdir($path) : false;
                                                }
                                                createPath($path);

                                                $file_name = explode('.', $_FILES['file_upload']['name']);
                                                $extension = end($file_name);
                                                //								
                                                //								$file_size =$_FILES['file_upload']['size'];
                                                //								$file_tmp =$_FILES['file_upload']['tmp_name'];
                                                //								$file_type=$_FILES['file_upload']['type'];


                                                try {

                                                    // Undefined | Multiple Files | $_FILES Corruption Attack
                                                    // If this request falls under any of them, treat it invalid.
                                                    if (
                                                        !isset($_FILES['file_upload']['error']) ||
                                                        is_array($_FILES['file_upload']['error'])
                                                    ) {
                                                        throw new RuntimeException('Invalid parameters.');
                                                    }

                                                    // Check $_FILES['upfile']['error'] value.
                                                    switch ($_FILES['file_upload']['error']) {
                                                        case UPLOAD_ERR_OK:
                                                            break;
                                                        case UPLOAD_ERR_NO_FILE:
                                                            throw new RuntimeException('No file sent.');
                                                        case UPLOAD_ERR_INI_SIZE:
                                                        case UPLOAD_ERR_FORM_SIZE:
                                                            throw new RuntimeException('Exceeded filesize limit.');
                                                        default:
                                                            throw new RuntimeException('Unknown errors.');
                                                    }

                                                    // You should also check file extenssion here.
                                                    if ($extension == "pdf" || $extension == "PDF") {
                                                    } else {
                                                        throw new RuntimeException('Invalid file format.');
                                                    }


                                                    // You should also check filesize here.
                                                    if ($_FILES['file_upload']['size'] > 2097152) {
                                                        //if ($_FILES['file_upload']['size'] > 4097152) {
                                                        throw new RuntimeException('Exceeded filesize limit.');
                                                    }
                                                    //$savepath="Content/".$savesession."/".$_POST["courses"]."/%s.%s";
                                                    $savepath = "Content/" . $savesession . "/" . $_POST["courses"] . "/";

                                                    // You should name it uniquely.
                                                    // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!
                                                    // On this example, obtain safe unique name from its binary data.
                                                    if (!move_uploaded_file(
                                                        //$_FILES['file_upload']['tmp_name'], sprintf($savepath, sha1_file($_FILES['file_upload']['tmp_name']), $extension)
                                                        $_FILES['file_upload']['tmp_name'],
                                                        $savepath . $savefile . ".pdf"
                                                    )) {
                                                        throw new RuntimeException('Failed to move uploaded file.');
                                                    }

                                                    $saveinfo =  'File is uploaded successfully.';

                                                    $filename = $_FILES['file_upload']['name'];

                                                    $savena = $savefile . ".pdf";
                                                    $course = $_POST["courses"];
                                                    $sql = "INSERT INTO courseware(CCode, sessionreg, bookname, savepath)VALUES ('$course', '$savesession', '$filename', '$savena')";
                                                    $result = $conn->query($sql);

                                                    $thelist = "";
                                                    $fname = "";
                                                    if ($handle = opendir('Content/' . $savesession . '/' . $course)) {
                                                        while (false !== ($file = readdir($handle))) {
                                                            if ($file != "." && $file != "..") {
                                                                //$thelist .= '<li><a href="'.$file.'">'.$file.'</a></li>';
                                                                $sql = "SELECT * FROM courseware WHERE savepath = '$file'";
                                                                $result = $conn->query($sql);

                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $fname = $row["bookname"];
                                                                    }
                                                                }

                                                                $thelist .= "<a href='download_courseware.php?filename1=" . $file . "'>$file</a>";
                                                                echo "<tr><td>$course</td><td>$fname</td><td>$thelist</td></tr>\n";
                                                                $thelist = "";
                                                            }
                                                        }
                                                        closedir($handle);
                                                        $_SESSION['downlcurse'] = $course;
                                                        $_SESSION['downlsession'] = $savesession;
                                                    }
                                                    //echo "<center><strong><h4 style='color:#00C'>$filename</h4></strong></center>";
                                                    //echo "<br>";

                                                } catch (RuntimeException $e) {

                                                    $errorcoment = $e->getMessage();
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>

                                    <br>
                                    <center><strong>
                                            <h4 style='color:#F00'><?php echo $errorcoment ?></h4>
                                        </strong></center>
                                    <center><strong>
                                            <h3 style='color:#00C'><?php echo $saveinfo ?></h3>
                                        </strong></center>


                                </div>

                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>


</body>

</html>
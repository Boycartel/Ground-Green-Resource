<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';


?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <!--Auto dropdown Select Start-->
    <script src="autoselect/jquery-1.12.0.min.js" type="text/javascript"></script>
    <script type="text/javascript">
    $(document).ready(function() {

        $("#sel_state").change(function() {
            var getid = $(this).val();

            $.ajax({
                url: 'lga_ddown.php',
                type: 'post',
                data: {
                    post_id: getid
                },
                dataType: 'json',
                success: function(response) {

                    var len = response.length;

                    $("#sel_lga").empty();
                    for (var i = 0; i < len; i++) {
                        var id = response[i]['id'];
                        var name = response[i]['name'];

                        $("#sel_lga").append("<option value='" + name + "'>" + name +
                            "</option>");

                    }
                }
            });
        });

    });
    </script>
    <!--Auto dropdown Select End-->


    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Prifile</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Profile</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Prifile
                        </div>
                        <div class="panel-body">
                            <?php

                            if (isset($_POST['submit'])) {
                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                $surname = $othername = $jambno = $nationality = "";
                                $state = $lga = $sex = $permaddres = $contaddres = $dob = $pob = $phone1 = $phone2 = $maried = "";
                                $state = str_replace("'", "''", $_POST['stateorigin']);

                                $surname = str_replace("'", "''", $_POST['surname']);
                                $surname = filter_var($surname, FILTER_SANITIZE_STRING);
                                $firstname = str_replace("'", "''", $_POST['firstname']);
                                $firstname = filter_var($firstname, FILTER_SANITIZE_STRING);
                                $othername = str_replace("'", "''", $_POST['othername']);
                                $othername = filter_var($othername, FILTER_SANITIZE_STRING);
                                $jambno = $_POST['jambno'];
                                $jambno = filter_var($jambno, FILTER_SANITIZE_STRING);
                                $nationality = $_POST['nationality'];

                                $lga = str_replace("'", "''", $_POST['sel_lga']);
                                //$lga = "X";
                                if ($_POST['sex'] = "Male") {
                                    $sex = "M";
                                } else {
                                    $sex = "F";
                                }
                                $permaddres = str_replace("'", "''", $_POST['permaddres']);
                                $permaddres = filter_var($permaddres, FILTER_SANITIZE_STRING);
                                $contaddres = str_replace("'", "''", $_POST['contaddres']);
                                $contaddres = filter_var($contaddres, FILTER_SANITIZE_STRING);
                                //$dob = $_POST['dob'];
                                $dob = date('d/m/Y', strtotime($_POST['dob']));
                                $pob = str_replace("'", "''", $_POST['pob']);
                                $pob = filter_var($pob, FILTER_SANITIZE_STRING);
                                $phone1 = $_POST['phone1'];
                                $phone1 = filter_var($phone1, FILTER_SANITIZE_STRING);
                                $email = $_POST['email'];
                                $maried = $_POST['maried'];
                                $fulname = $surname . " " . $firstname . " " . $othername;

                                //$stdid = $_SESSION['stdid'];
                                $regid = $_SESSION['regid'];

                                $sql = "UPDATE std_data_view SET surname='$surname', first_name='$firstname', other_name='$other_name', jamb_appl_no='$jambno', nationality='$nationality', state='$state', lga='$lga', gender='$sex', p_address='$permaddres', c_address='$contaddres', dob='$dob', phone_number='$phone1', sch_email='$email', marital_status='$maried' WHERE matric_no = '$regid'";

                                if ($conn2->query($sql) === true) {
                                    echo "<center><strong><h3 style='color:#30C'>Record updated successfully</h3></strong></center>";
                                } else {
                                    echo "<center><strong><h3 style='color:#F00'>Error updating record: </h3></strong></center>" . $mysqli->error;
                                }
                                $conn2->close();
                            }

                            ?>

                            <div class="row">
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }
                                ?>
                                <div class="col-md-4 col-lg-3">
                                    <?php
                                    $surname = $othername = $jambno = $stateorigin = $lgaorigin = $sex = $permaddres = $contaddres = "";
                                    $nationality = $dob = $pob = $phone1 = $phone2 = $maried = "";

                                    $regid = $_SESSION['regid'];
                                    $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                    $result = $conn2->query($sql);

                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $surname = $row["surname"];
                                            $firstname = $row["first_name"];
                                            $othername = $row["other_name"];
                                            $jambno = $row["jamb_appl_no"];
                                            $stateorigin = $row["state"];
                                            $lga = $row["lga"];

                                            $sex = $row["gender"];
                                            $permaddres = $row["p_address"];
                                            $contaddres = $row["c_address"];
                                            $nationality = $row["nationality"];
                                            $dob = $row["dob"];
                                            //$pob = $row["PlaceBirth"];
                                            $phone1 = $row["phone_number"];
                                            $maried = $row["marital_status"];
                                            $email = $row["sch_email"];
                                        }
                                    }
                                    //$_SESSION['lga']= $lga;
                                    //$mysqli->close();

                                    ?>

                                    <section class="panel">
                                        <div class="panel-body">
                                            <div class="thumb-info mb-md">
                                                <?php
                                                $regid = $_SESSION['regid'];

                                                $matpassport = str_replace("/", "_", $regid);
                                                echo "<img alt=''  class='' src='img/stupassport/$matpassport.jpg' width='200' height='210'>";
                                                ?>

                                                <div class="thumb-info-title">
                                                    <span
                                                        class="thumb-info-inner"><?php echo strtoupper($surname) . ", " . $firstname . " " . $othername ?></span>

                                                </div>
                                            </div>


                                            <hr class="dotted short">
                                            <span class="thumb-info-type"><?php echo $regid ?></span>

                                        </div>
                                    </section>



                                </div>
                                <div class="col-md-9 col-lg-9">

                                    <div class="tabs">
                                        <ul class="nav nav-tabs tabs-primary">
                                            <li class="active">
                                                <a href="#overview" data-toggle="tab">Overview</a>
                                            </li>
                                            <li>
                                                <!-- <a href="#edit" data-toggle="tab">Edit</a> -->
                                            </li>
                                        </ul>
                                        <div class="tab-content">
                                            <div id="overview" class="tab-pane active">
                                                <section class="panel">
                                                    <header class="panel-heading">

                                                        <h3>Personal Information</h3>
                                                    </header>
                                                    <div class="panel-body">
                                                        <form class="form-horizontal form-bordered" method="post">
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Surname:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $surname ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">First
                                                                    Name:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $firstname ?></label>
                                                            </div>

                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Other
                                                                    Name:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $othername ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">JAMB NO:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $jambno ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label
                                                                    class="col-md-3 control-label">Nationality:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $nationality ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">State:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $stateorigin ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">LGA:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $lga ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Sex:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $sex ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Parmanent Home
                                                                    Address:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $permaddres ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Contact
                                                                    Address:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $contaddres ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Date of
                                                                    Birth:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $dob ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Place of
                                                                    Birth:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php //echo $pob 
                                                                                                                                ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Phone No:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $phone1 ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">email:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $email ?></label>
                                                            </div>
                                                            <div class="form-group">
                                                                <label class="col-md-3 control-label">Marital
                                                                    Status:</label>
                                                                <label class="col-md-6 control-label"
                                                                    style="text-align: left"><?php echo $maried ?></label>
                                                            </div>
                                                        </form>
                                                    </div>

                                            </div>
                                            <div id="edit" class="tab-pane">

                                                <form class="form-horizontal" method="post">
                                                    <h3>Personal Information</h3>
                                                    <fieldset>

                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Surname</label>
                                                            <div class="col-lg-8">
                                                                <input type="text" class="form-control"
                                                                    style="color:#000000" name="surname"
                                                                    value="<?php echo $surname ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">First Name</label>
                                                            <div class="col-lg-8">
                                                                <input type="text" class="form-control"
                                                                    style="color:#000000" name="firstname"
                                                                    value="<?php echo $firstname ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Other Name</label>
                                                            <div class="col-lg-8">
                                                                <input type="text" class="form-control"
                                                                    style="color:#000000" name="othername"
                                                                    value="<?php echo $othername ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">JAMB NO</label>
                                                            <div class="col-lg-8">
                                                                <input type="text" class="form-control"
                                                                    style="color:#000000" name="jambno"
                                                                    value="<?php echo $jambno ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Nationality</label>
                                                            <div class="col-lg-8">

                                                                <select name="nationality" class="form-control"
                                                                    style="color:#000000" id="nationality">
                                                                    <option value="<?php echo $nationality ?>">
                                                                        <?php echo $nationality ?></option>
                                                                    <option value="Nigerian">Nigerian</option>
                                                                    <option value="Non Nigerian">Non Nigerian</option>

                                                                </select>

                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">State</label>
                                                            <div class="col-lg-8">
                                                                <select class="form-control" style="color:#000000"
                                                                    name="stateorigin" id="sel_state">
                                                                    <option value="<?php echo $stateorigin ?>">
                                                                        <?php echo $stateorigin ?></option>
                                                                    <?php

                                                                    $sql = "SELECT * FROM states";
                                                                    $result = $conn->query($sql);

                                                                    if ($result->num_rows > 0) {
                                                                        // output data of each row
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $state = $row["state"];
                                                                            echo "<option value=$state>$state</option>";
                                                                        }
                                                                    }
                                                                    ?>

                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">LGA: </label>
                                                            <div class="col-lg-8">
                                                                <select id="sel_lga" class="form-control" name="sel_lga"
                                                                    style="color:#000000">
                                                                    <option value="<?php echo $lga ?>">
                                                                        <?php echo $lga ?></option>
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Sex</label>
                                                            <div class="col-lg-8">

                                                                <select name="sex" class="form-control"
                                                                    style="color:#000000" id="sex">
                                                                    <option value="<?php echo $sex ?>">
                                                                        <?php echo $sex ?></option>
                                                                    <option value="Male">Male</option>
                                                                    <option value="Female">Female</option>

                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Parmanent Home
                                                                Address</label>
                                                            <div class="col-lg-8">
                                                                <textarea name="permaddres" style="color:#000000"
                                                                    class="form-control" cols="30"
                                                                    rows="3"> <?php echo $permaddres ?></textarea>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Contact
                                                                Address</label>
                                                            <div class="col-lg-8">
                                                                <textarea name="contaddres" style="color:#000000"
                                                                    class="form-control" cols="5"
                                                                    rows="3"><?php echo $contaddres ?></textarea>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label class="col-md-3 control-label">Date of Birth</label>
                                                            <div class="col-md-4">
                                                                <div class="input-group">
                                                                    <span class="input-group-addon">
                                                                        <i class="fa fa-calendar"></i>
                                                                    </span>
                                                                    <input type="text" style="color:#000000"
                                                                        data-plugin-datepicker class="form-control"
                                                                        name="dob" value="<?php echo $dob ?>">
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Place of Birth</label>
                                                            <div class="col-lg-8">

                                                                <input type="text" class="form-control"
                                                                    style="color:#000000" name="pob"
                                                                    value="<?php //echo $pob 
                                                                                                                                                ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Phone No</label>
                                                            <div class="col-lg-8">
                                                                <input type="text" class="form-control"
                                                                    style="color:#000000" name="phone1"
                                                                    value="<?php echo $phone1 ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">email</label>
                                                            <div class="col-lg-8">
                                                                <input type="email" class="form-control"
                                                                    style="color:#000000" name="email"
                                                                    value="<?php echo $email ?>">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-lg-3 control-label">Marital Status</label>
                                                            <div class="col-lg-8">

                                                                <select name="maried" class="form-control"
                                                                    style="color:#000000" id="maried">
                                                                    <option value="<?php echo $maried ?>">
                                                                        <?php echo $maried ?>
                                                                    </option>
                                                                    <option value="Single">Single</option>
                                                                    <option value="Married">Married</option>

                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <div class="col-lg-offset-2 col-lg-10">
                                                                <button type="submit" name="submit"
                                                                    class="btn btn-primary">Save</button>

                                                            </div>
                                                        </div>


                                                    </fieldset>
                                                    <hr class="dotted tall">

                                                </form>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- end: page -->
                                <?php
                                $conn->close();
                                $conn2->close();
                                ?>
                            </div>
                        </div>



                    </div>
                </div>

                <div class="footer">
                    <?php
                    include_once 'includes/footer2.php';
                    ?>
                </div>
            </div>
            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>


</body>

</html>
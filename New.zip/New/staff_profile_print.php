<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['senate_format'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!--Print Div-->
    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
    if ($conn2->connect_error) {
        die("Connection failed: " . $conn2->connect_error);
    }

    $conn7 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE7);
    if ($conn7->connect_error) {
        die("Connection failed: " . $conn7->connect_error);
    }

    if (isset($_POST["viewdapProfile"])) {
        $staffid = $_POST["id"];
    } else {
        $staffid = $_SESSION['staffid'];
    }

    $corntsession = $_SESSION['corntsession'];
    $cursemester = $_SESSION['cursemester'];
    $dept = $_SESSION['deptcode'];

    $PSN = $staffid;
    $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $emailAdd = $row['emailAdd'];
            $phone = $row['phone'];
        }
    }

    $sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
    $result = $conn7->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $fname = $row['fname'];
            $surname = $row['sname'];
            $othernames = $row['oname'];
        }
    }

    $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$PSN'";
    $result = $conn7->query($sql);
    $i = 0;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $i++;
        }
    }

    if ($i == 0) {
        $sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
    } else {
        $sql = "SELECT * FROM staff_profile_edit WHERE PSN = '$PSN'";
    }

    $result = $conn7->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {


            $mytitle = $row['title'];
            $apptype = $row['Status'];
            $leaveabsent_study = $row['leaveabsent_study'];
            $postn_rank = $row['Rank1'];
            $area_special = $row['area_special'];
            $salary_grade = $row['GradeL'];
            $stepG = $row['StepG'];

            $nationality = $row["nationality"];
            $placebirth = $row["placebirth"];
            $religion = $row["religion"];
            $healthstatus = $row["healthstatus"];
            $disable = $row["disable"];
            $healthtype = $row["healthtype"];
            $accommodation = $row["accommodation"];

            $DeptCode2 = $row["DeptCode"];
            $Department = $row["Department"];
            $Sex = $row["Sex"];
            $ParmtAdress = $row["ParmtAdress"];
            $ContAdd = $row["ContAdd"];
            $stateOfOrigin = $row["stateOfOrigin"];
            $LGA = $row["LGA"];
            $DateBirth = $row["DateBirth"];
            $FApptDate = $row["FApptDate"];
            $FApptMonth = $row["FApptMonth"];
            $FApptYear = $row["FApptYear"];
            $PApptDate = $row["PApptDate"];
            $BankCode2 = $row["BankCode"];
            $Bank = $row["Bank"];
            $Branch = $row["Branch"];
            $AccNo = $row["AccNo"];
            $email = $row["email"];
            $Scale = $row["Scale"];
            $HQualificatn = $row["HQualificatn"];
            $maritalstatus = $row["maritalstatus"];
            $nochildren = $row["nochildren"];
            $phonenumber = $row["phonenumber"];
            $phonenumber2 = $row["phonenumber2"];
            $Status = $row["Status"];
            $nextname = $row["nextname"];
            $nextrelation = $row["nextrelation"];
            $nextaddress = $row["nextaddress"];
            $nextphone = $row["nextphone"];
        }
    }


    if ($i !== 0) {

        $sql = "SELECT * FROM users WHERE staffid = '$staffid'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $emailAdd_old = $row['emailAdd'];
                //$phone = $row['phone'];
            }
        }


        $sql = "SELECT * FROM staff_profile WHERE PSN = '$PSN'";
        $result = $conn7->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                //$fname = $row['fname'];
                //$surname = $row['sname'];
                //$othernames = $row['oname'];
                $mytitle_old = $row['title'];
                $apptype_old = $row['Status'];
                $leaveabsent_study_old = $row['leaveabsent_study'];
                $postn_rank_old = $row['Rank1'];
                $area_special_old = $row['area_special'];
                $salary_grade_old = $row['GradeL'];
                $stepG_old = $row['StepG'];

                $nationality_old = $row["nationality"];
                $placebirth_old = $row["placebirth"];
                $religion_old = $row["religion"];
                $healthstatus_old = $row["healthstatus"];

                $healthtype_old = $row["healthtype"];
                $accommodation_old = $row["accommodation"];


                $Sex_old = $row["Sex"];
                $ParmtAdress_old = $row["ParmtAdress"];
                $ContAdd_old = $row["ContAdd"];
                $stateOfOrigin_old = $row["stateOfOrigin"];
                $LGA_old = $row["LGA"];
                $DateBirth_old = $row["DateBirth"];
                $FApptDate_old = $row["FApptDate"];

                $PApptDate_old = $row["PApptDate"];
                $BankCode2_old = $row["BankCode"];
                $Bank_old = $row["Bank"];
                $Branch_old = $row["Branch"];
                $AccNo_old = $row["AccNo"];
                $email_old = $row["email"];

                $HQualificatn_old = $row["HQualificatn"];
                $maritalstatus_old = $row["maritalstatus"];

                $phonenumber_old = $row["phonenumber"];
                $phonenumber2_old = $row["phonenumber2"];
                $Status_old = $row["Status"];
                $nextname_old = $row["nextname"];
                $nextrelation_old = $row["nextrelation"];
                $nextaddress_old = $row["nextaddress"];
                $nextphone_old = $row["nextphone"];
            }
        }
    }

    if ($apptype == "fulltime") {
        $apptype_full = "Full Time";
    } else if ($apptype == "parttime") {
        $apptype_full = "Part Time";
    } else {
        $apptype_full = "Contract";
    }


    if ($postn_rank == "Prof") {
        $postn_rank_full = "Professor";
    } elseif ($postn_rank == "assprof") {
        $postn_rank_full = "Associate Professor";
    } elseif ($postn_rank == "SL") {
        $postn_rank_full = "Senior Lecturer";
    } elseif ($postn_rank == "LI") {
        $postn_rank_full = "Lecturer I";
    } elseif ($postn_rank == "LII") {
        $postn_rank_full = "Lecturer II";
    } elseif ($postn_rank == "AL") {
        $postn_rank_full = "Assistant Lecturer";
    } else {
        $postn_rank_full = "Graduate Assistant";
    }

    if ($leaveabsent_study == "leaveabsent") {
        $leaveabsent_study_full = "Leave of Absent";
    } else if ($leaveabsent_study == "studyleave") {
        $leaveabsent_study_full = "Study Leave";
    } else {
        $leaveabsent_study_full = $leaveabsent_study;
    }

    if ($nationality == "non") {
        $natinal_full = "Non Nigerian";
    } else {
        $natinal_full = $nationality;
    }

    if ($accommodation == "campus") {
        $accommodation_full = "In Campus";
    } else {
        $accommodation_full = "Off Campus";
    }

    if ($HQualificatn == "firstdegree") {
        $HQualificatn_full = "First Degree";
    } else if ($HQualificatn == "masters") {
        $HQualificatn_full = "Masters";
    } else {
        $HQualificatn_full = "Ph.D";
    }

    ?>

    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Staff Profile</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li class="active">
                                <strong>Staff Profile</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Staff Profile
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-2">

                            </div>
                            <div class="col-lg-8">
                                <section class="panel panel-group">
                                    <div class="modal-header form-group">
                                        <?php if ($i == 0) { ?>
                                        <label class="col-lg-8 control-label"
                                            style="text-align: left; color: red"></label>
                                        <?php } else { ?>
                                        <label class="col-lg-8 control-label" style="text-align: left; color: red"><b>*
                                                New Record Awaiting
                                                Approval</b></label>
                                        <?php } ?>

                                        <div class="col-lg-4" style="text-align: right">

                                        </div>

                                    </div>
                                    <div id="printableAreaAll">
                                        <header class="panel-heading">

                                            <div class="widget-profile-info">
                                                <div>

                                                    <?php
                                                    $staff_pic_folder = $_SESSION['staff_pic_folder'];
                                                    echo "<img alt='' src='$staff_pic_folder/" . strtoupper($DeptCode2) . "/images/" . strtoupper($staffid) . "/MyPic1.jpg' width=100px height = 100px>";

                                                    ?>
                                                </div>

                                            </div>

                                        </header>
                                        <div id="accordion">
                                            <div class="panel panel-accordion panel-accordion-first">


                                                <div class="panel-body">
                                                    <?php if ($i == 0) { ?>
                                                    <table class="table mb-none">

                                                        <tbody>
                                                            <tr>
                                                                <th>SurName:</th>
                                                                <td><?php echo $surname ?></td>
                                                                <th>First Name:</th>
                                                                <td><?php echo $fname ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Other Name(s):</th>
                                                                <td><?php echo $othernames ?></td>
                                                                <th>File Number:</th>
                                                                <td><?php echo $PSN ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Title:</th>
                                                                <td><?php echo $mytitle ?></td>
                                                                <th>Department:</th>
                                                                <td><?php echo $_SESSION["deptname"] ?></td>
                                                            </tr>

                                                            <tr>
                                                                <th>email:</th>
                                                                <td><?php echo $emailAdd ?></td>
                                                                <th>Highest Qualification:</th>
                                                                <td><?php echo $HQualificatn_full ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Appointment Type:</th>
                                                                <td><?php echo $apptype_full ?></td>
                                                                <th>File:</th>
                                                                <td><?php echo $PSN ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Leave of Absence/Study Leave:</th>
                                                                <td><?php echo $leaveabsent_study_full ?></td>
                                                                <th>File:</th>
                                                                <td><?php echo $PSN ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Position/Rank:</th>
                                                                <td><?php echo $postn_rank_full ?></td>
                                                                <th>Area of Specialization:</th>
                                                                <td><?php echo $area_special ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Salary Grade:</th>
                                                                <td><?php echo $salary_grade ?></td>
                                                                <th>Step:</th>
                                                                <td><?php echo $stepG ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Marital Status:</th>
                                                                <td><?php echo $maritalstatus ?></td>
                                                                <th>Nationality:</th>
                                                                <td><?php echo $natinal_full ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>State of Origin:</th>
                                                                <td><?php echo $stateOfOrigin ?></td>
                                                                <th>LGA:</th>
                                                                <td><?php echo $LGA ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Religion:</th>
                                                                <td><?php echo $religion ?></td>
                                                                <th>Health Status:</th>
                                                                <td><?php echo $healthstatus ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>If Disabled, Type:</th>
                                                                <td><?php echo $healthtype ?></td>
                                                                <th>Accommodation Status:</th>
                                                                <td><?php echo $accommodation_full ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Date of Birth:</th>
                                                                <td><?php echo date('d F, Y', strtotime($DateBirth)) ?>
                                                                </td>
                                                                <th>Place of Birth:</th>
                                                                <td><?php echo $placebirth ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Permenet Home Address:</th>
                                                                <td><?php echo $ParmtAdress ?></td>
                                                                <th>Contact Address:</th>
                                                                <td><?php echo $ContAdd ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Phone Number 1:</th>
                                                                <td><?php echo $phonenumber ?></td>
                                                                <th>Phone Number 2:</th>
                                                                <td><?php echo $phonenumber2 ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Date of First Appointment:</th>
                                                                <td><?php echo date('d F, Y', strtotime($FApptDate)) ?>
                                                                </td>
                                                                <th>Date of Present Appointment:</th>
                                                                <td><?php echo date('d F, Y', strtotime($PApptDate)) ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th>Bank:</th>
                                                                <td><?php echo $Bank ?></td>
                                                                <th>Branch:</th>
                                                                <td><?php echo $Branch ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Account Number:</th>
                                                                <td><?php echo $AccNo ?></td>
                                                                <th></th>
                                                                <td></td>
                                                            </tr>

                                                        </tbody>
                                                    </table>

                                                    <?php } else { ?>
                                                    <table class="table mb-none">

                                                        <tbody>
                                                            <tr>
                                                                <th>SurName:</th>
                                                                <td><?php echo $surname ?></td>
                                                                <th>First Name:</th>
                                                                <td><?php echo $fname ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Other Name(s):</th>
                                                                <td><?php echo $othernames ?></td>
                                                                <th>File Number:</th>
                                                                <td><?php echo $PSN ?></td>
                                                            </tr>


                                                            <tr>
                                                                <?php if ($mytitle_old == $mytitle) { ?>
                                                                <th>Title:</th>
                                                                <td><?php echo $mytitle ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Title:</th>
                                                                <td><?php echo $mytitle ?></td>
                                                                <?php } ?>
                                                                <th>Department:</th>
                                                                <td><?php echo $_SESSION["deptname"] ?></td>
                                                            </tr>
                                                            <tr>
                                                                <?php if ($emailAdd_old == $emailAdd) { ?>
                                                                <th>email:</th>
                                                                <td><?php echo $emailAdd ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    email:</th>
                                                                <td><?php echo $emailAdd ?></td>
                                                                <?php } ?>
                                                                <?php if ($HQualificatn_old == $HQualificatn) { ?>
                                                                <th>Highest Qualification:</th>
                                                                <td><?php echo $HQualificatn_full ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Highest Qualification:</th>
                                                                <td><?php echo $HQualificatn_full ?></td>
                                                                <?php } ?>
                                                            </tr>
                                                            <tr>
                                                                <?php if ($apptype_old == $apptype) { ?>
                                                                <th>Appointment Type:</th>
                                                                <td><?php echo $apptype_full ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Appointment Type:</th>
                                                                <td><?php echo $apptype_full ?></td>
                                                                <?php } ?>
                                                                <?php if ($leaveabsent_study_old == $leaveabsent_study) { ?>
                                                                <th>Leave of Absence/Study Leave:</th>
                                                                <td><?php echo $leaveabsent_study_full ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Leave of Absence/Study Leave:</th>
                                                                <td><?php echo $leaveabsent_study_full ?></td>
                                                                <?php } ?>
                                                            </tr>
                                                            <tr>
                                                                <?php if ($postn_rank_old == $postn_rank) { ?>
                                                                <th>Position/Rank:</th>
                                                                <td><?php echo $postn_rank_full ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Position/Rank:</th>
                                                                <td><?php echo $postn_rank_full ?></td>
                                                                <?php } ?>
                                                                <?php if ($area_special_old == $area_special) { ?>
                                                                <th>Area of Specialization:</th>
                                                                <td><?php echo $area_special ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Area of Specialization:</th>
                                                                <td><?php echo $area_special ?></td>
                                                                <?php } ?>
                                                            </tr>
                                                            <tr>
                                                                <?php if ($salary_grade_old == $salary_grade) { ?>
                                                                <th>Salary Grade:</th>
                                                                <td><?php echo $salary_grade ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Salary Grade:</th>
                                                                <td><?php echo $salary_grade ?></td>
                                                                <?php } ?>
                                                                <?php if ($stepG_old == $stepG) { ?>
                                                                <th>Step:</th>
                                                                <td><?php echo $stepG ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Step:</th>
                                                                <td><?php echo $stepG ?></td>
                                                                <?php } ?>

                                                            </tr>
                                                            <tr>
                                                                <?php if ($maritalstatus_old == $maritalstatus) { ?>
                                                                <th>Marital Status:</th>
                                                                <td><?php echo $maritalstatus ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Marital Status:</th>
                                                                <td><?php echo $maritalstatus ?></td>
                                                                <?php } ?>
                                                                <?php if ($nationality_old == $nationality) { ?>
                                                                <th>Nationality:</th>
                                                                <td><?php echo $natinal_full ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Nationality:</th>
                                                                <td><?php echo $natinal_full ?></td>
                                                                <?php } ?>
                                                            </tr>
                                                            <tr>
                                                                <?php if ($stateOfOrigin_old == $stateOfOrigin) { ?>
                                                                <th>State of Origin:</th>
                                                                <td><?php echo $stateOfOrigin ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    State of Origin:</th>
                                                                <td><?php echo $stateOfOrigin ?></td>
                                                                <?php } ?>
                                                                <?php if ($LGA_old == $LGA) { ?>
                                                                <th>LGA:</th>
                                                                <td><?php echo $LGA ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    LGA:</th>
                                                                <td><?php echo $LGA ?></td>
                                                                <?php } ?>


                                                            </tr>
                                                            <tr>
                                                                <?php if ($religion_old == $religion) { ?>
                                                                <th>Religion:</th>
                                                                <td><?php echo $religion ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Religion:</th>
                                                                <td><?php echo $religion ?></td>
                                                                <?php } ?>
                                                                <?php if ($healthstatus_old == $healthstatus) { ?>
                                                                <th>Health Status:</th>
                                                                <td><?php echo $healthstatus ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Health Status:</th>
                                                                <td><?php echo $healthstatus ?></td>
                                                                <?php } ?>
                                                            </tr>

                                                            <tr>
                                                                <?php if ($healthtype_old == $healthtype) { ?>
                                                                <th>If Disabled, Type:</th>
                                                                <td><?php echo $healthtype ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    If Disabled, Type:</th>
                                                                <td><?php echo $healthtype ?></td>
                                                                <?php } ?>
                                                                <?php if ($accommodation_old == $accommodation) { ?>
                                                                <th>Accommodation Status:</th>
                                                                <td><?php echo $accommodation_full ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Accommodation Status:</th>
                                                                <td><?php echo $accommodation_full ?></td>
                                                                <?php } ?>
                                                            </tr>

                                                            <tr>
                                                                <?php if ($DateBirth_old == $DateBirth) { ?>
                                                                <th>Date of Birth:</th>
                                                                <td><?php echo date('d F, Y', strtotime($DateBirth)); ?>
                                                                </td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Date of Birth:</th>
                                                                <td><?php echo date('d F, Y', strtotime($DateBirth)); ?>
                                                                </td>
                                                                <?php } ?>
                                                                <?php if ($placebirth_old == $placebirth) { ?>
                                                                <th>Place of Birth:</th>
                                                                <td><?php echo $placebirth ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Place of Birth:</th>
                                                                <td><?php echo $placebirth ?></td>
                                                                <?php } ?>
                                                            </tr>

                                                            <tr>
                                                                <?php if ($ParmtAdress_old == $ParmtAdress) { ?>
                                                                <th>Permenet Home Address:</th>
                                                                <td><?php echo $ParmtAdress ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Permenet Home Address:</th>
                                                                <td><?php echo $ParmtAdress ?></td>
                                                                <?php } ?>
                                                                <?php if ($ContAdd_old == $ContAdd) { ?>
                                                                <th>Contact Address:</th>
                                                                <td><?php echo $ContAdd ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Contact Address:</th>
                                                                <td><?php echo $ContAdd ?></td>
                                                                <?php } ?>
                                                            </tr>

                                                            <tr>
                                                                <?php if ($phonenumber_old == $phonenumber) { ?>
                                                                <th>Phone Number 1:</th>
                                                                <td><?php echo $phonenumber ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Phone Number 1:</th>
                                                                <td><?php echo $phonenumber ?></td>
                                                                <?php } ?>
                                                                <?php if ($phonenumber2_old == $phonenumber2) { ?>
                                                                <th>Phone Number 2:</th>
                                                                <td><?php echo $phonenumber2 ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Phone Number 2:</th>
                                                                <td><?php echo $phonenumber2 ?></td>
                                                                <?php } ?>
                                                            </tr>

                                                            <tr>
                                                                <?php if ($FApptDate_old == $FApptDate) { ?>
                                                                <th>Date of First Appointment:</th>
                                                                <td><?php echo date('d F, Y', strtotime($FApptDate)); ?>
                                                                </td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Date of First Appointment:</th>
                                                                <td><?php echo date('d F, Y', strtotime($FApptDate)); ?>
                                                                </td>
                                                                <?php } ?>
                                                                <?php if ($PApptDate_old == $PApptDate) { ?>
                                                                <th>Date of Present Appointment:</th>
                                                                <td><?php echo date('d F, Y', strtotime($PApptDate)); ?>
                                                                </td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Date of Present Appointment:</th>
                                                                <td><?php echo date('d F, Y', strtotime($PApptDate)); ?>
                                                                </td>
                                                                <?php } ?>
                                                            </tr>

                                                            <tr>
                                                                <?php if ($Bank_old == $Bank) { ?>
                                                                <th>Date of First Appointment:</th>
                                                                <td><?php echo $Bank ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Date of First Appointment:</th>
                                                                <td><?php echo $Bank ?></td>
                                                                <?php } ?>
                                                                <?php if ($Branch_old == $Branch) { ?>
                                                                <th>Branch:</th>
                                                                <td><?php echo $Branch ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Branch:</th>
                                                                <td><?php echo $Branch ?></td>
                                                                <?php } ?>
                                                            </tr>

                                                            <tr>
                                                                <?php if ($AccNo_old == $AccNo) { ?>
                                                                <th>Account Number:</th>
                                                                <td><?php echo $AccNo ?></td>
                                                                <?php } else { ?>
                                                                <th><span class="required" style="font-size: large"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        title="New Record Awaiting Approval">*</span>
                                                                    Account Number:</th>
                                                                <td><?php echo $AccNo ?></td>
                                                                <?php } ?>
                                                                <th></th>
                                                                <td>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                    <?php } ?>
                                                </div>
                                                <hr class="separator" />
                                                <div class="form-group">
                                                    <label class="col-sm-5 control-label">Next of Kin:</label>
                                                    <div class="col-sm-7">

                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-sm-3 control-label"></label>
                                                    <div class="col-sm-9">
                                                        <table class="table mb-none">

                                                            <tbody>
                                                                <?php if ($i == 0) { ?>
                                                                <tr>
                                                                    <th>Name:</th>
                                                                    <td><?php echo $nextname ?></td>
                                                                    <th>Relationship:</th>
                                                                    <td><?php echo $nextrelation ?></td>
                                                                </tr>

                                                                <tr>
                                                                    <th>Address:</th>
                                                                    <td><?php echo $nextaddress ?></td>
                                                                    <th>Phone:</th>
                                                                    <td><?php echo $nextphone ?></td>
                                                                </tr>
                                                                <?php } else { ?>
                                                                <tr>
                                                                    <?php if ($nextname_old == $nextname) { ?>
                                                                    <th>Name:</th>
                                                                    <?php } else { ?>
                                                                    <th><span class="required" style="font-size: large"
                                                                            data-toggle="tooltip" data-placement="top"
                                                                            title="New Record Awaiting Approval">*</span>
                                                                        Name:</th>
                                                                    <?php } ?>

                                                                    <td><?php echo $nextname ?></td>
                                                                    <?php if ($nextrelation_old == $nextrelation) { ?>
                                                                    <th>Relationship:</th>
                                                                    <?php } else { ?>
                                                                    <th><span class="required" style="font-size: large"
                                                                            data-toggle="tooltip" data-placement="top"
                                                                            title="New Record Awaiting Approval">*</span>
                                                                        Relationship:</th>
                                                                    <?php } ?>

                                                                    <td><?php echo $nextrelation ?></td>
                                                                </tr>

                                                                <tr>
                                                                    <?php if ($nextaddress_old == $nextaddress) { ?>
                                                                    <th>Address:</th>
                                                                    <?php } else { ?>
                                                                    <th><span class="required" style="font-size: large"
                                                                            data-toggle="tooltip" data-placement="top"
                                                                            title="New Record Awaiting Approval">*</span>
                                                                        Address:</th>
                                                                    <?php } ?>

                                                                    <td><?php echo $nextaddress ?></td>
                                                                    <?php if ($nextphone_old == $nextphone) { ?>
                                                                    <th>Phone:</th>
                                                                    <?php } else { ?>
                                                                    <th><span class="required" style="font-size: large"
                                                                            data-toggle="tooltip" data-placement="top"
                                                                            title="New Record Awaiting Approval">*</span>
                                                                        Phone:</th>
                                                                    <?php } ?>

                                                                    <td><?php echo $nextphone ?></td>
                                                                </tr>
                                                                <?php } ?>

                                                            </tbody>
                                                        </table>

                                                    </div>
                                                </div>
                                                <br><br><br><br><br>
                                                <hr class="separator" />
                                                <div>
                                                    <h3 style="text-align: center">Children</h3>
                                                    <table class="table stats-table">
                                                        <thead>
                                                            <tr>

                                                                <th>Name</th>
                                                                <th>Sex</th>
                                                                <th>Date of Birth</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                            $sql = "SELECT * FROM children WHERE fileno = '$PSN'";
                                                            $result = $conn7->query($sql);
                                                            $sexsno = 0;
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $sexsno++;
                                                                    $id_child = $row["id"];
                                                                    $childname = $row["childname"];
                                                                    $childbirth = date('d F, Y', strtotime($row["datebirth"]));
                                                                    $childsex = $row["sex1"];
                                                                    $approval_child = $row['approval'];
                                                                    if ($approval_child == "YES") {
                                                                        echo "<tr><td>$childname</td><td>$childsex</td><td>$childbirth</td></tr>";
                                                                    } else {
                                                                        echo "<tr><td><span class='required' style='font-size: large' data-toggle='tooltip' data-placement='top' title='New Record Awaiting Approval'>*</span> $childname</td><td>$childsex</td><td>$childbirth</td></tr>";
                                                                    }
                                                                }
                                                            }

                                                            ?>

                                                        </tbody>
                                                    </table>
                                                </div>
                                                <hr class="separator" />
                                                <div>
                                                    <h3 style="text-align: center">Academic Qualification</h3>
                                                    <?php
                                                    $sql = "SELECT * FROM institution WHERE fileno = '$staffid'";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                    <table class="table stats-table">
                                                        <thead>
                                                            <tr>
                                                                <th>Institution Name</th>
                                                                <th>From</th>
                                                                <th>To</th>
                                                                <th>Qualification Obtained</th>
                                                                <th>Qualification Date</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php

                                                                while ($row = $result->fetch_assoc()) {
                                                                    $id_institu = $row["id"];
                                                                    $instiname = $row["instiname"];
                                                                    $fromdate = $row["fromdate"];
                                                                    $todate = $row["todate"];
                                                                    $qualiobtained = $row["qualiobtained"];
                                                                    $qualidate = date('d F, Y', strtotime($row["qualidate"]));

                                                                    $approval_institu = $row['approval'];
                                                                    if ($approval_institu == "YES") {
                                                                        echo "<tr><td>$instiname</td><td>$fromdate</td><td>$todate</td><td>$qualiobtained</td><td>$qualidate</td></tr>";
                                                                    } else {
                                                                        echo "<tr><td><span class='required' style='font-size: large' data-toggle='tooltip' data-placement='top' title='New Record Awaiting Approval'>*</span> $instiname</td><td>$fromdate</td><td>$todate</td><td>$qualiobtained</td><td>$qualidate</td></tr>";
                                                                    }
                                                                }

                                                                ?>

                                                        </tbody>
                                                    </table>

                                                    <?php } ?>
                                                </div>
                                                <hr class="separator" />
                                                <div>
                                                    <h3 style="text-align: center">Membership of Professional
                                                        Bodies/Societies</h3>
                                                    <table class="table stats-table">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Date</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                            $sql = "SELECT * FROM professional_body WHERE fileno = '$PSN'";
                                                            $result = $conn7->query($sql);
                                                            $bodysno = 0;
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $bodysno++;
                                                                    $id_prof_body = $row["id"];
                                                                    $profname = $row["profname"];
                                                                    $profdate = date('d F, Y', strtotime($row["profdate"]));
                                                                    $approval_profbody = $row['approval'];
                                                                    if ($approval_profbody == "YES") {
                                                                        echo "<tr><td>$profname</td><td>$profdate</td></tr>";
                                                                    } else {
                                                                        echo "<tr><td><span class='required' style='font-size: large' data-toggle='tooltip' data-placement='top' title='New Record Awaiting Approval'>*</span> $profname</td><td>$profdate</td></tr>";
                                                                    }
                                                                }
                                                            }

                                                            ?>

                                                        </tbody>
                                                    </table>

                                                </div>
                                                <hr class="separator" />
                                                <div>
                                                    <h3 style="text-align: center">ADMINISTRATIVE DUTIES</h3>
                                                    <?php
                                                    $sql = "SELECT * FROM admin_duties WHERE staffid = '$staffid' ORDER BY session1";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                    <table class="table mb-none">
                                                        <thead>
                                                            <tr>
                                                                <th>Type of Activity</th>
                                                                <th>Details</th>
                                                                <th>Year</th>
                                                                <th>Session</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $activit_code = $row['activit_code'];
                                                                    $activity_type = $row['activity_type'];
                                                                    $year1 = $row['year1'];
                                                                    $session1 = $row['session1'];
                                                                    $approval_duties = $row['approval'];
                                                                    $id = $row['id'];
                                                                    if ($activit_code == "15" || $activit_code == "18" || $activit_code == "19") {
                                                                        $specify = $row['specify'];
                                                                        if ($approval_duties == "YES") {
                                                                            echo "<tr><td>$activity_type</td><td>$specify</td><td>$year1</td><td>$session1</td>";
                                                                        } else {
                                                                            echo "<tr><td><span class='required' style='font-size: large' data-toggle='tooltip' data-placement='top' title='New Record Awaiting Approval'>*</span> $activity_type</td><td>$specify</td><td>$year1</td><td>$session1</td>";
                                                                        }
                                                                    } else {
                                                                        if ($approval_duties == "YES") {
                                                                            echo "<tr><td>$activity_type</td><td></td><td>$year1</td><td>$session1</td></tr>";
                                                                        } else {
                                                                            echo "<tr><td><span class='required' style='font-size: large' data-toggle='tooltip' data-placement='top' title='New Record Awaiting Approval'>*</span> $activity_type</td><td></td><td>$year1</td><td>$session1</td></tr>";
                                                                        }
                                                                    }
                                                                }

                                                                ?>
                                                        </tbody>
                                                    </table>
                                                    <?php } ?>
                                                </div>
                                                <hr class="separator" />
                                                <div>
                                                    <h3 style="text-align: center">FUNDED RESEARCH AND CONSULTANCY</h3>
                                                    <?php
                                                    $sql = "SELECT * FROM funded_research WHERE staffid = '$staffid' ORDER BY session1";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                    <table class="table mb-none">
                                                        <thead>
                                                            <tr>
                                                                <th>Project No</th>
                                                                <th>Title of Award</th>
                                                                <th>In-Kind Required by Grant</th>
                                                                <th>Release Time</th>
                                                                <th>Total (Amount)</th>
                                                                <th>Remark</th>
                                                                <th>Session</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $projt_no = $row['projt_no'];
                                                                    $projt_title = $row['projt_title'];
                                                                    $reguire_grant = $row['reguire_grant'];
                                                                    //$release_time = $row['release_time'];
                                                                    $release_time = date('d F, Y', strtotime($row["release_time"]));
                                                                    $session_research = $row['session1'];
                                                                    //$totamount = number_format($row['totamount'], 2);
                                                                    $totamount = $row['totamount'];
                                                                    $remark1 = $row['remark1'];
                                                                    $id_research = $row['id'];
                                                                    $approval_research = $row['approval'];
                                                                    if ($approval_research == "YES") {
                                                                        echo "<tr><td>$projt_no</td><td>$projt_title</td><td>$reguire_grant</td><td>$release_time</td><td>$totamount</td><td>$remark1</td><td>$session_research</td></tr>";
                                                                    } else {
                                                                        echo "<tr><td><span class='required' style='font-size: large' data-toggle='tooltip' data-placement='top' title='New Record Awaiting Approval'>*</span> $projt_no</td><td>$projt_title</td><td>$reguire_grant</td><td>$release_time</td><td>$totamount</td><td>$remark1</td><td>$session_research</td></tr>";
                                                                    }
                                                                }

                                                                ?>
                                                        </tbody>
                                                    </table>
                                                    <?php } ?>

                                                </div>
                                                <hr class="separator" />
                                                <div>
                                                    <h3 style="text-align: center">COMMUNITY SERVICE (<i>Services
                                                            Rendered Without Demand
                                                            for Payment</i>)</h3>
                                                    <?php
                                                    $sql = "SELECT * FROM comm_service WHERE staffid = '$staffid' ORDER BY session1";
                                                    $result = $conn7->query($sql);
                                                    if ($result->num_rows > 0) {
                                                    ?>
                                                    <table class="table mb-none">
                                                        <thead>
                                                            <tr>
                                                                <th>Type</th>
                                                                <th>Beneficiary</th>
                                                                <th>Effect</th>
                                                                <th>Date</th>
                                                                <th>Session</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $type_comm = $row['type_comm'];
                                                                    $beneficiary = $row['beneficiary'];
                                                                    $effect = $row['effect'];
                                                                    // $date_comm = $row['date_comm'];
                                                                    $date_comm = date('d F, Y', strtotime($row["date_comm"]));
                                                                    $session_comm = $row['session1'];
                                                                    $approval_comm = $row['approval'];
                                                                    $id_comm = $row['id'];
                                                                    if ($approval_comm == "YES") {
                                                                        echo "<tr><td>$type_comm</td><td>$beneficiary</td><td>$effect</td><td>$date_comm</td><td>$session_comm</td></tr>";
                                                                    } else {
                                                                        echo "<tr><td><span class='required' style='font-size: large' data-toggle='tooltip' data-placement='top' title='New Record Awaiting Approval'>*</span> $type_comm</td><td>$beneficiary</td><td>$effect</td><td>$date_comm</td><td>$session_comm</td></tr>";
                                                                    }
                                                                }

                                                                ?>
                                                        </tbody>
                                                    </table>
                                                    <?php } ?>

                                                </div>
                                                <br>
                                                <hr class="separator" />
                                                <br>
                                                <div>
                                                    <?php

                                                    //$sql = "INSERT INTO " . $dept . " (staffid, imageid, imageType, imageData, imagetitle) VALUE ('$staffid', '$imageid', '{$imageProperties['mime']}', '{$imgData}', '$filename')";
                                                    //$result = $conn12->query($sql);


                                                    $sql = "SELECT * FROM " . $dept . " WHERE staffid = '$staffid'";
                                                    $result = $conn12->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $img_id = $row["id"];
                                                            $from_cert = $row["from_cert"];
                                                    ?>
                                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($row["imageData"]) ?>"
                                                        class="img-responsive" alt="Project" /><br>
                                                    <?php
                                                        }
                                                    }

                                                    ?>

                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </section>

                                <hr class="separator" />
                                <div style="text-align: right">
                                    <input type="button" onclick="printDiv('printableAreaAll')" value="print"
                                        class="btn-success" />
                                </div>
                                <br><br>
                            </div>
                            <div class="col-lg-2">

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>
    <?php
    $conn->close();
    $conn2->close();
    $conn7->close();
    ?>
    <?php
    include_once 'includes/footer.php';
    ?>

</body>

</html>
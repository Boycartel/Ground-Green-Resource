<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="js/getexcel/tableToExcel_R.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Download DE Screened Candidates</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                DE Admission Screening
                            </li>

                            <li class="active">
                                <strong>Download DE Screened Candidates</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Download DE Screened Candidates
                        </div>
                        <div class="panel-body">
                            <?php
                            $getyear = $_SESSION["getyear"];
                            $GetTitle = "DE Admission Screening for the year " . $getyear;
                            ?>
                            <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups"
                                frame="hsides" border="2">
                                <caption><?php echo $GetTitle ?></caption>
                                <colgroup align="center"></colgroup>
                                <colgroup align="left"></colgroup>
                                <colgroup span="2"></colgroup>
                                <colgroup span="3" align="center"></colgroup>
                                <thead>
                                    <tr>
                                        <th>S/No</th>
                                        <th>JAMB No.</th>
                                        <th>Name</th>
                                        <th>Sex</th>
                                        <th>State Origin</th>
                                        <th>Dept</th>
                                        <th>School</th>
                                        <th>High Quali</th>
                                        <th>ND Grade</th>
                                        <th>HND Grade</th>
                                        <th>NCE Edu</th>
                                        <th>NCE Major</th>
                                        <th>IJMB Subjects</th>
                                        <th>FUT IJMB</th>
                                        <th>Score</th>
                                        <th>Level Admt</th>
                                        <th>Remark</th>

                                    </tr>
                                </thead>
                                <tbody>

                                    <?php

                                    $sno = 0;

                                    if ($cat_Acad_Ofice == "YES") {
                                        $sql2 = "SELECT * FROM de_screening WHERE FUTMX_SCH_CODE = '$schcode' AND year1 = '$getyear' ORDER BY CandName";
                                    } elseif ($cat_AcadSec == "YES" || $cat_Administrator == "YES") {
                                        $sql2 = "SELECT * FROM de_screening WHERE year1 = '$getyear' ORDER BY CandName";
                                    }
                                    $result2 = $conn11->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $HQual = $NDgrade = $HNDgrade = $NCEEdu = $NCEGS = $NCEMj = "-";
                                            $Remk = "Yet";
                                            $tot_score = 0;
                                            $MyJAMBNo = $row2["RegNumb"];
                                            $HQual = $row2["high_qual"];
                                            $NDgrade = $row2["nd_result"];
                                            $HNDgrade = $row2["hnd_result"];
                                            $NCEEdu = $row2["nce_education"];
                                            $level_admt = $row2["level_admt"];
                                            $NCEMj = $row2["nce_major1"];
                                            $Remk = $row2["remark"];
                                            $tot_score = $row2["tot_score"];

                                            $IJMB_Subjects = "-";
                                            $fut_IJMB2 = "-";
                                            if ($HQual == "IJMB") {
                                                $sql = "SELECT * FROM de_ijmb_subject WHERE JAMB_No = '$MyJAMBNo'";
                                                $result = $conn11->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $IJMB_Subjects = $row['sub1'] . "(" . $row['grade1'] . ")" . " " . $row['sub2'] . "(" . $row['grade2'] . ")" . " " . $row['sub3'] . "(" . $row['grade3'] . ")";
                                                        $fut_IJMB2 = $row['fut_IJMB'];
                                                    }
                                                }
                                            }
                                            $sql = "SELECT * FROM fchoice_" . $getyear . " WHERE RegNumb = '$MyJAMBNo'";
                                            $result = $conn11->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $sno++;
                                                    echo "<tr><td>$sno</td><td>{$row['RegNumb']}</td><td>{$row['CandName']}</td><td>{$row['Sex']}</td><td>{$row['StateOfOrigin']}</td><td>{$row['FUTMX_DEPT_CODE']}</td><td>{$row['FUTMX_SCH_CODE']}</td><td>$HQual</td><td>$NDgrade</td><td>$HNDgrade</td><td>$NCEEdu</td><td>$NCEMj</td><td>$IJMB_Subjects</td><td>$fut_IJMB2</td><td>$tot_score</td><td>$level_admt</td><td>$Remk</td>";

                                                    echo "</tr>\n";
                                                }
                                            }
                                        }
                                    }




                                    ?>

                                </tbody>
                            </table>
                            <br>
                            <div style="text-align: right">
                                <a href="#" id="test" onClick="javascript:fnExcelReport();"
                                    class="btn btn-primary">Download</a>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

</body>

</html>
<?php
$userdept = $_SESSION['deptcode'];
$userid = $_SESSION["staffid"];
$usernames = $_SESSION['names'];
$useremail = $_SESSION['email'];
$deptname = $_SESSION['deptname'];
//$cat = $_SESSION['cat'];
$corntsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];


$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}
$getDE = "NO";
$siwesstatus = $_SESSION["siwesstatus"];
$deptoption = $_SESSION['deptoption'];
$matno = str_replace("'", "", $_POST['id']);
$matno = filter_var(strtoupper($matno), FILTER_SANITIZE_STRING);

$Is500L = "NO";



$sql = "SELECT * FROM std_data_view WHERE matric_no = '$matno'";
$result = $conn2->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $stdid = $row["stdid"];
        $fulname = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
        $prog = "XXX";
        $permaddres = $row['p_address'];
        if (isset($_POST["view_in_sess"])) {
            $yeargrad = 0;
        } else {
            $yeargrad = $_SESSION['getyeargrad'];
        }

        $deptname = $row['department'];
        $dept = strtolower($row['dept_code']);
        $school = $row['school'];
        $stateorigin = $row['state'];
        $Stu_Dept_Opt = strtoupper($row["Dept_Option"]);
        $entry_session = $row['entry_session'];
        $YAddmitted = substr($entry_session, 0, 4);
        $entry_level = $row['entry_level'];

        if ($entry_level == 200) {
            $getDE = "DE200";
        } elseif ($entry_level == 300) {
            $getDE = "DE300";
        } elseif ($entry_level == 100) {
        }

        $PlaceBirth = "XX";

        $lga = $row['lga'];
        $sex1 = $row['gender'];


        $national = $row['nationality'];
        $dob = $row['dob'];


        $name_first = $row['first_name'];
        $name_last = $row['surname'];
        if (empty($row['other_name'])) {
            $name_middle = "";
        } else {
            $name_middle = $row['other_name'];
        }

        $modeofentry = $row["modeofentry"];
        if ($modeofentry == "ND") {
            $prog = "National Diploma";
        } elseif ($modeofentry == "HND") {
            $prog = "Higher National Diploma";
        }
    }
}

$sql = "SELECT * FROM std_login WHERE stdid = '$stdid'";
$result = $conn2->query($sql);
if ($result->num_rows > 0) {
    $passportid = $stdid;
} else {
    $passportid = $matno;
}
unset($ccode_tot);
unset($semester_tot);
unset($ctitle_tot);
unset($cunit_tot);
unset($grade_tot);
unset($gpoint_tot);

unset($countSesRes);
unset($sessionarry);
$sessionarry[] = "";

unset($SemCr1ST);
unset($SemCr2ND);
unset($CGPA1ST);
unset($CGPA2ND);
$SessionCount = 0;

/* $yearadmt = substr($entry_session, 0, 4);
if ($entry_level == 200) {
    $yearadmt = $yearadmt - 1;
} elseif ($entry_level == 300) {
    $yearadmt = $yearadmt - 2;
} */
$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}
//if (isset($_POST["view_in_sess"])) {
unset($getSessionUnGrad);
$getSessionUnGrad[] = "";
$countses = 0;
$resultsession = $_SESSION['resultsession'];
$resultsemester = $_SESSION['resultsemester'];
$FinalYear = substr($resultsession, 0, 4);
$StartYear = substr($entry_session, 0, 4);

for ($x = $StartYear; $x <= $FinalYear; $x++) {
    //$getstuSession2 = $x . "/" . ($x + 1);
    $sessionarry[$countses] = $x . "/" . ($x + 1);
    $countses++;

    /*
        $StuCurSess = str_ireplace("/", "_", $getstuSession2);
        $deptcorreg = "correg_" . $StuCurSess;

        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$matno'";
        $result = $conn_stu->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $countses++;
                $getSessionUnGrad[$countses] = $row['SessionRegis'];
            }
        }
        
        $sessionarry = array_values(array_unique($getSessionUnGrad));
        $getMaxSess = max($sessionarry);
        */
}
//}
$countSession = $countses - 1;
$getMaxSess = max($sessionarry);
$SemSumCR = 0;

$totgp = 0;


for ($x = 0; $x <= $countSession; $x++) {
    $maxLevel = 0;
    $countSesRes[$x] = 0;
    $stcp = 0;
    $SemCr1STsum = 0;
    $SemCr2NDsum = 0;
    $GRDpt1ST = 0;
    $GRDpt2ND = 0;

    //echo $sessionarry[$x] . "<br>";

    $StuCurSess = str_ireplace("/", "_", $sessionarry[$x]);

    $deptcorreg = "correg_" . $StuCurSess;
    if ($sessionarry[$x] == $getMaxSess) {
        if ($getMaxSess == $resultsession && $resultsemester == "1ST") {
            $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' AND SemTaken = '1ST' ORDER BY SemTaken, CCode";
        } else {
            $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
        }
    } else {
        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
    }

    //$sql = "SELECT * FROM ".$dept."_correg WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
    $result = $conn_stu->query($sql);
    $totunit = $cgpa = $gtotgp = $gtotunit = 0;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            $ccode = $row['CCode'];
            $ctitle = $row['CTitle'];
            $cunit = $row['CUnit'];
            $semester = $row['SemTaken'];

            $gpoint = $row['point'];
            $grade = $row['grade'];
            $stcp = $stcp + $cunit;


            if ($semester == "1ST") {
                $SemCr1STsum = $SemCr1STsum + $cunit;
                $GRDpt1ST = $GRDpt1ST + $gpoint;
            } else {
                $SemCr2NDsum = $SemCr2NDsum + $cunit;

                $GRDpt2ND = $GRDpt2ND + $gpoint;
            }
            $SemSumCR = $SemSumCR + $cunit;

            $totunit = $totunit + $cunit;
            $totgp = $totgp + $gpoint;

            $ccode_tot[$x][$countSesRes[$x]] = $ccode;
            $ctitle_tot[$x][$countSesRes[$x]] = $ctitle;
            $cunit_tot[$x][$countSesRes[$x]] = $cunit;
            $grade_tot[$x][$countSesRes[$x]] = $grade;
            $gpoint_tot[$x][$countSesRes[$x]] = $gpoint;
            $semester_tot[$x][$countSesRes[$x]] = $semester;

            $countSesRes[$x]++;
        }
    }
    $SessionCount = $x;
    $SemCr1ST[$x] = $SemCr1STsum;
    $SemCr2ND[$x] = $SemCr2NDsum;

    $CGPA1ST[$x] = number_format(($totgp - $GRDpt2ND) / ($SemSumCR - $SemCr2NDsum), 2);
    $CGPA2ND[$x] = number_format($totgp / $SemSumCR, 2);
}
$conn->close();
$conn2->close();
$conn_stu->close();
?>

<header class="panel-heading tab-bg-info">
    <ul class="nav nav-tabs">
        <li class="active">
            <a data-toggle="tab" href="#page1">
                Page 1
            </a>
        </li>
        <?php if ($SessionCount >= 6) { ?>
        <li>
            <a data-toggle="tab" href="#page2">
                Page 2
            </a>
        </li>
        <?php } ?>

    </ul>
</header>

<div class="panel-body">
    <div class="tab-content">

        <div id="page1" class="tab-pane active">
            <div id="printableArea" style="width: auto; float: none">
                <style>
                table,
                th,
                td {
                    /*border: 1px solid black;*/
                    border-collapse: collapse;
                }
                </style>
                <table style="width: 99%">
                    <tbody>
                        <tr>
                            <td>

                                <table style="width: 100%">
                                    <tbody>
                                        <tr>
                                            <td style="width: 10%">
                                                <img src="img/logo.ico" height="70" alt="FUTMinna" />
                                            </td>
                                            <td style="width: 80%">
                                                <h6 style="text-align: center; font-size: 14px">
                                                    <strong>
                                                        <?php echo $_SESSION['instname'] ?><br>

                                                        <?php echo strtoupper($school) ?><br>
                                                        DEPARTMENT OF
                                                        <?php echo strtoupper($deptname) ?><br>
                                                        <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                                        <?php echo strtoupper($prog) ?><br>
                                                        <?php } ?>

                                                        STUDENT'S RESULTS<br>
                                                    </strong>
                                                </h6>
                                            </td>
                                            <td>
                                                <figure class="profile-picture">
                                                    <?php

                                                    $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                    $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                                    echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='70' height='70'>";

                                                    ?>
                                                </figure>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table style="font-size:11px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                                    <tbody style="color: #0a0a0a">
                                        <tr>
                                            <th style="text-align: left;width: 10%">SURNAME
                                                :</th>
                                            <td style="width: 30%; text-align: left; padding-left: 1em">
                                                <?php echo $name_first ?></td>
                                            <th style="padding-left: 1em;width: 12%; text-align: left">
                                                OTHER NAME(S) :</th>
                                            <td style="padding-left: 1em;width: 18%">
                                                <?php echo $name_middle . " " . $name_last ?>
                                            </td>
                                            <th style="padding-left: 1em;width: 18%; text-align: left">
                                                MATRICULATION NUMBER :</th>
                                            <td style="padding-left: 1em">
                                                <?php echo $matno ?></td>
                                        </tr>

                                    </tbody>
                                </table>
                                <table style='border: 1px solid black; border-collapse: collapse; width: 100%'>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <table style="color: #0a0a0a; width: 100%; font-size: 10px; ">
                                                    <tbody>

                                                        <tr>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 0) {
                                                                    echo $sessionarry[0];
                                                                } ?></th>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 1) {
                                                                    echo $sessionarry[1];
                                                                } ?></th>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 2) {
                                                                    echo $sessionarry[2];
                                                                } ?></th>
                                                        </tr>
                                                        <tr>
                                                            <th valign="top" style="width: 33%">
                                                                <?php
                                                                $arrayNumb = 0;
                                                                if ($countSession >= 0) {
                                                                    include 'modulesInSess/stu_sem_results_inc.php';
                                                                }
                                                                ?>

                                                            </th>
                                                            <th valign="top" style="width: 33%">
                                                                <?php
                                                                $arrayNumb = 1;
                                                                if ($countSession >= 1) {
                                                                    include 'modulesInSess/stu_sem_results_inc.php';
                                                                }
                                                                ?>
                                                            </th>
                                                            <th valign="top">
                                                                <?php
                                                                $arrayNumb = 2;
                                                                if ($countSession >= 2) {
                                                                    include 'modulesInSess/stu_sem_results_inc.php';
                                                                }
                                                                ?>
                                                            </th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <br>
                                <table style='border: 1px solid black; border-collapse: collapse; width: 100%'>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <table style="color: #0a0a0a; width: 100%; font-size: 10px; ">
                                                    <tbody>

                                                        <tr>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 3) {
                                                                    echo $sessionarry[3];
                                                                } ?></th>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 4) {
                                                                    echo $sessionarry[4];
                                                                } ?></th>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 5) {
                                                                    echo $sessionarry[5];
                                                                } ?></th>
                                                        </tr>
                                                        <tr>
                                                            <th valign="top" style="width: 33%">
                                                                <?php
                                                                $arrayNumb = 3;
                                                                if ($countSession >= 3) {
                                                                    include 'modulesInSess/stu_sem_results_inc.php';
                                                                }
                                                                ?>

                                                            </th>
                                                            <th valign="top" style="width: 33%">
                                                                <?php
                                                                $arrayNumb = 4;
                                                                if ($countSession >= 4) {
                                                                    include 'modulesInSess/stu_sem_results_inc.php';
                                                                }
                                                                ?>
                                                            </th>
                                                            <th valign="top">
                                                                <?php
                                                                $arrayNumb = 5;
                                                                if ($countSession >= 5) {
                                                                    include 'modulesInSess/stu_sem_results_inc.php';
                                                                }
                                                                ?>
                                                            </th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <br>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="width: 40%; text-align: left">
                                                <?php echo $_SESSION["HOD_Sign"] ?></td>
                                            <td style="width: 25%"></td>
                                            <td style="text-align: left"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left">HOD's SIGNATURE AND
                                                DATE</td>
                                            <td></td>
                                            <td style="text-align: left"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>

                        </tr>
                    </tbody>
                </table>

            </div>
            <div class="row" style="text-align: right">
                <br>
                <input type="button" onclick="printDiv('printableArea')" value="print to PDF" class="btn-success" />
            </div>
        </div>
        <!-- profile -->
        <?php if ($countSession >= 6) { ?>
        <div id="page2" class="tab-pane">
            <div id="printableArea2" style="width: auto; float: none">
                <table style="width: 99%">
                    <tbody>
                        <tr>
                            <td>

                                <table style="width: 100%">
                                    <tbody>
                                        <tr>
                                            <td style="width: 10%">
                                                <img src="assets/images/futlogo.png" height="70" alt="FUTMinna" />
                                            </td>
                                            <td style="width: 80%">
                                                <h6 style="text-align: center; font-size: 14px">
                                                    <strong>
                                                        <?php echo $_SESSION['instname'] ?><br>
                                                        <?php echo $_SESSION['sch_faculty'] ?>
                                                        OF
                                                        <?php echo strtoupper($school) ?><br>
                                                        DEPARTMENT OF
                                                        <?php echo strtoupper($deptname) ?><br>
                                                        <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                                        <?php echo strtoupper($prog) ?><br>
                                                        <?php } ?>
                                                        STUDENT'S RESULTS<br>
                                                    </strong>
                                                </h6>
                                            </td>
                                            <td>
                                                <figure class="profile-picture">
                                                    <?php
                                                        $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                        $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                                        echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='70' height='70'>";

                                                        ?>
                                                </figure>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table style="font-size:11px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                                    <tbody style="color: #0a0a0a">
                                        <tr>
                                            <th style="text-align: left;width: 10%">SURNAME
                                                :</th>
                                            <td style="width: 30%; text-align: left; padding-left: 1em">
                                                <?php echo $name_first ?></td>
                                            <th style="padding-left: 1em;width: 12%; text-align: left">
                                                OTHER NAME(S) :</th>
                                            <td style="padding-left: 1em;width: 18%">
                                                <?php echo $name_middle . " " . $name_last ?>
                                            </td>
                                            <th style="padding-left: 1em;width: 18%; text-align: left">
                                                MATRICULATION NUMBER :</th>
                                            <td style="padding-left: 1em">
                                                <?php echo $matno ?></td>
                                        </tr>

                                    </tbody>
                                </table>
                                <table style='border: 1px solid black; border-collapse: collapse; width: 100%'>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <table style="color: #0a0a0a; width: 100%; font-size: 10px; ">
                                                    <tbody>

                                                        <tr>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 6) {
                                                                        echo $sessionarry[6];
                                                                    } ?></th>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 7) {
                                                                        echo $sessionarry[7];
                                                                    } ?></th>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 8) {
                                                                        echo $sessionarry[8];
                                                                    } ?></th>
                                                        </tr>
                                                        <tr>
                                                            <th valign="top" style="width: 33%">
                                                                <?php
                                                                    $arrayNumb = 6;
                                                                    if ($countSession >= 6) {
                                                                        include 'modulesInSess/stu_sem_results_inc.php';
                                                                    }
                                                                    ?>

                                                            </th>
                                                            <th valign="top" style="width: 33%">
                                                                <?php
                                                                    $arrayNumb = 7;
                                                                    if ($countSession >= 7) {
                                                                        include 'modulesInSess/stu_sem_results_inc.php';
                                                                    }
                                                                    ?>
                                                            </th>
                                                            <th valign="top">
                                                                <?php
                                                                    $arrayNumb = 8;
                                                                    if ($countSession >= 8) {
                                                                        include 'modulesInSess/stu_sem_results_inc.php';
                                                                    }
                                                                    ?>
                                                            </th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                                <br>
                                <table style='border: 1px solid black; border-collapse: collapse; width: 100%'>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <table style="color: #0a0a0a; width: 100%; font-size: 10px; ">
                                                    <tbody>

                                                        <tr>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 9) {
                                                                        echo $sessionarry[9];
                                                                    } ?></th>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 10) {
                                                                        echo $sessionarry[10];
                                                                    } ?></th>
                                                            <th
                                                                style="border-style:solid; border-width:thin; text-align:center">
                                                                <?php if ($countSession >= 11) {
                                                                        echo $sessionarry[11];
                                                                    } ?></th>
                                                        </tr>
                                                        <tr>
                                                            <th valign="top" style="width: 33%">
                                                                <?php
                                                                    $arrayNumb = 9;
                                                                    if ($countSession >= 9) {
                                                                        include 'modulesInSess/stu_sem_results_inc.php';
                                                                    }
                                                                    ?>

                                                            </th>
                                                            <th valign="top" style="width: 33%">
                                                                <?php
                                                                    $arrayNumb = 10;
                                                                    if ($countSession >= 10) {
                                                                        include 'modulesInSess/stu_sem_results_inc.php';
                                                                    }
                                                                    ?>
                                                            </th>
                                                            <th valign="top">
                                                                <?php
                                                                    $arrayNumb = 11;
                                                                    if ($countSession >= 11) {
                                                                        include 'modulesInSess/stu_sem_results_inc.php';
                                                                    }
                                                                    ?>
                                                            </th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <br>
                                <table style="width: 100%; font-size: 10px">
                                    <tbody>
                                        <tr>
                                            <td style="width: 40%; text-align: left">
                                                <?php echo $_SESSION["HOD_Sign"] ?></td>
                                            <td style="width: 25%"></td>
                                            <td style="text-align: left"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: left">HOD's SIGNATURE AND
                                                DATE</td>
                                            <td></td>
                                            <td style="text-align: left"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>

                        </tr>
                    </tbody>
                </table>

            </div>
            <div class="row" style="text-align: right">
                <br>
                <input type="button" onclick="printDiv('printableArea2')" value="print to PDF" class="btn-success" />
            </div>
        </div>

        <?php } ?>
    </div>
</div>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php
        include_once 'includes/header2_pg.php';
        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/pg_aside_menu.php';
            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Course Registration</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="stu_course_reg.php">
                                    <i class="fa fa-list"></i>
                                </a>
                            </li>
                            <li><span>Course Reg.</span></li>
                            <li><span>Course Registration</span></li>
                            <li><span>Course Reg Preview</span></li>
                            <li><span>Record Saved</span></li>
                        </ol>


                    </div>
                </header>


                <!-- start: page -->
                <div class="row">

                    <div class="col-md-1">
                    </div>
                    <div class="col-md-10">
                        <section class="panel panel-success">
                            <header class="panel-heading">
                                <div class="panel-actions">
                                    <a href="#" class="fa fa-caret-down"></a>
                                    <a href="#" class="fa fa-times"></a>
                                </div>

                                <h2 class="panel-title">Record Saved Successfully</h2>
                            </header>
                            <div class="panel-body">
                                <form class="form-horizontal" role="form" method="post" action="stu_registered_course.php">
                                    <div class="col-lg-6 col-md-6" style="text-align:right; text-align:center">

                                        <?php
                                        $names = $_SESSION['names'];
                                        $names = str_replace("'", "''", $names);


                                        $regid = $_SESSION["regid"];
                                        $dept = $_SESSION['deptcode'];
                                        $curtsession = $_SESSION['corntsession'];
                                        $date1 = date("Y-m-d");

                                        $sql = "DELETE FROM courses_register WHERE Regn1 ='$regid' AND session ='$curtsession'";
                                        $result = $conn->query($sql);

                                        $sql = "SELECT * FROM coursesregis WHERE Regn1 = '$regid'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {

                                            while ($row = $result->fetch_assoc()) {
                                                $ccode = $row["CCode"];
                                                $CTitle = str_replace("'", "''", $row["CTitle"]);
                                                $CUnit = $row["CUnit"];
                                                $SemTaken = $row["SemTaken"];
                                                $Nature = $row["Nature"];
                                                // sql to insert record
                                                $sql2 = "INSERT INTO courses_register (Regn1, name1, CCode, CUnit, CTitle, SemTaken, Nature, session, departments, date) VALUES ('$regid', '$names', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature', '$curtsession', '$dept', '$date1')";
                                                $result2 = $conn->query($sql2);
                                            }
                                        }

                                        $sql = "SELECT * FROM " . $dept . "_hod_list WHERE matricno = '$regid' AND Session1 ='$curtsession'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows == 0) {
                                            $sql2 = "INSERT INTO " . $dept . "_hod_list (matricno, LevelAdvice, session1, LAComment) VALUES ('$regid', 'Yet', '$curtsession', '_')";
                                            $result2 = $conn->query($sql2);
                                        }

                                        $conn->close();
                                        ?>

                                        <button type="submit" name="submit3" class="btn btn-primary">Back to Registered
                                            Courses</button>
                                    </div>
                        </section>
                    </div>
                    <div class="col-md-1">
                    </div>

                </div>

                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>




</body>

</html>
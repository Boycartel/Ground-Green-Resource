<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['board_format'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php $_SESSION['instcode'] ?> Students Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword" content="Results, Result, eresults, e-results, portal">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>

    <style>
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }
    </style>


    <style>
        .btn-xs,
        .btn-group-xs>.btn {
            padding: 1px 5px;
            font-size: 11px;
            line-height: 1.5;
            border-radius: 3px;
        }
    </style>


    <style type="text/css">
        table {
            page-break-inside: avoid;
        }

        h1,
        h2,
        h3,
        h4,
        h5 {
            page-break-after: avoid;
        }

        @page {
            size: A4 landscape;
            font-size: small;
        }

        @page :left {
            margin-left: 1cm;
        }

        @page :right {
            margin-left: 2cm;
        }
    </style>


    <script type="text/javascript">
        function printDiv(div_id) {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var content_vlue = document.getElementById(div_id).innerHTML;

            var docprint = window.open("", "", disp_setting);

            ///// Enable Bootstrap CSS
            //// Can also add customise CSS
            docprint.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
            );
            docprint.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    </script>



    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
        <form class="form-horizontal form-bordered" method="post">

            <div class="row">
                <h2 class="panel-title" style="text-align: center">EXAMINATION RESULTS SUMMARY REPORT</h2>
                <br><br><br>
                <div class="col-lg-5">
                    <div class="row">
                        <label class="control-label col-lg-5" for="content">Select Department:</label>
                        <div class="col-lg-7">
                            <select class="country form-control" style="color:#000000" name="dept">
                                <option value="SelectItem">Select Item</option>
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $dept = $_SESSION['deptcode'];


                                if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                } else {
                                    $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                }


                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    // output data of each row
                                    while ($row = $result->fetch_assoc()) {
                                        $deptcode2 = strtolower($row["DeptCode"]);
                                        $deptname2 = $row["DeptName"];
                                        echo "<option value=$deptcode2>$deptname2</option>";
                                    }
                                }
                                $conn->close();
                                ?>

                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="row">
                        <label class="control-label col-lg-5" for="regid">Level:</label>
                        <div class="col-lg-7">
                            <select name="getlevel" class="form-control" style="color:#000000" id="getlevel">
                                <option value="100">ND I</option>
                                <option value="200">ND II</option>
                                <option value="300">HND I</option>
                                <option value="400">HND II</option>


                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="row">
                        <label class="control-label col-lg-5" for="regid">Session:</label>
                        <div class="col-lg-7">
                            <?php
                            $iniyear = 2015;
                            $finalyear = substr($_SESSION['corntsession'], 5);

                            ?>
                            <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                <option value="<?php echo $_SESSION['corntsession'] ?>">
                                    <?php echo $_SESSION['corntsession'] ?></option>
                                <?php
                                while ($iniyear <= $finalyear) {
                                    $addyear = $iniyear + 1;

                                    echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                    $iniyear++;
                                }

                                ?>


                            </select>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="row">
                        <label class="control-label col-lg-4" for="regid">Semester:</label>
                        <div class="col-lg-4">
                            <select name="getsemester" class="form-control" style="color:#000000" id="getsemester">
                                <option value="1ST">1ST</option>
                                <option value="2ND">2ND</option>

                            </select>
                        </div>
                        <div class="col-lg-4">
                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                        </div>
                    </div>
                </div>
            </div>
        </form>
        <hr class="separator" />
    </div>
    <?php if (isset($_POST["submit"])) { ?>

        <?php
        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $_SESSION['dept_sctny'] = $_POST["dept"];
        $_SESSION['getsession_sctny'] = $_POST["getsession"];
        $_SESSION['getsemester_sctny'] = $_POST["getsemester"];
        $_SESSION['getlevel_sctny'] = $_POST["getlevel"];

        if ($_SESSION['getlevel_sctny'] == "100" || $_SESSION['getlevel_sctny'] == "200") {
            $prog = "ND";
        } else {
            $prog = "HND";
        }
        $OnGroup = false;
        $dept = $_SESSION['dept_sctny'];

        $sql = "SELECT * FROM dept_stu_group WHERE deptcode = '$dept' AND PROG = '$prog'";
        $result = $conn->query($sql);
        if ($result->num_rows > 1) {
            $OnGroup = true;
        }

        $conn->close();
        ?>
        <?php if ($OnGroup == true) { ?>
            <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
                <form class="form-horizontal form-bordered" method="post">

                    <div class="row" style="text-align: right;">

                        <div class="row">

                            <label class="control-label col-lg-4" for="regid">Group:</label>
                            <div class="col-lg-4">
                                <select name="getgroup" class="form-control" style="color:#000000" id="getgroup">
                                    <?php
                                    $sql = "SELECT * FROM dept_stu_group WHERE deptcode = '$dept' AND PROG = '$prog'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $group_Code = $row["group_Code"];
                                            $group_Title = $row["group_Title"];
                                            echo "<option value=$group_Code>$group_Title</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="col-lg-4" style="text-align: left;">
                                <button type="submit" name="submitgroup" class="btn btn-primary btn-sm">Submit</button>

                            </div>
                        </div>

                    </div>
                </form>
            </div>
        <?php } ?>
        <hr class="separator" />
    <?php } ?>
    <div style="padding-left:3em; padding-right: 3em">

        <?php if (isset($_POST["submit"])) { ?>
            <?php
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
            if ($conn2->connect_error) {
                die("Connection failed: " . $conn2->connect_error);
            }

            set_time_limit(1000);
            $DegType = $_SESSION['DegType'];

            if (isset($_POST["submit"])) {
                $_SESSION['dept_sctny'] = $_POST["dept"];
                $_SESSION['getsession_sctny'] = $_POST["getsession"];
                $_SESSION['getsemester_sctny'] = $_POST["getsemester"];
                $_SESSION['getlevel_sctny'] = $_POST["getlevel"];
                $_SESSION['getgroup'] = "NG";
            }

            if (isset($_POST["submitgroup"])) {
                $getdept = $_SESSION['dept_sctny'];
                $getsession = $_SESSION['getsession_sctny'];
                $getsemester = $_SESSION['getsemester_sctny'];
                $getlevel = $_SESSION['getlevel_sctny'];
                $_SESSION['getgroup'] = $_POST["getgroup"];
            }

            if (!isset($_POST["submit"]) || isset($_POST["submitAll"]) || !isset($_POST["submitgroup"])) {
                $getdept = $_SESSION['dept_sctny'];
                $getsession = $_SESSION['getsession_sctny'];
                $getsemester = $_SESSION['getsemester_sctny'];
                $getlevel = $_SESSION['getlevel_sctny'];
                $getgroup = $_SESSION['getgroup'];
            }

            if ((isset($_POST["submit"]) && $OnGroup == false) || isset($_POST["submitgroup"])) {
                $_SESSION['sn'] = 0;

                $deptname = "";

                $getdept = $_SESSION['dept_sctny'];
                $getsession = $_SESSION['getsession_sctny'];
                $getsemester = $_SESSION['getsemester_sctny'];
                $getlevel = $_SESSION['getlevel_sctny'];
                $getgroup = $_SESSION['getgroup'];

                $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                if ($conn_stu->connect_error) {
                    die("Connection failed: " . $conn_stu->connect_error);
                }

                $hod = "";
                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND Dean = 'YES'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $dean = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND HOD = 'YES'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $hod = $row["full_name"];
                    }
                }

                $sql = "SELECT * FROM users WHERE staffacddept = '$getdept' AND Examiner = 'YES'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $examiner = $row["full_name"];
                    }
                }

                $sql = "SELECT DeptName, DeptCode, School FROM deptcoding WHERE DeptCode = '$getdept'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $deptname = $row["DeptName"];
                        $schcode = $row["School"];
                    }
                }

                $sql = "SELECT * FROM schoolname WHERE SchCode = '$schcode'";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $schname = $row["SchName"];
                    }
                }

                if ($_SESSION['getlevel_sctny'] == 100 || $_SESSION['getlevel_sctny'] == 300) {
                    if ($getsemester == "1ST") {
                        $contactSem = "1<sup>st</sup>";
                    } else {
                        $contactSem = "2<sup>nd</sup>";
                    }
                } elseif ($_SESSION['getlevel_sctny'] == 200 || $_SESSION['getlevel_sctny'] == 400) {
                    if ($getsemester == "1ST") {
                        $contactSem = "3<sup>rd</sup>";
                    } else {
                        $contactSem = "4<sup>th</sup>";
                    }
                }
            ?>
                <section class="panel panel-success">
                    <!--<div style="text-align: center"><h2 class="panel-title"><?php /*echo $deptname */ ?> Department</h2></div>
                <br><br>-->
                    <div class="panel-body">

                        <div class="col-lg-12" id="printableArea">
                            <?php
                            $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;

                            if ($_SESSION['getlevel_sctny'] == 100) {
                                $gLevel = "ND I";
                            } elseif ($_SESSION['getlevel_sctny'] == 200) {
                                $gLevel = "ND II";
                            } elseif ($_SESSION['getlevel_sctny'] == 300) {
                                $gLevel = "HND I";
                            } elseif ($_SESSION['getlevel_sctny'] == 400) {
                                $gLevel = "HND II";
                            }
                            ?>
                            <table class="table table-striped">
                                <thead style='text-align:center'>
                                    <tr>
                                        <th colspan="2">
                                            <img src="img/logo.ico" height="120" width="120" alt="Logo" />
                                        </th>
                                        <th>
                                            <table>
                                                <tr>
                                                    <th style="font-size: xx-large; text-align:left">
                                                        <?php echo $_SESSION['instname'] ?></th>
                                                </tr>
                                                <tr>
                                                    <th style="font-size: large; text-align:left">SCHOOL OF
                                                        <?php echo strtoupper($schname) ?>, DEPARTMENT OF
                                                        <?php echo strtoupper($deptname) ?>
                                                    </th>
                                                </tr>
                                                <tr>
                                                    <th style="text-align:left">
                                                        <?php if ($_SESSION['getlevel_sctny'] == 100 || $_SESSION['getlevel_sctny'] == 200) { ?>
                                                            NATIONAL DIPLOMA PROGRAMME, *
                                                        <?php } else { ?>
                                                            HIGHER NATIONAL DIPLOMA PROGRAMME, *
                                                        <?php } ?>
                                                        (<?php echo $gLevel ?> [FT-*/REGULAR]),
                                                        <?php echo $contactSem ?>
                                                        SEMESTER, <?php echo $_SESSION['getsession_sctny']; ?> SESSION</th>
                                                </tr>
                                                <tr>
                                                    <th style="font-size: x-large; text-align:left">EXAMINATION RESULTS
                                                        SUMMARY REPORT DATE:- <?php echo date("d F, Y") ?></th>
                                                </tr>
                                            </table>
                                        </th>
                                    </tr>

                                </thead>

                            </table>
                            <?php
                            $cgpa_A = $cgpa_AB = $cgpa_B = $cgpa_BC = $cgpa_C = $cgpa_CD = $cgpa_D = $cgpa_E = $tot_roll = $countNoStuF = $countNoStuFOne = $NoOutStd = $TwoORmoreOuts = 0;
                            $ABS = $WAR = $PROB = $RHL = $DHL = $countHGPA = $countHCGPA = $NoRegs = $NoNOTRegs = $WD = 0;
                            $HGPA = $HCGPA = "";
                            $sql2 = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval <> 'Approve'";
                            $result2 = $conn_stu->query($sql2);
                            if ($result2->num_rows > 0) {
                                while ($row2 = $result2->fetch_assoc()) {
                                    $tot_roll++;
                                    if ($row2["CGPA"] >= 3.495) {
                                        $cgpa_A++;
                                    } else if ($row2["CGPA"] >= 3) {
                                        $cgpa_AB++;
                                    } else if ($row2["CGPA"] >= 2.495) {
                                        $cgpa_B++;
                                    } else if ($row2["CGPA"] >= 2) {
                                        $cgpa_BC++;
                                    } else if ($row2["CGPA"] >= 1.495) {
                                        $cgpa_C++;
                                    } else if ($row2["CGPA"] >= 1) {
                                        $cgpa_CD++;
                                    } else if ($row2["CGPA"] >= 0.495) {
                                        $cgpa_D++;
                                    } else if ($row2["CGPA"] >= 0) {
                                        $cgpa_E++;
                                    }

                                    if ($row2["numb_Course_failed"] > 0) {
                                        $countNoStuF++;
                                    }
                                    if ($row2["numb_Course_failed"] == 1) {
                                        $countNoStuFOne++;
                                    }

                                    if ($row2["SCT"] == 0) {
                                        $ABS++;
                                    }


                                    if ($row2["CGPA"] < 1.5) {
                                        $PROB++;
                                    } elseif ($row2["CGPA"] < 2) {
                                        $WAR++;
                                    }


                                    if ($row2["CGPA"] >= 3.495) {
                                        $RHL++;
                                    } elseif ($row2["CGPA"] >= 3.245) {
                                        $DHL++;
                                    }

                                    if ($row2["SGPA"] == 0) {
                                        $NoNOTRegs++;
                                    }

                                    if ($row2["no_semester"] > 1) {
                                        if ($row2["SGPA"] < 1.5 && $row2["CGPA"] < 1) {
                                            $WD++;
                                        }
                                    }
                                }
                            }
                            $NoOutStd = $tot_roll - $countNoStuF;
                            $TwoORmoreOuts = $countNoStuF - $countNoStuFOne;
                            $NoRegs = $tot_roll - $NoNOTRegs;

                            $highestSGPA = $highestCGPA = 0;
                            $highestSGPA_matNo = $highestCGPA_matNo = "";
                            $sql = "SELECT MAX(SGPA) AS maximum FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval <> 'Approve'";
                            $result = $conn_stu->query($sql);
                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $highestSGPA = $row['maximum'];
                            }

                            $sql2 = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND SGPA = '$highestSGPA'";
                            $result2 = $conn_stu->query($sql2);
                            if ($result2->num_rows > 0) {
                                while ($row2 = $result2->fetch_assoc()) {
                                    $highestSGPA_matNo = $highestSGPA_matNo . ", " . $row2["Regn"];
                                }
                            }

                            $sql = "SELECT MAX(CGPA) AS maximum FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval <> 'Approve'";
                            $result = $conn_stu->query($sql);
                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $highestCGPA = $row['maximum'];
                            }

                            $sql2 = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND CGPA = '$highestCGPA'";
                            $result2 = $conn_stu->query($sql2);
                            if ($result2->num_rows > 0) {
                                while ($row2 = $result2->fetch_assoc()) {
                                    $highestCGPA_matNo = $highestCGPA_matNo . ", " . $row2["Regn"];
                                }
                            }
                            ?>
                            <h3><u>ENROLMENT AND EXAMINATION RESULTS ANALYSIS</u></h3>
                            <table style="width: 98%;">
                                <tbody>
                                    <tr>
                                        <td style="width: 50%; border: 1px solid black;">
                                            <table style="width: 98%;">
                                                <tbody>
                                                    <tr>
                                                        <td>1</td>
                                                        <td style="padding-left: 1em;">Number of Students on
                                                            Roll</td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $tot_roll ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td style="padding-left: 1em;">Number of Registered
                                                            Students</td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $NoRegs ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>3</td>
                                                        <td style="padding-left: 1em;">Number of Students Not
                                                            Registered</td>
                                                        <td style="padding-left: 1em; padding-right:1em">
                                                            <?php echo $NoNOTRegs ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>4</td>
                                                        <td style="padding-left: 1em;">Number of Students with No Outstanding
                                                            Courses</td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $NoOutStd ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>5</td>
                                                        <td style="padding-left: 1em;">Number of Students with Outstanding
                                                            Courses
                                                        </td>
                                                        <td style="padding-left: 1em; padding-right:1em">
                                                            <?php echo $countNoStuF ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>6</td>
                                                        <td style="padding-left: 1em;">Number of Students with One Outstanding
                                                            Course</td>
                                                        <td style="padding-left: 1em; padding-right:1em">
                                                            <?php echo $countNoStuFOne ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>7</td>
                                                        <td style="padding-left: 1em;">Number of Students with 2 or More
                                                            Outstanding Courses</td>
                                                        <td style="padding-left: 1em; padding-right:1em">
                                                            <?php echo $TwoORmoreOuts ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>8</td>
                                                        <td style="padding-left: 1em;">Number of Students on
                                                            Warning</td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $WAR ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>9</td>
                                                        <td style="padding-left: 1em;">Number of Students on
                                                            Probation</td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $PROB ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>10</td>
                                                        <td style="padding-left: 1em;">Number of Students on Academic
                                                            Withdrawal
                                                        </td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $WD ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>11</td>
                                                        <td style="padding-left: 1em;">Number of Students Absent from
                                                            Examination
                                                        </td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $ABS ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>12</td>
                                                        <td style="padding-left: 1em;">Number of Students with Graduation Period
                                                            Expired</td>
                                                        <td style="padding-left: 1em; padding-right:1em">0</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                        <td valign="top" style="border: 1px solid black; padding-left:2em">
                                            <table style="width: 100%;">
                                                <tbody>
                                                    <tr>
                                                        <td>13</td>
                                                        <td style="padding-left: 1em;">Number of Students' Results Withheld for
                                                            Various Reasons</td>
                                                        <td style="padding-left: 1em; padding-right:1em">0</td>
                                                    </tr>
                                                    <tr>
                                                        <td>14</td>
                                                        <td style="padding-left: 1em;">Number of Students Rusticated or
                                                            Expelled</td>
                                                        <td style="padding-left: 1em; padding-right:1em">0</td>
                                                    </tr>
                                                    <tr>
                                                        <td>15</td>
                                                        <td style="padding-left: 1em;">Number of Students on Rector's Honour
                                                            List (gpa>=3.5)</td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $RHL ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>16</td>
                                                        <td style="padding-left: 1em;">Number of Students on Dean's Honour List
                                                            (gpa>=3.25)</td>
                                                        <td style="padding-left: 1em; padding-right:1em"><?php echo $DHL ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>17</td>
                                                        <td style="padding-left: 1em;">Highest GPA and Matric Number(s) for the
                                                            Semester</td>
                                                        <td style="padding-left: 1em; padding-right:1em">
                                                            <?php echo $highestSGPA . ", " . $highestSGPA_matNo ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>18</td>
                                                        <td style="padding-left: 1em;">Highest CGPA and Matric Number(s) for all
                                                            Semesters</td>
                                                        <td style="padding-left: 1em; padding-right:1em">
                                                            <?php echo $highestCGPA . ", " . $highestCGPA_matNo ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                            <table style="width: 98%;">
                                <tbody>
                                    <tr>
                                        <th style="text-align:center"><u>CGPA ANALYSIS</u></th>
                                        <th style="text-align:center"><u>0.0 - 0.49</u></th>
                                        <th style="text-align:center"><u>0.5 - 0.99</u></th>
                                        <th style="text-align:center"><u>1.0 - 1.49</u></th>
                                        <th style="text-align:center"><u>1.5 - 1.99</u></th>
                                        <th style="text-align:center"><u>2.0 - 2.49</u></th>
                                        <th style="text-align:center"><u>2.5 - 2.99</u></th>
                                        <th style="text-align:center"><u>3.0 - 3.49</u></th>
                                        <th style="text-align:center"><u>3.5 - 4.0</u></th>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td style="text-align:center"><?php echo $cgpa_E ?></td>
                                        <td style="text-align:center"><?php echo $cgpa_D ?></td>
                                        <td style="text-align:center"><?php echo $cgpa_CD ?></td>
                                        <td style="text-align:center"><?php echo $cgpa_C ?></td>
                                        <td style="text-align:center"><?php echo $cgpa_BC ?></td>
                                        <td style="text-align:center"><?php echo $cgpa_B ?></td>
                                        <td style="text-align:center"><?php echo $cgpa_AB ?></td>
                                        <td style="text-align:center"><?php echo $cgpa_A ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            <br>
                            <h3><u>EXAMINED COURSE CODES, TITLES, UNITS AND LETTER GRADE ANALYSIS</u></h3>
                            <table style="width: 98%;">
                                <thead>
                                    <tr>
                                        <th>S/No</th>
                                        <th>Course Code</th>
                                        <th>Course Title</th>
                                        <th>Unit</th>
                                        <th>Status</th>
                                        <th>A</th>
                                        <th>AB</th>
                                        <th>B</th>
                                        <th>BC</th>
                                        <th>C</th>
                                        <th>CD</th>
                                        <th>D</th>
                                        <th>E</th>
                                        <th>F</th>
                                        <th>S</th>
                                        <th>I</th>
                                        <th>DF</th>
                                        <th>W</th>
                                        <th>NR</th>
                                        <th>TOT</th>
                                        <th>PAS</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sno = 0;
                                    $sql = "SELECT DISTINCT CCode, session1, Level1, DeptCode, SemTaken, levelCode, CTitle, CUnit FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $sno++;
                                            $CourCode = $row["CCode"];
                                            $CourseTitle = $row["CTitle"];
                                            $CourseUnit = $row["CUnit"];
                                            $sql2 = "SELECT * FROM deptcourses WHERE CCode = '$CourCode' AND dept = '$getdept'";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $Nature = $row2["Nature"];
                                                    if ($Nature == "Core") {
                                                        $Nature = "C";
                                                    } else {
                                                        $Nature = "E";
                                                    }
                                                }
                                            }

                                            $A = $AB = $B = $BC = $C = $CD = $D = $E = $F = $TOT = $PAS = $DF = $I = $S = $W = 0;

                                            $dbsession = str_replace("/", "_", $getsession);
                                            $sql2 = "SELECT * FROM raw_results_" . $dbsession . " WHERE CCode = '$CourCode' AND stu_dept = '$getdept'";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $TOT++;
                                                    if ($row2["status1"] == "D") {
                                                        $DF++;
                                                    } elseif ($row2["status1"] == "I") {
                                                        $I++;
                                                    } elseif ($row2["status1"] == "S") {
                                                        $S++;
                                                    } elseif ($row2["status1"] == "W") {
                                                        $W++;
                                                    }
                                                }
                                            }


                                            $corregTB = "correg_" . str_replace("/", "_", $getsession);
                                            $sql2 = "SELECT grade, CCode FROM $corregTB WHERE CCode = '$CourCode'";
                                            $result2 = $conn_stu->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {

                                                    if ($row2["grade"] == "A") {
                                                        $A++;
                                                        $PAS++;
                                                    } else if ($row2["grade"] == "AB") {
                                                        $AB++;
                                                        $PAS++;
                                                    } else if ($row2["grade"] == "B") {
                                                        $B++;
                                                        $PAS++;
                                                    } else if ($row2["grade"] == "BC") {
                                                        $BC++;
                                                        $PAS++;
                                                    } else if ($row2["grade"] == "C") {
                                                        $C++;
                                                        $PAS++;
                                                    } else if ($row2["grade"] == "CD") {
                                                        $CD++;
                                                        $PAS++;
                                                    } else if ($row2["grade"] == "D") {
                                                        $D++;
                                                        $PAS++;
                                                    } else if ($row2["grade"] == "E") {
                                                        $E++;
                                                        $PAS++;
                                                    } else if ($row2["grade"] == "F") {
                                                        $F++;
                                                    }
                                                }
                                            }


                                            echo "<tr><td>$sno</td><td>$CourCode</td><td>$CourseTitle</td><td>$CourseUnit</td><td>$Nature</td><td>$A</td><td>$AB</td><td>$B</td><td>$BC</td><td>$C</td><td>$CD</td><td>$D</td><td>$E</td><td>$F</td><td>$S</td><td>$I</td><td>$DF</td><td>$W</td><td>0</td><td>$TOT</td><td>$PAS</td></tr>";
                                        }
                                    }
                                    ?>
                                    <tr>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                            <br>
                            <p><strong>SCORE GRADING KEY:- [75-100:A/4.0] [70-74:AB/3.5] [65-69:B/3.25] [60-64:BC/3.0]
                                    [55-59:C/2.75] [50-54:CD/2.5] [45-49:D/2.25] [40-44:E/2.0] [0-39:F/0.0]
                                    [X:F/0.0-Absent]; [S/I/D/N/W-Sick/Incomplte/Deferred/Not available/Withdraw
                                    courses].</strong></p>
                            <p><strong>ABBREVIATIONS:- RHL/DHL-Rector's/Dean's Honour List (GPA>=3.5/3.25); PAS-Passed all
                                    courses; COV-Carryover courses; PRO-Probation; WAR-Warning;
                                    WTH-Withheld; INC-Incomplete; WTD-Withdrawn; ABS-Absent from examination; NRE-Not
                                    registered; GPE-Graduation period expired.</strong></p>
                            <table style="width: 98%;">
                                <tbody>
                                    <tr>
                                        <th style="width: 35%; text-align:center">_______________________________</th>
                                        <th style="width: 30%; text-align:center">_______________________________</th>
                                        <th style="text-align:center">_______________________________</th>
                                    </tr>
                                    <tr>
                                        <th style="width: 35%; text-align:center"><?php echo $hod ?></th>
                                        <th style="width: 30%; text-align:center"><?php echo $dean ?></th>
                                        <th style="text-align:center"><?php echo $examiner ?></th>
                                    </tr>
                                    <tr>
                                        <th style="width: 35%; text-align:center">HEAD OF DEPARTMENT</th>
                                        <th style="width: 30%; text-align:center">DEAN OF SCHOOL</th>
                                        <th style="text-align:center">EXAMINATION OFFICER</th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <br><br>
                    <div style="text-align: right; padding-right: 3em">
                        <input type="button" onclick="printDiv('printableArea')" value="print" />
                    </div>
                    <br><br>
                </section>
        <?php
            }
            $conn->close();
            $conn2->close();
            $conn_stu->close();
        }
        ?>

    </div>




</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['board_format'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>


    <style>
    .btn-xs,
    .btn-group-xs>.btn {
        padding: 1px 5px;
        font-size: 12px;
        line-height: 1.5;
        border-radius: 3px;
    }
    </style>

    <style type="text/css">
    table {
        page-break-inside: avoid;
    }

    h1,
    h2,
    h3,
    h4,
    h5 {
        page-break-after: avoid;
    }

    @page {
        size: A4 landscape;
        font-size: small;
    }

    @page :left {
        margin-left: 1cm;
    }

    @page :right {
        margin-left: 2cm;
    }
    </style>

    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">
        <?php
        if (isset($_POST["submit_sel"])) {
            $_SESSION['apprFormat'] = $_POST["apprFormat"];
        }
        ?>

        <?php
        set_time_limit(500);
        $gradstuReg = $_SESSION["gradstuReg"];
        $gradStuName = $_SESSION["gradStuName"];
        $snoArray = $_SESSION["snoArray"];
        $sno = $_SESSION["sno"];
        ?>
        <div style="padding-left:3em; padding-right: 3em;">
            <div class="col-md-12">
                <div class="tabs tabs-bottom tabs-primary">
                    <div class="tab-content">

                        <?php
                        $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;
                        for ($i = 1; $i <= $sno; $i++) {
                            $no = $snoArray[$i];
                            $matno = $gradstuReg[$i];
                            $Name1 = $gradStuName[$i];

                            //$RegNo2 = substr($matno, 7, 7);
                            $RegNo2 = str_replace("/", "_", $matno);
                        ?>
                        <?php if ($i == 1) {  ?>
                        <div id="<?php echo $RegNo2 ?>" class="tab-pane active">
                            <?php
                                    include 'modulesInSess/grad_result_view_all.php';
                                    ?>

                        </div>
                        <?php } else { ?>
                        <div id="<?php echo $RegNo2 ?>" class="tab-pane">
                            <?php
                                    include 'modulesInSess/grad_result_view_all.php';
                                    ?>

                        </div>
                        <?php } ?>

                        <?php
                        }
                        ?>
                    </div>
                    <ul class="nav nav-tabs nav-right">

                        <?php
                        for ($i = 1; $i <= $sno; $i++) {
                            $matno = $gradstuReg[$i];
                            //$RegNo2 = substr($matno, 7, 7);
                            $RegNo2 = str_replace("/", "_", $matno);
                            $no = $snoArray[$i];
                        ?>
                        <?php if ($i == 1) {  ?>
                        <li class="active">
                            <a href="#<?php echo $RegNo2 ?>" data-toggle="tab"><i
                                    class="fa fa-star"></i><?php echo "(<b>" . $no . "</b>) " . $matno ?></a>
                        </li>
                        <?php } else { ?>
                        <li>
                            <a href="#<?php echo $RegNo2 ?>"
                                data-toggle="tab"><?php echo "(<b>" . $no . "</b>) " . $matno ?></a>
                        </li>
                        <?php } ?>

                        <?php
                        }
                        ?>
                    </ul>
                </div>
            </div>

        </div>
        <!-- end: page -->
    </section>

    <!-- Mainly scripts -->
    <script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>


    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Upload Courses</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Upload
                            </li>

                            <li class="active">
                                <strong>Upload Courses</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Upload Courses
                        </div>
                        <div class="panel-body">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <?php

                                /* $sql = "SELECT * FROM gencoursesupload";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $C_codding = $row["C_codding"];

                                        $countC = 0;
                                        $sql2 = "SELECT * FROM coursealocation WHERE CCode = '$C_codding'";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $countC++;
                                            }
                                        }
                                        if ($countC == 1) {
                                            $sql2 = "UPDATE coursealocation SET teamleader = 'YES' WHERE CCode = '$C_codding'";
                                            $result2 = $conn->query($sql2);
                                        }
                                    }
                                } */





                                $msg = "";
                                $success_upl = "no";

                                if (isset($_POST["upfile"])) {

                                    set_time_limit(500);
                                    error_reporting(E_ERROR);



                                    $filename = $_FILES["uploaded"]["tmp_name"];

                                    $file_ext = strtolower(end(explode('.', $_FILES['uploaded']['name'])));

                                    if ($file_ext == "csv") {

                                        if ($_FILES["uploaded"]["size"] > 0) {
                                            $file = fopen($filename, "r");

                                            $count = 0;
                                            /*
                                            while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                                $count++;
                                                $Row0 = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                                $Row1 = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                                $Row2 = filter_var($Row[2], FILTER_SANITIZE_STRING);
                                                $Row3 = filter_var($Row[3], FILTER_SANITIZE_STRING);
                                                $Row4 = filter_var($Row[4], FILTER_SANITIZE_STRING);
                                                $Row5 = filter_var($Row[5], FILTER_SANITIZE_STRING);

                                                $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$Row5'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $schl = $row["School"];
                                                    }
                                                }

                                                $randPasswd = rand(10000, 100000);
                                                $randPasswd2 = md5($randPasswd);
                                                $sql2 = "INSERT INTO users(staffid, full_name, cat, phone, emailAdd, department, staffacddept, SchCode, password2, password3, online_status)VALUES('$Row0', '$Row1', '$Row2', '$Row3', '$Row4', '$Row5', '$Row5', '$schl', '$randPasswd2', '$randPasswd', 'Online')";
                                                $result2 = $conn->query($sql2);
                                            }
                                            */
                                            /* while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                                $count++;
                                                $Row0 = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                                $Row1 = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                                $Row2 = filter_var($Row[2], FILTER_SANITIZE_STRING);
                                                $Row3 = filter_var($Row[3], FILTER_SANITIZE_STRING);
                                                $Row4 = filter_var($Row[4], FILTER_SANITIZE_STRING);
                                                $Row5 = filter_var($Row[5], FILTER_SANITIZE_STRING);
                                                $Row6 = filter_var($Row[6], FILTER_SANITIZE_STRING);
                                                $Row7 = filter_var($Row[7], FILTER_SANITIZE_STRING);

                                                $sql2 = "INSERT INTO deptcourses(CCode, CTitle, CUnit, SemTaken, dept, deptoption, Nature, level)VALUES('$Row0', '$Row1', '$Row2', '$Row3', '$Row4', '$Row5', '$Row6', '$Row7')";
                                                $result2 = $conn->query($sql2);
                                            }  */

                                            /* 
                                            while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                                $count++;
                                                $Row0 = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                                $Row1 = filter_var(trim($Row[1]), FILTER_SANITIZE_STRING);
                                                $Row2 = filter_var($Row[2], FILTER_SANITIZE_STRING);
                                                $Row3 = filter_var($Row[3], FILTER_SANITIZE_STRING);
                                                $Row4 = filter_var($Row[4], FILTER_SANITIZE_STRING);
                                                $Row5 = filter_var($Row[5], FILTER_SANITIZE_STRING);
                                                $Row6 = filter_var($Row[6], FILTER_SANITIZE_STRING);

                                                $sql3 = "SELECT * FROM gencoursesupload WHERE C_codding = '$Row1' AND type1 = '$Row6'";
                                                $result3 = $conn->query($sql3);
                                                if ($result3->num_rows === 0) {

                                                    $sql2 = "INSERT INTO gencoursesupload(id, C_codding, C_title, credit, semester, Department, type1)VALUES('$Row0', '$Row1', '$Row2', '$Row3', '$Row4', '$Row5', '$Row6')";
                                                    $result2 = $conn->query($sql2);
                                                }
                                            }
 */

                                            /* while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                                $count++;
                                                $Row0 = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                                $Row1 = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                                $Row2 = filter_var($Row[2], FILTER_SANITIZE_STRING);
                                                $Row3 = filter_var($Row[3], FILTER_SANITIZE_STRING);
                                                $Row4 = filter_var($Row[4], FILTER_SANITIZE_STRING);
                                                $Row5 = filter_var($Row[5], FILTER_SANITIZE_STRING);
                                                $Row6 = filter_var($Row[6], FILTER_SANITIZE_STRING);
                                                $Row7 = filter_var($Row[7], FILTER_SANITIZE_STRING);

                                                $dept_db = $_SESSION['deptdb'] . strtolower($Row4);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                } 

                                               
                                                $sql = "SELECT * FROM gencourses WHERE C_codding = '$Row0'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows == 0) {

                                                    $sql2 = "INSERT INTO gencourses(C_codding, C_title, credit, semester, Level1, Nature1)VALUES('$Row0', '$Row1', '$Row2', '$Row3', '$Row7', 'GST')";
                                                    $result2 = $conn_stu->query($sql2);
                                                }
                                            } */


                                            $studept = "ele";
                                            $selDept_old = "ele";

                                            $dept_db = $_SESSION['deptdb'] . strtolower($studept);
                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }

                                            while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                                $count++;
                                                $CCode = filter_var($Row[0], FILTER_SANITIZE_STRING);
                                                $MatNo = filter_var($Row[1], FILTER_SANITIZE_STRING);
                                                $CA = filter_var($Row[2], FILTER_SANITIZE_STRING);
                                                $Exam = filter_var($Row[3], FILTER_SANITIZE_STRING);
                                                $Semester = filter_var(strtoupper($Row[4]), FILTER_SANITIZE_STRING);
                                                $Session1 = filter_var($Row[5], FILTER_SANITIZE_STRING);

                                                $getCTitle = "XXXX";
                                                $UploadUnit = 0;
                                                $UploadSemTaken = "1ST";
                                                $MotherDept = "XX";
                                                $stuName = "XXXX";


                                                $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = 'CN2'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $getCTitle = $row["C_title"];
                                                        $UploadUnit = $row["credit"];
                                                        $UploadSemTaken = $row["semester"];
                                                        $MotherDept = $row["Department"];
                                                    }
                                                } else {
                                                    $sql = "SELECT * FROM gencoursesupload WHERE C_codding = '$CCode' AND type1 = 'CN1'";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $getCTitle = $row["C_title"];
                                                            $UploadUnit = $row["credit"];
                                                            $UploadSemTaken = $row["semester"];
                                                            $MotherDept = $row["Department"];
                                                        }
                                                    }
                                                }


                                                //$stuDept = $MotherDept;
                                                $regedit1 = $MatNo;
                                                /*
                                                $regedit1 = str_replace("18URT/", "18U/", $regedit1);
                                                $regedit1 = str_replace("18UTR/", "18U/", $regedit1);
                                                $regedit1 = str_replace("18UR/", "18U/", $regedit1);
                                                $regedit1 = str_replace("18UT/", "18U/", $regedit1);

                                                $regedit1 = str_replace("19URT/", "19U/", $regedit1);
                                                $regedit1 = str_replace("19UTR/", "19U/", $regedit1);
                                                $regedit1 = str_replace("19UR/", "19U/", $regedit1);
                                                $regedit1 = str_replace("19UT/", "19U/", $regedit1);

                                                $regedit1 = str_replace("20URT/", "20U/", $regedit1);
                                                $regedit1 = str_replace("20UTR/", "20U/", $regedit1);
                                                $regedit1 = str_replace("20UR/", "20U/", $regedit1);
                                                $regedit1 = str_replace("20UT/", "20U/", $regedit1);

                                                $regedit1 = str_replace("21URT/", "21U/", $regedit1);
                                                $regedit1 = str_replace("21UTR/", "21U/", $regedit1);
                                                $regedit1 = str_replace("21UR/", "21U/", $regedit1);
                                                $regedit1 = str_replace("21UT/", "21U/", $regedit1);

                                                $regedit1 = str_replace("22URT/", "22U/", $regedit1);
                                                $regedit1 = str_replace("22UTR/", "22U/", $regedit1);
                                                $regedit1 = str_replace("22UR/", "22U/", $regedit1);
                                                $regedit1 = str_replace("22UT/", "22U/", $regedit1);

                                                $regedit1 = str_replace("23URT/", "23U/", $regedit1);
                                                $regedit1 = str_replace("23UTR/", "23U/", $regedit1);
                                                $regedit1 = str_replace("23UR/", "23U/", $regedit1);
                                                $regedit1 = str_replace("23UT/", "23U/", $regedit1);


                                                $regedit1 = str_replace("18DRT/", "18D/", $regedit1);
                                                $regedit1 = str_replace("18DTR/", "18D/", $regedit1);
                                                $regedit1 = str_replace("18DR/", "18D/", $regedit1);
                                                $regedit1 = str_replace("18DT/", "18D/", $regedit1);

                                                $regedit1 = str_replace("19DRT/", "19D/", $regedit1);
                                                $regedit1 = str_replace("19DTR/", "19D/", $regedit1);
                                                $regedit1 = str_replace("19DR/", "19D/", $regedit1);
                                                $regedit1 = str_replace("19DT/", "19D/", $regedit1);

                                                $regedit1 = str_replace("20DRT/", "20D/", $regedit1);
                                                $regedit1 = str_replace("20DTR/", "20D/", $regedit1);
                                                $regedit1 = str_replace("20DR/", "20D/", $regedit1);
                                                $regedit1 = str_replace("20DT/", "20D/", $regedit1);
                                                */
                                                $regedit1 = str_replace("21DRT/", "21D/", $regedit1);
                                                $regedit1 = str_replace("21DTR/", "21D/", $regedit1);
                                                $regedit1 = str_replace("21DR/", "21D/", $regedit1);
                                                $regedit1 = str_replace("21DT/", "21D/", $regedit1);

                                                $regedit1 = str_replace("22DRT/", "22D/", $regedit1);
                                                $regedit1 = str_replace("22DTR/", "22D/", $regedit1);
                                                $regedit1 = str_replace("22DR/", "22D/", $regedit1);
                                                $regedit1 = str_replace("22DT/", "22D/", $regedit1);

                                                $regedit1 = str_replace("23DRT/", "23D/", $regedit1);
                                                $regedit1 = str_replace("23DTR/", "23D/", $regedit1);
                                                $regedit1 = str_replace("23DR/", "23D/", $regedit1);
                                                $regedit1 = str_replace("23DT/", "23D/", $regedit1);

                                                $regedit1 = str_replace("24DRT/", "24D/", $regedit1);
                                                $regedit1 = str_replace("24DTR/", "24D/", $regedit1);
                                                $regedit1 = str_replace("24DR/", "24D/", $regedit1);
                                                $regedit1 = str_replace("24DT/", "24D/", $regedit1);


                                                $selDept_old2 = strtoupper($selDept_old);
                                                $studept2 = strtoupper($studept);
                                                $regedit1 = str_replace($selDept_old2, $studept2, $regedit1);
                                                $oldMatricNo = str_replace($studept2, $selDept_old2, $regedit1);

                                                /* $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$studept2'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $deptname = $row["DeptName"];
                                                        $schcode = $row["School"];
                                                    }
                                                }

                                                $sql = "SELECT * FROM schoolname WHERE SchCode = '$schcode'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $schname = $row["SchName"];
                                                    }
                                                } */

                                                //$sql = "UPDATE std_data_view SET programme ='$deptname',  department ='$deptname', dept_code ='$studept2', school ='$schname', school_code ='$schcode', matric_no ='$regedit1', regid ='$regedit1' WHERE matric_no='$oldMatricNo'";
                                                //$result = $conn2->query($sql);

                                                /* $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regedit1'";
                                                $result = $conn2->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $stuName = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                        //$stuDept = $row["dept_code"];
                                                    }
                                                } */

                                                if (is_numeric($CA)) {
                                                    $CA2 = $CA;
                                                } else {
                                                    $CA2 = 0;
                                                }
                                                if (is_numeric($Exam)) {
                                                    $Exam2 = $Exam;
                                                    $NoExam = "NO";
                                                } else {
                                                    $Exam2 = 0;
                                                    $NoExam = "YES";
                                                }

                                                $getTotal = $CA2 + $Exam2;
                                                $NatureUpload = "XXX";
                                                $LevelUpload = 100;


                                                $session2 = str_replace("/", "_", $Session1);
                                                $sql = "SELECT * FROM correg_" . $session2 . " WHERE CCode = '$CCode' AND Regn1 = '$regedit1'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows == 0) {


                                                    if ($getTotal >= 70) {
                                                        $grade = "A";
                                                        $gp = $UploadUnit * 5;
                                                    } elseif ($getTotal >= 60) {
                                                        $grade = "B";
                                                        $gp = $UploadUnit * 4;
                                                    } elseif ($getTotal >= 50) {
                                                        $grade = "C";
                                                        $gp = $UploadUnit * 3;
                                                    } elseif ($getTotal >= 45) {
                                                        $grade = "D";
                                                        $gp = $UploadUnit * 2;
                                                    } elseif ($getTotal >= 40) {
                                                        $grade = "E";
                                                        $gp = $UploadUnit * 1;
                                                    } elseif ($getTotal <= 39.95) {
                                                        $grade = "F";
                                                        $gp = 0;
                                                    }

                                                    $sql2 = "INSERT INTO correg_" . $session2 . "(CCode, CTitle, CNature, CUnit, SemTaken, SessionRegis, CA, Exam, grade, Grouping2, Regn1, coursecondon, noexam, deptOption, curriculum, point)VALUES('$CCode', '$getCTitle', '$NatureUpload', '$UploadUnit', '$UploadSemTaken', '$Session1', '$CA2', '$Exam2', '$grade', 'NO', '$regedit1', 'NO', '$NoExam', 'NOP', 'OLD', '$gp')";
                                                    $result2 = $conn_stu->query($sql2);
                                                }

                                                $sql = "SELECT * FROM raw_results_" . $session2 . " WHERE CCode = '$CCode' AND SessionRegis = '$Session1' AND Regn1 = '$regedit1'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows == 0) {
                                                    $sql2 = "INSERT INTO raw_results_" . $session2 . "(CCode, SessionRegis, CA, Exam, total, Regn1, name1, mother_dept, stu_dept)VALUES('$CCode', '$Session1', '$CA2', '$Exam2', '$getTotal', '$regedit1', '$stuName', '$MotherDept', '$studept2')";
                                                    $result2 = $conn->query($sql2);
                                                }
                                            }

                                            fclose($file);


                                            /*
                                            $sql = "UPDATE users SET department ='$studept2', staffacddept ='$studept2' WHERE department='$selDept_old2'";
                                            $result = $conn->query($sql);

                                            $sql = "UPDATE deptcourses SET dept ='$studept2' WHERE dept='$selDept_old2'";
                                            $result = $conn->query($sql);

                                            $sql = "UPDATE gencoursesupload SET Department ='$studept2' WHERE Department='$selDept_old2'";
                                            $result = $conn->query($sql);
                                            */


                                            echo '<center><p style="color:#006">CSV File has been successfully Imported</p></center>';
                                            $success_upl = "yes";
                                        } else
                                            echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center>';
                                    } else {
                                        echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File</p></center></p>';
                                    }
                                }


                                ?>
                                <form enctype="multipart/form-data" action="" method="post">
                                    <h4 style="text-align: center">CSV File with the Format Below.</h4>
                                    <center><img src='img/upload_courses.JPG' width='500' height='300' alt=''>
                                    </center>
                                    <br><br>

                                    <div class="form-group" style="text-align: center;">
                                        <label class="col-md-2 control-label">File Upload</label>
                                        <div class="col-md-4">



                                            <div class="fileinput fileinput-new input-group" data-provides="fileinput">
                                                <div class="form-control" data-trigger="fileinput">
                                                    <i class="glyphicon glyphicon-file fileinput-exists"></i>
                                                    <span class="fileinput-filename"></span>
                                                </div>
                                                <span class="input-group-addon btn btn-default btn-file"><span class="fileinput-new">Select
                                                        file</span><span class="fileinput-exists">Change</span><input type="file" name="uploaded"></span>
                                                <a href="#" class="input-group-addon btn btn-default fileinput-exists" data-dismiss="fileinput">Remove</a>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <input type="submit" name="upfile" value="Upload File" class="btn btn-primary btn-sm">
                                        </div>
                                    </div>
                                </form>
                                <h3> <?php echo $msg ?> </h3>

                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>

</body>

</html>
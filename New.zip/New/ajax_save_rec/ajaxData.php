<?php
require_once '../includes/db_connect2.php';


if (!empty($_POST["sel_id"])) { ?>
    <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $IntYearAdmit = (int)$_POST["sel_id"];
    $SessCount = 0;
    $GetTheSession = $_SESSION['resultsession'];
    $GetTheSemester = $_SESSION['resultsemester'];
    $curYear = date('Y');
    $prevYear1 = $curYear - 1;
    $prevYear2 = $curYear - 2;
    $curYear2 = $curYear + 1;
    do {

        $sessionpres = $IntYearAdmit . "/" . ($IntYearAdmit + 1);
        $sql = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionpres'";
        $result = $conn->query($sql);
        $Add1 = 0;
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $Add1++;
            }
        }
        if ($Add1 == 0) {
            $SessCount = $SessCount + 1;
            $StuSession[$SessCount] = $sessionpres;
        }

        if ($StuSession[$SessCount] == $GetTheSession) {
            break;
        }

        $IntYearAdmit = $IntYearAdmit + 1;
    } while ($SessCount < 10);
    $conn->close();

    if ($SessCount >= $_SESSION['prog_no_years']) {
    ?>
        <div class="form-group">
            <label class="control-label col-lg-5" for="regid">Year of Graduation:</label>
            <div class="col-lg-7">
                <select name="getyearGrad" class="form-control" style="color:#000000" id="getyearAdt" required="required">
                    <option value=''>Select Year</option>
                    <option value='<?php echo $prevYear2 ?>'><?php echo $prevYear2 ?></option>
                    <option value='<?php echo $prevYear1 ?>'><?php echo $prevYear1 ?></option>
                    <option value='<?php echo $curYear ?>'><?php echo $curYear ?></option>
                    <option value='<?php echo $curYear2 ?>'><?php echo $curYear2 ?></option>

                </select>
            </div>
        </div>
    <?php } ?>
<?php } ?>
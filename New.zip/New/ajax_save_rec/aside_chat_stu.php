<?php require_once '../includes/db_connect.php'; ?>
<h4 style="color:#ffffff">Topic of Discussion</h4>
<h6 style="color:#ffffff"><?php echo $_SESSION["getccode"] . "(" . $_SESSION["topics"] . ")" ?></h6>
<ul class="chats">

    <?php
	$servername = $_SESSION['servername'];
	$db_username = $_SESSION['db_username'];
	$db_password = $_SESSION['db_password'];
	$dbname = $_SESSION['dbname8'];

	$conn = new mysqli($servername, $db_username, $db_password, $dbname);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	//$stdid = $_SESSION['stdid'];
	$getccode = $_SESSION["getccode"];
	$curtsession = $_SESSION['corntsession'];
	$usernames = $_SESSION['names'];
	$dept = strtoupper($_SESSION['deptcode']);
	$topics_id = $_SESSION["topics_id"];
	$staffid = $_SESSION["staffid"];
	$staffdept = $_SESSION["staffdept"];
	$staff_pic_folder = $_SESSION['staff_pic_folder'];

	$getccode2 = strtolower($getccode);
	$sql = "SELECT * FROM " . $getccode2 . " WHERE session1='$curtsession' AND topic_id='$topics_id' AND user_id='$staffid' ORDER BY date1";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
			$user_id = $row["user_id"];
			$message = $row["message"];
			$date1 = $row["date1"];
			$fullname = $row["fullname"];
			$image_url = $row["image_url"];
			$imgname = $row["imgname"];
			$filetype = $row["filetype"];

	?>
    <li class="by-me">
        <div class="avatar pull-left">


            <img alt='' class='img-circle'
                src='<?php echo $staff_pic_folder ?>/<?php echo $staffdept ?>/images/<?php echo $staffid ?>/MyPic1.jpg'
                width='50' height='50'>

        </div>
        <div class="chat-content">
            <div class="chat-meta" style="color: #000000">
                <strong><?php echo $date1 ?><br><?php echo $fullname ?></strong>
            </div>

            <?php if ($filetype == "jpg" || $filetype == "gif" || $filetype == "png") { ?>
            <a class="thumb-image" href="<?php echo $image_url ?>" target="_blank">
                <img src="<?php echo $image_url ?>" width="100" height="100">
            </a>
            <?php } elseif ($filetype == "mp3") { ?>

            <audio>
                <source src="<?php echo $image_url ?>" type="audio/mpeg">

            </audio>
            <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/audio_icon.svg" width="40"
                    height="40"><?php echo $imgname ?></a>

            <?php } elseif ($filetype == "mp4") { ?>


            <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/video_icon.jpg" width="40"
                    height="40"><?php echo $imgname ?></a>
            <?php } elseif ($filetype == "doc" || $filetype == "docx") { ?>

            <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/word_icon.png" width="40"
                    height="40"><?php echo $imgname ?></a>
            <?php } elseif ($filetype == "xls" || $filetype == "xlsx") { ?>

            <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/excel_icon.png" width="40"
                    height="40"> <?php echo $imgname ?></a>
            <?php } elseif ($filetype == "pdf") { ?>

            <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/pdf_icon.png" width="40"
                    height="40"><?php echo $imgname ?></a>
            <?php } elseif ($filetype == "zip") { ?>

            <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/zip_icon.png" width="40"
                    height="40"><?php echo $imgname ?></a>
            <?php } elseif ($filetype == "txt") { ?>

            <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/txt.png" width="40"
                    height="40"><?php echo $imgname ?></a>

            <?php } ?>
            <?php echo $message ?>

            <div class="clearfix"></div>
        </div>
    </li>
    <?php

		}
	}

	?>
</ul>
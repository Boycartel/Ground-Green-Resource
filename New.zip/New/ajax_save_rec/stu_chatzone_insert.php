<?php
require_once '../includes/db_connect2.php';

$regid = $_POST["stureg"];
$dept = $_POST['dept2'];
$dbdept = $_POST['dbdept'];

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$dept_db = $dbdept . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}


$msgto = $_POST["recip_id"];

$mymessage = str_replace("'", "''", $_POST['mychat']);
$mymessage = filter_var($mymessage, FILTER_SANITIZE_STRING);

$getlevel = "All";
//$level=300;

$isStu = false;
$sql3 = "SELECT matric_no FROM std_data_view WHERE matric_no = '$msgto'";
$result3 = $conn2->query($sql3);
if ($result3->num_rows > 0) {
    $isStu = true;
}


if ($msgto == "Dean" || $msgto == "HOD" || $msgto == "Examiner" || $msgto == "Ass_Examiner" || $msgto == "L100" || $msgto == "L200" || $msgto == "L300" || $msgto == "L400" || $msgto == "L500" || $msgto == "spill_over" || $msgto == "PG_Coord") {
    if ($msgto == "Dean") {
        $sql = "SELECT SchCode, staffid, Dean, Level1 FROM users WHERE SchCode = '$schcode' AND Dean = 'YES'";
    } elseif ($msgto == "HOD") {
        $sql = "SELECT department, staffid, HOD FROM users WHERE department = '$dept' AND HOD = 'YES'";
    } elseif ($msgto == "PG_Coord") {
        $sql = "SELECT department, staffid, PG_Coord FROM users WHERE department = '$dept' AND PG_Coord = 'YES'";
    } elseif ($msgto == "Examiner") {
        $sql = "SELECT department, staffid, Examiner FROM users WHERE department = '$dept' AND Examiner = 'YES'";
    } elseif ($msgto == "Ass_Examiner") {
        $sql = "SELECT department, staffid, Ass_Examiner FROM users WHERE department = '$dept' AND Ass_Examiner = 'YES'";
    } elseif ($msgto == "L100") {
        $sql = "SELECT department, staffid, L100 FROM users WHERE department = '$dept' AND L100 = 'YES'";
        $getlevel = 100;
    } elseif ($msgto == "L200") {
        $sql = "SELECT department, staffid, L200 FROM users WHERE department = '$dept' AND L200 = 'YES'";
        $getlevel = 200;
    } elseif ($msgto == "L300") {
        $sql = "SELECT department, staffid, L300 FROM users WHERE department = '$dept' AND L300 = 'YES'";
        $getlevel = 300;
    } elseif ($msgto == "L400") {
        $sql = "SELECT department, staffid, L400 FROM users WHERE department = '$dept' AND L400 = 'YES'";
        $getlevel = 400;
    } elseif ($msgto == "L500") {
        $sql = "SELECT department, staffid, L500 FROM users WHERE department = '$dept' AND L500 = 'YES'";
        $getlevel = 500;
    } elseif ($msgto == "spill_over") {
        $sql = "SELECT department, staffid, spill_over FROM users WHERE department = '$dept' AND spill_over = 'YES'";
        $getlevel = 600;
    }

    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $msgid = $row["staffid"];
        }
    }

    $sql = "INSERT INTO comment(matricno, cat_coment, sent_coment, msgid, msgopen)VALUES('$regid', '$msgto', '$mymessage', '$msgid', 'YES')";
    $result = $conn_stu->query($sql);

    $sql = "INSERT INTO staff_comment(matricno, cat, recieve_coment, msgid, msgopen, level1, Dept)VALUES('$regid', '$msgto', '$mymessage', '$msgid', 'NO', '$getlevel', '$dept')";
    $result = $conn->query($sql);
} elseif ($isStu == true) {
    $sql = "INSERT INTO comment(matricno, cat_coment, sent_coment, msgid, msgopen)VALUES('$regid', '$msgto', '$mymessage', '$msgto', 'YES')";
    $result = $conn_stu->query($sql);

    $sql = "INSERT INTO comment(matricno, cat_coment, recieve_coment, msgid, msgopen)VALUES('$msgto', '$regid', '$mymessage', '$regid', 'NO')";
    $result = $conn_stu->query($sql);
} else {
    $sql = "INSERT INTO comment(matricno, cat_coment, sent_coment, msgid, msgopen)VALUES('$regid', '$msgto', '$mymessage', '$msgto', 'YES')";
    $result = $conn_stu->query($sql);

    $sql = "INSERT INTO staff_comment(matricno, cat, recieve_coment, msgid, msgopen, level1, Dept)VALUES('$regid', '$msgto', '$mymessage', '$msgto', 'NO', 'All', '$dept')";
    $result = $conn->query($sql);
}

$conn->close();
$conn2->close();
$conn_stu->close();
    //echo "data inserted";
//}
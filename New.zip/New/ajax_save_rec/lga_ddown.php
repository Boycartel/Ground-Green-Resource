<?php
require_once '../includes/db_connect2.php';
if (isset($_POST["state1"])) {

	$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$state = $_POST["state1"];

	// Define country and city array


	$dbname = $_SESSION['dbname'];


	$sql = "SELECT * FROM lgas WHERE state = '$state'";
	$result = $conn->query($sql);

	echo "<select class='form-control' style='color:#000000' id='lga' name='lga' required='required'>";
	echo "<option></option>";
	echo "<option value='All'>All</option>";
	if ($result->num_rows > 0) {
		// output data of each row
		while ($row = $result->fetch_assoc()) {
			$lga = $row["lga"];
			echo "<option value='$lga'>$lga</option>";
		}
	}
	echo "</select>";

	$conn->close();
}

<?php
require_once '../includes/db_connect2.php';



if (!empty($_POST["sel_id"])) { ?>
    <?php
    //$IntYearAdmit = (int)$_POST["getyearAdt"];
    $High_Qual = $_POST["sel_id"];

    if ($High_Qual == "HND") {

    ?>
        <div class="row">
            <input type="hidden" name="highqual" id="highqual" value="HND">
            <div class="form-group">
                <label class="col-lg-5 control-label"><strong>ND Grade:</strong></label>
                <div class="col-lg-6">

                    <select name="nd_result" class="form-control" style="color:#000000" id="nd_result" required>
                        <option value="">Select Item</option>
                        <option value="Distinction">Distinction</option>
                        <option value="Upper_Credit">Upper Credit</option>
                        <option value="Lower_Credit">Lower Credit</option>
                        <option value="Pass">Pass</option>

                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="col-lg-5 control-label"><strong>HND Grade:</strong></label>
                <div class="col-lg-6">

                    <select name="hnd_result" class="form-control" style="color:#000000" id="hnd_result" required>
                        <option value="">Select Item</option>
                        <option value="Distinction">Distinction</option>
                        <option value="Upper_Credit">Upper Credit</option>
                        <option value="Lower_Credit">Lower Credit</option>
                        <option value="Pass">Pass</option>

                    </select>
                </div>
            </div>
        </div>
    <?php } elseif ($High_Qual == "ND") { ?>

        <div class="row">
            <input type="hidden" name="highqual" id="highqual" value="ND">
            <div class="form-group">
                <label class="col-lg-5 control-label"><strong>ND Grade:</strong></label>
                <div class="col-lg-6">

                    <select name="nd_result" class="form-control" style="color:#000000" id="nd_result" required>
                        <option value="">Select Item</option>
                        <option value="Distinction">Distinction</option>
                        <option value="Upper_Credit">Upper Credit</option>
                        <option value="Lower_Credit">Lower Credit</option>
                        <option value="Pass">Pass</option>

                    </select>
                </div>
            </div>
        </div>
    <?php } elseif ($High_Qual == "NCE") { ?>

        <div class="row">
            <input type="hidden" name="highqual" id="highqual" value="NCE">
            <div class="form-group">
                <label class="col-lg-7 control-label"><strong>Education:</strong></label>
                <div class="col-lg-5">

                    <select name="education" class="form-control" style="color:#000000" id="education" required>
                        <option value="">Select Item</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                        <option value="E">E</option>
                        <option value="F">F</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="col-lg-7 control-label"><strong>Major Course:</strong></label>
                <div class="col-lg-5">

                    <select name="major1" class="form-control" style="color:#000000" id="major1" required>
                        <option value="">Select Item</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                        <option value="E">E</option>
                        <option value="F">F</option>
                    </select>
                </div>
            </div>

        </div>
    <?php } elseif ($High_Qual == "IJMB") { ?>

        <div class="row">
            <input type="hidden" name="highqual" id="highqual" value="IJMB">
            <div class="form-group" style="text-align: center">
                <input type="checkbox" id="fut" name="fut" value="YES" style="font-size: large">
                <label for="fut" style="font-size: large"> FUT Minna</label>
            </div>
            <div class="form-group">
                <label class="col-lg-4 control-label"><strong>Subject 1:</strong></label>
                <div class="col-lg-5">

                    <select name="ijmb_sub1" class="form-control" style="color:#000000" id="ijmb_sub1" required>
                        <option value="">Select Item</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="Physics">Physics</option>
                        <option value="Chemistry">Chemistry</option>
                        <option value="Biology">Biology</option>
                        <option value="Geography">Geography</option>
                        <option value="Economics">Economics</option>
                    </select>
                </div>
                <div class="col-lg-3">

                    <select name="sub1_grade" class="form-control" style="color:#000000" id="sub1_grade" required>
                        <option value="">Select Item</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                        <option value="E">E</option>
                        <option value="F">F</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4 control-label"><strong>Subject 2:</strong></label>
                <div class="col-lg-5">

                    <select name="ijmb_sub2" class="form-control" style="color:#000000" id="ijmb_sub2" required>
                        <option value="">Select Item</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="Physics">Physics</option>
                        <option value="Chemistry">Chemistry</option>
                        <option value="Biology">Biology</option>
                        <option value="Geography">Geography</option>
                        <option value="Economics">Economics</option>
                    </select>
                </div>
                <div class="col-lg-3">

                    <select name="sub2_grade" class="form-control" style="color:#000000" id="sub2_grade" required>
                        <option value="">Select Item</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                        <option value="E">E</option>
                        <option value="F">F</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-lg-4 control-label"><strong>Subject 3:</strong></label>
                <div class="col-lg-5">

                    <select name="ijmb_sub3" class="form-control" style="color:#000000" id="ijmb_sub3" required>
                        <option value="">Select Item</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="Physics">Physics</option>
                        <option value="Chemistry">Chemistry</option>
                        <option value="Biology">Biology</option>
                        <option value="Geography">Geography</option>
                        <option value="Economics">Economics</option>
                    </select>
                </div>
                <div class="col-lg-3">

                    <select name="sub3_grade" class="form-control" style="color:#000000" id="sub3_grade" required>
                        <option value="">Select Item</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                        <option value="E">E</option>
                        <option value="F">F</option>
                    </select>
                </div>
            </div>
        </div>
    <?php } ?>

<?php }
?>
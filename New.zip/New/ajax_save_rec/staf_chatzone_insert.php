<?php
require_once '../includes/db_connect2.php';
$dept = $_SESSION['deptcode'];
$staffid = $_SESSION['staffid'];
$corntsession = $_SESSION['corntsession'];


$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}


$msgto = $_POST["recip_id"];



$mymessage = str_replace("'", "''", $_POST['mychat']);
$mymessage = filter_var($mymessage, FILTER_SANITIZE_STRING);

$schcode = $_SESSION['schcode'];

//$cat = $_SESSION['cat'];
//$staflevel = $_SESSION['staflevel'];

$getlevel = "All";
$cat = "Others";
$isAdmin = false;

$sql = "SELECT * FROM users WHERE staffid = '$staffid'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row["L100"] == "YES" || $row["L200"] == "YES" || $row["L300"] == "YES" || $row["L400"] == "YES" || $row["L500"] == "YES" || $row["spill_over"] == "YES") {
            $cat = "L100";
        }
        if ($row["Examiner"] == "YES" || $row["Ass_Examiner"] == "YES") {
            $cat = "Examiner";
        }
        if ($row["HOD"] == "YES") {
            $cat = "HOD";
        }
        if ($row["Dean"] == "YES") {
            $cat = "Dean";
        }
        if ($row["Sub_Admin"] == "YES") {
            $cat = "Sub_Admin";
            $isAdmin = true;
        }
        if ($row["Administrator"] == "YES") {
            $cat = "Administrator";
            $isAdmin = true;
        }
    }
}




if ($isAdmin == true) {
    $sql = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptCode";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {

            $dept_db = $_SESSION['deptdb'] . strtolower($row["DeptCode"]);
            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
            if ($conn_stu->connect_error) {
                die("Connection failed: " . $conn_stu->connect_error);
            }

            $sql2 = "SELECT matricno, name1, Session1 FROM hod_list WHERE Session1 = '$curtsession' AND matricno = '$msgto'";
            $result2 = $conn_stu->query($sql2);
            if ($result2->num_rows > 0) {
                while ($row2 = $result2->fetch_assoc()) {
                    $getlevel = $row2["StuLevel"];
                }
            }

            $sql2 = "INSERT INTO comment(matricno, cat_coment, recieve_coment, msgid, msgopen)VALUES('$msgto', '$cat', '$mymessage', '$staffid', 'NO')";
            $result2 = $conn_stu->query($sql2);
        }
    }
} else {
    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
    if ($conn_stu->connect_error) {
        die("Connection failed: " . $conn_stu->connect_error);
    }

    $sql = "INSERT INTO comment(matricno, cat_coment, recieve_coment, msgid, msgopen)VALUES('$msgto', '$cat', '$mymessage', '$staffid', 'NO')";
    $result = $conn_stu->query($sql);
}



$sql = "INSERT INTO staff_comment(matricno, cat, sent_coment, msgid, msgopen, level1, Dept)VALUES('$msgto', '$cat', '$mymessage', '$staffid', 'YES', '$getlevel', '$dept')";
$result = $conn->query($sql);


$conn->close();
$conn2->close();
$conn_stu->close();
//echo "data inserted";
//}
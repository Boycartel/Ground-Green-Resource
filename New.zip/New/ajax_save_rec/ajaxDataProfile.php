<?php
require_once '../includes/db_connect.php';


if (isset($_POST["activit"])) { ?>

<?php
    //$state = $_POST["state"];
    $specCode = $_POST["activit"];
    if ($specCode == "15" || $specCode == "18" || $specCode == "19") {
    ?>

<div class="form-group">
    <label class="control-label col-lg-4">Specify:</label>
    <div class="col-lg-7">
        <input type="text" class="form-control" style="color:#000000" name="specify" value="" required="required">
    </div>
</div>
<?php
    }
}


if (isset($_POST["state1"])) {

    $staename = $_POST["state1"];

    ?>

<div class="form-group">
    <label class="control-label col-lg-4">LGA:</label>
    <div class="col-lg-5">
        <select name="lga" class="state form-control" style="color:#000000" id="lga" required="required">

            <?php
                if ($staename == "Non Nigerian") {
                    echo "<option value='Non Nigerian'>Non Nigerian</option>";
                } else {
                    echo "<option value=''></option>";
                    $sql = "SELECT * FROM lgas WHERE state = '$staename' ORDER BY lga";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $lganame = $row["lga"];

                            echo "<option value = '$lganame'>$lganame</option>";
                        }
                    }
                }

                ?>
        </select>
    </div>
    <label class="col-lg-3 control-label" style="text-align: left"><?php echo $_SESSION["LGA"] ?></label>
</div>

<?php
}



if (isset($_POST["nation"])) {

    $nationname = $_POST["nation"];

    if ($nationname == "non") {
    ?>

<div class="form-group">
    <label class="control-label col-lg-4">Country:</label>
    <div class="col-lg-7">
        <input type="text" class="form-control" style="color:#000000" name="country"
            value="<?php echo $_SESSION["country"] ?>" required="required">
    </div>

</div>
<?php
    }
}




if (isset($_POST["health"])) {

    $healthname = $_POST["health"];

    if ($healthname == "Others") {
    ?>

<div class="form-group">
    <label class="control-label col-lg-4">Country:</label>
    <div class="col-lg-7">
        <input type="text" class="form-control" style="color:#000000" name="healthtype"
            value="<?php echo $_SESSION["healthtype"] ?>" required="required">
    </div>

</div>
<?php
    }
}
?>
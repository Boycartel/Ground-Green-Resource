<?php

require_once '../includes/db_connect2.php';

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id_small = $_POST["user_id_small"];
$user_full_name = $_POST["user_full_name"];
$user_helpdesk = $_POST["user_helpdesk"];

if ($user_helpdesk == "YES") {
    $sql = "UPDATE small_chat SET status1 ='YES'";
    $result = $conn->query($sql);
}
$mymessage = str_replace("'", "''", $_POST['mychat_small']);
$mymessage = validate_input($mymessage);

//$sql2 = "UPDATE small_chat SET status1 = 'YES'";
//$result2 = $conn->query($sql2);

$curTime = date('Y-m-d H:i:s');
$sql2 = "INSERT INTO small_chat(user_id, thechat, name1, helpdesk, date_time)VALUES('$user_id_small', '$mymessage', '$user_full_name', '$user_helpdesk', '$curTime')";
$result2 = $conn->query($sql2);
$conn->close();
echo "data inserted";

<?php
require_once '../includes/db_connect2.php';

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
$staffid = $_SESSION['staffid'];
$getccode = $_SESSION["getccode"];
$curtsession = $_SESSION['corntsession'];
$usernames = $_SESSION['names'];
$topics_id = $_SESSION["topics_id"];
$dept = $_SESSION['deptcode'];
$topics = $_SESSION["topics"];

//$mychat=$_POST['mychat'];
$mychat = str_replace("'", "''", $_POST['mychat']);
$mychat = filter_var($mychat, FILTER_SANITIZE_STRING);

$getccode2 = strtolower($getccode);
$sql = "INSERT INTO " . $getccode2 . " (user_id, fullname, message, session1, topic_id, topics, usertype) VALUES ('$staffid', '$usernames', '$mychat', '$curtsession', '$topics_id', '$topics', 'staff')";
if ($conn->query($sql) === TRUE) {
	echo "data inserted";
} else {
	echo "failed";
}
$conn->close();

<?php
require_once '../includes/db_connect2.php';

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$staffid = $_SESSION['staffid'];
$getccode = $_SESSION["getccode"];
$curtsession = $_SESSION['corntsession'];
$usernames = $_SESSION['names'];

$dept = $_SESSION['deptcode'];
$topics_id = $_SESSION["topics_id"];
$staff_pic_folder = $_SESSION['staff_pic_folder'];

$getccode2 = strtolower($getccode);

$sql = "SELECT * FROM aaa_online_courses WHERE ccode = '$getccode'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

?>

    <div class="timeline timeline-simple mt-xlg mb-md">
        <ul class="chats">
            <?php

            $sql = "SELECT * FROM " . $getccode2 . " WHERE session1='$curtsession' AND topic_id='$topics_id' ORDER BY date1";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $id = $row["id"];
                    $user_id = $row["user_id"];
                    $regid = $row["regid"];
                    $studept = strtolower($row["dept"]);
                    $message = $row["message"];
                    $date1 = $row["date1"];
                    $fullname = $row["fullname"];
                    $image_url = $row["image_url"];
                    $imgname = $row["imgname"];
                    $filetype = $row["filetype"];

                    if ($user_id == $staffid) {
            ?>

                        <li class="by-me">
                            <div class="avatar pull-left">
                                <!--<img alt='' src='assets/images/staff.jpg'  width='50' height='50' alt=''>-->
                                <img alt='' class='img-circle' src='<?php echo $staff_pic_folder ?>/<?php echo strtoupper($dept) ?>/images/<?php echo $staffid ?>/MyPic1.jpg' width='50' height='50'>
                                <center>
                                    <h3 style="color: #ffffff"><strong><?php echo $id ?></strong></h3>
                                </center>
                            </div>

                            <div class="chat-content">
                                <!-- In meta area, first include "name" and then "time" -->
                                <div class="chat-meta"><?php echo $date1 ?> <span class="pull-right"><?php echo $fullname ?></span>
                                </div>
                                <?php if ($filetype == "jpg" || $filetype == "gif" || $filetype == "png") { ?>
                                    <a class="thumb-image" href="<?php echo $image_url ?>" target="_blank">
                                        <img src="<?php echo $image_url ?>" width="100" height="100">
                                    </a>
                                <?php } elseif ($filetype == "mp3") { ?>

                                    <audio>
                                        <source src="<?php echo $image_url ?>" type="audio/mpeg">

                                    </audio>
                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/audio_icon.svg" width="40" height="40"><?php echo $imgname ?></a>

                                <?php } elseif ($filetype == "mp4") { ?>


                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/video_icon.jpg" width="40" height="40"><?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "doc" || $filetype == "docx") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/word_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "xls" || $filetype == "xlsx") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/excel_icon.png" width="40" height="40"> <?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "pdf") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/pdf_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "zip") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/zip_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "txt") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/txt.png" width="40" height="40"><?php echo $imgname ?></a>

                                <?php } ?>
                                <?php echo $message ?>
                                <div class="clearfix"></div>
                                <div class="chat-meta"> <span class="pull-right">
                                        <form class="" method="post">
                                            <input type="hidden" class="form-control" name="id_chat" value="<?php echo $id ?>">
                                            <!--<input type="submit" value="comment" name="comment_chat" class='btn btn-info btn-xs'> -->
                                            <input type="submit" value="Delete" name="delete_chat" class='btn btn-danger btn-xs'>
                                        </form>
                                    </span></div>
                                <br>
                            </div>
                        </li>
                    <?php } else { ?>
                        <li class="by-other">
                            <!-- Use the class "pull-right" in avatar -->
                            <div class="avatar pull-right">
                                <?PHP


                                $sql = "SELECT image FROM std_pictures WHERE matric_no='$regid'";
                                $sth = $conn2->query($sql);
                                $result2 = mysqli_fetch_array($sth);

                                echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['image']) . '"  width="50" height="50"/>';
                                ?>


                                <center>
                                    <h3 style="color: #ffffff"><strong><?php echo $id ?></strong></h3>
                                </center>
                            </div>
                            <div class="chat-content">
                                <!-- In the chat meta, first include "time" then "name" -->
                                <div class="chat-meta"><?php echo $date1 ?><span class="pull-right"><?php echo $fullname ?>(<?php echo $regid ?>)</span></div>
                                <?php if ($filetype == "jpg" || $filetype == "gif" || $filetype == "png") { ?>
                                    <a class="thumb-image" href="<?php echo $image_url ?>" target="_blank">
                                        <img src="<?php echo $image_url ?>" width="100" height="100">
                                    </a>
                                <?php } elseif ($filetype == "mp3") { ?>

                                    <audio>
                                        <source src="<?php echo $image_url ?>" type="audio/mpeg">

                                    </audio>
                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/audio_icon.svg" width="40" height="40"><?php echo $imgname ?></a>

                                <?php } elseif ($filetype == "mp4") { ?>


                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/video_icon.jpg" width="40" height="40"><?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "doc" || $filetype == "docx") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/word_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "xls" || $filetype == "xlsx") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/excel_icon.png" width="40" height="40"> <?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "pdf") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/pdf_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "zip") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/zip_icon.png" width="40" height="40"><?php echo $imgname ?></a>
                                <?php } elseif ($filetype == "txt") { ?>

                                    <a href="<?php echo $image_url ?>" target="_blank"><img src="assets/images/txt.png" width="40" height="40"><?php echo $imgname ?></a>

                                <?php } ?>
                                <?php echo $message ?>
                                <div class="clearfix"></div>
                                <div class="chat-meta"> <span class="pull-right">
                                        <form class="" method="post">
                                            <input type="hidden" class="form-control" name="id_chat" value="<?php echo $id ?>">
                                            <!--<input type="submit" value="comment" name="comment_chat" class='btn btn-info btn-xs'> -->
                                            <input type="submit" value="Delete" name="delete_chat" class='btn btn-danger btn-xs'>
                                        </form>
                                    </span></div>
                                <br>
                            </div>
                        </li>
            <?php
                    }
                }
            }
            $conn->close();
            $conn2->close();
            ?>
        </ul>

    </div>
<?php
} else {
    $_SESSION["getccode"] = "";
    $_SESSION["inipost"] = "";
    $_SESSION["newtopic"] = "NO";
    $_SESSION["course_title"] = "Classroom";
    $_SESSION["topics"] = "Classroom";
    $_SESSION["topics_id"] = 0;
    $_SESSION["showchat"] = 0;
    $_SESSION["startchat"] = "YES";
    $_SESSION["noonline"] = 0;
?>
    <div class="timeline timeline-simple mt-xlg mb-md">
        <ul class="chats">
            <h1 style='color: white'>Class Ended</h1>
        </ul>
    </div>
<?php
}
?>
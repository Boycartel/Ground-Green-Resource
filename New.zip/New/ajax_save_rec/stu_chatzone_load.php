<style type="text/css">
.asd {
    background: transparent !important;
    border: none !important;
    outline: none !important;
    padding: 0px, 0px, 0px, 0px !important;
    /* cursor: pointer; */

}
</style>
<?php




//if (isset($_POST["state1"])) {
require_once '../includes/db_connect2.php';

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}


$names = $staffdept = $msgid = "";
$reciep = $_POST["state1"];
//$stumatno = $_POST["stumatno"];
$dept = $_POST["dept1"];
$staff_pic_folder = $_POST["staff_pic_folder1"];
$level1 = $_POST["stulevel1"];

$isStu = false;
$sql3 = "SELECT matric_no FROM std_data_view WHERE matric_no = '$reciep'";
$result3 = $conn2->query($sql3);
if ($result3->num_rows > 0) {
    $isStu = true;
}

if ($reciep == "Dean" || $reciep == "HOD" || $reciep == "Examiner" || $reciep == "Ass_Examiner" || $reciep == "PG_Coord" || $reciep == "L100" || $reciep == "L200" || $reciep == "L300" || $reciep == "L400" || $reciep == "L500" || $reciep == "spill_over") {
    if ($reciep == "Dean") {
        $sql = "SELECT department, SchCode, staffid, Dean, Level1, full_name FROM users WHERE SchCode = '$schcode' AND Dean = 'YES'";
    } elseif ($reciep == "HOD") {
        $sql = "SELECT department, staffid, HOD, full_name FROM users WHERE department = '$dept' AND HOD = 'YES'";
    } elseif ($reciep == "PG_Coord") {
        $sql = "SELECT department, staffid, PG_Coord, full_name FROM users WHERE department = '$dept' AND PG_Coord = 'YES'";
    } elseif ($reciep == "Examiner") {
        $sql = "SELECT department, staffid, Examiner, full_name FROM users WHERE department = '$dept' AND Examiner = 'YES'";
    } elseif ($reciep == "Ass_Examiner") {
        $sql = "SELECT department, staffid, Ass_Examiner, full_name FROM users WHERE department = '$dept' AND Ass_Examiner = 'YES'";
    } elseif ($reciep == "L100") {
        $sql = "SELECT department, staffid, L100, full_name FROM users WHERE department = '$dept' AND L100 = 'YES'";
        $getlevel = 100;
    } elseif ($reciep == "L200") {
        $sql = "SELECT department, staffid, L200, full_name FROM users WHERE department = '$dept' AND L200 = 'YES'";
        $getlevel = 200;
    } elseif ($reciep == "L300") {
        $sql = "SELECT department, staffid, L300, full_name FROM users WHERE department = '$dept' AND L300 = 'YES'";
        $getlevel = 300;
    } elseif ($reciep == "L400") {
        $sql = "SELECT department, staffid, L400, full_name FROM users WHERE department = '$dept' AND L400 = 'YES'";
        $getlevel = 400;
    } elseif ($reciep == "L500") {
        $sql = "SELECT department, staffid, L500, full_name FROM users WHERE department = '$dept' AND L500 = 'YES'";
        $getlevel = 500;
    } elseif ($reciep == "spill_over") {
        $sql = "SELECT department, staffid, spill_over, full_name FROM users WHERE department = '$dept' AND spill_over = 'YES'";
        $getlevel = 600;
    }

    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $msgid = $row["staffid"];
            $staffdept = $row["department"];
            $names = $row["full_name"];
            $names = strtolower($names);
            $names = ucwords($names);
        }
    }
} elseif ($isStu == true) {



    $sql3 = "SELECT matric_no, first_name, other_name, surname FROM std_data_view WHERE matric_no = '$reciep'";
    $result3 = $conn2->query($sql3);
    if ($result3->num_rows > 0) {
        while ($row3 = $result3->fetch_assoc()) {
            $sturegother = $row3['matric_no'];
            $names = $row3["first_name"] . " " . $row3["other_name"] . " " . $row3["surname"];
            $names = strtolower($names);
            $names = ucwords($names);
            //$sturegother = $row3["stdid"];
            $matpassport = str_replace("/", "_", $row3['matric_no']);
        }
    }
} else {
    $dbsession = str_replace("/", "_", $curtsession);
    $sql = "SELECT C_codding, C_title FROM gencoursesupload WHERE C_codding = '$reciep'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $names = $row["C_title"];
        }
    }
}
$conn->close();
$conn2->close();
?>
<?php if ($reciep == "Dean" or $reciep == "HOD" or $reciep == "Examiner" or $reciep == "LevelAdv") { ?>
<diV>
    <div class="col-md-4" style="text-align: right;">
        <?php
            $filename = $staff_pic_folder . $msgid . '.jpg';

            if (file_exists($filename)) {
                echo "<img alt=''  class='img-circle' src='$staff_pic_folder" . $row['msgid'] . ".jpg' width='50' height='50'>";
            } else {
                echo "<img alt=''  class='img-circle' src='img/logo.ico' width='50' height='50'>";
            }
            ?>
    </div>
    <div class="col-md-8">
        <input type="hidden" name="recip_id" id="recip_id" value="<?php echo $reciep ?>">
        <p><?php echo $reciep ?></p>
        <p><?php echo $names ?></p>
    </div>
</diV>
<?php } elseif ($isStu == true) { ?>
<div class="col-md-4" style="text-align: right;">
    <?php echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='50' height='50'>" ?>
</div>
<div class="col-md-8">
    <input type="hidden" name="recip_id" id="recip_id" value="<?php echo $reciep ?>">
    <p><?php echo $reciep ?></p>
    <p><?php echo $names ?></p>
</div>
<?php } else { ?>
<div class="col-md-4" style="text-align: right;">
    <?php echo '<img class="img-circle" src="img/logo.ico" width="50" height="50" />'; ?>
</div>
<div class="col-md-8">
    <input type="hidden" name="recip_id" id="recip_id" value="<?php echo $reciep ?>">
    <p><?php echo $reciep ?></p>
    <p><?php echo $names ?></p>
</div>
<?php } ?>

<?php
//}
?>
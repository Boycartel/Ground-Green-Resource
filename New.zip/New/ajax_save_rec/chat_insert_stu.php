<?php
require_once '../includes/db_connect2.php';

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$mystdid = $_SESSION['stdid'];
$regid = $_SESSION["regid"];
$getccode = $_SESSION["getccode"];
$curtsession = $_SESSION['corntsession'];
$usernames = $_SESSION['names'];
$topics_id = $_SESSION["topics_id"];
$topics = $_SESSION["topics"];
$dept = strtoupper($_SESSION['deptcode']);

//$mychat=$_POST['mychat'];
$mychat = str_replace("'", "''", $_POST['mychat']);
$mychat = filter_var($mychat, FILTER_SANITIZE_STRING);

$getccode2 = strtolower($getccode);
$sql = "INSERT INTO " . $getccode2 . " (user_id, regid,  fullname, message, session1, topic_id, topics, usertype, dept) VALUES ('$mystdid', '$regid', '$usernames', '$mychat', '$curtsession', '$topics_id', '$topics', 'stu', '$dept')";

if ($conn->query($sql) === TRUE) {
	echo "data inserted";
} else {
	echo "failed";
}
$conn->close();

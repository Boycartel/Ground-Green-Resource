function printDiv(div_id) {
    var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
    disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
    var content_vlue = document.getElementById(div_id).innerHTML;

    var docprint = window.open("", "", disp_setting);

    ///// Enable Bootstrap CSS
    //// Can also add customise CSS 
    docprint.document.write('<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="css/bootstrap.min.css">');
    docprint.document.write('</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">');
    docprint.document.write(content_vlue);
    docprint.document.write('</body></html>');
    docprint.document.close();
    docprint.focus();
}
<?php

require_once '../includes/db_connect2.php';
$getccode = $_SESSION["getccode"];
$codetime = "";

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM aaa_quiz_list WHERE  ccode = '$getccode' AND quiz_begin = 'start'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$_SESSION["duration"] = $row["rem_time"];
	}
}
//$_SESSION["duration"]=300;

$sql = "SELECT * FROM aaa_online_courses WHERE ccode = '$getccode'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$codetime = $row["timestart"];
	}
}
date_default_timezone_set("Africa/Lagos");
$today = date('Y-m-d H:i:s');

$time = new DateTime($codetime);
$diff = $time->diff(new DateTime());
$minutes = ($diff->days * 24 * 60) + ($diff->h * 60) + $diff->i;

//echo "$minutes";
if ($minutes >= 180) {
	//$getccode=$_SESSION["getccode"];
	$sql = "DELETE FROM aaa_online_courses WHERE ccode='$getccode'";
	$result = $conn->query($sql);

	$sql = "DELETE FROM aaa_online_stu WHERE ccode = '$getccode'";
	$result = $conn->query($sql);

	$_SESSION["getccode"] = "";
	$_SESSION["inipost"] = "";
	$_SESSION["newtopic"] = "NO";
	$_SESSION["course_title"] = "Classroom";
	$_SESSION["topics"] = "Classroom";
	$_SESSION["topics_id"] = 0;
	$_SESSION["showchat"] = 0;
	$_SESSION["startchat"] = "YES";
	$_SESSION["noonline"] = 0;
}

$sql = "SELECT * FROM aaa_online_stu WHERE ccode='$getccode' AND status='online' ORDER BY name1";
$result = $conn->query($sql);
?>
<ul>
	<?php
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
			$stdid = $row["stdid"];
			$regdid = $row["regdid"];
			$name1 = $row["name1"];
			$dept = strtolower($row["dept"]);

	?>

			<li class="status-online">
				<div class="row">
					<div class="col-lg-2">
						<figure class="profile-picture">
							<?PHP


							$sql = "SELECT image FROM std_pictures WHERE matric_no='$regdid'";
							$sth = $conn2->query($sql);
							$result2 = mysqli_fetch_array($sth);

							echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['image']) . '"  width="50" height="50"/>';
							?>

						</figure>
					</div>
					<div class="col-lg-10">
						<div class="profile-info">
							<span class="name"><?php echo $name1 ?></span>
							<span style="color:#cccccc"><?php echo $regdid ?></span>
						</div>
					</div>
				</div>

			</li>


	<?php
		}
	}
	$conn->close();
	?>
</ul>
<?php
require_once '../includes/db_connect.php';

$staffid = $_SESSION['staffid'];
$getccode = $_SESSION["getccode"];
$curtsession = $_SESSION['corntsession'];
$_SESSION["no_quiz"];

$time_start = 0;
$duration = 0;
$rem_time = 0;
$sql = "SELECT * FROM aaa_quiz_list WHERE  ccode = '$getccode' AND quiz_begin = 'start'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $rem_time = $row["rem_time"];
    }
}


?>
<h5><span id="countdown-1"><?php echo $rem_time ?> seconds</span> Time Left</h5>

<script type="text/javascript">
// Initialize clock countdowns by using the total seconds in the elements tag
secs = parseInt(document.getElementById('countdown-1').innerHTML, 10);
setTimeout("countdown('countdown-1'," + secs + ")", 1000);
secs = parseInt(document.getElementById('countdown-2').innerHTML, 10);
setTimeout("countdown('countdown-2'," + secs + ")", 1000);

/**
 * Countdown function
 * Clock count downs to 0:00 then hides the element holding the clock
 * @param id Element ID of clock placeholder
 * @param timer Total seconds to display clock
 */
function countdown(id, timer) {
    timer--;
    minRemain = Math.floor(timer / 60);
    secsRemain = new String(timer - (minRemain * 60));
    // Pad the string with leading 0 if less than 2 chars long
    if (secsRemain.length < 2) {
        secsRemain = '0' + secsRemain;
    }

    // String format the remaining time
    clock = minRemain + ":" + secsRemain;
    document.getElementById(id).innerHTML = clock;
    if (timer > 0) {
        // Time still remains, call this function again in 1 sec
        setTimeout("countdown('" + id + "'," + timer + ")", 1000);
    } else {
        // Time is out! Hide the countdown
        document.getElementById(id).style.display = 'none';
    }
}
</script>
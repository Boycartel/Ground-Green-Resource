<style type="text/css">
    .asd {
        background: transparent !important;
        border: none !important;
        outline: none !important;
        padding: 0px, 0px, 0px, 0px !important;
        /* cursor: pointer; */

    }
</style>
<?php

//if (isset($_POST["state1"])) {
require_once '../includes/db_connect2.php';

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}

$reciep = $_POST["state1"];
$IsStudent = false;
//$reciep_1st_ca = substr($reciep, 0, 1);
$sql3 = "SELECT matric_no FROM std_data_view WHERE matric_no = '$reciep'";
$result3 = $conn2->query($sql3);
if ($result3->num_rows > 0) {
    $IsStudent = true;
}

$InstType = $_POST["InstType1"];
$stu_pic_folder =  $_POST["stu_pic_folder1"];



if ($reciep == "All") {
    $msgid = "All";
    $names = "All Students in the Department";
} elseif ($reciep == "All_stu") {
    $msgid = "All_stu";
    $names = "All Students";
} elseif ($reciep == "L100" || $reciep == "L200" || $reciep == "L300" || $reciep == "L400" || $reciep == "L500" || $reciep == "spill_over" || $reciep == "L100_stu" || $reciep == "L200_stu" || $reciep == "L300_stu" || $reciep == "L400_stu" || $reciep == "L500_stu" || $reciep == "spill_over_stu") {
    $msgid = $reciep;
    if ($InstType == "University") {
        if ($reciep == "spill_over" || $reciep == "spill_over_stu") {
            $names = "All Spill Over Students";
        } else {
            $names = "All " . substr($reciep, 1, 3) . " Level Students";
        }
    } elseif ($InstType == "Polytechnic") {
        if ($reciep == "spill_over" || $reciep == "spill_over_stu") {
            $names = "All Spill Over Students";
        } else {
            if ($reciep == "L100") {
                $names = "All NDI Students";
            } elseif ($reciep == "L200") {
                $names = "All NDII Students";
            } elseif ($reciep == "L300") {
                $names = "All HNDI Students";
            } elseif ($reciep == "L400") {
                $names = "All HNDII Students";
            }
        }
    }
} elseif ($IsStudent == true) {

    $sql3 = "SELECT matric_no, first_name, other_name, surname FROM std_data_view WHERE matric_no = '$reciep'";
    $result3 = $conn2->query($sql3);
    if ($result3->num_rows > 0) {
        while ($row3 = $result3->fetch_assoc()) {
            $sturegother = $row3['matric_no'];
            $names = $row3["first_name"] . " " . $row3["other_name"] . " " . $row3["surname"];
            $names = strtolower($names);
            $names = ucwords($names);
        }
    }
} else {
    //$dbsession = str_replace("/", "_", $curtsession);
    $sql = "SELECT C_codding, C_title FROM gencoursesupload WHERE C_codding = '$reciep'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $names = $row["C_title"];
        }
    }
}
?>
<?php if (($IsStudent == true)) { ?>
    <div class="col-md-4" style="text-align: right;">
        <?php

        $passptfile = str_replace("/", "", $reciep) . "_passport.jpg";
        echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='50' height='50'>";
        ?>

    </div>
    <div class="col-md-8">
        <input type="hidden" name="recip_id" id="recip_id" value="<?php echo $reciep ?>">
        <p><?php echo $reciep ?></p>
        <p><?php echo $names ?></p>
    </div>
<?php } else { ?>
    <div class="col-md-4" style="text-align: right;">
        <?php echo '<img class="img-circle" src="img/logo.ico" width="50" height="50" />'; ?>
    </div>
    <div class="col-md-8">
        <input type="hidden" name="recip_id" id="recip_id" value="<?php echo $reciep ?>">
        <p><?php echo $reciep ?></p>
        <p><?php echo $names ?></p>
    </div>
<?php } ?>
<?php
$conn->close();
$conn2->close();
?>
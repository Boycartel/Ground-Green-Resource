<?php
require_once 'includes/db_connect.php';

require_once 'includes/check_validity.php';
//$_SESSION['loadformval']="NO";
$corntsession = $_SESSION['corntsession'];
$tot1stoutunit = $tot2ndoutunit = 0;
$validate = "";
$stuname = "";
$_SESSION['valcoment'] = "";
//$getvalcoment = "";
//$cat = $_SESSION['cat'];

$dept = strtolower($_SESSION['valdept']);
//$dept = "MAT";
$regid = $_GET['q'];

$sql = "SELECT * FROM e_data_profile WHERE regid = '$regid'";
$result = $conn4->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$stdid =  $row["stdid"];
	}
}

$sql = "SELECT * FROM reg_password WHERE stdid = '$stdid'";
$result = $conn4->query($sql);
if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$name = $row["CandName"];
	}
}
echo "<div class='row'>";
echo "<div class='col-lg-9'>";
echo "Matric No:" . $regid;
echo "<br>";
echo "Name:  " . $name;
echo "</div>";

echo "</div>";


//echo $_SESSION['valdept'];
$sql = "SELECT * FROM " . $dept . "_hod_list WHERE matricno = '$regid'";
$result = $conn5->query($sql);

if ($result->num_rows > 0) {
	while ($row = $result->fetch_assoc()) {
		$validate = $row['LevelAdvice'];
		$getvalcat = "LevelAdvice";
		$getvalcoment = $row['LAComment'];
		$getfieldcomt = "LAComment";
	}
}

$sql = "SELECT * FROM courses_register WHERE Regn1 = '$regid' AND session ='$corntsession' AND SemTaken = '1ST'";
$result = $conn5->query($sql);

if ($result->num_rows > 0) {
	// output data of each row
?>

	<p>
		<center>1ST Semester Courses</center>
	</p>
	<table class="table mb-none">
		<thead>
			<tr>
				<th>Course Code</th>
				<th>Course Title</th>
				<th>Unit</th>
				<th>Semester</th>
				<th>Nature</th>
			</tr>
		</thead>
		<tbody>


			<?php
			while ($row = $result->fetch_assoc()) {
				$id = $row["sn"];
				$ccode = $row["CCode"];
				$CTitle = $row["CTitle"];
				$CUnit = $row["CUnit"];
				$SemTaken = $row["SemTaken"];
				$Nature = $row["Nature"];

				$tot1stoutunit += $row['CUnit'];


				echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['Nature']}</td></tr>\n";
			}
			?>
		</tbody>
	</table>

<?php

}
//$conn->close();
echo "<center> Total Credit Units : $tot1stoutunit</center>";
?>

<br /><br />
<?php



$sql = "SELECT * FROM courses_register WHERE Regn1 = '$regid' AND session ='$corntsession' AND SemTaken = '2ND'";
$result = $conn5->query($sql);

if ($result->num_rows > 0) {
	// output data of each row
?>
	<p>
		<center>2ND Semester Courses</center>
	</p>
	<table class="table mb-none">
		<thead>
			<tr>
				<th>Course Code</th>
				<th>Course Title</th>
				<th>Unit</th>
				<th>Semester</th>
				<th>Nature</th>
			</tr>
		</thead>
		<tbody>


			<?php
			while ($row = $result->fetch_assoc()) {

				$id = $row["sn"];
				$ccode = $row["CCode"];
				$CTitle = $row["CTitle"];
				$CUnit = $row["CUnit"];
				$SemTaken = $row["SemTaken"];
				$Nature = $row["Nature"];

				$tot2ndoutunit += $row['CUnit'];


				echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['Nature']}</td></tr>\n";
			}
			?>
		</tbody>
	</table>

<?php

}
//$conn->close();
echo "<center> Total Credit Units : $tot2ndoutunit</center>";

//$conn->close();
//$mysqli->close();
echo "<br>";
echo "<form class='form-horizontal'  method='post' action='course_validation_pg.php'>";
echo "<div class='form-group'>";
echo "<label class='control-label col-lg-4' for='regid'><strong>Comment:</strong></label>";
echo "<div class='col-lg-8'>";
echo "<input class='form-control' name='comment' id='comment' value='$getvalcoment'></input>";
echo "<input type='hidden' value=$regid name='valregid'>";
echo "<input type='hidden' value=$validate name='valcat'>";
echo "<input type='hidden' value=$getvalcat name='getvalcat'>";
echo "<input type='hidden' value=$getfieldcomt name='getfieldcomt'>";
echo "<br>";
if ($validate == "Yet") {
	echo "<button type='submit' name='validate' class='btn btn-primary'>Validate</button>";
	echo "<input type='hidden' value='Validate' name='valcoment'>";
} else {
	echo "<button type='submit' name='validate' class='btn btn-primary'>Cancel Validate</button>";
	echo "<input type='hidden' value='Yet' name='valcoment'>";
}
echo "</div>";
echo "</div>";

echo "</form>";
?>
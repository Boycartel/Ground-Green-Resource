<?php
session_start();

$_SESSION["mystatus"] = "staff";
$_SESSION["getccode"] = "";
$_SESSION["inipost"] = "";
$_SESSION["newtopic"] = "NO";
$_SESSION["course_title"] = "Classroom";
$_SESSION["topics"] = "Classroom";
$_SESSION["topics_id"] = 0;
$_SESSION["showchat"] = 0;
$_SESSION["startchat"] = "YES";
$_SESSION["noonline"] = 0;
$_SESSION["noregister"] = 0;
$_SESSION["be_on_chat"] = "NO";
$_SESSION["rem_time"] = 0;


require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

$usernames = $_SESSION['names'];
$cat = $_SESSION['cat'];
$curtsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$staffid = $_SESSION['staffid'];
$dept = strtoupper($_SESSION['deptcode']);
$_SESSION["course_title_assignment"] = "Assignment";


?>
<!doctype html>
<html class="fixed sidebar-left-collapsed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/isotope/jquery.isotope.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <!-- Message Chat CSS -->
    <link rel="stylesheet" href="assets/stylesheets/style_chat.css">
    <!-- Textarea Editor -->
    <link href="editor/css_/bootstrap3-wysihtml5.min.css" rel="stylesheet" media="screen" />
    <!--Download to excel-->
    <script src="assets/javascripts/tableToExcel_ATD.js"></script>
    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header">
            <div class="logo-container">
                <a href="../" class="logo">
                    <img src="img/favicon.ico" height="35" alt="FUTMinna" />
                </a>
                <div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <?php
                $imgpf = str_replace('.', '_', $_SESSION['staffid']);

                ?>

                <div id="userbox" class="userbox">
                    <a href="#" data-toggle="dropdown">
                        <figure class="profile-picture">
                            <?php

                            echo "<img src='https://staff.futminna.edu.ng/" . strtoupper($_SESSION['deptcode']) . "/images/" . strtoupper($imgpf) . "/MyPic1.jpg' alt='$usernames' class='img-circle' width='50' height='50' />";
                            ?>
                        </figure>
                        <div class="profile-info">
                            <span class="name"><?php echo $usernames ?></span>
                            <span class="role"><?php echo $staffid ?></span>
                        </div>

                        <i class="fa custom-caret"></i>
                    </a>

                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li class="divider"></li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="staff_profile.php"><i class="fa fa-user"></i> My
                                    Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="changepassw_staff.php"><i class="fa fa-chain (alias)"></i> Change Password</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="lock_screen.php"><i class="fa fa-lock"></i> Lock
                                    Screen</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="includes/logout_staff.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>




                        </ul>
                    </div>
                </div>
            </div>
            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php include_once 'includes/aside_menu_staff_class.php'; ?>
            <!-- end: sidebar -->
            <?php
            //$C_title="Classroom";


            ?>
            <section role="main" class="content-body">
                <header class="page-header" style="background-color:<?php echo $_SESSION['sch_color'] ?>">
                    <h2>Welcome to Nigerian Army University, Biu e-Classroom</h2>

                    <div class="right-wrapper pull-right">
                        <ol class="breadcrumbs">

                            <li>
                                <a href="classroom_assignment.php" class='btn btn-primary btn-xs'><i class="fa fa-graduation-cap"></i> Assignment</a>

                            </li>

                        </ol>
                    </div>
                </header>

                <!-- start: page -->
                <section class="content-with-menu content-with-menu-has-toolbar media-gallery">
                    <div class="content-with-menu-container">
                        <div class="inner-menu-toggle">
                            <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                Show Bar <i class="fa fa-chevron-right"></i>
                            </a>
                        </div>

                        <menu id="content-menu" class="inner-menu" role="menu">


                            <div class="nano">
                                <div class="form-group" style="padding-left: 1em; padding-right: 1em">

                                </div>
                                <div class="nano-content">
                                    <h4 style="text-align: center;">Calendar</h4>
                                    <div data-plugin-datepicker data-plugin-skin="dark"></div>

                                    <div class="inner-menu-toggle-inside">
                                        <a href="#" class="inner-menu-collapse">
                                            <i class="fa fa-chevron-up visible-xs-inline"></i><i class="fa fa-chevron-left hidden-xs-inline"></i> Hide Bar
                                        </a>
                                        <a href="#" class="inner-menu-expand" data-open="inner-menu">
                                            Show Bar <i class="fa fa-chevron-down"></i>
                                        </a>
                                    </div>

                                    <div class="inner-menu-content">



                                        <hr class="separator" />
                                        <?php
                                        if ($_SESSION["startchat"] == "NO") {
                                            if (isset($_POST["submit_ccode"])) {
                                                $getccode = $_POST["getccode"];
                                                $_SESSION["getccode"] = $getccode;
                                            }

                                        ?>

                                            <div class="sidebar-widget widget-friends" id="online_status">

                                            </div>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </menu>
                        <div class="inner-body mg-main">

                            <div class="inner-toolbar clearfix" style="color:#ffffff">

                            </div>


                            <div class="row mg-files" data-sort-destination data-sort-id="media-gallery">
                                <?php

                                $sql = "SELECT * FROM coursealocation WHERE PFNo='$staffid' AND SessionReg='$curtsession' AND Semester='$cursemester' ORDER BY CCode";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $CCode = $row["CCode"];
                                        $CTitle = $row["CTitle"];

                                ?>
                                        <div class="col-sm-6 col-md-4 col-lg-3">

                                            <section class="panel panel-quartenary">
                                                <header class="panel-heading bg-primary" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                                                    <div class="panel-heading-icon">
                                                        <img src="img/favicon.ico" class="img-responsive" alt="<?php echo $CCode ?>">
                                                    </div>
                                                </header>
                                                <div class="panel-body">
                                                    <br>
                                                    <div style="height: 100px; font-size: 14px">
                                                        <center>

                                                            <form class="form-horizontal bucket-form" method="Post" action="classroom_course.php">
                                                                <input type='hidden' value='<?php echo $CCode ?>' name='getccode'>
                                                                <button type="submit" name="view_course" style="background: none!important; border: none; padding: 0!important; font-family: arial, sans-serif; color: #069; cursor: pointer; font-size:xx-large"><span style="text-transform: capitalize;"><?php echo $CCode ?></span></button>
                                                            </form>
                                                        </center>
                                                        <center>
                                                            <form class="form-horizontal bucket-form" method="Post" action="classroom_course.php">
                                                                <input type='hidden' value='<?php echo $CCode ?>' name='getccode'>
                                                                <button type="submit" name="view_course" style="background: none!important; border: none; padding: 0!important; font-family: arial, sans-serif; color: #069; cursor: pointer"><span style="text-transform: capitalize;"><?php echo $CTitle ?></span></button>
                                                            </form>

                                                        </center>
                                                    </div>
                                                    <?php
                                                    $countcomp = 0;
                                                    $countnotcomp = 0;
                                                    $sql2 = "SELECT *  FROM aaa_course_topic WHERE ccode = '$CCode'";
                                                    $result2 = $conn8->query($sql2);
                                                    if ($result2->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {

                                                            $delivered = $row2["delivered"];
                                                            if ($delivered == "YES") {
                                                                $countcomp++;
                                                            } else {
                                                                $countnotcomp++;
                                                            }
                                                        }
                                                    }
                                                    if ($countcomp + $countnotcomp == 0) {
                                                        $perct = 0;
                                                    } else {
                                                        $perct = round(($countcomp / ($countcomp + $countnotcomp)) * 100);
                                                    }
                                                    $perct = round(($countcomp / ($countcomp + $countnotcomp)) * 100);
                                                    ?>
                                                    <div class="progress light m-md">
                                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $perct ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $perct ?>%;">
                                                            <?php echo $perct ?>% Complete
                                                        </div>
                                                    </div>
                                                    <div class="summary-footer" style="text-align: right">
                                                        <hr class="separator" />
                                                        <form class="form-horizontal bucket-form" method="Post" action="classroom_course.php">
                                                            <input type='hidden' value='<?php echo $CCode ?>' name='getccode'>
                                                            <input type="submit" value="View" name="view_course" class='btn btn-primary btn-xs'>
                                                        </form>


                                                    </div>

                                                </div>

                                            </section>


                                        </div>
                                <?php

                                    }
                                }
                                ?>

                            </div>

                        </div>

                    </div>

                </section>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/isotope/jquery.isotope.js"></script>
    <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>

    <!-- Examples -->
    <script src="assets/javascripts/pages/examples.mediagallery.js" />
    </script>

    <!--Textarea Editor-->
    <script src="editor/js_/app.js" type="text/javascript"></script>
    <script src="editor/js_/tinymce/tinymce.min.js" type="text/javascript"></script>
    <script src="editor/js_/ckeditor.js" type="text/javascript"></script>
    <script src="editor/js_/jquery.js" type="text/javascript"></script>
    <script src="editor/js_/editor1.js" type="text/javascript"></script>

</body>

</html>
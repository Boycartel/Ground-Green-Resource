<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>
<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">
    <script src="inline_edit/jquery.min.js"></script>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>ID Card Office Download</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Download
                            </li>

                            <li class="active">
                                <strong>ID Card Office Download</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                    if ($conn2->connect_error) {
                        die("Connection failed: " . $conn2->connect_error);
                    }
                    ?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            ID Card Office Download
                        </div>
                        <div class="panel-body">

                            <div class="row">

                                <div class="col-lg-12">
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="row">

                                            <div class="col-lg-4">
                                                <div class="row">
                                                    <label class="control-label col-lg-5" for="content">Select
                                                        Department:</label>
                                                    <div class="col-lg-7">
                                                        <select class="country form-control" style="color:#000000"
                                                            name="dept">
                                                            <option value="All">All</option>
                                                            <?php
                                                            $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                            $result = $conn->query($sql);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $deptcode2 = strtolower($row["DeptCode"]);
                                                                    $deptname2 = $row["DeptName"];
                                                                    echo "<option value=$deptcode2>$deptname2</option>";
                                                                }
                                                            }
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-3">
                                                <div class="row">
                                                    <label class="control-label col-lg-6" for="entry_session">Session
                                                        Admitted:</label>
                                                    <div class="col-lg-6">
                                                        <?php
                                                        $iniyear = 2018;
                                                        $finalyear = substr($_SESSION['corntsession'], 5);

                                                        ?>
                                                        <select name="entry_session" class="form-control"
                                                            style="color:#000000" id="entry_session"
                                                            required="required">
                                                            <option value="">Select Item</option>
                                                            <?php
                                                            while ($iniyear <= $finalyear) {
                                                                $addyear = $iniyear + 1;
                                                                $getsession = $iniyear . "/" . $addyear;
                                                                echo "<option value = '$getsession'>$getsession</option>";
                                                                $iniyear++;
                                                            }

                                                            ?>


                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if ($_SESSION['InstType'] == "University") { ?>
                                            <!-- <div class="col-lg-3">
                                                <div class="row">
                                                    <label class="control-label col-lg-6" for="curlevel">Current Level
                                                        :</label>
                                                    <div class="col-lg-6">
                                                        <select name="curlevel" class="form-control"
                                                            style="color:#000000" id="curlevel" required="required">
                                                            <option value="All">All</option>
                                                            <option value="100">100</option>
                                                            <option value="200">200</option>
                                                            <option value="300">300</option>
                                                            <option value="400">400</option>
                                                            <option value="500">500</option>

                                                        </select>
                                                    </div>
                                                </div>
                                            </div> -->
                                            <?php } ?>
                                            <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                            <div class="col-lg-3">
                                                <div class="row">
                                                    <label class="control-label col-lg-5"
                                                        for="getprogram">Program:</label>
                                                    <div class="col-lg-7">

                                                        <select name="getprogram" class="form-control"
                                                            style="color:#000000" id="getprogram" required="required">
                                                            <option value="">Select Item</option>
                                                            <option value="ND">ND</option>
                                                            <option value="HND">HND</option>

                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
                                            <div class="col-lg-2">
                                                <div class="row">

                                                    <div class="col-lg-4">
                                                        <button type="submit" name="submit"
                                                            class="btn btn-primary btn-sm">Submit</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </form>

                                    <hr class="separator" />
                                    <?php
                                    $staffid = $_SESSION['staffid'];
                                    ?>
                                    <?php if (isset($_POST["submit"])) { ?>
                                    <?php


                                        set_time_limit(500);
                                        $files = glob('img/tempimages/*'); //get all file names
                                        foreach ($files as $file) {
                                            if (is_file($file))
                                                unlink($file); //delete file
                                        }



                                        $passportidarry[] = "";
                                        $countpasspID = 0;
                                        $sno = 0;
                                        $dept = $_POST["dept"];
                                        $entry_session = $_POST["entry_session"];

                                        if ($dept == "All") {
                                            unlink("All_" . $staffid . ".zip"); //delete file                                           
                                        } else {
                                            unlink($dept . "_" . $staffid . ".zip"); //delete file                                           
                                        }



                                        if ($_SESSION['InstType'] == "Polytechnic") {
                                            $getprogram = $_POST["getprogram"];

                                            if ($getprogram == "ND") {
                                                $prog = "National Diploma";
                                            } elseif ($getprogram == "HND") {
                                                $prog = "Higher National Diploma";
                                            }
                                            if ($dept == "All") {

                                                $sql = "SELECT * FROM std_data_view WHERE entry_session = '$entry_session' AND modeofentry = '$getprogram'";
                                            } else {
                                                $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND entry_session = '$entry_session' AND modeofentry = '$getprogram'";
                                            }
                                        } else {
                                            //$curlevel = $_POST["curlevel"];
                                            if ($dept == "All") {
                                                $sql = "SELECT * FROM std_data_view WHERE entry_session = '$entry_session'";
                                                /* if ($curlevel == "All") {
                                                    $sql = "SELECT * FROM std_data_view WHERE entry_session = '$entry_session'";
                                                } else {
                                                    $sql = "SELECT * FROM std_data_view WHERE entry_session = '$entry_session' AND level = '$curlevel'";
                                                } */
                                            } else {
                                                $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND entry_session = '$entry_session'";
                                                /* if ($curlevel == "All") {
                                                    $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND entry_session = '$entry_session'";
                                                } else {
                                                    $sql = "SELECT * FROM std_data_view WHERE dept_code = '$dept' AND entry_session = '$entry_session' AND level = '$curlevel'";
                                                } */
                                            }
                                        }

                                        $result = $conn2->query($sql);

                                        if ($result->num_rows > 0) {

                                        ?>
                                    <div class="col-lg-12"
                                        style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">
                                        <table
                                            class="table table-striped table-bordered table-hover dataTables-example">
                                            <thead>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Matric No</th>
                                                    <th>JAMB Number</th>
                                                    <th>Surname</th>
                                                    <th>First Name</th>
                                                    <th>Other Name(s)</th>
                                                    <th>Level</th>
                                                    <th>Programme</th>
                                                    <th>State</th>
                                                    <th>LGA</th>
                                                    <th>DOB</th>
                                                    <th>Gender</th>
                                                    <th>Phone</th>
                                                    <th>Blood Group</th>
                                                    <th>Next of Kin</th>
                                                    <th>Next of Kin Phone</th>
                                                    <th>Entry Session</th>
                                                    <th>Image</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                        while ($row = $result->fetch_assoc()) {

                                                            if (strlen($row["matric_no"]) > 2) {
                                                                $sno++;
                                                                $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                                $stdid = $row["stdid"];
                                                                $matric_no = $row["matric_no"];
                                                                $blood_group = $row["blood_group"];
                                                                $timestamp = strtotime($row["dob"]);
                                                                if ($timestamp === false) {
                                                                    $dob = "";
                                                                } else {
                                                                    $dob = date_create($row["dob"]);
                                                                    $dob = date_format($dob, "d M, Y");
                                                                }


                                                                /* try {
                                                                
                                                            } catch (PDOException $e) {
                                                                
                                                            } */

                                                                if ($_SESSION['InstType'] == "Polytechnic") {
                                                                    if ($row["modeofentry"] == "ND") {
                                                                        if ($row['level'] == 100) {
                                                                            $level = "NDI";
                                                                        } elseif ($row['level'] == 200) {
                                                                            $level = "NDII";
                                                                        } else {
                                                                            $level = "Spill Over";
                                                                        }
                                                                    } elseif ($row["modeofentry"] == "HND") {
                                                                        if ($row['level'] == 100) {
                                                                            $level = "HNDI";
                                                                        } elseif ($row['level'] == 200) {
                                                                            $level = "HNDII";
                                                                        } else {
                                                                            $level = "Spill Over";
                                                                        }
                                                                    }
                                                                } else {
                                                                    $level = $row['level'];
                                                                }

                                                                $sql2 = "SELECT * FROM std_login WHERE stdid = '$stdid'";
                                                                $result2 = $conn2->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    $passportid = $stdid;
                                                                } else {
                                                                    $passportid = $matric_no;
                                                                }
                                                                echo "<tr><td>$sno</td><td>{$row['matric_no']}</td><td>{$row['jamb_appl_no']}</td><td>{$row['surname']}</td><td>{$row['first_name']}</td><td>{$row['other_name']}</td><td>$level</td><td>{$row['programme']}</td><td>{$row['state']}</td><td>{$row['lga']}</td><td>$dob</td><td>{$row['gender']}</td><td>{$row['phone_number']}</td><td>$blood_group</td><td>{$row['next_name']}</td><td>{$row['next_phone']}</td><td>{$row['entry_session']}</td>";

                                                                $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                                $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                                                //$countpasspID++;
                                                                //$passportidarry[$countpasspID] = $passptfile;
                                                                //$sourceFile = $stu_pic_folder . $passptfile;
                                                                //$destinationFile = 'Content/images/' . $passptfile;
                                                                //copy($sourceFile, $destinationFile);
                                                                //echo "<img alt='$names' src='$stu_pic_folder/$passptfile' width='100' height='100'>";
                                                                $imagename = str_replace("/", "_", $matric_no);

                                                                // Remote image URL
                                                                $url = $stu_pic_folder . "/" . $passptfile;

                                                                // Image path
                                                                //$img = 'img/tempimages/' . $imagename.'.jpg';
                                                                //$img = 'img/tempimages/img.jpg';

                                                                // Save image 
                                                                //file_put_contents($img, file_get_contents($url));



                                                                // Remote image URL
                                                                $url = $stu_pic_folder . "/" . $passptfile;

                                                                // Image path
                                                                $img = 'img/tempimages/' . $imagename . '.jpg';

                                                                // Save image
                                                                $ch = curl_init($url);
                                                                $fp = fopen($img, 'wb');
                                                                curl_setopt($ch, CURLOPT_FILE, $fp);
                                                                curl_setopt($ch, CURLOPT_HEADER, 0);
                                                                curl_exec($ch);
                                                                curl_close($ch);
                                                                fclose($fp);

                                                        ?>
                                                <td>
                                                    <img alt='$names'
                                                        src='<?php echo $stu_pic_folder . "/" . $passptfile ?>'
                                                        width='100' height='100'>


                                                </td>
                                                </tr>
                                                <?php
                                                            }
                                                        }
                                                        ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php } ?>
                                    <?php



                                        // Important: You should have read and write permissions to read
                                        // the folder and write the zip file
                                        $dir = 'img/tempimages';

                                        // Initialize archive object
                                        $zip = new ZipArchive();
                                        if ($dept == "All") {
                                            $zip_name = "All_" . $staffid . ".zip"; // Zip name
                                        } else {
                                            $zip_name = $dept . "_" . $staffid . ".zip"; // Zip name

                                        }

                                        $zip->open($zip_name, ZipArchive::CREATE);

                                        // Create recursive directory iterator
                                        /** @var SplFileInfo[] $files */
                                        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir), RecursiveIteratorIterator::LEAVES_ONLY);

                                        foreach ($files as $name => $file) {
                                            // Skip directories (they would be added automatically)
                                            if (!$file->isDir()) {
                                                // Get real and relative path for current file
                                                $filePath = $file->getRealPath();
                                                $relativePath = substr($filePath, strlen($dir) + 1);

                                                // Add current file to archive
                                                $zip->addFile($filePath, $relativePath);
                                            }
                                        }

                                        // Zip archive will be created only after closing object
                                        $zip->close();





                                        ?>
                                    <br><br>
                                    <div style="text-align: right;">
                                        <a href='<?php echo $zip_name ?>' download='<?php echo $zip_name ?>'>Downlod
                                            Images
                                        </a>
                                    </div>
                                    <?php } ?>

                                </div>
                                <br>

                            </div>

                        </div>
                    </div>

                    <?php
                    $conn->close();
                    $conn2->close();
                    ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <script>
    $(document).ready(function() {
        $('.dataTables-example').DataTable({
            pageLength: 25,
            responsive: true,
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [{
                    extend: 'copy'
                },
                {
                    extend: 'csv'
                },
                {
                    extend: 'excel',
                    title: 'ExampleFile'
                },
                {
                    extend: 'pdf',
                    title: 'ExampleFile'
                },

                {
                    extend: 'print',
                    customize: function(win) {
                        $(win.document.body).addClass('white-bg');
                        $(win.document.body).css('font-size', '10px');

                        $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                    }
                }
            ]

        });

    });
    </script>


</body>

</html>
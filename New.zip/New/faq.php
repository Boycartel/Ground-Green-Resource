<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['logintype'] !== "staff") {
    header('Location: index.php');
}

?>
<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>

</head>

<body>
    <?php
    $saveresponce = "";
    $names = $_SESSION['names'];
    if (isset($_POST["submit"])) {
        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $faqquestion = str_replace("'", "''", $_POST['faqquestion']);
        $faqquestion = filter_var($faqquestion, FILTER_SANITIZE_STRING);
        $sql = "INSERT INTO faq (question1, questionier_name) VALUES ('$faqquestion', '$names')";
        $result = $conn->query($sql);
        $conn->close();

        $saveresponce = "Record Saved ...";
    }
    ?>
    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>FAQ</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li class="active">
                            <strong>Frequently asked questions</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-sm-8">
                    <div class="title-action">

                        <div class="modal inmodal" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                                <form class="form-horizontal" action="" method="post">
                                    <div class="modal-content animated bounceInRight">
                                        <div class="modal-header">

                                            <h4 class="modal-title">Add Question</h4>

                                        </div>
                                        <div class="modal-body">
                                            <p style="text-align: center;">You can add question to "Frequently Asked
                                                Questions"<br>Your question will be
                                                responded to and added to the question bank.</p>

                                            <br>
                                            <div class="form-group" style="text-align: left;">
                                                <label>Add Question</label>
                                                <input type="text" name="faqquestion" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-white"
                                                data-dismiss="modal">Close</button>
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper wrapper-content animated fadeInRight">

                        <div class="ibox-content m-b-sm border-bottom">
                            <div class="text-center p-lg">
                                <h2>If you don't find the answer to your question</h2>
                                <span>add your question by selecting </span>
                                <button type="button" class="btn btn-primary btn-xs" data-toggle="modal"
                                    data-target="#myModal"><i class="fa fa-plus"></i>Add question</button>button
                                <h2><?php echo $saveresponce ?></h2>
                            </div>
                        </div>

                        <div class="col-md-1">

                        </div>
                        <div class="col-md-10">

                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $sql = "SELECT * FROM faq";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                            ?>

                            <table style="width: 100%;">
                                <tbody>
                                    <?php
                                        while ($row = $result->fetch_assoc()) {
                                        ?>
                                    <tr>
                                        <td>
                                            <div class="faq-item">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <a data-toggle="collapse" href="#<?php echo $row["id"] ?>"
                                                            class="faq-question"><?php echo $row["question1"] ?></a>
                                                        <small>Added by
                                                            <strong><?php echo $row["questionier_name"] ?></strong>
                                                            <i class="fa fa-clock-o"></i>
                                                            <?php echo $row["date1"] ?></small>
                                                    </div>

                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div id="<?php echo $row["id"] ?>"
                                                            class="panel-collapse collapse ">
                                                            <div class="faq-answer">
                                                                <p>
                                                                    <?php echo $row["question_resp"] ?><br><br>
                                                                    <video width="600" controls>
                                                                        <source
                                                                            src="videos/faq/<?php echo $row["id"] ?>.mp4"
                                                                            type="video/mp4">
                                                                        <source src="mov_bbb.ogg" type="video/ogg">
                                                                        Your browser does not support HTML video.
                                                                    </video>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                        }
                                        ?>
                                </tbody>
                            </table>
                            <?php
                            }
                            $conn->close();
                            ?>




                        </div>
                        <div class="col-md-1">

                        </div>


                    </div>
                </div>
            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
    $(document).ready(function() {

        $('#loading-example-btn').click(function() {
            btn = $(this);
            simpleLoad(btn, true)

            // Ajax example
            //                $.ajax().always(function () {
            //                    simpleLoad($(this), false)
            //                });

            simpleLoad(btn, false)
        });
    });

    function simpleLoad(btn, state) {
        if (state) {
            btn.children().addClass('fa-spin');
            btn.contents().last().replaceWith(" Loading");
        } else {
            setTimeout(function() {
                btn.children().removeClass('fa-spin');
                btn.contents().last().replaceWith(" Refresh");
            }, 2000);
        }
    }
    </script>
</body>

</html>
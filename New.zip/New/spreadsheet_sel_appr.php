<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php

    $deptoption = $_SESSION['deptoption'];
    $deptname = $_SESSION["deptname"];
    $schcode = $_SESSION['schcode'];
    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Graduating Students Spreadsheet</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>
                            <li>
                                Students Spreadsheet
                            </li>
                            <li class="active">
                                <strong>Graduating Students Spreadsheet</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Graduating Students Spreadsheet
                        </div>
                        <div class="panel-body">

                            <form class="form-horizontal form-bordered" action="spreadsheet_grad.php" target="_blank"
                                method="post">
                                <div class="row">

                                    <div class="col-lg-4">
                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Select Approval
                                                Level:</label>
                                            <div class="col-lg-7">
                                                <select class="form-control" style="color:#000000" name="apprFormat"
                                                    required="required">
                                                    <option value="">Select Item</option>
                                                    <?php if ($_SESSION['InstType'] == "University") { ?>
                                                    <option value="SchBoard">School Board Format</option>
                                                    <option value="Scrutiny">Scrutiny Format</option>
                                                    <option value="Senate">Senate Format</option>
                                                    <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                    <option value="SchBoard">School Board</option>
                                                    <option value="Scrutiny">Examination Results Board</option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="row">
                                            <label class="control-label col-lg-5" for="content">Select
                                                Semester:</label>
                                            <div class="col-lg-7">
                                                <select class="form-control" style="color:#000000" name="semesterSel"
                                                    required="required">
                                                    <option value="">Select Item</option>
                                                    <option value="1ST">1ST</option>
                                                    <option value="2ND">2ND</option>

                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="row">

                                            <div class="col-lg-4">
                                                <button type="submit" name="submit_sel"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </form>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
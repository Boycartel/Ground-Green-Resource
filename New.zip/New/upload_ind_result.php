<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">


    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> -->

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Upload Raw Results</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Upload
                            </li>

                            <li class="active">
                                <strong>Upload Raw Results</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php
                $resultsession = $_SESSION['resultsession'];
                $resultsemester = $_SESSION['resultsemester'];
                ?>
                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Upload Raw Results (<?php echo $resultsession ?> Session,
                            <?php echo $resultsemester ?> Semester)
                        </div>
                        <div class="panel-body">

                            <div class="col-lg-3">

                            </div>
                            <div class="col-lg-6">

                                <?php

                                $cursession = $_SESSION['resultsession'];
                                $dept = $_SESSION['deptcode'];
                                $staffid = $_SESSION['staffid'];


                                unset($MatNo);
                                $MatNo[] = "";
                                unset($CA);
                                $CA[] = "";
                                unset($Exam);
                                $Exam[] = "";

                                /* unset($MatNoDrop);
                                $MatNoDrop[] = "";
                                unset($CADrop);
                                $CADrop[] = "";
                                unset($ExamDrop);
                                $ExamDrop[] = ""; */
                                $countrec = 0;
                                //$countrecDrop = 0;


                                ?>


                            </div>
                            <div class="col-lg-3">

                            </div>


                            <?php
                            if (isset($_POST["submit"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                if ($conn2->connect_error) {
                                    die("Connection failed: " . $conn2->connect_error);
                                }

                                $MatNo = $_SESSION["MatNo"];
                                $CA = $_SESSION["CA"];
                                $Exam = $_SESSION["Exam"];
                                $countrec = $_SESSION["countrec"];
                                $ccode = $_SESSION["ccode"];

                                set_time_limit(500);
                                //error_reporting(E_ERROR);
                                $dbsession = str_replace("/", "_", $cursession);
                                $sql = "select 1 from raw_results_" . $dbsession;
                                $exists = $conn->query($sql);

                                if ($exists == false) {
                                    $TabCreate = "raw_results_" . $dbsession;
                                    $sql = "CREATE TABLE " . $TabCreate . " SELECT * FROM raw_results_empty";
                                    $result = $conn->query($sql);

                                    $sql = "ALTER TABLE " . $TabCreate . " ADD column sn int NOT NULL auto_increment Primary Key";
                                    $result = $conn->query($sql);
                                }

                                $sql = "DELETE FROM raw_results_" . $dbsession . " WHERE CCode = '$ccode'  AND semTaken = '$resultsemester'";
                                $result = $conn->query($sql);
                                $count2 = 0;
                                for ($x = 1; $x <= $countrec; $x++) {
                                    $matric_no = filter_var($MatNo[$x], FILTER_SANITIZE_STRING);
                                    $CA = filter_var($CA[$x], FILTER_SANITIZE_STRING);
                                    $Exam = filter_var($Exam[$x], FILTER_SANITIZE_STRING);

                                    if (is_numeric($CA)) {
                                        $CA2 = $CA;
                                    } else {
                                        $CA2 = 0;
                                        $StatusCA = $CA;
                                    }
                                    if (is_numeric($Exam)) {
                                        $Exam2 = $Exam;
                                        $NoExam = "NO";
                                        $StatusExam = "Y";
                                    } else {
                                        $Exam2 = 0;
                                        $NoExam = "YES";
                                        $StatusExam = $Exam;
                                    }

                                    $getTotal = $CA2 + $Exam2;
                                    $name1 = "XX";
                                    $sql2 = "SELECT * FROM std_data_view WHERE matric_no = '$matric_no'";
                                    $result2 = $conn2->query($sql2);
                                    if ($result2->num_rows > 0) {
                                        while ($row2 = $result2->fetch_assoc()) {
                                            $stu_dept = $row2["dept_code"];
                                            $name1 = str_replace("'", "''", $row2["first_name"] . " " . $row2["other_name"] . " " . $row2["surname"]);
                                        }
                                    }

                                    $sql2 = "SELECT * FROM raw_results_" . $dbsession . " WHERE Regn1 = '$matric_no' AND CCode = '$ccode'  AND semTaken = '$resultsemester'";
                                    $result2 = $conn->query($sql2);
                                    if ($result2->num_rows == 0) {
                                        $count2++;
                                        $sql3 = "INSERT INTO raw_results_" . $dbsession . "(CCode, SessionRegis, CA, Exam, total, Regn1, name1, mother_dept, stu_dept, status1, semTaken)VALUES('$ccode', '$cursession', '$CA2', '$Exam2', '$getTotal', '$matric_no', '$name1', '$dept', '$stu_dept', '$StatusExam', '$resultsemester')";
                                        $result3 = $conn->query($sql3);
                                    }
                                }

                                $sql = "DELETE FROM submitted_results_list WHERE CCode = '$ccode' AND Session1 = '$cursession' AND semester = '$resultsemester'";
                                $result = $conn->query($sql);

                                $sql = "INSERT INTO submitted_results_list(CCode, Mother_Dept, Session1, No_students, semester)VALUES('$ccode', '$dept', '$cursession', '$count2', '$resultsemester')";
                                $result = $conn->query($sql);
                                echo '<center><p style="color:#006">CSV File Imported successfully...</p></center>';
                                $conn->close();
                                $conn2->close();
                            ?>
                            <script>
                            $(document).ready(function() {
                                $("#ToasterSuccessModal").modal();
                            });
                            </script>
                            <?php

                            }
                            ?>

                            <div class="row">
                                <div class="col-lg-3">

                                </div>
                                <div class="col-lg-6">

                                    <div class="table-responsive">
                                        <h4 style="text-align: center">CSV File with the Format Below.</h4>
                                        <center><img src='img/resultFormat.jpg' width='250' height='200' alt=''>
                                        </center>
                                        <center><strong>D = Deferred; S = Sick; W = Withdraw; N = Not
                                                available; I = Incomplte</strong></center>
                                        <br><br>
                                        <table class="table table-striped mb-none">
                                            <thead>
                                                <tr>

                                                    <th hidden="hidden">ID</th>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>

                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }


                                                $sql = "SELECT * FROM coursealocation WHERE PFNo = '$staffid' AND SessionReg = '$resultsession' AND Semester = '$resultsemester'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $id = $row['sn'];
                                                        $ccode = $row['CCode'];
                                                        $ctitle = $row['CTitle'];
                                                        $CSemester = $row['Semester'];
                                                        $teamleader = $row['teamleader'];
                                                ?>
                                                <tr>

                                                    <td hidden="hidden"><?php echo $id; ?></td>
                                                    <td><?php echo $ccode; ?></td>
                                                    <td><?php echo $ctitle; ?></td>

                                                    <td>
                                                        <?php if ($teamleader == "YES") { ?>
                                                        <button type="button"
                                                            class='btn btn-default btn-xs uploaddata'><i
                                                                class="fa fa-cloud-upload" data-toggle="tooltip"
                                                                title="Upload"> Upload</i></button>

                                                        <?php } ?>
                                                    </td>

                                                </tr>
                                                <?php

                                                    }
                                                }
                                                $conn->close();
                                                ?>

                                            </tbody>
                                        </table>
                                        <br><br>
                                    </div>

                                    <?php
                                    $messageerror = "";

                                    if (isset($_POST["upfile"])) {
                                        //$ccode = $_POST['optcode'];
                                        $id = $_POST['update_id'];
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }


                                        $approval = "NO";

                                        $sql2 = "SELECT * FROM coursealocation WHERE sn = '$id'";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $ccode = $row2["CCode"];
                                            }
                                        }
                                        $_SESSION["ccode"] = $ccode;
                                        $sql2 = "SELECT * FROM submitted_results_list WHERE CCode = '$ccode'";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $approval = $row2["approval"];
                                            }
                                        }
                                        $conn->close();
                                        $resultsession2 = str_replace("/", "_", $resultsession);
                                        if ($approval != "YES") {

                                            $filename = $_FILES["uploaded"]["tmp_name"];
                                            //$file_ext = strtolower(end(explode('.', $_FILES['uploaded']['name'])));
                                            $file_ext = pathinfo($_FILES['uploaded']['name'], PATHINFO_EXTENSION);
                                            if ($file_ext == "csv") {
                                                if ($_FILES['uploaded']['name'] == $ccode . '.csv') {
                                                    if ($_FILES["uploaded"]["size"] > 0) {
                                                        $file = fopen($filename, "r");
                                                        $count = 0;
                                                        $count2 = 0;
                                    ?>
                                    <h3 style="color:green">Confirm Uploading <?php echo strtoupper($ccode) ?></h3>
                                    <table class="table table-bordered table-striped mb-none">
                                        <thead>
                                            <tr>
                                                <th>SNo</th>
                                                <th>Matric No</th>
                                                <th>CA</th>
                                                <th>Exam</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                                while (($Row = fgetcsv($file, 10000, ",")) !== false) {
                                                                    $count++;
                                                                    if ($count > 1) {
                                                                        /* $regno2 = $Row[0];
                                                                        $sql2 = "SELECT * FROM courses_register_" . $resultsession2 . " WHERE Regn1 = '$regno2' AND CCode = '$ccode'";
                                                                        $result2 = $conn->query($sql2);
                                                                        $Add2 = 0;
                                                                        if ($result2->num_rows > 0) {
                                                                            $countrec++;

                                                                            $MatNo[$countrec] = $Row[0];
                                                                            $CA[$countrec] = $Row[1];
                                                                            $Exam[$countrec] = $Row[2];

                                                                            echo "<tr><td>$countrec</td><td>$MatNo[$countrec]</td><td>$CA[$countrec]</td><td>$Exam[$countrec]</td></tr>";
                                                                        } else {
                                                                            $countrecDrop++;

                                                                            $MatNoDrop[$countrecDrop] = $Row[0];
                                                                            $CADrop[$countrecDrop] = $Row[1];
                                                                            $ExamDrop[$countrecDrop] = $Row[2];
                                                                        } */

                                                                        $countrec++;

                                                                        $MatNo[$countrec] = $Row[0];
                                                                        $CA[$countrec] = $Row[1];
                                                                        $Exam[$countrec] = $Row[2];

                                                                        echo "<tr><td>$countrec</td><td>$MatNo[$countrec]</td><td>$CA[$countrec]</td><td>$Exam[$countrec]</td></tr>";
                                                                    }
                                                                }
                                                                /*  $_SESSION["MatNoDrop"] = $MatNoDrop;
                                                                $_SESSION["CADrop"] = $CADrop;
                                                                $_SESSION["ExamDrop"] = $ExamDrop;
                                                                $_SESSION["countrecDrop"] = $countrecDrop; */

                                                                $_SESSION["MatNo"] = $MatNo;
                                                                $_SESSION["CA"] = $CA;
                                                                $_SESSION["Exam"] = $Exam;
                                                                $_SESSION["countrec"] = $countrec;
                                                                ?>
                                        </tbody>
                                    </table>

                                    <form class="form-horizontal form-bordered" method="post">
                                        <br>
                                        <div class="row" style="text-align: right">
                                            <button type="submit" name="submit" class="btn btn-primary btn-xs">Commit
                                                Operation</button>
                                        </div>
                                    </form>



                                    <?php
                                                        fclose($file);
                                                    } else {
                                                        echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File(' . $ccode . '.csv)</p></center>';
                                                        $messageerror = "Invalid File: Please Upload CSV File($ccode.csv)";
                                                    ?>
                                    <script>
                                    $(document).ready(function() {
                                        $("#ToasterModal").modal();
                                    });
                                    </script>
                                    <?php } ?>
                                    <?php

                                                } else {
                                                    echo '<center><p style="color:#F00">Invalid File:Please Pick Correct File(' . $ccode . '.csv)</p></center>';
                                                    $messageerror = "Invalid File: Please Pick Correct File($ccode.csv)";
                                                ?>
                                    <script>
                                    $(document).ready(function() {
                                        $("#ToasterModal").modal();
                                    });
                                    </script>
                                    <?php
                                                }
                                            } else {
                                                echo '<center><p style="color:#F00">Invalid File:Please Upload CSV File(' . $ccode . '.csv)</p></center></p>';
                                                $messageerror = "Invalid File: Please Upload CSV File($ccode.csv)";
                                                ?>

                                    <script>
                                    $(document).ready(function() {
                                        $("#ToasterModal").modal();
                                    });
                                    </script>
                                    <?php
                                            }
                                        } else {
                                            echo "<h3 style='color: red; text-align: center'>SORRY $ccode Already Uploaded and approved by HOD ...</h3><br>";
                                            $messageerror = "SORRY $ccode Already Uploaded and approved by HOD ...";
                                            ?>
                                    <script>
                                    $(document).ready(function() {
                                        $("#ToasterModal").modal();
                                    });
                                    </script>
                                    <?php
                                        }
                                    }
                                    ?>
                                </div>
                                <div class="col-lg-3">

                                </div>
                            </div>

                            <!-- Upload Results -->
                            <div id="uploadModal" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form enctype="multipart/form-data" action="" method="POST">
                                            <input type="hidden" name="update_id" id="update_id">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Upload Record</h4>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label>Course Code</label>
                                                    <input type="text" name="optcode" id="optcode" disabled="disabled"
                                                        class="form-control">

                                                </div>
                                                <div class="form-group">
                                                    <label>Course Title</label>
                                                    <input type="text" name="opttitle" id="opttitle" disabled="disabled"
                                                        class="form-control" placeholder="Enter Option Title" required>

                                                </div>

                                            </div>

                                            <div class="form-group">
                                                <label class="col-md-3 control-label">File Upload</label>
                                                <div class="col-md-9">
                                                    <div class="fileupload fileupload-new" data-provides="fileupload">
                                                        <div class="input-append">



                                                            <div class="fileinput fileinput-new input-group"
                                                                data-provides="fileinput">
                                                                <div class="form-control" data-trigger="fileinput">
                                                                    <i
                                                                        class="glyphicon glyphicon-file fileinput-exists"></i>
                                                                    <span class="fileinput-filename"></span>
                                                                </div>
                                                                <span
                                                                    class="input-group-addon btn btn-default btn-file"><span
                                                                        class="fileinput-new">Select
                                                                        file</span><span
                                                                        class="fileinput-exists">Change</span><input
                                                                        type="file" name="uploaded"></span>
                                                                <a href="#"
                                                                    class="input-group-addon btn btn-default fileinput-exists"
                                                                    data-dismiss="fileinput">Remove</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <br><br>
                                            <div class="modal-footer">
                                                <input type="button" class="btn btn-default" data-dismiss="modal"
                                                    value="Cancel">
                                                <input type="submit" name="upfile" value="Submit"
                                                    class="btn btn-primary btn-sm">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>




                            <!-- Toaster Modal -->
                            <div id="ToasterModal" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header" style="background-color: red; color:white">
                                            <h2 class="modal-title"><strong>Upload Error</strong></h2>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-hidden="true">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">

                                                <h3><?php echo $messageerror ?></h3>
                                            </div>

                                        </div>


                                        <div class="modal-footer">
                                            <input type="button" class="btn btn-default" data-dismiss="modal"
                                                value="Cancel">

                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div id="ToasterSuccessModal" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header" style="background-color:green; color:white">
                                            <h2 class="modal-title"><strong>Upload Success</strong></h2>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-hidden="true">&times;</button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">

                                                <h3>CSV File Imported successfully ...</h3>
                                            </div>

                                        </div>


                                        <div class="modal-footer">
                                            <input type="button" class="btn btn-default" data-dismiss="modal"
                                                value="Cancel">

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <!-- Jasny -->
    <script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>


    <script>
    $(document).ready(function() {

        $('.uploaddata').on('click', function() {

            $('#uploadModal').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function() {
                return $(this).text();
            }).get();

            console.log(data);

            $('#update_id').val(data[0]);
            $('#optcode').val(data[1]);
            $('#opttitle').val(data[2]);

        });
    });
    </script>



</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pg_staff_results'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Profile</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Student Biodata
                            </li>
                            <li class="active">
                                <strong>Postgraduate</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <div class="wrapper wrapper-content">
                    <div class="row animated fadeInRight">
                        <div>
                            <form class="form-horizontal form-bordered" method="post">
                                <div class="form-group">
                                    <label class="col-lg-4 control-label">Registration Number: </label>
                                    <div class="col-lg-5">
                                        <input type="text" class="form-control" style="color:#000000" name="regid">
                                    </div>
                                    <div class="col-lg-3">
                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                    </div>
                                </div>
                            </form>
                        </div>
                        <br>
                        <hr class="separator" />

                        <?php if (isset($_POST["submit"])) { ?>
                            <?php
                            $regno = $_POST["regid"];
                            $sql = "SELECT * FROM e_data_profile WHERE regid = '$regno'";
                            $result = $conn4->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $stuid = $row["stdid"];
                                    $paddr = $row["paddr"];
                                    $phone = $row["phone"];
                                    $marital = $row["marital"];
                                    $religion = $row["religion"];
                                    $blood_group = $row["blood_group"];
                                    $next_name = $row["next_name"];
                                    $next_rel = $row["next_rel"];
                                    $next_addr = $row["next_addr"];
                                    $next_phone = $row["next_phone"];
                                }
                                //$_SESSION['regno']=$regno;
                                //$_SESSION['stuid']=$stuid;
                            }

                            $sql = "SELECT * FROM pgapplication WHERE applicant_id = '$stuid'";
                            $result = $conn4->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $application_date = $row["application_date"];
                                    $course1 = $row["course1"];
                                    $course_time = $row["course_time"];
                                    $programme_title = $row["programme_title"];
                                    $date_of_birth = $row["date_of_birth"];
                                    $surname = $row["surname"];
                                    $firstname = $row["firstname"];
                                    $middlename = $row["middlename"];
                                    $display_fullname = $row["display_fullname"];
                                    $email = $row["email"];
                                    $hq_degree = $row["hq_degree"];

                                    $m_institute = $row["m_institute"];
                                    $m_yr_grad = $row["m_yr_grad"];
                                    $m_degree_class = $row["m_degree_class"];
                                    $m_cgpa = $row["m_cgpa"];
                                    $m_gps = $row["m_gps"];
                                    $m_discipline = $row["m_discipline"];

                                    $b_institute = $row["b_institute"];
                                    $b_yr_grad = $row["b_yr_grad"];
                                    $b_degree_class = $row["b_degree_class"];
                                    $b_cgpa = $row["b_cgpa"];
                                    $b_gps = $row["b_gps"];
                                    $b_discipline = $row["b_discipline"];

                                    $p_institute = $row["p_institute"];
                                    $p_yr_grad = $row["p_yr_grad"];
                                    $p_degree_class = $row["p_degree_class"];
                                    $p_cgpa = $row["p_cgpa"];
                                    $p_gps = $row["p_gps"];
                                    $p_discipline = $row["p_discipline"];

                                    $h_institute = $row["h_institute"];
                                    $h_yr_grad = $row["h_yr_grad"];
                                    $h_degree_class = $row["h_degree_class"];
                                    $h_cgpa = $row["h_cgpa"];
                                    $h_gps = $row["h_gps"];
                                    $h_discipline = $row["h_discipline"];

                                    $o_institute = $row["o_institute"];
                                    $o_yr_grad = $row["o_yr_grad"];
                                    $o_degree_class = $row["o_degree_class"];
                                    $o_cgpa = $row["o_cgpa"];
                                    $o_gps = $row["o_gps"];
                                    $o_discipline = $row["o_discipline"];

                                    $lga = $row["lga"];
                                    //$p_address = $row["p_address"];
                                    $nationality = $row["nationality"];
                                    //$phone = $row["phone"];
                                    $sex = $row["sex"];
                                    //$blood_grp = $row["blood_grp"];
                                    $department = $row["department"];
                                    $school = $row["school"];
                                    $regid = $row["regid"];
                                }
                                //$_SESSION['regno']=$regno;
                                //$_SESSION['stuid']=$stuid;
                            }

                            $length = strlen($lga);
                            $state = "";
                            $lga2 = "";
                            $countstate = 0;
                            for ($i = 0; $i < $length; $i++) {
                                $c = $lga[$i];
                                if ($c !== "_") {
                                    $state = $state . $c;
                                    $countstate++;
                                } else {
                                    break;
                                }
                            }

                            $countstate++;
                            for ($i = $countstate; $i < $length; $i++) {
                                $c = $lga[$i];
                                $lga2 = $lga2 . $c;
                            }

                            ?>
                            <div class="col-md-4">
                                <div class="ibox float-e-margins">
                                    <div class="ibox-title">
                                        <h5>Profile</h5>
                                    </div>
                                    <div>
                                        <div class="ibox-content no-padding border-left-right" style="text-align: center;">
                                            <?php

                                            echo "<img src='https://eportal.futminna.edu.ng/pg/uploads/" . $stuid . "_passport.jpg' alt='$surname' class='img-circle' data-lock-picture='https://eportal.futminna.edu.ng/pg/uploads/" . $stuid . "_passport.jpg' />"; ?>
                                        </div>
                                        <div class="ibox-content profile-content">
                                            <h4><strong>Matric Number:</strong><?php echo strtoupper($regno) ?></h4>
                                            <h4><strong>Name:</strong><?php echo $firstname . " " . $middlename . " " . $surname ?>
                                            </h4>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="ibox float-e-margins">
                                    <div class="ibox-title">
                                        <h5>Profile Detail</h5>
                                        <div class="ibox-tools">
                                            <a class="collapse-link">
                                                <i class="fa fa-chevron-up"></i>
                                            </a>
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                                <i class="fa fa-wrench"></i>
                                            </a>
                                            <ul class="dropdown-menu dropdown-user">
                                                <li><a href="#">Config option 1</a>
                                                </li>
                                                <li><a href="#">Config option 2</a>
                                                </li>
                                            </ul>
                                            <a class="close-link">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="ibox-content">
                                        <form method="get" class="form-horizontal">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Registration No. :</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo strtoupper($regno) ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Student ID:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo strtoupper($stuid) ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Surname:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $surname ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">First Name:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $firstname ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Other Names:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $middlename ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Gender:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $sex ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Parmenent Home Address:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $paddr ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Marital Status:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $marital ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Nationality:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $nationality ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">State of Origin:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo ucfirst($state) ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">LGA:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo ucfirst($lga2) ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Date of Birth:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $date_of_birth ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Place of Birth:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">School:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $school ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Department:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $department ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Programme of Study:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $course1 ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Programme Type:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo strtoupper($course_time) . " TIME" ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Programme Title:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $programme_title ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Highest Qualification:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $hq_degree ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Email:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $email ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Phone:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $phone ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Religion:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $religion ?></label>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Blood Group:</label>
                                                <div class="col-sm-8">
                                                    <label class="control-label" style="color:#000"><?php echo $blood_group ?></label>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Certificates Obtained:</label>
                                                <div class="col-sm-8">
                                                    <table class="table stats-table">
                                                        <thead>
                                                            <tr>
                                                                <th>S/No</th>
                                                                <th>Certificate</th>
                                                                <th>Institution</th>
                                                                <th>Year of Graduation</th>
                                                                <th>Class of Degree</th>
                                                                <th>CGPA</th>
                                                                <th>Discipline</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                            $sno2 = 0;
                                                            $sql = "SELECT * FROM pgapplication WHERE applicant_id = '$stuid'";
                                                            $result = $conn4->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {


                                                                    if (strlen($o_institute) > 0) {
                                                                        $sno2++;
                                                                        echo "<tr><td>$sno2</td><td>OND</td><td>$o_institute</td><td>$o_yr_grad</td><td>$o_degree_class</td><td>$o_cgpa</td><td>$o_discipline</td></tr>";
                                                                    }
                                                                    if (strlen($h_institute) > 0) {
                                                                        $sno2++;
                                                                        echo "<tr><td>$sno2</td><td>HND</td><td>$h_institute</td><td>$h_yr_grad</td><td>$h_degree_class</td><td>$h_cgpa</td><td>$h_discipline</td></tr>";
                                                                    }
                                                                    if (strlen($p_institute) > 0) {
                                                                        $sno2++;
                                                                        echo "<tr><td>$sno2</td><td>PGD</td><td>$p_institute</td><td>$p_yr_grad</td><td>$p_degree_class</td><td>$p_cgpa</td><td>$p_discipline</td></tr>";
                                                                    }
                                                                    if (strlen($b_institute) > 0) {
                                                                        $sno2++;
                                                                        echo "<tr><td>$sno2</td><td>First Degree</td><td>$b_institute</td><td>$b_yr_grad</td><td>$b_degree_class</td><td>$b_cgpa</td><td>$b_discipline</td></tr>";
                                                                    }
                                                                    if (strlen($m_institute) > 0) {
                                                                        $sno2++;
                                                                        echo "<tr><td>$sno2</td><td>Masters Degree</td><td>$m_institute</td><td>$m_yr_grad</td><td>$m_degree_class</td><td>$m_cgpa</td><td>$m_discipline</td></tr>";
                                                                    }
                                                                }
                                                            }

                                                            ?>

                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                            <br><br>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">O'Level Results:</label>
                                                <div class="col-sm-8">
                                                    <table class="table stats-table">
                                                        <thead>
                                                            <tr>
                                                                <th>S/No</th>
                                                                <th>Subject</th>
                                                                <th>Grade</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody>

                                                            <?php
                                                            $sql = "SELECT * FROM pgapplication WHERE applicant_id = '$stuid'";
                                                            $result = $conn4->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {

                                                                    $sub1 = $row["sub1"];
                                                                    $sub2 = $row["sub2"];
                                                                    $sub3 = $row["sub3"];
                                                                    $sub4 = $row["sub4"];
                                                                    $sub5 = $row["sub5"];
                                                                    $sub6 = $row["sub6"];
                                                                    $sub7 = $row["sub7"];

                                                                    $grade1 = $row["grade1"];
                                                                    $grade2 = $row["grade2"];
                                                                    $grade3 = $row["grade3"];
                                                                    $grade4 = $row["grade4"];
                                                                    $grade5 = $row["grade5"];
                                                                    $grade6 = $row["grade6"];
                                                                    $grade7 = $row["grade7"];


                                                                    echo "<tr><td>1</td><td>$sub1</td><td>$grade1</td></tr>";
                                                                    echo "<tr><td>2</td><td>$sub2</td><td>$grade2</td></tr>";
                                                                    echo "<tr><td>3</td><td>$sub3</td><td>$grade3</td></tr>";
                                                                    echo "<tr><td>4</td><td>$sub4</td><td>$grade4</td></tr>";
                                                                    echo "<tr><td>5</td><td>$sub5</td><td>$grade5</td></tr>";
                                                                    echo "<tr><td>6</td><td>$sub6</td><td>$grade6</td></tr>";
                                                                    echo "<tr><td>7</td><td>$sub7</td><td>$grade7</td></tr>";
                                                                }
                                                            }

                                                            ?>

                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Next of Kin:</label>
                                                <div class="col-sm-8">

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"></label>
                                                <div class="col-sm-8">
                                                    <table class="table stats-table">

                                                        <tbody>
                                                            <tr>
                                                                <th>Name:</th>
                                                                <td><?php echo $next_name ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Relationship:</th>
                                                                <td><?php echo $next_rel ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Address:</th>
                                                                <td><?php echo $next_addr ?></td>
                                                            </tr>
                                                            <tr>
                                                                <th>Phone:</th>
                                                                <td><?php echo $next_phone ?></td>
                                                            </tr>

                                                        </tbody>
                                                    </table>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>


                        <?php } ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <?php
            include_once 'includes/footer2.php';
            ?>
        </div>

        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
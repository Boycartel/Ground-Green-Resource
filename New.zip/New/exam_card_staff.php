<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';


if ($_SESSION['pass_reset_admin'] == false && $_SESSION['apu_request'] == false && $_SESSION['acad_office_request'] == false) {
    header('Location: home_staff.php');
}
?>



<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


</head>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Exam Card</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_stu.php">Home</a>
                        </li>

                        <li class="active">
                            <strong>Exam Card</strong>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper wrapper-content animated fadeInUp">

                        <div class="ibox">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10 panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                                <div class="panel-heading">
                                    Exam Card

                                </div>
                                <div class="panel-body">
                                    <div>
                                        <form class="form-horizontal form-bordered" method="post" target="_blank"
                                            action="exam_card_pdf.php">
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label">Matric Number: </label>
                                                <div class="col-lg-5">
                                                    <input type="text" class="form-control" style="color:#000000"
                                                        name="regid">
                                                </div>
                                                <div class="col-lg-3">
                                                    <button type="submit" name="submit"
                                                        class="btn btn-primary">Submit</button>

                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
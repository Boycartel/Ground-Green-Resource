<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="inline_edit/jquery.min.js"></script>
    <script src="js/getexcel/tableToExcel_Staff.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    $user1 = $_SESSION['staffid'];
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>APU</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>

                            <li><span>APU</span></li>
                            <li><span>PG Students Record</span></li>
                            <li class="active">
                                <strong>By State of Origin</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            By State of Origin
                        </div>
                        <div class="panel-body">
                            <?php
                            //error_reporting(0);
                            if (isset($_POST["submit"])) {
                                if (!$_POST["getsession"]) {
                                    $getsession = $_SESSION["getsession"];
                                }
                            }
                            ?>
                            <div class="row">

                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="form-group">
                                        <label class="control-label col-lg-3" style="font-size: larger">Session</label>
                                        <div class="col-lg-4">
                                            <?php if (!isset($_POST["submit"])) { ?>
                                                <?php
                                                $iniyear = 2018;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>
                                            <?php } else { ?>
                                                <?php echo $_SESSION["getsession"] ?>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-5">


                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-lg-2">
                                        </div>
                                        <div class="col-lg-8">
                                            <?php
                                            $sql = "SELECT * FROM states ORDER BY state";
                                            $result = $conn5->query($sql);
                                            if ($result->num_rows > 0) {
                                            ?>
                                                <table class="table mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th>Select</th>
                                                            <th>State</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["sn"];
                                                            $state = $row["state"];
                                                            echo "<tr>
                                    <td><input type='checkbox' name='chosen1c[" . $id . "]' value='" . $id . "'/></td>
                                    <td>
                                    <label id='statetitle' name='statetitle[" . $id . "]'>$state</label>
                                    <input type='hidden' id='statetitle' name='statetitle[" . $id . "]' value='" . $state . "'/>
                                    </td>
                                    
                                    </tr>\n";
                                                        }
                                                        ?>

                                                    </tbody>
                                                </table>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-2">
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        <div class="col-lg-2">
                                        </div>
                                        <div class="col-lg-8" style="text-align: right">
                                            <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                        <div class="col-lg-2">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <hr class="separator" />
                            <div class="row">
                                <?php



                                ?>
                                <?php if (!empty($_POST["chosen1c"])) { ?>
                                    <?php
                                    set_time_limit(500);
                                    error_reporting(E_ERROR);

                                    $sql = "DELETE FROM state_select WHERE user1='$user1'";
                                    $result = $conn2->query($sql);
                                    foreach ($_POST["chosen1c"] as $key => $value) {

                                        $statecode = $_POST["statecode"][$key];
                                        $statetitle = $_POST["statetitle"][$key];

                                        $sql = "INSERT INTO state_select (state, user1) VALUES ('$statetitle', '$user1')";
                                        $result = $conn2->query($sql);
                                    }
                                    if ($_POST["getsession"]) {
                                        $getsession = $_POST["getsession"];
                                        $_SESSION["getsession"] = $getsession;
                                        $sql = "DELETE FROM dap_pg_dept WHERE user1='$user1'";
                                        $result = $conn2->query($sql);
                                    } else {
                                        $getsession = $_SESSION["getsession"];
                                    }

                                    $GetTitle = "Students Count by State of Origin(" . $getsession . ")";

                                    $totmale = $totfemale = $tottotal = $totPGDm = $totPGDf = $totMasterM = $totMasterF = $totPhDm = $totPhDf = 0;
                                    ?>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>State</th>
                                                    <th>Male</th>
                                                    <th>Female</th>
                                                    <th>Total</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $sql = "SELECT * FROM state_select WHERE user1='$user1' ORDER BY state";
                                                $result = $conn2->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $statetitle = $row["state"];
                                                        //$statetitle2 = strtoupper($row["state"]);
                                                        $male = $female = $total = 0;
                                                        $PGDm = $PGDf = $MasterM = $MasterF = $PhDm = $PhDf = 0;
                                                        $sql3 = "SELECT * FROM pgapplication WHERE stateoforigin = '$statetitle'";
                                                        $result3 = $conn4->query($sql3);
                                                        if ($result3->num_rows > 0) {
                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                $sex = $row3["sex"];
                                                                $dept = $row3["deptcode"];
                                                                $prog = strtoupper($row3["programme_title"]);
                                                                $matricno = $row3["regid"];
                                                                $matriclen = strlen($matricno);
                                                                if ($matriclen >= 10) {

                                                                    $getdept = strtolower($dept) . "_hod_list";
                                                                    $sql2 = "SELECT * FROM " . $getdept . " WHERE Session1 = '$getsession' AND matricno = '$matricno'";
                                                                    $result2 = $conn5->query($sql2);
                                                                    if ($result2->num_rows > 0) {
                                                                        while ($row2 = $result2->fetch_assoc()) {

                                                                            if ($sex == "M") {
                                                                                $male++;
                                                                                $totmale++;
                                                                                if ($prog == "PH.D" || $prog == "PhD") {
                                                                                    $PhDm++;
                                                                                    $totPhDm++;
                                                                                } elseif ($prog == "PGD") {
                                                                                    $PGDm++;
                                                                                    $totPGDm++;
                                                                                } else {
                                                                                    $MasterM++;
                                                                                    $totMasterM++;
                                                                                }
                                                                            } elseif ($sex == "F") {
                                                                                $female++;
                                                                                $totfemale++;
                                                                                if ($prog == "PH.D" || $prog == "PhD") {
                                                                                    $PhDf++;
                                                                                    $totPhDf++;
                                                                                } elseif ($prog == "PGD") {
                                                                                    $PGDf++;
                                                                                    $totPGDf++;
                                                                                } else {
                                                                                    $MasterF++;
                                                                                    $totMasterF++;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }


                                                        $total = $male + $female;
                                                        if ($total > 0) {

                                                            $sql3 = "SELECT * FROM dap_pg_dept WHERE deptcode = '$statetitle' AND user1='$user1'";
                                                            $result3 = $conn2->query($sql3);
                                                            if ($result3->num_rows == 0) {
                                                                $sql2 = "INSERT INTO dap_pg_dept (depttitle, nomale, nofemale, noPGDm, noPGDf, noMastersm, noMastersf, noPhDm, noPhDf, total, user1) VALUES ('$statetitle', '$male', '$female', '$PGDm', '$PGDf', '$MasterM', '$MasterF', '$PhDm', '$PhDf', '$total', '$user1')";
                                                                $result2 = $conn2->query($sql2);
                                                            }
                                                        }
                                                    }
                                                }
                                                $sql3 = "SELECT * FROM dap_pg_dept WHERE user1='$user1' ORDER BY depttitle";
                                                $result3 = $conn2->query($sql3);
                                                if ($result3->num_rows > 0) {
                                                    while ($row3 = $result3->fetch_assoc()) {
                                                        $sno++;
                                                        //$DeptCode = $row3["deptcode"];
                                                        $statetitle = $row3["depttitle"];
                                                        $male = $row3["nomale"];
                                                        $female = $row3["nofemale"];
                                                        $total = $row3["total"];
                                                        echo "<tr><td>$sno</td><td>$statetitle</td><td>$male</td><td>$female</td>";
                                                        echo "<td>$total</td></tr>\n";
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>

                                <?php } ?>
                                <div class="form-group">
                                    <div class="col-lg-2">
                                    </div>
                                    <div class="col-lg-8" style="text-align: right">
                                        <?php if (!empty($_POST["chosen1c"])) { ?>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <button type="submit" name="conclude" class="btn btn-primary btn-sm">Conclude</button>
                                            </form>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-2">
                                    </div>
                                </div>
                                <?php if (isset($_POST["conclude"])) { ?>
                                    <?php
                                    $getsession = $_SESSION["getsession"];
                                    $GetTitle = "Students Count by State of Origin(" . $getsession . ")";
                                    ?>
                                    <h2 class="panel-title"><?php echo $GetTitle ?></h2>
                                    <?php
                                    $totmale = $totfemale = $tottotal = 0;
                                    $totmale = $totfemale = $tottotal = $totPGDm = $totPGDf = $totMasterM = $totMasterF = $totPhDm = $totPhDf = 0;
                                    ?>
                                    <div class="col-lg-12" style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">

                                        <table id="myTable" class="table table-bordered mb-none" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Department</th>
                                                    <th>Male</th>
                                                    <th>Female</th>
                                                    <th>PGD(M)</th>
                                                    <th>PGD(F)</th>
                                                    <th>Masters(M)</th>
                                                    <th>Masters(F)</th>
                                                    <th>Ph.D(M)</th>
                                                    <th>Ph.D(F)</th>
                                                    <th>Total</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $sno = 0;
                                                $male = $female = $total = 0;
                                                $PGDm = $PGDf = $MasterM = $MasterF = $PhDm = $PhDf = 0;
                                                $sql = "SELECT * FROM dap_pg_dept WHERE user1='$user1' ORDER BY depttitle";
                                                $result = $conn2->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $statetitle = $row["depttitle"];
                                                        $male = $row["nomale"];
                                                        $female = $row["nofemale"];
                                                        $PGDm = $row["noPGDm"];
                                                        $PGDf = $row["noPGDf"];
                                                        $MasterM = $row["noMastersm"];
                                                        $MasterF = $row["noMastersf"];
                                                        $PhDm = $row["noPhDm"];
                                                        $PhDf = $row["noPhDf"];

                                                        $total = $row["total"];
                                                        $totmale = $totmale + $male;
                                                        $totfemale = $totfemale + $female;
                                                        $totPGDm = $totPGDm + $PGDm;
                                                        $totPGDf = $totPGDf + $PGDf;
                                                        $totMasterM = $totMasterM + $MasterM;
                                                        $totMasterF = $totMasterF + $MasterF;
                                                        $totPhDm = $totPhDm + $PhDm;
                                                        $totPhDf = $totPhDf + $PhDf;

                                                        $sno++;
                                                        echo "<tr><td>$sno</td><td>$statetitle</td><td>$male</td><td>$female</td><td>$PGDm</td><td>$PGDf</td>";
                                                        echo "<td>$MasterM</td><td>$MasterF</td><td>$PhDm</td><td>$PhDf</td>";
                                                        echo "<td>$total</td><td>
                                                <form action='dap_stu_list.php' method='post'>
                                                    <input type='hidden' value='$statetitle' name='id2'>
                                                    <input type='hidden' value='yesstate' name='deptstate'>
                                                    <input type='hidden' value='$getsession' name='mysession'>
                                                    <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
                                                </form>
                                                </td>
                                                    
                                                </tr>\n";
                                                    }
                                                }
                                                $tottotal = $totmale + $totfemale;
                                                echo "<tr><th></th><th>Total</th><th>$totmale</th><th>$totfemale</th><th>$totPGDm</th><th>$totPGDf</th>";
                                                echo "<th>$totMasterM</th><th>$totMasterF</th><th>$totPhDm</th><th>$totPhDf</th>";
                                                echo "<th>$tottotal</th><th></th><th></th>
                                                            
                                           </tr>\n";
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <br><br>
                                    <div style="text-align: right">
                                        <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary btn-sm">Download</a>
                                    </div>

                                    <?php
                                    $sql = "DELETE FROM dap_pg_dept WHERE user1='$user1'";
                                    $result = $conn2->query($sql);
                                    ?>
                                <?php } ?>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

</body>

</html>
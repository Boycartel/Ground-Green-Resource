<?php

require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['Administrator'] !== "YES" && $_SESSION['Sub_Admin'] !== "YES") {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Create New Curriculum</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Settings
                            </li>

                            <li class="active">
                                <strong>Create New Curriculum</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Create New Curriculum
                        </div>
                        <div class="panel-body">
                            <?php
                            $success = "";
                            $GetTheSession = $_SESSION['resultsession'];
                            $deptoption = $_SESSION['deptoption'];
                            if (isset($_POST["addnew"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $optcode = strtoupper($_POST["curricode"]);
                                $opttitle = mysqli_real_escape_string($conn, $_POST["currititle"]);
                                //$opttitle = $_POST["currititle"];
                                if ($_SESSION['InstType'] == "Polytechnic") {
                                    $prog = $_POST["curriprog"];
                                } else {
                                    $prog = "XX";
                                }
                                $dept = strtoupper($_SESSION["deptAddCurri"]);
                                $countex = 0;

                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }


                                $sql = "SELECT * FROM dept_curriculum WHERE curri_Code = '$optcode' AND deptcode = '$dept' AND prog = '$prog'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    $countex++;
                                }

                                if ($countex == 0) {
                                    $sql = "UPDATE deptcoding SET curriculum = 'YES' WHERE DeptCode = '$dept'";
                                    $result = $conn->query($sql);

                                    $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept' AND curri_Code = '$optcode' AND prog = '$prog'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows == 0) {
                                        $sql2 = "INSERT INTO dept_curriculum(curri_Code, curri_Title, deptcode, prog) VALUES ('$optcode','$opttitle','$dept', '$prog')";
                                        $result2 = $conn->query($sql2);
                                    }
                                    $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept' AND curri_Code = 'OLD' AND prog = '$prog'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows == 0) {
                                        $sql2 = "INSERT INTO dept_curriculum(curri_Code, curri_Title, deptcode, prog) VALUES ('OLD','Old Curriculum','$dept', '$prog')";
                                        $result2 = $conn->query($sql2);
                                    }

                                    $dept2 = $_SESSION["deptAddCurri"];

                                    if ($_SESSION['InstType'] == "University") {
                                        $sql = "SELECT * FROM requirement_tab WHERE DeptCode = '$dept' AND curri_Code = 'OLD'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $Requirement_Code = $row["Requirement_Code"];
                                                $Requirement_Name = $row["Requirement_Name"];
                                                $Requirement_100 = $row["Requirement_100"];
                                                $Requirement_DE200 = $row["Requirement_DE200"];
                                                $Requirement_DE300 = $row["Requirement_DE300"];
                                                $sql2 = "SELECT * FROM requirement_tab WHERE DeptCode = '$dept' AND curri_Code = '$optcode' AND Requirement_Code = '$Requirement_Code'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows == 0) {

                                                    $sql3 = "INSERT INTO requirement_tab(Requirement_Code, Requirement_Name, Requirement_100, Requirement_DE200, Requirement_DE300, DeptCode, curri_Code) VALUES ('$Requirement_Code','$Requirement_Name','$Requirement_100','$Requirement_DE200','$Requirement_DE300','$dept','$optcode')";
                                                    $result3 = $conn->query($sql3);
                                                }
                                            }
                                        }
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        $sql = "SELECT * FROM requirement_tab_poly WHERE DeptCode = '$dept' AND curri_Code = 'OLD' AND prog = '$prog'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $Requirement_Code = $row["Requirement_Code"];
                                                $Requirement_Name = $row["Requirement_Name"];
                                                $Requirement_100 = $row["Requirement_100"];
                                                $prog = $row["prog"];
                                                $sql2 = "SELECT * FROM requirement_tab_poly WHERE DeptCode = '$dept' AND curri_Code = '$optcode' AND Requirement_Code = '$Requirement_Code' AND prog = '$prog'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows == 0) {

                                                    $sql3 = "INSERT INTO requirement_tab_poly(Requirement_Code, Requirement_Name, Requirement_100, prog, DeptCode, curri_Code) VALUES ('$Requirement_Code','$Requirement_Name','$Requirement_100','$prog','$dept','$optcode')";
                                                    $result3 = $conn->query($sql3);
                                                }
                                            }
                                        }
                                    }


                                    $sql = "select 1 from gencourses_" . $optcode;
                                    $exists = $conn_stu->query($sql);

                                    if ($exists == FALSE) {
                                        $TabCreate = "gencourses_" . $optcode;
                                        $sql = "CREATE TABLE " . $TabCreate . " SELECT * FROM gencourses";
                                        $result = $conn_stu->query($sql);
                                    }

                                    $newCode = "gencourses_" . $optcode;
                                    $sql = "ALTER TABLE " . $newCode . " DROP id";
                                    $result = $conn_stu->query($sql);

                                    $sql = "ALTER TABLE " . $newCode . " ADD id INT NOT NULL AUTO_INCREMENT primary key";
                                    $result = $conn_stu->query($sql);

                                    if ($deptoption == "YES") {

                                        $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $optcodeG = "Grouping" . $row["Opt_Code"];

                                                $sql2 = "UPDATE " . $newCode . " SET " . $optcodeG . " = 'NO'";
                                                $result2 = $conn_stu->query($sql2);
                                            }
                                        }
                                    } else {
                                        $sql = "UPDATE " . $newCode . " SET Grouping = 'NO'";
                                        $result = $conn_stu->query($sql);
                                    }

                                    //$success = "Record Saved Successfully";
                                    echo '<script type="text/javascript">';
                                    echo 'window.location.href = "includes/logout.php"';
                                    echo '</script>';
                                }
                                $conn->close();
                                $conn_stu->close();
                            }

                            if (isset($_POST['deletesingle'])) {
                                $id = $_POST['delete_id'];

                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                $sql = "SELECT * FROM dept_curriculum WHERE id = '$id'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $optcode = $row["curri_Code"];
                                        $prog = $row["prog"];
                                    }
                                }

                                $dept = strtoupper($_SESSION["deptAddCurri"]);
                                $dept2 = $_SESSION["deptAddCurri"];

                                $dept_db = $_SESSION['deptdb'] . strtolower($dept2);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                $sql = "select 1 from gencourses_" . $optcode;
                                $exists = $conn_stu->query($sql);

                                if ($exists == TRUE) {
                                    $TabCreate = "gencourses_" . $optcode;
                                    $sql = "DROP TABLE " . $TabCreate;
                                    $result = $conn_stu->query($sql);
                                }



                                $sql = "DELETE FROM dept_curriculum WHERE id='$id'";
                                $result = $conn->query($sql);
                                if ($_SESSION['InstType'] == "University") {
                                    $sql = "DELETE FROM requirement_tab WHERE curri_Code='$optcode' AND DeptCode='$dept'";
                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                    $sql = "DELETE FROM requirement_tab_poly WHERE curri_Code='$optcode' AND DeptCode='$dept' AND prog='$prog'";
                                }

                                $result = $conn->query($sql);

                                $sql = "UPDATE deptcoding SET curriculum='NO' WHERE DeptCode = '$dept2'";
                                $result = $conn->query($sql);

                                if ($_SESSION['InstType'] == "University") {
                                    $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept'";
                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                    $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept' AND prog='$prog'";
                                }
                                $result = $conn->query($sql);
                                $countCur = 0;
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $countCur++;
                                    }
                                }

                                if ($countCur < 2) {
                                    if ($_SESSION['InstType'] == "University") {
                                        $sql = "DELETE FROM dept_curriculum WHERE DeptCode='$dept'";
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        $sql = "DELETE FROM dept_curriculum WHERE DeptCode='$dept' AND prog='$prog'";
                                    }

                                    $result = $conn->query($sql);

                                    $sql = "UPDATE `deptcoding` SET curriculum = 'NO' WHERE DeptCode = '$dept'";
                                    $result = $conn->query($sql);
                                }

                                $sql = "DELETE FROM grouping_couses WHERE curriculum ='$optcode' AND DeptCode='$dept'";
                                $result = $conn->query($sql);

                                //$success = "Record Deleted Successfully";
                                echo '<script type="text/javascript">';
                                echo 'window.location.href = "includes/logout.php"';
                                echo '</script>';
                                $conn->close();
                                $conn_stu->close();
                            }

                            if (isset($_POST['updatesingle'])) {
                                $id = $_POST['update_id'];
                                $opttitle = $_POST['currititle'];

                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $sql = "UPDATE dept_curriculum SET curri_Title='$opttitle' WHERE id = '$id'";
                                $result = $conn->query($sql);
                                $conn->close();
                                $success = "Record Updated Successfully";
                            }

                            ?>
                            <div class="row">

                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="row">

                                        <div class="col-lg-4">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="content">Select
                                                    Department:</label>
                                                <div class="col-lg-7">
                                                    <select class="country form-control" style="color:#000000" name="dept">
                                                        <option value="SelectItem">Select Item</option>
                                                        <?php
                                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                        if ($conn->connect_error) {
                                                            die("Connection failed: " . $conn->connect_error);
                                                        }
                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $deptcode2 = strtolower($row["DeptCode"]);
                                                                $deptname2 = $row["DeptName"];
                                                                echo "<option value=$deptcode2>$deptname2</option>";
                                                            }
                                                        }
                                                        $conn->close();
                                                        ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="row">

                                                <div class="col-lg-4">
                                                    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </form>

                                <?php if (isset($_POST["submit"]) || isset($_POST["addnew"]) || isset($_POST["deletesingle"]) || isset($_POST["updatesingle"])) { ?>
                                    <?php
                                    if (isset($_POST["submit"])) {
                                        $dept = $_POST["dept"];
                                        $_SESSION["deptAddCurri"] = $dept;
                                        $dept = $_POST["dept"];
                                        $_SESSION["deptAddCurri"] = $dept;
                                    } else {
                                        $dept = $_SESSION["deptAddCurri"];
                                    }

                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $deptname = $row["DeptName"];
                                        }
                                    }
                                    ?>

                                    <br>
                                    <br>
                                    <div class="row">
                                        <div class="col-lg-1">

                                        </div>
                                        <div class="col-lg-10">
                                            <h2 style="color: blue"><?php echo $success ?></h2>
                                            <h2 style="text-align: center"><?php echo $deptname ?> Department</h2>

                                            <div style="text-align: right; padding-right:2em">
                                                <a href="#addEmployeeModal" class="btn btn-success btn-xs" data-toggle="modal"><span>Add
                                                        New</span></a>
                                                <!--<a href="#deleteEmployeeModal" class="btn btn-danger btn-xs" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>-->
                                            </div>
                                            <br>
                                            <table class="table table-bordered table-striped mb-none" id="datatable-default">
                                                <thead>
                                                    <tr>
                                                        <th>
                                                            <span class="custom-checkbox">
                                                                <input type="checkbox" id="selectAll">
                                                                <label for="selectAll"></label>
                                                            </span>
                                                        </th>
                                                        <th hidden="hidden">ID</th>
                                                        <th style='text-align:center'>Curriculum Code</th>
                                                        <th style='text-align:center'>Curriculum Title</th>
                                                        <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                            <th style='text-align:center'>Programme</th>
                                                        <?php } ?>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php
                                                    //$dept=$_POST["dept"];
                                                    $sno = 0;
                                                    $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept' ORDER BY curri_Title";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $Opt_Code = $row["curri_Code"];
                                                            $Opt_Title = $row["curri_Title"];
                                                            $id = $row["id"];
                                                            $prog = $row["prog"];
                                                    ?>
                                                            <tr>
                                                                <td>
                                                                    <span class="custom-checkbox">
                                                                        <input type="checkbox" id="checkbox1" name="options[]" value="1">
                                                                        <label for="checkbox1"></label>
                                                                    </span>
                                                                </td>
                                                                <td hidden="hidden"><?php echo $id; ?></td>
                                                                <td><?php echo $Opt_Code; ?></td>
                                                                <td><?php echo $Opt_Title; ?></td>
                                                                <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                                    <td><?php echo $prog; ?></td>
                                                                <?php } ?>

                                                                <td>
                                                                    <?php if ($Opt_Code != "OLD") { ?>
                                                                        <button type="button" class='btn btn-default btn-xs editone'><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></button>
                                                                        <button type="button" class='btn btn-default btn-xs deleteone'><i class="material-icons" data-toggle="tooltip" title="Delete" style="color: red">&#xE872;</i></button>
                                                                    <?php } ?>
                                                                </td>

                                                            </tr>

                                                    <?php
                                                        }
                                                    }

                                                    ?>


                                                </tbody>
                                            </table>

                                        </div>
                                        <div class="col-lg-1">

                                        </div>
                                    </div>
                                    <?php
                                    $conn->close();
                                    ?>

                                <?php } ?>


                                <!-- Add New Modal HTML -->
                                <div id="addEmployeeModal" class="modal fade">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="post" action="">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Add New Curriculum</h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label>Curriculum Code</label>
                                                        <select name="curricode" class="form-control" style="color:#000000">
                                                            <option value="CUR01">CUR01</option>
                                                            <option value="CUR02">CUR02</option>
                                                            <option value="CUR03">CUR03</option>
                                                            <option value="CUR04">CUR04</option>
                                                            <option value="CUR05">CUR05</option>
                                                            <option value="CUR06">CUR06</option>
                                                            <option value="CUR07">CUR07</option>
                                                            <option value="CUR08">CUR08</option>
                                                            <option value="CUR09">CUR09</option>
                                                            <option value="CUR10">CUR10</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Curriculum Title</label>
                                                        <input type="text" class="form-control" name="currititle" placeholder="Curriculum Title..." required>

                                                    </div>
                                                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                        <div class="form-group">
                                                            <label>Programme: </label>
                                                            <select name="curriprog" class="form-control" style="color:#000000" required>
                                                                <option value="">Select Item</option>
                                                                <option value="ND">ND</option>
                                                                <option value="HND">HND</option>

                                                            </select>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                    <input type="submit" class="btn btn-success" name="addnew" value="Save">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>


                                <!-- Edit Modal HTML -->
                                <div id="editModal" class="modal fade">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="" method="POST">
                                                <input type="hidden" name="update_id" id="update_id">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Edit Record</h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label>Curriculum Code</label>

                                                        <select name="curricode" id="curricode" class=" form-control" disabled="disabled" style="color:#000000">
                                                            <option value="CUR01">CUR01</option>
                                                            <option value="CUR02">CUR02</option>
                                                            <option value="CUR03">CUR03</option>
                                                            <option value="CUR04">CUR04</option>
                                                            <option value="CUR05">CUR05</option>
                                                            <option value="CUR06">CUR06</option>
                                                            <option value="CUR07">CUR07</option>
                                                            <option value="CUR08">CUR08</option>
                                                            <option value="CUR09">CUR09</option>
                                                            <option value="CUR10">CUR10</option>
                                                        </select>
                                                    </div>
                                                    <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                        <div class="form-group">
                                                            <label>Programme: </label>
                                                            <select name="curriprog" id="curriprog" class="form-control" style="color:#000000" required>
                                                                <option value="">Select Item</option>
                                                                <option value="ND">ND</option>
                                                                <option value="HND">HND</option>

                                                            </select>
                                                        </div>
                                                    <?php } ?>
                                                    <div class="form-group">
                                                        <label>Curriculum Title</label>
                                                        <input type="text" name="currititle" id="currititle" class="form-control" placeholder="Enter Option Code">
                                                    </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                    <input type="submit" name="updatesingle" class="btn btn-info" value="Save">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Delete Modal HTML -->
                                <div id="deleteModal" class="modal fade">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="" method="POST">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Delete Curriculum</h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="hidden" name="delete_id" id="delete_id">
                                                    <p>Are you sure you want to delete these Records?</p>

                                                    <p class="text-warning"><small>This action cannot be undone.</small>
                                                    </p>
                                                </div>
                                                <div class="modal-footer">
                                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                                                    <input type="submit" name="deletesingle" class="btn btn-danger" value="Delete">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>


                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <script>
        $(document).ready(function() {
            // Activate tooltip
            $('[data-toggle="tooltip"]').tooltip();

            // Select/Deselect checkboxes
            var checkbox = $('table tbody input[type="checkbox"]');
            $("#selectAll").click(function() {
                if (this.checked) {
                    checkbox.each(function() {
                        this.checked = true;
                    });
                } else {
                    checkbox.each(function() {
                        this.checked = false;
                    });
                }
            });
            checkbox.click(function() {
                if (!this.checked) {
                    $("#selectAll").prop("checked", false);
                }
            });
        });
    </script>

    <script>
        $(document).ready(function() {

            $('.deleteone').on('click', function() {

                $('#deleteModal').modal('show');

                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function() {
                    return $(this).text();
                }).get();

                console.log(data);

                $('#delete_id').val(data[1]);

            });
        });
    </script>

    <script>
        $(document).ready(function() {

            $('.editone').on('click', function() {

                $('#editModal').modal('show');

                $tr = $(this).closest('tr');

                var data = $tr.children("td").map(function() {
                    return $(this).text();
                }).get();

                console.log(data);

                $('#update_id').val(data[1]);
                $('#curricode').val(data[2]);
                $('#currititle').val(data[3]);
                $('#curriprog').val(data[4]);

            });
        });
    </script>


</body>

</html>
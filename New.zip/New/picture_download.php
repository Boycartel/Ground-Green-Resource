<?php

require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['stu_biodata_grad'] == false) {
	header('Location: Home_Staff.php');
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Untitled Document</title>
</head>

<body>
	<?php
	//$files =array("https://eportal.futminna.edu.ng/img/Spain.png", "https://eportal.futminna.edu.ng/img/user.jpg", "https://eportal.futminna.edu.ng/img/india.png", "https://eportal.futminna.edu.ng/img/futlogo.png");// array of files
	$dept = $_SESSION['dept'];
	$session1 = $_SESSION['session1'];
	$files = array();
	//$conn = new mysqli($_SESSION['localhost'], $_SESSION['root'], $_SESSION['passwroot'], $_SESSION['databasename']);
	//// Check connection
	//if ($conn->connect_error) {
	//	die("Connection failed: " . $conn->connect_error);
	//} 
	$sql = "SELECT * FROM graduated WHERE Deptcode = '$dept' AND yeargrad = '$session1' ORDER BY regid";
	$result = $conn2->query($sql);
	$sn = 0;
	if ($result->num_rows > 0) {
		// output data of each row
		while ($row = $result->fetch_assoc()) {
			$stureg = substr($row["regid"], -7);
			$files[$sn] = "grad_stu_pp/" . $stureg . ".jpg";
			$sn++;
		}
	}

	//$sql = "SELECT * FROM aatest";
	//$result = $conn->query($sql);
	//$sn=0;
	//if ($result->num_rows > 0) {
	//	// output data of each row
	//	while($row = $result->fetch_assoc()) {
	//		$stureg=substr($row["stureg"],-7);
	//		$files[$sn] = "grad_stu_pp/".$stureg.".jpg"; 
	//		$sn++;
	//	}
	//}
	//$conn->close();


	$zip = new ZipArchive(); //Create an object of ZipArchive class

	$zipname = $dept . ".zip"; // give zip file name 

	//$zipname=$dept;// give zip file name 
	$zip->open("zipfiles/" . $zipname, ZipArchive::CREATE); //example_zip zip file created 

	foreach ($files as $key => $file) {
		$zip->addFile($file); //add each file into example_zip zip file
	}

	$zip->close(); // zip file with files created successful now close it

	//Download Zip File
	//header('Content-Type: application/zip');
	//  header('Content-disposition: attachment; filename='.$zipname);
	//  header('Content-Length: ' . filesize($zipname));
	//  readfile($zipname);


	?>
	<center>
		<h1><a href="<?php echo "zipfiles/" . $zipname ?>" id="downloadpic" class="btn btn-primary">Click to Download <?php echo $zipname ?></a></h1>
	</center>
	<br /><br /><br /><br />
	<center>
		<h1><a href="home_staff.php" id="" class="btn btn-primary">Click to Return Home</a></h1>
	</center>
</body>

</html>
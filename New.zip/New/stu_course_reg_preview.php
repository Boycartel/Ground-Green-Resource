<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

include_once 'includes/get_stu_level.php';

?>



<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <!--
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
-->

</head>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-4">
                    <h2>Course Registration</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_stu.php">Home</a>
                        </li>
                        <li>
                            Course Registration
                        </li>

                        <li class="active">
                            <strong>Course Reg Preview</strong>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper wrapper-content animated fadeInUp">

                        <div class="ibox">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10 panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                                <div class="panel-heading">
                                    Course Reg Preview (Current Level:- <?php echo $level ?>)

                                </div>
                                <div class="panel-body">
                                    <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                    ?>
                                    <form class="form-horizontal" role="form" method="post" action="stu_course_reg_subt.php">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Status</th>

                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                $dept = $_SESSION['deptcode'];
                                                $minCredit = $_SESSION['minCredit'];
                                                $MaxCredit = $_SESSION['MaxCredit'];

                                                $minCreditNew = $_SESSION['minCreditNew'];
                                                $MaxCreditNew = $_SESSION['MaxCreditNew'];




                                                $ccode2c = $CTitle2c = $CUnit2c = $SemTaken2c = $Nature2c = "";
                                                $ccode1c = $CTitle1c = $CUnit1c = $SemTaken1c = $Nature1c = "";
                                                $ccode = $CTitle = $CUnit = $SemTaken = $Nature = "";
                                                $stopit = "No";
                                                $countrepcourse = 0;
                                                $get4lcourse = "";

                                                $regid = $_SESSION["regid"];
                                                $engrrep100level = $_SESSION['engrrep100level'];



                                                $sum1st = $sum2nd = 0;
                                                $TCP400 = $SIW400 = $SWP400 = "";
                                                $countsiwtp1 = $countsiwtp2 = 0;


                                                /* if (!empty($_POST["chosen"])) {
                                                    foreach ($_POST["chosen"] as $key => $value) {

                                                        $ccode = $_POST["ccode1"][$key];
                                                        if ($ccode == "SIW400") {
                                                            $countsiwtp1++;
                                                            $SIW400 = "SIW400";
                                                        }
                                                        if ($ccode == "SWP400") {
                                                            $countsiwtp1++;
                                                            $SWP400 = "SWP400";
                                                        }
                                                        if ($ccode == "TCP400") {
                                                            $countsiwtp1++;
                                                            $TCP400 = "TCP400";
                                                        }
                                                    }
                                                }


                                                if (!empty($_POST["chosenadd"])) {
                                                    foreach ($_POST["chosenadd"] as $key => $value) {

                                                        $ccode = $_POST["ccode1"][$key];
                                                        if ($ccode == "SIW400") {
                                                            $countsiwtp1++;
                                                            $SIW400 = "SIW400";
                                                        }
                                                        if ($ccode == "SWP400") {
                                                            $countsiwtp1++;
                                                            $SWP400 = "SWP400";
                                                        }
                                                        if ($ccode == "TCP400") {
                                                            $countsiwtp1++;
                                                            $TCP400 = "TCP400";
                                                        }
                                                    }
                                                }
                                                //										


                                                if (!empty($_POST["chosen2"])) {
                                                    foreach ($_POST["chosen2"] as $key => $value) {

                                                        $ccode = $_POST["ccode2"][$key];
                                                        if ($ccode == "SIW400") {
                                                            $countsiwtp2++;
                                                            $SIW400 = "SIW400";
                                                        }
                                                        if ($ccode == "SWP400") {
                                                            $countsiwtp2++;
                                                            $SWP400 = "SWP400";
                                                        }
                                                        if ($ccode == "TCP400") {
                                                            $countsiwtp2++;
                                                            $TCP400 = "TCP400";
                                                        }
                                                    }
                                                }


                                                if (!empty($_POST["chosenadd2"])) {
                                                    foreach ($_POST["chosenadd2"] as $key => $value) {

                                                        $ccode = $_POST["ccode2"][$key];
                                                        if ($ccode == "SIW400") {
                                                            $countsiwtp2++;
                                                            $SIW400 = "SIW400";
                                                        }
                                                        if ($ccode == "SWP400") {
                                                            $countsiwtp2++;
                                                            $SWP400 = "SWP400";
                                                        }
                                                        if ($ccode == "TCP400") {
                                                            $countsiwtp2++;
                                                            $TCP400 = "TCP400";
                                                        }
                                                    }
                                                } */
                                                //	
                                                unset($CCodeArry);
                                                unset($CUnitArry);
                                                unset($CTitleArry);
                                                unset($SemTakenArry);
                                                unset($NatureArry);

                                                $CCodeArry[] = "";
                                                $CUnitArry[] = 0;
                                                $CTitleArry[] = "";
                                                $SemTakenArry[] = "";
                                                $NatureArry[] = "";
                                                $countCC = 0;
                                                if (!empty($_POST["chosen1c"])) {
                                                    foreach ($_POST["chosen1c"] as $key => $value) {

                                                        //echo $_POST["chosen"][$key];

                                                        $ccode1c = $_POST["ccodec1"][$key];
                                                        $CTitle1c = str_replace("'", "''", $_POST["CTitlec1"][$key]);
                                                        $CUnit1c = $_POST["CUnitc1"][$key];
                                                        $SemTaken1c = $_POST["SemTakenc1"][$key];
                                                        $Nature1c = $_POST["Naturec1"][$key];


                                                        //if ($countsiwtp1 == 0) {
                                                        $sum1st += $CUnit1c;
                                                        echo "<tr><td>$ccode1c</td><td>$CTitle1c</td><td>$CUnit1c</td><td>$SemTaken1c</td><td>$Nature1c</td></tr>\n";

                                                        //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode1c', '$CUnit1c', '$CTitle1c', '$SemTaken1c', '$Nature1c')";
                                                        //$result = $conn_stu->query($sql);
                                                        $countCC++;
                                                        $CCodeArry[$countCC] = $ccode1c;
                                                        $CUnitArry[$countCC] = $CUnit1c;
                                                        $CTitleArry[$countCC] = $CTitle1c;
                                                        $SemTakenArry[$countCC] = $SemTaken1c;
                                                        $NatureArry[$countCC] = $Nature1c;
                                                        //}
                                                    }
                                                }

                                                //$array = $_POST["chosen"];
                                                if (!empty($_POST["chosen"])) {
                                                    foreach ($_POST["chosen"] as $key => $value) {

                                                        $ccode = $_POST["ccode1"][$key];
                                                        $CTitle = str_replace("'", "''", $_POST["CTitle1"][$key]);
                                                        $CUnit = $_POST["CUnit1"][$key];
                                                        $SemTaken = $_POST["SemTaken1"][$key];
                                                        $Nature = $_POST["Nature1"][$key];

                                                        //$sum1st += $CUnit;
                                                        $sum1st += $CUnit;
                                                        echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td></tr>\n";
                                                        //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature')";
                                                        $countCC++;
                                                        $CCodeArry[$countCC] = $ccode;
                                                        $CUnitArry[$countCC] = $CUnit;
                                                        $CTitleArry[$countCC] = $CTitle;
                                                        $SemTakenArry[$countCC] = $SemTaken;
                                                        $NatureArry[$countCC] = $Nature;
                                                        //$result = $conn_stu->query($sql);
                                                    }
                                                }



                                                if (!empty($_POST["chosenadd"])) {
                                                    foreach ($_POST["chosenadd"] as $key => $value) {

                                                        $ccode = $_POST["ccode1"][$key];
                                                        $CTitle = str_replace("'", "''", $_POST["CTitle1"][$key]);
                                                        $CUnit = $_POST["CUnit1"][$key];
                                                        $SemTaken = $_POST["SemTaken1"][$key];
                                                        $Nature = $_POST["Nature1"][$key];


                                                        $sum1st += $CUnit;
                                                        echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td></tr>\n";
                                                        //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature')";
                                                        $countCC++;
                                                        $CCodeArry[$countCC] = $ccode;
                                                        $CUnitArry[$countCC] = $CUnit;
                                                        $CTitleArry[$countCC] = $CTitle;
                                                        $SemTakenArry[$countCC] = $SemTaken;
                                                        $NatureArry[$countCC] = $Nature;
                                                        //$result = $conn_stu->query($sql);
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <br>
                                        <?php

                                        echo "<center> Total Credit Units : $sum1st</center>";
                                        ?>

                                        <?php
                                        if ($_SESSION['InstType'] == "University") {
                                            /* if ($level == "100" || $level == "200" || $level == "300") {

                                                if ($engrrep100level == "YES" && $level == "200") {
                                                    if ($sum1st < 8) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of 8 Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } else {
                                                    if ($level == "100") {
                                                        if ($sum1st < $minCreditNew) {
                                                            echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    } else {
                                                        if ($sum1st < $minCredit) {
                                                            echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    }
                                                }
                                                if ($level == "100") {
                                                    if ($sum1st > $MaxCreditNew) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } else {
                                                    if ($sum1st > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                }
                                            }
                                            if ($level == "400") {
                                                if ($countrepcourse <> 0) {
                                                    if ($sum1st > $MaxCredit) {

                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                    if ($sum1st < $minCredit) {
                                                        if ($countsiwtp1 == 0) {
                                                            echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    }
                                                } else {
                                                    if ($sum1st > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                }
                                            }

                                            if ($level == "500") {
                                                if ($sum1st < $minCredit) {
                                                    echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                    $stopit = "Yes";
                                                }
                                                if ($sum1st > 26) {
                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of 26 Unit per semester</center></strong>";
                                                    $stopit = "Yes";
                                                }
                                            } */




                                            if ($level == "600") {
                                                if ($sum1st > $MaxCredit) {
                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                    $stopit = "Yes";
                                                }
                                            } else {
                                                if ($level == "100") {
                                                    if ($sum1st < $minCreditNew) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCreditNew Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                    if ($sum1st > $MaxCreditNew) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCreditNew Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } else {
                                                    if ($sum1st < $minCredit) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                    if ($sum1st > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                }
                                            }
                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                            if ($modeofentry == "ND") {
                                                if ($level == "100" || $level == "200") {

                                                    if ($sum1st < $minCredit) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                    if ($level == "200") {
                                                        $MaxCredit2 = $MaxCredit + 4;
                                                        if ($sum1st > $MaxCredit2) {
                                                            echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit2 Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    } else {
                                                        if ($sum1st > $MaxCredit) {
                                                            echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    }
                                                } else if ($level == "600") {
                                                    if ($sum1st > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                }
                                            } else {
                                                if ($level == "300" || $level == "400") {

                                                    if ($sum1st < $minCredit) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }

                                                    if ($sum1st > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } else if ($level == "600") {
                                                    if ($sum1st > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                }
                                            }
                                        }




                                        ?>
                                        <br /><br>

                                        <!-- Second Semester -->
                                        <?php
                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $siwes = $row["siwes"];
                                                $siwes_level = $row["siwes_level"];
                                                $siwes_unit = $row["siwes_unit"];
                                                $siwes_semester = $row["siwes_semester"];
                                            }
                                            /* if ($siwes_level == 300) {
                                                $ccode = "SIW300";
                                            } else {
                                                $ccode = "SIW400";
                                            } */
                                        }
                                        ?>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Status</th>

                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                /*  if ($level == $siwes_level && $_SESSION['InstType'] == "University") {
                                                    $sum2nd += $siwes_unit;
                                                    echo "<tr><td>$ccode</td><td>SIWES</td><td>$siwes_unit</td><td>$siwes_semester</td><td>Core</td></tr>\n";

                                                    $countCC++;
                                                    $CCodeArry[$countCC] = $ccode;
                                                    $CUnitArry[$countCC] = $siwes_unit;
                                                    $CTitleArry[$countCC] = "SIWES";
                                                    $SemTakenArry[$countCC] = $siwes_semester;
                                                    $NatureArry[$countCC] = "Core";
                                                } else { */
                                                if (!empty($_POST["chosen2c"])) {
                                                    foreach ($_POST["chosen2c"] as $key => $value) {

                                                        //echo $_POST["chosen"][$key];

                                                        $ccode2c = $_POST["ccodec2"][$key];
                                                        $CTitle2c = str_replace("'", "''", $_POST["CTitlec2"][$key]);
                                                        $CUnit2c = $_POST["CUnitc2"][$key];
                                                        $SemTaken2c = $_POST["SemTakenc2"][$key];
                                                        $Nature2c = $_POST["Naturec2"][$key];

                                                        //if ($countrepcourse == 0){
                                                        $sum2nd += $CUnit2c;
                                                        echo "<tr><td>$ccode2c</td><td>$CTitle2c</td><td>$CUnit2c</td><td>$SemTaken2c</td><td>$Nature2c</td></tr>\n";

                                                        //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode2c', '$CUnit2c', '$CTitle2c', '$SemTaken2c', '$Nature2c')";
                                                        //$result = $conn_stu->query($sql);
                                                        $countCC++;
                                                        $CCodeArry[$countCC] = $ccode2c;
                                                        $CUnitArry[$countCC] = $CUnit2c;
                                                        $CTitleArry[$countCC] = $CTitle2c;
                                                        $SemTakenArry[$countCC] = $SemTaken2c;
                                                        $NatureArry[$countCC] = $Nature2c;
                                                        //}
                                                    }
                                                }

                                                if (!empty($_POST["chosen2"])) {
                                                    foreach ($_POST["chosen2"] as $key => $value) {

                                                        //echo $_POST["chosen"][$key];

                                                        $ccode2 = $_POST["ccode2"][$key];
                                                        $CTitle2 = str_replace("'", "''", $_POST["CTitle2"][$key]);
                                                        $CUnit2 = $_POST["CUnit2"][$key];
                                                        $SemTaken2 = $_POST["SemTaken2"][$key];
                                                        $Nature2 = $_POST["Nature2"][$key];
                                                        $sum2nd += $CUnit2;
                                                        echo "<tr><td>$ccode2</td><td>$CTitle2</td><td>$CUnit2</td><td>$SemTaken2</td><td>$Nature2</td></tr>\n";
                                                        //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode2', '$CUnit2', '$CTitle2', '$SemTaken2', '$Nature2')";
                                                        //$result = $conn_stu->query($sql);
                                                        $countCC++;
                                                        $CCodeArry[$countCC] = $ccode2;
                                                        $CUnitArry[$countCC] = $CUnit2;
                                                        $CTitleArry[$countCC] = $CTitle2;
                                                        $SemTakenArry[$countCC] = $SemTaken2;
                                                        $NatureArry[$countCC] = $Nature2;
                                                    }
                                                }

                                                if (!empty($_POST["chosenadd2"])) {
                                                    foreach ($_POST["chosenadd2"] as $key => $value) {

                                                        //echo $_POST["chosen"][$key];

                                                        $ccode2 = $_POST["ccode2"][$key];
                                                        $CTitle2 = str_replace("'", "''", $_POST["CTitle2"][$key]);
                                                        $CUnit2 = $_POST["CUnit2"][$key];
                                                        $SemTaken2 = $_POST["SemTaken2"][$key];
                                                        $Nature2 = $_POST["Nature2"][$key];

                                                        $sum2nd += $CUnit2;
                                                        echo "<tr><td>$ccode2</td><td>$CTitle2</td><td>$CUnit2</td><td>$SemTaken2</td><td>$Nature2</td></tr>\n";
                                                        //$sql = "INSERT INTO coursesregis (Regn1, CCode, CUnit, CTitle, SemTaken, Nature) VALUES ('$regid', '$ccode2', '$CUnit2', '$CTitle2', '$SemTaken2', '$Nature2')";
                                                        //$result = $conn_stu->query($sql);
                                                        $countCC++;
                                                        $CCodeArry[$countCC] = $ccode2;
                                                        $CUnitArry[$countCC] = $CUnit2;
                                                        $CTitleArry[$countCC] = $CTitle2;
                                                        $SemTakenArry[$countCC] = $SemTaken2;
                                                        $NatureArry[$countCC] = $Nature2;
                                                    }
                                                }
                                                // }
                                                ?>
                                            </tbody>
                                        </table>
                                        <br>
                                        <?php
                                        echo "<center> Total Credit Units : $sum2nd</center>";
                                        ?>

                                        <?php
                                        if ($_SESSION['InstType'] == "University") {
                                            /* if ($level == "100" || $level == "200" || $level == "300" || $level == "400" || $level == "500") {
                                                if ($engrrep100level == "YES" && $level == "200") {
                                                    if ($sum2nd < 8) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of 8 Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } else {
                                                    if ($level == "100") {
                                                        if ($sum2nd < $minCreditNew) {
                                                            echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    } elseif ($level !== $siwes_level) {
                                                        if ($sum2nd < $minCredit) {
                                                            echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    }
                                                }

                                                if ($level == "100") {
                                                    if ($sum2nd > $MaxCreditNew) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } elseif ($level !== $siwes_level) {

                                                    if ($sum2nd > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                }
                                            }


                                            // if ($level == "500") {
                                            //     if ($sum2nd < $minCredit) {
                                            //         echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                            //         $stopit = "Yes";
                                            //     }
                                            //     if ($sum2nd > 26) {
                                            //         echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of 26 Unit per semester</center></strong>";
                                            //         $stopit = "Yes";
                                            //     }
                                            //     if ($sum1st + $sum2nd > 50) {
                                            //         echo "<strong style='color:#F00'><center>Excess Credit Unit(Options are $MaxCredit & 26 OR 25 & 25 OR 26 & $MaxCredit)</center></strong>";
                                            //         $stopit = "Yes";
                                            //     }
                                            // }
                                            if ($level == "600") {
                                                if ($sum2nd > 26) {
                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of 26 Unit per semester</center></strong>";
                                                    $stopit = "Yes";
                                                }
                                                if ($sum1st + $sum2nd > 50) {
                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit(Options are $MaxCredit & 26 OR 25 & 25 OR 26 & $MaxCredit)</center></strong>";
                                                    $stopit = "Yes";
                                                }
                                            }
 */



                                            if ($level == "600") {
                                                if ($sum2nd > $MaxCredit) {
                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                    $stopit = "Yes";
                                                }
                                            } else {
                                                if ($level == "100") {
                                                    if ($sum2nd < $minCreditNew) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCreditNew Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                    if ($sum2nd > $MaxCreditNew) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCreditNew Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } else {
                                                    if ($level == $siwes_level) {
                                                        if ($sum2nd < $siwes_unit) {
                                                            echo "<strong style='color:#F00'><center>Shortage of Unit, $siwes_unit Unit for student on SIWES</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                        if ($sum2nd > $siwes_unit) {
                                                            echo "<strong style='color:#F00'><center>Excess Credit Unit, $siwes_unit Unit for student on SIWES</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    } else {
                                                        if ($sum2nd < $minCredit) {
                                                            echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                        if ($sum2nd > $MaxCredit) {
                                                            echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    }
                                                }
                                            }
                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                            if ($modeofentry == "ND") {
                                                if ($level == "100" || $level == "200") {

                                                    if ($sum2nd < $minCredit) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                    if ($sum2nd > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } else if ($level > "200") {
                                                    if ($sum2nd > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                }
                                            } else {
                                                if ($level == "300" || $level == "400") {

                                                    if ($sum2nd < $minCredit) {
                                                        echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }

                                                    if ($sum2nd > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                } else if ($level > "400") {
                                                    if ($sum2nd > $MaxCredit) {
                                                        echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                        $stopit = "Yes";
                                                    }
                                                }
                                            }
                                        }

                                        $_SESSION["CCodeArry"] = $CCodeArry;
                                        $_SESSION["CUnitArry"] = $CUnitArry;
                                        $_SESSION["CTitleArry"] = $CTitleArry;
                                        $_SESSION["SemTakenArry"] = $SemTakenArry;
                                        $_SESSION["NatureArry"] = $NatureArry;
                                        $_SESSION["countCC"] = $countCC;

                                        //$conn->close();
                                        ?>
                                        <br /><br />
                                        <?php if ($stopit !== "Yes") { ?>
                                            <p style="text-align: right"><button type="submit" name="submit2" class="btn btn-primary">Submit</button></p>
                                        <?php } ?>
                                    </form>
                                    <?php
                                    $conn->close();
                                    $conn_stu->close();
                                    ?>
                                    <br /><br />
                                </div>
                            </div>
                            <div class="col-lg-1">

                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
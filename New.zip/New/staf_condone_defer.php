<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staf_condone_defer'] == false) {
	header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
	$autologoutURL = "";
	include_once 'includes/autologout.php';
	?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Missing Session/Semester</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Missing Session
                            </li>

                            <li class="active">
                                <strong>Missing Session/Semester</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">
                    <?php
					$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					}

					$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
					if ($conn2->connect_error) {
						die("Connection failed: " . $conn2->connect_error);
					}
					?>
                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Missing Session/Semester
                        </div>
                        <div class="panel-body">
                            <?php

							$stuschcode = "";
							$regid = "";
							$name1 = "";
							$cursession = "";
							$response = $response_full = "";
							$semester = "";
							$senateno = 0;
							$comment = "";
							$approval = "";
							$sno = 0;
							$updid = 0;

							$senatenowdsel = $senatenosel = $fullsenatenosel = "";
							$updatesenate = "NO";
							$schcode = $_SESSION['schcode2'];
							$names = $_SESSION['names'];
							$staffid = strtoupper($_SESSION['staffid']);

							$withdexist = 0;
							$sql = "SELECT * FROM missing_session_temp WHERE schcode = '$schcode'";
							$result = $conn->query($sql);
							if ($result->num_rows > 0) {
								$withdexist++;
							}

							$error1 = "NO";
							$error2 = "NO";
							$error3 = "NO";
							$date1 = date("Y/m/d");
							if (isset($_POST["submit"])) {
								$response = $_POST["response"];
								$session = $_POST["sesion"];
								$senatenosel = $_POST["senateno"];
								$sql2 = "SELECT * FROM miss_session_senateno WHERE senateno = '$senatenosel'";
								$result2 = $conn->query($sql2);
								if ($result2->num_rows > 0) {
									while ($row2 = $result2->fetch_assoc()) {
										$senatedate = $row2["senatedate"];

										$fulsenatedate = date_format(date_create($senatedate), "D") . ", " . date_format(date_create($senatedate), "j") . date_format(date_create($senatedate), "M") . ", " . date_format(date_create($senatedate), "Y");
										//$senatesel=$row2["senateno"];
										$fullsenatenosel = $senatenosel . ", " . $fulsenatedate;
									}
								}

								if ($response !== "Sel") {

									if ($response == "Deferment") {
										$response_full = "Deferment";
									} else if ($response == "Abscond") {
										$response_full = "Abscond";
									} else if ($response == "Condonation") {
										$response_full = "Condonation";
									} else if ($response == "Suspension") {
										$response_full = "Suspension";
									} else if ($response == "Expulsion") {
										$response_full = "Expulsion";
									} else if ($response == "VolWithdrawal") {
										$response_full = "Voluntary Withdrawal";
									} else if ($response == "PoorWithdrawal") {
										$response_full = "Withdrawal(Poor Acad Performance)";
									} else if ($response == "Notification_illhealth") {
										$response_full = "Notification of ill-health";
									} else if ($response == "recall_susp") {
										$response_full = "Recall from Suspension";
									} else if ($response == "recall_expul") {
										$response_full = "Recall from Expulsion";
									}

									$matno = strtoupper($_POST["regid"]);
									$senateno = $_POST["senateno"];
									$comment = str_replace("'", "''", $_POST['comment']);
									$comment = filter_var($comment, FILTER_SANITIZE_STRING);
									$approval = $_POST["approval"];
									$stdid = "";
									$sql = "SELECT * FROM std_data_view WHERE matric_no = '$matno'";
									$result = $conn2->query($sql);
									if ($result->num_rows > 0) {
										while ($row = $result->fetch_assoc()) {
											$name1 = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
											$dept = strtolower($row['dept_code']);
											$stuschcode = $row["school_code"];
											//$stdid = $row["stdid"];
											$stulevel = $row["level"];
											$oldstatus = $row["status"];
										}
									}



									if (!empty($_POST["semester1"]) && !empty($_POST["semester2"])) {
										$semester = "1ST,2ND";
									} else if (!empty($_POST["semester1"])) {
										$semester = "1ST";
									} else if (!empty($_POST["semester2"])) {
										$semester = "2ND";
									}

									$sql = "SELECT * FROM missing_session WHERE matno = '$matno' AND session = '$session' AND response = '$response' AND semester = '$semester' AND senateno = '$senateno'";
									$result = $conn->query($sql);
									if ($result->num_rows > 0) {
										$error2 = "YES";
									}

									if ($stuschcode == $schcode) {
										if ($error2 == "NO") {
											$sql = "INSERT INTO missing_session (matno, name1, stulevel, response, response_full, session, semester, schcode, deptcode, senateno, coment, approval, date1, officername, oldstatus, officerno) VALUES ('$matno', '$name1', '$stulevel', '$response', '$response_full', '$session', '$semester', '$stuschcode', '$dept', '$senateno', '$comment', '$approval', '$date1', '$names', '$oldstatus', '$staffid')";
											$result = $conn->query($sql);

											if ($response == "Suspension") {
												$sql = "UPDATE std_data_view set status = '8' WHERE matric_no = '$matno'";
												$result = $conn3->query($sql);
											}
											if ($response == "VolWithdrawal" || $response == "PoorWithdrawal" || $response == "Expulsion") {
												$sql = "UPDATE std_data_view set status = '14' WHERE matric_no = '$matno'";
												$result = $conn3->query($sql);
											}
										}
									} else {
										$error1 = "YES";
									}
								} else {
									$error3 = "YES";
								}
							}

							if (isset($_POST["delete"])) {
								$id = $_POST["id"];
								$sql = "SELECT * FROM missing_session WHERE id ='$id'";
								$result = $conn->query($sql);
								if ($result->num_rows > 0) {
									while ($row = $result->fetch_assoc()) {
										$oldstatus = $row["oldstatus"];
										$matno = $row["matno"];
									}
								}


								$sql = "UPDATE std_data_view set status = '$oldstatus' WHERE matric_no = '$matno'";
								$result = $conn3->query($sql);

								$sql = "DELETE FROM missing_session WHERE id ='$id'";
								$result = $conn->query($sql);
							}

							if (isset($_POST["withd"])) {
								$senatenowdsel = $_POST["senatenowd"];
								if ($senatenowdsel !== "") {
									$sn = $_POST["id"];
									$senatenowd = $_POST["senatenowd"];

									$sql = "SELECT * FROM missing_session_temp WHERE sn = '$sn'";
									$result = $conn->query($sql);
									if ($result->num_rows > 0) {
										while ($row = $result->fetch_assoc()) {
											$matno = $row["matno"];
											$name1 = $row["name1"];
											$stulevel = $row["stulevel"];
											$deptcode = $row["deptcode"];
											$schcode = $row["schcode"];
											$session1 = $row["session1"];
										}
									}

									$sql = "SELECT * FROM std_data_view WHERE matric_no = '$matno'";
									$result = $conn2->query($sql);
									if ($result->num_rows > 0) {
										while ($row = $result->fetch_assoc()) {
											//$stdid = $row["stdid"];
											$stulevel = $row["level"];
											$oldstatus = $row["status"];
										}
									}



									$sql = "INSERT INTO missing_session (matno, name1, stulevel, response, response_full, session, semester, schcode, deptcode, senateno, coment, approval, date1, officername, oldstatus, officerno) VALUES ('$matno', '$name1', '$stulevel', 'PoorWithdrawal', 'Withdrawal(Poor Acad Performance)', '$session1', '2ND', '$schcode', '$deptcode', '$senatenowd', '', 'Approved', '$date1', '$names', '$oldstatus', '$staffid')";
									$result = $conn->query($sql);

									$sql = "UPDATE std_data_view set status = '14' WHERE matric_no = '$matno'";
									$result = $conn3->query($sql);

									$sql = "DELETE FROM missing_session_temp WHERE sn = '$sn'";
									$result = $conn->query($sql);
								}
							}

							if (isset($_POST["withddelete"])) {
								$sn = $_POST["id"];

								$sql = "DELETE FROM missing_session_temp WHERE sn = '$sn'";
								$result = $conn->query($sql);
							}
							if (isset($_POST["updatesenate"])) {
								$updatesenate = "YES";
							}
							if (isset($_POST["submitnewsenate"])) {
								$newsenateno = $_POST["newsenateno"];
								$newsenatedate = $_POST["newsenatedate"];
								$sql2 = "SELECT * FROM miss_session_senateno WHERE senateno = '$newsenateno'";
								$result2 = $conn->query($sql2);
								if ($result2->num_rows == 0) {
									$sql = "INSERT INTO miss_session_senateno (senateno, senatedate) VALUES ('$newsenateno', '$newsenatedate')";
									$result = $conn->query($sql);
								}
							}

							if (isset($_POST["edit"])) {
								$sno = $_POST["id"];
								$updid = $_POST["id"];
								$sql = "SELECT * FROM missing_session WHERE id = '$sno'";
								$result = $conn->query($sql);

								if ($result->num_rows > 0) {
									while ($row = $result->fetch_assoc()) {
										$regid = $row["matno"];
										$name1 = $row["name1"];
										$cursession = $row["session"];
										$response = $row['response'];
										$semester = $row['semester'];
										$senateno = $row['senateno'];
										$comment = $row['coment'];
										$approval = $row["approval"];
										if ($response == "Deferment") {
											$response_full = "Deferment";
										} else if ($response == "Abscond") {
											$response_full = "Abscond";
										} else if ($response == "Condonation") {
											$response_full = "Condonation";
										} else if ($response == "Suspension") {
											$response_full = "Suspension";
										} else if ($response == "Expulsion") {
											$response_full = "Expulsion";
										} else if ($response == "VolWithdrawal") {
											$response_full = "Voluntary Withdrawal";
										} else if ($response == "PoorWithdrawal") {
											$response_full = "Withdrawal(Poor Acad Performance)";
										} else if ($response == "Notification_illhealth") {
											$response_full = "Notification of ill-health";
										} else if ($response == "recall_susp") {
											$response_full = "Recall from Suspension";
										} else if ($response == "recall_expul") {
											$response_full = "Recall from Expulsion";
										}
									}
								}
								$sql2 = "SELECT * FROM miss_session_senateno WHERE senateno='$senateno'";
								$result2 = $conn->query($sql2);
								if ($result2->num_rows > 0) {

									while ($row2 = $result2->fetch_assoc()) {
										$senatedate = $row2["senatedate"];

										$fulsenatedate = date_format(date_create($senatedate), "D") . ", " . date_format(date_create($senatedate), "j") . " " . date_format(date_create($senatedate), "M") . ", " . date_format(date_create($senatedate), "Y");
										$fullsenatenosel = $senateno . ", " . $fulsenatedate;
									}
								}
							}
							if (isset($_POST["update"])) {
								$id = $_POST["updateid"];
								$response = $_POST["response"];
								$session = $_POST["sesion"];
								$senatenosel = $_POST["senateno"];
								$sql2 = "SELECT * FROM miss_session_senateno WHERE senateno = '$senatenosel'";
								$result2 = $conn->query($sql2);
								if ($result2->num_rows > 0) {
									while ($row2 = $result2->fetch_assoc()) {
										$senatedate = $row2["senatedate"];

										$fulsenatedate = date_format(date_create($senatedate), "D") . ", " . date_format(date_create($senatedate), "j") . date_format(date_create($senatedate), "M") . ", " . date_format(date_create($senatedate), "Y");
										//$senatesel=$row2["senateno"];
										$fullsenatenosel = $senatenosel . ", " . $fulsenatedate;
									}
								}

								if ($response == "Deferment") {
									$response_full = "Deferment";
								} else if ($response == "Abscond") {
									$response_full = "Abscond";
								} else if ($response == "Condonation") {
									$response_full = "Condonation";
								} else if ($response == "Suspension") {
									$response_full = "Suspension";
								} else if ($response == "Expulsion") {
									$response_full = "Expulsion";
								} else if ($response == "VolWithdrawal") {
									$response_full = "Voluntary Withdrawal";
								} else if ($response == "PoorWithdrawal") {
									$response_full = "Withdrawal(Poor Acad Performance)";
								} else if ($response == "Notification_illhealth") {
									$response_full = "Notification of ill-health";
								} else if ($response == "recall_susp") {
									$response_full = "Recall from Suspension";
								} else if ($response == "recall_expul") {
									$response_full = "Recall from Expulsion";
								}

								$matno = $_POST["regid"];
								$senateno = $_POST["senateno"];
								$comment = $_POST["comment"];
								$approval = $_POST["approval"];


								//$sql = "SELECT * FROM e_data WHERE stdid = '$stdid'";
								//					$result = $mysqli3->query($sql);
								//					if ($result->num_rows > 0) {
								//						while($row = $result->fetch_assoc()) {
								//							$oldstatus=$row["status"];
								//						}
								//					}



								if (!empty($_POST["semester1"]) && !empty($_POST["semester2"])) {
									$semester = "1ST,2ND";
								} else if (!empty($_POST["semester1"])) {
									$semester = "1ST";
								} else if (!empty($_POST["semester2"])) {
									$semester = "2ND";
								}

								$sql = "SELECT * FROM missing_session WHERE matno = '$matno' AND session = '$session' AND response = '$response' AND semester = '$semester' AND senateno = '$senateno'";
								$result = $conn->query($sql);
								if ($result->num_rows > 0) {
									$error2 = "YES";
								}
								if ($error2 == "NO") {
									$sql = "UPDATE missing_session set response = '$response', response_full = '$response_full', session = '$session', semester = '$semester', senateno = '$senateno', coment = '$comment', approval = '$approval' WHERE id = '$id'";
									$result = $conn->query($sql);

									if ($response == "Suspension") {
										$sql = "UPDATE std_data_view set status = '8' WHERE matric_no = '$matno'";
										$result = $conn3->query($sql);
									}
									if ($response == "VolWithdrawal" || $response == "PoorWithdrawal" || $response == "Expulsion") {
										$sql = "UPDATE std_data_view set status = '14' WHERE matric_no = '$matno'";
										$result = $conn3->query($sql);
									}
								}
							}
							?>

                            <div class="row">

                                <div class="col-lg-12  col-md-12">
                                    <div class="col-lg-4 col-md-4">
                                        <?php if ($error1 == "YES") { ?>
                                        <center>
                                            <h4 style="color:#F00">Student NOT in School assign to you</h4>
                                        </center>
                                        <?php } ?>
                                        <?php if ($error2 == "YES") { ?>
                                        <center>
                                            <h4 style="color:#F00">Record already exist!</h4>
                                        </center>
                                        <?php } ?>
                                        <?php if ($error3 == "YES") { ?>
                                        <center>
                                            <h4 style="color:#F00">Select Response</h4>
                                        </center>
                                        <?php } ?>
                                        <input type='hidden' value=<?php echo $sno ?> name='sn'>
                                        <form class="form-horizontal" role="form" method="post" action="">
                                            <!-- Content -->
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="regid"><strong>Matric
                                                        No.:</strong></label>
                                                <div class="col-lg-7">
                                                    <?php if (isset($_POST["edit"])) { ?>
                                                    <input class="form-control" name="regid" id="regid"
                                                        value="<?php echo $regid ?>" disabled>
                                                    <input type="hidden" name="updateid" id="updateid"
                                                        value="<?php echo $updid ?>">
                                                    <?php } else { ?>
                                                    <input class="form-control" name="regid" id="regid"
                                                        value="<?php echo $regid ?>">
                                                    <?php } ?>

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-3 control-label"><strong>Session:</strong></label>
                                                <div class="col-lg-7">
                                                    <?php
													$iniyear = 2015;
													//$D = exec('date /T');
													//												  $T = exec('time /T');
													//												  $DT = strtotime(str_replace("/","-",$D." ".$T));
													$finalyear = substr($_SESSION['corntsession'], 5);

													?>
                                                    <select name="sesion" class="form-control" style="color:#000000"
                                                        id="sesion">

                                                        <option value="<?php echo $cursession ?>">
                                                            <?php echo $cursession ?></option>
                                                        <?php
														while ($iniyear <= $finalyear) {
															$addyear = $iniyear + 1;

															echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
															$iniyear++;
														}

														?>

                                                    </select>

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-3 control-label"><strong>Response:</strong></label>
                                                <div class="col-lg-7">

                                                    <select name="response" class="form-control" style="color:#000000"
                                                        id="response">
                                                        <option value="<?php echo $response ?>">
                                                            <?php echo $response_full ?></option>
                                                        <option value="Deferment">Deferment</option>
                                                        <option value="Abscond">Abscond</option>
                                                        <option value="Condonation">Condonation</option>
                                                        <option value="Suspension">Suspension</option>
                                                        <option value="Expulsion">Expulsion</option>
                                                        <option value="VolWithdrawal">Voluntary Withdrawal</option>
                                                        <option value="PoorWithdrawal">Withdrawal(Poor Acad Performance)
                                                        </option>
                                                        <option value="Notification_illhealth">Notification of
                                                            ill-health</option>
                                                        <option value="recall_susp">Recall from Suspension</option>
                                                        <option value="recall_expul">Recall from Expulsion</option>
                                                    </select>

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-3 control-label"><strong>Semester:</strong></label>
                                                <div class="col-lg-7">

                                                    <?php if ($semester == "1ST") { ?>
                                                    <input type="checkbox" name="semester1" value="1ST" checked>1ST
                                                    <input type="checkbox" name="semester2" value="2ND">2ND
                                                    <?php } else if ($semester == "2ND") { ?>
                                                    <input type="checkbox" name="semester1" value="1ST">1ST
                                                    <input type="checkbox" name="semester2" value="2ND" checked>2ND
                                                    <?php } else if ($semester == "1ST,2ND") { ?>
                                                    <input type="checkbox" name="semester1" value="1ST" checked>1ST
                                                    <input type="checkbox" name="semester2" value="2ND" checked>2ND
                                                    <?php } else { ?>
                                                    <input type="checkbox" name="semester1" value="1ST">1ST
                                                    <input type="checkbox" name="semester2" value="2ND">2ND
                                                    <?php } ?>

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-lg-3 control-label"><strong>Approval:</strong></label>
                                                <div class="col-lg-7">

                                                    <select name="approval" class="form-control" style="color:#000000"
                                                        id="approval">
                                                        <option value="<?php echo $approval ?>"><?php echo $approval ?>
                                                        </option>
                                                        <option value="Approve">Approve</option>
                                                        <option value="Not_Approve">Not Approve</option>

                                                    </select>

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="regid"><strong>Senate
                                                        No.:</strong></label>
                                                <div class="col-lg-7">
                                                    <select name="senateno" class="form-control" style="color:#000000"
                                                        id="senateno">

                                                        <option value="<?php echo $senateno ?>">
                                                            <?php echo $fullsenatenosel ?></option>
                                                        <?php
														$sql2 = "SELECT * FROM miss_session_senateno ORDER BY senateno DESC";
														$result2 = $conn->query($sql2);
														if ($result2->num_rows > 0) {

															while ($row2 = $result2->fetch_assoc()) {
																$senatedate = $row2["senatedate"];

																$fulsenatedate = date_format(date_create($senatedate), "D") . ", " . date_format(date_create($senatedate), "j") . " " . date_format(date_create($senatedate), "M") . ", " . date_format(date_create($senatedate), "Y");
																$senatenoget = $row2["senateno"];
																echo "<option value = '$senatenoget'>$senatenoget, $fulsenatedate</option>";
															}
														}
														?>

                                                    </select>
                                                </div>
                                                <div class="col-lg-2">

                                                    <button type="submit" name="updatesenate"
                                                        class="btn btn-warning btn-xs">Add</button>
                                                    Senate No.

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="regid"><strong>Comment (<i
                                                            style="color:#609">Optional</i>):</strong></label>
                                                <div class="col-lg-7">
                                                    <input type="text" name="comment" id="comment" class="form-control"
                                                        value="<?php echo $comment ?>">
                                                </div>
                                            </div>
                                            <?php if ($updatesenate == "NO") { ?>
                                            <div class="form-group">
                                                <!-- Buttons -->
                                                <div class="col-lg-offset-5 col-lg-9">
                                                    <?php if (isset($_POST["edit"])) { ?>
                                                    <button type="submit" name="update"
                                                        class="btn btn-info btn-xm">Update</button>
                                                    <?php } else { ?>
                                                    <button type="submit" name="submit"
                                                        class="btn btn-primary btn-xm">Submit</button>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <?php } ?>
                                            <br>
                                        </form>

                                    </div>
                                    <div class="col-lg-8 col-md-8"
                                        style="overflow-x: scroll; overflow-y: hidden; white-space: nowrap;">
                                        <?php if ($updatesenate == "NO") { ?>
                                        <?php if ($withdexist !== 0) { ?>
                                        <center>
                                            <h3>Withdrawal(Poor Acad Performance)</h3>
                                        </center>

                                        <br>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Matric No.</th>
                                                    <th>Name</th>
                                                    <th>Department</th>
                                                    <th>Senate No</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php

														$sql = "SELECT * FROM missing_session_temp WHERE schcode = '$schcode' ORDER BY matno";
														$sno = 0;
														$result = $conn->query($sql);
														if ($result->num_rows > 0) {
															while ($row = $result->fetch_assoc()) {
																$sno++;
																$id = $row['sn'];

																echo "<tr><td>$sno</td><td>{$row['matno']}</td><td>{$row['name1']}</td><td>{$row['deptcode']}</td>
																											
																<form action='' method='post'>";
														?>
                                                <td>
                                                    <select name="senatenowd" id="senatenowd">
                                                        <option value="<?php echo $senatenowdsel ?>">
                                                            <?php echo $senatenowdsel ?></option>
                                                        <?php
																		$sql2 = "SELECT * FROM miss_session_senateno ORDER BY senateno DESC";
																		$result2 = $conn->query($sql2);
																		if ($result2->num_rows > 0) {

																			while ($row2 = $result2->fetch_assoc()) {
																				$senatenowithd = $row2["senateno"];
																				echo "<option value = '$senatenowithd'>$senatenowithd</option>";
																			}
																		}
																		?>
                                                    </select>
                                                </td>
                                                <?php
																echo "<td>
																  <input type='hidden' value=$id name='id'>
																  <input type='submit' name = 'withd' class='btn btn-primary btn-xs' value='Approved'>
																  <input type='submit' name = 'withddelete' class='btn btn-danger btn-xs' value='Not Approve'>
																 </td>
																  
															 </form>
															</tr>\n";
															}
														}


														?>
                                            </tbody>
                                        </table>
                                        <br><br>
                                        <?php } ?>
                                        <center>
                                            <h4>Today's Records</h4>
                                        </center>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Matric No.</th>
                                                    <th>Name</th>
                                                    <th>Response</th>
                                                    <th>Session</th>
                                                    <th>Semester</th>
                                                    <th>Comment</th>
                                                    <th>Approval</th>
                                                    <th>Senate Number</th>
                                                    <th>Action</th>
                                                    <th>Action</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php

													$sql = "SELECT * FROM missing_session WHERE date1 = '$date1' AND schcode = '$schcode' ORDER BY id DESC";
													$sno = 0;
													$result = $conn->query($sql);
													if ($result->num_rows > 0) {
														while ($row = $result->fetch_assoc()) {
															$sno++;
															$id = $row['id'];
															$response = $row['response'];
															if ($response == "Deferment") {
																$response_full = "Deferment";
															} else if ($response == "Abscond") {
																$response_full = "Abscond";
															} else if ($response == "Condonation") {
																$response_full = "Condonation";
															} else if ($response == "Suspension") {
																$response_full = "Suspension";
															} else if ($response == "Expulsion") {
																$response_full = "Expulsion";
															} else if ($response == "VolWithdrawal") {
																$response_full = "Voluntary Withdrawal";
															} else if ($response == "PoorWithdrawal") {
																$response_full = "Withdrawal(Poor Acad Performance)";
															} else if ($response == "Notification_illhealth") {
																$response_full = "Notification of ill-health";
															} else if ($response == "recall_susp") {
																$response_full = "Recall from Suspension";
															} else if ($response == "recall_expul") {
																$response_full = "Recall from Expulsion";
															}

															if ($response == "PoorWithdrawal") {
																echo "<tr><td>$sno</td><td>{$row['matno']}</td><td>{$row['name1']}</td><td>$response_full</td><td>{$row['session']}</td><td></td><td>{$row['coment']}</td><td>{$row['approval']}</td><td>{$row['senateno']}</td>
																												
																	<form action='' method='post'>
																		  <input type='hidden' value=$id name='id'>
																		  <td></td>
																		  <td><input type='submit' name = 'delete' class='btn btn-danger btn-xs disabled' value='Delete'></td>
																		  <td><a href='miss_session_print.php?id2=$id' class='btn btn-primary btn-xs'>Print</a></td>
																		  
																	 </form>
																</tr>\n";
															} else {
																echo "<tr><td>$sno</td><td>{$row['matno']}</td><td>{$row['name1']}</td><td>$response_full</td><td>{$row['session']}</td><td>{$row['semester']}</td><td>{$row['coment']}</td><td>{$row['approval']}</td><td>{$row['senateno']}</td>
																												
																	<form action='' method='post'>
																		  <input type='hidden' value=$id name='id'>
																		  <td><input type='submit' name = 'edit' class='btn btn-info btn-xs' value='View'></td>
																		  <td><input type='submit' name = 'delete' class='btn btn-danger btn-xs' value='Delete'></td>
																		  <td><a href='miss_session_print.php?id2=$id' class='btn btn-primary btn-xs'>Print</a></td>
																	 </form>
																</tr>\n";
															}
														}
													}


													?>
                                            </tbody>
                                        </table>
                                        <?php } else { ?>

                                        <form class="form-horizontal" role="form" method="post" action="">
                                            <!-- Content -->
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="regid"><strong>Senate
                                                        No.:</strong></label>
                                                <div class="col-lg-7">
                                                    <input type="number" name="newsenateno" id="newsenateno"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label col-lg-3" for="regid"><strong>Senate
                                                        Date:</strong></label>
                                                <div class="col-lg-7">
                                                    <input type="date" name="newsenatedate" id="newsenatedate"
                                                        class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <!-- Buttons -->
                                                <div class="col-lg-offset-5 col-lg-9">
                                                    <button type="submit" name="submitnewsenate"
                                                        class="btn btn-primary btn-xm">Submit</button>
                                                </div>
                                            </div>
                                        </form>

                                        <?php } ?>
                                    </div>


                                </div>

                            </div>


                        </div>
                    </div>

                    <?php
					$conn->close();
					$conn2->close();
					?>

                </div>
            </div>

            <div class="footer">
                <?php
				include_once 'includes/footer2.php';
				?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
			include_once 'includes/aside_right.php';
			?>

        </div>

    </div>

    <?php
	include_once 'includes/footer.php';
	?>


</body>

</html>
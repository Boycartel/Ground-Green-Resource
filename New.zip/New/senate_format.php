<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['senate_format'] == false) {
    header('Location: home_staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Senate Format</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Senate Format</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Senate Format
                        </div>
                        <div class="panel-body">
                            <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
                                <form class="form-horizontal form-bordered" method="post">

                                    <div class="row">

                                        <div class="col-lg-5">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="content">Select
                                                    Department:</label>
                                                <div class="col-lg-7">
                                                    <select class="country form-control" style="color:#000000"
                                                        name="dept">
                                                        <option value="SelectItem">Select Item</option>
                                                        <?php
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

                                                        $dept = $_SESSION['deptcode'];


                                                        if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                                            $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                        } else {
                                                            $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                        }


                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {
                                                            // output data of each row
                                                            while ($row = $result->fetch_assoc()) {
                                                                $deptcode2 = strtolower($row["DeptCode"]);
                                                                $deptname2 = $row["DeptName"];
                                                                echo "<option value=$deptcode2>$deptname2</option>";
                                                            }
                                                        }
                                                        $conn->close();
                                                        ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="regid">Level:</label>
                                                <div class="col-lg-7">
                                                    <select name="getlevel" class="form-control" style="color:#000000"
                                                        id="getlevel">
                                                        <option value="100">100</option>
                                                        <option value="200">200</option>
                                                        <option value="300">300</option>
                                                        <option value="400">400</option>
                                                        <option value="500">500</option>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="regid">Session:</label>
                                                <div class="col-lg-7">
                                                    <?php
                                                    $iniyear = 2015;
                                                    $finalyear = substr($_SESSION['corntsession'], 5);

                                                    ?>
                                                    <select name="getsession" class="form-control" style="color:#000000"
                                                        id="getsession">
                                                        <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                            <?php echo $_SESSION['corntsession'] ?></option>
                                                        <?php
                                                        while ($iniyear <= $finalyear) {
                                                            $addyear = $iniyear + 1;

                                                            echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                            $iniyear++;
                                                        }

                                                        ?>


                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="row">
                                                <label class="control-label col-lg-4" for="regid">Semester:</label>
                                                <div class="col-lg-4">
                                                    <select name="getsemester" class="form-control"
                                                        style="color:#000000" id="getsemester">
                                                        <option value="1ST">1ST</option>
                                                        <option value="2ND">2ND</option>

                                                    </select>
                                                </div>
                                                <div class="col-lg-4">
                                                    <button type="submit" name="submit"
                                                        class="btn btn-primary btn-sm">Submit</button>

                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                                <hr class="separator" />
                            </div>

                            <div style="padding-left:3em; padding-right: 3em">
                                <?php
                                if (isset($_POST["submitAll"])) {
                                    $getstatus = $_POST["getstatus"];
                                    $getdept = $_SESSION['dept_sctny'];
                                    $getsession = $_SESSION['getsession_sctny'];
                                    $getsemester = $_SESSION['getsemester_sctny'];
                                    $getlevel = $_SESSION['getlevel_sctny'];

                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }

                                    $sql2 = "UPDATE scrutiny_senate SET senate_aproval = '$getstatus' WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval = 'Approve'";
                                    $result2 = $conn_stu->query($sql2);
                                    $conn_stu->close();
                                }

                                ?>
                                <?php if (isset($_POST["submit"]) || isset($_POST["submitAll"])) { ?>
                                <?php
                                    if (isset($_POST["submit"])) {
                                        $_SESSION['dept_sctny'] = $_POST["dept"];
                                        $_SESSION['getsession_sctny'] = $_POST["getsession"];
                                        $_SESSION['getsemester_sctny'] = $_POST["getsemester"];
                                        $_SESSION['getlevel_sctny'] = $_POST["getlevel"];
                                    }

                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                    if ($conn2->connect_error) {
                                        die("Connection failed: " . $conn2->connect_error);
                                    }

                                    $_SESSION['sn'] = 0;

                                    $deptname = "";

                                    $getdept = $_SESSION['dept_sctny'];
                                    $getsession = $_SESSION['getsession_sctny'];
                                    $getsemester = $_SESSION['getsemester_sctny'];
                                    $getlevel = $_SESSION['getlevel_sctny'];

                                    $sql = "SELECT DeptName, DeptCode FROM deptcoding WHERE DeptCode = '$getdept'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $deptname = $row["DeptName"];
                                        }
                                    }
                                    ?>

                                <div style="text-align: center">
                                    <h2 class="panel-title"><?php echo $deptname ?> Department</h2>
                                </div>
                                <br>
                                <div class="panel-body">
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="row">
                                            <div class="col-lg-6">

                                            </div>
                                            <label class="control-label col-lg-2" for="regid">Select Status:</label>
                                            <div class="col-lg-3">
                                                <select name="getstatus" class="form-control" style="color:#000000"
                                                    id="getstatus" required>
                                                    <option value='Yet'>Yet</option>
                                                    <option value='Approve'>Approve</option>
                                                    <option value='Not Approve'>Not Approve</option>

                                                </select>

                                            </div>
                                            <div class="col-lg-1" style="text-align: right">
                                                <button type="submit" name="submitAll"
                                                    class="btn btn-primary btn-xs">Submit All
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            Department: <?php echo $deptname; ?>
                                        </div>
                                        <div class="col-lg-2">
                                            Level: <?php echo $_SESSION['getlevel_sctny']; ?>
                                        </div>
                                        <div class="col-lg-3">
                                            Session: <?php echo $_SESSION['getsession_sctny']; ?>
                                        </div>
                                        <div class="col-lg-3">
                                            Semester: <?php echo $_SESSION['getsemester_sctny']; ?>
                                        </div>

                                    </div>
                                    <hr class="separator" />
                                    <br>
                                    <div class="col-lg-12">
                                        <?php
                                            unset($LblCodeArray);
                                            $LblCodeArray[] = "";
                                            unset($CourseCodeArray);
                                            $CourseCodeArray[] = "";
                                            $countCCode = 0;
                                            $deptgencourses = "gencourses";

                                            $sql = "SELECT * FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $countCCode++;
                                                    $CourseCodeArray[$countCCode] = $row["CCode"];
                                                    $CCode = $row["CCodeSepr"];
                                                    $LblCodeArray[$countCCode] = $CCode . " (" . $row["CUnit"] . ")";
                                                }
                                            }

                                            ?>
                                        <table class="table table-bordered table-striped mb-none"
                                            id="datatable-default">
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/ No</th>
                                                    <th style='text-align:center'>Matric_No</th>
                                                    <th style='text-align:center'>Name</th>
                                                    <th style="font-size: 10px">PCGPA</th>
                                                    <th style="font-size: 10px">SGPA</th>
                                                    <th style="font-size: 10px">CGPA</th>
                                                    <th>RMK</th>
                                                    <th>Deff. & Outstanding</th>
                                                    <th>Approval</th>
                                                    <th>Comment</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $sno = 0;
                                                    $DEFCount = 0;
                                                    $IGSCount = 0;
                                                    $SP1Count = 0;
                                                    $SP2Count = 0;
                                                    $PCount = 0;
                                                    $DLCount = 0;
                                                    $VCLCount = 0;
                                                    $Ten88Count = 0;
                                                    $BL2Count = 0;

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND secrutiny_aproval = 'Approve' ORDER BY Regn";
                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $regid = $row["Regn"];
                                                            $names = $row["Name1"];
                                                            $id = $row["sn"];
                                                            $aproval = $row['board_aproval'];
                                                            $coment = $row["board_comment"];

                                                            $defout = $def = $out = $rmk = $grade = "";


                                                            $unit = $ptct = $ptcp = $pgp = $pcgpa = $stct = $stcp = $sgp = $scgpa = $tct = $tcp = $tgp = $cgpa = 0;

                                                            $ptct = $row['PCT'];
                                                            $ptcp = $row['PCP'];
                                                            $pgp = $row['PGP'];
                                                            $pcgpa = $row['PCGPA'];

                                                            $stct = $row['SCT'];
                                                            $stcp = $row['SCP'];
                                                            $sgp = $row['SGP'];
                                                            $scgpa = $row['SGPA'];
                                                            $tct = $row['TCT'];
                                                            $tcp = $row['TCP'];
                                                            $tgp = $row['CGP'];
                                                            $cgpa = $row['CGPA'];
                                                            $rmk = $row['RMK'];
                                                            $defout = $row['def_out'];

                                                            if ($rmk == "P") {
                                                                $PCount++;
                                                                //$PtotCount++;
                                                            } elseif ($rmk == "IGS") {
                                                                $IGSCount++;
                                                                //IGStotCount = IGStotCount + 1
                                                            } elseif ($rmk == "DEF") {
                                                                $DEFCount++;
                                                                //DEFtotCount = DEFtotCount + 1
                                                            } elseif ($rmk == "SP1") {
                                                                $SP1Count++;
                                                                //SP1totCount = SP1totCount + 1
                                                            } elseif ($rmk == "SP2") {
                                                                $SP2Count++;
                                                                //SP2totCount = SP2totCount + 1
                                                            } elseif ($rmk == "DL") {
                                                                $DLCount++;
                                                                //DLtotCount = DLtotCount + 1
                                                            } elseif ($rmk == "VL") {
                                                                $VCLCount++;
                                                            } elseif ($rmk == "8-7-6") {
                                                                $Ten88Count++;
                                                            } elseif ($rmk == "BL2") {
                                                                $BL2Count++;
                                                            }

                                                            if ($ptct == 0) {
                                                                $ptct = "";
                                                                $ptcp = "";
                                                                $pgp = "";
                                                                $pcgpa = "";
                                                            } else {
                                                                $ptct = $row['PCT'];
                                                                $ptcp = $row['PCP'];
                                                                $pgp = $row['PGP'];
                                                                $pcgpa = $row['PCGPA'];
                                                            }
                                                            if ($stct == 0) {
                                                                $stct2 = "";
                                                                $stcp = "";

                                                                $Response = "";

                                                                $sql2 = "SELECT * FROM missing_session WHERE matno = '$regid' AND session = '$getsession' AND semester = '$getsemester'";
                                                                $result2 = $conn->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $Response = $row2["response"];
                                                                    }
                                                                }
                                                                if ($Response == "Deferment") {
                                                                    //$sgp="Defe";
                                                                    $scgpa = "Deferred";
                                                                } elseif ($Response == "Condonation") {
                                                                    //$sgp="Con";
                                                                    $scgpa = "Condole";
                                                                } elseif ($Response == "VolWithdrawal") {
                                                                    //$sgp="With";
                                                                    $scgpa = "Withdrawn";
                                                                } elseif ($Response == "PoorWithdrawal") {
                                                                    //$sgp="With";
                                                                    $scgpa = "Withdrawn";
                                                                } else {
                                                                    //$sgp="Abs";
                                                                    $scgpa = "Abscond";
                                                                }
                                                            } else {
                                                                $stct2 = $row['SCT'];
                                                                $stcp = $row['SCP'];
                                                                $sgp = $row['SGP'];
                                                                $scgpa = $row['SGPA'];
                                                            }



                                                            echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$regid </td><td> $names</td>";

                                                            if ($stct == 0) {
                                                                if ($Response == "Deferment" || $Response == "Condonation") {
                                                                    echo "<td>$pcgpa</td><td style='background-color: purple; color: white'>$scgpa</td><td>$cgpa</td><td>$rmk</td><td>$defout</td>";
                                                                } else {
                                                                    echo "<td>$pcgpa</td><td style='background-color: #9d1e15; color: white'>$scgpa</td><td>$cgpa</td><td>$rmk</td><td>$defout</td>";
                                                                }
                                                            } else {
                                                                echo "<td>$pcgpa</td><td>$scgpa</td><td>$cgpa</td><td>$rmk</td><td>$defout</td>";
                                                            }

                                                            echo '<td><a href="#" class="senate_aproval" id="senate_aproval_' . $row["sn"] . '" data-type="select" data-pk="' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="senate_aproval">' . $row["senate_aproval"] . '</a></td>
                                           <td><a href="#" class="senate_comment" id="senate_comment_' . $row["sn"] . '" data-type="text" data-pk = "' . $row["sn"] . '" data-url="inline_edit/process_sch_scrutiny_senate.php" data-name="senate_comment">' . $row["senate_comment"] . '</a></td>
                                          ';

                                                            echo "</tr>\n";
                                                        }
                                                    }
                                                    $SubTotal = $PCount + $IGSCount + $DEFCount + $SP1Count + $SP2Count + $DLCount + $VCLCount + $Ten88Count + $BL2Count;
                                                    //echo "<tr><td></td><td>";

                                                    //echo "</td></tr>";


                                                    ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div>
                                        <p style="font-size: 14px">
                                            <?php
                                                echo "SUMMARY<br>  VCL = " . $VCLCount . ",  DL = " . $DLCount . ",  IGS = " . $IGSCount . ",   DEF = " . $DEFCount . ",  P = " . $PCount . ",   SP1 = " . $SP1Count . ",  SP2 = " . $SP2Count . ",  10-8-8 = " . $Ten88Count . ",  BL2 = " . $BL2Count . ",  Total = " . $SubTotal;
                                                ?>
                                        </p>
                                    </div>


                                </div>
                                <br><br>
                                <div class="row" style="text-align: right">
                                    <form action='Print_rec/print_senate.php' method='post' target='_blank'>
                                        <input type='submit' name='print' class='btn btn-primary btn-xs'
                                            value='Print Preview'>
                                    </form>
                                </div>
                                <br><br>
                                <?php
$conn->close();
$conn2->close();
$conn_stu->close();
?>
                                <?php } ?>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
    //For Comment Table Column Data

    const senate_comment = document.getElementsByClassName('senate_comment');

    for (var count = 0; count < senate_comment.length; count++) {
        const senate_comment_data = document.getElementById(senate_comment[count].getAttribute('id'));

        const senate_comment_popover = new DarkEditable(senate_comment_data);
    }


    //For Approval Table column Data

    const senate_aproval = document.getElementsByClassName('senate_aproval');

    for (var count = 0; count < senate_aproval.length; count++) {
        const senate_aproval_data = document.getElementById(senate_aproval[count].getAttribute("id"));

        const senate_aproval_popover = new DarkEditable(senate_aproval_data, {
            source: [{
                    value: 'Yet',
                    text: 'Yet'
                },
                {
                    value: 'Approve',
                    text: 'Approve'
                },
                {
                    value: 'Not Approve',
                    text: 'Not Approve'
                }
            ]
        });
    }
    </script>
</body>

</html>
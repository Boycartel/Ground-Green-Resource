<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['HOD'] !== "YES" && $_SESSION['Examiner'] !== "YES" && $_SESSION['Administrator'] !== "YES" && $_SESSION['Sub_Admin'] !== "YES") {
    header('Location: home_staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Results View</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Results View</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Results View
                        </div>
                        <div class="panel-body">
                            <?php

                            if (isset($_POST["submitApr"])) {
                                $id = $_SESSION['id'];

                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                $sql2 = "UPDATE hod_semester_res_approval SET Approval ='YES' WHERE sn = '$id'";
                                $result2 = $conn->query($sql2);
                                $conn->close();
                                echo "<h3 style='color: blue'>Results Approved</h3>";
                            }

                            if (isset($_POST["submitCanc"])) {
                                $id = $_SESSION['id'];
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                $sql2 = "UPDATE hod_semester_res_approval SET Approval ='NO' WHERE sn = '$id'";
                                $result2 = $conn->query($sql2);
                                $conn->close();
                                echo "<h3 style='color: blue'>Approval Canceled</h3>";
                            }
                            ?>

                            <?php if (isset($_POST["view"])) { ?>
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $id = $_POST["id"];
                                $_SESSION['id'] = $id;

                                $sql = "SELECT * FROM hod_semester_res_approval WHERE sn = '$id'";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $_SESSION['getsession_sctny'] = $row["session_apprv"];
                                        $_SESSION['getsemester_sctny'] = $row["semester_apprv"];
                                        $_SESSION['getlevel_sctny'] = $row["Level_Apprv"];
                                        $_SESSION['getdeptoption'] = $row["deptoption"];
                                        $_SESSION['curriculum'] = $row["curriculum"];
                                    }
                                }

                                $_SESSION['sn'] = 0;

                                $deptname = "";

                                $getdept = $_SESSION['deptcode'];
                                $getsession = $_SESSION['getsession_sctny'];
                                $getsemester = $_SESSION['getsemester_sctny'];
                                $getlevel = $_SESSION['getlevel_sctny'];

                                $sql = "SELECT DeptName, DeptCode FROM deptcoding WHERE DeptCode = '$getdept'";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    // output data of each row
                                    while ($row = $result->fetch_assoc()) {
                                        $deptname = $row["DeptName"];
                                    }
                                }
                                ?>
                                <section>

                                    <div class="panel-body">

                                        <div class="row">
                                            <div class="col-lg-4">
                                                Department: <?php echo $deptname; ?>
                                            </div>
                                            <div class="col-lg-1">
                                                <?php if ($_SESSION['InstType'] == "University") { ?>
                                                    Level: <?php echo $_SESSION['getlevel_sctny']; ?>
                                                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                    <?php
                                                    if ($_SESSION['getlevel_sctny'] == 100) {
                                                        echo "Level: ND I";
                                                    } elseif ($_SESSION['getlevel_sctny'] == 200) {
                                                        echo "Level: ND II";
                                                    } elseif ($_SESSION['getlevel_sctny'] == 300) {
                                                        echo "Level: HND I";
                                                    } elseif ($_SESSION['getlevel_sctny'] == 400) {
                                                        echo "Level: HND II";
                                                    }
                                                    ?>
                                                <?php } ?>
                                            </div>
                                            <div class="col-lg-2">
                                                Session: <?php echo $_SESSION['getsession_sctny']; ?>
                                            </div>
                                            <div class="col-lg-1">
                                                Semester: <?php echo $_SESSION['getsemester_sctny']; ?>
                                            </div>
                                            <?php
                                            if ($_SESSION['deptoption'] == "YES") {
                                                $deptoption = $_SESSION['getdeptoption'];
                                                $sql2 = "SELECT * FROM dept_option WHERE deptcode =  '$getdept' AND Opt_Code = '$deptoption' ";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $OptTitle = $row2["Opt_Title"];
                                                    }
                                                }
                                            ?>
                                                <div class="col-lg-2">
                                                    Dept Option: <?php echo $OptTitle; ?>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                            <?php
                                            if ($_SESSION['curricul'] == "YES") {
                                                $curriculum = $_SESSION['curriculum'];
                                                $sql2 = "SELECT * FROM dept_curriculum WHERE deptcode = '$getdept' AND curri_Code = '$curriculum'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $curri_Title = $row2["curri_Title"];
                                                    }
                                                }
                                            ?>
                                                <div class="col-lg-2">
                                                    Curriculum: <?php echo $curri_Title; ?>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                        </div>
                                        <hr class="separator" />
                                        <br>
                                        <div class="col-lg-12 table-responsive">
                                            <?php

                                            unset($LblCodeArray);
                                            $LblCodeArray[] = "";
                                            unset($CourseCodeArray);
                                            $CourseCodeArray[] = "";
                                            $countCCode = 0;

                                            //$deptgencourses = $getdept . "_gencourses";

                                            $sql = "SELECT DISTINCT CCode, session1, Level1, DeptCode, SemTaken, levelCode, split_two, CUnit FROM grade_cursem WHERE session1  = '$getsession' AND SemTaken = '$getsemester' AND Level1 =  '$getlevel' AND DeptCode =  '$getdept' ORDER BY levelCode DESC";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $countCCode++;
                                                    $CourseCodeArray[$countCCode] = $row["CCode"];
                                                    $CCode = $row["split_two"];
                                                    $LblCodeArray[$countCCode] = $CCode . " (" . $row["CUnit"] . ")";
                                                }
                                            }

                                            ?>
                                            <table class="table table-striped table-bordered table-hover dataTables-example">
                                                <thead style='text-align:center'>
                                                    <tr>
                                                        <th>S/ No</th>
                                                        <th>Matric_No/ Name</th>

                                                        <?php for ($i = 1; $i <= $countCCode; $i++) { ?>
                                                            <th style="font-size: 10px"><?php echo $LblCodeArray[$i] ?></th>
                                                        <?php } ?>
                                                        <?php if ($getlevel == 200) { ?>
                                                            <th style="font-size: 10px">100L CGPA</th>
                                                        <?php } ?>
                                                        <?php if ($getlevel == 300) { ?>
                                                            <th style="font-size: 10px">100L CGPA</th>
                                                            <th style="font-size: 10px">200L CGPA</th>
                                                        <?php } ?>
                                                        <?php if ($getlevel == 400) { ?>
                                                            <th style="font-size: 10px">100L CGPA</th>
                                                            <th style="font-size: 10px">200L CGPA</th>
                                                            <th style="font-size: 10px">300L CGPA</th>
                                                        <?php } ?>
                                                        <?php if ($getlevel == 500) { ?>
                                                            <th style="font-size: 10px">100L CGPA</th>
                                                            <th style="font-size: 10px">200L CGPA</th>
                                                            <th style="font-size: 10px">300L CGPA</th>
                                                            <th style="font-size: 10px">400L CGPA</th>
                                                        <?php } ?>
                                                        <th style="font-size: 10px">PCT</th>
                                                        <th style="font-size: 10px">PCP</th>
                                                        <th style="font-size: 10px">PGP</th>
                                                        <th style="font-size: 10px">PCGPA</th>
                                                        <th style="font-size: 10px">SCT</th>
                                                        <th style="font-size: 10px">SCP</th>
                                                        <th style="font-size: 10px">SGP</th>
                                                        <th style="font-size: 10px">SGPA</th>
                                                        <th style="font-size: 10px">TCT</th>
                                                        <th style="font-size: 10px">TCP</th>
                                                        <th style="font-size: 10px">TGP</th>
                                                        <th style="font-size: 10px">CGPA</th>
                                                        <th>RMK</th>
                                                        <th>Deficiency/Outstanding</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $sno = 0;
                                                    $DEFCount = 0;
                                                    $IGSCount = 0;
                                                    $SP1Count = 0;
                                                    $SP2Count = 0;
                                                    $PCount = 0;
                                                    $DLCount = 0;
                                                    $VCLCount = 0;
                                                    $Ten88Count = 0;
                                                    $BL2Count = 0;

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    if ($_SESSION['deptoption'] == "YES") {
                                                        $getdeptoption =  $_SESSION["getdeptoption"];
                                                        if ($_SESSION['curricul'] == "YES") {
                                                            $curri = $_SESSION["curriculum"];
                                                            $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND curriculum = '$curri' ORDER BY Regn";
                                                        } else {
                                                            $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND DeptOpt = '$getdeptoption' ORDER BY Regn";
                                                        }
                                                    } else {
                                                        if ($_SESSION['curricul'] == "YES") {
                                                            $curri = $_SESSION['curriculum'];
                                                            $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' AND curriculum = '$curri' ORDER BY Regn";
                                                        } else {
                                                            $sql = "SELECT * FROM scrutiny_senate WHERE Level1 = '$getlevel' AND session1 = '$getsession' AND semester = '$getsemester' ORDER BY Regn";
                                                        }
                                                    }


                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $regid = $row["Regn"];
                                                            $names = $row["Name1"];
                                                            $id = $row["sn"];
                                                            $aproval = $row['board_aproval'];
                                                            $coment = $row["board_comment"];

                                                            $defout = $def = $out = $rmk = $grade = "";


                                                            $unit = $ptct = $ptcp = $pgp = $pcgpa = $stct = $stcp = $sgp = $scgpa = $tct = $tcp = $tgp = $cgpa = 0;
                                                            $cgpa100 = $row['CGPA100'];
                                                            $cgpa200 = $row['CGPA200'];
                                                            $cgpa300 = $row['CGPA300'];
                                                            $cgpa400 = $row['CGPA400'];

                                                            $ptct = $row['PCT'];
                                                            $ptcp = $row['PCP'];
                                                            $pgp = $row['PGP'];
                                                            $pcgpa = $row['PCGPA'];

                                                            $stct = $row['SCT'];
                                                            $stcp = $row['SCP'];
                                                            $sgp = $row['SGP'];
                                                            $scgpa = $row['SGPA'];
                                                            $tct = $row['TCT'];
                                                            $tcp = $row['TCP'];
                                                            $tgp = $row['CGP'];
                                                            $cgpa = $row['CGPA'];
                                                            $rmk = $row['RMK'];
                                                            $defout = $row['def_out'];

                                                            if ($rmk == "P") {
                                                                $PCount++;
                                                            } elseif ($rmk == "IGS") {
                                                                $IGSCount++;
                                                            } elseif ($rmk == "DEF") {
                                                                $DEFCount++;
                                                            } elseif ($rmk == "SP1") {
                                                                $SP1Count++;
                                                            } elseif ($rmk == "SP2") {
                                                                $SP2Count++;
                                                            } elseif ($rmk == "DL") {
                                                                $DLCount++;
                                                            } elseif ($rmk == "VL") {
                                                                $VCLCount++;
                                                            } elseif ($rmk == "8-7-6") {
                                                                $Ten88Count++;
                                                            } elseif ($rmk == "BL2") {
                                                                $BL2Count++;
                                                            }

                                                            if ($ptct == 0) {
                                                                $ptct = "";
                                                                $ptcp = "";
                                                                $pgp = "";
                                                                $pcgpa = "";
                                                            } else {
                                                                $ptct = $row['PCT'];
                                                                $ptcp = $row['PCP'];
                                                                $pgp = $row['PGP'];
                                                                $pcgpa = $row['PCGPA'];
                                                            }
                                                            if ($stct == 0) {
                                                                $stct2 = "";
                                                                $stcp = "";

                                                                $Response = "";

                                                                $sql2 = "SELECT * FROM missing_session WHERE matno = '$regid' AND session = '$getsession' AND semester = '$getsemester'";
                                                                $result2 = $conn->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $Response = $row2["response"];
                                                                    }
                                                                }
                                                                if ($Response == "Deferment") {
                                                                    $sgp = "Defe";
                                                                    $scgpa = "rred";
                                                                } elseif ($Response == "Condonation") {
                                                                    $sgp = "Con";
                                                                    $scgpa = "done";
                                                                } elseif ($Response == "VolWithdrawal") {
                                                                    $sgp = "With";
                                                                    $scgpa = "drawn";
                                                                } elseif ($Response == "PoorWithdrawal") {
                                                                    $sgp = "With";
                                                                    $scgpa = "drawn";
                                                                } else {
                                                                    $sgp = "Abs";
                                                                    $scgpa = "cond";
                                                                }
                                                            } else {
                                                                $stct2 = $row['SCT'];
                                                                $stcp = $row['SCP'];
                                                                $sgp = $row['SGP'];
                                                                $scgpa = $row['SGPA'];
                                                            }
                                                            if ($_SESSION['InstType'] == "Polytechnic") {
                                                                if ($rmk == "VL") {
                                                                    $rmk = "RHL";
                                                                }
                                                                if ($rmk == "DL") {
                                                                    $rmk = "DHL";
                                                                }
                                                                if ($rmk == "DEF") {
                                                                    $rmk = "COV";
                                                                }
                                                            }


                                                            echo "<tr><td>$sno</td><td>$regid <br> $names</td>";
                                                            for ($i = 1; $i <= $countCCode; $i++) {
                                                                $grade = "-";

                                                                $StuCurSess = str_ireplace("/", "_", $getsession);
                                                                $deptcorreg = "correg_" . $StuCurSess;
                                                                $sql2 = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND CCode  = '$CourseCodeArray[$i]' AND SemTaken = '$getsemester' AND SessionRegis =  '$getsession'";

                                                                //$sql2 = "SELECT * FROM ".$getdept."_cursem_grade WHERE regn = '$regid' AND session1 = '$getsession' AND SemTaken = '$getsemester' AND CCode = '$CourseCodeArray[$i]'";
                                                                $result2 = $conn_stu->query($sql2);
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $grade = $row2["grade"];
                                                                    }
                                                                }
                                                                echo "<td>$grade</td>";
                                                            }
                                                            if ($getlevel == 200) {
                                                                echo "<td>$cgpa100</td>";
                                                            } elseif ($getlevel == 300) {
                                                                echo "<td>$cgpa100</td><td>$cgpa200</td>";
                                                            } elseif ($getlevel == 400) {
                                                                echo "<td>$cgpa100</td><td>$cgpa200</td><td>$cgpa300</td>";
                                                            } elseif ($getlevel == 500) {
                                                                echo "<td>$cgpa100</td><td>$cgpa200</td><td>$cgpa300</td><td>$cgpa400</td>";
                                                            }
                                                            if ($stct == 0) {
                                                                if ($Response == "Deferment" || $Response == "Condonation") {
                                                                    echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td style='background-color: purple; color: white'>$sgp</td><td style='background-color: purple; color: white'>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$rmk</td><td>$defout</td>";
                                                                } else {
                                                                    echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td style='background-color: #9d1e15; color: white'>$sgp</td><td style='background-color: #9d1e15; color: white'>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$rmk</td><td>$defout</td>";
                                                                }
                                                            } else {
                                                                echo "<td>$ptct</td><td>$ptcp</td><td>$pgp</td><td>$pcgpa</td><td>$stct2</td><td>$stcp</td><td>$sgp</td><td>$scgpa</td><td>$tct</td><td>$tcp</td><td>$tgp</td><td>$cgpa</td><td>$rmk</td><td>$defout</td>";
                                                            }

                                                            echo "</tr>\n";
                                                        }
                                                    }
                                                    $SubTotal = $PCount + $IGSCount + $DEFCount + $SP1Count + $SP2Count + $DLCount + $VCLCount + $Ten88Count + $BL2Count;

                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div>
                                            <p style="font-size: 14px">
                                                <?php
                                                if ($_SESSION['InstType'] == "University") {
                                                    echo "SUMMARY<br>  VCL = " . $VCLCount . ",  DL = " . $DLCount . ",  IGS = " . $IGSCount . ",   DEF = " . $DEFCount . ",  P = " . $PCount . ",   SP1 = " . $SP1Count . ",  SP2 = " . $SP2Count . ",  10-8-8 = " . $Ten88Count . ",  BL2 = " . $BL2Count . ",  Total = " . $SubTotal;
                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                    echo "SUMMARY<br>  RHL = " . $VCLCount . ",  DHL = " . $DLCount . ",  IGS = " . $IGSCount . ",   COV = " . $DEFCount . ",  P = " . $PCount . ",   SP1 = " . $SP1Count . ",  SP2 = " . $SP2Count . ",  Total = " . $SubTotal;
                                                }

                                                ?>
                                            </p>
                                        </div>


                                    </div>
                                    <br><br>
                                    <div class="row">
                                        <?php
                                        $id = $_SESSION['id'];
                                        $sql = "SELECT * FROM hod_semester_res_approval WHERE sn = '$id'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $approval = $row["Approval"];
                                            }
                                        }
                                        ?>
                                        <div class="col-lg-8">
                                            <?php if ($_SESSION['InstType'] == "University") { ?>
                                                <ul>
                                                    <li><b>VCL:</b> VC's List</li>
                                                    <li><b>DL:</b> Dean's List</li>
                                                    <li><b>IGS:</b> In Good Standing</li>
                                                    <li><b>DEF:</b> Defficiency and Outstanding</li>
                                                    <li><b>P:</b> Semester Probation</li>
                                                    <li><b>SP1:</b> Sessional Probation I</li>
                                                    <li><b>SP2:</b> Sessional Probation II (Withdrawal)</li>
                                                    <li><b>10-8-8:</b> For Engineering units paased. 10 Mathematics, 8 Physics
                                                        and 8 Chemistry</li>
                                                    <li><b>BL2:</b> For Engineering, CGPA below 2.00</li>

                                                </ul>
                                            <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                <ul>
                                                    <li><b>RHL:</b> Rector's List</li>
                                                    <li><b>DHL:</b> Dean's List</li>
                                                    <li><b>IGS:</b> In Good Standing</li>
                                                    <li><b>COV:</b> Defficiency and Outstanding</li>
                                                    <li><b>P:</b> Semester Probation</li>
                                                    <li><b>SP1:</b> Sessional Probation I</li>
                                                    <li><b>SP2:</b> Sessional Probation II (Withdrawal)</li>

                                                </ul>
                                            <?php } ?>

                                        </div>
                                        <div class="col-lg-4">
                                            <div class="row">
                                                <div class="col-lg-8" style="text-align: right;">
                                                    <form action='' method='post'>
                                                        <?php if ($_SESSION['cat'] == "Administrator" || $_SESSION['cat'] == "HOD" || $_SESSION['cat'] == "HODLAdvice" || $_SESSION['cat'] == "HODDean" || $_SESSION['cat'] == "PGHOD") { ?>
                                                            <?php if ($approval == "YES") { ?>
                                                                <button type="submit" name="submitCanc" class="btn btn-success btn-sm">Cancel
                                                                    Approval</button>
                                                            <?php } else { ?>
                                                                <button type="submit" name="submitApr" class="btn btn-primary btn-sm">Approve</button>
                                                            <?php } ?>
                                                        <?php } ?>
                                                    </form>
                                                </div>
                                                <div class="col-lg-4" style="text-align:inherit;">
                                                    <form action='Print_rec/print_schboard.php' method='post' target='_blank'>
                                                        <input type='submit' name='print_appr' class='btn btn-info btn-sm' value='Print'>
                                                    </form>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                    <br><br>
                                </section>
                                <?php
                                $conn->close();
                                $conn_stu->close();
                                ?>
                            <?php } ?>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
        $(document).ready(function() {
            $('.dataTables-example').DataTable({
                pageLength: 25,
                responsive: true,
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [{
                        extend: 'copy'
                    },
                    {
                        extend: 'csv'
                    },
                    {
                        extend: 'excel',
                        title: 'ExampleFile'
                    },

                    {
                        extend: 'print',
                        customize: function(win) {
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                        }
                    }
                ]

            });

        });
    </script>
</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title><?php echo $_SESSION['instcode'] ?> Portal</title>
    <meta name="keywords" content="FUTMinna Result" />
    <meta name="description" content="FUT Minna e-Results Portal">
    <meta name="author" content="Adamu">
    <meta name="keyword"
        content="FUT, FUTMinna, Minna, Results, Result, eresults, e-results, portal, Federal, University, Technolgy">
    <link rel="shortcut icon" href="img/logo.ico">

    <!-- Bootstrap CSS -->
    <link href="inline_edit/library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
    <script src="inline_edit/library/bootstrap-5/bootstrap.bundle.min.js"></script>
    <script src="inline_edit/library/moment.js"></script>
    <link rel="stylesheet" href="inline_edit/library/dark-editable/dark-editable.css" />
    <script src="inline_edit/library/dark-editable/dark-editable.js"></script>




    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
        <form class="form-horizontal form-bordered" method="post">

            <div class="row">
                <h2 class="panel-title" style="text-align: center">Setup Courses</h2>
                <br><br><br>

            </div>
        </form>
        <hr class="separator" />
    </div>

    <div style="padding-left:3em; padding-right: 3em">


        <?php
        $dept = $_SESSION['deptcode'];
        $deptoption = $_SESSION['deptoption'];
        $DegType = $_SESSION['DegType'];

        

                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

        $_SESSION['yesCurri'] = "NO";
        $yesCurri = "NO";
        $sql = "SELECT DeptName, DeptCode, curriculum FROM deptcoding WHERE DeptCode = '$dept'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $deptname = $row["DeptName"];
                $yesCurri = $row["curriculum"];
                $_SESSION['yesCurri'] = $yesCurri;
            }
        }
$conn->close();

        ?>

        <div style="text-align: center">
            <h2 class="panel-title"><?php echo $deptname ?> Department</h2>
        </div>
        <br>
        <div class="panel-body">


            <br>
            <div class="col-lg-12">
                <?php
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                if ($conn_stu->connect_error) {
                    die("Connection failed: " . $conn_stu->connect_error);
                }
                ?>
                <?php if ($yesCurri == "YES") { ?>
                <?php if (isset($_POST["submitcurri"])) { ?>
                <?php
                        $curri = $_POST["curri"];
                        $_SESSION['curri'] = $curri;

                        if ($curri == "OLD") {
                            $curri2 = "";
                        } else {
                            $curri2 = "_" . $curri;
                        }
                    

                   
                        $sql = "SELECT * FROM dept_curriculum WHERE curri_Code = '$curri' AND deptcode = '$dept'";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $curriname2 = $row["curri_Title"];
                            }
                        }
                        ?>
                <div style="text-align: center">
                    <h2 class="panel-title"><?php echo $curriname2 ?></h2>
                </div>
                <table class="table table-bordered table-striped mb-none">
                    <thead style='text-align:center'>
                        <tr>
                            <th>S/ No</th>
                            <th style='text-align:center'>Course Code</th>
                            <th style='text-align:center'>Course Title</th>
                            <th>Unit</th>
                            <th>Semester</th>
                            <th>Nature</th>
                            <th>Level</th>
                            <th>Relevant</th>
                            <?php if ($_SESSION['InstType'] == "University") { ?>
                            <th>Core UME</th>
                            <th>Core DE200</th>
                            <th>Core DE300</th>
                            <?php if ($DegType == "BEng") { ?>
                            <th>Ten88</th>
                            <?php } ?>
                            <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                            <th>Core</th>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                                $sno = 0;

                                $sql = "SELECT * FROM gencourses" . $curri2 . " ORDER BY Level1, C_codding";
                                $result = $conn_stu->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $sno++;
                                        $C_codding = $row["C_codding"];
                                        $C_title = $row["C_title"];
                                        $id = $row["id"];
                                        $credit = $row['credit'];
                                        $semester = $row["semester"];
                                        $Nature1 = $row["Nature1"];
                                        $Level1 = $row["Level1"];


                                        //$Ten88 = $row["Ten88"];

                                        echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$C_codding </td><td> $C_title</td>";
                                        echo '<td><a href="#" class="credit" id="credit_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="credit">' . $credit . '</a></td>';
                                        echo '<td><a href="#" class="semester" id="semester_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="semester">' . $row["semester"] . '</a></td>';
                                        echo '<td><a href="#" class="Nature1" id="Nature1_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Nature1">' . $row["Nature1"] . '</a></td>';
                                        echo '<td><a href="#" class="Level1" id="Level1_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Level1">' . $Level1 . '</a></td>';
                                        echo '<td><a href="#" class="Relevant" id="Relevant_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Relevant">' . $row["Relevant"] . '</a></td>';
                                        if ($_SESSION['InstType'] == "University") {
                                        echo '<td><a href="#" class="Core" id="Core_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Core">' . $row["Core"] . '</a></td>';
                                        echo '<td><a href="#" class="CoreDE200" id="CoreDE200_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="CoreDE200">' . $row["CoreDE200"] . '</a></td>';
                                        echo '<td><a href="#" class="CoreDE300" id="CoreDE300_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="CoreDE300">' . $row["CoreDE300"] . '</a></td>';
                                        if ($DegType == "BEng") {
                                            echo '<td><a href="#" class="Ten88" id="Ten88_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Ten88">' . $row["Ten88"] . '</a></td>';
                                        }
                                        } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                            echo '<td><a href="#" class="Core" id="Core_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Core">' . $row["Core"] . '</a></td>';
                                        }
                                        echo "</tr>\n";
                                    }
                                }


                                ?>
                    </tbody>
                </table>
                <?php } else { ?>
                <form class="form-horizontal form-bordered" method="post">
                    <div class="row">
                        <div class="col-lg-2">

                        </div>

                        <label class="control-label col-lg-2" for="content">Select
                            Curriculum:</label>
                        <div class="col-lg-4">
                            <select class="form-control" style="color:#000000" name="curri">
                                <option value="SelectItem">Select Item</option>
                                <?php
                                        //$cat = $_SESSION['cat'];
                                        $dept = $_SESSION['deptcode'];

                                        $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $curricode2 = $row["curri_Code"];
                                                $curriname2 = $row["curri_Title"];
                                                echo "<option value=$curricode2>$curriname2</option>";
                                            }
                                        }
                                        ?>

                            </select>
                        </div>
                        <div class="col-lg-2">
                            <button type="submit" name="submitcurri" class="btn btn-primary btn-sm">Submit</button>

                        </div>
                        <div class="col-lg-2">

                        </div>
                    </div>
                </form>
                <?php } ?>

                <?php } else { ?>
                <table class="table table-bordered table-striped mb-none">
                    <thead style='text-align:center'>
                        <tr>
                            <th>S/ No</th>
                            <th style='text-align:center'>Course Code</th>
                            <th style='text-align:center'>Course Title</th>
                            <th>Unit</th>
                            <th>Semester</th>
                            <th>Nature</th>
                            <th>Level</th>
                            <th>Relevant</th>
                            <?php if ($_SESSION['InstType'] == "University") { ?>
                            <th>Core UME</th>
                            <th>Core DE200</th>
                            <th>Core DE300</th>
                            <?php if ($DegType == "BEng") { ?>
                            <th>Ten88</th>
                            <?php } ?>
                            <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                            <th>Core</th>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $sno = 0;

                            $sql = "SELECT * FROM gencourses ORDER BY Level1, C_codding";
                            $result = $conn_stu->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $sno++;
                                    $C_codding = $row["C_codding"];
                                    $C_title = $row["C_title"];
                                    $id = $row["id"];
                                    $credit = $row['credit'];
                                    $semester = $row["semester"];
                                    $Nature1 = $row["Nature1"];
                                    $Level1 = $row["Level1"];
                                    /* if ($_SESSION['InstType'] == "Polytechnic") {
                                        if ($Level1 == 100) {
                                            $Level2 = "ND I";
                                        } elseif ($Level1 == 200) {
                                            $Level2 = "ND II";
                                        } elseif ($Level1 == 300) {
                                            $Level2 = "HND I";
                                        } elseif ($Level1 == 400) {
                                            $Level2 = "HND II";
                                        }
                                    } */
                                    //$Ten88 = $row["Ten88"];

                                    echo "<tr><td style='text-align:center'>$sno</td><td style='text-align:center'>$C_codding </td><td> $C_title</td>";
                                    echo '<td><a href="#" class="credit" id="credit_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="credit">' . $credit . '</a></td>';
                                    echo '<td><a href="#" class="semester" id="semester_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="semester">' . $row["semester"] . '</a></td>';
                                    echo '<td><a href="#" class="Nature1" id="Nature1_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Nature1">' . $row["Nature1"] . '</a></td>';
                                    echo '<td><a href="#" class="Level1" id="Level1_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Level1">' . $Level1 . '</a></td>';
                                    echo '<td><a href="#" class="Relevant" id="Relevant_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Relevant">' . $row["Relevant"] . '</a></td>';
                                    if ($_SESSION['InstType'] == "University") {
                                    echo '<td><a href="#" class="Core" id="Core_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Core">' . $row["Core"] . '</a></td>';
                                    echo '<td><a href="#" class="CoreDE200" id="CoreDE200_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="CoreDE200">' . $row["CoreDE200"] . '</a></td>';
                                    echo '<td><a href="#" class="CoreDE300" id="CoreDE300_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="CoreDE300">' . $row["CoreDE300"] . '</a></td>';
                                    if ($DegType == "BEng") {
                                        echo '<td><a href="#" class="Ten88" id="Ten88_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Ten88">' . $row["Ten88"] . '</a></td>';
                                    }
                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                        echo '<td><a href="#" class="Core" id="Core_' . $row["id"] . '" data-type="select" data-pk="' . $row["id"] . '" data-url="inline_edit/process_gencourses.php" data-name="Core">' . $row["Core"] . '</a></td>';
                                    }
                                    echo "</tr>\n";
                                }
                            }


                            ?>
                    </tbody>
                </table>
                <?php } ?>
                <?php
$conn->close();
$conn_stu->close();
?>
            </div>


        </div>

    </div>



    <script>
    //For Credit Unit Table column Data

    const credit = document.getElementsByClassName('credit');

    for (var count = 0; count < credit.length; count++) {
        const credit_data = document.getElementById(credit[count].getAttribute("id"));

        const credit_popover = new DarkEditable(credit_data, {
            source: [{
                    value: '1',
                    text: '1'
                },
                {
                    value: '2',
                    text: '2'
                },
                {
                    value: '3',
                    text: '3'
                },
                {
                    value: '4',
                    text: '4'
                },
                {
                    value: '5',
                    text: '5'
                },
                {
                    value: '6',
                    text: '6'
                }
            ]
        });
    }
    </script>
    <script>
    //For semester Table column Data

    const semester = document.getElementsByClassName('semester');

    for (var count = 0; count < semester.length; count++) {
        const semester_data = document.getElementById(semester[count].getAttribute("id"));

        const semester_popover = new DarkEditable(semester_data, {
            source: [{
                    value: '1ST',
                    text: '1ST'
                },
                {
                    value: '2ND',
                    text: '2ND'
                }
            ]
        });
    }
    </script>

    <script>
    //For Nature1 Table column Data

    const Nature1 = document.getElementsByClassName('Nature1');

    for (var count = 0; count < Nature1.length; count++) {
        const Nature1_data = document.getElementById(Nature1[count].getAttribute("id"));

        const Nature1_popover = new DarkEditable(Nature1_data, {
            source: [
                <?php
                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                    $dept = $_SESSION['deptcode'];
                    if ($_SESSION['InstType'] == "University") {
                        if ($_SESSION['yesCurri'] == "YES") {
                            $curri = $_SESSION['curri'];
                            $sql = "SELECT * FROM requirement_tab WHERE DeptCode = '$dept' AND curri_Code = '$curri'";
                        } else {
                            $sql = "SELECT * FROM requirement_tab WHERE DeptCode = '$dept' AND curri_Code = 'OLD'";
                        }
                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                        if ($_SESSION['yesCurri'] == "YES") {
                            $curri = $_SESSION['curri'];
                            $sql = "SELECT * FROM requirement_tab_poly WHERE DeptCode = '$dept' AND curri_Code = '$curri'";
                        } else {
                            $sql = "SELECT * FROM requirement_tab_poly WHERE DeptCode = '$dept' AND curri_Code = 'OLD'";
                        }
                    }
                    $result = $conn->query($sql);
                    $Add1 = 0;
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $requireCode = $row["Requirement_Code"];
                    ?> {
                    value: '<?php echo $requireCode ?>',
                    text: '<?php echo $requireCode ?>'
                },
                <?php
                        }
                    }
                    $conn->close();
                    ?>

            ]
        });
    }
    </script>

    <script>
    //For Level1 Table column Data

    const Level1 = document.getElementsByClassName('Level1');

    for (var count = 0; count < Level1.length; count++) {
        const Level1_data = document.getElementById(Level1[count].getAttribute("id"));

        const Level1_popover = new DarkEditable(Level1_data, {

            source: [
                <?php if ($_SESSION['InstType'] == "University") { ?> {
                    value: '100',
                    text: '100'
                },
                {
                    value: '200',
                    text: '200'
                },
                {
                    value: '300',
                    text: '300'
                },
                {
                    value: '400',
                    text: '400'
                },
                {
                    value: '500',
                    text: '500'
                }
                <?php } elseif ($_SESSION['InstType'] == "Polytechnic") { ?> {
                    value: '100',
                    text: 'ND I'
                },
                {
                    value: '200',
                    text: 'ND II'
                },
                {
                    value: '300',
                    text: 'HND I'
                },
                {
                    value: '400',
                    text: 'HND II'
                }
                <?php } else { ?>
                <?php } ?>
            ]


        });
    }
    </script>

    <script>
    //For Relevant Table column Data

    const Relevant = document.getElementsByClassName('Relevant');

    for (var count = 0; count < Relevant.length; count++) {
        const Relevant_data = document.getElementById(Relevant[count].getAttribute("id"));

        const Relevant_popover = new DarkEditable(Relevant_data, {
            source: [{
                    value: 'NO',
                    text: 'NO'
                },
                {
                    value: 'YES',
                    text: 'YES'
                }
            ]
        });
    }
    </script>

    <script>
    //For Core Table column Data

    const Core = document.getElementsByClassName('Core');

    for (var count = 0; count < Core.length; count++) {
        const Core_data = document.getElementById(Core[count].getAttribute("id"));

        const Core_popover = new DarkEditable(Core_data, {
            source: [{
                    value: 'NO',
                    text: 'NO'
                },
                {
                    value: 'YES',
                    text: 'YES'
                }
            ]
        });
    }
    </script>

    <script>
    //For CoreDE200 Table column Data

    const CoreDE200 = document.getElementsByClassName('CoreDE200');

    for (var count = 0; count < CoreDE200.length; count++) {
        const CoreDE200_data = document.getElementById(CoreDE200[count].getAttribute("id"));

        const CoreDE200_popover = new DarkEditable(CoreDE200_data, {
            source: [{
                    value: 'NO',
                    text: 'NO'
                },
                {
                    value: 'YES',
                    text: 'YES'
                }
            ]
        });
    }
    </script>

    <script>
    //For CoreDE300 Table column Data

    const CoreDE300 = document.getElementsByClassName('CoreDE300');

    for (var count = 0; count < CoreDE300.length; count++) {
        const CoreDE300_data = document.getElementById(CoreDE300[count].getAttribute("id"));

        const CoreDE300_popover = new DarkEditable(CoreDE300_data, {
            source: [{
                    value: 'NO',
                    text: 'NO'
                },
                {
                    value: 'YES',
                    text: 'YES'
                }
            ]
        });
    }
    </script>

    <script>
    //For Ten88 Table column Data

    const Ten88 = document.getElementsByClassName('Ten88');

    for (var count = 0; count < Ten88.length; count++) {
        const Ten88_data = document.getElementById(Ten88[count].getAttribute("id"));

        const Ten88_popover = new DarkEditable(Ten88_data, {
            source: [{
                    value: 'NO',
                    text: 'NO'
                },
                {
                    value: 'Mathematics',
                    text: 'Mathematics'
                },
                {
                    value: 'Physics',
                    text: 'Physics'
                },
                {
                    value: 'Chemistry',
                    text: 'Chemistry'
                }

            ]
        });
    }
    </script>
</body>

</html>
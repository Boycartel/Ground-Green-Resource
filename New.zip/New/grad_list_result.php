<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['grad_list_result'] == false) {
    header('Location: home_staff.php');
}

?>



<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Graduated Students Result</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Graduated Students Result</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Graduated Students Result
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-1">
                                </div>
                                <div class="col-md-10">
                                    <div style="padding-left:3em; padding-right: 3em; padding-top: 3em">
                                        <form class="form-horizontal form-bordered" method="post">
                                            <div class="row">

                                                <div class="col-lg-4">
                                                    <div class="row">
                                                        <label class="control-label col-lg-5">Year of
                                                            Graduation:</label>
                                                        <div class="col-lg-7">
                                                            <?php
                                                            $iniyear = 2015;
                                                            $finalyear = substr($_SESSION['corntsession'], 5) + 1;
                                                            ?>
                                                            <select name="getyeargrad" class="form-control"
                                                                style="color:#000000" id="getyeargrad">
                                                                <option value="<?php echo $finalyear ?>">
                                                                    <?php echo $finalyear ?></option>
                                                                <?php
                                                                while ($iniyear <= $finalyear) {
                                                                    $addyear = $iniyear + 1;

                                                                    echo "<option value = '$iniyear'>$iniyear</option>";
                                                                    $iniyear++;
                                                                }

                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="row">
                                                        <label class="control-label col-lg-5" for="content">Select
                                                            Semester:</label>
                                                        <div class="col-lg-7">
                                                            <select class="form-control" style="color:#000000"
                                                                name="semesterSel" required="required">
                                                                <option value="">Select Item</option>
                                                                <option value="1ST">1ST</option>
                                                                <option value="2ND">2ND</option>

                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4">
                                                    <div class="row">

                                                        <div class="col-lg-4">
                                                            <button type="submit" name="submit"
                                                                class="btn btn-primary btn-sm">Submit</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                        </form>
                                    </div>
                                    <hr class="separator" />
                                    <div style="padding-left:3em; padding-right: 3em;">

                                        <?php if (isset($_POST["submit"])) { ?>
                                        <?php
                                            $getyeargrad = $_POST["getyeargrad"];
                                            $semesterSel = $_POST["semesterSel"];
                                            $getdept = $_SESSION['deptcode'];
                                            ?>
                                        <div class="col-lg-12">

                                            <div class="col-lg-4">
                                                <h5><b>Year of Graduation: <?php echo $getyeargrad; ?></b></h5>
                                            </div>
                                            <div class="col-lg-5">
                                                <h5><b>Semester: <?php echo $semesterSel; ?></b></h5>
                                            </div>
                                        </div>

                                        <div class="col-lg-12">
                                            <table class="table table-bordered table-striped mb-none"
                                                id="datatable-default">
                                                <thead style='text-align:center'>
                                                    <tr>
                                                        <th>S/No</th>
                                                        <th>Matric No</th>
                                                        <th>Name</th>
                                                        <th>CGPA</th>
                                                        <?php if ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                        <th>Programme</th>
                                                        <?php } ?>
                                                        <th>Action</th>


                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php

                                                        $sno = 0;
                                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                        if ($conn_stu->connect_error) {
                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                        }

                                                        $sql = "SELECT * FROM scrutiny_senate WHERE yearGrad = '$getyeargrad' AND semester = '$semesterSel' AND graduated = 'YES' ORDER BY Regn";
                                                        $result = $conn_stu->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $regid = $row["Regn"];
                                                                $names = $row["Name1"];
                                                                if ($semesterSel == "1ST") {
                                                                    $ccgpa = $row['CGPA_grad_1st'];
                                                                } else {
                                                                    $ccgpa = $row['CGPA'];
                                                                }

                                                                echo "<tr><td>$sno</td><td>$regid</td><td>$names</td><td>$ccgpa</td>";
                                                                if ($_SESSION['InstType'] == "Polytechnic") {
                                                                    $mode_entry = $row["mode_entry"];
                                                                    echo "<td>$mode_entry</td>";
                                                                }
                                                                echo "<td>
                                                                <form action='spreadsheet_grad_view.php' method='post' target='_blank'>
                                                                    <input type='hidden' value='$regid' name='id'>
                                                                    
                                                                    <input type='submit' name='view' class='btn btn-info btn-xs' value='View'>
                                                                </form>
                                                                </td>";

                                                                echo "</tr>\n";
                                                            }
                                                        }
$conn_stu->close();

                                                        ?>
                                                </tbody>
                                            </table>
                                        </div>

                                        <?php } ?>

                                    </div>
                                </div>
                                <div class="col-md-1">
                                </div>


                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';

//header('Location:home_stu.php');
/* if ($_SESSION['logintype'] == "student") {
    $sql2 = "SELECT * FROM setting WHERE CourseREg = 'Closed'";
    $result2 = $conn->query($sql2);
    if ($result2->num_rows == 0) {
        header('Location:home_stu.php');
    }
} */


require_once("dompdf/autoload.inc.php");
// Reference the Dompdf namespace 
use Dompdf\Dompdf;
// Reference the Options namespace 
use Dompdf\Options;

// Set options to enable embedded PHP 
$options = new Options();
$options->set('isPhpEnabled', 'true');

// Instantiate dompdf class 
$dompdf = new Dompdf($options);

//Start body
$corntsession = $_SESSION['corntsession'];
$cursemester = $_SESSION['cursemester'];
$tot1stoutunit = $tot2ndoutunit = 0;

if (isset($_POST["submit"])) {
    $regid = $_POST["regid"];
    $_SESSION["regid"] = $regid;
} else {
    $regid = $_SESSION["regid"];
}

$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}



$sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
$result = $conn2->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $dept = $row["dept_code"];
        $programme = $row["programme"];
        $cat_class_degree = $row["cat_class_degree"];
        $stdid = $row["stdid"];
    }
}

$dept_db = $_SESSION['deptdb'] . strtolower($dept);
$conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
if ($conn_stu->connect_error) {
    die("Connection failed: " . $conn_stu->connect_error);
}


$sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession'  AND matricno = '$regid'";
$result = $conn_stu->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $stuname = $row["name1"];
        $stulevel = $row["StuLevel"];
        $leveladv = $row["LevelAdvice"];
        $HOD = $row["HOD"];
        $Dean = $row["Dean"];
        $Registrar = $row["Registrar"];
        $LAName = $row["LAName"];
        $HODName = $row["HODName"];
    }
}

$sql = "SELECT * FROM std_login WHERE stdid = '$stdid'";
$result = $conn2->query($sql);
if ($result->num_rows > 0) {
    $passportid = $stdid;
} else {
    $passportid = $regid;
}

if ($cursemester == "1ST") {
    $getSem = "1<sup>st</sup>";
} else {
    $getSem = "2<sup>nd</sup>";
}
$stu_pic_folder = $_SESSION['stu_pic_folder'];
$passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
// URL of the image to be downloaded
$imageUrl = $stu_pic_folder . '/' . $passptfile;
//$imageUrl = 'https://my.naub.edu.ng/uploads_acad/pics/ACC19U0913_passport.jpg';

// Path where the image will be saved
$matpassport = str_replace("/", "_", $regid);
$savePath = 'img/stupassport/' . $matpassport . '.jpg';

$ch = curl_init($imageUrl);
$fp = fopen($savePath, "wb");
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_exec($ch);
curl_close($ch);
fclose($fp);


// Load HTML content 

$instname = $_SESSION['instname'];

$html = "<br><br><br><br>";
$html .= "<h1 style='text-align: center; color:black'>$instname</h1>";
$html .= "<h1 style='text-align: center; color:black'>EXAMINATION CARD</h1>";
$html .= "<h2 style='text-align:center; color:black'>$getSem Semester $corntsession Session</h2>";



$html .= "<table style='width: 97%'>
            <tr>
                <td>Matric No: $regid<br>Name:  $stuname<br>Programme:  $cat_class_degree   $programme<br>Level:  $stulevel</td>
                <td style='text-align:right'>
                    
                        <img alt=''  class='' src='' width='100' height='100'>
                        
                </td>
            </tr>
        </table>";
$curtsession2 = str_replace("/", "_", $corntsession);
$sql = "SELECT * FROM courses_register_" . $curtsession2 . " WHERE Regn1 = '$regid' AND SemTaken = '$cursemester'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $html .= "<table class='table table-bordered' cellspacing='0' rules='all' border='1'
                style='width: 97%'>
                <thead>
                    <tr>
                        <th style='padding-left: 1em;'>Course Code</th>
                        <th>Course Title</th>
                        <th>Unit</th>
                        <th>Sign & Date by Invigilator</th>
                    </tr>
                </thead>
                <tbody>";

    while ($row = $result->fetch_assoc()) {
        $id = $row["sn"];
        $ccode = $row["CCode"];
        $CTitle = $row["CTitle"];
        $CUnit = $row["CUnit"];
        $SemTaken = $row["SemTaken"];
        $Nature = $row["Nature"];

        $tot1stoutunit += $row['CUnit'];


        $html .= "<tr><td style='padding: 0.3em;'>{$row['CCode']}</td><td style='padding: 0.3em;'>{$row['CTitle']}</td><td style='padding: 0.3em;'>{$row['CUnit']}</td><td></td></tr>\n";
    }
    $html .= " </tbody>
            </table>";
}

$html .= "<br><br>";
$html .= "<div style='text-align: center;'>
            _____________________________________<br>HOD's Sign and
            Stamp
        </div>";

$conn->close();
$conn2->close();
$conn_stu->close();

$dompdf->loadHtml($html);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render the HTML as PDF
$dompdf->render();

// Instantiate canvas instance
$canvas = $dompdf->getCanvas();

// Get height and width of page
$w = $canvas->get_width();
$h = $canvas->get_height();

// Specify watermark image
$imageURL = 'img/watermarklogo.png';
$imageURL2 = 'img/logo.png';
//$imageURL3 = $stu_pic_folder . '/' . $passptfile;
$imageURL3 = $savePath;
$imgWidth = 500;
$imgHeight = 500;

// Set image opacity
//$canvas->set_opacity(.5);

// Specify horizontal and vertical position
$x = (($w - $imgWidth) / 2);
$y = (($h - $imgHeight) / 2);

// Add an image to the pdf
$canvas->image($imageURL, $x, $y, $imgWidth, $imgHeight);

$canvas->image($imageURL2, 250, 10, 110, 100);
$canvas->image($imageURL3, 463, 210, 80, 80);

// Output the generated PDF (1 = download and 0 = preview)
$dompdf->stream('document.pdf', array("Attachment" => 0));

<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: Home_Staff.php');
}

?>




<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>

    <!--Auto pop up div-->
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        $("select.country").change(function() {
            var selectedCountry = $(".country option:selected").val();
            $.ajax({
                type: "POST",
                url: "includes/course_setup_inc.php",
                data: {
                    country: selectedCountry
                }
            }).done(function(data) {
                $("#getalldeptlist").html(data);
            });
        });
    });
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Setup</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>
                            <li>
                                Course Setup
                            </li>
                            <li class="active">
                                <strong>Course Setup Add</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Setup
                        </div>
                        <div class="panel-body table-responsive">
                            <?php
        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
        if ($conn2->connect_error) {
            die("Connection failed: " . $conn2->connect_error);
        }

                            $dept = $_SESSION['deptcode'];
                            $numbschCurri = $_SESSION['numbschCurri'];

                            $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' ORDER BY deptoption, level, SemTaken, CCode";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                            ?>
                            <table class="table table-hover margin bottom">
                                <thead>
                                    <tr>
                                        <th>Course Code</th>
                                        <th>Course Title</th>
                                        <th>Unit</th>
                                        <th>Semester</th>
                                        <th>Nature</th>
                                        <th>Level</th>
                                        <?php if ($_SESSION['deptoption'] == "YES") { ?>
                                        <th>Department Option</th>
                                        <?php } ?>
                                        <?php if ($numbschCurri > 1) { ?>
                                        <th>Curriculum</th>
                                        <?php } ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        // output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $id = $row["id"];
                                            $ccode = $row["CCode"];
                                            $CTitle = $row["CTitle"];
                                            $CUnit = $row["CUnit"];
                                            $SemTaken = $row["SemTaken"];
                                            $Nature = $row["Nature"];
                                            $level = $row["level"];
                                            $type1 = $row["type1"];

                                            $sql2 = "SELECT * FROM sch_curriculum WHERE curri_Code = '$type1'";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $type1 = $row2["curri_Title"];
                                                }
                                            }
                                            if ($_SESSION['deptoption'] == "YES") {
                                                $deptoption = $row["deptoption"];
                                                $sql2 = "SELECT * FROM dept_option WHERE deptcode = '$dept' AND Opt_Code = '$deptoption'";
                                                $result2 = $conn->query($sql2);
                                                if ($result2->num_rows > 0) {
                                                    while ($row2 = $result2->fetch_assoc()) {
                                                        $opttitle = $row2["Opt_Title"];
                                                    }
                                                }
                                            }
                                            if ($_SESSION['InstType'] == "University") {
                                                if ($_SESSION['deptoption'] == "YES") {
                                                    echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$level</td><td>$opttitle</td>";
                                                    if ($numbschCurri > 1) {
                                                        echo "<td>$type1</td>";
                                                    }
                                                    echo "</tr>\n";
                                                } else {
                                                    echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$level</td>";
                                                    if ($numbschCurri > 1) {
                                                        echo "<td>$type1</td>";
                                                    }
                                                    echo "</tr>\n";
                                                }
                                            } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                if ($row["level"] == 100) {
                                                    $stulevel2 = "ND I";
                                                } elseif ($row["level"] == 200) {
                                                    $stulevel2 = "ND II";
                                                } elseif ($row["level"] == 300) {
                                                    $stulevel2 = "HND I";
                                                } elseif ($row["level"] == 400) {
                                                    $stulevel2 = "HND II";
                                                }
                                                if ($_SESSION['deptoption'] == "YES") {
                                                    echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$stulevel2</td><td>$opttitle</td>";
                                                    if ($numbschCurri > 1) {
                                                        echo "<td>$type1</td>";
                                                    }
                                                    echo "</tr>\n";
                                                } else {
                                                    echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$stulevel2</td>";
                                                    if ($numbschCurri > 1) {
                                                        echo "<td>$type1</td>";
                                                    }
                                                    echo "</tr>\n";
                                                }
                                            } else {
                                            }
                                        }
                                        ?>
                                </tbody>
                            </table>

                            <?php
                            }
                            ?>
                            <br><br />
                            <div class="form-group">
                                <label class="control-label col-lg-3" for="dept">Select Department:</label>
                                <div class="col-lg-8">
                                    <select class="country form-control" style="color:#000000" name="dept">
                                        <option value="SelectItem">Select Item</option>
                                        <?php

                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                            while ($row = $result->fetch_assoc()) {
                                                $deptcode2 = $row["DeptCode"];
                                                $deptname2 = $row["DeptName"];
                                                echo "<option value=$deptcode2>$deptname2</option>";
                                            }
                                        }

                                        $sql = "SELECT * FROM schoolname ORDER BY SchName";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $deptcode2 = $row["SchCode"];
                                                $deptname2 = $row["SchName"];
                                                echo "<option value=$deptcode2>$deptname2</option>";
                                            }
                                        }
                                        ?>

                                    </select>
                                </div>
                            </div>
                            <br>
                            <strong>
                                <center>
                                    <h3>Select to Add Courses</h3>
                                </center>
                            </strong>

                            <form method="post" action="course_setup_subt.php">
                                <div class="form-group" id="getalldeptlist">

                                    <?php

                                    $sql = "SELECT * FROM gencoursesupload WHERE Department = '$dept' ORDER BY C_codding";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                    ?>
                                    <table class="table table-hover margin bottom">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th>Course Code</th>
                                                <th>Course Title</th>
                                                <th>Unit</th>
                                                <th>Semester</th>
                                                <th>Nature</th>
                                                <th>Level</th>
                                                <?php if ($_SESSION['deptoption'] == "YES") { ?>
                                                <th>Department Option</th>
                                                <?php } ?>
                                                <?php if ($numbschCurri > 1) { ?>
                                                <th>Curriculum</th>
                                                <?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                // output data of each row
                                                while ($row = $result->fetch_assoc()) {
                                                    $id = $row["id"];
                                                    $ccode = $row["C_codding"];
                                                    $CTitle = $row["C_title"];
                                                    $CUnit = $row["credit"];
                                                    $SemTaken = $row["semester"];
                                                    $type1 = $row["type1"];

                                                    $sql2 = "SELECT * FROM sch_curriculum WHERE curri_Code = '$type1'";
                                                    $result2 = $conn->query($sql2);
                                                    if ($result2->num_rows > 0) {
                                                        while ($row2 = $result2->fetch_assoc()) {
                                                            $type2 = $row2["curri_Title"];
                                                        }
                                                    }


                                                    echo "<tr>
                                                        <td><input type='checkbox' name='chosen[" . $id . "]' value='" . $id . "'/></td>
                                                        
                                                        
                                                        <td>
                                                        <label id='ccode' name='ccode[" . $id . "]'>$ccode</label>
                                                        <input type='hidden' id='ccode' name='ccode[" . $id . "]' value='" . $ccode . "'/>
                                                        </td>
                                                        <td>
                                                        <label id='CTitle' name='CTitle[" . $id . "]'>$CTitle</label>
                                                        <input type='hidden' id='CTitle' name='CTitle[" . $id . "]' value='" . $CTitle . "'/>
                                                        </td>";
                                                    if ($_SESSION['useDeptUnit'] == false) {
                                                        echo "<td>
                                                        <label id='CUnit' name='CUnit[" . $id . "]'>$CUnit</label>
                                                        <input type='hidden' id='CUnit' name='CUnit[" . $id . "]' value='" . $CUnit . "'/>
                                                        </td>";
                                                    } elseif ($_SESSION['useDeptUnit'] == true) {
                                                        echo "<td>
                                                        
                                                        <select class='form-control' id='CUnit' style='color:#000000' name='CUnit[" . $id . "]'>
															<option value = '$CUnit'>$CUnit</option>
                                                            <option value = '0'>0</option>
                                                            <option value = '1'>1</option>
                                                            <option value = '2'>2</option>
                                                            <option value = '3'>3</option>
                                                            <option value = '4'>4</option>
                                                            <option value = '5'>5</option>
                                                            <option value = '6'>6</option>
                                                        </select>
                                                        </td>";
                                                    }


                                                    echo "<td>
                                                    
                                                        <select class='form-control' id='SemTaken1' style='color:#000000' name='SemTaken[" . $id . "]'>
															<option value = '$SemTaken'>$SemTaken</option>
                                                            <option value = '1ST'>1ST</option>
                                                            <option value = '2ND'>2ND</option>
                                                        </select>
                                                        </td>
                                                        <td>
                                                        <select class='form-control' id='Nature1' style='color:#000000' name='Nature[" . $id . "]'>
                                                            <option value = 'Core'>Core</option>
                                                            <option value = 'Elective'>Elective</option>
                                                        </select>
                                                        </td>
                                                        <td>";
                                                    if ($_SESSION['InstType'] == "University") {
                                                        echo "<select class='form-control' id='level1' style='color:#000000' name='level[" . $id . "]'>
                                                            <option value = '100'>100</option>
                                                            <option value = '200'>200</option>
                                                            <option value = '300'>300</option>
                                                            <option value = '400'>400</option>
                                                            <option value = '500'>500</option>
                                                        </select>";
                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {

                                                        echo "<select class='form-control' id='level1' style='color:#000000' name='level[" . $id . "]'>
                                                            <option value = '100'>ND I</option>
                                                            <option value = '200'>ND II</option>
                                                            <option value = '300'>HND I</option>
                                                            <option value = '400'>HND II</option>
                                                            
                                                        </select>";
                                                    } else {
                                                    }

                                                    echo "</td>";
                                                    if ($_SESSION['deptoption'] == "YES") {
                                                        echo "<td>";
                                                        echo "<select class='form-control' id='deptoptn' style='color:#000000' name='deptoptn[" . $id . "]'>";
                                                        $sql2 = "SELECT * FROM dept_option WHERE deptcode = '$dept'";
                                                        $result2 = $conn->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $Opt_Code = $row2["Opt_Code"];
                                                                $opttitle = $row2["Opt_Title"];
                                                                echo "<option value = '$Opt_Code'>$opttitle</option>";
                                                            }
                                                        }
                                                        echo "</select>";
                                                        echo "</td>";
                                                    }
                                                    if ($numbschCurri > 1) {
                                                        echo "<td>
                                                        
                                                        <label id='Ctype' name='Ctype[" . $id . "]'>$type2</label>
                                                        <input type='hidden' id='Ctype' name='Ctype[" . $id . "]' value='" . $type1 . "'/>
                                                       
                                                        </td>";
                                                    }


                                                    echo "</tr>\n";
                                                }
                                                ?>
                                        </tbody>
                                    </table>

                                    <?php
                                    }
                                    //$conn->close();


                                    ?>



                                </div>

                                <br /><br />
                                <button type="submit" class="btn btn-primary">Submit</button>
                                <br /><br />
                            </form>
                            <?php
$conn->close();
$conn2->close();
?>

                        </div>
                    </div>


                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>


</body>

</html>
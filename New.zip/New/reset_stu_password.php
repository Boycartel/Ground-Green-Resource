<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}

?>
<!DOCTYPE html>
<html>

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">


    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>

    <div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Reset Password</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="home_staff.php">Home</a>
                        </li>
                        <li>
                            <a>Users</a>
                        </li>
                        <li class="active">
                            <strong>Reset Password</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>
            <?php
            $success = $recexist = $errorpf = "";
            $errorcode = "NO";
            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
            if ($conn2->connect_error) {
                die("Connection failed: " . $conn2->connect_error);
            }

            if (isset($_POST["passwdreset"])) {
                $matno2 = $_POST['matno2'];

                $sql = "UPDATE std_login SET password ='cd73502828457d15655bbd7a63fb0bc8' WHERE matric_no='$matno2'";
                $result = $conn2->query($sql);

                $success = "<h2 class='alert alert-success'>Record Saved Successfully with Password: <strong style='color:red'>student</strong></h2>";
            }


            ?>
            <div class="wrapper wrapper-content animated fadeInRight">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Reset Password</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-user">
                                        <li><a href="#">Config option 1</a>
                                        </li>
                                        <li><a href="#">Config option 2</a>
                                        </li>
                                    </ul>
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-sm-2">
                                        <h3></h3>
                                    </div>
                                    <div class="col-sm-8">
                                        <?php echo $success ?>
                                        <form action="" method="POST">

                                            <div class="modal-body">

                                                <div class="form-group">
                                                    <label>File Number:</label>
                                                    <input type="text" class="form-control" style="color:#000000" name="matno" id="matno">
                                                </div>

                                            </div>
                                            <div class="modal-footer">

                                                <button name="submit" class="btn btn-primary" type="submit">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="col-sm-2">
                                        <h3></h3>
                                    </div>

                                </div>
                                <?php if (isset($_POST["submit"])) { ?>
                                    <?php
                                    $matno = $_POST["matno"];
                                    $sql3 = "SELECT * FROM std_data_view WHERE matric_no= '$matno'";
                                    $result3 = $conn2->query($sql3);
                                    if ($result3->num_rows > 0) {
                                        while ($row3 = $result3->fetch_assoc()) {
                                            $stdid = $row3["stdid"];
                                            $names = $row3["first_name"] . " " . $row3["other_name"] . " " . $row3["surname"];
                                            $sql = "UPDATE std_login SET matric_no = '$matno' WHERE stdid ='$stdid'";
                                            $result = $conn2->query($sql);
                                        }
                                    }


                                    ?>
                                    <div class="table-responsive">
                                        <form action="" method="POST">
                                            <div class="modal-header">
                                                <h4 class="modal-title" style="color: #F00;"><strong>Password Reset</strong>
                                                </h4>

                                            </div>
                                            <div class="modal-body">
                                                <input type="hidden" name="matno2" value="<?php echo $matno ?>" />
                                                <div class="form-group">
                                                    <label>Matric Number:</label>
                                                    <input type="text" class="form-control" style="color:#000000" name="pfno" value="<?php echo $matno ?>" readonly>
                                                </div>
                                                <div class="form-group">
                                                    <label>Full Name:</label>
                                                    <input type="text" class="form-control" style="color:#000000" name="fullname" value="<?php echo $names ?>" readonly>
                                                </div>
                                            </div>
                                            <div class="modal-footer">

                                                <button name="passwdreset" class="btn btn-danger" type="submit">Reset</button>
                                            </div>
                                        </form>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $conn->close();
            $conn2->close();
            ?>
            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

        </div>
    </div>


    </section>

    <?php
    include_once 'includes/footer.php';
    ?>




</body>

</html>
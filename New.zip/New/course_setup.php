<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: Home_Staff.php');
}

?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--To Delete
		<link href='delete_res/bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
    <script src='delete_res/jquery-3.3.1.js' type='text/javascript'> </script>
    <script src='delete_res/bootstrap/js/bootstrap.min.js'> </script>
    <script src='delete_res/bootbox.min.js'> </script>-->

    <!-- End To Delete -->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Setup</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Setup</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Setup
                        </div>
                        <div class="panel-body">
                            <div>
                                <div class="col-lg-1">

                                </div>
                                <div class="col-lg-10 table-responsive">
                                    <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                    if ($conn2->connect_error) {
                                        die("Connection failed: " . $conn2->connect_error);
                                    }

                                    $dept = $_SESSION['deptcode'];
                                    $numbschCurri = $_SESSION['numbschCurri'];
                                    $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' ORDER BY deptoption, level, SemTaken, CCode";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                    ?>
                                        <table class="table mb-none">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Nature</th>
                                                    <th>Level</th>
                                                    <?php if ($_SESSION['deptoption'] == "YES") { ?>
                                                        <th>Department Option</th>
                                                    <?php } ?>
                                                    <?php if ($numbschCurri > 1) { ?>
                                                        <th>Curriculum</th>
                                                    <?php } ?>
                                                    <th>Action</th>


                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                // output data of each row
                                                while ($row = $result->fetch_assoc()) {
                                                    $id = $row["id"];
                                                    $ccode = $row["CCode"];
                                                    $CTitle = $row["CTitle"];
                                                    $CUnit = $row["CUnit"];
                                                    $SemTaken = $row["SemTaken"];
                                                    $Nature = $row["Nature"];
                                                    $level = $row["level"];
                                                    $type1 = $row["type1"];

                                                    if ($numbschCurri > 1) {
                                                        $sql2 = "SELECT * FROM sch_curriculum WHERE curri_Code = '$type1'";
                                                        $result2 = $conn->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $type1 = $row2["curri_Title"];
                                                            }
                                                        }
                                                    }

                                                    if ($_SESSION['deptoption'] == "YES") {
                                                        $deptoption = $row["deptoption"];
                                                        $sql2 = "SELECT * FROM dept_option WHERE deptcode = '$dept' AND Opt_Code = '$deptoption'";
                                                        $result2 = $conn->query($sql2);
                                                        if ($result2->num_rows > 0) {
                                                            while ($row2 = $result2->fetch_assoc()) {
                                                                $opttitle = $row2["Opt_Title"];
                                                            }
                                                        }
                                                    }
                                                    if ($_SESSION['InstType'] == "University") {
                                                        if ($_SESSION['deptoption'] == "YES") {
                                                            echo "<tr id='$id'><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$level</td><td>$opttitle</td>";
                                                            if ($numbschCurri > 1) {
                                                                echo "<td>$type1</td>";
                                                            }
                                                        } else {
                                                            echo "<tr id='$id'><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$level</td>";
                                                            if ($numbschCurri > 1) {
                                                                echo "<td>$type1</td>";
                                                            }
                                                        }
                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                        if ($row["level"] == 100) {
                                                            $stulevel2 = "ND I";
                                                        } elseif ($row["level"] == 200) {
                                                            $stulevel2 = "ND II";
                                                        } elseif ($row["level"] == 300) {
                                                            $stulevel2 = "HND I";
                                                        } elseif ($row["level"] == 400) {
                                                            $stulevel2 = "HND II";
                                                        }
                                                        if ($_SESSION['deptoption'] == "YES") {
                                                            echo "<tr id='$id'><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$stulevel2</td><td>$opttitle</td>";
                                                            if ($numbschCurri > 1) {
                                                                echo "<td>$type1</td>";
                                                            }
                                                        } else {
                                                            echo "<tr id='$id'><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td><td>$stulevel2</td>";
                                                            if ($numbschCurri > 1) {
                                                                echo "<td>$type1</td>";
                                                            }
                                                        }
                                                    } else {
                                                    }

                                                ?>
                                                    <td>
                                                        <button class="btn btn-danger btn-xs remove-record">Delete</button>
                                                    </td>
                                                <?php
                                                    echo "</tr>\n";
                                                }
                                                ?>
                                            </tbody>
                                        </table>

                                    <?php

                                    }

                                    $conn->close();
                                    $conn2->close();

                                    ?>


                                    <br><br>
                                    <div class="col-lg-12"><a class="btn btn-primary" href="course_setup_add.php">Add
                                            Courses</a></div>

                                </div>
                                <div class="col-lg-1">

                                </div>
                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>

        <script type="text/javascript">
            $(".remove-record").click(function() {
                var id = $(this).parents("tr").attr("id");
                if (confirm('Are you sure to delete this record ?')) {
                    $.ajax({
                        url: 'delete_res/delete_course_setup.php',
                        type: 'GET',
                        data: {
                            id: id
                        },
                        error: function() {
                            alert('Something is wrong, couldn\'t delete record');
                        },
                        success: function(data) {
                            $("#" + id).remove();
                            alert("Record delete successfully.");
                        }
                    });
                }
            });
        </script>
</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['pass_reset_admin'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="css/plugins/dropzone/basic.css" rel="stylesheet">
    <link href="css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Allocation Summary</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Course Managment
                            </li>

                            <li class="active">
                                <strong>Course Allocation Summary</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Allocation Summary
                        </div>
                        <div class="panel-body table-responsive">
                            <?php
                            $msg = "";
                            $success_upl = "no";
                            $cursession = $_SESSION['corntsession'];
                            $prevsession = $_SESSION['prevsession'];


                            ?>

                            <br>
                            <?php
                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }
                            $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                            ?>
                                <table class="table mb-none">
                                    <thead>
                                        <tr>
                                            <th>S/No</th>
                                            <th>Department</th>
                                            <th>Number of Courses</th>
                                            <th>Action</th>
                                        </tr>

                                    </thead>
                                    <tbody>


                                        <?php


                                        $sno = 0;
                                        while ($row = $result->fetch_assoc()) {

                                            $dept2 = $row["DeptCode"];
                                            $DeptName = $row["DeptName"];
                                            $totcourse = 0;
                                            $sql2 = "SELECT DISTINCT CCode FROM coursealocation WHERE Department = '$dept2'";
                                            $result2 = $conn->query($sql2);
                                            if ($result2->num_rows > 0) {
                                                while ($row2 = $result2->fetch_assoc()) {
                                                    $totcourse++;
                                                }
                                            }



                                            $sno++;

                                            echo "<tr><td>$sno</td><td>$DeptName</td><td>$totcourse</td>";

                                            echo "
												 <td style='text-align: center;'><form action='' method='post'>
													  <input type='hidden' value='$dept2' name='dept2'>
                                                      <input type='hidden' value='$DeptName' name='depttitle'>
													  <input type='submit' name='view' class='btn btn-primary btn-xs' value='View'>
												 </form></td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            <?php } ?>
                            <?php
                            $conn->close();
                            ?>

                        </div>
                    </div>
                    <?php if (isset($_POST["view"])) { ?>
                        <?php
                        $dept2 = $_POST["dept2"];
                        $depttitle = $_POST["depttitle"];
                        ?>
                        <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                            <div class="panel-heading">
                                <?php echo $depttitle ?> Department, <?php echo $cursession ?> Session
                            </div>
                            <div class="panel-body table-responsive">
                                <table class="table mb-none">
                                    <thead>

                                        <tr>
                                            <th>S/No</th>
                                            <th>File Number</th>
                                            <th>Course Code</th>
                                            <th>Course Title</th>
                                            <th>Credit Unit</th>
                                            <th>Semester</th>
                                            <th>Corriculum</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }
                                        $sno2 = 0;
                                        $sql2 = "SELECT * FROM coursealocation WHERE Department = '$dept2' ORDER BY CCode, PFNo";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $sno2++;
                                                $PFNo = $row2["PFNo"];
                                                $CCode = $row2["CCode"];
                                                $CTitle = $row2["CTitle"];
                                                $CUnit = $row2["CUnit"];
                                                $SemTaken = $row2["Semester"];
                                                $type1 = $row2["curri"];

                                                echo "<tr><td>$sno2</td><td>$PFNo</td><td>$CCode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$type1</td></tr>";
                                            }
                                        }
                                        $conn->close();
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php } ?>

                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>





    </div>

    <?php
    include_once 'includes/footer.php';
    ?>

    <script>
        $(function() {
            $('a.view100').click(function(e) {
                e.preventDefault();
                var link = this;
                var deleteModal = $("#viewRecModal100");
                // store the ID inside the modal's form
                deleteModal.find('input[name=id]').val(link.dataset.id);

                // open modal
                deleteModal.modal();
            });
        });
    </script>
</body>

</html>
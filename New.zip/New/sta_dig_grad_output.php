<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['apu_request'] == false && $_SESSION['acad_office_request'] == false) {
    header('Location: home_staff.php');
}


?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>

    <style>
    table,
    td,
    th {
        border: 0.5px solid;
    }

    table {
        width: 97%;
        border-collapse: collapse;
    }
    </style>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Graduate Output</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li>
                                Statistical Digest
                            </li>
                            <li class="active">
                                Graduate Output
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Graduate Output
                        </div>
                        <div class="panel-body">

                            <div class="row">

                                <div class="row">
                                    <div>
                                        <form class="form-horizontal form-bordered" method="post">
                                            <div class="form-group">
                                                <label class="col-lg-4 control-label">Year of Graduation: </label>
                                                <div class="col-lg-5">
                                                    <select name="gradyear" class="form-control" style="color:#000000"
                                                        id="gradyear" required>
                                                        <option value=""></option>
                                                        <?php
                                                        $iniyear = 2020;
                                                        $finalyear = substr($_SESSION['corntsession'], 5);

                                                        while ($iniyear <= $finalyear) {
                                                            $addyear = $iniyear + 1;

                                                            echo "<option value = '$iniyear'>$iniyear</option>";
                                                            $iniyear++;
                                                        }

                                                        ?>

                                                    </select>
                                                </div>
                                                <div class="col-lg-3">
                                                    <button type="submit" name="submit"
                                                        class="btn btn-primary">Submit</button>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <br>
                                    <hr class="separator" />
                                    <br>
                                    <?php if (isset($_POST["submit"])) { ?>
                                    <?php

                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        $gradyear = $_POST["gradyear"];
                                        unset($maleFC);
                                        $maleFC[] = 0;
                                        unset($maleSCU);
                                        $maleSCU[] = 0;
                                        unset($maleSCL);
                                        $maleSCL[] = 0;
                                        unset($maleTC);
                                        $maleTC[] = 0;
                                        unset($maleP);
                                        $maleP[] = 0;

                                        unset($femaleFC);
                                        $femaleFC[] = 0;
                                        unset($femaleSCU);
                                        $femaleSCU[] = 0;
                                        unset($femaleSCL);
                                        $femaleSCL[] = 0;
                                        unset($femaleTC);
                                        $femaleTC[] = 0;
                                        unset($femaleP);
                                        $femaleP[] = 0;

                                        unset($deptArray);
                                        $deptArray[] = "";
                                        $totMaleFC = $totFemaleFC = $totMaleSCU = $totFemaleSCU = $totMaleSCL = $totFemaleSCL = $totMaleTC = $totFemaleTC = $totMaleP = $totFemaleP = 0;
                                        $count = 0;
                                        $sql2 = "SELECT * FROM deptcoding WHERE students = 'yes' ORDER BY DeptName";
                                        $result2 = $conn->query($sql2);
                                        if ($result2->num_rows > 0) {
                                            while ($row2 = $result2->fetch_assoc()) {
                                                $deptcode = $row2["DeptCode"];
                                                $deptname = $row2["DeptName"];

                                                $count++;

                                                $dept_db = $_SESSION['deptdb'] . strtolower($deptcode);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                $sql = "SELECT * FROM scrutiny_senate WHERE graduated = 'YES' AND yearGrad = '$gradyear'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {

                                                        if ($row["classdegree"] == "First Class") {
                                                            if (strtoupper($row["sex"]) == "M" || strtoupper($row["sex"]) == "MALE") {
                                                                $maleFC[$count]++;
                                                                $totMaleFC++;
                                                            } else {
                                                                $femaleFC[$count]++;
                                                                $totFemaleFC++;
                                                            }
                                                        } elseif ($row["classdegree"] == "Second Class Upper") {
                                                            if (strtoupper($row["sex"]) == "M" || strtoupper($row["sex"]) == "MALE") {
                                                                $maleSCU[$count]++;
                                                                $totMaleSCU++;
                                                            } else {
                                                                $femaleSCU[$count]++;
                                                                $totFemaleSCU++;
                                                            }
                                                        } elseif ($row["classdegree"] == "Second Class Lower") {
                                                            if (strtoupper($row["sex"]) == "M" || strtoupper($row["sex"]) == "MALE") {
                                                                $maleSCL[$count]++;
                                                                $totMaleSCL++;
                                                            } else {
                                                                $femaleSCL[$count]++;
                                                                $totFemaleSCL++;
                                                            }
                                                        } elseif ($row["classdegree"] == "Third Class") {
                                                            if (strtoupper($row["sex"]) == "M" || strtoupper($row["sex"]) == "MALE") {
                                                                $maleTC[$count]++;
                                                                $totMaleTC++;
                                                            } else {
                                                                $femaleTC[$count]++;
                                                                $totFemaleTC++;
                                                            }
                                                        } elseif ($row["classdegree"] == "Pass") {
                                                            if (strtoupper($row["sex"]) == "M" || strtoupper($row["sex"]) == "MALE") {
                                                                $maleP[$count]++;
                                                                $totMaleP++;
                                                            } else {
                                                                $femaleP[$count]++;
                                                                $totFemaleP++;
                                                            }
                                                        }
                                                    }
                                                }
                                                $deptArray[$count] = $deptname;
                                            }
                                        }



                                        $conn->close();
                                        $conn2->close();
                                        $conn_stu->close();


                                        ?>

                                    <section class="panel panel-default">
                                        <header class="panel-heading">

                                            <h2 class="panel-title"><?php //echo $names 
                                                                        ?></h2>
                                        </header>
                                        <div class="panel-body">

                                            <div class="row">
                                                <div id="printableArea" class="table-responsive">
                                                    <h1><strong> Table 1a: Enrolment</strong></h1>
                                                    <h2><strong>Total Number of Students who Graduated from the
                                                            University in the Year <?php echo $gradyear ?></strong>
                                                    </h2>
                                                    <table class="table mb-none" style="width: 100%">
                                                        <thead>
                                                            <tr>
                                                                <th style="text-align: center;">S/No</th>
                                                                <th style="text-align: center;">Department</th>
                                                                <th style="text-align: center;" colspan="2">First Class
                                                                </th>
                                                                <th style="text-align: center;" colspan="2">Second Class
                                                                    Upper</th>
                                                                <th style="text-align: center;" colspan="2">Second Class
                                                                    Lower</th>
                                                                <th style="text-align: center;" colspan="2">Third Class
                                                                </th>
                                                                <th style="text-align: center;" colspan="2">Pass</th>
                                                                <th style="text-align: center;">Total</th>
                                                            </tr>
                                                            <tr>
                                                                <th></th>
                                                                <th></th>
                                                                <th style="text-align: center;">Male</th>
                                                                <th style="text-align: center;">Female</th>
                                                                <th style="text-align: center;">Male</th>
                                                                <th style="text-align: center;">Female</th>
                                                                <th style="text-align: center;">Male</th>
                                                                <th style="text-align: center;">Female</th>
                                                                <th style="text-align: center;">Male</th>
                                                                <th style="text-align: center;">Female</th>
                                                                <th style="text-align: center;">Male</th>
                                                                <th style="text-align: center;">Female</th>
                                                                <th></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                                for ($x = 1; $x <= $count; $x++) {
                                                                    $total = $maleFC[$x] + $femaleFC[$x] + $maleSCU[$x] + $femaleSCU[$x] + $maleSCL[$x] + $femaleSCL[$x] + $maleTC[$x] + $femaleTC[$x] + $maleP[$x] + $femaleP[$x];
                                                                    echo "<tr><td style='text-align: center;'>$x</td><td>$deptArray[$x]</td><td style='text-align: center;'>$maleFC[$x]</td><td style='text-align: center;'>$femaleFC[$x]</td><td style='text-align: center;'>$maleSCU[$x]</td><td style='text-align: center;'>$femaleSCU[$x]</td><td style='text-align: center;'>$maleSCL[$x]</td><td style='text-align: center;'>$femaleSCL[$x]</td><td style='text-align: center;'>$maleTC[$x]</td><td style='text-align: center;'>$femaleTC[$x]</td><td style='text-align: center;'>$maleP[$x]</td><td style='text-align: center;'>$femaleP[$x]</td><td style='text-align: center;'>$total</td></tr>";
                                                                }
                                                                $tot_total = $totMaleFC + $totFemaleFC + $totMaleSCU + $totFemaleSCU + $totMaleSCL + $totFemaleSCL + $totMaleTC + $totFemaleTC + $totMaleP + $totFemaleP;
                                                                ?>
                                                            <tr>
                                                                <th></th>
                                                                <th>Total</th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totMaleFC ?></th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totFemaleFC ?></th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totMaleSCU ?></th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totFemaleSCU ?></th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totMaleSCL ?></th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totFemaleSCL ?></th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totMaleTC ?></th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totFemaleTC ?></th>
                                                                <th style="text-align: center;"><?php echo $totMaleP ?>
                                                                </th>
                                                                <th style="text-align: center;">
                                                                    <?php echo $totFemaleP ?></th>
                                                                <th style="text-align: center;"><?php echo $tot_total ?>
                                                                </th>
                                                            </tr>
                                                        </tbody>
                                                    </table>

                                                </div>
                                                <br>
                                                <div style="text-align: right">
                                                    <input type="button" onclick="printDiv('printableArea')"
                                                        value="print" class="btn-success" />
                                                </div>
                                            </div>

                                        </div>
                                    </section>


                                    <?php } ?>
                                </div>

                            </div>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
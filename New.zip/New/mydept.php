<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity_stu.php';

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout_stu.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">

                <?php
                $stutype = $_SESSION['progtype'];
                $sch_color = $_SESSION['sch_color'];
                $entry_session = $_SESSION['entry_session'];
                ?>
                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>My Department</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>

                            <li class="active">
                                <strong>My Department</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            My Department
                        </div>
                        <div class="panel-body">
                            <center>
                                <h4>Department of <?php echo " " . $_SESSION['deptname']  ?></h4>
                            </center>
                            <center>
                                <h4>School of <?php echo " " . $_SESSION['schname']  ?></h4>
                            </center>
                            <center>
                                <h4><?php echo $_SESSION['instname'] ?></h4>
                            </center>

                            <div class="row">
                                <?php
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }
                                ?>
                                <div class="col-md-6">
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">
                                            My Lecturers
                                        </div>
                                        <div class="panel-body">

                                            <div class="table-responsive">
                                                <table class="table table-striped mb-none">
                                                    <thead>
                                                        <tr>

                                                            <th>Name</th>
                                                            <th>Course(s) <?php echo " " . $corntsession . " " ?>Session
                                                            </th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $dept = $_SESSION['deptcode'];



                                                        $sql = "SELECT * FROM users WHERE staffacddept = '$dept'";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $stafname = $row["full_name"];
                                                                $pfno = $row["staffid"];
                                                                $sql2 = "SELECT * FROM coursealocation WHERE PFNo = '$pfno' AND SessionReg = '$corntsession' AND ugpg = '$stutype'";
                                                                $result2 = $conn->query($sql2);
                                                                $stafcourse = "";
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $stafcourse = $stafcourse . " " . $row2["CCode"];
                                                                    }
                                                                }
                                                                //$activity1 = $row["activity1"];
                                                                echo "<tr><td>$stafname</td><td>$stafcourse</td></tr>\n";
                                                            }
                                                        }

                                                        ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <?php
                                $resultsession = $_SESSION['resultsession'];
                                unset($CcodeArray);
                                $CcodeArray[] = "";
                                unset($CtitleArray);
                                $CtitleArray[] = "";
                                $CodeCount = 0;
                                $regid = $_SESSION['regid'];
                                $dept = strtolower($dept);
                                $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' ORDER BY level, CCode";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $CodeCount++;
                                        $CcodeArray[$CodeCount] = $row["CCode"];
                                        $CtitleArray[$CodeCount] = $row["CTitle"];
                                    }
                                }
                                unset($CodePassArray);
                                $CodePassArray[] = "";
                                $CodePassCount = 0;

                                $FinalYear = substr($resultsession, 0, 4);
                                $StartYear = substr($entry_session, 0, 4);

                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }


                                for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                    $getstuSession2 = $x . "/" . ($x + 1);

                                    $StuCurSess = str_ireplace("/", "_", $getstuSession2);
                                    if ($getstuSession2 < "2014/2015") {
                                        $deptcorreg = "correg";
                                    } else {
                                        $deptcorreg = "correg_" . $StuCurSess;
                                    }

                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis = '$getstuSession2'";
                                    $result = $conn_stu->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            if ($row["grade"] != "F") {
                                                $CodePassCount++;
                                                $CodePassArray[$CodePassCount] = $row['CCode'];
                                            }
                                        }
                                    }
                                }

                                unset($difarray);
                                unset($difarray2);
                                $difarray = array_values(array_diff($CcodeArray, $CodePassArray));
                                $difarray2 = array_values(array_unique($difarray));


                                ?>
                                <div class="col-md-6">
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">
                                            My Courses
                                        </div>
                                        <div class="panel-body">
                                            <table class="table table-striped mb-none">
                                                <thead>
                                                    <tr>

                                                        <th>Course Code</th>
                                                        <th>Course Title</th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php

                                                    for ($x = 1; $x <= $CodeCount; $x++) {
                                                        $coursepass = false;
                                                        foreach ($difarray2 as $CCode2) {
                                                            if ($CcodeArray[$x] == $CCode2) {
                                                                $coursepass = true;
                                                            }
                                                        }
                                                        if ($coursepass == true) {
                                                            echo "<tr><td>$CcodeArray[$x]</td><td>$CtitleArray[$x]</td></tr>";
                                                        } elseif ($coursepass == false) {
                                                            echo "<tr><td style='background-color:$sch_color; color:#FFF'>$CcodeArray[$x]</td><td style='background-color:$sch_color; color:#FFF'>$CtitleArray[$x]</td></tr>";
                                                        }
                                                    }


                                                    ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>


                                </div>
                                <?php
$conn->close();
?>
                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['staff_results'] == false) {
    header('Location: home_staff.php');
}


?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script type="text/javascript">
        function printDiv(div_id) {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var content_vlue = document.getElementById(div_id).innerHTML;

            var docprint = window.open("", "", disp_setting);

            ///// Enable Bootstrap CSS
            //// Can also add customise CSS
            docprint.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
            );
            docprint.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            docprint.document.write(content_vlue);
            docprint.document.write('</body></html>');
            docprint.document.close();
            docprint.focus();
        }
    </script>
    <!--End Print Div-->

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Format I</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_stu.php">Home</a>
                            </li>
                            <li><span>Results</span></li>
                            <li>Students' Result</li>
                            <li class="active">
                                <strong>Format I</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students' Result
                        </div>
                        <div class="panel-body">

                            <div class="row">

                                <div class="col-md-1">
                                </div>
                                <div class="col-md-10">
                                    <?php if (!isset($_POST["viewCGPAresults"])) { ?>
                                        <div>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <div class="form-group">
                                                    <label class="col-lg-4 control-label">Matric Number: </label>
                                                    <div class="col-lg-5">
                                                        <input type="text" class="form-control" style="color:#000000" name="regid">
                                                    </div>
                                                    <div class="col-lg-3">
                                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    <?php } ?>
                                    <br>
                                    <hr class="separator" />
                                    <br>
                                    <?php if (isset($_POST["submit"]) || isset($_POST["viewCGPAresults"])) { ?>
                                        <?php

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }
                                        $norecord = "";
                                        if (isset($_POST["viewCGPAresults"])) {
                                            $regid = $_POST["id"];
                                        } else {
                                            $regid = $_POST["regid"];
                                        }
                                        unset($getSessionUnGrad);
                                        $getSessionUnGrad[] = "";

                                        $curtsession = $_SESSION['corntsession'];

                                        $defer1st = $studeptcode = "";

                                        //$cat = $_SESSION['cat'];
                                        $staflevel = $_SESSION['staflevel'];
                                        //$regid = $_POST["regid"];
                                        $dept = $_SESSION['deptcode'];
                                        $siwesstatus = $_SESSION["siwesstatus"];
                                        $schcode = $_SESSION['schcode'];

                                        $studept = "XX";
                                        $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                        $result = $conn2->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $stdid = $row["stdid"];
                                                $studept = strtolower($row['dept_code']);
                                                $defer1st = $row["defer1styear"];
                                                $stuschool = $row["school_code"];
                                                $deptname = $row["department"];
                                                $StartYear = substr($row["entry_session"], 0, 4);
                                                $modeofentry = $row["modeofentry"];
                                                if ($modeofentry == "ND") {
                                                    $prog = "National Diploma";
                                                } elseif ($modeofentry == "HND") {
                                                    $prog = "Higher National Diploma";
                                                }
                                                $entry_level = $row["entry_level"];
                                                $entry_session = $row["entry_session"];
                                                $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                            }
                                        }
                                        /* $sql = "SELECT * FROM std_login WHERE stdid = '$stdid'";
                                        $result = $conn2->query($sql);
                                        if ($result->num_rows > 0) {
                                            $passportid = $stdid;
                                        } else {
                                            $passportid = $regid;
                                        }
 */

                                        $conn2->close();
                                        if ($studept == "XX") {
                                            goto NoRec;
                                        }
                                        include_once 'includes/get_stu_level_staff.php';

                                        if ($cat_L100 == "YES" || $cat_L200 == "YES" || $cat_L300 == "YES" || $cat_L400 == "YES" || $cat_L500 == "YES" || $cat_spill_over == "YES") {
                                            if (strtolower($studept) == strtolower($dept)) {
                                                if ($level == 100) {
                                                    if ($cat_L100 == "NO") {
                                                        $norecord = "Record Does NOT Exist OR Not in your Level";
                                                    }
                                                } elseif ($level == 200) {
                                                    if ($cat_L200 == "NO") {
                                                        $norecord = "Record Does NOT Exist OR Not in your Level";
                                                    }
                                                } elseif ($level == 300) {
                                                    if ($cat_L300 == "NO") {
                                                        $norecord = "Record Does NOT Exist OR Not in your Level";
                                                    }
                                                } elseif ($level == 400) {
                                                    if ($cat_L400 == "NO") {
                                                        $norecord = "Record Does NOT Exist OR Not in your Level";
                                                    }
                                                } elseif ($level == 500) {
                                                    if ($cat_L500 == "NO") {
                                                        $norecord = "Record Does NOT Exist OR Not in your Level";
                                                    }
                                                } elseif ($level == 600) {
                                                    if ($cat_spill_over == "NO") {
                                                        $norecord = "Record Does NOT Exist OR Not in your Level";
                                                    }
                                                }
                                            } else {
                                                $norecord = "Record Does NOT Exist OR Not in your Department";
                                            }
                                        }

                                        if ($cat_HOD == "YES" || $cat_Examiner == "YES" || $cat_Ass_Examiner == "YES") {
                                            if (strtolower($studept) !== strtolower($dept)) {
                                                $norecord = "Record Does NOT Exist OR Not in your Department";
                                            }
                                        }

                                        if ($cat_Dean == "YES" || $cat_SchExaminer == "YES") {
                                            if (strtolower($schcode) !== strtolower($stuschool)) {
                                                $norecord = "Record Does NOT Exist OR Not in your School/Faculty";
                                            }
                                        }


                                        if ($norecord == "") {



                                            $_SESSION["regid"] = $regid;
                                            $_SESSION['studept'] = $studept;
                                            //$_SESSION['stdid'] = $stdid;
                                            $_SESSION['stunames'] = $names;
                                            $_SESSION['studeptname'] = $deptname;
                                            $resultsession = $_SESSION['resultsession'];
                                            $resultsemester = $_SESSION['resultsemester'];

                                            $FinalYear = substr($resultsession, 0, 4);
                                            //$StartYear = substr($regid, 0, 4);
                                            $countses = 0;

                                            $dept_db = $_SESSION['deptdb'] . strtolower($studept);
                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }

                                            for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                $getstuSession2 = $x . "/" . ($x + 1);
                                                $StuCurSess = str_ireplace("/", "_", $getstuSession2);
                                                if ($getstuSession2 < "2014/2015") {
                                                    $deptcorreg = "correg";
                                                } else {
                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                }

                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $countses++;
                                                        $getSessionUnGrad[$countses] = $row['SessionRegis'];
                                                    }
                                                }
                                                $getSessionUnGrad2 = array_unique($getSessionUnGrad);
                                                $lastsession = max($getSessionUnGrad2);
                                            }

                                            $conn_stu->close();
                                            $finalyear = substr($lastsession, 5);

                                            $sessionarry[] = "";
                                            $addyear = 0;
                                            $noarry = 0;
                                            $yearadmt = $StartYear;

                                            for ($x = $StartYear; $x <= $finalyear; $x++) {
                                                $noarry++;
                                                $nextyear = $x + 1;
                                                $sessionarry[$noarry] = "$x/$nextyear";
                                                //$yearadmt++;

                                                if ($lastsession == $sessionarry[$noarry]) {
                                                    break;
                                                }
                                            }


                                            $cgpa = $totsumunits = $totsumgp = 0;
                                        ?>

                                            <section class="panel panel-default">
                                                <header class="panel-heading">

                                                    <h2 class="panel-title"><?php echo $names ?></h2>
                                                </header>
                                                <div class="panel-body">

                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-10">
                                                        <div class="tabs tabs-primary">

                                                            <ul class="nav nav-tabs">
                                                                <li class="active">
                                                                    <a href="#1" data-toggle="tab"><i class="fa fa-star"></i>
                                                                        <?php echo $sessionarry[1] ?></a>
                                                                </li>
                                                                <?php for ($i = 2; $i <= $noarry; $i++) { ?>
                                                                    <li>
                                                                        <a href="#<?php echo $i ?>" data-toggle="tab"><?php echo $sessionarry[$i] ?></a>
                                                                    </li>
                                                                <?php } ?>
                                                                <li>
                                                                    <a href="#all" data-toggle="tab"> All</a>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content">
                                                                <div id="1" class="tab-pane active">
                                                                    <p><?php echo $sessionarry[1] ?></p>
                                                                    <div id="printableArea">

                                                                        <table style="width: 100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style="width: 40%">
                                                                                        Matric Number: <?php echo $regid ?><br>

                                                                                        Name : <?php echo $names ?><br>
                                                                                        Department: <?php echo $deptname ?><br>
                                                                                        <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                                                                            Programme: <?php echo $prog ?>
                                                                                        <?php } ?>
                                                                                    </td>
                                                                                    <td style="width: 40%">
                                                                                        <?php
                                                                                        echo "<center><img alt='testing' src='includes/barcode.php?codetype=code39&size=50&text=" . $names . "'/></center>";
                                                                                        ?>
                                                                                    </td>
                                                                                    <td>
                                                                                        <figure class="profile-picture">
                                                                                            <?php

                                                                                            //$stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                                                            //$passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                                                                            $matpassport = str_replace("/", "_", $regid);
                                                                                            echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='100'>";
                                                                                            ?>
                                                                                        </figure>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <?php
                                                                        $sumunits = $sumgp = $point = $gp = $gpa = 0;
                                                                        $grade = "";
                                                                        $session1 = $sessionarry[1];
                                                                        $_SESSION["mysession"] = $sessionarry[1];

                                                                        include 'includes/result_stu.php';
                                                                        ?>
                                                                    </div>
                                                                    <div class="row" style="text-align: right">
                                                                        <br>
                                                                        <input type="button" onclick="printDiv('printableArea')" value="print" class="btn-success" />
                                                                    </div>
                                                                </div>
                                                                <?php for ($i = 2; $i <= $noarry; $i++) { ?>
                                                                    <div id="<?php echo $i ?>" class="tab-pane">
                                                                        <p><?php echo $sessionarry[$i] ?></p>
                                                                        <div id="printableArea<?php echo $i ?>">

                                                                            <table style="width: 100%">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="width: 40%">
                                                                                            Matric Number: <?php echo $regid ?><br>

                                                                                            Name : <?php echo $names ?><br>
                                                                                            Department: <?php echo $deptname ?><br>
                                                                                            <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                                                                                Programme: <?php echo $prog ?>
                                                                                            <?php } ?>
                                                                                        </td>
                                                                                        <td style="width: 40%">
                                                                                            <?php
                                                                                            echo "<center><img alt='testing' src='includes/barcode.php?codetype=code39&size=50&text=" . $names . "'/></center>";
                                                                                            ?>
                                                                                        </td>
                                                                                        <td>
                                                                                            <figure class="profile-picture">
                                                                                                <?php
                                                                                                $matpassport = str_replace("/", "_", $regid);
                                                                                                echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='100'>";


                                                                                                ?>
                                                                                            </figure>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                            <?php
                                                                            $sumunits = $sumgp = $point = $gp = $gpa = 0;
                                                                            $grade = "";
                                                                            $session1 = $sessionarry[$i];
                                                                            $_SESSION["mysession"] = $sessionarry[$i];

                                                                            include 'includes/result_stu.php';
                                                                            ?>

                                                                        </div>
                                                                        <div style="text-align: right">
                                                                            <input type="button" onclick="printDiv('printableArea<?php echo $i ?>')" value="print" class="btn-success" />
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>

                                                                <div id="all" class="tab-pane">
                                                                    <p>All</p>
                                                                    <div id="printableAreaAll">
                                                                        <table style="width: 100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style="width: 40%">
                                                                                        Matric Number: <?php echo $regid ?><br>

                                                                                        Name : <?php echo $names ?><br>
                                                                                        Department: <?php echo $deptname ?><br>
                                                                                        <?php if ($_SESSION['InstType'] == "Polytechnic") {  ?>
                                                                                            Programme: <?php echo $prog ?>
                                                                                        <?php } ?>
                                                                                    </td>
                                                                                    <td style="width: 40%">
                                                                                        <?php
                                                                                        echo "<center><img alt='testing' src='includes/barcode.php?codetype=code39&size=50&text=" . $names . "'/></center>";
                                                                                        ?>
                                                                                    </td>
                                                                                    <td>
                                                                                        <figure class="profile-picture">
                                                                                            <?php
                                                                                            $matpassport = str_replace("/", "_", $regid);
                                                                                            echo "<img alt=''  class='img-circle' src='img/stupassport/$matpassport.jpg' width='100' height='100'>";
                                                                                            ?>
                                                                                        </figure>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <?php
                                                                        $sumunits = $sumgp = $point = $gp = $gpa = 0;
                                                                        /*$grade="";
							                                        $_SESSION["mysession"]="";
							                                        $session2="";
							                                        $session3="";
							                                       	include 'includes/result_stu.php'; */
                                                                        ?>

                                                                        <table class="table mb-none">
                                                                            <thead>
                                                                                <tr>
                                                                                    <th>Course Code</th>
                                                                                    <th>Course Title</th>
                                                                                    <th>Unit</th>
                                                                                    <th>Semester</th>
                                                                                    <th>Session</th>
                                                                                    <th>Grade</th>
                                                                                    <th>GP</th>
                                                                                </tr>
                                                                            </thead>
                                                                            <tbody>
                                                                                <?php
                                                                                $dept_db = $_SESSION['deptdb'] . strtolower($studept);
                                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                if ($conn_stu->connect_error) {
                                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                                }
                                                                                for ($i = 1; $i <= $noarry; $i++) {
                                                                                    $session1 =  $sessionarry[$i];
                                                                                    $StuCurSess = str_ireplace("/", "_", $session1);

                                                                                    //$deptcorreg = "correg_" . $StuCurSess;

                                                                                    if ($session1 < "2014/2015") {
                                                                                        $deptcorreg = "correg";
                                                                                    } else {
                                                                                        $deptcorreg = "correg_" . $StuCurSess;
                                                                                    }


                                                                                    if ($resultsemester == "1ST") {
                                                                                        if ($session1 == $resultsession) {
                                                                                            $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis  = '$session1' AND SemTaken  = '1ST' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
                                                                                        } else {
                                                                                            $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis  = '$session1' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
                                                                                        }
                                                                                    } else {
                                                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$regid' AND SessionRegis  = '$session1' AND coursecondon = 'NO' ORDER BY SessionRegis, SemTaken, CCode";
                                                                                    }

                                                                                    $result = $conn_stu->query($sql);
                                                                                    if ($result->num_rows > 0) {
                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                            $grade = $row['grade'];
                                                                                            $gp = $row['point'];



                                                                                            echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['SessionRegis']}</td><td>$grade</td><td>$gp</td></tr>\n";
                                                                                            $sumunits += $row['CUnit'];

                                                                                            $sumgp += $gp;
                                                                                        }
                                                                                    }
                                                                                }
                                                                                $conn_stu->close();
                                                                                echo "<tr><td></td><th>Total</th><th>$sumunits</th><td></td><td></td><td></td><th>$sumgp</th></tr>";
                                                                                ?>
                                                                            </tbody>
                                                                        </table>
                                                                        <br>
                                                                        <center>
                                                                            <?php
                                                                            $totsumunits += $sumunits;
                                                                            $totsumgp += $sumgp;
                                                                            ?>
                                                                            <?php if ($sumunits > 0) { ?>
                                                                                GPA =
                                                                                <?php echo number_format((float)$sumgp / $sumunits, 2, '.', ''); ?>
                                                                            <?php } ?>
                                                                            <br>
                                                                            <?php if ($totsumunits > 0) { ?>
                                                                                CGPA =
                                                                                <?php echo number_format((float)$totsumgp / $totsumunits, 2, '.', ''); ?>
                                                                            <?php } ?>
                                                                        </center>

                                                                    </div>
                                                                    <div style="text-align: right">
                                                                        <input type="button" onclick="printDiv('printableAreaAll')" value="print" class="btn-success" />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-1">
                                                    </div>

                                                </div>
                                            </section>
                                            <?php
                                            NoRec:
                                            ?>
                                        <?php } else { ?>
                                            <h4>
                                                <center><?php echo $norecord ?></center>
                                            </h4>
                                        <?php } ?>

                                    <?php } ?>
                                </div>
                                <div class="col-md-1">
                                </div>

                            </div>
                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['upload_result(e-exam)'] == false) {
    header('Location: Home_Staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Drop Results</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-upload"></i>
                                </a>
                            </li>
                            <li><span>Upload</span></li>
                            <li><span>Drop Results</span></li>
                        </ol>


                    </div>
                </header>

                <!-- start: page -->

                <div class="row">

                    <div class="col-lg-12  col-md-12">

                        <div class="col-lg-12">
                            <section class="panel panel-success">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>

                                    <h2 class="panel-title">Drop Results</h2>
                                </header>
                                <div class="panel-body">
                                    <?php
                                    $droprec = "";

                                    $corntsession = $_SESSION['corntsession'];
                                    $dbsession = str_replace("/", "_", $corntsession);
                                    if (isset($_POST["dropfile"])) {
                                        $ccode = $_POST['course'];
                                        $sql = "DELETE FROM e_exam_results_" . $dbsession . " WHERE ccode = '$ccode' AND session_regist = '$corntsession'";
                                        $result = $conn->query($sql);
                                        $droprec = "Record Droped";
                                    }
                                    ?>
                                    <form enctype="multipart/form-data" action="" method="post">

                                        <br>
                                        <?php
                                        if (isset($_POST["dropfile"])) {
                                            echo "<center><h2>$droprec</h2></center>";
                                        }
                                        ?>

                                        <br>
                                        <div class="form-group">

                                            <label class="col-lg-4 control-label">Current Session:-</label>
                                            <div class="col-lg-6">
                                                <label class="control-label"><?php echo $corntsession ?></label>
                                            </div>
                                        </div>
                                        <br><br>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Select Course</label>
                                            <div class="col-lg-6">
                                                <select class="form-control" style="color:#000000" name="course">
                                                    <option value="SelectItem">Select Item</option>
                                                    <?php
                                                    $sql = "SELECT * FROM gencoursesupload ORDER BY C_codding";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $coursecode = $row["C_codding"];
                                                            $coursetitle = $row["C_title"];
                                                            echo "<option value='$coursecode'>$coursecode $coursetitle</option>";
                                                        }
                                                    }
                                                    //$conn->close();
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <br><br>
                                        <div class="form-group">

                                            <div class="col-lg-4">

                                            </div>
                                            <div class="col-lg-8">
                                                <input type="submit" name="dropfile" value="Drop Result" class="btn btn-primary btn-sm">
                                            </div>
                                        </div>

                                    </form>

                                </div>

                            </section>


                        </div>

                    </div>

                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>

</body>

</html>
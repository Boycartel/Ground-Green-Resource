<?php
require_once 'includes/db_connect.php';

require_once 'includes/check_validity.php';

if ($_SESSION['pg_course_setup'] == false) {
    header('Location: Home_Staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--To Delete
		<link href='delete_res/bootstrap/css/bootstrap.min.css' rel='stylesheet' type='text/css'>-->
    <script src='delete_res/jquery-3.3.1.js' type='text/javascript'> </script>
    <script src='delete_res/bootstrap/js/bootstrap.min.js'> </script>
    <script src='delete_res/bootbox.min.js'> </script>

    <!-- End To Delete -->


    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Setup</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Course Setup</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <?php $_SESSION['loadformval'] = "YES"; ?>
                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Setup
                        </div>
                        <div class="panel-body">
                            <div>
                                <?php
                                // Create connection
                                $dept = $_SESSION['deptcode'];

                                $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' ORDER BY CCode";
                                $result = $conn5->query($sql);

                                if ($result->num_rows > 0) {
                                ?>
                                    <table class="table mb-none">
                                        <thead>
                                            <tr>
                                                <th>Course Code</th>
                                                <th>Course Title</th>
                                                <th>Unit</th>
                                                <th>Semester</th>
                                                <th>Nature</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // output data of each row
                                            while ($row = $result->fetch_assoc()) {
                                                $id = $row["id"];
                                                $ccode = $row["CCode"];
                                                $CTitle = $row["CTitle"];
                                                $CUnit = $row["CUnit"];
                                                $SemTaken = $row["SemTaken"];
                                                $Nature = $row["Nature"];

                                                echo "<tr><td>$ccode</td><td>$CTitle</td><td>$CUnit</td><td>$SemTaken</td><td>$Nature</td>													
													<td>
													 	
														<button class='delete_course btn btn-danger btn-xs' id='del_.$id' data-id='$id'>Delete</button>
													</td>
													</tr>\n";
                                            }
                                            ?>
                                        </tbody>
                                    </table>

                                <?php
                                }
                                //$conn->close();


                                ?>


                                <br><br>
                                <div class="col-lg-12"><a class="btn btn-primary" href="course_setup_add_pg.php">Add
                                        Courses</a></div>


                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>

            <div id="right-sidebar">

                <?php
                include_once 'includes/aside_right.php';
                ?>

            </div>

        </div>

        <?php
        include_once 'includes/footer.php';
        ?>

        <script>
            $(document).ready(function() {

                // Delete 
                $('.delete_course').click(function() {
                    var el = this;

                    // Delete id
                    var deleteid = $(this).data('id');

                    // Confirm box
                    bootbox.confirm("Do you really want to delete record?", function(result) {

                        if (result) {
                            // AJAX Request
                            $.ajax({
                                url: 'delete_res/delete_course_pg.php',
                                type: 'POST',
                                data: {
                                    id: deleteid
                                },
                                success: function(response) {

                                    // Removing row from HTML Table
                                    if (response == 1) {
                                        $(el).closest('tr').css('background', 'tomato');
                                        $(el).closest('tr').fadeOut(800, function() {
                                            $(this).remove();
                                        });
                                    } else {
                                        bootbox.alert('Record not deleted.');
                                    }

                                }
                            });
                        }

                    });

                });

            });
        </script>
</body>

</html>
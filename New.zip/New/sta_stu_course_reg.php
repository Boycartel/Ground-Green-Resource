<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['sta_stu_course_reg'] == false) {
    header('Location: Home_Staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>

    <!--Check All checkbox-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script type="text/javascript" charset="utf-8">
    $(document).ready(function() {
        var $selectAll = $('#selectAll1'); // main checkbox inside table thead
        var $table = $('.tablechk1'); // table selector 
        var $tdCheckbox = $table.find('tbody input:checkbox'); // checboxes inside table body
        var tdCheckboxChecked = 0; // checked checboxes

        // Select or deselect all checkboxes depending on main checkbox change
        $selectAll.on('click', function() {
            $tdCheckbox.prop('checked', this.checked);
        });

        // Toggle main checkbox state to checked when all checkboxes inside tbody tag is checked
        $tdCheckbox.on('change', function(e) {
            tdCheckboxChecked = $table.find('tbody input:checkbox:checked')
                .length; // Get count of checkboxes that is checked
            // if all checkboxes are checked, then set property of main checkbox to "true", else set to "false"
            $selectAll.prop('checked', (tdCheckboxChecked === $tdCheckbox.length));
        })
    });
    </script>

    <script type="text/javascript">
    function printDiv(div_id) {
        var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
        disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
        var content_vlue = document.getElementById(div_id).innerHTML;

        var docprint = window.open("", "", disp_setting);

        ///// Enable Bootstrap CSS
        //// Can also add customise CSS
        docprint.document.write(
            '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">'
        );
        docprint.document.write(
            '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
        );
        docprint.document.write(content_vlue);
        docprint.document.write('</body></html>');
        docprint.document.close();
        docprint.focus();
    }
    </script>

</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Students' Registered Courses</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Courses
                            </li>

                            <li class="active">
                                <strong>Students' Registered Courses</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students' Registered Courses
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="col-lg-1">

                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="control-label col-lg-5" for="regid"><strong>Matric
                                                    Number</strong></label>
                                            <div class="col-lg-6">
                                                <input class="form-control" name="regid" id="regid"></input>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="col-lg-5 control-label"><strong>Session:</strong></label>
                                            <div class="col-lg-6">
                                                <?php
                                                $iniyear = 2015;
                                                $finalyear = substr($_SESSION['corntsession'], 5);

                                                ?>
                                                <select name="sesion" class="form-control" style="color:#000000"
                                                    id="sesion">
                                                    <option value="<?php echo $_SESSION['corntsession'] ?>">
                                                        <?php echo $_SESSION['corntsession'] ?></option>
                                                    <?php
                                                    while ($iniyear <= $finalyear) {
                                                        $addyear = $iniyear + 1;

                                                        echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                        $iniyear++;
                                                    }

                                                    ?>

                                                </select>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <div class="col-lg-offset-2 col-lg-9">
                                                <button type="submit" name="submit"
                                                    class="btn btn-primary btn-sm">Submit</button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1">

                                    </div>
                                </form>
                                <hr class="separator" />

                                <?php
                                $norecord = "";
                                $leveladv = $HOD = $Dean = $Registrar = "Yet";
                                ?>

                                <div class="col-lg-1">

                                </div>
                                <div class="col-lg-10">
                                    <?php
                                    if (isset($_POST["submit2"])) {
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        $names = $_SESSION['names'];
                                        $names = str_replace("'", "''", $names);
                                        $IsYearAdmt = strlen($_SESSION['YAddmitted']);
                                        if ($_SESSION['modeofentry'] == "DE") {
                                            $YearAdmt = substr($_SESSION['entry_session'], 0, 4);
                                            $YearAdmtDE = intval($YearAdmt) - 1;
                                        } else {
                                            $YearAdmt = substr($_SESSION['entry_session'], 0, 4);
                                            $YearAdmtDE = "XXXX";
                                        }

                                        $regid = $_SESSION["regid"];
                                        $dept = $_SESSION['deptcode'];
                                        $curtsession = $_SESSION['corntsession'];

                                        $sql = "DELETE FROM add_courses_cat WHERE Regn1 ='$regid'";
                                        $result = $conn->query($sql);

                                        $sql = "SELECT * FROM std_data_payment WHERE Matriculation_no = '$regid' AND session = '$curtsession' AND (payment_cat = 'registration' OR payment_cat = 'registration_dce') AND (pay_or_skip LIKE 'pay' OR pay_or_skip LIKE 'skip')";
                                        $result = $conn2->query($sql);
                                        if ($result->num_rows == 0) {
                                            goto NotPay;
                                        }

                                        $stucurriculum = strtoupper($_SESSION['stucurriculum']);
                                        $stateorigin = $_SESSION['stateorigin'];
                                        $lga = $_SESSION['lga'];

                                        if ($stucurriculum == "OLD") {
                                            $curri2 = "";
                                        } else {
                                            $curri2 = "_" . $stucurriculum;
                                        }



                                        $date1 = date("Y-m-d");
                                        $dbsession = str_replace("/", "_", $curtsession);
                                        $sql = "DELETE FROM courses_register_" . $dbsession . " WHERE Regn1 ='$regid'";
                                        $result = $conn->query($sql);


                                        $StuCurSess = str_ireplace("/", "_", $curtsession);
                                        $deptcorreg = "correg_" . $StuCurSess;


                                        $CCodeArry = $_SESSION["CCodeArry"];
                                        $CUnitArry = $_SESSION["CUnitArry"];
                                        $CTitleArry = $_SESSION["CTitleArry"];
                                        $SemTakenArry = $_SESSION["SemTakenArry"];
                                        $NatureArry = $_SESSION["NatureArry"];
                                        $countCC = $_SESSION["countCC"];

                                        for ($i = 1; $i <= $countCC; $i++) {
                                            $ccode = $CCodeArry[$i];
                                            $CTitle = str_replace("'", "''", $CTitleArry[$i]);
                                            $CUnit = $CUnitArry[$i];
                                            $SemTaken = $SemTakenArry[$i];
                                            $Nature = $NatureArry[$i];

                                            $sql2 = "INSERT INTO courses_register_" . $dbsession . " (Regn1, name1, CCode, CUnit, CTitle, SemTaken, Nature, session, departments, date) VALUES ('$regid', '$names', '$ccode', '$CUnit', '$CTitle', '$SemTaken', '$Nature', '$curtsession', '$dept', '$date1')";
                                            $result2 = $conn->query($sql2);

                                            $sql3 = "SELECT COUNT(*) AS total FROM courses_register_" . $dbsession . "  WHERE CCode = '$ccode'";
                                            $result3 = $conn->query($sql3);
                                            $row3 = $result3->fetch_assoc();
                                            $totalRows = $row3["total"];

                                            $sql2 = "UPDATE gencoursesupload SET totStu = '$totalRows' WHERE C_codding = '$ccode'";
                                            $result2 = $conn->query($sql2);
                                        }


                                        if ($IsYearAdmt < 4) {
                                            $sql2 = "UPDATE std_data_view SET getme = 'NO', session_reg_status = 'YES', YAddmitted = '$YearAdmt', YAddmittedDir = '$YearAdmtDE' WHERE matric_no = '$regid'";
                                            $result2 = $conn2->query($sql2);
                                        } else {
                                            $sql2 = "UPDATE std_data_view SET getme = 'NO', session_reg_status = 'YES' WHERE matric_no = '$regid'";
                                            $result2 = $conn2->query($sql2);
                                        }

                                        $sql = "SELECT * FROM hod_list WHERE matricno = '$regid' AND Session1 ='$curtsession'";
                                        $result = $conn_stu->query($sql);
                                        if ($result->num_rows == 0) {
                                            $sql2 = "INSERT INTO hod_list (matricno, LevelAdvice, HOD, Dean, Registrar, session1, StuLevel, LAComment, HODComment, DeanComment, RegisComment, stateorigin, name1, lga) VALUES ('$regid', 'Yet', 'Yet', 'Yet', 'Yet', '$curtsession', '$level', '_', '_', '_', '_', '$stateorigin', '$names', '$lga')";
                                            $result2 = $conn_stu->query($sql2);
                                        }

                                        goto MoveEnd;
                                        NotPay:
                                        echo "<h2 style='text-align:center;color:red'>Error: Student NOT Pay for the Session </h2>";
                                        MoveEnd:

                                        $conn->close();
                                        $conn2->close();
                                        $conn_stu->close();
                                    }
                                    ?>

                                    <?php if (isset($_POST["submit"]) || isset($_POST["submitprev"]) || isset($_POST["submitreg"]) || isset($_POST["submit2"])) { ?>
                                    <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        $staflevel = $_SESSION['staflevel'];

                                        $staffdept = $_SESSION['deptcode'];
                                        $siwesstatus = $_SESSION["siwesstatus"];
                                        $schcode = $_SESSION['schcode'];
                                        if (isset($_POST["submit"])) {
                                            $regid = $_POST["regid"];
                                            $sesion1 = $_POST["sesion"];
                                            $_SESSION['regid'] = $regid;
                                            $_SESSION["sesion1"] = $sesion1;
                                        } else {

                                            $regid = $_SESSION['regid'];
                                            $sesion1 = $_SESSION["sesion1"];
                                        }

                                        //

                                        $courseRegSplitSess = $_SESSION['courseRegSplitSess'];

                                        $sql = "SELECT * FROM std_data_view WHERE matric_no = '$regid'";
                                        $result = $conn2->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $studept = strtolower($row['dept_code']);
                                                $defer1st = $row["defer1styear"];
                                                $stuschool = $row["school_code"];
                                                $_SESSION["stulevelsess"] = $row["level"];
                                                $_SESSION["studeptsess"] = $row["dept_code"];
                                                $_SESSION['names'] = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                $_SESSION['stucurriculum'] =  $row["curriculum"];
                                                $_SESSION['stateorigin'] = $row["state"];
                                                $_SESSION['lga'] = $row["lga"];
                                                $_SESSION['entry_session'] = $row["entry_session"];
                                            }
                                        }
                                        $conn->close();
                                        $conn2->close();

                                        include_once 'includes/get_stu_level_staff.php';
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        if ($cat_L100 == "YES" || $cat_L200 == "YES" || $cat_L300 == "YES" || $cat_L400 == "YES" || $cat_L500 == "YES") {
                                            if (strtolower($studept) == strtolower($staffdept)) {
                                                if ($staflevel !== $level) {
                                                    //header('Location: no_record.html');
                                                    $norecord = "Record Does NOT Exist OR Not in your Level/Department/School";
                                                }
                                            } else {
                                                $norecord = "Record Does NOT Exist OR Not in your Level/Department/School";
                                            }
                                        }

                                        if ($cat_HOD == "YES" || $cat_PG_Coord == "YES" || $cat_Examiner == "YES") {
                                            if (strtolower($studept) !== strtolower($staffdept)) {
                                                //header('Location: no_record.html');	
                                                $norecord = "Record Does NOT Exist OR Not in your Level/Department/School";
                                            }
                                        }

                                        if ($cat_Dean == "YES" || $cat_SchExaminer == "YES") {
                                            if (strtolower($schcode) !== strtolower($stuschool)) {
                                                //header('Location: no_record.html');
                                                $norecord = "Record Does NOT Exist OR Not in your Level/Department/School";
                                            }
                                        }
                                        ?>
                                    <div id="printableArea">
                                        <?php
                                            if ($norecord == "") {
                                                $corntsession = $_SESSION['corntsession'];

                                                $tot1stoutunit = $tot2ndoutunit = 0;

                                                $sql = "SELECT entry_session, dept_code, first_name, other_name, surname, matric_no, stdid, department FROM std_data_view WHERE matric_no = '$regid'";
                                                $result = $conn2->query($sql);

                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $dept = strtolower($row["dept_code"]);
                                                        $entry_session = $row['entry_session'];
                                                        $stdid = $row["stdid"];
                                                        $deptname = $row["department"];

                                                        $names = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                        $names = strtolower($names);
                                                        $names = ucwords($names);
                                                    }
                                                }
                                                $sql = "SELECT * FROM std_login WHERE stdid = '$stdid'";
                                                $result = $conn2->query($sql);
                                                if ($result->num_rows > 0) {
                                                    $passportid = $stdid;
                                                } else {
                                                    $passportid = $regid;
                                                }
                                            ?>
                                        <table style="width: 100%">
                                            <tr>
                                                <td><?php echo "Matric No: " . $regid; ?><br><?php echo "Name:  " . $names; ?>
                                                </td>
                                                <td style="text-align:right">
                                                    <figure class="profile-picture">
                                                        <?php
                                                                $stu_pic_folder = $_SESSION['stu_pic_folder'];
                                                                $passptfile = str_replace("/", "", $passportid) . "_passport.jpg";
                                                                echo "<img alt=''  class='img-circle' src='$stu_pic_folder/$passptfile' width='100' height='100'>";
                                                                ?>
                                                    </figure>
                                                </td>
                                            </tr>
                                        </table>
                                        <?php

                                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }
                                                $sql = "SELECT * FROM hod_list WHERE Session1 = '$corntsession'  AND matricno = '$regid'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $leveladv = $row["LevelAdvice"];
                                                        $HOD = $row["HOD"];
                                                        $Dean = $row["Dean"];
                                                        $Registrar = $row["Registrar"];
                                                        $LAName = $row["LAName"];
                                                        $HODName = $row["HODName"];
                                                    }
                                                }
                                                ?>
                                        <?php if ($leveladv == "Validate") { ?>
                                        <h3 style="text-align: center;"><strong> Approved Courses</strong> </h3>
                                        <?php } ?>
                                        <h3 style='text-align:center'><strong><?php echo $deptname ?>
                                                Department<br>Course Registration Form</strong></h3>

                                        <?php


                                                if ($sesion1 < $courseRegSplitSess) {
                                                    $sql = "SELECT * FROM courses_register WHERE Regn1 = '$regid' AND session ='$sesion1' AND SemTaken = '1ST'";
                                                } else {
                                                    $dbsession = str_replace("/", "_", $sesion1);
                                                    $sql = "SELECT * FROM courses_register_" . $dbsession . " WHERE Regn1 = '$regid' AND SemTaken = '1ST'";
                                                }
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    // output data of each row
                                                ?>
                                        <center>
                                            <h3>Session: <?php echo $curtsession ?><br>1ST Semester Courses</h3>
                                        </center>
                                        <table class="table table-bordered" cellspacing="0" rules="all" border="1"
                                            style="width: 100%">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Nature</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                            while ($row = $result->fetch_assoc()) {
                                                                $id = $row["sn"];
                                                                $ccode = $row["CCode"];
                                                                $CTitle = $row["CTitle"];
                                                                $CUnit = $row["CUnit"];
                                                                $SemTaken = $row["SemTaken"];
                                                                $Nature = $row["Nature"];

                                                                $tot1stoutunit += $row['CUnit'];


                                                                //echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['Nature']}</td></tr>\n";
                                                                echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>$Nature</td></tr>\n";
                                                            }
                                                            ?>
                                            </tbody>
                                        </table>

                                        <?php
                                                    echo "<center> Total Credit Units : $tot1stoutunit</center>";
                                                }
                                                //$conn->close();

                                                ?>

                                        <br /><br />
                                        <?php


                                                if ($sesion1 < $courseRegSplitSess) {
                                                    $sql = "SELECT * FROM courses_register WHERE Regn1 = '$regid' AND session ='$sesion1' AND SemTaken = '2ND'";
                                                } else {
                                                    $dbsession = str_replace("/", "_", $sesion1);
                                                    $sql = "SELECT * FROM courses_register_" . $dbsession . " WHERE Regn1 = '$regid' AND SemTaken = '2ND'";
                                                }
                                                //$sql = "SELECT * FROM courses_register WHERE Regn1 = '$regid' AND session ='$sesion1' AND SemTaken = '2ND'";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    // output data of each row
                                                ?>
                                        <p>
                                            <center>2ND Semester Courses</center>
                                        </p>
                                        <table class="table table-bordered" cellspacing="0" rules="all" border="1"
                                            style="width: 100%">
                                            <thead>
                                                <tr>
                                                    <th>Course Code</th>
                                                    <th>Course Title</th>
                                                    <th>Unit</th>
                                                    <th>Semester</th>
                                                    <th>Nature</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                            while ($row = $result->fetch_assoc()) {

                                                                $id = $row["sn"];
                                                                $ccode = $row["CCode"];
                                                                $CTitle = $row["CTitle"];
                                                                $CUnit = $row["CUnit"];
                                                                $SemTaken = $row["SemTaken"];
                                                                $Nature = $row["Nature"];

                                                                $tot2ndoutunit += $row['CUnit'];


                                                                //echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>{$row['Nature']}</td></tr>\n";
                                                                echo "<tr><td>{$row['CCode']}</td><td>{$row['CTitle']}</td><td>{$row['CUnit']}</td><td>{$row['SemTaken']}</td><td>$Nature</td></tr>\n";
                                                            }
                                                            ?>
                                            </tbody>
                                        </table>

                                        <?php
                                                    echo "<center> Total Credit Units : $tot2ndoutunit</center>";
                                                } else {
                                                }
                                                //$conn->close();


                                                ?>
                                        <br>
                                        <br>
                                        <div>
                                            <table class="table table-hover margin bottom" style="width: 100%">
                                                <tbody>
                                                    <tr>
                                                        <td style="width: 50%">
                                                            <?php if ($leveladv == "Validate") { ?>
                                                            <strong><input type="checkbox" name="LevelAdvice"
                                                                    checked="checked" disabled="disabled"> Level
                                                                Adviser</strong>
                                                            <br>Validated By <?php echo $LAName ?> <br>
                                                            <?php } else { ?>
                                                            <input type="checkbox" name="LevelAdvice"
                                                                disabled="disabled">
                                                            Level
                                                            Adviser<br>
                                                            <?php } ?>
                                                        </td>
                                                        <!--
                                                                <td style="width: 50%">
                                                                    <?php if ($Dean == "Validate") { ?>
                                                                        <strong><input type="checkbox" name="Dean" checked="checked" disabled="disabled"> Dean</strong>
                                                                        <br>Validated
                                                                    <?php } else { ?>
                                                                        <input type="checkbox" name="Dean" disabled="disabled">
                                                                        Dean<br>
                                                                    <?php } ?>
                                                                </td>
                                                                    -->
                                                        <td style="width: 50%">
                                                            <?php if ($HOD == "Validate") { ?>
                                                            <strong><input type="checkbox" name="HOD" checked="checked"
                                                                    disabled="disabled">
                                                                HOD</strong>
                                                            <br>Validated By <?php echo $HODName ?><br>
                                                            <?php } else { ?>
                                                            <input type="checkbox" name="HOD" disabled="disabled">
                                                            HOD<br>
                                                            <?php } ?>
                                                        </td>
                                                        <!--
                                                        <td>
                                                            <?php if ($Registrar == "Validate") { ?>
                                                            <strong><input type="checkbox" name="Registrar"
                                                                    checked="checked" disabled="disabled">
                                                                Registrar</strong>
                                                            <br>Validated
                                                            <?php } else { ?>
                                                            <input type="checkbox" name="Registrar" disabled="disabled">
                                                            Registrar<br>
                                                            <?php } ?>
                                                        </td> -->
                                                    </tr>
                                                </tbody>
                                            </table>

                                        </div>
                                        <br><br><br>



                                        <?php } else { ?>
                                        <h4>
                                            <center><?php echo $norecord ?></center>
                                        </h4>
                                        <?php } ?>
                                    </div>
                                    <div style="text-align: right">
                                        <?php if ($leveladv == "Validate") { ?>
                                        <input type="button" onclick="printDiv('printableArea')" value="print"
                                            class="btn-success" />
                                        <?php } ?>
                                        <div style="text-align: left;">
                                            <?php if ($_SESSION['pass_reset_admin'] == true) { ?>
                                            <form class="form-horizontal" role="form" method="post" action="">
                                                <button type="submit" name="submitreg" class="btn btn-primary">Register
                                                    Courses</button>
                                            </form>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <?php
                                        $conn->close();
                                        $conn2->close();
                                        $conn_stu->close();
                                        ?>
                                    <?php } ?>
                                    <div>
                                        <?php if (isset($_POST["submitprev"])) { ?>
                                        <?php
                                            $dept = $_SESSION['studeptsess'];
                                            $minCredit = $_SESSION['minCredit'];
                                            $MaxCredit = $_SESSION['MaxCredit'];

                                            $minCreditNew = $_SESSION['minCreditNew'];
                                            $MaxCreditNew = $_SESSION['MaxCreditNew'];
                                            $level = $_SESSION["stulevelsess"];

                                            $ccode2c = $CTitle2c = $CUnit2c = $SemTaken2c = $Nature2c = "";
                                            $ccode1c = $CTitle1c = $CUnit1c = $SemTaken1c = $Nature1c = "";
                                            $ccode = $CTitle = $CUnit = $SemTaken = $Nature = "";
                                            $stopit = "No";
                                            $countrepcourse = 0;
                                            $get4lcourse = "";

                                            $regid = $_SESSION["regid"];
                                            include 'includes/get_stu_level_staff.php';

                                            $sum1st = $sum2nd = 0;
                                            $TCP400 = $SIW400 = $SWP400 = "";
                                            $countsiwtp1 = $countsiwtp2 = 0;

                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                            if ($conn2->connect_error) {
                                                die("Connection failed: " . $conn2->connect_error);
                                            }

                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }

                                            ?>
                                        <form class="form-horizontal" role="form" method="post" action="">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Curriculum</th>

                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php



                                                        unset($CCodeArry);
                                                        unset($CUnitArry);
                                                        unset($CTitleArry);
                                                        unset($SemTakenArry);
                                                        unset($NatureArry);

                                                        $CCodeArry[] = "";
                                                        $CUnitArry[] = 0;
                                                        $CTitleArry[] = "";
                                                        $SemTakenArry[] = "";
                                                        $NatureArry[] = "";
                                                        $countCC = 0;
                                                        if (!empty($_POST["chosen2c"])) {
                                                            foreach ($_POST["chosen2c"] as $key => $value) {

                                                                //echo $_POST["chosen"][$key];

                                                                $ccode2c = $_POST["ccodec2"][$key];
                                                                $CTitle2c = str_replace("'", "''", $_POST["CTitlec2"][$key]);
                                                                $CUnit2c = $_POST["CUnitc2"][$key];
                                                                $SemTaken2c = strtoupper($_POST["SemTakenc2"][$key]);
                                                                $Nature2c = $_POST["Naturec2"][$key];


                                                                //if ($countsiwtp1 == 0) {
                                                                if ($SemTaken2c == "1ST") {
                                                                    $sum1st += $CUnit2c;
                                                                    echo "<tr><td>$ccode2c</td><td>$CTitle2c</td><td>$CUnit2c</td><td>$SemTaken2c</td><td>$Nature2c</td></tr>\n";

                                                                    $countCC++;
                                                                    $CCodeArry[$countCC] = $ccode2c;
                                                                    $CUnitArry[$countCC] = $CUnit2c;
                                                                    $CTitleArry[$countCC] = $CTitle2c;
                                                                    $SemTakenArry[$countCC] = $SemTaken2c;
                                                                    $NatureArry[$countCC] = $Nature2c;
                                                                }
                                                                //}
                                                            }
                                                        }


                                                        ?>
                                                </tbody>
                                            </table>
                                            <br>
                                            <?php

                                                echo "<center> Total Credit Units : $sum1st</center>";
                                                ?>

                                            <?php
                                                if ($_SESSION['InstType'] == "University") {

                                                    if ($level == "600") {
                                                        if ($sum1st > $MaxCredit) {
                                                            echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    } else {
                                                        if ($level == "100") {
                                                            if ($sum1st < $minCreditNew) {
                                                                echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCreditNew Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                            if ($sum1st > $MaxCreditNew) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCreditNew Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        } else {
                                                            if ($sum1st < $minCredit) {
                                                                echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                            if ($sum1st > $MaxCredit) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        }
                                                    }
                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                    if ($modeofentry == "ND") {
                                                        if ($level == "100" || $level == "200") {

                                                            if ($sum1st < $minCredit) {
                                                                echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                            if ($level == "200") {
                                                                $MaxCredit2 = $MaxCredit + 4;
                                                                if ($sum1st > $MaxCredit2) {
                                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit2 Unit per semester</center></strong>";
                                                                    $stopit = "Yes";
                                                                }
                                                            } else {
                                                                if ($sum1st > $MaxCredit) {
                                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                    $stopit = "Yes";
                                                                }
                                                            }
                                                        } else if ($level == "600") {
                                                            if ($sum1st > $MaxCredit) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        }
                                                    } else {
                                                        if ($level == "300" || $level == "400") {

                                                            if ($sum1st < $minCredit) {
                                                                echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }

                                                            if ($sum1st > $MaxCredit) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        } else if ($level == "600") {
                                                            if ($sum1st > $MaxCredit) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        }
                                                    }
                                                }




                                                ?>
                                            <br /><br>

                                            <!-- Second Semester -->
                                            <?php
                                                $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $siwes = $row["siwes"];
                                                        $siwes_level = $row["siwes_level"];
                                                        $siwes_unit = $row["siwes_unit"];
                                                        $siwes_semester = $row["siwes_semester"];
                                                    }
                                                }
                                                ?>
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Status</th>

                                                    </tr>
                                                </thead>
                                                <tbody>


                                                    <?php

                                                        if (!empty($_POST["chosen2c"])) {
                                                            foreach ($_POST["chosen2c"] as $key => $value) {

                                                                //echo $_POST["chosen"][$key];

                                                                $ccode2c = $_POST["ccodec2"][$key];
                                                                $CTitle2c = str_replace("'", "''", $_POST["CTitlec2"][$key]);
                                                                $CUnit2c = $_POST["CUnitc2"][$key];
                                                                $SemTaken2c = strtoupper($_POST["SemTakenc2"][$key]);
                                                                $Nature2c = $_POST["Naturec2"][$key];

                                                                if ($SemTaken2c == "2ND") {
                                                                    $sum2nd += $CUnit2c;
                                                                    echo "<tr><td>$ccode2c</td><td>$CTitle2c</td><td>$CUnit2c</td><td>$SemTaken2c</td><td>$Nature2c</td></tr>\n";


                                                                    $countCC++;
                                                                    $CCodeArry[$countCC] = $ccode2c;
                                                                    $CUnitArry[$countCC] = $CUnit2c;
                                                                    $CTitleArry[$countCC] = $CTitle2c;
                                                                    $SemTakenArry[$countCC] = $SemTaken2c;
                                                                    $NatureArry[$countCC] = $Nature2c;
                                                                }
                                                            }
                                                        }


                                                        ?>
                                                </tbody>
                                            </table>
                                            <br>
                                            <?php
                                                echo "<center> Total Credit Units : $sum2nd</center>";
                                                ?>

                                            <?php
                                                if ($_SESSION['InstType'] == "University") {


                                                    if ($level == "600") {
                                                        if ($sum2nd > $MaxCredit) {
                                                            echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                            $stopit = "Yes";
                                                        }
                                                    } else {
                                                        if ($level == "100") {
                                                            if ($sum2nd < $minCreditNew) {
                                                                echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCreditNew Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                            if ($sum2nd > $MaxCreditNew) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCreditNew Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        } else {
                                                            if ($level == $siwes_level) {
                                                                if ($sum2nd < $siwes_unit) {
                                                                    echo "<strong style='color:#F00'><center>Shortage of Unit, $siwes_unit Unit for student on SIWES</center></strong>";
                                                                    $stopit = "Yes";
                                                                }
                                                                if ($sum2nd > $siwes_unit) {
                                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit, $siwes_unit Unit for student on SIWES</center></strong>";
                                                                    $stopit = "Yes";
                                                                }
                                                            } else {
                                                                if ($sum2nd < $minCredit) {
                                                                    echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                                    $stopit = "Yes";
                                                                }
                                                                if ($sum2nd > $MaxCredit) {
                                                                    echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                    $stopit = "Yes";
                                                                }
                                                            }
                                                        }
                                                    }
                                                } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                    if ($modeofentry == "ND") {
                                                        if ($level == "100" || $level == "200") {

                                                            if ($sum2nd < $minCredit) {
                                                                echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                            if ($sum2nd > $MaxCredit) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        } else if ($level > "200") {
                                                            if ($sum2nd > $MaxCredit) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        }
                                                    } else {
                                                        if ($level == "300" || $level == "400") {

                                                            if ($sum2nd < $minCredit) {
                                                                echo "<strong style='color:#F00'><center>Shortage of Unit, Minimum of $minCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }

                                                            if ($sum2nd > $MaxCredit) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        } else if ($level > "400") {
                                                            if ($sum2nd > $MaxCredit) {
                                                                echo "<strong style='color:#F00'><center>Excess Credit Unit, Maximum of $MaxCredit Unit per semester</center></strong>";
                                                                $stopit = "Yes";
                                                            }
                                                        }
                                                    }
                                                }

                                                $_SESSION["CCodeArry"] = $CCodeArry;
                                                $_SESSION["CUnitArry"] = $CUnitArry;
                                                $_SESSION["CTitleArry"] = $CTitleArry;
                                                $_SESSION["SemTakenArry"] = $SemTakenArry;
                                                $_SESSION["NatureArry"] = $NatureArry;
                                                $_SESSION["countCC"] = $countCC;
                                                //$conn->close();
                                                ?>
                                            <br /><br />
                                            <?php if ($stopit !== "Yes") { ?>
                                            <p style="text-align: right"><button type="submit" name="submit2"
                                                    class="btn btn-primary">Submit</button></p>
                                            <?php } ?>
                                        </form>
                                        <?php
                                            $conn->close();
                                            $conn2->close();
                                            $conn_stu->close();
                                            ?>
                                        <?php } ?>

                                        <?php if (isset($_POST["submitreg"]) || isset($_POST["submitBackCReg"])) { ?>
                                        <?php
                                            $dept = $_SESSION['studeptsess'];
                                            $level = $_SESSION["stulevelsess"];
                                            $regid = $_SESSION['regid'];

                                            include 'includes/get_stu_level_staff.php';

                                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                            if ($conn2->connect_error) {
                                                die("Connection failed: " . $conn2->connect_error);
                                            }

                                            $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                            $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                            if ($conn_stu->connect_error) {
                                                die("Connection failed: " . $conn_stu->connect_error);
                                            }
                                            ?>
                                        <h4 style="text-align: center;">Select Course to Register </h4>
                                        <form class="form-horizontal form-bordered" method="post" action="">
                                            <table class="table mb-none tablechk1">
                                                <thead>
                                                    <tr>
                                                        <th><input type="checkbox" id="selectAll1"></th>
                                                        <th>Course Code</th>
                                                        <th>Course Title</th>
                                                        <th>Unit</th>
                                                        <th>Semester</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <?php


                                                    ?>
                                                <tbody>


                                                    <?php



                                                        $sql = "SELECT * FROM diff_outs_courses WHERE Regn1 = '$regid' ORDER BY SemTaken, CCode";
                                                        $result = $conn_stu->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {

                                                                $id = $row["id"];
                                                                $ccode = $row["CCode"];
                                                                $CTitle = $row["CTitle"];
                                                                $CUnit = $row["CUnit"];
                                                                $SemTaken = strtoupper(trim($row["SemTaken"]));
                                                                $Nature = "Core";

                                                                echo "<tr>
                                                                <td><input type='checkbox' name='chosen2c[" . $id . "]' value='" . $id . "'/></td>
                                                                <td>
                                                                <label id='ccodec2' name='ccodec2[" . $id . "]'>$ccode</label>
                                                                <input type='hidden' id='ccodec2' name='ccodec2[" . $id . "]' value='" . $ccode . "'/>
                                                                </td>
                                                                <td>
                                                                <label id='CTitlec2' name='CTitlec2[" . $id . "]'>$CTitle</label>
                                                                <input type='hidden' id='CTitlec2' name='CTitlec2[" . $id . "]' value='" . $CTitle . "'/>
                                                                </td>
                                                                <td>
                                                                <label id='CUnitc2' name='CUnitc2[" . $id . "]'>$CUnit</label>
                                                                <input type='hidden' id='CUnitc2' name='CUnitc2[" . $id . "]' value='" . $CUnit . "'/>
                                                                </td>
                                                                <td>
                                                                <label id='SemTakenc2' name='SemTakenc2[" . $id . "]'>$SemTaken</label>
                                                                <input type='hidden' id='SemTakenc2' name='SemTakenc2[" . $id . "]' value='" . $SemTaken . "'/>
                                                                </td>
                                                            <td>
                                                                <label id='Naturec2' name='Naturec2[" . $id . "]'>$Nature</label>
                                                                <input type='hidden' id='Naturec2' name='Naturec2[" . $id . "]' value='" . $Nature . "'/>
                                                                </td>
                                                                
                                                                </tr>\n";
                                                            }
                                                        }

                                                        if ($level !== 600) {

                                                            $sql = "SELECT * FROM deptcourses WHERE dept = '$dept' AND level = '$level' ORDER BY SemTaken, CCode";
                                                            $result = $conn->query($sql);

                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {

                                                                    $id = $row["id"];
                                                                    $ccode = $row["CCode"];
                                                                    $CTitle = $row["CTitle"];
                                                                    $CUnit = $row["CUnit"];
                                                                    $SemTaken = strtoupper(trim($row["SemTaken"]));
                                                                    $Nature = $row["Nature"];

                                                                    echo "<tr>
                                                                    <td><input type='checkbox' name='chosen2c[" . $id . "]' value='" . $id . "'/></td>
                                                                    <td>
                                                                    <label id='ccodec2' name='ccodec2[" . $id . "]'>$ccode</label>
                                                                    <input type='hidden' id='ccodec2' name='ccodec2[" . $id . "]' value='" . $ccode . "'/>
                                                                    </td>
                                                                    <td>
                                                                    <label id='CTitlec2' name='CTitlec2[" . $id . "]'>$CTitle</label>
                                                                    <input type='hidden' id='CTitlec2' name='CTitlec2[" . $id . "]' value='" . $CTitle . "'/>
                                                                    </td>
                                                                    <td>
                                                                    <label id='CUnitc2' name='CUnitc2[" . $id . "]'>$CUnit</label>
                                                                    <input type='hidden' id='CUnitc2' name='CUnitc2[" . $id . "]' value='" . $CUnit . "'/>
                                                                    </td>
                                                                    <td>
                                                                    <label id='SemTakenc2' name='SemTakenc2[" . $id . "]'>$SemTaken</label>
                                                                    <input type='hidden' id='SemTakenc2' name='SemTakenc2[" . $id . "]' value='" . $SemTaken . "'/>
                                                                    </td>
                                                                <td>
                                                                    <label id='Naturec2' name='Naturec2[" . $id . "]'>$Nature</label>
                                                                    <input type='hidden' id='Naturec2' name='Naturec2[" . $id . "]' value='" . $Nature . "'/>
                                                                    </td>
                                                                    
                                                                    </tr>\n";
                                                                }
                                                            }
                                                        }

                                                        $sql = "SELECT * FROM add_courses_cat WHERE Regn1 = '$regid' ORDER BY SemTaken, CCode";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {

                                                                $id = $row["sn"];
                                                                $ccode = $row["CCode"];
                                                                $CTitle = $row["CTitle"];
                                                                $CUnit = $row["CUnit"];
                                                                $SemTaken = strtoupper(trim($row["SemTaken"]));
                                                                $Nature = $row["Nature"];

                                                                echo "<tr>
                                                                <td><input type='checkbox' name='chosen2c[" . $id . "]' value='" . $id . "'/></td>
                                                                <td>
                                                                <label id='ccodec2' name='ccodec2[" . $id . "]'>$ccode</label>
                                                                <input type='hidden' id='ccodec2' name='ccodec2[" . $id . "]' value='" . $ccode . "'/>
                                                                </td>
                                                                <td>
                                                                <label id='CTitlec2' name='CTitlec2[" . $id . "]'>$CTitle</label>
                                                                <input type='hidden' id='CTitlec2' name='CTitlec2[" . $id . "]' value='" . $CTitle . "'/>
                                                                </td>
                                                                <td>
                                                                <label id='CUnitc2' name='CUnitc2[" . $id . "]'>$CUnit</label>
                                                                <input type='hidden' id='CUnitc2' name='CUnitc2[" . $id . "]' value='" . $CUnit . "'/>
                                                                </td>
                                                                <td>
                                                                <label id='SemTakenc2' name='SemTakenc2[" . $id . "]'>$SemTaken</label>
                                                                <input type='hidden' id='SemTakenc2' name='SemTakenc2[" . $id . "]' value='" . $SemTaken . "'/>
                                                                </td>
                                                            <td>
                                                                <label id='Naturec2' name='Naturec2[" . $id . "]'>$Nature</label>
                                                                <input type='hidden' id='Naturec2' name='Naturec2[" . $id . "]' value='" . $Nature . "'/>
                                                                </td>
                                                                
                                                                </tr>\n";
                                                            }
                                                        }
                                                        ?>
                                                </tbody>

                                            </table>
                                            <div class="row" style="text-align:right; padding-right:2em">

                                                <button type="submit" name="submitprev"
                                                    class="btn btn-primary">Preview</button>
                                            </div>
                                        </form>
                                        <form class="form-horizontal form-bordered" method="post"
                                            action="addcoursesreg_staff.php">
                                            <div class="row" style="text-align:left">
                                                <input type='hidden' name='matno' value='<?php echo $regid ?>' />
                                                <input type='hidden' name='studept' value='<?php echo $dept ?>' />
                                                <input type='hidden' name='stulevel' value='<?php echo $level ?>' />
                                                <button type="submit" name="addfromdept" class="btn btn-default"
                                                    style="color:blue;">Add
                                                    Courses from other
                                                    Dept</button>

                                            </div>
                                        </form>
                                        <?php
                                            $conn->close();
                                            $conn2->close();
                                            $conn_stu->close();
                                            ?>
                                        <?php } ?>
                                    </div>
                                </div>

                                <div class="col-lg-1">

                                </div>





                            </div>

                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>




    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
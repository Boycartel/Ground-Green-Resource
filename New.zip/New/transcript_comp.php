<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['transcript_email'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


    <style type="text/css">
        table {
            page-break-inside: avoid;
        }

        p {
            page-break-before: always;
        }

        @page {
            size: A4 landscape;
            font-size: small;
        }

        @page :left {
            margin-left: 1cm;
        }

        @page :right {
            margin-left: 1cm;
        }
    </style>

    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript">
        $("#btnPrint").live("click", function() {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var divContents = $("#dvContainer").html();
            var printWindow = window.open('', '', disp_setting);
            printWindow.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
            );
            printWindow.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>


    <script type="text/javascript">
        $("#btnPrint2").live("click", function() {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var divContents = $("#dvContainer2").html();
            var printWindow = window.open('', '', disp_setting);
            printWindow.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
            );
            printWindow.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>

    <script type="text/javascript">
        $("#btnPrint3").live("click", function() {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var divContents = $("#dvContainer3").html();
            var printWindow = window.open('', '', disp_setting);
            printWindow.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
            );
            printWindow.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>


    <script type="text/javascript">
        $("#btnPrint4").live("click", function() {
            var disp_setting = "toolbar=yes,location=no,directories=yes,menubar=yes,";
            disp_setting += "scrollbars=yes,width=800, height=400, left=100, top=25";
            var divContents = $("#dvContainer4").html();
            var printWindow = window.open('', '', disp_setting);
            printWindow.document.write(
                '<html><head><title>.::PDF Title </title> <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.">'
            );
            printWindow.document.write(
                '</head><body onLoad="self.print()" style="width: 100%; height="auto" font-size:16px; font-family:arial;">'
            );
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
    </script>
    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <?php
    $userdept = $_SESSION['deptcode'];
    $userid = $_SESSION["staffid"];
    $usernames = $_SESSION['names'];
    $useremail = $_SESSION['email'];
    $deptname = $_SESSION['deptname'];
    //$cat = $_SESSION['cat'];
    $corntsession = $_SESSION['corntsession'];
    $cursemester = $_SESSION['cursemester'];
    ?>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Students' Academic Transcript</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Results
                            </li>

                            <li class="active">
                                <strong>Students' Academic Transcript</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Students' Academic Transcript
                        </div>
                        <div class="panel-body">
                            <div>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="form-group">
                                        <label class="col-lg-4 control-label">Matric Number: </label>
                                        <div class="col-lg-5">
                                            <input type="text" class="form-control" style="color:#000000" name="regid" value="2018/1/73251PM">
                                        </div>
                                        <div class="col-lg-3">
                                            <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                                        </div>
                                    </div>
                                </form>
                            </div>
                            <br>
                            <hr class="separator" />
                            <br>
                            <div class="row">
                                <?php if (isset($_POST["submit"])) { ?>
                                    <section class="panel">



                                        <?php
                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        $yeargrad = "";
                                        $getDE = "NO";
                                        $siwesstatus = $_SESSION["siwesstatus"];
                                        $deptoption = $_SESSION['deptoption'];
                                        $matno = str_replace("'", "", $_POST['regid']);
                                        $matno = filter_var(strtoupper($matno), FILTER_SANITIZE_STRING);


                                        $Is500L = "NO";
                                        $sql = "SELECT * FROM std_data_view WHERE matric_no = '$matno'";
                                        $result = $conn2->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                /* $fulname = $row['first_name'] . " " . $row['other_name'] . " " . $row['surname'];
                                                $prog = "XXX";
                                                $permaddres = $row['p_address'];
                                                if (isset($_POST["view_in_sess"])) {
                                                    $yeargrad = 0;
                                                } else {
                                                    $yeargrad = $_SESSION['getyeargrad'];
                                                }

                                                if ($_SESSION['InstType'] == "Polytechnic") {
                                                    $modeofentry = $row['modeofentry'];
                                                }

                                                $deptname = $_SESSION['deptname'];
                                                $dept = strtolower($row['dept_code']);
                                                

                                                $school = $_SESSION['schname'];
                                                $stateorigin = $row['state'];
                                                $stu_curriculum = strtolower($row['curriculum']);
                                                $Stu_Dept_Opt = $row["Dept_Option"];
                                                $YAddmitted = substr($entry_session, 0, 4);
                                                if ($entry_level == 200) {
                                                    $getDE = "DE200";
                                                } elseif ($entry_level == 300) {
                                                    $getDE = "DE300";
                                                } elseif ($entry_level == 100) {
                                                }

                                                //$PlaceBirth = $row['PlaceBirth'];

                                                $lga = $row['lga'];
                                                $sex1 = $row['gender'];

                                                //$withddate = $row['WidDate'];
                                                $national = $row['nationality'];
                                                $dob = $row['dob'];

                                                $name_first = $row['first_name'];
                                                $name_last = $row['surname'];
                                                if (empty($row['other_name'])) {
                                                    $name_middle = "";
                                                } else {
                                                    $name_middle = $row['other_name'];
                                                }

 */


                                                $entry_session = $row['entry_session'];
                                                $entry_level = $row['entry_level'];
                                                $fulname = $row["first_name"] . " " . $row["other_name"] . " " . $row["surname"];
                                                $modeofentry = $row["modeofentry"];
                                                $prog = "XXXX";

                                                $permaddres = $row['p_address'];


                                                $deptname = $_SESSION['deptname'];
                                                $dept = strtolower($row['dept_code']);


                                                $school = $row['school'];
                                                $stateorigin = $row['state'];
                                                $stu_curriculum = strtolower($row['curriculum']);
                                                $Stu_Dept_Opt = $row["Dept_Option"];
                                                $YAddmitted = substr($entry_session, 0, 4);
                                                if ($entry_level == 200) {
                                                    $getDE = "DE200";
                                                } elseif ($entry_level == 300) {
                                                    $getDE = "DE300";
                                                } elseif ($entry_level == 100) {
                                                }

                                                $PlaceBirth = "XXXX";

                                                $lga = $row['lga'];
                                                $sex1 = $row['gender'];

                                                $national = $row['nationality'];
                                                $dob = $row['dob'];


                                                $name_first = $row['first_name'];
                                                $name_last = $row['surname'];
                                                if (empty($row['other_name'])) {
                                                    $name_middle = "";
                                                } else {
                                                    $name_middle = $row['other_name'];
                                                }
                                            }
                                        }

                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }
                                        $sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND graduated = 'YES'";
                                        $result = $conn_stu->query($sql);
                                        $totunit1 = $totgp1 = $cgpa1 = $gtotgp1 = $gtotunit1 = $stcp1 = 0;
                                        $conn->close();
                                        $conn2->close();
                                        $conn_stu->close();


                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $yeargrad = $row["yearGrad"];
                                            }
                                        } else {
                                        ?>
                                            <script type="text/javascript">
                                                window.location.href = "transcript_comp.php"
                                            </script>
                                        <?php
                                        }


                                        $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                        if ($conn->connect_error) {
                                            die("Connection failed: " . $conn->connect_error);
                                        }

                                        $conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
                                        if ($conn2->connect_error) {
                                            die("Connection failed: " . $conn2->connect_error);
                                        }

                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                        $result = $conn->query($sql);
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $isdeptoption = $row["deptoption"];
                                                $iscurriculum = $row["curriculum"];
                                            }
                                        }
                                        //$conn->close();
                                        unset($unitarry);
                                        unset($gparry);
                                        unset($gpaarry);
                                        unset($cgpaarry);
                                        unset($totcpass);
                                        unset($tct);
                                        unset($tcp);
                                        unset($getfivelevel);
                                        unset($getfourlevel);
                                        unset($sessionarry);
                                        unset($LevelArray);

                                        unset($totunit);
                                        unset($totgp);
                                        unset($countSesRes);

                                        unset($ccode_tot);
                                        unset($ctitle_tot);
                                        unset($cunit_tot);
                                        unset($grade_tot);
                                        unset($gpoint_tot);

                                        unset($LevelCGPA);
                                        unset($absent1ST);
                                        unset($absent2ND);

                                        $Lev_totunit = 0;
                                        $Lev_totgp = 0;
                                        $maxSession = "";
                                        $NotRelevant = false;
                                        $SessionCount = 0;

                                        $yearadmt = substr($entry_session, 0, 4);
                                        if ($entry_level == 200) {
                                            $yearadmt = $yearadmt - 1;
                                        } elseif ($entry_level == 300) {
                                            $yearadmt = $yearadmt - 2;
                                        }

                                        $resultsession = $_SESSION['resultsession'];
                                        $resultsemester = $_SESSION['resultsemester'];
                                        $FinalYear = substr($resultsession, 0, 4);
                                        $StartYear = substr($entry_session, 0, 4);
                                        if (isset($_POST["view_in_sess"])) {
                                            unset($getSessionUnGrad);
                                            $countses = 0;

                                            for ($x = $StartYear; $x <= $FinalYear; $x++) {
                                                $getstuSession2 = $x . "/" . ($x + 1);
                                                $StuCurSess = str_ireplace("/", "_", $getstuSession2);

                                                if ($getstuSession2 < "2014/2015") {
                                                    $deptcorreg = "correg";
                                                } else {
                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                }

                                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                if ($conn_stu->connect_error) {
                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                }

                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1  = '$matno' AND SessionRegis = '$getstuSession2'";
                                                $result = $conn_stu->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $countses++;
                                                        $getSessionUnGrad[$countses] = $row['SessionRegis'];
                                                    }
                                                }
                                                $getSessionUnGrad2 = array_unique($getSessionUnGrad);
                                                $getMaxSess = max($getSessionUnGrad2);
                                            }
                                        }
                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        for ($x = 0; $x <= 11; $x++) {
                                            //$countOneLev=$countTwoLev=$countThreLev=$countFivLev=$countFourLev=0;
                                            $maxLevel = 0;
                                            $nextyr = $yearadmt + 1;
                                            $sessionarry[$x] = $yearadmt . "/" . $nextyr;
                                            $yearadmt++;


                                            $gtotgp = 0;
                                            $stcp = 0;
                                            $LevelCGPA2 = 0;
                                            $countSesRes[$x] = 0;
                                            $absent1ST[$x] = 0;
                                            $absent2ND[$x] = 0;
                                            $countOneLev = $countTwoLev = $countThreLev = $countFivLev = $countFourLev = $getlevel = 0;


                                            $StuCurSess = str_ireplace("/", "_", $sessionarry[$x]);

                                            if (isset($_POST["view_in_sess"])) {

                                                if ($sessionarry[$x] < "2014/2015") {
                                                    $deptcorreg = "correg";
                                                } else {
                                                    $deptcorreg = "correg_" . $StuCurSess;
                                                }
                                                if ($sessionarry[$x] == $getMaxSess) {
                                                    if ($getMaxSess == $resultsession && $resultsemester == "1ST") {
                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' AND SemTaken = '1ST' ORDER BY SemTaken, CCode";
                                                    } else {
                                                        $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
                                                    }
                                                } else {
                                                    $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
                                                }
                                            } else {
                                                $deptcorreg = "correg_" . $StuCurSess;
                                                $sql = "SELECT * FROM " . $deptcorreg . " WHERE Regn1 = '$matno' AND SessionRegis = '$sessionarry[$x]' ORDER BY SemTaken, CCode";
                                            }

                                            $result = $conn_stu->query($sql);
                                            $totunit = $totgp = $cgpa = $gtotgp = $gtotunit = 0;
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {

                                                    $ccode = $row['CCode'];
                                                    $ctitle = $row['CTitle'];
                                                    $cunit = $row['CUnit'];


                                                    if ($isdeptoption == "YES") {
                                                        if ($iscurriculum == "YES") {
                                                            if ($stu_curriculum == "old") {
                                                                $stu_curriculum2 = "";
                                                            } else {
                                                                $stu_curriculum2 = "_" . $stu_curriculum;
                                                            }
                                                            $sql3 = "SELECT * FROM gencourses" . $stu_curriculum2 . " WHERE C_codding  = '$ccode' AND " . $Stu_Dept_Opt . " = 'YES'";
                                                        } else {
                                                            $sql3 = "SELECT * FROM gencourses WHERE C_codding  = '$ccode' AND " . $Stu_Dept_Opt . " = 'YES'";
                                                        }

                                                        $result3 = $conn_stu->query($sql3);
                                                        $Add3 = 0;
                                                        if ($result3->num_rows > 0) {
                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                $Add3++;
                                                            }
                                                        }
                                                    } else {

                                                        if ($iscurriculum == "YES") {
                                                            if ($stu_curriculum == "old") {
                                                                $stu_curriculum2 = "";
                                                            } else {
                                                                $stu_curriculum2 = "_" . $stu_curriculum;
                                                            }
                                                            $sql3 = "SELECT * FROM gencourses" . $stu_curriculum2 . " WHERE C_codding  = '$ccode' AND Relevant = 'YES'";
                                                        } else {
                                                            $sql3 = "SELECT * FROM gencourses WHERE C_codding  = '$ccode' AND Relevant = 'YES'";
                                                        }

                                                        $result3 = $conn_stu->query($sql3);
                                                        $Add3 = 0;
                                                        if ($result3->num_rows > 0) {
                                                            while ($row3 = $result3->fetch_assoc()) {
                                                                $Add3++;
                                                            }
                                                        }
                                                    }


                                                    if ($row['SemTaken'] == "1ST") {
                                                        $absent1ST[$x]++;
                                                    } elseif ($row['SemTaken'] == "2ND") {
                                                        $absent2ND[$x]++;
                                                    }
                                                    if ((int)substr($ccode, 3, 1) == 5) {
                                                        $countFivLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 4) {
                                                        $countFourLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 3) {
                                                        $countThreLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 2) {
                                                        $countTwoLev++;
                                                    } elseif ((int)substr($ccode, 3, 1) == 1) {
                                                        $countOneLev++;
                                                    }

                                                    $gpoint = $row['point'];
                                                    $grade = $row['grade'];
                                                    $stcp = $stcp + $cunit;

                                                    if ($grade == "F") {

                                                        if ($Add3 == 0) {
                                                            $NotRelevant = true;
                                                            $ccode = "*" . $ccode;
                                                        }
                                                    }


                                                    $totunit = $totunit + $cunit;
                                                    $totgp = $totgp + $gpoint;

                                                    $ccode_tot[$x][$countSesRes[$x]] = $ccode;
                                                    $ctitle_tot[$x][$countSesRes[$x]] = $ctitle;
                                                    $cunit_tot[$x][$countSesRes[$x]] = $cunit;
                                                    $grade_tot[$x][$countSesRes[$x]] = $grade;
                                                    $gpoint_tot[$x][$countSesRes[$x]] = $gpoint;

                                                    $countSesRes[$x]++;
                                                }
                                            }
                                            $SessionCount = $x;
                                            $maxLevel = max($countOneLev, $countTwoLev, $countThreLev, $countFourLev, $countFivLev);
                                            if ($countOneLev == $maxLevel) {
                                                $LevelArray[$x] = 100;
                                            } elseif ($countTwoLev == $maxLevel) {
                                                $LevelArray[$x] = 200;
                                            } elseif ($countThreLev == $maxLevel) {
                                                $LevelArray[$x] = 300;
                                            } elseif ($countFourLev == $maxLevel) {
                                                $LevelArray[$x] = 400;
                                            } elseif ($countFivLev == $maxLevel) {
                                                $LevelArray[$x] = 500;
                                                //$Is500L="YES";
                                            }

                                            $unitarry[$x] = $totunit;
                                            $gparry[$x] = $totgp;
                                            $tgp[$x] = $totgp;
                                            $tct[$x] = $totunit;
                                            $tcp[$x] = $stcp;
                                            $totcpass[$x] = $stcp;

                                            $Lev_totunit = $Lev_totunit + $totunit;
                                            $Lev_totgp = $Lev_totgp + $totgp;

                                            if ($unitarry[$x] == 0) {
                                                $cgpa = 0;
                                                $gpaarry[$x] = 0;
                                                //$cgpaarry[$x]=0;
                                            } else {
                                                $cgpa = $gparry[$x] / $unitarry[$x];
                                                if ($totunit !== 0) {
                                                    $gpaarry[$x] = $totgp / $totunit;
                                                }
                                            }

                                            if ($Lev_totunit == 0) {
                                                $LevelCGPA[$x] = 0;
                                            } else {
                                                $LevelCGPA[$x] = $Lev_totgp / $Lev_totunit;
                                            }
                                            if (!isset($_POST["view_in_sess"])) {
                                                if ($nextyr >= $yeargrad) {
                                                    $maxSession = $sessionarry[$x];
                                                    $getMaxSess = $sessionarry[$x];
                                                    break;
                                                }
                                            } else {
                                                if ($sessionarry[$x] == $getMaxSess) {
                                                    break;
                                                }
                                            }
                                        }

                                        $classdegree = "";
                                        $getdept = $dept;

                                        // To Change

                                        //$getyeargrad = "2021";
                                        //$getsemester = "2ND";
                                        $Countfirst = $Count2Upper = $Count2Lower = $Count3Class = $CountPass = $CountFail = 0;
                                        $dept_db = $_SESSION['deptdb'] . strtolower($getdept);
                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                        if ($conn_stu->connect_error) {
                                            die("Connection failed: " . $conn_stu->connect_error);
                                        }

                                        //$sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND yearGrad = '$getyeargrad' AND semester = '$getsemester'";
                                        $sql = "SELECT * FROM scrutiny_senate WHERE Regn = '$matno' AND graduated = 'YES'";
                                        $result = $conn_stu->query($sql);
                                        $totunit1 = $totgp1 = $cgpa1 = $gtotgp1 = $gtotunit1 = $stcp1 = 0;
                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                /* if ($getsemester == "1ST") {
                                                    $ccgpa = $row['CGPA_grad_1st'];
                                                } else {
                                                    $ccgpa = $row['CGPA'];
                                                } */
                                                $ccgpa = $row['CGPA'];
                                                $totunit1 = $row['TCT'];
                                                $stcp1 = $row['TCP'];
                                                $totgp1 = $row['CGP'];
                                            }
                                        }
                                        $conn->close();
                                        $conn2->close();
                                        $conn_stu->close();
                                        include 'modulesInSess/classofdegree_inc.php';

                                        /* if ($ccgpa >= 4.495) {
                                            $classdegree = "First Class";
                                        } elseif ($ccgpa >= 3.495) {
                                            $classdegree = "Second Class Upper";
                                        } elseif ($ccgpa >= 2.395) {
                                            $classdegree = "Second Class Lower";
                                        } elseif ($ccgpa >= 1.495) {
                                            $classdegree = "Third Class";
                                        } else {
                                            $classdegree = "Pass";
                                        }
 */
                                        ?>

                                        <header class="panel-heading tab-bg-info">
                                            <ul class="nav nav-tabs">
                                                <li class="active">
                                                    <a data-toggle="tab" href="#page1">
                                                        Page 1
                                                    </a>
                                                </li>
                                                <?php if ($SessionCount >= 3) { ?>
                                                    <li>
                                                        <a data-toggle="tab" href="#page2">
                                                            Page 2
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                                <?php if ($SessionCount >= 6) { ?>
                                                    <li class="">
                                                        <a data-toggle="tab" href="#page3">
                                                            Page 3
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                                <?php if ($SessionCount >= 9) { ?>
                                                    <li class="">
                                                        <a data-toggle="tab" href="#page4">
                                                            Page 4
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                            </ul>
                                        </header>

                                        <div class="panel-body">
                                            <div class="tab-content">

                                                <div id="page1" class="tab-pane active">
                                                    <div id="dvContainer" style="width: auto; float: none">

                                                        <style>
                                                            table,
                                                            th,
                                                            td {
                                                                /*border: 1px solid black;*/
                                                                border-collapse: collapse;
                                                                font-size: 11px;
                                                            }
                                                        </style>
                                                        <table style="width: 99%">
                                                            <tbody>
                                                                <tr>
                                                                    <td>

                                                                        <table style="width: 100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style="width: 10%">
                                                                                        <img src="img/logo.ico" height="70" alt="logo" />
                                                                                    </td>
                                                                                    <th style="width: 80%">

                                                                                        <h2 style="text-align: center; font-size:x-large; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                            <?php echo $_SESSION['instname'] ?>
                                                                                        </h2>
                                                                                        <h4 style="text-align: center; font-size:large; color:black">
                                                                                            <?php echo $_SESSION['InstAdrress'] ?>
                                                                                        </h4>
                                                                                        <h3 style="text-align: center; font-size:large; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                            STUDENTS' ACADEMIC TRANSCRIPT
                                                                                        </h3>


                                                                                    </th>
                                                                                    <td>
                                                                                        <figure class="profile-picture">
                                                                                            <?php
                                                                                            /* $sql = "SELECT imageType, imageData FROM " . $dept . " WHERE stdid='$stdid'";
                                                                        $sth = $conn10->query($sql);
                                                                        $result2 = mysqli_fetch_array($sth);

                                                                        echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['imageData']) . '"  width="70" height="70"/>'; */
                                                                                            ?>
                                                                                        </figure>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <table style="font-size:12px; width: 100%; color: #0a0a0a; padding-bottom: 1em; padding-top: 1em">
                                                                            <tbody style="color: #0a0a0a">
                                                                                <tr>
                                                                                    <th style="text-align: left;width: 10%">
                                                                                        SURNAME :</th>
                                                                                    <td style="width: 30%; text-align: left; padding-left: 1em">
                                                                                        <?php echo $name_first ?></td>
                                                                                    <th style="padding-left: 1em;width: 12%; text-align: left">
                                                                                        OTHER NAME(S) :</th>
                                                                                    <td style="padding-left: 1em;width: 18%">
                                                                                        <?php echo $name_middle . " " . $name_last ?>
                                                                                    </td>
                                                                                    <th style="padding-left: 1em;width: 18%; text-align: left">
                                                                                        MATRICULATION NUMBER :</th>
                                                                                    <td style="padding-left: 1em">
                                                                                        <?php echo $matno ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="text-align: left">STATE OF
                                                                                        ORIGIN :</th>
                                                                                    <td style="padding-left: 1em; text-align: left">
                                                                                        <?php echo $stateorigin ?></td>
                                                                                    <th style="padding-left: 1em; text-align: left">
                                                                                        LOCAL GOVT.
                                                                                        AREA :</th>
                                                                                    <td style="padding-left: 1em">
                                                                                        <?php echo $lga ?></td>
                                                                                    <th style="padding-left: 1em; text-align: left">
                                                                                        SEX :</th>
                                                                                    <td style="padding-left: 1em">
                                                                                        <?php echo $sex1 ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="vertical-align: top;text-align: left">
                                                                                        ADDRESS :
                                                                                    </th>
                                                                                    <td style="padding-left: 1em; text-align: left">
                                                                                        <?php echo $permaddres ?></td>
                                                                                    <th style="padding-left: 1em; text-align: left">
                                                                                        DATE OF
                                                                                        BIRTH :</th>
                                                                                    <td style="padding-left: 1em">
                                                                                        <?php echo $dob ?></td>
                                                                                    <th style="padding-left: 1em; text-align: left">
                                                                                        YEAR OF
                                                                                        MATRICULATION:</th>
                                                                                    <td style="padding-left: 1em">
                                                                                        <?php echo $YAddmitted ?></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <th style="vertical-align: top;text-align: left">
                                                                                        PROGRAMME:
                                                                                    </th>
                                                                                    <td style="padding-left: 1em; text-align: left">
                                                                                        <?php echo $prog ?></td>
                                                                                    <th style="padding-left: 1em; text-align: left">
                                                                                        PLACE OF
                                                                                        BIRTH :</th>
                                                                                    <td style="padding-left: 1em">
                                                                                        <?php //echo $PlaceBirth 
                                                                                        ?></td>
                                                                                    <th style="padding-left: 1em; text-align: left">
                                                                                    </th>
                                                                                    <td style="padding-left: 1em"></td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>

                                                                        <table style="color: #0a0a0a; width: 100%; font-size: 9px">
                                                                            <tbody>

                                                                                <tr>
                                                                                    <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                        <?php echo $sessionarry[0] . " " . $LevelArray[0] . "  Level" ?>
                                                                                    </th>
                                                                                    <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                        <?php if ($SessionCount >= 1) {
                                                                                            echo $sessionarry[1] . " " . $LevelArray[1] . "  Level";
                                                                                        } ?></th>
                                                                                    <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                        <?php if ($SessionCount >= 2) {
                                                                                            echo $sessionarry[2] . " " . $LevelArray[2] . "  Level";
                                                                                        } ?></th>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td style="border-style:solid; border-width:thin; width: 33%" valign="top">

                                                                                        <?php

                                                                                        echo "<table style='font-size:13px; width: 100%'>";
                                                                                        echo "<thead style='text-align:center;'>";
                                                                                        echo "<tr>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                        echo "</tr>";
                                                                                        echo "</thead>";
                                                                                        echo "<tbody>";

                                                                                        $arrayNumb = 0;
                                                                                        if ($absent1ST[0] != 0 && $absent2ND[0] != 0) {
                                                                                            include 'modulesInSess/calSemResult_Grad.php';
                                                                                        } elseif ($absent1ST[0] == 0 && $absent2ND[0] != 0) {
                                                                                            $indSession = $sessionarry[0];
                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                            include 'modulesInSess/calSemResult_Grad.php';
                                                                                        } elseif ($absent1ST[0] != 0 && $absent2ND[0] == 0) {
                                                                                            include 'modulesInSess/calSemResult_Grad.php';
                                                                                            if ($sessionarry[0] != $getMaxSess) {
                                                                                                $indSession = $sessionarry[0];
                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                            }
                                                                                        } elseif ($absent1ST[0] == 0 && $absent2ND[0] == 0) {
                                                                                            if ($getDE == "DE200" || $getDE == "DE300") {
                                                                                                echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                            } else {

                                                                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                if ($conn->connect_error) {
                                                                                                    die("Connection failed: " . $conn->connect_error);
                                                                                                }
                                                                                                $Issess0 = false;
                                                                                                $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[0]'";
                                                                                                $result4 = $conn->query($sql4);
                                                                                                if ($result4->num_rows > 0) {
                                                                                                    $response_full = "Cancel Session";
                                                                                                    $Issess0 = true;
                                                                                                }
                                                                                                $conn->close();
                                                                                                if ($Issess0 == false) {
                                                                                                    $indSession = $sessionarry[0];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                }
                                                                                            }
                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                        }



                                                                                        if ($tct[0] != 0) {
                                                                                            echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[0]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[0]</th></tr>";
                                                                                        }

                                                                                        echo "</tbody>";
                                                                                        echo "</table>";


                                                                                        ?>

                                                                                    </td>
                                                                                    <td style="border-style:solid; border-width:thin; width: 33%" valign="top">
                                                                                        <?php
                                                                                        //$session1 = $sessionarry[1];
                                                                                        //include 'includes/semresults.php';
                                                                                        echo "<table style='font-size:13px; width: 100%'>";
                                                                                        echo "<thead style='text-align:center;'>";
                                                                                        echo "<tr>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                        echo "</tr>";
                                                                                        echo "</thead>";
                                                                                        echo "<tbody>";

                                                                                        $arrayNumb = 1;
                                                                                        if ($SessionCount >= 1) {
                                                                                            if ($absent1ST[1] != 0 && $absent2ND[1] != 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[1] == 0 && $absent2ND[1] != 0) {
                                                                                                $indSession = $sessionarry[1];
                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";

                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[1] != 0 && $absent2ND[1] == 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                                if ($sessionarry[1] != $getMaxSess) {
                                                                                                    $indSession = $sessionarry[1];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                }
                                                                                            } elseif ($absent1ST[1] == 0 && $absent2ND[1] == 0) {
                                                                                                if ($getDE == "DE300") {
                                                                                                    echo '<img src="img/DE.png" alt="logo" style="width: 200px; height: 150px;" />';
                                                                                                } else {

                                                                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                    if ($conn->connect_error) {
                                                                                                        die("Connection failed: " . $conn->connect_error);
                                                                                                    }
                                                                                                    $Issess1 = false;
                                                                                                    $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[1]'";
                                                                                                    $result4 = $conn->query($sql4);
                                                                                                    if ($result4->num_rows > 0) {
                                                                                                        $response_full = "Cancel Session";
                                                                                                        $Issess1 = true;
                                                                                                    }
                                                                                                    $conn->close();
                                                                                                    if ($Issess1 == false) {
                                                                                                        $indSession = $sessionarry[1];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                    }
                                                                                                }
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                            }


                                                                                            if ($tct[1] != 0) {
                                                                                                echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[1]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[1]</th></tr>";
                                                                                            }
                                                                                        }
                                                                                        echo "</tbody>";
                                                                                        echo "</table>";

                                                                                        /*if($getDE=="DE300"){
                                                            echo "<br><br><br><h1 style='text-align: center'><strong>DE</strong></h1>";
                                                        }*/
                                                                                        ?>

                                                                                    </td>
                                                                                    <td style="border-style:solid; border-width:thin" valign="top">
                                                                                        <?php

                                                                                        echo "<table style='font-size:13px; width: 100%'>";
                                                                                        echo "<thead style='text-align:center;'>";
                                                                                        echo "<tr>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                        echo "</tr>";
                                                                                        echo "</thead>";
                                                                                        echo "<tbody>";

                                                                                        $arrayNumb = 2;
                                                                                        if ($SessionCount >= 2) {
                                                                                            if ($absent1ST[2] != 0 && $absent2ND[2] != 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[2] == 0 && $absent2ND[2] != 0) {
                                                                                                $indSession = $sessionarry[2];
                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";

                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[2] != 0 && $absent2ND[2] == 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                                if ($sessionarry[2] != $getMaxSess) {
                                                                                                    $indSession = $sessionarry[2];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                }
                                                                                            } elseif ($absent1ST[2] == 0 && $absent2ND[2] == 0) {

                                                                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                if ($conn->connect_error) {
                                                                                                    die("Connection failed: " . $conn->connect_error);
                                                                                                }
                                                                                                $Issess2 = false;
                                                                                                $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[2]'";
                                                                                                $result4 = $conn->query($sql4);
                                                                                                if ($result4->num_rows > 0) {
                                                                                                    $response_full = "Cancel Session";
                                                                                                    $Issess2 = true;
                                                                                                }
                                                                                                $conn->close();
                                                                                                if ($Issess2 == false) {
                                                                                                    $indSession = $sessionarry[2];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                }
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                            }


                                                                                            if ($tct[2] != 0) {
                                                                                                echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[2]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[2]</th></tr>";
                                                                                            }
                                                                                        }
                                                                                        echo "</tbody>";
                                                                                        echo "</table>";
                                                                                        ?>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td style="border-style:solid; border-width:thin">
                                                                                        <?php if ($tct[0] !== 0) { ?>
                                                                                            <table style="width: 100%; font-size: 10px">
                                                                                                <tbody>


                                                                                                    <tr>
                                                                                                        <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                            Cumulative Average
                                                                                                        </th>
                                                                                                        <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                            <?php echo number_format((float)$LevelCGPA[0], 2, '.', '') ?>
                                                                                                        </th>
                                                                                                    </tr>
                                                                                                </tbody>
                                                                                            </table>
                                                                                        <?php } ?>
                                                                                    </td>
                                                                                    <td style="border-style:solid; border-width:thin">
                                                                                        <?php if ($SessionCount >= 1) { ?>
                                                                                            <?php if ($tct[1] !== 0) { ?>
                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>

                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                Cumulative Average
                                                                                                            </th>
                                                                                                            <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                <?php echo number_format((float)$LevelCGPA[1], 2, '.', '') ?>
                                                                                                            </th>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            <?php } ?>
                                                                                        <?php } ?>
                                                                                    </td>
                                                                                    <td style="border-style:solid; border-width:thin">
                                                                                        <?php if ($SessionCount >= 2) { ?>
                                                                                            <?php if ($tct[2] !== 0) { ?>
                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>

                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                Cumulative Average
                                                                                                            </th>
                                                                                                            <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                <?php echo number_format((float)$LevelCGPA[2], 2, '.', '') ?>
                                                                                                            </th>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            <?php } ?>
                                                                                        <?php } ?>
                                                                                    </td>
                                                                                </tr>

                                                                            </tbody>
                                                                        </table>
                                                                        <table style="width: 100%; font-size: 10px">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style="width: 40%; text-align: left">
                                                                                        .</td>
                                                                                    <th style="width: 25%; font-size: 12px">
                                                                                    </th>
                                                                                    <td></td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td style="width: 40%; text-align: left">
                                                                                    </td>
                                                                                    <td style="width: 25%"></td>
                                                                                    <td style="text-align: left">
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td style="text-align: left"></td>
                                                                                    <td></td>
                                                                                    <th style="text-align: left; font-size:large">
                                                                                        <br><br>REGISTRAR's
                                                                                        SIGNATURE AND DATE
                                                                                    </th>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </div>
                                                    <div class="row" style="text-align: right">
                                                        <br>

                                                        <input type="button" value="print to PDF" id="btnPrint" class="btn-success" />
                                                    </div>
                                                </div>
                                                <!-- profile -->
                                                <div id="page2" class="tab-pane">
                                                    <div id="dvContainer2" style="width: auto; float: none">
                                                        <style>
                                                            table,
                                                            th,
                                                            td {
                                                                /*border: 1px solid black;*/
                                                                border-collapse: collapse;
                                                                font-size: 11px;
                                                            }
                                                        </style>
                                                        <!--<p style="text-align: center; font-size: 10px"><strong>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</strong></p>-->
                                                        <table style="width: 99%">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <table style="width: 100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style="width: 10%">
                                                                                        <img src="img/logo.ico" height="70" alt="logo" />
                                                                                    </td>
                                                                                    <th style="width: 80%">
                                                                                        <h2 style="text-align: center; font-size:x-large; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                            <?php echo $_SESSION['instname'] ?>
                                                                                        </h2>
                                                                                        <h4 style="text-align: center; font-size:large; color:black">
                                                                                            <?php echo $_SESSION['InstAdrress'] ?>
                                                                                        </h4>
                                                                                        <h3 style="text-align: center; font-size:large; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                            STUDENTS' ACADEMIC TRANSCRIPT
                                                                                        </h3>


                                                                                    </th>
                                                                                    <td>
                                                                                        <figure class="profile-picture">
                                                                                            <?php
                                                                                            /* $sql = "SELECT imageType, imageData FROM " . $dept . " WHERE stdid='$stdid'";
                                                                        $sth = $conn10->query($sql);
                                                                        $result2 = mysqli_fetch_array($sth);

                                                                        echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['imageData']) . '"  width="70" height="70"/>'; */
                                                                                            ?>
                                                                                        </figure>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <table style="font-size:9px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                                                                            <tbody style="color: #0a0a0a">
                                                                                <tr>
                                                                                    <th style="text-align: left;width: 10%">
                                                                                        SURNAME :</th>
                                                                                    <td style="width: 30%; text-align: left; padding-left: 1em">
                                                                                        <?php echo $name_first ?></td>
                                                                                    <th style="padding-left: 1em;width: 12%; text-align: left">
                                                                                        OTHER NAME(S) :</th>
                                                                                    <td style="padding-left: 1em;width: 18%">
                                                                                        <?php echo $name_middle . " " . $name_last ?>
                                                                                    </td>
                                                                                    <th style="padding-left: 1em;width: 18%; text-align: left">
                                                                                        MATRICULATION NUMBER :</th>
                                                                                    <td style="padding-left: 1em">
                                                                                        <?php echo $matno ?></td>
                                                                                </tr>
                                                                                <!--<tr><th style="text-align: left">STATE OF ORIGIN :</th><td style="padding-left: 1em; text-align: left"><?php /*echo $stateorigin */ ?></td><th style="padding-left: 1em; text-align: left">LOCAL GOVT. AREA :</th><td style="padding-left: 1em"><?php /*echo $lga */ ?></td><th style="padding-left: 1em; text-align: left">SEX :</th><td style="padding-left: 1em"><?php /*echo $sex1 */ ?></td></tr>
                    <tr><th style="vertical-align: top;text-align: left">ADDRESS :</th><td style="padding-left: 1em; text-align: left"><?php /*echo $permaddres */ ?></td><th style="padding-left: 1em; text-align: left">DATE OF BIRTH :</th><td style="padding-left: 1em"><?php /*echo $dob */ ?></td><th style="padding-left: 1em; text-align: left">YEAR OF MATRICULATION:</th><td style="padding-left: 1em"><?php /*echo $YAddmitted */ ?></td></tr>
                    <tr><th style="vertical-align: top;text-align: left">PROGRAMME:</th><td style="padding-left: 1em; text-align: left"><?php /*echo $prog */ ?></td><th style="padding-left: 1em; text-align: left">PLACE OF BIRTH :</th><td style="padding-left: 1em"><?php /*echo $PlaceBirth */ ?></td><th style="padding-left: 1em; text-align: left">YEAR OF GRADUATION :</th><td style="padding-left: 1em"><?php /*echo $yeargrad */ ?></td></tr>-->
                                                                            </tbody>
                                                                        </table>

                                                                        <table style="color: #0a0a0a; width: 100%; font-size: 10px">
                                                                            <tbody>

                                                                                <tr>
                                                                                    <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                        <?php echo $sessionarry[3] . " " . $LevelArray[3] . "  Level" ?>
                                                                                    </th>
                                                                                    <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                        <?php echo $sessionarry[4] . " " . $LevelArray[4] . "  Level" ?>
                                                                                    </th>
                                                                                    <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                        <?php if ($SessionCount > 5) {
                                                                                            echo $sessionarry[5] . " " . $LevelArray[5] . "  Level";
                                                                                        } ?> </th>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td style="border-style:solid; border-width:thin; width: 33%" valign="top">

                                                                                        <?php

                                                                                        echo "<table style='font-size:13px; width: 100%'>";
                                                                                        echo "<thead style='text-align:center;'>";
                                                                                        echo "<tr>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                        echo "</tr>";
                                                                                        echo "</thead>";
                                                                                        echo "<tbody>";

                                                                                        $arrayNumb = 3;
                                                                                        if ($SessionCount >= 3) {
                                                                                            if ($absent1ST[3] != 0 && $absent2ND[3] != 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[3] == 0 && $absent2ND[3] != 0) {
                                                                                                if ($siwesstatus == "Part") {
                                                                                                    if ($LevelArray[3] != 300) {
                                                                                                        $indSession = $sessionarry[3];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                    }
                                                                                                }

                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[3] != 0 && $absent2ND[3] == 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                                if ($sessionarry[3] != $getMaxSess) {
                                                                                                    if ($LevelArray[3] != 300) {
                                                                                                        $indSession = $sessionarry[3];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                    }
                                                                                                }
                                                                                            } elseif ($absent1ST[3] == 0 && $absent2ND[3] == 0) {
                                                                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                if ($conn->connect_error) {
                                                                                                    die("Connection failed: " . $conn->connect_error);
                                                                                                }
                                                                                                $Issess3 = false;
                                                                                                $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[3]'";
                                                                                                $result4 = $conn->query($sql4);
                                                                                                if ($result4->num_rows > 0) {
                                                                                                    $response_full = "Cancel Session";
                                                                                                    $Issess3 = true;
                                                                                                }
                                                                                                $conn->close();
                                                                                                if ($Issess3 == false) {
                                                                                                    $indSession = $sessionarry[3];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                }
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                            }


                                                                                            if ($tct[3] != 0) {
                                                                                                echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[3]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[3]</th></tr>";
                                                                                            }
                                                                                        }

                                                                                        echo "</tbody>";
                                                                                        echo "</table>";

                                                                                        ?>

                                                                                    </td>
                                                                                    <td style="border-style:solid; border-width:thin; width: 33%" valign="top">
                                                                                        <?php
                                                                                        //$session1 = $sessionarry[1];
                                                                                        //include 'includes/semresults.php';
                                                                                        echo "<table style='font-size:13px; width: 100%'>";
                                                                                        echo "<thead style='text-align:center;'>";
                                                                                        echo "<tr>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                        echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                        echo "</tr>";
                                                                                        echo "</thead>";
                                                                                        echo "<tbody>";

                                                                                        $arrayNumb = 4;
                                                                                        if ($SessionCount >= 4) {
                                                                                            if ($absent1ST[4] != 0 && $absent2ND[4] != 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[4] == 0 && $absent2ND[4] != 0) {
                                                                                                if ($LevelArray[4] < 500) {
                                                                                                    if ($LevelArray[4] == 400) {
                                                                                                        if ($siwesstatus == "Part") {
                                                                                                            $indSession = $sessionarry[4];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        }
                                                                                                    } elseif ($LevelArray[4] == 300) {
                                                                                                        if ($LevelArray[3] != 300) {
                                                                                                            $indSession = $sessionarry[4];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        }
                                                                                                    }
                                                                                                } else {
                                                                                                    $indSession = $sessionarry[4];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                }
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[4] != 0 && $absent2ND[4] == 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                                if ($sessionarry[4] != $getMaxSess) {
                                                                                                    if ($LevelArray[4] < 500) {
                                                                                                        if ($LevelArray[4] == 300) {
                                                                                                            if ($LevelArray[3] != 300) {
                                                                                                                $indSession = $sessionarry[4];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    } else {
                                                                                                        $indSession = $sessionarry[4];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                    }
                                                                                                }
                                                                                            } elseif ($absent1ST[4] == 0 && $absent2ND[4] == 0) {

                                                                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                if ($conn->connect_error) {
                                                                                                    die("Connection failed: " . $conn->connect_error);
                                                                                                }
                                                                                                $Issess4 = false;
                                                                                                $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[4]'";
                                                                                                $result4 = $conn->query($sql4);
                                                                                                if ($result4->num_rows > 0) {
                                                                                                    $response_full = "Cancel Session";
                                                                                                    $Issess4 = true;
                                                                                                }
                                                                                                $conn->close();
                                                                                                if ($Issess4 == false) {
                                                                                                    $indSession = $sessionarry[4];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                }
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                            }


                                                                                            if ($tct[4] != 0) {
                                                                                                echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[4]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[4]</th></tr>";
                                                                                            }
                                                                                        }

                                                                                        echo "</tbody>";
                                                                                        echo "</table>";

                                                                                        ?>


                                                                                    </td>
                                                                                    <td style="border-style:solid; border-width:thin" valign="top">
                                                                                        <?php
                                                                                        if ($SessionCount > 5) {
                                                                                            echo "<table style='font-size:13px; width: 100%'>";
                                                                                            echo "<thead style='text-align:center;'>";
                                                                                            echo "<tr>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                            echo "</tr>";
                                                                                            echo "</thead>";
                                                                                            echo "<tbody>";

                                                                                            $arrayNumb = 5;
                                                                                            if ($SessionCount >= 5) {
                                                                                                if ($absent1ST[5] != 0 && $absent2ND[5] != 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[5] == 0 && $absent2ND[5] != 0) {
                                                                                                    if ($LevelArray[4] < 500) {
                                                                                                        if ($LevelArray[4] == 400) {
                                                                                                            $indSession = $sessionarry[5];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        } else {
                                                                                                            if ($LevelArray[4] == 300) {
                                                                                                                if ($LevelArray[5] == 400) {
                                                                                                                    if ($siwesstatus == "Part") {
                                                                                                                        $indSession = $sessionarry[5];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } elseif ($LevelArray[5] != 300) {
                                                                                                                    $indSession = $sessionarry[5];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } else {
                                                                                                                $indSession = $sessionarry[5];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[5] != 0 && $absent2ND[5] == 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                    if ($sessionarry[5] != $getMaxSess) {
                                                                                                        if ($LevelArray[4] < 500) {
                                                                                                            if ($LevelArray[4] == 400) {
                                                                                                                $indSession = $sessionarry[5];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            } else {
                                                                                                                if ($LevelArray[4] == 300) {
                                                                                                                    if ($LevelArray[5] != 400) {
                                                                                                                        $indSession = $sessionarry[5];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    $indSession = $sessionarry[5];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                } elseif ($absent1ST[5] == 0 && $absent2ND[5] == 0) {

                                                                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                    if ($conn->connect_error) {
                                                                                                        die("Connection failed: " . $conn->connect_error);
                                                                                                    }
                                                                                                    $Issess5 = false;
                                                                                                    $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[5]'";
                                                                                                    $result4 = $conn->query($sql4);
                                                                                                    if ($result4->num_rows > 0) {
                                                                                                        $response_full = "Cancel Session";
                                                                                                        $Issess5 = true;
                                                                                                    }
                                                                                                    $conn->close();
                                                                                                    if ($Issess5 == false) {
                                                                                                        $indSession = $sessionarry[5];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                    }
                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                }


                                                                                                if ($tct[5] != 0) {
                                                                                                    echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[5]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[5]</th></tr>";
                                                                                                }
                                                                                            }

                                                                                            echo "</tbody>";
                                                                                            echo "</table>";
                                                                                        }
                                                                                        ?>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td style="border-style:solid; border-width:thin">
                                                                                        <?php if ($SessionCount >= 3) { ?>
                                                                                            <?php if ($tct[3] !== 0) { ?>
                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>

                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                Cumulative Average
                                                                                                            </th>
                                                                                                            <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                <?php echo number_format((float)$LevelCGPA[3], 2, '.', '') ?>
                                                                                                            </th>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            <?php } ?>
                                                                                        <?php } ?>
                                                                                    </td>
                                                                                    <td style="border-style:solid; border-width:thin">
                                                                                        <?php if ($SessionCount >= 4) { ?>
                                                                                            <?php if ($tct[4] !== 0) { ?>
                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>

                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                Cumulative Average
                                                                                                            </th>
                                                                                                            <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                <?php echo number_format((float)$LevelCGPA[4], 2, '.', '') ?>
                                                                                                            </th>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            <?php } ?>
                                                                                        <?php } ?>
                                                                                    </td>
                                                                                    <td style="border-style:solid; border-width:thin">
                                                                                        <?php if ($SessionCount >= 5) { ?>
                                                                                            <?php if ($tct[5] != 0) { ?>
                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>

                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                Cumulative Average
                                                                                                            </th>
                                                                                                            <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                <?php echo number_format((float)$LevelCGPA[5], 2, '.', '') ?>
                                                                                                            </th>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            <?php } ?>
                                                                                        <?php } ?>
                                                                                    </td>
                                                                                </tr>

                                                                                <?php if ($arrayNumb <= 5) { ?>
                                                                                    <tr>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <table style="width: 100%; font-size: 12px">
                                                                                                <tbody>

                                                                                                    <tr style='border: 1px solid #ddd'>
                                                                                                        <th style='padding-left: 1em; text-align: left'>
                                                                                                            PROGRAME:-
                                                                                                            <?php echo $deptname ?>
                                                                                                        </th>
                                                                                                    </tr>
                                                                                                    <tr style='border: 1px solid #ddd'>
                                                                                                        <th style='padding-left: 1em; text-align: left'>
                                                                                                            DEGREE:- B.Sc
                                                                                                            (<?php echo $classdegree ?>)
                                                                                                        </th>
                                                                                                    </tr>
                                                                                                    <tr style='border: 1px solid #ddd'>
                                                                                                        <th style='padding-left: 1em; text-align: left'>
                                                                                                            DATE OF GRADUATION:-
                                                                                                            <?php echo $yeargrad ?>
                                                                                                        </th>
                                                                                                    </tr>
                                                                                                </tbody>
                                                                                            </table>
                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <table style="width: 100%; font-size: 10px">
                                                                                                <tbody>
                                                                                                    <p style="text-align: center; font-size:large;">
                                                                                                        GRADING SYSTEM
                                                                                                    </p>
                                                                                                    <tr>
                                                                                                        <th style="text-align: center">
                                                                                                            CGPA</th>
                                                                                                        <th style="text-align: center">
                                                                                                            Class of
                                                                                                            Degree</th>

                                                                                                    </tr>

                                                                                                    <?php if ($classdegree == "First Class") { ?>
                                                                                                        <tr style='border: 3px solid #ddd; color:<?php echo $_SESSION['sch_color'] ?>'>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                4.50 - 5.00
                                                                                                            </th>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                First Class
                                                                                                            </th>

                                                                                                        </tr>
                                                                                                    <?php } else { ?>
                                                                                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                            <td>4.50 - 5.00</td>
                                                                                                            <td>First Class</td>

                                                                                                        </tr>
                                                                                                    <?php } ?>

                                                                                                    <?php if ($classdegree == "Second Class Upper") { ?>
                                                                                                        <tr style='border: 3px solid #ddd; color:<?php echo $_SESSION['sch_color'] ?>'>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                3.50 - 4.49
                                                                                                            </th>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                Second Class
                                                                                                                Upper</th>

                                                                                                        </tr>
                                                                                                    <?php } else { ?>
                                                                                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                            <td>3.50 - 4.49</td>
                                                                                                            <td>Second Class Upper
                                                                                                            </td>

                                                                                                        </tr>
                                                                                                    <?php } ?>

                                                                                                    <?php if ($classdegree == "Second Class Lower") { ?>
                                                                                                        <tr style='border: 3px solid #ddd; color:<?php echo $_SESSION['sch_color'] ?>'>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                2.40 - 3.49
                                                                                                            </th>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                Second Class Lower
                                                                                                            </th>

                                                                                                        </tr>
                                                                                                    <?php } else { ?>
                                                                                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                            <td>2.40 - 3.49</td>
                                                                                                            <td>Second Class Lower
                                                                                                            </td>

                                                                                                        </tr>
                                                                                                    <?php } ?>

                                                                                                    <?php if ($classdegree == "Third Class") { ?>
                                                                                                        <tr style='border: 3px solid #ddd; color:<?php echo $_SESSION['sch_color'] ?>'>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                1.50 - 2.39
                                                                                                            </th>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                Third Class
                                                                                                            </th>

                                                                                                        </tr>
                                                                                                    <?php } else { ?>
                                                                                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                            <td>1.50 - 2.39</td>
                                                                                                            <td>Third Class</td>

                                                                                                        </tr>
                                                                                                    <?php } ?>

                                                                                                    <?php if ($classdegree == "Pass") { ?>
                                                                                                        <tr style='border: 3px solid #ddd; color:<?php echo $_SESSION['sch_color'] ?>'>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                1.00 - 1.49
                                                                                                            </th>
                                                                                                            <th style="text-align: center; font-size:14px;">
                                                                                                                Pass
                                                                                                            </th>

                                                                                                        </tr>
                                                                                                    <?php } else { ?>
                                                                                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                            <td>1.00 - 1.49</td>
                                                                                                            <td>Pass</td>

                                                                                                        </tr>
                                                                                                    <?php } ?>
                                                                                                    <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                        <td>0.00 - 0.99</td>
                                                                                                        <td>Fail</td>

                                                                                                    </tr>

                                                                                                </tbody>
                                                                                            </table>
                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <br><br>
                                                                                            <p style="text-align: center; font-size:large; color:#000000">
                                                                                                REGISTRAR's
                                                                                                SIGNATURE AND DATE</p>
                                                                                            <br>
                                                                                            <p style="text-align: center; font-size:large; color:#000000">
                                                                                                Office Stamp</p>
                                                                                        </td>
                                                                                    </tr>
                                                                                <?php } ?>
                                                                            </tbody>
                                                                        </table>

                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="row" style="text-align: right">
                                                        <br>
                                                        <input type="button" value="print to PDF" id="btnPrint2" class="btn-success" />
                                                    </div>
                                                </div>
                                                <?php if ($SessionCount >= 6) { ?>
                                                    <div id="page3" class="tab-pane">
                                                        <div id="dvContainer3" style="width: auto; float: none">
                                                            <style>
                                                                table,
                                                                th,
                                                                td {
                                                                    /*border: 1px solid black;*/
                                                                    border-collapse: collapse;
                                                                    font-size: 11px;
                                                                }
                                                            </style>
                                                            <!--<p style="text-align: center; font-size: 10px"><strong>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</strong></p>-->
                                                            <table style="width: 99%">
                                                                <tbody>
                                                                    <tr>
                                                                        <td>
                                                                            <table style="width: 100%">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="width: 10%">
                                                                                            <img src="img/logo.ico" height="70" alt="logo" />
                                                                                        </td>
                                                                                        <th style="width: 80%">
                                                                                            <h2 style="text-align: center; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                                <?php echo $_SESSION['instname'] ?>
                                                                                            </h2>
                                                                                            <h4 style="text-align: center; color:#000000">
                                                                                                <?php echo $_SESSION['InstAdrress'] ?>
                                                                                            </h4>
                                                                                            <h3 style="text-align: center; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                                STUDENTS'
                                                                                                ACADEMIC
                                                                                                TRANSCRIPT</h3>


                                                                                        </th>
                                                                                        <td>
                                                                                            <figure class="profile-picture">
                                                                                                <?php
                                                                                                /* $sql = "SELECT imageType, imageData FROM " . $dept . " WHERE stdid='$stdid'";
                                                                            $sth = $conn10->query($sql);
                                                                            $result2 = mysqli_fetch_array($sth);

                                                                            echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['imageData']) . '"  width="70" height="70"/>'; */
                                                                                                ?>
                                                                                            </figure>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                            <table style="font-size:9px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                                                                                <tbody style="color: #0a0a0a">
                                                                                    <tr>
                                                                                        <th style="text-align: left;width: 10%">
                                                                                            SURNAME :</th>
                                                                                        <td style="width: 30%; text-align: left; padding-left: 1em">
                                                                                            <?php echo $name_first ?></td>
                                                                                        <th style="padding-left: 1em;width: 12%; text-align: left">
                                                                                            OTHER NAME(S) :</th>
                                                                                        <td style="padding-left: 1em;width: 18%">
                                                                                            <?php echo $name_middle . " " . $name_last ?>
                                                                                        </td>
                                                                                        <th style="padding-left: 1em;width: 18%; text-align: left">
                                                                                            MATRICULATION NUMBER :</th>
                                                                                        <td style="padding-left: 1em">
                                                                                            <?php echo $matno ?></td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>

                                                                            <table style="color: #0a0a0a; width: 100%; font-size: 10px">
                                                                                <tbody>

                                                                                    <tr>
                                                                                        <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                            <?php echo $sessionarry[6] . " " . $LevelArray[6] . "  Level" ?>
                                                                                        </th>
                                                                                        <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                            <?php if ($SessionCount >= 7) {
                                                                                                echo $sessionarry[7] . " " . $LevelArray[7] . "  Level";
                                                                                            } ?></th>
                                                                                        <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                            <?php if ($SessionCount >= 8) {
                                                                                                echo $sessionarry[8] . " " . $LevelArray[8] . "  Level";
                                                                                            } ?> </th>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="border-style:solid; border-width:thin; width: 33%" valign="top">

                                                                                            <?php

                                                                                            echo "<table style='font-size:13px; width: 100%'>";
                                                                                            echo "<thead style='text-align:center;'>";
                                                                                            echo "<tr>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                            echo "</tr>";
                                                                                            echo "</thead>";
                                                                                            echo "<tbody>";

                                                                                            $arrayNumb = 6;
                                                                                            if ($absent1ST[6] != 0 && $absent2ND[6] != 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[6] == 0 && $absent2ND[6] != 0) {
                                                                                                if ($LevelArray[5] < 500) {
                                                                                                    if ($LevelArray[5] == 400) {
                                                                                                        $indSession = $sessionarry[6];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                    } else {
                                                                                                        if ($LevelArray[5] == 300) {
                                                                                                            if ($LevelArray[6] == 400) {
                                                                                                                if ($siwesstatus == "Part") {
                                                                                                                    $indSession = $sessionarry[6];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } elseif ($LevelArray[6] != 300) {
                                                                                                                $indSession = $sessionarry[6];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        } else {
                                                                                                            $indSession = $sessionarry[6];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[6] != 0 && $absent2ND[6] == 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                                if ($sessionarry[6] != $getMaxSess) {
                                                                                                    if ($LevelArray[5] < 500) {
                                                                                                        if ($LevelArray[5] == 400) {
                                                                                                            $indSession = $sessionarry[6];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        } else {
                                                                                                            if ($LevelArray[5] == 300) {
                                                                                                                if ($LevelArray[6] != 400) {
                                                                                                                    $indSession = $sessionarry[6];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } else {
                                                                                                                $indSession = $sessionarry[6];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            } elseif ($absent1ST[6] == 0 && $absent2ND[6] == 0) {

                                                                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                if ($conn->connect_error) {
                                                                                                    die("Connection failed: " . $conn->connect_error);
                                                                                                }
                                                                                                $Issess6 = false;
                                                                                                $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[6]'";
                                                                                                $result4 = $conn->query($sql4);
                                                                                                if ($result4->num_rows > 0) {
                                                                                                    $response_full = "Cancel Session";
                                                                                                    $Issess6 = true;
                                                                                                }
                                                                                                $conn->close();
                                                                                                if ($Issess6 == false) {
                                                                                                    $indSession = $sessionarry[6];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                }
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                            }


                                                                                            if ($tct[6] != 0) {
                                                                                                echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[6]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[6]</th></tr>";
                                                                                            }


                                                                                            echo "</tbody>";
                                                                                            echo "</table>";

                                                                                            ?>

                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin; width: 33%" valign="top">
                                                                                            <?php
                                                                                            //$session1 = $sessionarry[1];
                                                                                            //include 'includes/semresults.php';
                                                                                            echo "<table style='font-size:13px; width: 100%'>";
                                                                                            echo "<thead style='text-align:center;'>";
                                                                                            echo "<tr>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                            echo "</tr>";
                                                                                            echo "</thead>";
                                                                                            echo "<tbody>";

                                                                                            if ($SessionCount >= 7) {
                                                                                                $arrayNumb = 7;
                                                                                                if ($absent1ST[7] != 0 && $absent2ND[7] != 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[7] == 0 && $absent2ND[7] != 0) {
                                                                                                    if ($LevelArray[6] < 500) {
                                                                                                        if ($LevelArray[6] == 400) {
                                                                                                            $indSession = $sessionarry[7];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        } else {
                                                                                                            if ($LevelArray[6] == 300) {
                                                                                                                if ($LevelArray[7] == 400) {
                                                                                                                    if ($siwesstatus == "Part") {
                                                                                                                        $indSession = $sessionarry[7];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } elseif ($LevelArray[7] != 300) {
                                                                                                                    $indSession = $sessionarry[7];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } else {
                                                                                                                $indSession = $sessionarry[7];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[7] != 0 && $absent2ND[7] == 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                    if ($sessionarry[7] != $getMaxSess) {
                                                                                                        if ($LevelArray[6] < 500) {
                                                                                                            if ($LevelArray[6] == 400) {
                                                                                                                $indSession = $sessionarry[7];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            } else {
                                                                                                                if ($LevelArray[6] == 300) {
                                                                                                                    if ($LevelArray[7] != 400) {
                                                                                                                        $indSession = $sessionarry[7];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    $indSession = $sessionarry[7];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                } elseif ($absent1ST[7] == 0 && $absent2ND[7] == 0) {

                                                                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                    if ($conn->connect_error) {
                                                                                                        die("Connection failed: " . $conn->connect_error);
                                                                                                    }
                                                                                                    $Issess7 = false;
                                                                                                    $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[7]'";
                                                                                                    $result4 = $conn->query($sql4);
                                                                                                    if ($result4->num_rows > 0) {
                                                                                                        $response_full = "Cancel Session";
                                                                                                        $Issess7 = true;
                                                                                                    }
                                                                                                    $conn->close();
                                                                                                    if ($Issess7 == false) {
                                                                                                        $indSession = $sessionarry[7];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                    }
                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                }


                                                                                                if ($tct[7] != 0) {
                                                                                                    echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[7]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[7]</th></tr>";
                                                                                                }
                                                                                            }


                                                                                            echo "</tbody>";
                                                                                            echo "</table>";

                                                                                            ?>


                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin" valign="top">
                                                                                            <?php
                                                                                            //$session1 = $sessionarry[2];
                                                                                            //include 'includes/semresults.php';
                                                                                            echo "<table style='font-size:13px; width: 100%'>";
                                                                                            echo "<thead style='text-align:center;'>";
                                                                                            echo "<tr>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                            echo "</tr>";
                                                                                            echo "</thead>";
                                                                                            echo "<tbody>";

                                                                                            if ($SessionCount >= 8) {
                                                                                                $arrayNumb = 8;
                                                                                                if ($absent1ST[8] != 0 && $absent2ND[8] != 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[8] == 0 && $absent2ND[8] != 0) {
                                                                                                    if ($LevelArray[7] < 500) {
                                                                                                        if ($LevelArray[7] == 400) {
                                                                                                            $indSession = $sessionarry[8];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        } else {
                                                                                                            if ($LevelArray[7] == 300) {
                                                                                                                if ($LevelArray[8] == 400) {
                                                                                                                    if ($siwesstatus == "Part") {
                                                                                                                        $indSession = $sessionarry[8];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } elseif ($LevelArray[8] != 300) {
                                                                                                                    $indSession = $sessionarry[8];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } else {
                                                                                                                $indSession = $sessionarry[8];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[8] != 0 && $absent2ND[8] == 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                    if ($sessionarry[8] != $getMaxSess) {
                                                                                                        if ($LevelArray[7] < 500) {
                                                                                                            if ($LevelArray[7] == 400) {
                                                                                                                $indSession = $sessionarry[8];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            } else {
                                                                                                                if ($LevelArray[7] == 300) {
                                                                                                                    if ($LevelArray[8] != 400) {
                                                                                                                        $indSession = $sessionarry[8];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    $indSession = $sessionarry[8];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                } elseif ($absent1ST[8] == 0 && $absent2ND[8] == 0) {

                                                                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                    if ($conn->connect_error) {
                                                                                                        die("Connection failed: " . $conn->connect_error);
                                                                                                    }
                                                                                                    $Issess8 = false;
                                                                                                    $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[8]'";
                                                                                                    $result4 = $conn->query($sql4);
                                                                                                    if ($result4->num_rows > 0) {
                                                                                                        $response_full = "Cancel Session";
                                                                                                        $Issess8 = true;
                                                                                                    }
                                                                                                    $conn->close();
                                                                                                    if ($Issess8 == false) {
                                                                                                        $indSession = $sessionarry[8];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                    }
                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                }


                                                                                                if ($tct[8] != 0) {
                                                                                                    echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[8]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[8]</th></tr>";
                                                                                                }
                                                                                            }

                                                                                            echo "</tbody>";
                                                                                            echo "</table>";

                                                                                            ?>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <?php if ($SessionCount >= 6) { ?>
                                                                                                <?php if ($tct[6] !== 0) { ?>
                                                                                                    <table style="width: 100%; font-size: 10px">
                                                                                                        <tbody>

                                                                                                            <tr>
                                                                                                                <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                    Cumulative Average
                                                                                                                </th>
                                                                                                                <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                    <?php echo number_format((float)$LevelCGPA[6], 2, '.', '') ?>
                                                                                                                </th>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                <?php } ?>
                                                                                            <?php } ?>
                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <?php if ($SessionCount >= 7) { ?>
                                                                                                <?php if ($tct[7] !== 0) { ?>
                                                                                                    <table style="width: 100%; font-size: 10px">
                                                                                                        <tbody>

                                                                                                            <tr>
                                                                                                                <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                    Cumulative Average
                                                                                                                </th>
                                                                                                                <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                    <?php echo number_format((float)$LevelCGPA[7], 2, '.', '') ?>
                                                                                                                </th>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                <?php } ?>
                                                                                            <?php } ?>
                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <?php if ($arrayNumb >= 8) { ?>
                                                                                                <?php if ($tct[8] !== 0) { ?>
                                                                                                    <table style="width: 100%; font-size: 10px">
                                                                                                        <tbody>

                                                                                                            <tr>
                                                                                                                <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                    Cumulative Average
                                                                                                                </th>
                                                                                                                <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                    <?php echo number_format((float)$LevelCGPA[8], 2, '.', '') ?>
                                                                                                                </th>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                <?php } ?>
                                                                                            <?php } ?>
                                                                                        </td>
                                                                                    </tr>

                                                                                    <?php if ($arrayNumb <= 8) { ?>
                                                                                        <tr>
                                                                                            <td style="border-style:solid; border-width:thin">
                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>
                                                                                                        <tr style="border: 1px solid #ddd">
                                                                                                            <th style="text-align: center">
                                                                                                                SUMMARY</th>
                                                                                                        </tr>

                                                                                                        <?php
                                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                                        if ($conn_stu->connect_error) {
                                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                                        }
                                                                                                        $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                                                                                        $result = $conn_stu->query($sql);
                                                                                                        if ($result->num_rows > 0) {
                                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                                $gettitle = $row['title1'];
                                                                                                                if ($gettitle == "XXXX") {
                                                                                                                    echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'> .</td></tr>";
                                                                                                                } else {
                                                                                                                    echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'>$gettitle</td></tr>";
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                        $conn_stu->close();
                                                                                                        ?>
                                                                                                        <tr style='border: 1px solid #ddd'>
                                                                                                            <td style='padding-left: 1em; text-align: left'>
                                                                                                                SWEP</td>
                                                                                                        </tr>
                                                                                                        <tr style='border: 1px solid #ddd'>
                                                                                                            <th style='padding-left: 1em; text-align: left'>
                                                                                                                Total:-</th>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </td>
                                                                                            <td style="border-style:solid; border-width:thin">
                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>
                                                                                                        <tr>
                                                                                                            <th style="text-align: center">
                                                                                                                REQUIRED</th>
                                                                                                            <th style="text-align: center">
                                                                                                                EARNED</th>
                                                                                                            <th style="text-align: center">
                                                                                                                DEF</th>
                                                                                                        </tr>

                                                                                                        <?php
                                                                                                        $totReq = $totearn = $totdif = 0;
                                                                                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                                        if ($conn_stu->connect_error) {
                                                                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                                                                        }
                                                                                                        $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                                                                                        $result = $conn_stu->query($sql);
                                                                                                        if ($result->num_rows > 0) {
                                                                                                            while ($row = $result->fetch_assoc()) {
                                                                                                                $require1 = $row['require1'];
                                                                                                                $earned = $row['earned'];
                                                                                                                $totReq = $totReq + $require1;
                                                                                                                $totearn = $totearn + $earned;
                                                                                                                $dif = $require1 - $earned;
                                                                                                                if ($dif <= 0) {
                                                                                                                    $dif = 0;
                                                                                                                }
                                                                                                                $totdif = $totdif + $dif;
                                                                                                                echo "<tr style='border: 1px solid #ddd; text-align: center'><td>$require1</td><td>$earned</td><td>$dif</td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                        $conn_stu->close();

                                                                                                        $totReq = $totReq + 2;
                                                                                                        $totearn = $totearn + 2;

                                                                                                        ?>
                                                                                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                            <td>0</td>
                                                                                                            <td>0</td>
                                                                                                            <td>0</td>
                                                                                                        </tr>
                                                                                                        <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                            <th style="text-align: center">
                                                                                                                <?php echo $totReq ?>
                                                                                                            </th>
                                                                                                            <th style="text-align: center">
                                                                                                                <?php echo $totearn ?>
                                                                                                            </th>
                                                                                                            <th style="text-align: center">
                                                                                                                <?php echo $totdif ?>
                                                                                                            </th>
                                                                                                        </tr>

                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </td>
                                                                                            <td style="border-style:solid; border-width:thin">

                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>

                                                                                                        <tr>
                                                                                                            <td>.</td>
                                                                                                            <td>.</td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                                TCT for graduation:
                                                                                                            </th>
                                                                                                            <td style="border-bottom-style: solid; border-width:thin">
                                                                                                                <?php echo $totunit1 ?>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                                TCP for graduation:
                                                                                                            </th>
                                                                                                            <td style="border-bottom-style: solid; border-width:thin">
                                                                                                                <?php echo $stcp1 ?>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                                TGP for graduation:
                                                                                                            </th>
                                                                                                            <td style="border-bottom-style: solid; border-width:thin">
                                                                                                                <?php echo $totgp1 ?>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                                CGPA:</th>
                                                                                                            <td style="border-bottom-style: solid; border-width:thin">
                                                                                                                <?php echo number_format((float)$ccgpa, 2, '.', '') ?>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                                Class of Degree :-
                                                                                                            </th>
                                                                                                            <td style="border-bottom-style: solid; border-width:thin">
                                                                                                                <?php echo $classdegree ?>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                                Remark :- </th>
                                                                                                            <td style="border-bottom-style: solid; border-width:thin">
                                                                                                                PASSED</td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                                * A satisfactory
                                                                                                                completion of the
                                                                                                                scheme is all that
                                                                                                                is required to
                                                                                                                qualify the
                                                                                                                candidate for
                                                                                                                graduation
                                                                                                            </th>
                                                                                                            <td style="border-bottom-style: solid; border-width:thin">
                                                                                                            </td>
                                                                                                        </tr>


                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </td>
                                                                                        </tr>
                                                                                    <?php } ?>
                                                                                </tbody>
                                                                            </table>
                                                                            <table style="width: 100%; font-size: 10px">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="width: 40%; text-align: left">
                                                                                            .</td>
                                                                                        <th style="width: 25%; font-size: 12px">
                                                                                            <?php if ($NotRelevant == true) {
                                                                                                echo "* Courses NOT Relevant to the Department";
                                                                                            } ?>
                                                                                        </th>
                                                                                        <td></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 40%; text-align: left">
                                                                                        </td>
                                                                                        <td style="width: 25%"></td>
                                                                                        <td style="text-align: left">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="text-align: left"></td>
                                                                                        <td></td>
                                                                                        <th style="text-align: left; font-size:large">
                                                                                            REGISTRAR's
                                                                                            SIGNATURE AND DATE
                                                                                        </th>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <div class="row" style="text-align: right">
                                                            <br>
                                                            <input type="button" value="print to PDF" id="btnPrint3" class="btn-success" />
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php if ($SessionCount >= 9) { ?>
                                                    <div id="page4" class="tab-pane">
                                                        <div id="dvContainer4" style="width: auto; float: none">
                                                            <style>
                                                                table,
                                                                th,
                                                                td {
                                                                    /*border: 1px solid black;*/
                                                                    border-collapse: collapse;
                                                                    font-size: 11px;
                                                                }
                                                            </style>
                                                            <!--<p style="text-align: center; font-size: 10px"><strong>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</strong></p>-->
                                                            <table style="width: 99%">
                                                                <tbody>
                                                                    <tr>
                                                                        <td>
                                                                            <table style="width: 100%">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="width: 10%">
                                                                                            <img src="img/logo.ico" height="70" alt="logo" />
                                                                                        </td>
                                                                                        <th style="width: 80%">
                                                                                            <h2 style="text-align: center; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                                <?php echo $_SESSION['instname'] ?>
                                                                                            </h2>
                                                                                            <h4 style="text-align: center; color:#000000">
                                                                                                <?php echo $_SESSION['InstAdrress'] ?>
                                                                                            </h4>
                                                                                            <h3 style="text-align: center; color:<?php echo $_SESSION['sch_color'] ?>">
                                                                                                STUDENTS'
                                                                                                ACADEMIC
                                                                                                TRANSCRIPT</h3>


                                                                                        </th>
                                                                                        <td>
                                                                                            <figure class="profile-picture">
                                                                                                <?php
                                                                                                /* $sql = "SELECT imageType, imageData FROM " . $dept . " WHERE stdid='$stdid'";
                                                                            $sth = $conn10->query($sql);
                                                                            $result2 = mysqli_fetch_array($sth);

                                                                            echo '<img class="img-circle" src="data:image/jpeg;base64,' . base64_encode($result2['imageData']) . '"  width="70" height="70"/>'; */
                                                                                                ?>
                                                                                            </figure>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                            <table style="font-size:9px; width: 100%; color: #0a0a0a; padding-bottom: 1em">
                                                                                <tbody style="color: #0a0a0a">
                                                                                    <tr>
                                                                                        <th style="text-align: left;width: 10%">
                                                                                            SURNAME :</th>
                                                                                        <td style="width: 30%; text-align: left; padding-left: 1em">
                                                                                            <?php echo $name_first ?></td>
                                                                                        <th style="padding-left: 1em;width: 12%; text-align: left">
                                                                                            OTHER NAME(S) :</th>
                                                                                        <td style="padding-left: 1em;width: 18%">
                                                                                            <?php echo $name_middle . " " . $name_last ?>
                                                                                        </td>
                                                                                        <th style="padding-left: 1em;width: 18%; text-align: left">
                                                                                            MATRICULATION NUMBER :</th>
                                                                                        <td style="padding-left: 1em">
                                                                                            <?php echo $matno ?></td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>

                                                                            <table style="color: #0a0a0a; width: 100%; font-size: 10px">
                                                                                <tbody>

                                                                                    <tr>
                                                                                        <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                            <?php echo $sessionarry[9] . " " . $LevelArray[9] . "  Level" ?>
                                                                                        </th>
                                                                                        <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                            <?php if ($SessionCount >= 10) {
                                                                                                echo $sessionarry[10] . " " . $LevelArray[10] . "  Level";
                                                                                            } ?></th>
                                                                                        <th style="border-style:solid; border-width:thin; text-align:center">
                                                                                            <?php if ($SessionCount >= 11) {
                                                                                                echo $sessionarry[11] . " " . $LevelArray[11] . "  Level";
                                                                                            } ?> </th>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="border-style:solid; border-width:thin; width: 33%" valign="top">

                                                                                            <?php

                                                                                            echo "<table style='font-size:13px; width: 100%'>";
                                                                                            echo "<thead style='text-align:center;'>";
                                                                                            echo "<tr>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                            echo "</tr>";
                                                                                            echo "</thead>";
                                                                                            echo "<tbody>";

                                                                                            $arrayNumb = 9;
                                                                                            if ($absent1ST[9] != 0 && $absent2ND[9] != 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[9] == 0 && $absent2ND[9] != 0) {
                                                                                                if ($LevelArray[8] < 500) {
                                                                                                    if ($LevelArray[8] == 400) {
                                                                                                        $indSession = $sessionarry[9];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                    } else {
                                                                                                        if ($LevelArray[8] == 300) {
                                                                                                            if ($LevelArray[9] == 400) {
                                                                                                                if ($siwesstatus == "Part") {
                                                                                                                    $indSession = $sessionarry[9];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } elseif ($LevelArray[9] != 300) {
                                                                                                                $indSession = $sessionarry[9];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        } else {
                                                                                                            $indSession = $sessionarry[9];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                            } elseif ($absent1ST[9] != 0 && $absent2ND[9] == 0) {
                                                                                                include 'modulesInSess/calSemResult_Grad.php';
                                                                                                if ($sessionarry[9] != $getMaxSess) {
                                                                                                    if ($LevelArray[8] < 500) {
                                                                                                        if ($LevelArray[8] == 400) {
                                                                                                            $indSession = $sessionarry[9];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        } else {
                                                                                                            if ($LevelArray[8] == 300) {
                                                                                                                if ($LevelArray[9] != 400) {
                                                                                                                    $indSession = $sessionarry[9];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } else {
                                                                                                                $indSession = $sessionarry[9];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            } elseif ($absent1ST[9] == 0 && $absent2ND[9] == 0) {

                                                                                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                if ($conn->connect_error) {
                                                                                                    die("Connection failed: " . $conn->connect_error);
                                                                                                }
                                                                                                $Issess9 = false;
                                                                                                $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[9]'";
                                                                                                $result4 = $conn->query($sql4);
                                                                                                if ($result4->num_rows > 0) {
                                                                                                    $response_full = "Cancel Session";
                                                                                                    $Issess9 = true;
                                                                                                }
                                                                                                $conn->close();
                                                                                                if ($Issess9 == false) {
                                                                                                    $indSession = $sessionarry[9];
                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                }
                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                            }


                                                                                            if ($tct[9] != 0) {
                                                                                                echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[9]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[9]</th></tr>";
                                                                                            }


                                                                                            echo "</tbody>";
                                                                                            echo "</table>";

                                                                                            ?>

                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin; width: 33%" valign="top">
                                                                                            <?php
                                                                                            //$session1 = $sessionarry[1];
                                                                                            //include 'includes/semresults.php';
                                                                                            echo "<table style='font-size:13px; width: 100%'>";
                                                                                            echo "<thead style='text-align:center;'>";
                                                                                            echo "<tr>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                            echo "</tr>";
                                                                                            echo "</thead>";
                                                                                            echo "<tbody>";

                                                                                            if ($SessionCount >= 10) {
                                                                                                $arrayNumb = 10;
                                                                                                if ($absent1ST[10] != 0 && $absent2ND[10] != 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[10] == 0 && $absent2ND[10] != 0) {
                                                                                                    if ($LevelArray[9] < 500) {
                                                                                                        if ($LevelArray[9] == 400) {
                                                                                                            $indSession = $sessionarry[10];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        } else {
                                                                                                            if ($LevelArray[9] == 300) {
                                                                                                                if ($LevelArray[10] == 400) {
                                                                                                                    if ($siwesstatus == "Part") {
                                                                                                                        $indSession = $sessionarry[10];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } elseif ($LevelArray[10] != 300) {
                                                                                                                    $indSession = $sessionarry[10];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } else {
                                                                                                                $indSession = $sessionarry[10];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[10] != 0 && $absent2ND[10] == 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                    if ($sessionarry[10] != $getMaxSess) {
                                                                                                        if ($LevelArray[9] < 500) {
                                                                                                            if ($LevelArray[9] == 400) {
                                                                                                                $indSession = $sessionarry[10];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            } else {
                                                                                                                if ($LevelArray[9] == 300) {
                                                                                                                    if ($LevelArray[10] != 400) {
                                                                                                                        $indSession = $sessionarry[10];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    $indSession = $sessionarry[10];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                } elseif ($absent1ST[10] == 0 && $absent2ND[10] == 0) {

                                                                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                    if ($conn->connect_error) {
                                                                                                        die("Connection failed: " . $conn->connect_error);
                                                                                                    }
                                                                                                    $Issess10 = false;
                                                                                                    $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[10]'";
                                                                                                    $result4 = $conn->query($sql4);
                                                                                                    if ($result4->num_rows > 0) {
                                                                                                        $response_full = "Cancel Session";
                                                                                                        $Issess10 = true;
                                                                                                    }
                                                                                                    $conn->close();
                                                                                                    if ($Issess10 == false) {
                                                                                                        $indSession = $sessionarry[10];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                    }
                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                }


                                                                                                if ($tct[10] != 0) {
                                                                                                    echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[10]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[10]</th></tr>";
                                                                                                }
                                                                                            }


                                                                                            echo "</tbody>";
                                                                                            echo "</table>";

                                                                                            ?>


                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin" valign="top">
                                                                                            <?php
                                                                                            //$session1 = $sessionarry[2];
                                                                                            //include 'includes/semresults.php';
                                                                                            echo "<table style='font-size:13px; width: 100%'>";
                                                                                            echo "<thead style='text-align:center;'>";
                                                                                            echo "<tr>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>C Code</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>Course Title</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>CU</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GD</th>";
                                                                                            echo "<th style='border-style:solid; border-width:thin; padding-left:0.5em; padding-right:0.5em; font-size: 10px'>GP</th>";

                                                                                            echo "</tr>";
                                                                                            echo "</thead>";
                                                                                            echo "<tbody>";

                                                                                            if ($SessionCount >= 11) {
                                                                                                $arrayNumb = 11;
                                                                                                if ($absent1ST[11] != 0 && $absent2ND[11] != 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[11] == 0 && $absent2ND[11] != 0) {
                                                                                                    if ($LevelArray[10] < 500) {
                                                                                                        if ($LevelArray[10] == 400) {
                                                                                                            $indSession = $sessionarry[11];
                                                                                                            include 'modulesInSess/missing_ses.php';
                                                                                                            echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                        } else {
                                                                                                            if ($LevelArray[10] == 300) {
                                                                                                                if ($LevelArray[11] == 400) {
                                                                                                                    if ($siwesstatus == "Part") {
                                                                                                                        $indSession = $sessionarry[11];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } elseif ($LevelArray[11] != 300) {
                                                                                                                    $indSession = $sessionarry[11];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            } else {
                                                                                                                $indSession = $sessionarry[11];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                } elseif ($absent1ST[11] != 0 && $absent2ND[11] == 0) {
                                                                                                    include 'modulesInSess/calSemResult_Grad.php';
                                                                                                    if ($sessionarry[11] != $getMaxSess) {
                                                                                                        if ($LevelArray[10] < 500) {
                                                                                                            if ($LevelArray[10] == 400) {
                                                                                                                $indSession = $sessionarry[11];
                                                                                                                include 'modulesInSess/missing_ses.php';
                                                                                                                echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                            } else {
                                                                                                                if ($LevelArray[10] == 300) {
                                                                                                                    if ($LevelArray[11] != 400) {
                                                                                                                        $indSession = $sessionarry[11];
                                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                                        echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                    }
                                                                                                                } else {
                                                                                                                    $indSession = $sessionarry[11];
                                                                                                                    include 'modulesInSess/missing_ses.php';
                                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px;'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                } elseif ($absent1ST[11] == 0 && $absent2ND[11] == 0) {

                                                                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                                                                    if ($conn->connect_error) {
                                                                                                        die("Connection failed: " . $conn->connect_error);
                                                                                                    }
                                                                                                    $Issess11 = false;
                                                                                                    $sql4 = "SELECT * FROM cancelsessionlist WHERE cancsession = '$sessionarry[11]'";
                                                                                                    $result4 = $conn->query($sql4);
                                                                                                    if ($result4->num_rows > 0) {
                                                                                                        $response_full = "Cancel Session";
                                                                                                        $Issess11 = true;
                                                                                                    }
                                                                                                    $conn->close();
                                                                                                    if ($Issess11 == false) {
                                                                                                        $indSession = $sessionarry[11];
                                                                                                        include 'modulesInSess/missing_ses.php';
                                                                                                    }
                                                                                                    echo "<tr><td style='border-right-style:solid; border-right-width:thin'> </td><td style='border-right-style:solid; border-right-width:thin; font-size: 40px; text-align: center; height: 180px'>$response_full</td><td style='border-right-style:solid; border-right-width:thin; text-align:center' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td><td style='border-right-style:solid; border-right-width:thin; text-align:center;' valign='top'></td></tr>";
                                                                                                }


                                                                                                if ($tct[11] != 0) {
                                                                                                    echo "<tr><td style='border-style:solid; border-width:thin'></td><th style='border-style:solid; border-width:thin; padding-left: 1em'>Total</th><th style='border-style:solid; border-width:thin; text-align: center'>$tct[11]</th><th style='border-style:solid; border-width:thin'></th><th style='border-style:solid; border-width:thin; text-align: center'>$tgp[11]</th></tr>";
                                                                                                }
                                                                                            }

                                                                                            echo "</tbody>";
                                                                                            echo "</table>";

                                                                                            ?>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <?php if ($tct[9] !== 0) { ?>
                                                                                                <table style="width: 100%; font-size: 10px">
                                                                                                    <tbody>

                                                                                                        <tr>
                                                                                                            <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                Cumulative Average
                                                                                                            </th>
                                                                                                            <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                <?php echo number_format((float)$LevelCGPA[9], 2, '.', '') ?>
                                                                                                            </th>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            <?php } ?>
                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <?php if ($SessionCount >= 10) { ?>
                                                                                                <?php if ($tct[10] !== 0) { ?>
                                                                                                    <table style="width: 100%; font-size: 10px">
                                                                                                        <tbody>

                                                                                                            <tr>
                                                                                                                <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                    Cumulative Average
                                                                                                                </th>
                                                                                                                <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                    <?php echo number_format((float)$LevelCGPA[10], 2, '.', '') ?>
                                                                                                                </th>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                <?php } ?>
                                                                                            <?php } ?>
                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <?php if ($arrayNumb >= 11) { ?>
                                                                                                <?php if ($tct[11] !== 0) { ?>
                                                                                                    <table style="width: 100%; font-size: 10px">
                                                                                                        <tbody>

                                                                                                            <tr>
                                                                                                                <th style="padding-left: 1em; text-align: left; font-size:large">
                                                                                                                    Cumulative Average
                                                                                                                </th>
                                                                                                                <th style="text-align: right; padding-right: 1em; font-size:large">
                                                                                                                    <?php echo number_format((float)$LevelCGPA[11], 2, '.', '') ?>
                                                                                                                </th>
                                                                                                            </tr>
                                                                                                        </tbody>
                                                                                                    </table>
                                                                                                <?php } ?>
                                                                                            <?php } ?>
                                                                                        </td>
                                                                                    </tr>


                                                                                    <tr>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <table style="width: 100%; font-size: 10px">
                                                                                                <tbody>
                                                                                                    <tr style="border: 1px solid #ddd">
                                                                                                        <th style="text-align: center">
                                                                                                            SUMMARY</th>
                                                                                                    </tr>

                                                                                                    <?php
                                                                                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                                    if ($conn_stu->connect_error) {
                                                                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                                                                    }
                                                                                                    $sql = "SELECT * FROM " . $dept . "_grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                                                                                    $result = $conn_stu->query($sql);
                                                                                                    if ($result->num_rows > 0) {
                                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                                            $gettitle = $row['title1'];
                                                                                                            if ($gettitle == "XXXX") {
                                                                                                                echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'> .</td></tr>";
                                                                                                            } else {
                                                                                                                echo "<tr style='border: 1px solid #ddd'><td style='padding-left: 1em; text-align: left'>$gettitle</td></tr>";
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    $conn_stu->close();
                                                                                                    ?>
                                                                                                    <tr style='border: 1px solid #ddd'>
                                                                                                        <td style='padding-left: 1em; text-align: left'>
                                                                                                            SWEP</td>
                                                                                                    </tr>
                                                                                                    <tr style='border: 1px solid #ddd'>
                                                                                                        <th style='padding-left: 1em; text-align: left'>
                                                                                                            Total:-</th>
                                                                                                    </tr>
                                                                                                </tbody>
                                                                                            </table>
                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin">
                                                                                            <table style="width: 100%; font-size: 10px">
                                                                                                <tbody>
                                                                                                    <tr>
                                                                                                        <th style="text-align: center">
                                                                                                            REQUIRED</th>
                                                                                                        <th style="text-align: center">
                                                                                                            EARNED</th>
                                                                                                        <th style="text-align: center">
                                                                                                            DEF</th>
                                                                                                    </tr>

                                                                                                    <?php
                                                                                                    $totReq = $totearn = $totdif = 0;
                                                                                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                                                    if ($conn_stu->connect_error) {
                                                                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                                                                    }
                                                                                                    $sql = "SELECT * FROM grad_require WHERE Regn = '$matno' ORDER BY title1 DESC";
                                                                                                    $result = $conn_stu->query($sql);
                                                                                                    if ($result->num_rows > 0) {
                                                                                                        while ($row = $result->fetch_assoc()) {
                                                                                                            $require1 = $row['require1'];
                                                                                                            $earned = $row['earned'];
                                                                                                            $totReq = $totReq + $require1;
                                                                                                            $totearn = $totearn + $earned;
                                                                                                            $dif = $require1 - $earned;
                                                                                                            if ($dif <= 0) {
                                                                                                                $dif = 0;
                                                                                                            }
                                                                                                            $totdif = $totdif + $dif;
                                                                                                            echo "<tr style='border: 1px solid #ddd; text-align: center'><td>$require1</td><td>$earned</td><td>$dif</td></tr>";
                                                                                                        }
                                                                                                    }
                                                                                                    $conn_stu->close();

                                                                                                    $totReq = $totReq + 2;
                                                                                                    $totearn = $totearn + 2;

                                                                                                    ?>
                                                                                                    <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                        <td>0</td>
                                                                                                        <td>0</td>
                                                                                                        <td>0</td>
                                                                                                    </tr>
                                                                                                    <tr style='border: 1px solid #ddd; text-align: center'>
                                                                                                        <th style="text-align: center">
                                                                                                            <?php echo $totReq ?>
                                                                                                        </th>
                                                                                                        <th style="text-align: center">
                                                                                                            <?php echo $totearn ?>
                                                                                                        </th>
                                                                                                        <th style="text-align: center">
                                                                                                            <?php echo $totdif ?>
                                                                                                        </th>
                                                                                                    </tr>

                                                                                                </tbody>
                                                                                            </table>
                                                                                        </td>
                                                                                        <td style="border-style:solid; border-width:thin">

                                                                                            <table style="width: 100%; font-size: 10px">
                                                                                                <tbody>

                                                                                                    <tr>
                                                                                                        <td>.</td>
                                                                                                        <td>.</td>
                                                                                                    </tr>
                                                                                                    <tr>
                                                                                                        <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                            TCT for graduation:
                                                                                                        </th>
                                                                                                        <td style="border-bottom-style: solid; border-width:thin">
                                                                                                            <?php echo $totunit1 ?>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                    <tr>
                                                                                                        <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                            TCP for graduation:
                                                                                                        </th>
                                                                                                        <td style="border-bottom-style: solid; border-width:thin">
                                                                                                            <?php echo $stcp1 ?>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                    <tr>
                                                                                                        <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                            TGP for graduation:
                                                                                                        </th>
                                                                                                        <td style="border-bottom-style: solid; border-width:thin">
                                                                                                            <?php echo $totgp1 ?>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                    <tr>
                                                                                                        <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                            CGPA:</th>
                                                                                                        <td style="border-bottom-style: solid; border-width:thin">
                                                                                                            <?php echo number_format((float)$ccgpa, 2, '.', '') ?>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                    <tr>
                                                                                                        <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                            Class of Degree :-
                                                                                                        </th>
                                                                                                        <td style="border-bottom-style: solid; border-width:thin">
                                                                                                            <?php echo $classdegree ?>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                    <tr>
                                                                                                        <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                            Remark :- </th>
                                                                                                        <td style="border-bottom-style: solid; border-width:thin">
                                                                                                            PASSED</td>
                                                                                                    </tr>
                                                                                                    <tr>
                                                                                                        <th style="padding-left: 1em; text-align: left; border-bottom-style: solid; border-width:thin">
                                                                                                            * A satisfactory
                                                                                                            completion of the
                                                                                                            scheme is all that
                                                                                                            is required to
                                                                                                            qualify the
                                                                                                            candidate for
                                                                                                            graduation
                                                                                                        </th>
                                                                                                        <td style="border-bottom-style: solid; border-width:thin">
                                                                                                        </td>
                                                                                                    </tr>


                                                                                                </tbody>
                                                                                            </table>
                                                                                        </td>
                                                                                    </tr>

                                                                                </tbody>
                                                                            </table>
                                                                            <table style="width: 100%; font-size: 10px">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="width: 40%; text-align: left">
                                                                                            .</td>
                                                                                        <th style="width: 25%; font-size: 12px">
                                                                                            <?php if ($NotRelevant == true) {
                                                                                                echo "* Courses NOT Relevant to the Department";
                                                                                            } ?>
                                                                                        </th>
                                                                                        <td></td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="width: 40%; text-align: left">
                                                                                        </td>
                                                                                        <td style="width: 25%"></td>
                                                                                        <td style="text-align: left">
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td style="text-align: left"></td>
                                                                                        <td></td>
                                                                                        <th style="text-align: left; font-size:large">
                                                                                            REGISTRAR's
                                                                                            SIGNATURE AND DATE
                                                                                        </th>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <div class="row" style="text-align: right">
                                                            <br>
                                                            <input type="button" value="print to PDF" id="btnPrint4" class="btn-success" />
                                                        </div>

                                                    </div>
                                                <?php } ?>


                                            </div>
                                        </div>

                                    </section>

                                <?php } ?>

                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
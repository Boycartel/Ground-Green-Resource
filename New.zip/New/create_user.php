<?php
require_once 'includes/db_connect2.php';
require_once 'includes/check_validity.php';

if ($_SESSION['create_users'] == false) {
    header('Location: home_staff.php');
}
?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Create User</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Users
                            </li>

                            <li class="active">
                                <strong>Create User</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Create User
                        </div>
                        <div class="panel-body">
                            <?php
                            $recexist = $recsaved = $errorpf = "";
                            $errorcode = "NO";
                            $schcode = $_SESSION['schcode'];
                            $dept = $_SESSION['deptcode'];
                            $deptname = $_SESSION['deptname'];
                            if (isset($_POST['submit'])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }


                                $pfno = $fullname = $phoneno = $email = $responsblty = "";
                                $pfno = strtoupper($_POST['pfno']);
                                $pfno = filter_var($pfno, FILTER_SANITIZE_STRING);
                                $fullname = filter_var($_POST['fullname'], FILTER_SANITIZE_STRING);
                                //$fullname = str_replace("'", "''", $_POST['fullname']);
                                $phoneno = $_POST['phoneno'];
                                $phoneno = filter_var($phoneno, FILTER_SANITIZE_STRING);
                                $email = $_POST['email'];
                                $email = filter_var($email, FILTER_SANITIZE_STRING);


                                $pflength = strlen($pfno);
                                if ($pflength < 5) {

                                    $errorcode = "YES";
                                }

                                $staffDept = strtoupper($_SESSION['selectdept']);

                                if ($_POST['pfno'] == "" || $_POST['fullname'] == "" || $_POST['phoneno'] == "" || $_POST['email'] == "") {
                                    $errorpf = "All Fields are Required";
                                } else {
                                    if ($errorcode == "NO") {
                                        $password3 = rand(100000, 1000000);
                                        $password2 = md5($password3);
                                        $dept = $_SESSION['deptcode'];
                                        $sql = "SELECT staffid FROM users WHERE staffid = '$pfno'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $recexist = "Record Already Exist";
                                        } else {

                                            $sql2 = "INSERT INTO users(SchCode, password2, password3, full_name, phone, department, staffid, emailAdd, staffacddept, online_status, CourseLec)VALUES('$schcode', '$password2', '$password3', '$fullname', '$phoneno', '$staffDept', '$pfno', '$email', '$staffDept', 'Online', 'YES')";
                                            $result2 = $conn->query($sql2);

                                            //$sql3 = "INSERT INTO passwcheck(pfno, password)VALUES('$pfno', '0000')";
                                            //$result3 = $conn3->query($sql3);

                                            // Default Password school2024
                                            //$sql3 = "INSERT INTO stafflist(staffid, password2, fullname, deptcode, department, emailaddress, phoneno, online_status)VALUES('$pfno', 'bb350a95c1e13891431de484f8f08ecd', '$fullname', '$staffDept', '$deptname', '$email', '$phoneno', 'Online')";
                                            //$result3 = $conn6->query($sql3);

                                            $recsaved = "Record Saved with New Password: $password3";
                                        }
                                    } else {
                                        $errorpf = "Wrong File Number Format";
                                    }
                                }
                                $conn->close();
                            }

                            ?>
                            <div class="row">

                                <div class="col-lg-12">
                                    <div class="hr-line-dashed"></div>
                                    <form class="form-horizontal form-bordered" method="post">
                                        <div class="form-group">
                                            <label class="col-sm-2 control-label">Select
                                                Department:-</label>

                                            <div class="col-sm-8">
                                                <select class="form-control m-b" name="depart" required>
                                                    <option value="">Select Department</option>
                                                    <?php
                                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                                    if ($conn->connect_error) {
                                                        die("Connection failed: " . $conn->connect_error);
                                                    }


                                                    $dept = $_SESSION['deptcode'];


                                                    if ($cat_HOD == "YES") {
                                                        $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$dept'";
                                                    } elseif ($cat_Administrator == "YES" || $cat_Sub_Admin == "YES") {
                                                        $sql = "SELECT * FROM deptcoding ORDER BY DeptName";
                                                    }
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        // output data of each row
                                                        while ($row = $result->fetch_assoc()) {
                                                            $deptcode2 = strtolower($row["DeptCode"]);
                                                            $deptname2 = $row["DeptName"];
                                                            echo "<option value=$deptcode2>$deptname2</option>";
                                                        }
                                                    }
                                                    $conn->close();
                                                    ?>

                                                </select>

                                            </div>
                                            <div class="col-sm-2">
                                                <button type="submit" name="submitselect" class="btn btn-primary btn-sm">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                    <br><br>

                                    <?php
                                    if (isset($_POST["submitselect"])) {
                                        $selectdept = $_POST['depart'];
                                        $_SESSION['selectdept'] = $selectdept;
                                    } else {
                                        $selectdept = $_SESSION['selectdept'];
                                    }

                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }



                                    $sql = "SELECT * FROM deptcoding WHERE DeptCode = '$selectdept'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $deptname2 = $row["DeptName"];
                                        }
                                    }
                                    ?>
                                    <center><strong>
                                            <h4 style="color:#000">Staff Number in at least 5 character e.g. F0001</h4>
                                        </strong></center>
                                    <center><strong>
                                            <h3 style="color:#F00"><?php echo $recexist ?></h3>
                                        </strong></center>
                                    <center><strong>
                                            <h3 style="color:#F00"><?php echo $errorpf ?></h3>
                                        </strong></center>
                                    <center><strong>
                                            <h3 style="color:#00C"><?php echo $recsaved ?></h3>
                                        </strong></center>
                                    <form class="form-horizontal" method="post" action="create_user.php">
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">File Number:</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" style="color:#000000" name="pfno" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Full Name:</label>
                                            <div class="col-lg-6">
                                                <input type="text" class="form-control" style="color:#000000" name="fullname" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">Phone Number:</label>
                                            <div class="col-lg-6">
                                                <input type="number" class="form-control" style="color:#000000" name="phoneno" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label">email:</label>
                                            <div class="col-lg-6">
                                                <input type="email" class="form-control" style="color:#000000" name="email" required>
                                            </div>
                                        </div>



                                        <br>
                                        <div class="form-group">
                                            <label class="col-lg-4 control-label"></label>
                                            <div class="col-lg-6" style="text-align: right">
                                                <?php if ($cat_Sub_Admin == "YES" || $cat_Administrator == "YES") { ?>
                                                    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
                                                <?php } ?>
                                            </div>

                                        </div>
                                    </form>

                                    <h3><?php echo $deptname2 ?> Department</h3>
                                    <?php
                                    $sno = 0;
                                    $sql = "SELECT * FROM users WHERE staffacddept = '$selectdept' ORDER BY full_name";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        // output data of each row
                                    ?>

                                        <table class="table table-striped mb-none">
                                            <thead>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>PF Number</th>
                                                    <th>Name</th>
                                                    <th>Course Lecturer</th>
                                                    <th>Exam Officer</th>
                                                    <th>Ass. Exam Officer</th>
                                                    <?php if ($_SESSION['InstType'] == "University") { ?>
                                                        <th>100 Level Advise</th>
                                                        <th>200 Level Advise</th>
                                                        <th>300 Level Advise</th>
                                                        <th>400 Level Advise</th>
                                                        <th>500 Level Advise</th>
                                                        <th>Spill Over Level Adviser</th>
                                                        <th>Seminer Coordinator</th>
                                                        <th>PG Coordinator</th>
                                                        <th>SIWES Coordinator</th>
                                                    <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                        <th>NDI Level Advise</th>
                                                        <th>NDII Level Advise</th>
                                                        <th>HNDi Level Advise</th>
                                                        <th>HNDII Level Advise</th>
                                                        <th>Spill Over Level Adviser</th>
                                                        <th>Seminar Coordinator</th>

                                                        <th>SIWES Coordinator</th>
                                                    <?php } ?>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                <?php
                                                while ($row = $result->fetch_assoc()) {
                                                    $sno++;
                                                    $sn = $row["sn"];
                                                    $pfno = $row["staffid"];
                                                    $fullname = $row["full_name"];
                                                    $Examiner = $row["Examiner"];
                                                    $Ass_Examiner = $row["Ass_Examiner"];
                                                    $PG_Coord = $row["PG_Coord"];
                                                    $Seminer_Coord = $row["Seminer_Coord"];
                                                    $SIWES_Coord = $row["SIWES_Coord"];
                                                    $L100 = $row["L100"];
                                                    $L200 = $row["L200"];
                                                    $L300 = $row["L300"];
                                                    $L400 = $row["L400"];
                                                    $L500 = $row["L500"];
                                                    $spill_over = $row["spill_over"];
                                                    $CourseLec = $row["CourseLec"];

                                                    echo "<tr><td>$sno</td><td>$pfno</td><td>$fullname</td><td>$CourseLec</td><td>$Examiner</td><td>$Ass_Examiner</td><td>$L100</td><td>$L200</td><td>$L300</td><td>$L400</td>";

                                                    if ($_SESSION['InstType'] == "University") {
                                                        echo "<td>$L500</td><td>$spill_over</td><td>$Seminer_Coord</td><td>$PG_Coord</td><td>$SIWES_Coord</td>";
                                                    } elseif ($_SESSION['InstType'] == "Polytechnic") {
                                                        echo "<td>$spill_over</td><td>$Seminer_Coord</td><td>$SIWES_Coord</td>";
                                                    } else {
                                                    }


                                                    echo "<td>
										 	<form action='edit_users_prev.php' method='post'>
												  <input type='hidden' value=$sn name='sn'>
												  <input type='submit' name='submitstaff' class='btn btn-primary btn-xs' value='View'>
											 </form>
										 </td>";
                                                    echo "</tr>\n";
                                                }
                                                ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>PF Number</th>
                                                    <th>Name</th>
                                                    <th>Course Lecturer</th>
                                                    <th>Exam Officer</th>
                                                    <th>Ass. Exam Officer</th>
                                                    <?php if ($_SESSION['InstType'] == "University") { ?>
                                                        <th>100 Level Advise</th>
                                                        <th>200 Level Advise</th>
                                                        <th>300 Level Advise</th>
                                                        <th>400 Level Advise</th>
                                                        <th>500 Level Advise</th>
                                                        <th>Spill Over Level Adviser</th>
                                                        <th>Seminer Coordinator</th>
                                                        <th>PG Coordinator</th>
                                                        <th>SIWES Coordinator</th>
                                                    <?php  } elseif ($_SESSION['InstType'] == "Polytechnic") { ?>
                                                        <th>NDI Level Advise</th>
                                                        <th>NDII Level Advise</th>
                                                        <th>HNDi Level Advise</th>
                                                        <th>HNDII Level Advise</th>
                                                        <th>Spill Over Level Adviser</th>
                                                        <th>Seminar Coordinator</th>

                                                        <th>SIWES Coordinator</th>
                                                    <?php } ?>
                                                    <th>Action</th>
                                                </tr>
                                            </tfoot>
                                        </table>

                                    <?php

                                    } else {
                                    }
                                    $conn->close();

                                    ?>

                                </div>


                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>


</body>

</html>
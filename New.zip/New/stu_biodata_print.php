<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

?>

<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <!--Print Div-->
    <script type="text/javascript">
        function printme() {
            var print_div = document.getElementById("printablediv");
            var print_area = window.open();
            print_area.document.write(print_div.innerHTML);
            print_area.document.close();
            print_area.focus();
            print_area.print();
            print_area.close();
        }
    </script>
    <!--End Print Div-->
    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Profile</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Student Biodata
                            </li>
                            <li>
                                Graduted
                            </li>
                            <li class="active">
                                <strong>Print</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>
                <div class="wrapper wrapper-content">
                    <div class="row animated fadeInRight">
                        <div class="col-lg-12">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>Students' Biodata</h5>
                                    <div class="ibox-tools">
                                        <a class="collapse-link">
                                            <i class="fa fa-chevron-up"></i>
                                        </a>
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                            <i class="fa fa-wrench"></i>
                                        </a>
                                        <ul class="dropdown-menu dropdown-user">
                                            <li><a href="#">Config option 1</a>
                                            </li>
                                            <li><a href="#">Config option 2</a>
                                            </li>
                                        </ul>
                                        <a class="close-link">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="ibox-content" style="position: relative">

                                    <div class="table-responsive">
                                        <?php
                                        if (isset($_POST['view'])) {

                                            $id = $_POST["id"];
                                            $_SESSION['id'] = $id;


                                            $sql = "SELECT * FROM graduated WHERE id = '$id'";
                                            $result = $conn2->query($sql);

                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $fname = $row["firstname"];
                                                    $mname = $row["othername"];
                                                    $surname = $row["surname"];
                                                    $matricno = $row["regid"];
                                                    $studentid = $row["stdid"];
                                                    $jambno = $row["JAMB_RegNo"];
                                                    $school = $row["SchCode"];
                                                    $dept = $row["Deptcode"];
                                                    $cstudy = $row["cstudy"];
                                                    $coption = $row["coption"];
                                                    $degree = $row["degree"];
                                                    $phone = $row["Phone"];
                                                    $email = $row["email"];
                                                    $state = $row["StateOfOrigin"];
                                                    $lga = $row["lga"];
                                                    $tribe = $row["tribe"];
                                                    $yearentry = $row["session"];
                                                    $yeargrad = $row["yeargrad"];
                                                    $pbirth = $row["PlaceBirth"];
                                                    $dob = $row["dob"];
                                                    $gender = $row["sex"];
                                                    $mstatus = $row["marital"];
                                                    $pname = $row["next_rel"];
                                                    $paddress = $row["next_addr"];
                                                    $pemail = $row["next_email"];
                                                    $phoneno = $row["next_phone"];
                                                    $staddress = $row["ParmtAdress"];
                                                    $imgpath = $row["passp_path"];
                                                }
                                            }
                                            $imgpath = "https://eportal.futminna.edu.ng/accpt/biodata/" . $imgpath;


                                        ?>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <table width="100%">
                                                    <tr>
                                                        <td><a href="#"><img src="assets/images/futlogo.png" alt="Insert Logo Here" name="Insert_logo" width="80" height="80" id="Insert_logo" style="display:block;" />
                                                            </a></td>
                                                        <td>
                                                            <center>
                                                                <h3>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</h3>
                                                                <h3>(Registry Department - Academic Office)</h3>
                                                                <strong>GRADUATE'S BIODATA REGISTRATION</strong><br />
                                                                </h3>
                                                            </center>
                                                        </td>
                                                        <td><?php echo "<img src='$imgpath' class='img' width='110' height='110'/>" ?>
                                                        </td>
                                                    </tr>
                                                </table>

                                                <br>

                                                <table width="100%">
                                                    <colgroup>
                                                        <col style="width:45%">
                                                        <col style="width:45%">
                                                        <col style="width:10%">
                                                    </colgroup>
                                                    <tbody>
                                                        <tr>
                                                            <td><strong>First Name:</strong></td>
                                                            <td><?php echo strtoupper($fname); ?></td>
                                                            <td><strong>Middle Name:</strong></td>
                                                            <td><?php echo strtoupper($mname); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Surname:</strong></td>
                                                            <td><?php echo strtoupper($surname); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Matriculation Number:</strong></td>
                                                            <td><?php echo strtoupper($matricno); ?></td>
                                                            <td><strong>JAMB Reg. No.:</strong></td>
                                                            <td><?php echo strtoupper($jambno); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>School:</strong></td>
                                                            <td><?php echo strtoupper($school); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Department:</strong></td>
                                                            <td><?php echo strtoupper($dept); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Course of study:</strong></td>
                                                            <td><?php echo strtoupper($cstudy); ?></td>
                                                            <td><strong>Option (If any):</strong></td>
                                                            <td><?php echo strtoupper($coption); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Type of Degree:</strong></td>
                                                            <td><?php echo strtoupper($degree); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Phone No.:</strong></td>
                                                            <td><?php echo $phone; ?></td>
                                                            <td><strong>Email:</strong></td>
                                                            <td><?php echo $email; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>State of Origin:</strong></td>
                                                            <td><?php echo strtoupper($state); ?></td>
                                                            <td><strong>L.G.A.:</strong></td>
                                                            <td><?php echo strtoupper($lga); ?></td>
                                                            <td><strong>Tribe:</strong></td>
                                                            <td><?php echo strtoupper($tribe); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Year of Entry:</strong></td>
                                                            <td><?php echo $yearentry; ?></td>
                                                            <td><strong>Year of Graduation:</strong></td>
                                                            <td><?php echo $yeargrad; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Place of Birth:</strong></td>
                                                            <td><?php echo strtoupper($pbirth); ?></td>
                                                            <td><strong>Date of Birth:</strong></td>
                                                            <td><?php echo $dob; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Gender:</strong></td>
                                                            <td><?php echo strtoupper($gender); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Marital Staus:</strong></td>
                                                            <td><?php echo strtoupper($mstatus); ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Full name of Parent:</strong></td>
                                                            <td><?php echo strtoupper($pname); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td><strong>Email Address:</strong></td>
                                                            <td><?php echo $pemail; ?></td>
                                                            <td><strong>Phone No.:</strong></td>
                                                            <td><?php echo $phoneno; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table width="100%">
                                                    <tr>
                                                        <td><strong>Contact Address:</strong></td>
                                                        <td><?php echo strtoupper($paddress); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td><strong>Student Permanent Home Address:</strong></td>
                                                        <td><?php echo strtoupper($staddress); ?></td>
                                                    </tr>
                                                </table>
                                                <br />
                                                (For Official Use Only)
                                                <br />
                                                <br />
                                                Graduate Signature: _________________________________________________
                                                <br />
                                                <br />
                                                Date of Senate approval of Result: ______________________________________
                                                <br />
                                                <br />
                                                NB- Please do not attempt to fill this form for your friend or others.

                                                <br />
                                                <div style="text-align: right">
                                                    <input type="button" class='btn btn-info btn-sm' value="Print" onclick="printme()">
                                                </div>


                                            </form>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div id="printablediv" style="width: 100%; height: 200px;" hidden="hidden">
            <?php
            $id = $_SESSION['id'];
            $sql = "SELECT * FROM graduated WHERE id = '$id'";
            $result = $conn2->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $fname = $row["firstname"];
                    $mname = $row["othername"];
                    $surname = $row["surname"];
                    $matricno = $row["regid"];
                    $studentid = $row["stdid"];
                    $jambno = $row["JAMB_RegNo"];
                    $school = $row["SchCode"];
                    $dept = $row["Deptcode"];
                    $cstudy = $row["cstudy"];
                    $coption = $row["coption"];
                    $degree = $row["degree"];
                    $phone = $row["Phone"];
                    $email = $row["email"];
                    $state = $row["StateOfOrigin"];
                    $lga = $row["lga"];
                    $tribe = $row["tribe"];
                    $yearentry = $row["session"];
                    $yeargrad = $row["yeargrad"];
                    $pbirth = $row["PlaceBirth"];
                    $dob = $row["dob"];
                    $gender = $row["sex"];
                    $mstatus = $row["marital"];
                    $pname = $row["next_rel"];
                    $paddress = $row["next_addr"];
                    $pemail = $row["next_email"];
                    $phoneno = $row["next_phone"];
                    $staddress = $row["ParmtAdress"];
                    $imgpath = $row["passp_path"];
                }
            }
            $imgpath = "https://eportal.futminna.edu.ng/accpt/biodata/" . $imgpath;
            ?>

            <table width="100%">
                <tr>
                    <td><a href="#"><img src="assets/images/futlogo.png" alt="Insert Logo Here" name="Insert_logo" width="80" height="80" id="Insert_logo" style="display:block;" />
                        </a></td>
                    <td>
                        <center>
                            <h3>FEDERAL UNIVERSITY OF TECHNOLOGY, MINNA</h3>
                            <h3>(Registry Department - Academic Office)</h3>
                            <strong>GRADUATE'S BIODATA REGISTRATION</strong><br />
                            </h3>
                        </center>
                    </td>
                    <td><?php echo "<img src='$imgpath' class='img' width='110' height='110'/>" ?></td>
                </tr>
            </table>

            <br>

            <table width="100%">
                <colgroup>
                    <col style="width:45%">
                    <col style="width:45%">
                    <col style="width:10%">
                </colgroup>
                <tbody>
                    <tr>
                        <td><strong>First Name:</strong></td>
                        <td><?php echo strtoupper($fname); ?></td>
                        <td><strong>Middle Name:</strong></td>
                        <td><?php echo strtoupper($mname); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Surname:</strong></td>
                        <td><?php echo strtoupper($surname); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Matriculation Number:</strong></td>
                        <td><?php echo strtoupper($matricno); ?></td>
                        <td><strong>JAMB Reg. No.:</strong></td>
                        <td><?php echo strtoupper($jambno); ?></td>
                    </tr>
                    <tr>
                        <td><strong>School:</strong></td>
                        <td><?php echo strtoupper($school); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Department:</strong></td>
                        <td><?php echo strtoupper($dept); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Course of study:</strong></td>
                        <td><?php echo strtoupper($cstudy); ?></td>
                        <td><strong>Option (If any):</strong></td>
                        <td><?php echo strtoupper($coption); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Type of Degree:</strong></td>
                        <td><?php echo strtoupper($degree); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Phone No.:</strong></td>
                        <td><?php echo $phone; ?></td>
                        <td><strong>Email:</strong></td>
                        <td><?php echo $email; ?></td>
                    </tr>
                    <tr>
                        <td><strong>State of Origin:</strong></td>
                        <td><?php echo strtoupper($state); ?></td>
                        <td><strong>L.G.A.:</strong></td>
                        <td><?php echo strtoupper($lga); ?></td>
                        <td><strong>Tribe:</strong></td>
                        <td><?php echo strtoupper($tribe); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Year of Entry:</strong></td>
                        <td><?php echo $yearentry; ?></td>
                        <td><strong>Year of Graduation:</strong></td>
                        <td><?php echo $yeargrad; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Place of Birth:</strong></td>
                        <td><?php echo strtoupper($pbirth); ?></td>
                        <td><strong>Date of Birth:</strong></td>
                        <td><?php echo $dob; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Gender:</strong></td>
                        <td><?php echo strtoupper($gender); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Marital Staus:</strong></td>
                        <td><?php echo strtoupper($mstatus); ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Full name of Parent:</strong></td>
                        <td><?php echo strtoupper($pname); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Email Address:</strong></td>
                        <td><?php echo $pemail; ?></td>
                        <td><strong>Phone No.:</strong></td>
                        <td><?php echo $phoneno; ?></td>
                    </tr>
                </tbody>
            </table>
            <table>
                <tr>
                    <td><strong>Contact Address:</strong></td>
                    <td><?php echo strtoupper($paddress); ?></td>
                </tr>
                <tr>
                    <td><strong>Student Permanent Home Address:</strong></td>
                    <td><?php echo strtoupper($staddress); ?></td>
                </tr>
            </table>
            <br />
            (For Official Use Only)
            <br />
            <br />
            Graduate Signature: _________________________________________________
            <br />
            <br />
            Date of Senate approval of Result: ______________________________________
            <br />
            <br />
            NB- Please do not attempt to fill this form for your friend or others.

        </div>

        <div class="footer">
            <?php
            include_once 'includes/footer2.php';
            ?>
        </div>

        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
</body>

</html>
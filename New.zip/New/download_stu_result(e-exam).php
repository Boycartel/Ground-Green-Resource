<?php
require_once 'includes/db_connect.php';
require_once 'includes/check_validity.php';

if ($_SESSION['download_stu_result(e-exam)'] == false) {
    header('Location: Home_Staff.php');
}
?>

<!doctype html>
<html class="fixed">

<head>

    <?php
    include_once 'includes/header_top.php';
    ?>

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
    <link rel="stylesheet" href="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
    <link rel="stylesheet" href="assets/vendor/morris/morris.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="assets/vendor/modernizr/modernizr.js"></script>

    <script src="assets/javascripts/tableToExcel_R.js"></script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
        window.history.forward();

        function noBack() {
            window.history.forward();
        }
    </script>

    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>

<body>
    <section class="body">

        <!-- start: header -->
        <?php

        include_once 'includes/header2_staff.php';

        ?>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <?php
            include_once 'includes/aside_menu_staff.php';

            ?>
            <!-- end: sidebar -->

            <section role="main" class="content-body">
                <header class="page-header" style="background-color: <?php echo $_SESSION['sch_color'] ?>;">
                    <h2>Download Students Result(e-exam)</h2>

                    <div class="right-wrapper pull-right" style="padding-right: 2em">
                        <ol class="breadcrumbs">
                            <li>
                                <a href="index.html">
                                    <i class="fa fa-download"></i>
                                </a>
                            </li>
                            <li><span>Download</span></li>
                            <li><span>Download Students Result(e-exam)</span></li>
                        </ol>


                    </div>
                </header>

                <!-- start: page -->
                <div class="row">
                    <form class="form-horizontal" method="post">
                        <div class="col-lg-1">

                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="control-label col-lg-4" for="content">Select Course:</label>
                                <div class="col-lg-8">
                                    <select class="country form-control" style="color:#000000" name="course">
                                        <option value="SelectItem">Select Item</option>
                                        <?php
                                        $dept = $_SESSION['deptcode'];
                                        if ($cat == "PGExam" || $cat == "Examiner" || $cat == "ExamLAdvice") {
                                            $sql = "SELECT * FROM gencoursesupload WHERE Department = '$dept' ORDER BY C_codding";
                                        } else {
                                            $sql = "SELECT * FROM gencoursesupload ORDER BY C_codding";
                                        }

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            // output data of each row
                                            while ($row = $result->fetch_assoc()) {
                                                $coursecode = $row["C_codding"];
                                                $coursetitle = $row["C_title"];
                                                echo "<option value=$coursecode>$coursecode $coursetitle</option>";
                                            }
                                        }
                                        ?>

                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">

                                <label class="control-label col-lg-3" for="regid">Session:</label>
                                <div class="col-lg-8">
                                    <select name="getsession" class="form-control" style="color:#000000" id="getsession">
                                        <option value="<?php echo $_SESSION['corntsession'] ?>">
                                            <?php echo $_SESSION['corntsession'] ?></option>
                                        <?php
                                        $iniyear = 2016;
                                        $finalyear = substr($_SESSION['corntsession'], 5);

                                        while ($iniyear <= $finalyear) {
                                            $addyear = $iniyear + 1;

                                            echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                            $iniyear++;
                                        }

                                        //$conn->close();
                                        ?>

                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-9">
                                    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-1">

                        </div>
                    </form>
                </div>
                <hr class="separator" />
                <div class="row">

                    <?php if (isset($_POST["submit"])) { ?>
                        <?php
                        $course = $_POST['course'];
                        $session = $_POST['getsession'];

                        $sql2 = "SELECT * FROM gencoursesupload WHERE C_codding = '$course'";
                        $result2 = $conn->query($sql2);

                        if ($result2->num_rows > 0) {
                            while ($row = $result2->fetch_assoc()) {
                                $cursedept = strtolower($row["Department"]);
                                $coursetitle = $row["C_title"];
                            }
                        }
                        ?>
                        <div class="col-lg-12  col-md-12">
                            <div class="col-lg-1">

                            </div>
                            <div class="col-lg-10">
                                <section class="panel panel-success">
                                    <header class="panel-heading">
                                        <div class="panel-actions">
                                            <a href="#" class="fa fa-caret-down"></a>
                                            <a href="#" class="fa fa-times"></a>
                                        </div>

                                        <h2 class="panel-title">Students Result(e-exam)</h2>
                                    </header>
                                    <div class="panel-body">
                                        <?php
                                        set_time_limit(500);
                                        $GetTitle = $coursetitle;
                                        $sno = 0;
                                        ?>
                                        <table id="myTable" class="table mb-none" style="font-size:14px" summary="" rules="groups" frame="hsides" border="2">
                                            <caption><?php echo $GetTitle ?></caption>
                                            <colgroup align="center"></colgroup>
                                            <colgroup align="left"></colgroup>
                                            <colgroup span="2"></colgroup>
                                            <colgroup span="3" align="center"></colgroup>
                                            <thead>
                                                <tr>

                                                    <th>SNo</th>
                                                    <th>Matric No</th>
                                                    <th>CA</th>
                                                    <th>Exam</th>
                                                    <th>Total</th>
                                                    <th>Grade</th>
                                                    <th>Corse Code</th>
                                                    <th>Session</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if ($session == "2017/2018" || $session == "2018/2019") {
                                                    $sql = "SELECT matno, ccode, ctitle, unit, Semester, ca, exam, session_regist FROM e_exam_results WHERE ccode= '$course' AND session_regist= '$session' ORDER BY matno";
                                                } else {
                                                    $gettable = "e_exam_results_" . str_replace("/", "_", $session);
                                                    $sql = "SELECT matno, ccode, ctitle, unit, Semester, ca, exam, session_regist FROM " . $gettable . " WHERE ccode= '$course' AND session_regist= '$session' ORDER BY matno";
                                                }

                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $sno++;
                                                        $total = $row['ca'] + $row['exam'];
                                                        if ($row['ca'] + $row['exam'] >= 70) {
                                                            $grade = "A";
                                                        } elseif ($row['ca'] + $row['exam'] >= 60) {
                                                            $grade = "B";
                                                        } elseif ($row['ca'] + $row['exam'] >= 50) {
                                                            $grade = "C";
                                                        } elseif ($row['ca'] + $row['exam'] >= 45) {
                                                            $grade = "D";
                                                        } elseif ($row['ca'] + $row['exam'] >= 40) {
                                                            $grade = "E";
                                                        } elseif ($row['ca'] + $row['exam'] <= 39.95) {
                                                            $grade = "F";
                                                        }

                                                        echo "<tr><td>$sno</td><td>{$row['matno']}</td><td>{$row['ca']}</td><td>{$row['exam']}</td><td>$total</td><td>$grade</td><td>$course</td><td>{$row['session_regist']}</td></tr>\n";
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <br>
                                        <div style="text-align: right">
                                            <a href="#" id="test" onClick="javascript:fnExcelReport();" class="btn btn-primary">Download</a>
                                        </div>


                                    </div>

                                </section>


                            </div>
                            <div class="col-lg-1">

                            </div>


                        </div>



                    <?php } ?>
                </div>
                <!-- end: page -->
            </section>
        </div>


    </section>


    <!-- Vendor -->
    <script src="assets/vendor/jquery/jquery.js"></script>
    <script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
    <script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
    <script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
    <script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

    <!-- Specific Page Vendor -->
    <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
    <script src="assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js"></script>
    <script src="assets/vendor/jquery-appear/jquery.appear.js"></script>
    <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
    <script src="assets/vendor/jquery-easypiechart/jquery.easypiechart.js"></script>
    <script src="assets/vendor/flot/jquery.flot.js"></script>
    <script src="assets/vendor/flot-tooltip/jquery.flot.tooltip.js"></script>
    <script src="assets/vendor/flot/jquery.flot.pie.js"></script>
    <script src="assets/vendor/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendor/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendor/jquery-sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/raphael/raphael.js"></script>
    <script src="assets/vendor/morris/morris.js"></script>
    <script src="assets/vendor/gauge/gauge.js"></script>
    <script src="assets/vendor/snap-svg/snap.svg.js"></script>
    <script src="assets/vendor/liquid-meter/liquid.meter.js"></script>
    <script src="assets/vendor/jqvmap/jquery.vmap.js"></script>
    <script src="assets/vendor/jqvmap/data/jquery.vmap.sampledata.js"></script>
    <script src="assets/vendor/jqvmap/maps/jquery.vmap.world.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.africa.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.asia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.australia.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.europe.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.north-america.js"></script>
    <script src="assets/vendor/jqvmap/maps/continents/jquery.vmap.south-america.js"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="assets/javascripts/theme.js"></script>

    <!-- Theme Custom -->
    <script src="assets/javascripts/theme.custom.js"></script>

    <!-- Theme Initialization Files -->
    <script src="assets/javascripts/theme.init.js"></script>


    <!-- Examples -->
    <script src="assets/javascripts/dashboard/examples.dashboard.js"></script>

</body>

</html>
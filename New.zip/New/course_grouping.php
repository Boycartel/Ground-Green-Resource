<?php
require_once 'includes/db_connect2.php';

require_once 'includes/check_validity.php';

if ($_SESSION['course_setup'] == false) {
    header('Location: home_staff.php');
}

?>


<!doctype html>
<html class="fixed">

<head>

    <?php include_once 'includes/header_top.php'; ?>
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
    <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js">
    </script>

    <!--To Prevent Backward-->
    <script type="text/javascript">
    window.history.forward();

    function noBack() {
        window.history.forward();
    }
    </script>


    <?php
    $autologoutURL = "";
    include_once 'includes/autologout.php';
    ?>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <?php include_once 'includes/aside_menu_staff.php'; ?>
        </nav>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <?php include_once 'includes/header2_staff.php'; ?>
                </nav>
            </div>
            <div class="wrapper wrapper-content">


                <div class="row wrapper border-bottom white-bg page-heading">
                    <div class="col-lg-10">
                        <h2>Course Grouping</h2>
                        <ol class="breadcrumb">
                            <li>
                                <a href="home_staff.php">Home</a>
                            </li>
                            <li>
                                Settings
                            </li>

                            <li class="active">
                                <strong>Course Grouping</strong>
                            </li>
                        </ol>


                    </div>
                    <div class="col-lg-2">

                    </div>
                </div>

                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="panel panel-<?php echo $_SESSION['palheadcolor'] ?>">
                        <div class="panel-heading">
                            Course Grouping
                        </div>
                        <div class="panel-body">
                            <?php
                            unset($deptoptionCode);
                            unset($deptoptionTitle);
                            $deptoptCount = 0;
                            $dept = $_SESSION['deptcode'];
                            $deptoption = $_SESSION['deptoption'];
                            $deptname = $_SESSION["deptname"];
                            $schcode = $_SESSION['schcode'];
                            $DegType = $_SESSION['DegType'];
                            $GetTheSession = $_SESSION['resultsession'];



                            $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $yesCurri = "NO";
                            $_SESSION['yesCurri'] = "NO";
                            $sql = "SELECT * FROM deptcoding  WHERE DeptCode = '$dept'";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $yesCurri = $row["curriculum"];
                                    $_SESSION['yesCurri'] = $yesCurri;
                                }
                            }

                            $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept' ORDER BY Opt_Code";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $deptoptCount++;
                                    $deptoptionCode[$deptoptCount] = $row["Opt_Code"];
                                    $deptoptionTitle[$deptoptCount] = $row["Opt_Title"];
                                }
                            }
                            $conn->close();
                            if (isset($_POST["submit"])) {
                                $getopt = "XXXX";

                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }


                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                $CountCourseArray = $_SESSION["CountCourseArray"];
                                $selCourseArray = $_SESSION["selCourseArray"];

                                $getgroup = $_SESSION["getgroup"];

                                if ($deptoption == "YES") {
                                    $getopt = $_SESSION["getopt"];
                                }

                                $getinisession = $_POST["getinisession"];

                                $iniyear = substr($getinisession, 0, 4);
                                $finalyear = substr($GetTheSession, 6, 4);

                                if ($_SESSION['curricul'] == "YES") {
                                    $curri = strtolower($_SESSION['curri']);
                                    if ($curri == "OLD") {
                                        $curri2 = "";
                                    } else {
                                        $curri2 = "_" . $curri;
                                    }
                                } else {
                                    $curri = "OLD";
                                    $curri2 = "";
                                }



                                if ($CountCourseArray > 2) {
                                    if (!empty($_POST["getoutstanding"])) {
                                        foreach ($_POST['getoutstanding'] as $getoutstand) {
                                            $sql2 = "INSERT INTO grouping_couses_outs(GroupCode, OptCode, DeptCode, outsCourse, curriculum)VALUES('$getgroup', '$getopt', '$dept', '$getoutstand', '$curri')";
                                            $result2 = $conn->query($sql2);
                                        }
                                        //print "You selected $subject<br/>";
                                    }
                                    $getoutstanding = "Multi";
                                } else {
                                    $getoutstanding = $_POST["getoutstanding"];
                                }

                                for ($i = 1; $i <= $CountCourseArray; $i++) {
                                    $ccode = $selCourseArray[$i];
                                    $sql = "SELECT * FROM gencourses" . $curri2 . " WHERE C_codding = '$ccode'";
                                    $result = $conn_stu->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            $Cunit = $row["credit"];
                                            $Level1 = $row["Level1"];
                                        }
                                    }
                                    $sql2 = "INSERT INTO grouping_couses(GroupCode, RegCourse, CUnit, OptCode, DeptCode, outsCourse, curriculum, inisession)VALUES('$getgroup', '$ccode', '$Cunit', '$getopt', '$dept', '$getoutstanding', '$curri', '$getinisession')";
                                    $result2 = $conn->query($sql2);

                                    if ($deptoption == "YES") {
                                        if ($Level1 > 200) {
                                            $sql3 = "UPDATE gencourses" . $curri2 . " SET Group" . $getopt . "='$getgroup', Core_" . $getopt . "='YES', CoreDE200_" . $getopt . "='YES', CoreDE300_" . $getopt . "='YES' WHERE C_codding = '$ccode'";
                                        } elseif ($Level1 > 100) {
                                            $sql3 = "UPDATE gencourses" . $curri2 . " SET Group" . $getopt . "='$getgroup', Core_" . $getopt . "='YES', CoreDE200_" . $getopt . "='YES' WHERE C_codding = '$ccode'";
                                        } else {
                                            $sql3 = "UPDATE gencourses" . $curri2 . " SET Group" . $getopt . "='$getgroup', Core_" . $getopt . "='YES' WHERE C_codding = '$ccode'";
                                        }
                                        $result3 = $conn_stu->query($sql3);


                                        for ($j = $iniyear; $j <= $finalyear; $j++) {
                                            $StuCurSess = $j . "_" . ($j + 1);
                                            $deptcorreg = "correg_" . $StuCurSess;
                                            $sql4 = "UPDATE " . $deptcorreg . " SET Grouping2 ='$getgroup' WHERE CCode = '$ccode' AND deptOption = '$getopt' AND curriculum = '$curri'";
                                            $result4 = $conn_stu->query($sql4);
                                        }
                                    } else {
                                        if ($Level1 > 200) {
                                            $sql3 = "UPDATE gencourses" . $curri2 . " SET Grouping2 ='$getgroup', Relevant ='YES', Core ='YES', CoreDE200 ='YES', CoreDE300 ='YES' WHERE C_codding = '$ccode'";
                                        } elseif ($Level1 > 100) {
                                            $sql3 = "UPDATE gencourses" . $curri2 . " SET Grouping2 ='$getgroup', Relevant ='YES', Core ='YES', CoreDE200 ='YES' WHERE C_codding = '$ccode'";
                                        } else {
                                            $sql3 = "UPDATE gencourses" . $curri2 . " SET Grouping2 ='$getgroup', Relevant ='YES', Core ='YES' WHERE C_codding = '$ccode'";
                                        }
                                        $result3 = $conn_stu->query($sql3);

                                        for ($j = $iniyear; $j <= $finalyear; $j++) {
                                            $StuCurSess = $j . "_" . ($j + 1);
                                            $deptcorreg = "correg_" . $StuCurSess;
                                            $sql4 = "UPDATE " . $deptcorreg . " SET Grouping2 ='$getgroup' WHERE CCode = '$ccode' AND deptOption = 'NOP' AND curriculum = '$curri'";
                                            $result4 = $conn_stu->query($sql4);
                                        }
                                    }
                                }
                                $conn->close();
                                $conn_stu->close();
                            }
                            if (isset($_POST["confyes"])) {
                                $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                if ($conn->connect_error) {
                                    die("Connection failed: " . $conn->connect_error);
                                }

                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                if ($conn_stu->connect_error) {
                                    die("Connection failed: " . $conn_stu->connect_error);
                                }

                                unset($CourseGrpDel);
                                $CountCourseGrpDel = 0;
                                $DelGroup = $_POST["DelGroup"];


                                if ($_SESSION['curricul'] == "YES") {
                                    $curri = strtolower($_SESSION['curri']);
                                    if ($curri == "OLD") {
                                        $curri2 = "";
                                    } else {
                                        $curri2 = "_" . $curri;
                                    }
                                } else {
                                    $curri = "OLD";
                                    $curri2 = "";
                                }


                                if ($deptoption == "YES") {
                                    $DelOptGroup = $_POST["DelOptGroup"];
                                    $sql = "SELECT * FROM grouping_couses WHERE DeptCode = '$dept' AND GroupCode ='$DelGroup' AND OptCode = '$DelOptGroup' AND curriculum = '$curri'";
                                } else {
                                    $sql = "SELECT * FROM grouping_couses WHERE DeptCode = '$dept' AND GroupCode ='$DelGroup' AND curriculum = '$curri'";
                                }
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $CountCourseGrpDel++;
                                        $CourseGrpDel[$CountCourseGrpDel] = $row["RegCourse"];
                                        $getinisession = $row["inisession"];
                                    }
                                }

                                $GetTheSession = $_SESSION['resultsession'];

                                $iniyear = substr($getinisession, 0, 4);
                                $finalyear = substr($GetTheSession, 6, 4);

                                if ($deptoption == "YES") {
                                    $sql = "DELETE FROM grouping_couses WHERE  GroupCode ='$DelGroup' AND DeptCode = '$dept' AND OptCode = '$DelOptGroup' AND curriculum = '$curri'";
                                } else {
                                    $sql = "DELETE FROM grouping_couses WHERE GroupCode ='$DelGroup' AND DeptCode = '$dept' AND curriculum = '$curri'";
                                }
                                $result = $conn->query($sql);

                                if ($deptoption == "YES") {
                                    $sql = "DELETE FROM grouping_couses_outs WHERE GroupCode ='$DelGroup' AND DeptCode = '$dept' AND OptCode = '$DelOptGroup' AND curriculum = '$curri'";
                                } else {
                                    $sql = "DELETE FROM grouping_couses_outs WHERE GroupCode ='$DelGroup' AND DeptCode = '$dept' AND curriculum = '$curri'";
                                }
                                $result = $conn->query($sql);

                                for ($i = 1; $i <= $CountCourseGrpDel; $i++) {
                                    $ccode = $CourseGrpDel[$i];
                                    if ($deptoption == "YES") {
                                        $sql3 = "UPDATE gencourses" . $curri2 . " SET Group" . $DelOptGroup . "='NO' WHERE C_codding = '$ccode'";
                                        $result3 = $conn_stu->query($sql3);

                                        for ($j = $iniyear; $j <= $finalyear; $j++) {
                                            $StuCurSess = $j . "_" . ($j + 1);
                                            $deptcorreg = "correg_" . $StuCurSess;
                                            $sql4 = "UPDATE " . $deptcorreg . " SET Grouping2 ='NO' WHERE CCode = '$ccode' AND deptOption = '$getopt' AND curriculum = '$curri'";
                                            $result4 = $conn_stu->query($sql4);
                                        }
                                    } else {
                                        $sql3 = "UPDATE gencourses" . $curri2 . " SET Grouping2 ='NO' WHERE C_codding = '$ccode'";
                                        $result3 = $conn_stu->query($sql3);

                                        for ($j = $iniyear; $j <= $finalyear; $j++) {
                                            $StuCurSess = $j . "_" . ($j + 1);
                                            $deptcorreg = "correg_" . $StuCurSess;
                                            $sql4 = "UPDATE " . $deptcorreg . " SET Grouping2 ='NO' WHERE CCode = '$ccode' AND curriculum = '$curri'";
                                            $result4 = $conn_stu->query($sql4);
                                        }
                                    }
                                }

                                $conn->close();
                                $conn_stu->close();
                            }
                            ?>

                            <!-- start: page -->

                            <div class="row">

                                <?php if ($_SESSION['yesCurri'] == "YES") { ?>
                                <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                    ?>

                                <?php if (isset($_POST["submitcurri"]) || isset($_POST["view"]) || isset($_POST["delete"]) || isset($_POST["confyes"]) || isset($_POST["submit"])) { ?>
                                <?php
                                        if (isset($_POST["submitcurri"])) {
                                            $curri = strtolower($_POST["curri"]);
                                            $_SESSION['curri'] = $curri;
                                        } else {
                                            $curri = $_SESSION['curri'];
                                        }



                                        if ($curri == "OLD") {
                                            $curri2 = "";
                                        } else {
                                            $curri2 = "_" . $curri;
                                        }
                                        $sql = "SELECT * FROM dept_curriculum WHERE curri_Code = '$curri' AND deptcode = '$dept'";
                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $curriname2 = $row["curri_Title"];
                                            }
                                        }
                                        ?>
                                <h2 style="padding-left: 2em;"><?php echo $curriname2 ?></h2>

                                <div class="row" style="padding-left: 3em;">
                                    <table>
                                        <thead style='text-align:center'>
                                            <tr style='border: 1px solid #ddd'>
                                                <th style='padding-right: 2em'>Course Code </th>
                                                <th style='padding-right: 2em'>--</th>
                                                <th style='padding-right: 2em'> Group Code</th>
                                                <th style='padding-right: 2em'>--</th>
                                                <th style='padding-right: 2em'> Outstanding Course</th>
                                                <th style='padding-right: 2em'>--</th>
                                                <?php if ($deptoption == "YES") { ?>
                                                <th style='padding-right: 2em'> Department Option</th>
                                                <th style='padding-right: 2em'>--</th>
                                                <?php } ?>
                                                <th style='padding-right: 2em'> Initial Session</th>
                                                <th style='padding-right: 2em'>--</th>
                                                <th>Action</th>
                                            </tr>

                                        </thead>
                                        <tbody>
                                            <?php
                                                    $sql = "SELECT * FROM grouping_couses WHERE DeptCode = '$dept' AND curriculum = '$curri' ORDER BY GroupCode";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $id = $row["SNo"];
                                                            $CtCode = $row["RegCourse"];
                                                            $GroupCode = $row["GroupCode"];
                                                            $outsCourse = $row["outsCourse"];
                                                            $getOpt = $row["OptCode"];
                                                            if ($outsCourse == "Multi") {
                                                                $sql2 = "SELECT * FROM grouping_couses_outs WHERE GroupCode = '$GroupCode' AND OptCode = '$getOpt' AND DeptCode = '$dept' AND curriculum = '$curri'";
                                                                $result2 = $conn->query($sql2);
                                                                $outsCourse = "";
                                                                if ($result2->num_rows > 0) {
                                                                    while ($row2 = $result2->fetch_assoc()) {
                                                                        $outsCourse = $outsCourse . ", " . $row2["outsCourse"];
                                                                    }
                                                                }
                                                            }
                                                            $inisession = $row["inisession"];
                                                            echo "<tr style='border: 1px solid #ddd'>";
                                                            echo "<td style='padding-right: 2em'>$CtCode </td><td style='padding-right: 2em'>--</td><td style='padding-right: 2em'> $GroupCode</td><td style='padding-right: 2em'>--</td><td style='padding-right: 2em'> $outsCourse</td><td style='padding-right: 2em'>--</td>";
                                                            if ($deptoption == "YES") {

                                                                echo "<td style='padding-right: 2em'> $getOpt</td><td style='padding-right: 2em'>--</td>";
                                                            }
                                                            echo "<td style='padding-right: 2em'>$inisession </td><td style='padding-right: 2em'>--</td>";
                                                            echo "<td>
                                                <form class='form-horizontal form-bordered' method='post'>
                                                
                                                    <input type='hidden' value='$id' name='id'>
                                                    
                                                    <input type='submit' name='delete' class='btn btn-danger btn-xs' value='Delete'>
                                                </form>
                                                </td>";
                                                            echo "</tr>";
                                                        }
                                                    }

                                                    ?>
                                        </tbody>
                                    </table>
                                    <br><br>
                                </div>
                                <div class="row" style="padding-left: 3em;">
                                    <div class="col-lg-4">
                                        <div class="row">
                                            <?php
                                                    if (isset($_POST["delete"])) {

                                                        $id = $_POST["id"];
                                                        $sql = "SELECT * FROM grouping_couses WHERE SNo ='$id'";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $DelGroup = $row["GroupCode"];
                                                                if ($deptoption == "YES") {
                                                                    $DOpt = $row["OptCode"];
                                                                }
                                                            }
                                                        }

                                                    ?>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <div class="row">
                                                    <h2 style="color: blue">
                                                        <?php
                                                                    if ($deptoption == "YES") {
                                                                        echo "Confirm Deleting Group " . $DelGroup . " for " . $DOpt;
                                                                    } else {
                                                                        echo "Confirm Deleting Group " . $DelGroup;
                                                                    }

                                                                    ?> ?
                                                    </h2>
                                                    <input type='hidden' id='DelGroup' name='DelGroup'
                                                        value='<?php echo $DelGroup ?>' />
                                                    <?php if ($deptoption == "YES") { ?>
                                                    <input type='hidden' id='DelOptGroup' name='DelOptGroup'
                                                        value='<?php echo $DOpt ?>' />
                                                    <?php } ?>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <button type="submit" name="confno"
                                                            class="btn btn-primary btn-sm">NO</button>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <button type="submit" name="confyes"
                                                            class="btn btn-primary btn-sm">YES</button>
                                                    </div>

                                                </div>
                                            </form>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" style="padding-left: 3em;">
                                    <div class="col-lg-4">
                                        <div class="row">
                                            <?php
                                                    if (isset($_POST["view"])) {
                                                        $GroupExist = false;
                                                        $getgroup = $_POST["getgroup"];
                                                        if ($deptoption == "YES") {
                                                            $getopt = strtoupper($_POST["getopt"]);
                                                            $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept' AND Opt_Code = '$getopt' ";
                                                            $result = $conn->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    $optname = $row["Opt_Title"];
                                                                }
                                                            }
                                                        }
                                                        if ($deptoption == "YES") {
                                                            $sql = "SELECT * FROM grouping_couses WHERE DeptCode = '$dept' AND GroupCode ='$getgroup' AND OptCode ='$getopt' AND curriculum = '$curri'";
                                                        } else {
                                                            $sql = "SELECT * FROM grouping_couses WHERE DeptCode = '$dept' AND GroupCode ='$getgroup' AND curriculum = '$curri'";
                                                        }
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $GroupExist = true;
                                                            }
                                                        }
                                                        unset($selCourseArray);
                                                        $CountCourseArray = 0;
                                                        $ccode2 = "";
                                                        $CGroup = "";
                                                        $IsGroup = false;

                                                        if (!empty($_POST["chosen1"])) {

                                                            foreach ($_POST["chosen1"] as $key => $value) {
                                                                $CountCourseArray++;
                                                                $ccode = $_POST["ccode"][$key];
                                                                $selCourseArray[$CountCourseArray] = $ccode;
                                                                $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                                $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                                if ($conn_stu->connect_error) {
                                                                    die("Connection failed: " . $conn_stu->connect_error);
                                                                }
                                                                $sql = "SELECT * FROM gencourses" . $curri2 . " WHERE C_codding = '$ccode'";
                                                                $result = $conn_stu->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        if ($deptoption == "YES") {
                                                                            $CGroup = $row["Group" . $getopt];
                                                                        } else {
                                                                            $CGroup = $row["Grouping2"];
                                                                        }
                                                                    }
                                                                }
                                                                if ($CGroup == "NO") {
                                                                    $ccode2 = $ccode2 . $_POST["ccode"][$key] . "<br>";
                                                                } else {
                                                                    $IsGroup = true;
                                                                    $ccode2 = $ccode2 . $_POST["ccode"][$key] . "(" . $CGroup . ")<br>";
                                                                }
                                                            }
                                                            $_SESSION["CountCourseArray"] = $CountCourseArray;
                                                            $_SESSION["selCourseArray"] = $selCourseArray;
                                                            $_SESSION["getgroup"] = $getgroup;
                                                            if ($deptoption == "YES") {
                                                                $_SESSION["getopt"] = $getopt;
                                                            }

                                                    ?>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <div class="row">
                                                    <label class="control-label col-lg-6" style="text-align: left">Group
                                                        :-</label>
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left"><?php echo $getgroup ?></label>
                                                </div>
                                                <?php if ($deptoption == "YES") { ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left">Department Option :-</label>
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left"><?php echo $optname ?></label>
                                                </div>
                                                <?php } ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left">Courses
                                                        :-</label>
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left"><?php echo $ccode2 ?></label>
                                                    <br>
                                                </div>
                                                <div class="row">
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left">Select
                                                        Outstanding Course(s) :-</label>
                                                    <div class="col-lg-6">
                                                        <?php if ($CountCourseArray > 2) { ?>
                                                        <!-- Multiple Select -->
                                                        <select id="getoutstanding" name="getoutstanding[]"
                                                            placeholder="Select Courses(max of 3)" multiple required>
                                                            <?php
                                                                                for ($i = 1; $i <= $CountCourseArray; $i++) {
                                                                                    echo "<option value = '$selCourseArray[$i]'>$selCourseArray[$i]</option>";
                                                                                }

                                                                                ?>
                                                        </select>
                                                        <?php } else { ?>
                                                        <select name="getoutstanding" class="form-control"
                                                            style="color:#000000" id="getoutstanding"
                                                            required="required">
                                                            <option value="">Select Item ...</option>
                                                            <?php
                                                                                for ($i = 1; $i <= $CountCourseArray; $i++) {
                                                                                    echo "<option value = '$selCourseArray[$i]'>$selCourseArray[$i]</option>";
                                                                                }
                                                                                ?>

                                                        </select>
                                                        <?php } ?>

                                                    </div>
                                                    <br>
                                                </div>
                                                <br>
                                                <div class="row">
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left">Select
                                                        Initial Session:-</label>
                                                    <div class="col-lg-6">
                                                        <?php
                                                                        $iniyear = substr($_SESSION['corntsession'], 5) - 6;
                                                                        $finalyear = substr($_SESSION['corntsession'], 5) - 1;

                                                                        ?>
                                                        <select name="getinisession" class="form-control"
                                                            style="color:#000000" id="getinisession"
                                                            required="required">
                                                            <option value="">Select Item ...</option>
                                                            <?php
                                                                            while ($iniyear <= $finalyear) {
                                                                                $addyear = $iniyear + 1;

                                                                                echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                                                $iniyear++;
                                                                            }

                                                                            ?>


                                                        </select>
                                                    </div>
                                                    <br>
                                                </div>
                                                <?php if ($GroupExist == true) { ?>
                                                <h2 style="color: #9d1e15">Group Already Exist ...</h2>
                                                <?php } else { ?>
                                                <?php if ($IsGroup == false) { ?>
                                                <div class="row" style="padding: 3em; text-align: right">
                                                    <button type="submit" name="submit"
                                                        class="btn btn-primary btn-sm">Submit</button>
                                                </div>
                                                <?php } else { ?>
                                                <h2 style="color: #9d1e15">Some Courses already belong to a group</h2>
                                                <?php } ?>
                                                <?php } ?>


                                            </form>
                                            <?php
                                                        } else {
                                                            echo "<h2 style='color: #9d1e15'>Select Courses for the Group</h2>";
                                                        }
                                                    }
                                                    ?>
                                        </div>
                                        <br><br><br>
                                    </div>

                                </div>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="row" style="padding-left: 3em;">
                                        <div class="col-lg-4">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="regid"
                                                    style="text-align: left">Select Group :-</label>
                                                <div class="col-lg-7">
                                                    <select name="getgroup" class="form-control" style="color:#000000"
                                                        id="getgroup" required="required">
                                                        <option value="">Select Item ...</option>
                                                        <option value="G1">G1</option>
                                                        <option value="G2">G2</option>
                                                        <option value="G3">G3</option>
                                                        <option value="G4">G4</option>
                                                        <option value="G5">G5</option>
                                                        <option value="G6">G6</option>
                                                        <option value="G7">G7</option>
                                                        <option value="G8">G8</option>
                                                        <option value="G9">G9</option>
                                                        <option value="G10">G10</option>
                                                        <option value="G11">G11</option>
                                                        <option value="G12">G12</option>
                                                        <option value="G13">G13</option>
                                                        <option value="G14">G14</option>
                                                        <option value="G15">G15</option>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <br><br><br>
                                    </div>
                                    <?php if ($deptoption == "YES") { ?>
                                    <div class="row" style="padding-left: 3em;">
                                        <div class="col-lg-4">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="regid"
                                                    style="text-align: left">Select Department Option :-</label>
                                                <div class="col-lg-7">
                                                    <select name="getopt" class="form-control" style="color:#000000"
                                                        id="getopt" required="required">
                                                        <option value="">Select Item ...</option>
                                                        <?php
                                                                    $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept'";
                                                                    $result = $conn->query($sql);
                                                                    if ($result->num_rows > 0) {
                                                                        while ($row = $result->fetch_assoc()) {
                                                                            $optcode = strtolower($row["Opt_Code"]);
                                                                            $optname = $row["Opt_Title"];
                                                                            echo "<option value=$optcode>$optname</option>";
                                                                        }
                                                                    }
                                                                    ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <br><br><br>
                                    </div>
                                    <?php } ?>
                                    <div class="col-lg-12">
                                        <table class="table table-bordered table-striped mb-none">
                                            <!--                                    <table class="table table-bordered table-striped mb-none" id="datatable-default">-->
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Check to Select</th>
                                                    <th style='text-align:center'>Course Code</th>
                                                    <th style='text-align:center'>Course Title</th>
                                                    <th style='text-align:center'>Unit</th>
                                                    <th style='text-align:center'>Level</th>
                                                    <?php if ($deptoption == "YES") { ?>
                                                    <?php
                                                                for ($i = 1; $i <= $deptoptCount; $i++) {
                                                                    //$deptoptCount++;
                                                                    //$deptoptionCode[$i] = $row["Opt_Code"];
                                                                    //$deptoptionTitle[$i] = $row["Opt_Title"];
                                                                ?>
                                                    <th style='text-align:center'>
                                                        Group(<?php echo $deptoptionTitle[$i] ?>)
                                                    </th>
                                                    <?php
                                                                }
                                                                ?>

                                                    <?php } else { ?>
                                                    <th style='text-align:center'>Group</th>
                                                    <?php } ?>



                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                        $sno = 0;
                                                        $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                        $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                        if ($conn_stu->connect_error) {
                                                            die("Connection failed: " . $conn_stu->connect_error);
                                                        }
                                                        if ($deptoption == "YES") {
                                                            $sql = "SELECT * FROM gencourses" . $curri2 . " ORDER BY C_codding";
                                                        } else {
                                                            $sql = "SELECT * FROM gencourses" . $curri2 . " ORDER BY Grouping2, C_codding";
                                                        }

                                                        $result = $conn_stu->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $sno++;
                                                                $C_codding = $row["C_codding"];
                                                                $C_title = $row["C_title"];
                                                                $id = $row["id"];
                                                                $credit = $row['credit'];
                                                                $semester = $row["semester"];
                                                                $Nature1 = $row["Nature1"];
                                                                $Level1 = $row["Level1"];
                                                                $Grouping = $row["Grouping2"];
                                                                $Level1 = $row["Level1"];


                                                                echo "<tr><td style='text-align:center'>$sno</td>";
                                                                echo "<td><input type='checkbox' name='chosen1[" . $id . "]' value='" . $id . "'/></td>";
                                                                echo "<td>
                                                    <label id='ccode' name='ccode[" . $id . "]'>$C_codding</label>
                                                    <input type='hidden' id='ccode' name='ccode[" . $id . "]' value='" . $C_codding . "'/>
                                                    </td>";
                                                                echo "<td> $C_title</td>";
                                                                echo "<td> $credit</td>";
                                                                echo "<td> $Level1</td>";
                                                                if ($deptoption == "YES") {
                                                                    for ($i = 1; $i <= $deptoptCount; $i++) {
                                                                        $groupRes = $row["Group" . $deptoptionCode[$i]];
                                                                        echo "<td> $groupRes</td>";
                                                                    }
                                                                } else {
                                                                    echo "<td> $Grouping</td>";
                                                                }


                                                                echo "</tr>\n";
                                                            }
                                                        }


                                                        ?>
                                            </tbody>
                                        </table>
                                        <br><br>
                                    </div>
                                    <div class="row" style="padding: 3em; text-align: right">
                                        <button type="submit" name="view" class="btn btn-primary btn-sm">View</button>
                                    </div>
                                </form>


                                <?php } else { ?>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="row">
                                        <div class="col-lg-2">

                                        </div>

                                        <label class="control-label col-lg-2" for="content">Select
                                            Curriculum:</label>
                                        <div class="col-lg-4">
                                            <select class="form-control" style="color:#000000" name="curri">
                                                <option value="SelectItem">Select Item</option>
                                                <?php
                                                        //$cat = $_SESSION['cat'];
                                                        $dept = $_SESSION['deptcode'];

                                                        $sql = "SELECT * FROM dept_curriculum WHERE deptcode = '$dept'";
                                                        $result = $conn->query($sql);

                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $curricode2 = $row["curri_Code"];
                                                                $curriname2 = $row["curri_Title"];
                                                                echo "<option value=$curricode2>$curriname2</option>";
                                                            }
                                                        }
                                                        ?>

                                            </select>
                                        </div>
                                        <div class="col-lg-2">
                                            <button type="submit" name="submitcurri"
                                                class="btn btn-primary btn-sm">Submit</button>

                                        </div>
                                        <div class="col-lg-2">

                                        </div>
                                    </div>
                                </form>
                                <?php } ?>


                                <?php
                                    $conn->close();
                                    $conn_stu->close();
                                    ?>



                                <?php } else { ?>
                                <?php
                                    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                    if ($conn_stu->connect_error) {
                                        die("Connection failed: " . $conn_stu->connect_error);
                                    }
                                    ?>
                                <h2 style="padding-left: 2em;"><?php echo $deptname ?></h2>
                                <div class="row" style="padding-left: 3em;">
                                    <table>
                                        <thead style='text-align:center'>
                                            <tr style='border: 1px solid #ddd'>
                                                <th style='padding-right: 2em'>Course Code </th>
                                                <th style='padding-right: 2em'>--</th>
                                                <th style='padding-right: 2em'> Group Code</th>
                                                <th style='padding-right: 2em'>--</th>
                                                <th style='padding-right: 2em'> Outstanding Course</th>
                                                <th style='padding-right: 2em'>--</th>
                                                <?php if ($deptoption == "YES") { ?>
                                                <th style='padding-right: 2em'> Department Option</th>
                                                <th style='padding-right: 2em'>--</th>
                                                <?php } ?>
                                                <th style='padding-right: 2em'> Initial Session</th>
                                                <th style='padding-right: 2em'>--</th>
                                                <th>Action</th>
                                            </tr>

                                        </thead>
                                        <tbody>
                                            <?php
                                                $sql = "SELECT * FROM grouping_couses WHERE DeptCode = '$dept' ORDER BY GroupCode";
                                                $result = $conn->query($sql);
                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {
                                                        $id = $row["SNo"];
                                                        $CtCode = $row["RegCourse"];
                                                        $GroupCode = $row["GroupCode"];
                                                        $outsCourse = $row["outsCourse"];
                                                        $inisession = $row["inisession"];
                                                        $getOpt = $row["OptCode"];
                                                        if ($outsCourse == "Multi") {
                                                            $sql2 = "SELECT * FROM grouping_couses_outs WHERE GroupCode = '$GroupCode' AND OptCode = '$getOpt' AND DeptCode = '$dept'";
                                                            $result2 = $conn->query($sql2);
                                                            $outsCourse = "";
                                                            if ($result2->num_rows > 0) {
                                                                while ($row2 = $result2->fetch_assoc()) {
                                                                    $outsCourse = $outsCourse . ", " . $row2["outsCourse"];
                                                                }
                                                            }
                                                        }

                                                        echo "<tr style='border: 1px solid #ddd'>";
                                                        echo "<td style='padding-right: 2em'>$CtCode </td><td style='padding-right: 2em'>--</td><td style='padding-right: 2em'> $GroupCode</td><td style='padding-right: 2em'>--</td><td style='padding-right: 2em'> $outsCourse</td><td style='padding-right: 2em'>--</td>";
                                                        if ($deptoption == "YES") {

                                                            echo "<td style='padding-right: 2em'> $getOpt</td><td style='padding-right: 2em'>--</td>";
                                                        }
                                                        echo "<td style='padding-right: 2em'>$inisession </td><td style='padding-right: 2em'>--</td>";
                                                        echo "<td>
                                                <form class='form-horizontal form-bordered' method='post'>
                                                
                                                    <input type='hidden' value='$id' name='id'>
                                                    
                                                    <input type='submit' name='delete' class='btn btn-danger btn-xs' value='Delete'>
                                                </form>
                                                </td>";
                                                        echo "</tr>";
                                                    }
                                                }

                                                ?>
                                        </tbody>
                                    </table>
                                    <br><br>
                                </div>
                                <div class="row" style="padding-left: 3em;">
                                    <div class="col-lg-4">
                                        <div class="row">
                                            <?php
                                                if (isset($_POST["delete"])) {

                                                    $id = $_POST["id"];
                                                    $sql = "SELECT * FROM grouping_couses WHERE SNo ='$id'";
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $DelGroup = $row["GroupCode"];
                                                            if ($deptoption == "YES") {
                                                                $DOpt = $row["OptCode"];
                                                            }
                                                        }
                                                    }

                                                ?>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <div class="row">
                                                    <h2 style="color: blue">
                                                        <?php
                                                                if ($deptoption == "YES") {
                                                                    echo "Confirm Deleting Group " . $DelGroup . " for " . $DOpt;
                                                                } else {
                                                                    echo "Confirm Deleting Group " . $DelGroup;
                                                                }

                                                                ?> ?
                                                    </h2>
                                                    <input type='hidden' id='DelGroup' name='DelGroup'
                                                        value='<?php echo $DelGroup ?>' />
                                                    <?php if ($deptoption == "YES") { ?>
                                                    <input type='hidden' id='DelOptGroup' name='DelOptGroup'
                                                        value='<?php echo $DOpt ?>' />
                                                    <?php } ?>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <button type="submit" name="confno"
                                                            class="btn btn-primary btn-sm">NO</button>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <button type="submit" name="confyes"
                                                            class="btn btn-primary btn-sm">YES</button>
                                                    </div>

                                                </div>
                                            </form>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" style="padding-left: 3em;">
                                    <div class="col-lg-4">
                                        <div class="row">
                                            <?php
                                                if (isset($_POST["view"])) {
                                                    $GroupExist = false;
                                                    $getgroup = $_POST["getgroup"];
                                                    if ($deptoption == "YES") {
                                                        $getopt = strtoupper($_POST["getopt"]);
                                                        $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept' AND Opt_Code = '$getopt' ";
                                                        $result = $conn->query($sql);
                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $optname = $row["Opt_Title"];
                                                            }
                                                        }
                                                    }
                                                    if ($deptoption == "YES") {
                                                        $sql = "SELECT * FROM grouping_couses WHERE DeptCode = '$dept' AND GroupCode ='$getgroup' AND OptCode ='$getopt'";
                                                    } else {
                                                        $sql = "SELECT * FROM grouping_couses WHERE DeptCode = '$dept' AND GroupCode ='$getgroup'";
                                                    }
                                                    $result = $conn->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $GroupExist = true;
                                                        }
                                                    }
                                                    unset($selCourseArray);
                                                    $CountCourseArray = 0;
                                                    $ccode2 = "";
                                                    $CGroup = "";
                                                    $IsGroup = false;

                                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    if (!empty($_POST["chosen1"])) {
                                                        foreach ($_POST["chosen1"] as $key => $value) {
                                                            $CountCourseArray++;
                                                            $ccode = $_POST["ccode"][$key];
                                                            $selCourseArray[$CountCourseArray] = $ccode;
                                                            $sql = "SELECT * FROM gencourses WHERE C_codding = '$ccode'";
                                                            $result = $conn_stu->query($sql);
                                                            if ($result->num_rows > 0) {
                                                                while ($row = $result->fetch_assoc()) {
                                                                    if ($deptoption == "YES") {
                                                                        $CGroup = $row["Group" . $getopt];
                                                                    } else {
                                                                        $CGroup = $row["Grouping2"];
                                                                    }
                                                                }
                                                            }
                                                            if ($CGroup == "NO") {
                                                                $ccode2 = $ccode2 . $_POST["ccode"][$key] . "<br>";
                                                            } else {
                                                                $IsGroup = true;
                                                                $ccode2 = $ccode2 . $_POST["ccode"][$key] . "(" . $CGroup . ")<br>";
                                                            }
                                                        }
                                                        $_SESSION["CountCourseArray"] = $CountCourseArray;
                                                        $_SESSION["selCourseArray"] = $selCourseArray;
                                                        $_SESSION["getgroup"] = $getgroup;
                                                        if ($deptoption == "YES") {
                                                            $_SESSION["getopt"] = $getopt;
                                                        }

                                                ?>
                                            <form class="form-horizontal form-bordered" method="post">
                                                <div class="row">
                                                    <label class="control-label col-lg-6" style="text-align: left">Group
                                                        :-</label>
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left"><?php echo $getgroup ?></label>
                                                </div>
                                                <?php if ($deptoption == "YES") { ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left">Department Option :-</label>
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left"><?php echo $optname ?></label>
                                                </div>
                                                <?php } ?>
                                                <div class="row">
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left">Courses
                                                        :-</label>
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left"><?php echo $ccode2 ?></label>
                                                    <br>
                                                </div>
                                                <div class="row">
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left">Select
                                                        Outstanding Course :-</label>
                                                    <div class="col-lg-6">
                                                        <?php if ($CountCourseArray > 2) { ?>

                                                        <!--Select Multiple-->
                                                        <select id="getoutstanding" name="getoutstanding[]"
                                                            placeholder="Select Courses(max of 3)" multiple required>

                                                            <?php
                                                                            for ($i = 1; $i <= $CountCourseArray; $i++) {
                                                                                echo "<option value = '$selCourseArray[$i]'>$selCourseArray[$i]</option>";
                                                                            }

                                                                            ?>
                                                        </select>


                                                        <?php } else { ?>
                                                        <select name="getoutstanding" class="form-control"
                                                            style="color:#000000" id="getoutstanding"
                                                            required="required">
                                                            <option value="">Select Item ...</option>
                                                            <?php
                                                                            for ($i = 1; $i <= $CountCourseArray; $i++) {
                                                                                echo "<option value = '$selCourseArray[$i]'>$selCourseArray[$i]</option>";
                                                                            }
                                                                            ?>

                                                        </select>
                                                        <?php } ?>
                                                    </div>
                                                    <br>
                                                </div>
                                                <br>
                                                <div class="row">
                                                    <label class="control-label col-lg-6"
                                                        style="text-align: left">Select
                                                        Initial Session:-</label>
                                                    <div class="col-lg-6">
                                                        <?php
                                                                    $iniyear = substr($_SESSION['corntsession'], 5) - 6;
                                                                    $finalyear = substr($_SESSION['corntsession'], 5) - 1;

                                                                    ?>
                                                        <select name="getinisession" class="form-control"
                                                            style="color:#000000" id="getinisession"
                                                            required="required">
                                                            <option value="">Select Item ...</option>
                                                            <?php
                                                                        while ($iniyear <= $finalyear) {
                                                                            $addyear = $iniyear + 1;

                                                                            echo "<option value = '$iniyear/$addyear'>$iniyear/$addyear</option>";
                                                                            $iniyear++;
                                                                        }

                                                                        ?>


                                                        </select>
                                                    </div>
                                                    <br>
                                                </div>
                                                <?php if ($GroupExist == true) { ?>
                                                <h2 style="color: #9d1e15">Group Already Exist ...</h2>
                                                <?php } else { ?>
                                                <?php if ($IsGroup == false) { ?>
                                                <div class="row" style="padding: 3em; text-align: right">
                                                    <button type="submit" name="submit"
                                                        class="btn btn-primary btn-sm">Submit</button>
                                                </div>
                                                <?php } else { ?>
                                                <h2 style="color: #9d1e15">Some Courses already belong to a group</h2>
                                                <?php } ?>
                                                <?php } ?>


                                            </form>
                                            <?php
                                                    } else {
                                                        echo "<h2 style='color: #9d1e15'>Select Courses for the Group</h2>";
                                                    }
                                                }
                                                ?>
                                        </div>
                                        <br><br><br>
                                    </div>

                                </div>
                                <form class="form-horizontal form-bordered" method="post">
                                    <div class="row" style="padding-left: 3em;">
                                        <div class="col-lg-4">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="regid"
                                                    style="text-align: left">Select Group :-</label>
                                                <div class="col-lg-7">
                                                    <select name="getgroup" class="form-control" style="color:#000000"
                                                        id="getgroup" required="required">
                                                        <option value="">Select Item ...</option>
                                                        <option value="G1">G1</option>
                                                        <option value="G2">G2</option>
                                                        <option value="G3">G3</option>
                                                        <option value="G4">G4</option>
                                                        <option value="G5">G5</option>
                                                        <option value="G6">G6</option>
                                                        <option value="G7">G7</option>
                                                        <option value="G8">G8</option>
                                                        <option value="G9">G9</option>
                                                        <option value="G10">G10</option>
                                                        <option value="G11">G11</option>
                                                        <option value="G12">G12</option>
                                                        <option value="G13">G13</option>
                                                        <option value="G14">G14</option>
                                                        <option value="G15">G15</option>

                                                    </select>
                                                </div>
                                            </div>

                                        </div>
                                        <br><br><br>
                                    </div>

                                    <?php if ($deptoption == "YES") { ?>
                                    <div class="row" style="padding-left: 3em;">
                                        <div class="col-lg-4">
                                            <div class="row">
                                                <label class="control-label col-lg-5" for="regid"
                                                    style="text-align: left">Select Department Option :-</label>
                                                <div class="col-lg-7">
                                                    <select name="getopt" class="form-control" style="color:#000000"
                                                        id="getopt" required="required">
                                                        <option value="">Select Item ...</option>
                                                        <?php
                                                                $sql = "SELECT * FROM dept_option WHERE deptcode = '$dept'";
                                                                $result = $conn->query($sql);
                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $optcode = strtolower($row["Opt_Code"]);
                                                                        $optname = $row["Opt_Title"];
                                                                        echo "<option value=$optcode>$optname</option>";
                                                                    }
                                                                }
                                                                ?>

                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <br><br><br>
                                    </div>
                                    <?php } ?>
                                    <div class="col-lg-12">
                                        <table class="table table-bordered table-striped mb-none">
                                            <!--                                    <table class="table table-bordered table-striped mb-none" id="datatable-default">-->
                                            <thead style='text-align:center'>
                                                <tr>
                                                    <th>S/No</th>
                                                    <th>Check to Select</th>
                                                    <th style='text-align:center'>Course Code</th>
                                                    <th style='text-align:center'>Course Title</th>
                                                    <th style='text-align:center'>Unit</th>
                                                    <th style='text-align:center'>Level</th>
                                                    <?php if ($deptoption == "YES") { ?>
                                                    <?php
                                                            for ($i = 1; $i <= $deptoptCount; $i++) {
                                                                //$deptoptCount++;
                                                                //$deptoptionCode[$i] = $row["Opt_Code"];
                                                                //$deptoptionTitle[$i] = $row["Opt_Title"];
                                                            ?>
                                                    <th style='text-align:center'>
                                                        Group(<?php echo $deptoptionTitle[$i] ?>)
                                                    </th>
                                                    <?php
                                                            }
                                                            ?>

                                                    <?php } else { ?>
                                                    <th style='text-align:center'>Group</th>
                                                    <?php } ?>



                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $sno = 0;
                                                    $dept_db = $_SESSION['deptdb'] . strtolower($dept);
                                                    $conn_stu = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, $dept_db);
                                                    if ($conn_stu->connect_error) {
                                                        die("Connection failed: " . $conn_stu->connect_error);
                                                    }

                                                    if ($deptoption == "YES") {
                                                        $sql = "SELECT * FROM gencourses ORDER BY C_codding";
                                                    } else {
                                                        $sql = "SELECT * FROM gencourses ORDER BY Grouping2, C_codding";
                                                    }

                                                    $result = $conn_stu->query($sql);
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            $sno++;
                                                            $C_codding = $row["C_codding"];
                                                            $C_title = $row["C_title"];
                                                            $id = $row["id"];
                                                            $credit = $row['credit'];
                                                            $semester = $row["semester"];
                                                            $Nature1 = $row["Nature1"];
                                                            $Level1 = $row["Level1"];
                                                            $Grouping = $row["Grouping2"];
                                                            $Level1 = $row["Level1"];


                                                            echo "<tr><td style='text-align:center'>$sno</td>";
                                                            echo "<td><input type='checkbox' name='chosen1[" . $id . "]' value='" . $id . "'/></td>";
                                                            echo "<td>
                                                    <label id='ccode' name='ccode[" . $id . "]'>$C_codding</label>
                                                    <input type='hidden' id='ccode' name='ccode[" . $id . "]' value='" . $C_codding . "'/>
                                                    </td>";
                                                            echo "<td> $C_title</td>";
                                                            echo "<td> $credit</td>";
                                                            echo "<td> $Level1</td>";
                                                            if ($deptoption == "YES") {
                                                                for ($i = 1; $i <= $deptoptCount; $i++) {
                                                                    $groupRes = $row["Group" . $deptoptionCode[$i]];
                                                                    echo "<td> $groupRes</td>";
                                                                }
                                                            } else {
                                                                echo "<td> $Grouping</td>";
                                                            }


                                                            echo "</tr>\n";
                                                        }
                                                    }


                                                    ?>
                                            </tbody>
                                        </table>
                                        <br><br>
                                    </div>
                                    <div class="row" style="padding: 3em; text-align: right">
                                        <button type="submit" name="view" class="btn btn-primary btn-sm">View</button>
                                    </div>
                                </form>

                                <?php
                                    $conn->close();
                                    $conn_stu->close();
                                    ?>
                                <?php } ?>


                            </div>


                        </div>
                    </div>



                </div>
            </div>

            <div class="footer">
                <?php
                include_once 'includes/footer2.php';
                ?>
            </div>
        </div>
        <div id="right-sidebar">

            <?php
            include_once 'includes/aside_right.php';
            ?>

        </div>

    </div>

    <?php
    include_once 'includes/footer.php';
    ?>
    <!-- Table -->
    <script src="js/plugins/dataTables/datatables.min.js"></script>


    <script>
    $(document).ready(function() {

        var multipleCancelButton = new Choices('#getoutstanding', {
            removeItemButton: true,
            maxItemCount: 3,
            searchResultLimit: 3
            /* renderChoiceLimit: 7 */
        });


    });
    </script>

</body>

</html>
<?php
require_once '../includes/db_connect.php';
if (isset($_POST['id'])) {
	$id =  $_POST['id'];

	$sql = "DELETE FROM deptcourses WHERE id ='$id'";
	$result = $conn->query($sql);



	echo 1;
	exit;
}

echo 0;
exit;

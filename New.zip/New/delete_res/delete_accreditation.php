<?php
require_once '../includes/db_connect2.php';
if (isset($_POST['id'])) {
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sn = $_POST["id"];
    $sql = "DELETE FROM dept_accreditation WHERE sn='$sn'";
    $result = $conn->query($sql);
    $conn->close();

    echo 1;
    exit;
}

echo 0;
exit;

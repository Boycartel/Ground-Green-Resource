<?php

require_once '../includes/db_connect2.php';
if (isset($_GET['id'])) {
    $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql = "DELETE FROM deptcourses WHERE id=" . $_GET['id'];
    $conn->query($sql);
    $conn->close();

    echo 'Record deleted successfully.';
}

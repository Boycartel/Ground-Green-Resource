<?php
require_once '../includes/db_connect2.php';
if (isset($_POST['id'])) {
	$id =  $_POST['id'];

	$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$conn2 = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE2);
	if ($conn2->connect_error) {
		die("Connection failed: " . $conn2->connect_error);
	}

	$sql = "SELECT * FROM missing_session WHERE id ='$id'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		while ($row = $result->fetch_assoc()) {
			$oldstatus = $row["oldstatus"];
			$matno = $row["matno"];
		}
	}



	$sql = "UPDATE std_data_view set status = '$oldstatus' WHERE matric_no = '$matno'";
	$result = $conn2->query($sql);

	$sql = "DELETE FROM missing_session WHERE id = '$id'";
	$result = $conn->query($sql);
	$conn->close();
	$conn2->close();

	echo 1;
	exit;
}

echo 0;
exit;
